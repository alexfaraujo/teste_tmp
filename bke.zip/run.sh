#!/usr/bin/env bash
set -e

echo "=== Inicializando Backend LGBM (Linux) ==="

if [ ! -d "venv" ]; then
    echo "Criando ambiente virtual (venv)..."
    python3 -m venv venv
fi

source venv/bin/activate

echo "Instalando/Atualizando dependências..."
pip install --upgrade pip
if [ -f "requirements.txt" ]; then
    pip install -r requirements.txt
fi

if [ ! -f ".env" ]; then
    echo "Copiando .env.example para .env..."
    cp .env.example .env
fi

echo "Iniciando servidor FastAPI com hot-reload..."
uvicorn src.presentation.main:app --reload --port 8000 --host 0.0.0.0
