from sqlmodel import SQLModel, Field, Relationship
from datetime import date


class Paciente(SQLModel, table=True):
    __tablename__ = "pacientes"

    id: int | None = Field(default=None, primary_key=True)
    nome: str
    data_nascimento: date
    recem_nascido: bool
    etnia: str
    genero: str
    naturalidade: str
    observacao: str
    status: bool = True

    unidade_id: int = Field(
        foreign_key="unidades.id"
    )

    unidade: "Unidade" = Relationship(
        back_populates="pacientes"
    )

    endereco_id: int = Field(
        foreign_key="enderecos.id"
    )

    endereco: "Endereco" = Relationship(
        back_populates="pacientes"
    )

    amostras: list["Amostras"] = Relationship(
        back_populates="paciente"
    )