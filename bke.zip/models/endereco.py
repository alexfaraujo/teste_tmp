from sqlmodel import SQLModel, Field, Relationship


class Endereco(SQLModel, table=True):
    __tablename__ = "enderecos"

    id: int | None = Field(default=None, primary_key=True)
    estado: str
    cidade: str
    cep: str
    bairro: str
    rua: str
    numero: str
    status: bool= True

    unidade: "Unidade" = Relationship(
        back_populates = "endereco"
    )

    pacientes: list["Paciente"] = Relationship(
        back_populates="endereco"
    )

    solicitantes: list["Solicitantes"] = Relationship(
        back_populates="endereco"
    )

