from sqlmodel import SQLModel, Field, Relationship


class User(SQLModel, table=True):
    __tablename__ = "users"

    id: int | None = Field(default=None, primary_key=True)
    nome: str
    email: str
    password: str
    status: bool = True


    # para identificar de qual unidade o user é
    unidade_id: int = Field(
        foreign_key="unidades.id"
    )
    
    # para conectar unidade ---> user
    unidade: "Unidade" = Relationship(
        back_populates="users"
    )