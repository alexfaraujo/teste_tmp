from sqlmodel import SQLModel, Field, Relationship
from datetime import date

class Solicitante(SQLModel, table=True):
    __tablename__ = "solicitantes"

    id: int | None = Field(default=None, primary_key=True)
    nome: str 
    email: str
    contato: str
    observacao: str
    status: bool = True

    endereco_id: int = Field(
        foreign_key="enderecos.id"
    )

    endereco: "Endereco" = Relationship(
        back_populates="solicitantes"
    )

    amostras: list["Amostras"] = Relationship(
        back_populates="solicitante"
    )