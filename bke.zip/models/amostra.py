from sqlmodel import SQLModel, Field, Relationship
from datetime import date
from .amostras_exames import AmostrasExames

class Amostra(SQLModel, table=True):
    __tablename__ = "amostras"

    id: int | None = Field(default=None, primary_key=True)
    nome: str
    data_coleta: date
    data_envio: date
    data_nascimento: date
    data_recebimento: date
    idade_paciente: str
    material: str  
    sexo: str  
    gestante: str  
    semanas_gestacao: int | None = None
    recem_nascido: bool = False
    naturalidade: str
    etnia: str  
    suspeita_diagnostico: str
    transfusao_sangue: str  
    ultima_transfusao: date | None = None
    # codigo_barras ??

    # Hemograma / bioquímica
    eritrocitos: float | None = None            
    reticulocitos_pct: float | None = None       
    reticulocitos_mm3: float | None = None       
    hemoglobina: float | None = None             
    desidrogenase_lactica: float | None = None   
    hematocrito: float | None = None              
    bilirrubina_total: float | None = None        
    bilirrubina_indireta: float | None = None
    bilirrubina_direta: float | None = None
    vcm: float | None = None                     
    ferritina: float | None = None                
    hcm: float | None = None                      
    chcm: float | None = None                     
    rdw: float | None = None                      
    outros_exames_auxiliares: str | None = None

    uso_hidroxiureia: str  
    uso_medicamento: str   
    medicamentos: str | None = None  
    observacao: str | None = None
    anexo_documento: str | None = None  
    status: bool = True

    paciente_id: int = Field(
        foreign_key="pacientes.id"
    )
    paciente: "Paciente" = Relationship(
        back_populates="amostras"
    )

    solicitante_id: int = Field(
        foreign_key="solicitantes.id"
    )
    solicitante: "Solicitantes" = Relationship(
        back_populates="amostras"
    )

    exames: list["Exames"] = Relationship(
        back_populates="amostras",
        link_model=AmostrasExames
    )