from sqlmodel import SQLModel, Field, Relationship
from datetime import date
from .amostras_exames import AmostrasExames

class Exame(SQLModel, table=True):
  __tablename__ = "exames"

  id: int | None = Field(default=None, primary_key=True)
  nome: str 
  sigla: str
  tipo_exame: str
  metodo: str
  preco: float
  valor_referencia: float
  tipo_referencia: str 
  tipo_valor_resultado: str
  observacao: str
  status: bool = True


  amostras: list["Amostras"] = Relationship(
    back_populates="exames",
    link_model=AmostrasExames
  )
