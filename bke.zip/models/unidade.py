from sqlmodel import SQLModel, Field, Relationship


class Unidade(SQLModel, table=True):
    __tablename__ = "unidades"

    id: int | None = Field(default=None, primary_key=True)
    email: str
    observacao: str
    status: bool = True

    endereco_id: int = Field(
        foreign_key="enderecos.id",
        unique=True
    )


    endereco: "Endereco" = Relationship(
        back_populates="unidade"
    )

    #list: para saber os users que fazem parte dessa unidade
    users: list["User"] = Relationship(
        back_populates="unidade"
    )

    
    pacientes: list["Paciente"] = Relationship(
        back_populates="unidade"
    )