from sqlmodel import SQLModel, Field, Relationship

class AmostraExame(SQLModel, table=True):
  __tablename__ = "amostras_exames"

  amostra_id: int = Field(
    foreign_key="amostras.id",
    primary_key=True
  )

  exame_id: int = Field(
    foreign_key="exames.id",
    primary_key=True
  )