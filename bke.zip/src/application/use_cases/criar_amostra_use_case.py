from datetime import date
from sqlalchemy.orm import Session
from src.application.dtos.amostra_dto import AmostraCreateDTO, AmostraResponseDTO
from src.domain.entities.amostra import AmostraEntity
from src.infrastructure.repositories.amostra_repository_impl import AmostraRepositoryImpl
from src.infrastructure.models.paciente_model import PacienteModel
from src.infrastructure.models.solicitante_model import SolicitanteModel

class CriarAmostraUseCase:
    def __init__(self, db: Session):
        self.db = db
        self.repo = AmostraRepositoryImpl(db)

    def execute(self, dto: AmostraCreateDTO) -> AmostraResponseDTO:
        today = date.today()
        dt_nascimento = dto.data_nascimento or date(1990, 1, 1)

        # 1. Buscar ou cadastrar o Paciente
        paciente = self.db.query(PacienteModel).filter(
            PacienteModel.nome == dto.nome,
            PacienteModel.deleted_at.is_(None)
        ).first()

        if not paciente:
            paciente = PacienteModel(
                nome=dto.nome,
                data_nascimento=dt_nascimento,
                recem_nascido=dto.recem_nascido,
                etnia=dto.etnia or "Parda",
                genero=dto.sexo or "M",
                naturalidade=dto.naturalidade or "Não informada",
                observacao="Cadastrado via formulário de amostra"
            )
            self.db.add(paciente)
            self.db.commit()
            self.db.refresh(paciente)

        # 2. Buscar ou cadastrar Solicitante (se informado)
        solicitante_id = None
        if dto.solicitante:
            solicitante = self.db.query(SolicitanteModel).filter(
                SolicitanteModel.nome == dto.solicitante,
                SolicitanteModel.deleted_at.is_(None)
            ).first()
            if not solicitante:
                solicitante = SolicitanteModel(
                    nome=dto.solicitante,
                    observacao="Cadastrado automaticamente via requisição de amostra"
                )
                self.db.add(solicitante)
                self.db.commit()
                self.db.refresh(solicitante)
            solicitante_id = solicitante.id

        # 3. Criar Entidade Amostra
        amostra_entity = AmostraEntity(
            id=None,
            nome=f"AM-{dto.nome[:3].upper()}-{today.strftime('%Y%m%d')}",
            data_coleta=dto.data_coleta or today,
            data_envio=dto.data_envio or today,
            data_recebimento=dto.data_recebimento or today,
            data_nascimento=dt_nascimento,
            idade_paciente=dto.idade_paciente or "Não informada",
            material=dto.material or "Sangue total",
            sexo=dto.sexo or "M",
            gestante=dto.gestante or "NA",
            semanas_gestacao=dto.semanas_gestacao,
            recem_nascido=dto.recem_nascido,
            naturalidade=dto.naturalidade or "Não informada",
            etnia=dto.etnia or "Parda",
            suspeita_diagnostico=dto.suspeita_diagnostico or "Em investigação",
            transfusao_sangue=dto.transfusao_sangue or "Não",
            ultima_transfusao=dto.ultima_transfusao,
            paciente_id=paciente.id,
            solicitante_id=solicitante_id,
            eritrocitos=dto.eritrocitos,
            reticulocitos_pct=dto.reticulocitos_pct,
            reticulocitos_mm3=dto.reticulocitos_mm3,
            hemoglobina=dto.hemoglobina,
            desidrogenase_lactica=dto.desidrogenase_lactica,
            hematocrito=dto.hematocrito,
            bilirrubina_total=dto.bilirrubina_total,
            bilirrubina_indireta=dto.bilirrubina_indireta,
            bilirrubina_direta=dto.bilirrubina_direta,
            vcm=dto.vcm,
            ferritina=dto.ferritina,
            hcm=dto.hcm,
            chcm=dto.chcm,
            rdw=dto.rdw,
            outros_exames_auxiliares=dto.outros_exames_auxiliares,
            quais_exames=dto.quaisExames,
            uso_hidroxiureia=dto.uso_hidroxiureia or "Não",
            uso_medicamento=dto.uso_medicamento or "Não",
            medicamentos=dto.medicamentos,
            observacao=dto.observacoes,
            anexo_documento=dto.anexo_documento
        )

        saved = self.repo.save(amostra_entity)
        total_paciente = self.repo.count_by_paciente_id(paciente.id)

        return AmostraResponseDTO(
            id=saved.id,
            nome=saved.nome,
            status_formatado="Processando" if saved.status else "Inativa",
            data_formatada=saved.data_coleta.strftime("%d/%m/%Y"),
            paciente_nome=paciente.nome,
            paciente_total_amostras=total_paciente,
            data_coleta=saved.data_coleta,
            data_envio=saved.data_envio,
            material=saved.material,
            sexo=saved.sexo,
            etnia=saved.etnia,
            naturalidade=saved.naturalidade,
            suspeita_diagnostico=saved.suspeita_diagnostico,
            outros_exames_auxiliares=saved.outros_exames_auxiliares,
            quais_exames=saved.quais_exames,
            observacao=saved.observacao,
            status=saved.status,
            deleted_at=saved.deleted_at
        )
