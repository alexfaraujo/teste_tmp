from typing import List
from datetime import date
from sqlalchemy.orm import Session
from src.application.dtos.paciente_dto import PacienteResponseDTO
from src.infrastructure.repositories.paciente_repository_impl import PacienteRepositoryImpl

class ListarPacientesUseCase:
    def __init__(self, db: Session):
        self.db = db
        self.repo = PacienteRepositoryImpl(db)

    def execute(self, skip: int = 0, limit: int = 100) -> List[PacienteResponseDTO]:
        pacientes = self.repo.find_all(skip=skip, limit=limit)
        result = []
        today = date.today()

        for p in pacientes:
            idade = (today - p.data_nascimento).days // 365
            total_amostras = self.repo.count_amostras(p.id)

            result.append(
                PacienteResponseDTO(
                    id=p.id,
                    nome=p.nome,
                    data_nascimento=p.data_nascimento,
                    idade=idade,
                    recem_nascido=p.recem_nascido,
                    etnia=p.etnia,
                    genero=p.genero,
                    naturalidade=p.naturalidade,
                    amostras_registradas=total_amostras,
                    observacao=p.observacao,
                    status=p.status,
                    deleted_at=p.deleted_at
                )
            )

        return result
