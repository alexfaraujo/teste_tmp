from typing import Optional
from datetime import date
from sqlalchemy.orm import Session
from src.application.dtos.paciente_dto import PacienteUpdateDTO, PacienteResponseDTO
from src.domain.entities.paciente import PacienteEntity
from src.infrastructure.repositories.paciente_repository_impl import PacienteRepositoryImpl

class AtualizarPacienteUseCase:
    def __init__(self, db: Session):
        self.db = db
        self.repo = PacienteRepositoryImpl(db)

    def execute(self, id: int, dto: PacienteUpdateDTO) -> Optional[PacienteResponseDTO]:
        existing = self.repo.find_by_id(id)
        if not existing:
            return None

        updated_entity = PacienteEntity(
            id=existing.id,
            nome=dto.nome or existing.nome,
            data_nascimento=dto.data_nascimento or existing.data_nascimento,
            recem_nascido=dto.recem_nascido if dto.recem_nascido is not None else existing.recem_nascido,
            etnia=dto.etnia or existing.etnia,
            genero=dto.genero or existing.genero,
            naturalidade=dto.naturalidade or existing.naturalidade,
            observacao=dto.observacao if dto.observacao is not None else existing.observacao,
            status=existing.status,
            deleted_at=existing.deleted_at
        )

        saved = self.repo.update(id, updated_entity)
        if not saved:
            return None

        total = self.repo.count_amostras(saved.id)
        idade = (date.today() - saved.data_nascimento).days // 365

        return PacienteResponseDTO(
            id=saved.id,
            nome=saved.nome,
            data_nascimento=saved.data_nascimento,
            idade=idade,
            recem_nascido=saved.recem_nascido,
            etnia=saved.etnia,
            genero=saved.genero,
            naturalidade=saved.naturalidade,
            amostras_registradas=total,
            observacao=saved.observacao,
            status=saved.status,
            deleted_at=saved.deleted_at
        )
