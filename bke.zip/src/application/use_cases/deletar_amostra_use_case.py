from sqlalchemy.orm import Session
from src.infrastructure.repositories.amostra_repository_impl import AmostraRepositoryImpl

class DeletarAmostraUseCase:
    def __init__(self, db: Session):
        self.db = db
        self.repo = AmostraRepositoryImpl(db)

    def execute(self, id: int) -> bool:
        return self.repo.soft_delete(id)
