from typing import Optional
from sqlalchemy.orm import Session
from src.application.dtos.amostra_dto import AmostraCreateDTO, AmostraResponseDTO
from src.domain.entities.amostra import AmostraEntity
from src.infrastructure.repositories.amostra_repository_impl import AmostraRepositoryImpl
from src.infrastructure.models.paciente_model import PacienteModel

class AtualizarAmostraUseCase:
    def __init__(self, db: Session):
        self.db = db
        self.repo = AmostraRepositoryImpl(db)

    def execute(self, id: int, dto: AmostraCreateDTO) -> Optional[AmostraResponseDTO]:
        existing = self.repo.find_by_id(id)
        if not existing:
            return None

        updated_entity = AmostraEntity(
            id=existing.id,
            nome=dto.nome or existing.nome,
            data_coleta=dto.data_coleta or existing.data_coleta,
            data_envio=dto.data_envio or existing.data_envio,
            data_recebimento=dto.data_recebimento or existing.data_recebimento,
            data_nascimento=dto.data_nascimento or existing.data_nascimento,
            idade_paciente=dto.idade_paciente or existing.idade_paciente,
            material=dto.material or existing.material,
            sexo=dto.sexo or existing.sexo,
            gestante=dto.gestante or existing.gestante,
            semanas_gestacao=dto.semanas_gestacao if dto.semanas_gestacao is not None else existing.semanas_gestacao,
            recem_nascido=dto.recem_nascido if dto.recem_nascido is not None else existing.recem_nascido,
            naturalidade=dto.naturalidade or existing.naturalidade,
            etnia=dto.etnia or existing.etnia,
            suspeita_diagnostico=dto.suspeita_diagnostico or existing.suspeita_diagnostico,
            transfusao_sangue=dto.transfusao_sangue or existing.transfusao_sangue,
            ultima_transfusao=dto.ultima_transfusao if dto.ultima_transfusao is not None else existing.ultima_transfusao,
            paciente_id=existing.paciente_id,
            solicitante_id=existing.solicitante_id,
            eritrocitos=dto.eritrocitos if dto.eritrocitos is not None else existing.eritrocitos,
            reticulocitos_pct=dto.reticulocitos_pct if dto.reticulocitos_pct is not None else existing.reticulocitos_pct,
            reticulocitos_mm3=dto.reticulocitos_mm3 if dto.reticulocitos_mm3 is not None else existing.reticulocitos_mm3,
            hemoglobina=dto.hemoglobina if dto.hemoglobina is not None else existing.hemoglobina,
            desidrogenase_lactica=dto.desidrogenase_lactica if dto.desidrogenase_lactica is not None else existing.desidrogenase_lactica,
            hematocrito=dto.hematocrito if dto.hematocrito is not None else existing.hematocrito,
            bilirrubina_total=dto.bilirrubina_total if dto.bilirrubina_total is not None else existing.bilirrubina_total,
            bilirrubina_indireta=dto.bilirrubina_indireta if dto.bilirrubina_indireta is not None else existing.bilirrubina_indireta,
            bilirrubina_direta=dto.bilirrubina_direta if dto.bilirrubina_direta is not None else existing.bilirrubina_direta,
            vcm=dto.vcm if dto.vcm is not None else existing.vcm,
            ferritina=dto.ferritina if dto.ferritina is not None else existing.ferritina,
            hcm=dto.hcm if dto.hcm is not None else existing.hcm,
            chcm=dto.chcm if dto.chcm is not None else existing.chcm,
            rdw=dto.rdw if dto.rdw is not None else existing.rdw,
            outros_exames_auxiliares=dto.outros_exames_auxiliares or existing.outros_exames_auxiliares,
            quais_exames=dto.quaisExames or existing.quais_exames,
            uso_hidroxiureia=dto.uso_hidroxiureia or existing.uso_hidroxiureia,
            uso_medicamento=dto.uso_medicamento or existing.uso_medicamento,
            medicamentos=dto.medicamentos or existing.medicamentos,
            observacao=dto.observacoes or existing.observacao,
            anexo_documento=dto.anexo_documento or existing.anexo_documento,
            status=existing.status,
            deleted_at=existing.deleted_at
        )

        saved = self.repo.update(id, updated_entity)
        if not saved:
            return None

        paciente = self.db.query(PacienteModel).filter(PacienteModel.id == saved.paciente_id).first()
        paciente_nome = paciente.nome if paciente else "Não identificado"
        total_amostras = self.repo.count_by_paciente_id(saved.paciente_id) if paciente else 1

        return AmostraResponseDTO(
            id=saved.id,
            nome=saved.nome,
            status_formatado="Processando" if saved.status else "Inativa",
            data_formatada=saved.data_coleta.strftime("%d/%m/%Y"),
            paciente_nome=paciente_nome,
            paciente_total_amostras=total_amostras,
            data_coleta=saved.data_coleta,
            data_envio=saved.data_envio,
            material=saved.material,
            sexo=saved.sexo,
            etnia=saved.etnia,
            naturalidade=saved.naturalidade,
            suspeita_diagnostico=saved.suspeita_diagnostico,
            outros_exames_auxiliares=saved.outros_exames_auxiliares,
            quais_exames=saved.quais_exames,
            observacao=saved.observacao,
            status=saved.status,
            deleted_at=saved.deleted_at
        )
