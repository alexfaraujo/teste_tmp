from datetime import date
from sqlalchemy.orm import Session
from src.application.dtos.paciente_dto import PacienteCreateDTO, PacienteResponseDTO
from src.domain.entities.paciente import PacienteEntity
from src.infrastructure.repositories.paciente_repository_impl import PacienteRepositoryImpl

class CriarPacienteUseCase:
    def __init__(self, db: Session):
        self.db = db
        self.repo = PacienteRepositoryImpl(db)

    def execute(self, dto: PacienteCreateDTO) -> PacienteResponseDTO:
        # Verificar se paciente já existe (busca por nome + data_nascimento)
        existing = self.repo.find_by_nome_e_nascimento(dto.nome, dto.data_nascimento)
        if existing:
            total = self.repo.count_amostras(existing.id)
            idade = (date.today() - existing.data_nascimento).days // 365
            return PacienteResponseDTO(
                id=existing.id,
                nome=existing.nome,
                data_nascimento=existing.data_nascimento,
                idade=idade,
                recem_nascido=existing.recem_nascido,
                etnia=existing.etnia,
                genero=existing.genero,
                naturalidade=existing.naturalidade,
                amostras_registradas=total,
                observacao=existing.observacao,
                status=existing.status,
                deleted_at=existing.deleted_at
            )

        entity = PacienteEntity(
            id=None,
            nome=dto.nome,
            data_nascimento=dto.data_nascimento,
            recem_nascido=dto.recem_nascido,
            etnia=dto.etnia or "Parda",
            genero=dto.genero or "M",
            naturalidade=dto.naturalidade or "Não informada",
            observacao=dto.observacao
        )

        saved = self.repo.save(entity)
        total = self.repo.count_amostras(saved.id)
        idade = (date.today() - saved.data_nascimento).days // 365

        return PacienteResponseDTO(
            id=saved.id,
            nome=saved.nome,
            data_nascimento=saved.data_nascimento,
            idade=idade,
            recem_nascido=saved.recem_nascido,
            etnia=saved.etnia,
            genero=saved.genero,
            naturalidade=saved.naturalidade,
            amostras_registradas=total,
            observacao=saved.observacao,
            status=saved.status,
            deleted_at=saved.deleted_at
        )
