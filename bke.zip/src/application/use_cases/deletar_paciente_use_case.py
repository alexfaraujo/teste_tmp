from sqlalchemy.orm import Session
from src.infrastructure.repositories.paciente_repository_impl import PacienteRepositoryImpl

class DeletarPacienteUseCase:
    def __init__(self, db: Session):
        self.db = db
        self.repo = PacienteRepositoryImpl(db)

    def execute(self, id: int) -> bool:
        return self.repo.soft_delete(id)
