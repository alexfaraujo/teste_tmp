from typing import Optional
from sqlalchemy.orm import Session
from src.application.dtos.amostra_dto import AmostraResponseDTO
from src.infrastructure.repositories.amostra_repository_impl import AmostraRepositoryImpl
from src.infrastructure.models.paciente_model import PacienteModel

class ObterAmostraPorIdUseCase:
    def __init__(self, db: Session):
        self.db = db
        self.repo = AmostraRepositoryImpl(db)

    def execute(self, id: int) -> Optional[AmostraResponseDTO]:
        a = self.repo.find_by_id(id)
        if not a:
            return None

        paciente = self.db.query(PacienteModel).filter(PacienteModel.id == a.paciente_id).first()
        paciente_nome = paciente.nome if paciente else "Não identificado"
        total_amostras = self.repo.count_by_paciente_id(a.paciente_id) if paciente else 1

        return AmostraResponseDTO(
            id=a.id,
            nome=a.nome,
            status_formatado="Processando" if a.status else "Inativa",
            data_formatada=a.data_coleta.strftime("%d/%m/%Y"),
            paciente_nome=paciente_nome,
            paciente_total_amostras=total_amostras,
            data_coleta=a.data_coleta,
            data_envio=a.data_envio,
            material=a.material,
            sexo=a.sexo,
            etnia=a.etnia,
            naturalidade=a.naturalidade,
            suspeita_diagnostico=a.suspeita_diagnostico,
            outros_exames_auxiliares=a.outros_exames_auxiliares,
            quais_exames=a.quais_exames,
            observacao=a.observacao,
            status=a.status,
            deleted_at=a.deleted_at
        )
