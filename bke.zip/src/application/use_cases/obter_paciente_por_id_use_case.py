from typing import Optional
from datetime import date
from sqlalchemy.orm import Session
from src.application.dtos.paciente_dto import PacienteDetailResponseDTO
from src.application.dtos.amostra_dto import AmostraResponseDTO
from src.infrastructure.repositories.paciente_repository_impl import PacienteRepositoryImpl
from src.infrastructure.repositories.amostra_repository_impl import AmostraRepositoryImpl
from src.infrastructure.models.amostra_model import AmostraModel

class ObterPacientePorIdUseCase:
    def __init__(self, db: Session):
        self.db = db
        self.repo = PacienteRepositoryImpl(db)
        self.amostra_repo = AmostraRepositoryImpl(db)

    def execute(self, id: int) -> Optional[PacienteDetailResponseDTO]:
        p = self.repo.find_by_id(id)
        if not p:
            return None

        idade = (date.today() - p.data_nascimento).days // 365
        total_amostras = self.repo.count_amostras(p.id)

        # Buscar amostras biológicas ativas deste paciente
        amostras_models = self.db.query(AmostraModel).filter(
            AmostraModel.paciente_id == p.id,
            AmostraModel.deleted_at.is_(None)
        ).all()

        amostras_dtos = [
            AmostraResponseDTO(
                id=a.id,
                nome=a.nome,
                status_formatado="Processando" if a.status else "Inativa",
                data_formatada=a.data_coleta.strftime("%d/%m/%Y"),
                paciente_nome=p.nome,
                paciente_total_amostras=total_amostras,
                data_coleta=a.data_coleta,
                data_envio=a.data_envio,
                material=a.material,
                sexo=a.sexo,
                etnia=a.etnia,
                naturalidade=a.naturalidade,
                suspeita_diagnostico=a.suspeita_diagnostico,
                outros_exames_auxiliares=a.outros_exames_auxiliares,
                quais_exames=a.quais_exames,
                observacao=a.observacao,
                status=a.status,
                deleted_at=a.deleted_at
            ) for a in amostras_models
        ]

        return PacienteDetailResponseDTO(
            id=p.id,
            nome=p.nome,
            data_nascimento=p.data_nascimento,
            idade=idade,
            recem_nascido=p.recem_nascido,
            etnia=p.etnia,
            genero=p.genero,
            naturalidade=p.naturalidade,
            amostras_registradas=total_amostras,
            observacao=p.observacao,
            status=p.status,
            deleted_at=p.deleted_at,
            amostras=amostras_dtos
        )
