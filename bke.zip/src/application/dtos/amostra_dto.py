from pydantic import BaseModel, Field, ConfigDict, model_validator
from datetime import date, datetime
from typing import Optional, Any

class AmostraCreateDTO(BaseModel):
    # Demográficos / Paciente embutido no form do frontend
    nome: str = Field(..., description="Nome do paciente ou da amostra")
    data_coleta: Optional[date] = None
    data_envio: Optional[date] = None
    data_recebimento: Optional[date] = None
    data_nascimento: Optional[date] = None
    idade_paciente: Optional[str] = "Não informada"
    material: Optional[str] = "Sangue total"
    sexo: Optional[str] = "M"
    gestante: Optional[str] = "NA"
    semanas_gestacao: Optional[int] = None
    recem_nascido: Any = False
    naturalidade: Optional[str] = "Não informada"
    etnia: Optional[str] = "Parda"
    suspeita_diagnostico: Optional[str] = "Em investigação"
    transfusao_sangue: Optional[str] = "Não"
    ultima_transfusao: Optional[date] = None
    solicitante: Optional[str] = None

    # Hemograma / Exames auxiliares
    eritrocitos: Optional[float] = None
    reticulocitos_pct: Optional[float] = None
    reticulocitos_mm3: Optional[float] = None
    hemoglobina: Optional[float] = None
    desidrogenase_lactica: Optional[float] = None
    hematocrito: Optional[float] = None
    bilirrubina_total: Optional[float] = None
    bilirrubina_indireta: Optional[float] = None
    bilirrubina_direta: Optional[float] = None
    vcm: Optional[float] = None
    ferritina: Optional[float] = None
    hcm: Optional[float] = None
    chcm: Optional[float] = None
    rdw: Optional[float] = None
    outros_exames_auxiliares: Optional[str] = None
    quaisExames: Optional[str] = None

    uso_hidroxiureia: Optional[str] = "Não"
    uso_medicamento: Optional[str] = "Não"
    medicamentos: Optional[str] = None
    observacoes: Optional[str] = None
    anexo_documento: Optional[str] = None

    @model_validator(mode='before')
    @classmethod
    def preprocess_payload(cls, data: Any) -> Any:
        if isinstance(data, dict):
            cleaned = {}
            for key, value in data.items():
                if isinstance(value, str):
                    stripped_val = value.strip()
                    if stripped_val == "":
                        cleaned[key] = None
                    else:
                        cleaned[key] = stripped_val
                else:
                    cleaned[key] = value

            rn_val = cleaned.get('recem_nascido')
            if isinstance(rn_val, str):
                rn_clean = rn_val.strip().lower()
                cleaned['recem_nascido'] = rn_clean in ['sim', 's', 'true', '1']
            elif rn_val is None:
                cleaned['recem_nascido'] = False

            return cleaned
        return data

class AmostraResponseDTO(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    nome: str
    status_formatado: str = "Processando"
    data_formatada: str
    paciente_nome: str
    paciente_total_amostras: int
    data_coleta: Optional[date] = None
    data_envio: Optional[date] = None
    material: Optional[str] = None
    sexo: Optional[str] = None
    etnia: Optional[str] = None
    naturalidade: Optional[str] = None
    suspeita_diagnostico: Optional[str] = None
    outros_exames_auxiliares: Optional[str] = None
    quais_exames: Optional[str] = None
    observacao: Optional[str] = None
    status: bool = True
    deleted_at: Optional[datetime] = None

