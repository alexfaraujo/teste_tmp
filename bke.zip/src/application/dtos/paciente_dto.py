from pydantic import BaseModel, Field, ConfigDict, model_validator
from datetime import date, datetime
from typing import Optional, List, Any
from src.application.dtos.amostra_dto import AmostraResponseDTO

class PacienteCreateDTO(BaseModel):
    nome: str = Field(..., description="Nome completo do paciente")
    data_nascimento: date = Field(..., description="Data de nascimento do paciente")
    recem_nascido: Any = False
    etnia: Optional[str] = "Parda"
    genero: Optional[str] = "M"
    naturalidade: Optional[str] = "Não informada"
    observacao: Optional[str] = None

    @model_validator(mode='before')
    @classmethod
    def preprocess_payload(cls, data: Any) -> Any:
        if isinstance(data, dict):
            cleaned = {}
            for key, value in data.items():
                if isinstance(value, str):
                    stripped_val = value.strip()
                    if stripped_val == "":
                        cleaned[key] = None
                    else:
                        cleaned[key] = stripped_val
                else:
                    cleaned[key] = value

            rn_val = cleaned.get('recem_nascido')
            if isinstance(rn_val, str):
                rn_clean = rn_val.strip().lower()
                cleaned['recem_nascido'] = rn_clean in ['sim', 's', 'true', '1']
            elif rn_val is None:
                cleaned['recem_nascido'] = False

            return cleaned
        return data

class PacienteUpdateDTO(BaseModel):
    nome: Optional[str] = None
    data_nascimento: Optional[date] = None
    recem_nascido: Optional[bool] = None
    etnia: Optional[str] = None
    genero: Optional[str] = None
    naturalidade: Optional[str] = None
    observacao: Optional[str] = None

class PacienteResponseDTO(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    nome: str
    data_nascimento: date
    idade: int
    recem_nascido: bool
    etnia: str
    genero: str
    naturalidade: str
    amostras_registradas: int
    observacao: Optional[str] = None
    status: bool = True
    deleted_at: Optional[datetime] = None

class PacienteDetailResponseDTO(PacienteResponseDTO):
    amostras: List[AmostraResponseDTO] = []
