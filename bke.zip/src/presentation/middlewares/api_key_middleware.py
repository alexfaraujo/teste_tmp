import os
from fastapi import Security, HTTPException, status
from fastapi.security.api_key import APIKeyHeader
from dotenv import load_dotenv

load_dotenv()

EXPECTED_API_KEY = os.getenv("API_KEY", "lgbm_m2m_secret_key_2026")

api_key_header_x = APIKeyHeader(name="X-API-Key", auto_error=False)
api_key_header_std = APIKeyHeader(name="api-key", auto_error=False)

def verify_api_key(
    key_x: str = Security(api_key_header_x),
    key_std: str = Security(api_key_header_std)
) -> str:
    provided_key = key_x or key_std
    if not provided_key or provided_key != EXPECTED_API_KEY:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={
                "status": 401,
                "code": "UNAUTHORIZED",
                "message": "API Key de autenticação M2M ausente ou inválida."
            }
        )
    return provided_key
