from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from src.infrastructure.database.database import engine, Base
# Importar todos os modelos para garantir que as tabelas sejam mapeadas no SQLAlchemy
from src.infrastructure.models import (
    endereco_model,
    unidade_model,
    user_model,
    solicitante_model,
    paciente_model,
    exame_model,
    amostra_exame_model,
    amostra_model
)
from src.presentation.api.v1.amostras_router import router as amostras_router
from src.presentation.api.v1.pacientes_router import router as pacientes_router

# Inicializar tabelas no banco relacional PostgreSQL local
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="LGBM Backend API — Laboratório UFMS",
    description="API REST autenticada por API Key para o Laboratório de Genética e Biologia Molecular da UFMS",
    version="1.0.0"
)

# Configuração do Middleware CORS para comunicação desacoplada com o Frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Em produção, restringir para as URLs específicas do frontend
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Inclusão das rotas da API (padronizado em /api/v1)
app.include_router(amostras_router, prefix="/api/v1")
app.include_router(pacientes_router, prefix="/api/v1")

@app.get("/health", tags=["Health"])
def health_check():
    return {"status": "ok", "message": "LGBM Backend API operational."}
