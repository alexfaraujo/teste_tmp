from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from src.infrastructure.database.database import get_db
from src.presentation.middlewares.api_key_middleware import verify_api_key
from src.application.dtos.paciente_dto import (
    PacienteCreateDTO,
    PacienteUpdateDTO,
    PacienteResponseDTO,
    PacienteDetailResponseDTO
)
from src.application.use_cases.criar_paciente_use_case import CriarPacienteUseCase
from src.application.use_cases.listar_pacientes_use_case import ListarPacientesUseCase
from src.application.use_cases.obter_paciente_por_id_use_case import ObterPacientePorIdUseCase
from src.application.use_cases.atualizar_paciente_use_case import AtualizarPacienteUseCase
from src.application.use_cases.deletar_paciente_use_case import DeletarPacienteUseCase

router = APIRouter(
    prefix="/pacientes",
    tags=["Pacientes"],
    dependencies=[Depends(verify_api_key)]
)

@router.post("", response_model=PacienteResponseDTO, status_code=status.HTTP_201_CREATED)
def criar_paciente(dto: PacienteCreateDTO, db: Session = Depends(get_db)):
    use_case = CriarPacienteUseCase(db)
    return use_case.execute(dto)

@router.get("", response_model=List[PacienteResponseDTO])
def listar_pacientes(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    use_case = ListarPacientesUseCase(db)
    return use_case.execute(skip=skip, limit=limit)

@router.get("/{id}", response_model=PacienteDetailResponseDTO)
def obter_paciente(id: int, db: Session = Depends(get_db)):
    use_case = ObterPacientePorIdUseCase(db)
    resultado = use_case.execute(id)
    if not resultado:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"status": 404, "code": "NOT_FOUND", "message": f"Paciente com ID {id} não encontrado."}
        )
    return resultado

@router.put("/{id}", response_model=PacienteResponseDTO)
def atualizar_paciente(id: int, dto: PacienteUpdateDTO, db: Session = Depends(get_db)):
    use_case = AtualizarPacienteUseCase(db)
    resultado = use_case.execute(id, dto)
    if not resultado:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"status": 404, "code": "NOT_FOUND", "message": f"Paciente com ID {id} não encontrado para atualização."}
        )
    return resultado

@router.delete("/{id}", status_code=status.HTTP_200_OK)
def deletar_paciente(id: int, db: Session = Depends(get_db)):
    use_case = DeletarPacienteUseCase(db)
    sucesso = use_case.execute(id)
    if not sucesso:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"status": 404, "code": "NOT_FOUND", "message": f"Paciente com ID {id} não encontrado para exclusão."}
        )
    return {"status": 200, "code": "SUCCESS", "message": f"Paciente {id} e suas amostras associadas foram inativados com sucesso (Soft Delete)."}
