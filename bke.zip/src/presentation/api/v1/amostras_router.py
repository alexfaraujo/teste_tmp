from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from src.infrastructure.database.database import get_db
from src.presentation.middlewares.api_key_middleware import verify_api_key
from src.application.dtos.amostra_dto import AmostraCreateDTO, AmostraResponseDTO
from src.application.use_cases.criar_amostra_use_case import CriarAmostraUseCase
from src.application.use_cases.listar_amostras_use_case import ListarAmostrasUseCase
from src.application.use_cases.obter_amostra_por_id_use_case import ObterAmostraPorIdUseCase
from src.application.use_cases.atualizar_amostra_use_case import AtualizarAmostraUseCase
from src.application.use_cases.deletar_amostra_use_case import DeletarAmostraUseCase

router = APIRouter(
    prefix="/amostras",
    tags=["Amostras"],
    dependencies=[Depends(verify_api_key)]
)

@router.post("", response_model=AmostraResponseDTO, status_code=status.HTTP_201_CREATED)
@router.post("/", response_model=AmostraResponseDTO, status_code=status.HTTP_201_CREATED, include_in_schema=False)
def criar_amostra(dto: AmostraCreateDTO, db: Session = Depends(get_db)):
    use_case = CriarAmostraUseCase(db)
    return use_case.execute(dto)

@router.get("", response_model=List[AmostraResponseDTO])
@router.get("/", response_model=List[AmostraResponseDTO], include_in_schema=False)
def listar_amostras(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    use_case = ListarAmostrasUseCase(db)
    return use_case.execute(skip=skip, limit=limit)

@router.get("/{id}", response_model=AmostraResponseDTO)
def obter_amostra(id: int, db: Session = Depends(get_db)):
    use_case = ObterAmostraPorIdUseCase(db)
    resultado = use_case.execute(id)
    if not resultado:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"status": 404, "code": "NOT_FOUND", "message": f"Amostra com ID {id} não encontrada."}
        )
    return resultado

@router.put("/{id}", response_model=AmostraResponseDTO)
def atualizar_amostra(id: int, dto: AmostraCreateDTO, db: Session = Depends(get_db)):
    use_case = AtualizarAmostraUseCase(db)
    resultado = use_case.execute(id, dto)
    if not resultado:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"status": 404, "code": "NOT_FOUND", "message": f"Amostra com ID {id} não encontrada para atualização."}
        )
    return resultado

@router.delete("/{id}", status_code=status.HTTP_200_OK)
def deletar_amostra(id: int, db: Session = Depends(get_db)):
    use_case = DeletarAmostraUseCase(db)
    sucesso = use_case.execute(id)
    if not sucesso:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"status": 404, "code": "NOT_FOUND", "message": f"Amostra com ID {id} não encontrada para exclusão."}
        )
    return {"status": 200, "code": "SUCCESS", "message": f"Amostra {id} excluída com sucesso (Soft Delete)."}
