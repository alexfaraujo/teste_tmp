from typing import Protocol, Optional, List
from src.domain.entities.amostra import AmostraEntity

class AmostraRepository(Protocol):
    def save(self, amostra: AmostraEntity) -> AmostraEntity:
        ...

    def find_by_id(self, id: int) -> Optional[AmostraEntity]:
        ...

    def find_all(self, skip: int = 0, limit: int = 100) -> List[AmostraEntity]:
        ...

    def update(self, id: int, amostra: AmostraEntity) -> Optional[AmostraEntity]:
        ...

    def soft_delete(self, id: int) -> bool:
        ...

    def count_by_paciente_id(self, paciente_id: int) -> int:
        ...
