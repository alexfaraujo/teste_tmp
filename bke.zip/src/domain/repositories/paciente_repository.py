from typing import Protocol, Optional, List
from datetime import date
from src.domain.entities.paciente import PacienteEntity

class PacienteRepository(Protocol):
    def save(self, paciente: PacienteEntity) -> PacienteEntity:
        ...

    def find_by_id(self, id: int) -> Optional[PacienteEntity]:
        ...

    def find_by_nome_e_nascimento(self, nome: str, data_nascimento: date) -> Optional[PacienteEntity]:
        ...

    def find_all(self, skip: int = 0, limit: int = 100) -> List[PacienteEntity]:
        ...

    def update(self, id: int, paciente: PacienteEntity) -> Optional[PacienteEntity]:
        ...

    def soft_delete(self, id: int) -> bool:
        ...

    def count_amostras(self, paciente_id: int) -> int:
        ...
