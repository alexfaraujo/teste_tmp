from dataclasses import dataclass
from datetime import date, datetime
from typing import Optional

@dataclass
class PacienteEntity:
    id: Optional[int]
    nome: str
    data_nascimento: date
    recem_nascido: bool
    etnia: str
    genero: str
    naturalidade: str
    observacao: Optional[str] = None
    unidade_id: Optional[int] = None
    endereco_id: Optional[int] = None
    status: bool = True
    deleted_at: Optional[datetime] = None
