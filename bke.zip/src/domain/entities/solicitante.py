from dataclasses import dataclass
from datetime import datetime
from typing import Optional

@dataclass
class SolicitanteEntity:
    id: Optional[int]
    nome: str
    email: Optional[str] = None
    contato: Optional[str] = None
    observacao: Optional[str] = None
    endereco_id: Optional[int] = None
    status: bool = True
    deleted_at: Optional[datetime] = None
