from dataclasses import dataclass
from datetime import date, datetime
from typing import Optional

@dataclass
class AmostraEntity:
    id: Optional[int]
    nome: str
    data_coleta: date
    data_envio: date
    data_recebimento: date
    data_nascimento: date
    idade_paciente: str
    material: str
    sexo: str
    gestante: str
    semanas_gestacao: Optional[int]
    recem_nascido: bool
    naturalidade: str
    etnia: str
    suspeita_diagnostico: str
    transfusao_sangue: str
    ultima_transfusao: Optional[date]
    paciente_id: int
    solicitante_id: Optional[int]

    # Hemograma & Bioquímica
    eritrocitos: Optional[float] = None
    reticulocitos_pct: Optional[float] = None
    reticulocitos_mm3: Optional[float] = None
    hemoglobina: Optional[float] = None
    desidrogenase_lactica: Optional[float] = None
    hematocrito: Optional[float] = None
    bilirrubina_total: Optional[float] = None
    bilirrubina_indireta: Optional[float] = None
    bilirrubina_direta: Optional[float] = None
    vcm: Optional[float] = None
    ferritina: Optional[float] = None
    hcm: Optional[float] = None
    chcm: Optional[float] = None
    rdw: Optional[float] = None
    outros_exames_auxiliares: Optional[str] = None
    quais_exames: Optional[str] = None

    uso_hidroxiureia: str = "Não"
    uso_medicamento: str = "Não"
    medicamentos: Optional[str] = None
    observacao: Optional[str] = None
    anexo_documento: Optional[str] = None
    status: bool = True
    deleted_at: Optional[datetime] = None
