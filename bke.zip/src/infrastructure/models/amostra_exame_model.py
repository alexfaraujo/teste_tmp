from sqlalchemy import Column, Integer, ForeignKey
from src.infrastructure.database.database import Base

class AmostraExameModel(Base):
    __tablename__ = "amostras_exames"

    amostra_id = Column(Integer, ForeignKey("amostras.id"), primary_key=True)
    exame_id = Column(Integer, ForeignKey("exames.id"), primary_key=True)
