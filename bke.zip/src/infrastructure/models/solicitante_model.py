from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from src.infrastructure.database.database import Base

class SolicitanteModel(Base):
    __tablename__ = "solicitantes"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    nome = Column(String, nullable=False)
    email = Column(String, nullable=True)
    contato = Column(String, nullable=True)
    observacao = Column(String, nullable=True)
    status = Column(Boolean, default=True, nullable=False)
    deleted_at = Column(DateTime, nullable=True)
    endereco_id = Column(Integer, ForeignKey("enderecos.id"), nullable=True)

    endereco = relationship("EnderecoModel")
