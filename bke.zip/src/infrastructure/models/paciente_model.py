from sqlalchemy import Column, Integer, String, Boolean, Date, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from src.infrastructure.database.database import Base

class PacienteModel(Base):
    __tablename__ = "pacientes"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    nome = Column(String, nullable=False)
    data_nascimento = Column(Date, nullable=False)
    recem_nascido = Column(Boolean, default=False, nullable=False)
    etnia = Column(String, nullable=False)
    genero = Column(String, nullable=False)
    naturalidade = Column(String, nullable=False)
    observacao = Column(String, nullable=True)
    status = Column(Boolean, default=True, nullable=False)
    deleted_at = Column(DateTime, nullable=True)
    unidade_id = Column(Integer, ForeignKey("unidades.id"), nullable=True)
    endereco_id = Column(Integer, ForeignKey("enderecos.id"), nullable=True)

    unidade = relationship("UnidadeModel")
    endereco = relationship("EnderecoModel")
    amostras = relationship("AmostraModel", back_populates="paciente")
