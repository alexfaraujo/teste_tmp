from sqlalchemy import Column, Integer, String, Float, Boolean, Date, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from src.infrastructure.database.database import Base

class AmostraModel(Base):
    __tablename__ = "amostras"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    nome = Column(String, nullable=False)
    data_coleta = Column(Date, nullable=False)
    data_envio = Column(Date, nullable=False)
    data_recebimento = Column(Date, nullable=False)
    data_nascimento = Column(Date, nullable=False)
    idade_paciente = Column(String, nullable=False)
    material = Column(String, nullable=False)
    sexo = Column(String, nullable=False)
    gestante = Column(String, nullable=False)
    semanas_gestacao = Column(Integer, nullable=True)
    recem_nascido = Column(Boolean, default=False, nullable=False)
    naturalidade = Column(String, nullable=False)
    etnia = Column(String, nullable=False)
    suspeita_diagnostico = Column(String, nullable=False)
    transfusao_sangue = Column(String, nullable=False)
    ultima_transfusao = Column(Date, nullable=True)

    # Hemograma & Exames Auxiliares
    eritrocitos = Column(Float, nullable=True)
    reticulocitos_pct = Column(Float, nullable=True)
    reticulocitos_mm3 = Column(Float, nullable=True)
    hemoglobina = Column(Float, nullable=True)
    desidrogenase_lactica = Column(Float, nullable=True)
    hematocrito = Column(Float, nullable=True)
    bilirrubina_total = Column(Float, nullable=True)
    bilirrubina_indireta = Column(Float, nullable=True)
    bilirrubina_direta = Column(Float, nullable=True)
    vcm = Column(Float, nullable=True)
    ferritina = Column(Float, nullable=True)
    hcm = Column(Float, nullable=True)
    chcm = Column(Float, nullable=True)
    rdw = Column(Float, nullable=True)
    outros_exames_auxiliares = Column(String, nullable=True)
    quais_exames = Column(String, nullable=True)  # Nova coluna para acolher o campo quaisExames do frontend

    uso_hidroxiureia = Column(String, nullable=False, default="Não")
    uso_medicamento = Column(String, nullable=False, default="Não")
    medicamentos = Column(String, nullable=True)
    observacao = Column(String, nullable=True)
    anexo_documento = Column(String, nullable=True)
    status = Column(Boolean, default=True, nullable=False)
    deleted_at = Column(DateTime, nullable=True)

    paciente_id = Column(Integer, ForeignKey("pacientes.id"), nullable=False)
    solicitante_id = Column(Integer, ForeignKey("solicitantes.id"), nullable=True)

    paciente = relationship("PacienteModel", back_populates="amostras")
    solicitante = relationship("SolicitanteModel")
