from sqlalchemy import Column, Integer, String, Boolean, DateTime
from src.infrastructure.database.database import Base

class EnderecoModel(Base):
    __tablename__ = "enderecos"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    estado = Column(String, nullable=False)
    cidade = Column(String, nullable=False)
    cep = Column(String, nullable=False)
    bairro = Column(String, nullable=False)
    rua = Column(String, nullable=False)
    numero = Column(String, nullable=False)
    status = Column(Boolean, default=True, nullable=False)
    deleted_at = Column(DateTime, nullable=True)
