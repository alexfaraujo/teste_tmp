from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from src.infrastructure.database.database import Base

class UserModel(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    nome = Column(String, nullable=False)
    email = Column(String, nullable=False)
    password = Column(String, nullable=False)
    status = Column(Boolean, default=True, nullable=False)
    deleted_at = Column(DateTime, nullable=True)
    unidade_id = Column(Integer, ForeignKey("unidades.id"), nullable=True)

    unidade = relationship("UnidadeModel")
