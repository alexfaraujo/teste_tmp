from sqlalchemy import Column, Integer, String, Float, Boolean, DateTime
from src.infrastructure.database.database import Base

class ExameModel(Base):
    __tablename__ = "exames"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    nome = Column(String, nullable=False)
    sigla = Column(String, nullable=False)
    tipo_exame = Column(String, nullable=False)
    metodo = Column(String, nullable=False)
    preco = Column(Float, nullable=False)
    valor_referencia = Column(Float, nullable=False)
    tipo_referencia = Column(String, nullable=False)
    tipo_valor_resultado = Column(String, nullable=False)
    observacao = Column(String, nullable=False)
    status = Column(Boolean, default=True, nullable=False)
    deleted_at = Column(DateTime, nullable=True)
