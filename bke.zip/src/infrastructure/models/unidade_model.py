from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from src.infrastructure.database.database import Base

class UnidadeModel(Base):
    __tablename__ = "unidades"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    email = Column(String, nullable=False)
    observacao = Column(String, nullable=False)
    status = Column(Boolean, default=True, nullable=False)
    deleted_at = Column(DateTime, nullable=True)
    endereco_id = Column(Integer, ForeignKey("enderecos.id"), unique=True, nullable=True)

    endereco = relationship("EnderecoModel")
