from typing import Optional, List
from datetime import datetime
from sqlalchemy.orm import Session
from src.domain.entities.amostra import AmostraEntity
from src.domain.repositories.amostra_repository import AmostraRepository
from src.infrastructure.models.amostra_model import AmostraModel

class AmostraRepositoryImpl(AmostraRepository):
    def __init__(self, db: Session):
        self.db = db

    def _to_entity(self, model: AmostraModel) -> AmostraEntity:
        return AmostraEntity(
            id=model.id,
            nome=model.nome,
            data_coleta=model.data_coleta,
            data_envio=model.data_envio,
            data_recebimento=model.data_recebimento,
            data_nascimento=model.data_nascimento,
            idade_paciente=model.idade_paciente,
            material=model.material,
            sexo=model.sexo,
            gestante=model.gestante,
            semanas_gestacao=model.semanas_gestacao,
            recem_nascido=model.recem_nascido,
            naturalidade=model.naturalidade,
            etnia=model.etnia,
            suspeita_diagnostico=model.suspeita_diagnostico,
            transfusao_sangue=model.transfusao_sangue,
            ultima_transfusao=model.ultima_transfusao,
            paciente_id=model.paciente_id,
            solicitante_id=model.solicitante_id,
            eritrocitos=model.eritrocitos,
            reticulocitos_pct=model.reticulocitos_pct,
            reticulocitos_mm3=model.reticulocitos_mm3,
            hemoglobina=model.hemoglobina,
            desidrogenase_lactica=model.desidrogenase_lactica,
            hematocrito=model.hematocrito,
            bilirrubina_total=model.bilirrubina_total,
            bilirrubina_indireta=model.bilirrubina_indireta,
            bilirrubina_direta=model.bilirrubina_direta,
            vcm=model.vcm,
            ferritina=model.ferritina,
            hcm=model.hcm,
            chcm=model.chcm,
            rdw=model.rdw,
            outros_exames_auxiliares=model.outros_exames_auxiliares,
            quais_exames=model.quais_exames,
            uso_hidroxiureia=model.uso_hidroxiureia,
            uso_medicamento=model.uso_medicamento,
            medicamentos=model.medicamentos,
            observacao=model.observacao,
            anexo_documento=model.anexo_documento,
            status=model.status,
            deleted_at=model.deleted_at
        )

    def save(self, entity: AmostraEntity) -> AmostraEntity:
        model = AmostraModel(
            nome=entity.nome,
            data_coleta=entity.data_coleta,
            data_envio=entity.data_envio,
            data_recebimento=entity.data_recebimento,
            data_nascimento=entity.data_nascimento,
            idade_paciente=entity.idade_paciente,
            material=entity.material,
            sexo=entity.sexo,
            gestante=entity.gestante,
            semanas_gestacao=entity.semanas_gestacao,
            recem_nascido=entity.recem_nascido,
            naturalidade=entity.naturalidade,
            etnia=entity.etnia,
            suspeita_diagnostico=entity.suspeita_diagnostico,
            transfusao_sangue=entity.transfusao_sangue,
            ultima_transfusao=entity.ultima_transfusao,
            paciente_id=entity.paciente_id,
            solicitante_id=entity.solicitante_id,
            eritrocitos=entity.eritrocitos,
            reticulocitos_pct=entity.reticulocitos_pct,
            reticulocitos_mm3=entity.reticulocitos_mm3,
            hemoglobina=entity.hemoglobina,
            desidrogenase_lactica=entity.desidrogenase_lactica,
            hematocrito=entity.hematocrito,
            bilirrubina_total=entity.bilirrubina_total,
            bilirrubina_indireta=entity.bilirrubina_indireta,
            bilirrubina_direta=entity.bilirrubina_direta,
            vcm=entity.vcm,
            ferritina=entity.ferritina,
            hcm=entity.hcm,
            chcm=entity.chcm,
            rdw=entity.rdw,
            outros_exames_auxiliares=entity.outros_exames_auxiliares,
            quais_exames=entity.quais_exames,
            uso_hidroxiureia=entity.uso_hidroxiureia,
            uso_medicamento=entity.uso_medicamento,
            medicamentos=entity.medicamentos,
            observacao=entity.observacao,
            anexo_documento=entity.anexo_documento,
            status=entity.status,
            deleted_at=entity.deleted_at
        )
        self.db.add(model)
        self.db.commit()
        self.db.refresh(model)
        return self._to_entity(model)

    def find_by_id(self, id: int) -> Optional[AmostraEntity]:
        model = self.db.query(AmostraModel).filter(
            AmostraModel.id == id,
            AmostraModel.deleted_at.is_(None)
        ).first()
        return self._to_entity(model) if model else None

    def find_all(self, skip: int = 0, limit: int = 100) -> List[AmostraEntity]:
        models = self.db.query(AmostraModel).filter(
            AmostraModel.deleted_at.is_(None)
        ).order_by(AmostraModel.id.desc()).offset(skip).limit(limit).all()
        return [self._to_entity(m) for m in models]

    def update(self, id: int, entity: AmostraEntity) -> Optional[AmostraEntity]:
        model = self.db.query(AmostraModel).filter(
            AmostraModel.id == id,
            AmostraModel.deleted_at.is_(None)
        ).first()
        if not model:
            return None

        for field in [
            'nome', 'data_coleta', 'data_envio', 'data_recebimento', 'data_nascimento',
            'idade_paciente', 'material', 'sexo', 'gestante', 'semanas_gestacao',
            'recem_nascido', 'naturalidade', 'etnia', 'suspeita_diagnostico',
            'transfusao_sangue', 'ultima_transfusao', 'eritrocitos', 'reticulocitos_pct',
            'reticulocitos_mm3', 'hemoglobina', 'desidrogenase_lactica', 'hematocrito',
            'bilirrubina_total', 'bilirrubina_indireta', 'bilirrubina_direta', 'vcm',
            'ferritina', 'hcm', 'chcm', 'rdw', 'outros_exames_auxiliares', 'quais_exames',
            'uso_hidroxiureia', 'uso_medicamento', 'medicamentos', 'observacao',
            'anexo_documento', 'status'
        ]:
            val = getattr(entity, field, None)
            if val is not None:
                setattr(model, field, val)

        self.db.commit()
        self.db.refresh(model)
        return self._to_entity(model)

    def soft_delete(self, id: int) -> bool:
        model = self.db.query(AmostraModel).filter(
            AmostraModel.id == id,
            AmostraModel.deleted_at.is_(None)
        ).first()
        if not model:
            return False

        model.status = False
        model.deleted_at = datetime.now()
        self.db.commit()
        return True

    def count_by_paciente_id(self, paciente_id: int) -> int:
        return self.db.query(AmostraModel).filter(
            AmostraModel.paciente_id == paciente_id,
            AmostraModel.deleted_at.is_(None)
        ).count()
