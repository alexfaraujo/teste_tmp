from typing import Optional, List
from datetime import date, datetime
from sqlalchemy.orm import Session
from src.domain.entities.paciente import PacienteEntity
from src.domain.repositories.paciente_repository import PacienteRepository
from src.infrastructure.models.paciente_model import PacienteModel
from src.infrastructure.models.amostra_model import AmostraModel

class PacienteRepositoryImpl(PacienteRepository):
    def __init__(self, db: Session):
        self.db = db

    def _to_entity(self, model: PacienteModel) -> PacienteEntity:
        return PacienteEntity(
            id=model.id,
            nome=model.nome,
            data_nascimento=model.data_nascimento,
            recem_nascido=model.recem_nascido,
            etnia=model.etnia,
            genero=model.genero,
            naturalidade=model.naturalidade,
            observacao=model.observacao,
            unidade_id=model.unidade_id,
            endereco_id=model.endereco_id,
            status=model.status,
            deleted_at=model.deleted_at
        )

    def save(self, entity: PacienteEntity) -> PacienteEntity:
        model = PacienteModel(
            nome=entity.nome,
            data_nascimento=entity.data_nascimento,
            recem_nascido=entity.recem_nascido,
            etnia=entity.etnia,
            genero=entity.genero,
            naturalidade=entity.naturalidade,
            observacao=entity.observacao,
            unidade_id=entity.unidade_id,
            endereco_id=entity.endereco_id,
            status=entity.status,
            deleted_at=entity.deleted_at
        )
        self.db.add(model)
        self.db.commit()
        self.db.refresh(model)
        return self._to_entity(model)

    def find_by_id(self, id: int) -> Optional[PacienteEntity]:
        model = self.db.query(PacienteModel).filter(
            PacienteModel.id == id,
            PacienteModel.deleted_at.is_(None)
        ).first()
        return self._to_entity(model) if model else None

    def find_by_nome_e_nascimento(self, nome: str, data_nascimento: date) -> Optional[PacienteEntity]:
        model = self.db.query(PacienteModel).filter(
            PacienteModel.nome.ilike(nome.strip()),
            PacienteModel.data_nascimento == data_nascimento,
            PacienteModel.deleted_at.is_(None)
        ).first()
        return self._to_entity(model) if model else None

    def find_all(self, skip: int = 0, limit: int = 100) -> List[PacienteEntity]:
        models = self.db.query(PacienteModel).filter(
            PacienteModel.deleted_at.is_(None)
        ).order_by(PacienteModel.id.desc()).offset(skip).limit(limit).all()
        return [self._to_entity(m) for m in models]

    def update(self, id: int, entity: PacienteEntity) -> Optional[PacienteEntity]:
        model = self.db.query(PacienteModel).filter(
            PacienteModel.id == id,
            PacienteModel.deleted_at.is_(None)
        ).first()
        if not model:
            return None

        if entity.nome:
            model.nome = entity.nome
        if entity.data_nascimento:
            model.data_nascimento = entity.data_nascimento
        if entity.recem_nascido is not None:
            model.recem_nascido = entity.recem_nascido
        if entity.etnia:
            model.etnia = entity.etnia
        if entity.genero:
            model.genero = entity.genero
        if entity.naturalidade:
            model.naturalidade = entity.naturalidade
        if entity.observacao is not None:
            model.observacao = entity.observacao

        self.db.commit()
        self.db.refresh(model)
        return self._to_entity(model)

    def soft_delete(self, id: int) -> bool:
        now = datetime.now()
        model = self.db.query(PacienteModel).filter(
            PacienteModel.id == id,
            PacienteModel.deleted_at.is_(None)
        ).first()
        if not model:
            return False

        # Soft Delete no Paciente
        model.status = False
        model.deleted_at = now

        # Soft Delete em cascata em todas as amostras biológicas do Paciente
        self.db.query(AmostraModel).filter(
            AmostraModel.paciente_id == id,
            AmostraModel.deleted_at.is_(None)
        ).update({
            AmostraModel.status: False,
            AmostraModel.deleted_at: now
        }, synchronize_session=False)

        self.db.commit()
        return True

    def count_amostras(self, paciente_id: int) -> int:
        return self.db.query(AmostraModel).filter(
            AmostraModel.paciente_id == paciente_id,
            AmostraModel.deleted_at.is_(None)
        ).count()
