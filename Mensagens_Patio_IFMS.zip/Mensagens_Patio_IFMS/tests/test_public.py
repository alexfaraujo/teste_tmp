def test_index_page(client):
    response = client.get('/')
    assert response.status_code == 200
    assert b'Painel Informativo' in response.data

def test_api_noticias(client):
    response = client.get('/api/noticias')
    assert response.status_code == 200
    assert response.json == [] 