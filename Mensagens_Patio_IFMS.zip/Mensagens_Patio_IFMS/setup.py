from setuptools import setup, find_packages

setup(
    name="painel_informativo",
    version="0.1",
    packages=find_packages(),
    install_requires=[
        'Flask==2.0.1',
        'Flask-SQLAlchemy==2.5.1',
        'Flask-Login==0.5.0',
        'Flask-WTF==0.15.1',
        'Pillow==8.3.1',
        'python-dateutil==2.8.2',
        'werkzeug==2.0.1',
        'pytest==7.3.1'
    ]
) 