from datetime import datetime
from app import db

class Noticia(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    titulo = db.Column(db.String(200), nullable=False)
    imagem = db.Column(db.String(200), nullable=False)
    data_inicio = db.Column(db.DateTime, nullable=False)
    data_fim = db.Column(db.DateTime, nullable=False)
    data_criacao = db.Column(db.DateTime, default=datetime.utcnow)
    
    @property
    def esta_ativa(self):
        agora = datetime.utcnow()
        return self.data_inicio <= agora <= self.data_fim 