from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, FileField, SubmitField
from wtforms.fields import DateTimeLocalField
from wtforms.validators import DataRequired, Length, ValidationError, EqualTo
from flask_wtf.file import FileAllowed, FileRequired

class LoginForm(FlaskForm):
    username = StringField('Usuário', validators=[DataRequired()])
    password = PasswordField('Senha', validators=[DataRequired()])

class NoticiaForm(FlaskForm):
    titulo = StringField('Título', validators=[DataRequired(), Length(max=200)])
    imagem = FileField('Imagem', validators=[
        FileAllowed(['jpg', 'jpeg', 'png', 'gif'], 'Apenas imagens são permitidas!')
    ])
    data_inicio = DateTimeLocalField(
        'Data de Início',
        format='%Y-%m-%dT%H:%M',
        validators=[DataRequired()]
    )
    data_fim = DateTimeLocalField(
        'Data de Fim',
        format='%Y-%m-%dT%H:%M',
        validators=[DataRequired()]
    )

    def validate_data_fim(self, field):
        if field.data < self.data_inicio.data:
            raise ValidationError('A data de fim deve ser posterior à data de início')

class AlterarSenhaForm(FlaskForm):
    senha_atual = PasswordField('Senha Atual', validators=[DataRequired()])
    nova_senha = PasswordField('Nova Senha', validators=[
        DataRequired(),
        Length(min=6, message='A senha deve ter pelo menos 6 caracteres')
    ])
    confirmar_senha = PasswordField('Confirmar Nova Senha', validators=[
        DataRequired(),
        EqualTo('nova_senha', message='As senhas devem ser iguais')
    ])
    submit = SubmitField('Alterar Senha') 