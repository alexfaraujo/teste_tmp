from flask import Blueprint, render_template, redirect, url_for, flash, request, current_app
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.utils import secure_filename
from app.models.usuario import Usuario
from app.models.noticia import Noticia
from app.forms import LoginForm, NoticiaForm, AlterarSenhaForm
from app import db
import os
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash

bp = Blueprint('admin', __name__, url_prefix='/admin')

@bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('admin.dashboard'))
    
    form = LoginForm()
    if form.validate_on_submit():
        user = Usuario.query.filter_by(username=form.username.data).first()
        if user and user.check_password(form.password.data):
            login_user(user)
            return redirect(url_for('admin.dashboard'))
        flash('Usuário ou senha inválidos')
    return render_template('admin/login.html', form=form)

@bp.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('public.index'))

@bp.route('/dashboard')
@login_required
def dashboard():
    noticias = Noticia.query.order_by(Noticia.data_criacao.desc()).all()
    return render_template('admin/dashboard.html', noticias=noticias)

@bp.route('/noticia/nova', methods=['GET', 'POST'])
@login_required
def nova_noticia():
    form = NoticiaForm()
    if form.validate_on_submit():
        try:
            # Criar diretório de uploads se não existir
            upload_folder = current_app.config['UPLOAD_FOLDER']
            if not os.path.exists(upload_folder):
                os.makedirs(upload_folder)
            
            # Processar upload da imagem
            arquivo = form.imagem.data
            nome_arquivo = secure_filename(arquivo.filename)
            caminho_arquivo = os.path.join(upload_folder, nome_arquivo)
            
            # Salvar arquivo
            arquivo.save(caminho_arquivo)
            
            # Criar notícia
            noticia = Noticia(
                titulo=form.titulo.data,
                imagem=nome_arquivo,
                data_inicio=form.data_inicio.data,
                data_fim=form.data_fim.data
            )
            
            db.session.add(noticia)
            db.session.commit()
            flash('Notícia adicionada com sucesso!', 'success')
            return redirect(url_for('admin.dashboard'))
            
        except Exception as e:
            flash(f'Erro ao adicionar notícia: {str(e)}', 'error')
            db.session.rollback()
    
    return render_template('admin/form_noticia.html', form=form)

@bp.route('/noticia/editar/<int:id>', methods=['GET', 'POST'])
@login_required
def editar_noticia(id):
    noticia = Noticia.query.get_or_404(id)
    form = NoticiaForm(obj=noticia)
    
    if form.validate_on_submit():
        try:
            noticia.titulo = form.titulo.data
            noticia.data_inicio = form.data_inicio.data
            noticia.data_fim = form.data_fim.data
            
            # Processar nova imagem se fornecida
            if form.imagem.data:
                upload_folder = current_app.config['UPLOAD_FOLDER']
                
                # Remover imagem antiga
                if noticia.imagem:
                    caminho_antigo = os.path.join(upload_folder, noticia.imagem)
                    if os.path.exists(caminho_antigo):
                        os.remove(caminho_antigo)
                
                # Salvar nova imagem
                arquivo = form.imagem.data
                nome_arquivo = secure_filename(arquivo.filename)
                caminho_arquivo = os.path.join(upload_folder, nome_arquivo)
                arquivo.save(caminho_arquivo)
                noticia.imagem = nome_arquivo
            
            db.session.commit()
            flash('Notícia atualizada com sucesso!', 'success')
            return redirect(url_for('admin.dashboard'))
            
        except Exception as e:
            flash(f'Erro ao atualizar notícia: {str(e)}', 'error')
            db.session.rollback()
    
    return render_template('admin/form_noticia.html', form=form, noticia=noticia)

@bp.route('/noticia/excluir/<int:id>', methods=['POST'])
@login_required
def excluir_noticia(id):
    noticia = Noticia.query.get_or_404(id)
    try:
        # Remove a imagem se existir
        if noticia.imagem:
            image_path = os.path.join(current_app.config['UPLOAD_FOLDER'], noticia.imagem)
            if os.path.exists(image_path):
                os.remove(image_path)
        
        db.session.delete(noticia)
        db.session.commit()
        flash('Notícia excluída com sucesso!', 'success')
    except Exception as e:
        flash(f'Erro ao excluir notícia: {str(e)}', 'error')
        db.session.rollback()
    
    return redirect(url_for('admin.dashboard'))

@bp.route('/alterar-senha', methods=['GET', 'POST'])
@login_required
def alterar_senha():
    form = AlterarSenhaForm()
    if form.validate_on_submit():
        # Primeiro, vamos imprimir os atributos do usuário para debug
        print("Atributos do usuário:", dir(current_user))
        
        # Depois ajustamos o código com o nome correto do atributo
        if current_user.check_password(form.senha_atual.data):
            # Usar o método de definição de senha do modelo
            current_user.set_password(form.nova_senha.data)
            db.session.commit()
            flash('Senha alterada com sucesso!', 'success')
            return redirect(url_for('admin.dashboard'))
        else:
            flash('Senha atual incorreta!', 'danger')
    return render_template('admin/alterar_senha.html', form=form) 