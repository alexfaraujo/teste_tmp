#!/bin/bash

# --- CONFIGURAÇÕES ---
PORT=2053
ENV_FILE=".env.local"

echo "=== INICIANDO IMPLANTAÇÃO REMOTA DO FRONTEND (PORTA $PORT) ==="

# 1. Verificar instalação do Node.js/NPM
if ! command -v npm &> /dev/null; then
    echo "Erro: npm/node não está instalado no sistema."
    exit 1
fi

# 2. Instalar dependências npm
echo "Instalando dependências do projeto (npm install)..."
npm install
if [ $? -ne 0 ]; then
    echo "Erro ao instalar as dependências do frontend."
    exit 1
fi

# 3. Configurar variáveis de ambiente do backend
echo "Configurando as variáveis de ambiente..."
if [ ! -f "$ENV_FILE" ]; then
    if [ -f ".env.local.example" ]; then
        cp .env.local.example "$ENV_FILE"
        echo "Criado arquivo $ENV_FILE a partir do exemplo."
    else
        touch "$ENV_FILE"
        echo "Criado arquivo vazio $ENV_FILE."
    fi
fi

# Perguntar/atualizar a URL do backend se necessário
read -p "Digite a URL pública ou IP do seu backend (ex: https://seu-backend.com ou https://IP:2052) [Pressione ENTER para manter a atual]: " BACKEND_URL

if [ -n "$BACKEND_URL" ]; then
    # Limpa e atualiza a variável NEXT_PUBLIC_API_URL no .env.local
    sed -i '/NEXT_PUBLIC_API_URL=/d' "$ENV_FILE"
    echo "NEXT_PUBLIC_API_URL=$BACKEND_URL" >> "$ENV_FILE"
    echo "URL do backend atualizada para: $BACKEND_URL"
else
    echo "Mantendo a configuração atual de backend contida em $ENV_FILE."
fi

# 4. Escolha do Modo de Execução (Dev HTTPS vs Produção)
echo "--------------------------------------------------"
echo "Escolha o modo de inicialização do Next.js:"
echo "1) Modo Desenvolvimento com HTTPS nativo (Recomendado para testar webcam em HTTPS)"
echo "2) Modo Produção (Compilado de alta performance - Requer proxy reverso externo para HTTPS)"
echo "--------------------------------------------------"
read -p "Selecione uma opção (1 ou 2): " OPTION

if [ "$OPTION" = "1" ]; then
    echo "Iniciando Next.js em Modo Desenvolvimento com HTTPS na porta $PORT..."
    # O Next.js cria certificados autoassinados locais automaticamente com o flag --experimental-https
    npx next dev --experimental-https --port $PORT --hostname 0.0.0.0
elif [ "$OPTION" = "2" ]; then
    echo "Compilando pacote de produção (npm run build)..."
    npm run build
    if [ $? -ne 0 ]; then
        echo "Erro ao realizar o build do frontend."
        exit 1
    fi
    echo "Iniciando Next.js em Modo Produção (HTTP) na porta $PORT..."
    echo "Certifique-se de configurar Nginx/Caddy/CPanel para expor esta porta em HTTPS."
    npx next start --port $PORT --hostname 0.0.0.0
else
    echo "Opção inválida. Abortando."
    exit 1
fi
