"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import Image from "next/image";
import { onAuthStateChanged, signOut, User as FirebaseUser } from "firebase/auth";
import { auth } from "@/lib/firebase";
import { Menu, X, LogOut, User as UserIcon } from "lucide-react";

export default function Header() {
  const pathname = usePathname();
  const router = useRouter();
  const [isOpen, setIsOpen] = useState(false);
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [dbTeacher, setDbTeacher] = useState<any>(null);
  const [teacherPhotoUrl, setTeacherPhotoUrl] = useState<string | null>(null);

  // Resolve dinamicamente a API URL baseada no hostname de acesso
  const getApiUrl = () => {
    let url = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
    if (typeof window !== "undefined") {
      const hostname = window.location.hostname;
      if (hostname !== "localhost" && hostname !== "127.0.0.1") {
        url = `http://${hostname}:8000`;
      }
    }
    return url;
  };

  const getApiKey = () => {
    return process.env.NEXT_PUBLIC_API_KEY ?? "";
  };

  const loadTeacherPhoto = async (userEmail: string) => {
    const API_URL = getApiUrl();
    const apiKey = getApiKey();

    const res = await fetch(`${API_URL}/api/teachers/me/photo`, {
      method: "GET",
      cache: "no-store",
      headers: {
        "X-User-Email": userEmail,
        "x-api-key": apiKey,
      },
    });

    if (!res.ok) {
      setTeacherPhotoUrl((prev) => {
        if (prev) URL.revokeObjectURL(prev);
        return null;
      });
      return;
    }

    const blob = await res.blob();
    const objectUrl = URL.createObjectURL(blob);
    setTeacherPhotoUrl((prev) => {
      if (prev) URL.revokeObjectURL(prev);
      return objectUrl;
    });
  };

  // Monitora sessão e busca perfil no banco
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      if (currentUser && currentUser.email) {
        // Buscar nome/foto oficiais salvos no banco
        try {
          const API_URL = getApiUrl();
          const apiKey = getApiKey();
          const res = await fetch(`${API_URL}/api/teachers/me`, {
            method: "GET",
            cache: "no-store",
            headers: {
              "Content-Type": "application/json",
              "X-User-Email": currentUser.email,
              "x-api-key": apiKey,
            },
          });
          if (res.ok) {
            const data = await res.json();
            setDbTeacher(data);
            await loadTeacherPhoto(currentUser.email);
          } else {
            setDbTeacher(null);
            setTeacherPhotoUrl((prev) => {
              if (prev) URL.revokeObjectURL(prev);
              return null;
            });
          }
        } catch (err) {
          console.error("Erro ao buscar perfil do professor no header:", err);
          setDbTeacher(null);
          setTeacherPhotoUrl((prev) => {
            if (prev) URL.revokeObjectURL(prev);
            return null;
          });
        }
      } else {
        setDbTeacher(null);
        setTeacherPhotoUrl((prev) => {
          if (prev) URL.revokeObjectURL(prev);
          return null;
        });
      }
    });

    return () => {
      unsubscribe();
      setTeacherPhotoUrl((prev) => {
        if (prev) URL.revokeObjectURL(prev);
        return null;
      });
    };
  }, [pathname]); // Recarrega quando navega (para atualizar caso altere o perfil)

  // O cabeçalho só não deve aparecer na tela de login (raiz "/")
  if (pathname === "/") {
    return null;
  }

  const menuItems = [
    { name: "Início", path: "/dashboard" },
    { name: "Estudantes", path: "/students" },
    { name: "Gerenciar UCs", path: "/courses" },
    { name: "Perfil do Professor", path: "/profile" },
  ];

  const handleToggle = () => setIsOpen(!isOpen);
  const handleClose = () => setIsOpen(false);

  const handleLogout = async (e: React.MouseEvent) => {
    e.preventDefault();
    handleClose();
    try {
      await signOut(auth);
      router.push("/");
    } catch (err) {
      console.error("Erro ao deslogar:", err);
    }
  };

  // Lógica para obter as iniciais do nome
  const getInitials = (fullName: string) => {
    if (!fullName) return "?";
    const parts = fullName.trim().split(/\s+/);
    if (parts.length >= 2) {
      return `${parts[0][0]}${parts[parts.length - 1][0]}`.toUpperCase();
    }
    return fullName[0].toUpperCase();
  };

  const displayName = dbTeacher?.name || user?.displayName || "Professor";
  const displayEmail = user?.email || "";
  const initials = getInitials(displayName);
  const photoUrl = teacherPhotoUrl;

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border-color bg-white px-4 md:px-8 py-3 flex items-center justify-between shadow-[0_1px_2px_0_rgba(0,0,0,0.02)]">
      {/* Brand Logo e Nome */}
      <div className="flex items-center gap-3">
        <div className="relative w-8 h-8 md:w-9 md:h-9">
          <Image
            src="/assets/logo-sistema.png"
            alt="Logo Sistema"
            fill
            className="object-contain"
            priority
            sizes="(max-width: 768px) 32px, 36px"
          />
        </div>
        <span className="text-base md:text-lg font-bold bg-gradient-to-r from-primary to-blue-600 bg-clip-text text-transparent">
          Chamada Inteligente
        </span>
      </div>

      {/* Menu Horizontal de Navegação - Desktop */}
      <nav className="hidden md:flex items-center gap-6">
        {menuItems.map((item) => {
          const isActive = pathname === item.path || (item.path !== "/dashboard" && pathname.startsWith(item.path));
          return (
            <Link
              key={item.path}
              href={item.path}
              className={`text-sm font-medium transition-colors hover:text-foreground relative py-2 ${
                isActive ? "text-primary" : "text-text-secondary"
              }`}
            >
              {item.name}
              {isActive && (
                <span className="absolute bottom-[-13px] left-0 right-0 h-[2px] rounded-full bg-gradient-to-r from-primary to-blue-600" />
              )}
            </Link>
          );
        })}
      </nav>

      {/* Perfil Simplificado e Logout - Desktop */}
      <div className="hidden md:flex items-center gap-4">
        <Link href="/profile" className="flex items-center gap-2.5 group text-text-primary hover:opacity-90">
          <span className="text-sm font-medium group-hover:text-primary transition-colors max-w-[150px] truncate">
            Prof. {displayName}
          </span>
          <div className="relative w-8 h-8 rounded-full bg-primary flex items-center justify-center text-white font-semibold text-xs shadow-sm overflow-hidden">
            {photoUrl ? (
              <img
                src={photoUrl}
                alt="Avatar"
                className="w-full h-full object-cover"
              />
            ) : (
              <span>{initials}</span>
            )}
          </div>
        </Link>
        <button
          onClick={handleLogout}
          className="text-sm font-medium text-text-secondary hover:text-red-600 flex items-center gap-1 transition-colors ml-2 cursor-pointer bg-transparent border-none"
        >
          <LogOut className="w-4 h-4" />
          <span>Sair</span>
        </button>
      </div>

      {/* Botão do Menu Hambúrguer - Mobile */}
      <button
        onClick={handleToggle}
        className="flex md:hidden p-1.5 text-text-secondary hover:text-text-primary hover:bg-background rounded-lg transition-all focus:outline-none z-50"
        aria-label="Toggle Menu"
      >
        {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
      </button>

      {/* Dropdown Vertical - Mobile */}
      {isOpen && (
        <div className="absolute top-full left-0 right-0 w-full border-b border-border-color bg-white flex flex-col px-4 py-4 gap-4 shadow-lg md:hidden z-50">
          <nav className="flex flex-col gap-2">
            {menuItems.map((item) => {
              const isActive = pathname === item.path || (item.path !== "/dashboard" && pathname.startsWith(item.path));
              return (
                <Link
                  key={item.path}
                  href={item.path}
                  onClick={handleClose}
                  className={`text-sm font-semibold p-2.5 rounded-lg transition-colors ${
                    isActive
                      ? "bg-primary/5 text-primary"
                      : "text-text-secondary hover:bg-background hover:text-text-primary"
                  }`}
                >
                  {item.name}
                </Link>
              );
            })}
          </nav>
          
          <hr className="border-border-color" />
          
          {/* Perfil e Sair no Mobile */}
          <div className="flex items-center justify-between px-2">
            <Link href="/profile" onClick={handleClose} className="flex items-center gap-3">
              <div className="relative w-9 h-9 rounded-full bg-primary flex items-center justify-center text-white font-semibold text-sm shadow-sm overflow-hidden">
                {photoUrl ? (
                  <img
                    src={photoUrl}
                    alt="Avatar"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <span>{initials}</span>
                )}
              </div>
              <div className="flex flex-col max-w-[180px]">
                <span className="text-sm font-semibold text-text-primary truncate">Prof. {displayName}</span>
                <span className="text-xs text-text-secondary truncate">{displayEmail}</span>
              </div>
            </Link>
            <button
              onClick={handleLogout}
              className="text-sm font-semibold text-red-500 hover:text-red-700 transition-colors p-2 cursor-pointer bg-transparent border-none"
            >
              Sair
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
