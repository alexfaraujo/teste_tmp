"use client";

import { usePathname } from "next/navigation";
import Image from "next/image";

export default function Footer() {
  const pathname = usePathname();

  // O rodapé só não aparece na tela de login (raiz "/")
  if (pathname === "/") {
    return null;
  }

  const currentYear = new Date().getFullYear();

  return (
    <footer className="w-full bg-card-bg border-t border-border-color py-6 flex flex-col items-center justify-center gap-1 text-center text-sm text-text-secondary">
      <div className="flex items-center gap-2">
        <span>Desenvolvido por</span>
        <div className="relative w-20 h-5">
          <Image
            src="/assets/logo_magic-it-lab.png"
            alt="Logo Magic IT Lab"
            fill
            className="object-contain"
            sizes="80px"
          />
        </div>
      </div>
      <p className="text-xs opacity-80 mt-1">
        &copy; {currentYear} Todos os direitos reservados.
      </p>
    </footer>
  );
}
