# Especificação da Arquitetura do Frontend

Este documento descreve os requisitos arquiteturais, decisões tecnológicas, fluxo de dados e design de interfaces para o Frontend do **Sistema de Chamada Inteligente**.

---

## 1. Stack Tecnológica Recomendada

Para garantir um visual moderno, reatividade fluida e uma experiência de usuário *premium*, a pilha de tecnologia selecionada é:

* **Framework Principal:** [Next.js](https://nextjs.org/) (React 18+) utilizando a estrutura moderna de **App Router** para otimização de rotas e renderização híbrida.
* **Estilização e Layout:** [TailwindCSS](https://tailwindcss.com/) para design utilitário responsivo, suporte automático a Dark/Light Mode e transições fluidas. A interface será projetada com foco em **Responsividade Mobile-First**, garantindo usabilidade perfeita em smartphones de diferentes proporções, facilitando a operação do professor diretamente do celular.
* **Componentes de UI:** [Shadcn/ui](https://ui.shadcn.com/) (baseado em Radix UI) para componentes acessíveis, elegantes e customizáveis (Tabelas, Modais, Cards, Seletores).
* **Biblioteca de Gráficos:** [Recharts](https://recharts.org/) para visualizações estatísticas leves e responsivas no Dashboard do professor.

---

## 2. Autenticação e Segurança (Google OAuth 2.0)

Para eliminar a necessidade de armazenamento de senhas e garantir conformidade com políticas corporativas/acadêmicas:

* **Mecanismo:** Integração com o login do **Google Workspace** (Google OAuth 2.0) utilizando o **Firebase Authentication** (Google Provider) ou o SDK oficial Google Identity Services.
* **Restrição de Perfil por Domínio (Email-Filtering):**
  * O frontend e o backend aplicarão uma regra estrita de validação na resposta do login.
  * Apenas e-mails contendo o domínio institucional configurado no sistema (ex: `@ifms.edu.br`) terão acesso liberado.
  * E-mails pessoais (`@gmail.com`) ou de qualquer outro domínio de estudantes serão imediatamente barrados com mensagem informativa na tela de login.
* **Auto-cadastro Obrigatório no Primeiro Login:**
  * Não havendo cadastro prévio no banco de dados, o primeiro login do professor através do Google OAuth retornará uma resposta indicando a ausência do perfil.
  * O frontend interceptará esse retorno e redirecionará o usuário obrigatoriamente para a tela de preenchimento de perfil inicial. 
  * O acesso ao Dashboard e outras áreas restritas da aplicação só será liberado após o preenchimento bem-sucedido de seus dados e envio da foto de perfil.
* **Sessão:** Token JWT (JSON Web Token) guardado de forma segura (HTTP-only Cookies ou LocalStorage encriptado) para autenticar requisições subsequentes.

---

## 3. Fluxo de Telas e Interfaces de Usuário (UI/UX)

Toda a interface do frontend será centralizada em um perfil único: o do **Professor da Unidade Curricular**. 

### Layout Global Unificado (`app/layout.tsx`)
Todas as telas do frontend compartilharão obrigatoriamente uma casca de layout padronizada contendo:
* **Cabeçalho Global (Header):** Exibe o nome do sistema ("Chamada Inteligente") e o logotipo do site, além do link de atalho para o perfil do professor conectado. Não há menus de notificações redundantes.
* **Rodapé Global (Footer):** Exibe a identificação e direitos autorais do laboratório de desenvolvimento que acolheu o projeto: **Magic IT Lab**, acompanhado do logotipo oficial do laboratório.
* **Organização de Assets para Substituição:** Os caminhos dos logotipos serão mapeados de forma estática para facilitar a edição pelo desenvolvedor ao final:
  * Logotipo do site: `/public/assets/logo.png`
  * Logotipo do Magic IT Lab: `/public/assets/magic_it_lab_logo.png`

As páginas específicas planejadas são:

### A. Página de Autenticação (`/`)
* **Design:** Visual limpo clássico acadêmico, utilizando técnicas de *Glassmorphism* no card central de login e fundos com gradientes suaves.
* **Componentes:**
  * Logotipo da instituição.
  * Breve descrição didática do sistema.
  * **Login com Google Exclusivo:** Botão proeminente *"Entrar com e-mail institucional do Google"*. Não possui campos para digitação de login e senha convencionais.

### B. Dashboard Administrativo (`/dashboard`)
* **Métricas Gerais (Cards):**
  * Presença média semanal da turma.
  * Número de estudantes críticos em faltas (risco de reprovação).
  * Total de estudantes matriculados na disciplina ativa.
* **Análise Visual (Gráficos):**
  * Gráfico de evolução de presença aula a aula.
  * Tabela de estudantes cadastrados com ações rápidas para edição e exclusão.
* **Ações Rápidas:**
  * Seletor de Unidade Curricular (carregado dinamicamente via API).
  * Botão *"Iniciar Chamada (Totem)"* e *"Cadastrar Estudante"*.
  * Botão *"Exportar Chamada (CSV)"*: Permite o download das frequências do dia ou mês selecionado para importação direta em planilhas acadêmicas oficiais.
  * Painel de Chamada Manual (contingência): Lista de estudantes da turma com *checkboxes* para o professor marcar presenças manuais caso um estudante esteja impossibilitado de ler a face.

### C. Cadastro de Estudante (`/students/register`)
* **Formulário:** Nome completo, Matrícula única e seleção múltipla das Unidades Curriculares em que o estudante está matriculado.
* **Validação de Matrícula:** Caso a matrícula fornecida já exista no banco, o cadastro é bloqueado impedindo a inserção duplicada, exibindo aviso detalhado para que o professor edite o estudante em vez de recadastrá-lo.
* **Câmera Integrada:**
  * Acesso à câmera usando `navigator.mediaDevices.getUserMedia`.
  * **Seleção de Câmeras (Alternador):** Permite a alternância rápida entre a câmera frontal (selfie) e a câmera traseira do smartphone.
  * **Moldura Ring Light:** Botão que, quando ativo, deixa o fundo da tela totalmente branco e destaca uma borda brilhante ao redor da elipse de alinhamento da face, gerando iluminação artificial para o rosto do estudante.
  * **Overlay Guia:** Exibição de um contorno oval translúcido no centro do vídeo.
  * **Captura:** O professor clica em "Capturar e Cadastrar". O frame é convertido em arquivo Blob binário e enviado via POST Multipart para a API.

### D. Edição de Estudante (`/students/edit/:id`)
* **Formulário:** Permite atualizar os dados cadastrais do estudante e tomar uma nova fotografia de rosto caso o reconhecimento facial comece a falhar na leitura do totem devido a alterações físicas do estudante ou qualidade da imagem original.
* **Câmera:** Possui os mesmos recursos de câmera integrada do cadastro (seleção de câmera, ring light e overlay guia).

### E. Perfil do Professor (`/profile`)
* **Finalidade:** Permite ao professor logado verificar seus dados (Nome completo, email institucional, departamento) e atualizar informações de contato secundárias (como telefone e ramal) e a própria foto de perfil.

### F. Quiosque Totem de Chamada (`/attendance/totem`)
* **Modo Quiosque (Fullscreen):** Abre a câmera em tela cheia para leitura contínua com fundo escuro/claro minimalista com linhas geométricas discretas (sem fotos pesadas).
* **Seleção de Câmeras e Ring Light:** Controles rápidos para alternar lentes do celular e ativar a iluminação da moldura ring light.
* **Leitura Contínua e Automática:**
  * O sistema captura fotos da câmera a cada 2 segundos e envia ao endpoint `/api/attendance` da disciplina ativa.
* **Feedbacks Visuais e Alertas Dinâmicos:**
  * **Sucesso (Verde):** Exibe um *check* animado com o nome do estudante, número de matrícula e mensagem *"Presença Confirmada!"*. Permanece na tela por 1.5s e retorna à leitura.
  * **Alerta/Erro (Vermelho):** Mensagens amigáveis para falhas comuns:
    * *Anti-spoofing:* "A foto capturada falhou no teste de vivacidade. Olhe diretamente para a câmera."
    * *Não Matriculado:* "Estudante reconhecido, mas não possui matrícula nesta Unidade Curricular."
    * *Duplicado:* "Presença já registrada para este estudante na aula de hoje."
    * *Não Reconhecido:* "Rosto não encontrado no banco de dados."
* **Feedback Sonoro (Audio-Sintetizador):**
  * Integração nativa com a **Web Speech API** (`window.speechSynthesis`).
  * O totem fala o nome do estudante ao registrar com sucesso (ex: *"Presença confirmada, Thiago!"*) ou emite alertas específicos em falhas.
* **Bloqueio de Segurança:**
  * Para sair do modo totem, exige-se a digitação de um PIN numérico de 4 dígitos configurado pelo professor.

### G. Gerenciamento de Unidades Curriculares (`/courses`)
* **Finalidade:** Permitir que o professor gerencie (liste, crie, edite e exclua) suas próprias Unidades Curriculares registradas na tabela `course_units`.
* **Componentes:**
  * **Listagem:** Grid ou tabela exibindo Nome da UC, Código, Carga Horária, Sala/Local e quantidade de estudantes. Contém botões de "Editar" e "Excluir".
  * **Formulário Dinâmico:** Campos para Nome da Disciplina, Código da UC, Carga Horária e Sala/Local, com suporte a cancelamento de edição.
  * **Validação de Código Único:** Alerta caso o código fornecido coincida com outra UC já existente.

---

## 4. Integração e Comunicação com o Backend

* **Chave de API:** Todas as requisições enviadas ao backend incluirão o cabeçalho de autenticação `x-api-key` contendo o token definido nas variáveis de ambiente.
* **Upload de Imagens:** Comunicação baseada em requisições HTTP do tipo `multipart/form-data` para envio dos arquivos Blob das fotos.
* **Tratamento de Exceções:** Mapeamento de retornos HTTP do FastAPI (400, 403, 404, 503) para exibição de modais e alertas amigáveis na UI do professor.

---

## 5. Governança de Commits e Sincronização Remota

* **Pausa para Aprovação:** A cada etapa concluída e testada localmente, o agente deve pausar a execução e aguardar a avaliação do usuário.
* **Proibição de Push Automático:** O comando `git push` nunca deve ser executado de forma automática ou autônoma pelo agente. O envio de modificações locais para o repositório GitHub depende estritamente de aprovação formal e comando escrito do usuário (ex: "pode fazer o push") após validar o funcionamento local.

