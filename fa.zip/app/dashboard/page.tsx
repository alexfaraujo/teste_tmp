"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { onAuthStateChanged, User as FirebaseUser } from "firebase/auth";
import { auth } from "@/lib/firebase";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer
} from "recharts";
import {
  Users,
  BookOpen,
  ClipboardCheck,
  TrendingUp,
  PlusCircle,
  Play,
  ArrowRight,
  Clock,
  RefreshCw,
  AlertCircle
} from "lucide-react";

export default function Dashboard() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [teacherName, setTeacherName] = useState("");
  const [isMounted, setIsMounted] = useState(false);

  // Estados de Dados da API
  const [stats, setStats] = useState({
    avgAttendance: 0,
    totalStudents: 0,
    totalClasses: 0,
    totalCourses: 0
  });
  const [chartData, setChartData] = useState<any[]>([]);
  const [recentActivities, setRecentActivities] = useState<any[]>([]);
  const [error, setError] = useState<string | null>(null);

  // Resolve dinamicamente a API URL baseada no hostname de acesso (útil para celulares)
  const getApiUrl = () => {
    let url = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
    if (typeof window !== "undefined") {
      const hostname = window.location.hostname;
      if (hostname !== "localhost" && hostname !== "127.0.0.1") {
        url = `http://${hostname}:8000`;
      }
    }
    return url;
  };

  const getApiKey = () => {
    return process.env.NEXT_PUBLIC_API_KEY ?? "";
  };

  useEffect(() => {
    setIsMounted(true);
  }, []);

  // Monitora a sessão do Firebase
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      if (user) {
        setFirebaseUser(user);
        loadDashboardData(user.email || "");
      } else {
        router.push("/");
      }
    });

    return () => unsubscribe();
  }, [router]);

  const loadDashboardData = async (userEmail: string) => {
    setLoading(true);
    setError(null);
    const API_URL = getApiUrl();
    const apiKey = getApiKey();

    try {
      // 1. Validar perfil do Professor no Backend
      const profileRes = await fetch(`${API_URL}/api/teachers/me`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          "X-User-Email": userEmail,
          "x-api-key": apiKey,
        },
      });

      if (profileRes.status === 404) {
        // Sem perfil -> Roteia ao auto-cadastro
        router.push("/profile");
        return;
      }

      if (!profileRes.ok) {
        const errData = await profileRes.json();
        throw new Error(errData.detail || "Falha ao obter perfil do professor.");
      }

      const profileData = await profileRes.json();
      setTeacherName(profileData.name);

      // 2. Buscar Dados Reais das APIs de Apoio
      const [coursesRes, studentsRes, attendanceRes] = await Promise.all([
        fetch(`${API_URL}/api/course_units`, { headers: { "X-User-Email": userEmail, "x-api-key": apiKey } }),
        fetch(`${API_URL}/api/students`, { headers: { "X-User-Email": userEmail, "x-api-key": apiKey } }),
        fetch(`${API_URL}/api/attendance`, { headers: { "X-User-Email": userEmail, "x-api-key": apiKey } })
      ]);

      const courses = coursesRes.ok ? await coursesRes.json() : [];
      const students = studentsRes.ok ? await studentsRes.json() : [];
      const attendances = attendanceRes.ok ? await attendanceRes.json() : [];

      // 3. Montar Métricas e Gráficos
      const coursesCount = courses.length;
      const studentsCount = students.length;
      // 1. Mapeamento de matrícula: para cada UC, guardar o Set de IDs dos alunos matriculados nela
      const enrollmentMap: { [key: number]: Set<number> } = {};
      courses.forEach((c: any) => {
        enrollmentMap[c.id] = new Set<number>();
      });

      students.forEach((student: any) => {
        if (student.course_units) {
          student.course_units.forEach((cu: any) => {
            if (!enrollmentMap[cu.id]) {
              enrollmentMap[cu.id] = new Set<number>();
            }
            enrollmentMap[cu.id].add(student.id);
          });
        }
      });

      // 2. Agrupar presenças por UC e por Data (Sessão de Aula)
      const sessions: { [sessionKey: string]: { courseUnitId: number; dateStr: string; presentStudents: Set<number> } } = {};
      attendances.forEach((att: any) => {
        if (!att.timestamp) return;
        const dateObj = new Date(att.timestamp);
        const dateStr = dateObj.toISOString().split("T")[0]; // YYYY-MM-DD
        const sessionKey = `${att.course_unit_id}_${dateStr}`;

        if (!sessions[sessionKey]) {
          sessions[sessionKey] = {
            courseUnitId: att.course_unit_id,
            dateStr,
            presentStudents: new Set<number>()
          };
        }
        sessions[sessionKey].presentStudents.add(att.student_id);
      });

      // 3. Calcular a taxa de presença de cada sessão
      const sessionRates: { sessionKey: string; dateStr: string; rate: number }[] = [];
      let totalRatesSum = 0;
      let validSessionsCount = 0;

      Object.entries(sessions).forEach(([sessionKey, session]) => {
        const enrolledStudents = enrollmentMap[session.courseUnitId] || new Set();
        const enrolledCount = enrolledStudents.size;
        const presentCount = session.presentStudents.size;

        if (enrolledCount > 0) {
          const rate = Math.min(100, (presentCount / enrolledCount) * 100);
          sessionRates.push({
            sessionKey,
            dateStr: session.dateStr,
            rate
          });
          totalRatesSum += rate;
          validSessionsCount++;
        }
      });

      // 4. Calcular a média geral de frequência
      const avgAttendance = validSessionsCount > 0
        ? Math.round(totalRatesSum / validSessionsCount)
        : 0;

      setStats({
        avgAttendance,
        totalStudents: studentsCount,
        totalClasses: validSessionsCount,
        totalCourses: coursesCount
      });

      // 5. Agrupar as taxas de presença calculadas por data para gerar o histórico diário
      const ratesByDate: { [dateStr: string]: { rateSum: number; count: number } } = {};
      sessionRates.forEach(s => {
        if (!ratesByDate[s.dateStr]) {
          ratesByDate[s.dateStr] = { rateSum: 0, count: 0 };
        }
        ratesByDate[s.dateStr].rateSum += s.rate;
        ratesByDate[s.dateStr].count++;
      });

      const dailyAverages = Object.entries(ratesByDate).map(([dateStr, data]) => {
        return {
          dateStr,
          rate: Math.round(data.rateSum / data.count)
        };
      });

      // Ordenar por data crescente
      dailyAverages.sort((a, b) => a.dateStr.localeCompare(b.dateStr));

      // 6. Preencher os últimos 5 dias letivos de forma contígua terminando na data mais recente
      const chartDataList: { name: string; Frequencia: number }[] = [];
      let endDate = new Date();
      if (dailyAverages.length > 0) {
        const latestDateStr = dailyAverages[dailyAverages.length - 1].dateStr;
        endDate = new Date(latestDateStr + "T12:00:00");
      }

      const weekdayNames = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];

      for (let i = 4; i >= 0; i--) {
        const targetDate = new Date(endDate);
        targetDate.setDate(endDate.getDate() - i);
        const targetDateStr = targetDate.toISOString().split("T")[0];

        const realData = dailyAverages.find(d => d.dateStr === targetDateStr);
        const dayName = weekdayNames[targetDate.getDay()];
        const formattedDate = `${targetDate.getDate().toString().padStart(2, "0")}/${(targetDate.getMonth() + 1).toString().padStart(2, "0")}`;

        chartDataList.push({
          name: `${dayName} (${formattedDate})`,
          Frequencia: realData ? realData.rate : 0
        });
      }

      setChartData(chartDataList);

      // 7. Mapear as atividades recentes usando os nomes reais de estudante e UC
      const activities = attendances.slice(0, 5).map((att: any, index: number) => {
        const studentName = att.student?.name || "Estudante";
        const courseName = att.course_unit?.name || "UC";
        return {
          id: index,
          type: "chamada",
          text: `Presença registrada em ${courseName}`,
          time: new Date(att.timestamp).toLocaleDateString("pt-BR"),
          detail: `Estudante: ${studentName} (${att.student?.matricula || "—"})`
        };
      });

      setRecentActivities(activities.length > 0 ? activities : [
        { id: 1, type: "info", text: "Sem atividades registradas no histórico real.", time: "Agora", detail: "" }
      ]);

    } catch (err: any) {
      console.error("Erro ao carregar dados do dashboard:", err);
      setError("Erro de conexão: Não foi possível conectar ao servidor backend (FastAPI).");
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex-1 w-full flex flex-col items-center justify-center bg-[#F1F5F9] py-20 gap-4">
        <RefreshCw className="w-8 h-8 text-primary animate-spin" />
        <span className="text-sm font-medium text-text-secondary">Carregando informações do painel...</span>
      </div>
    );
  }

  return (
    <div className="flex-1 w-full bg-[#F1F5F9] px-4 py-8 flex flex-col items-center">
      <div className="w-full max-w-5xl flex flex-col gap-6">
        
        {/* Card de Boas-vindas */}
        <div className="w-full bg-white border border-[#E2E8F0] rounded-2xl p-6 md:p-8 shadow-sm flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div>
            <h2 className="text-2xl font-bold text-text-primary tracking-tight">
              Olá, {teacherName || "Professor"}
            </h2>
            <p className="text-sm text-text-secondary mt-1">
              Bem-vindo ao painel da sua sala de aula. Gerencie presenças e estudantes em um só lugar.
            </p>
          </div>

          {/* Ações Rápidas do Topo */}
          <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto">
            <Link
              href="/attendance/totem"
              className="flex-1 md:flex-initial bg-gradient-to-r from-primary to-blue-600 hover:opacity-95 text-white font-semibold py-2.5 px-4 rounded-xl text-sm flex items-center justify-center gap-2 shadow-sm transition-all"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>Iniciar Chamada</span>
            </Link>
            <Link
              href="/students/register"
              className="flex-1 md:flex-initial bg-white border border-[#CBD5E1] hover:bg-[#F8FAFC] text-text-primary font-semibold py-2.5 px-4 rounded-xl text-sm flex items-center justify-center gap-2 shadow-sm transition-all"
            >
              <PlusCircle className="w-4 h-4 text-text-secondary" />
              <span>Cadastrar Estudante</span>
            </Link>
          </div>
        </div>

        {/* Alerta de Conexão */}
        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 rounded-xl p-4 flex items-start gap-2.5 text-sm animate-in fade-in duration-200">
            <AlertCircle className="w-5 h-5 shrink-0 text-red-500 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        {/* Grid de Cards de Métricas */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 w-full">
          
          {/* Card 1: Freqüência Média */}
          <div className="bg-white border border-[#E2E8F0] rounded-2xl p-5 shadow-sm flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-text-secondary uppercase tracking-wider">
                Frequência Média
              </span>
              <div className="w-7 h-7 bg-primary/10 rounded-lg flex items-center justify-center text-primary">
                <TrendingUp className="w-4 h-4" />
              </div>
            </div>
            <div className="flex flex-col gap-1.5">
              <span className="text-3xl font-extrabold text-text-primary tracking-tight">
                {stats.avgAttendance}%
              </span>
              {/* Barra de progresso visual */}
              <div className="w-full bg-[#E2E8F0] h-2 rounded-full overflow-hidden mt-1">
                <div
                  className="bg-gradient-to-r from-primary to-blue-600 h-full rounded-full"
                  style={{ width: `${stats.avgAttendance}%` }}
                />
              </div>
            </div>
          </div>

          {/* Card 2: Estudantes Ativos */}
          <div className="bg-white border border-[#E2E8F0] rounded-2xl p-5 shadow-sm flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-text-secondary uppercase tracking-wider">
                Estudantes Ativos
              </span>
              <div className="w-7 h-7 bg-blue-50 rounded-lg flex items-center justify-center text-blue-600">
                <Users className="w-4 h-4" />
              </div>
            </div>
            <div className="flex flex-col">
              <span className="text-3xl font-extrabold text-text-primary tracking-tight">
                {stats.totalStudents}
              </span>
              <span className="text-xs text-text-secondary mt-1">
                Matriculados no total
              </span>
            </div>
          </div>

          {/* Card 3: Chamadas Realizadas */}
          <div className="bg-white border border-[#E2E8F0] rounded-2xl p-5 shadow-sm flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-text-secondary uppercase tracking-wider">
                Chamadas Efetuadas
              </span>
              <div className="w-7 h-7 bg-green-50 rounded-lg flex items-center justify-center text-green-600">
                <ClipboardCheck className="w-4 h-4" />
              </div>
            </div>
            <div className="flex flex-col">
              <span className="text-3xl font-extrabold text-text-primary tracking-tight">
                {stats.totalClasses}
              </span>
              <span className="text-xs text-text-secondary mt-1">
                Histórico acumulado
              </span>
            </div>
          </div>

          {/* Card 4: Disciplinas UCs */}
          <div className="bg-white border border-[#E2E8F0] rounded-2xl p-5 shadow-sm flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-text-secondary uppercase tracking-wider">
                Unidades Curriculares
              </span>
              <div className="w-7 h-7 bg-purple-50 rounded-lg flex items-center justify-center text-purple-600">
                <BookOpen className="w-4 h-4" />
              </div>
            </div>
            <div className="flex flex-col">
              <span className="text-3xl font-extrabold text-text-primary tracking-tight">
                {stats.totalCourses}
              </span>
              <span className="text-xs text-text-secondary mt-1">
                UCs cadastradas
              </span>
            </div>
          </div>

        </div>

        {/* Conteúdo Principal em Grade (Gráfico e Atividades Recentes) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 w-full">
          
          {/* Gráfico Semanal (Col 8) */}
          <div className="lg:col-span-8 bg-white border border-[#E2E8F0] rounded-2xl p-5 md:p-6 shadow-sm flex flex-col gap-4">
            <div className="flex justify-between items-center border-b border-[#F1F5F9] pb-3 mb-2">
              <h3 className="text-base font-bold text-text-primary">Frequência Semanal (%)</h3>
              <span className="text-xs text-text-secondary">Taxa diária de presenças</span>
            </div>

            <div className="w-full h-[260px]">
              {isMounted && (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chartData} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                    <defs>
                      <linearGradient id="barGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#4f46e5" stopOpacity={0.9} />
                        <stop offset="100%" stopColor="#3b82f6" stopOpacity={0.6} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
                    <XAxis
                      dataKey="name"
                      tickLine={false}
                      axisLine={false}
                      stroke="#64748B"
                      fontSize={11}
                      fontWeight={500}
                    />
                    <YAxis
                      domain={[0, 100]}
                      tickLine={false}
                      axisLine={false}
                      stroke="#64748B"
                      fontSize={11}
                      fontWeight={500}
                    />
                    <Tooltip
                      cursor={{ fill: "#F8FAFC", radius: 8 }}
                      contentStyle={{
                        backgroundColor: "#FFFFFF",
                        border: "1px solid #CBD5E1",
                        borderRadius: "12px",
                        boxShadow: "0 10px 15px -3px rgba(0,0,0,0.05)"
                      }}
                      labelStyle={{ fontWeight: 600, color: "#0F172A", fontSize: 12 }}
                      itemStyle={{ color: "#4F46E5", fontWeight: 600, fontSize: 12 }}
                    />
                    <Bar
                      dataKey="Frequencia"
                      fill="url(#barGrad)"
                      radius={[6, 6, 0, 0]}
                      maxBarSize={45}
                    />
                  </BarChart>
                </ResponsiveContainer>
              )}
            </div>
          </div>

          {/* Atividades Recentes (Col 4) */}
          <div className="lg:col-span-4 bg-white border border-[#E2E8F0] rounded-2xl p-5 md:p-6 shadow-sm flex flex-col gap-4">
            <div className="flex justify-between items-center border-b border-[#F1F5F9] pb-3 mb-2">
              <h3 className="text-base font-bold text-text-primary">Atividade Recente</h3>
            </div>

            <div className="flex flex-col gap-4 overflow-y-auto max-h-[260px]">
              {recentActivities.map((act) => (
                <div key={act.id} className="flex gap-3 text-sm group">
                  <div className="flex flex-col items-center">
                    <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-text-secondary border border-[#CBD5E1] shrink-0">
                      <Clock className="w-3.5 h-3.5" />
                    </div>
                    {/* Linha conectora vertical */}
                    <div className="flex-1 w-[1px] bg-slate-200 my-1 group-last:hidden" />
                  </div>

                  <div className="flex flex-col gap-0.5 pt-0.5">
                    <span className="font-semibold text-text-primary leading-tight">
                      {act.text}
                    </span>
                    <span className="text-xs text-text-secondary">
                      {act.time} {act.detail && `• ${act.detail}`}
                    </span>
                  </div>
                </div>
              ))}
            </div>

            {/* Link para Visualizar Lista de Chamadas completa */}
            <div className="pt-2 border-t border-[#F1F5F9] mt-auto">
              <Link
                href="/courses"
                className="w-full text-xs font-semibold text-primary hover:text-blue-600 transition-colors flex items-center justify-center gap-1 py-1"
              >
                <span>Gerenciar UCs e chamadas</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
}
