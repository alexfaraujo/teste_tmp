"use client";

import { useState, useEffect, useRef } from "react";
import { useRouter } from "next/navigation";
import Image from "next/image";
import { onAuthStateChanged, User as FirebaseUser } from "firebase/auth";
import { auth } from "@/lib/firebase";
import {
  Camera,
  Save,
  Edit2,
  User,
  Phone,
  Building2,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  XCircle
} from "lucide-react";

export default function ProfilePage() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);

  // Estados do Perfil
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [department, setDepartment] = useState("");
  const [photoObjectUrl, setPhotoObjectUrl] = useState<string | null>(null);
  const [hasServerPhoto, setHasServerPhoto] = useState(false);

  // Estados de Fluxo da Tela
  const [isRegistered, setIsRegistered] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  // Estados da Webcam
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const isFetchedRef = useRef(false);
  const [cameraActive, setCameraActive] = useState(false);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [capturedPhoto, setCapturedPhoto] = useState<string | null>(null);

  // Resolve dinamicamente a API URL baseada no hostname de acesso (útil para celulares)
  const getApiUrl = () => {
    let url = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
    if (typeof window !== "undefined") {
      const hostname = window.location.hostname;
      if (hostname !== "localhost" && hostname !== "127.0.0.1") {
        url = `http://${hostname}:8000`;
      }
    }
    return url;
  };

  const getApiKey = () => {
    return process.env.NEXT_PUBLIC_API_KEY ?? "";
  };

  const clearPhotoObjectUrl = () => {
    setPhotoObjectUrl((prev) => {
      if (prev) URL.revokeObjectURL(prev);
      return null;
    });
  };

  const loadTeacherPhoto = async (userEmail: string) => {
    const API_URL = getApiUrl();
    const apiKey = getApiKey();
    const response = await fetch(`${API_URL}/api/teachers/me/photo`, {
      method: "GET",
      cache: "no-store",
      headers: {
        "X-User-Email": userEmail,
        "x-api-key": apiKey,
      },
    });

    if (!response.ok) {
      clearPhotoObjectUrl();
      setHasServerPhoto(false);
      return;
    }

    const blob = await response.blob();
    const objectUrl = URL.createObjectURL(blob);
    setPhotoObjectUrl((prev) => {
      if (prev) URL.revokeObjectURL(prev);
      return objectUrl;
    });
    setHasServerPhoto(true);
  };

  // Monitora a sessão do Firebase e evita loops repetitivos que resetam o modo de edição
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      if (user) {
        setFirebaseUser(user);
        setName(user.displayName || "");
        setEmail(user.email || "");
        
        // Executa a API apenas uma vez por ciclo de vida do componente
        if (!isFetchedRef.current) {
          isFetchedRef.current = true;
          checkTeacherProfile(user.email || "");
        }
      } else {
        router.push("/");
      }
    });

    return () => {
      unsubscribe();
      stopCamera();
      clearPhotoObjectUrl();
    };
  }, [router]);

  // Vincula o stream do vídeo ao elemento <video> assim que ele é montado no DOM
  useEffect(() => {
    if (videoRef.current && stream) {
      videoRef.current.srcObject = stream;
    }
  }, [stream, cameraActive]);


  // Consulta se o cadastro já existe no banco
  const checkTeacherProfile = async (userEmail: string) => {
    setError(null);
    const API_URL = getApiUrl();
    const apiKey = getApiKey();
    try {
      const response = await fetch(`${API_URL}/api/teachers/me`, {
        method: "GET",
        cache: "no-store",
        headers: {
          "Content-Type": "application/json",
          "X-User-Email": userEmail,
          "x-api-key": apiKey,
        },
      });

      if (response.status === 200) {
        const data = await response.json();
        setIsRegistered(true);
        setName(data.name);
        setPhone(data.phone || "");
        setDepartment(data.department || "");
        const teacherHasPhoto = Boolean(data.photo_key);
        setHasServerPhoto(teacherHasPhoto);
        if (teacherHasPhoto) {
          await loadTeacherPhoto(userEmail);
        } else {
          clearPhotoObjectUrl();
        }
        setIsEditing(false);
      } else if (response.status === 404) {
        setIsRegistered(false);
        setIsEditing(true); // Fica editável para preenchimento no auto-cadastro
        clearPhotoObjectUrl();
        setHasServerPhoto(false);
        startCamera(); // Inicia a câmera automaticamente para o auto-cadastro
      } else {
        const data = await response.json();
        setError(data.detail || "Erro ao consultar perfil no banco de dados.");
      }
    } catch (err) {
      console.error("Erro de conexão ao consultar perfil:", err);
      setError("Erro de conexão: Não foi possível conectar ao servidor backend (FastAPI).");
    } finally {
      setLoading(false);
    }
  };

  // Liga a Webcam nativa do navegador
  const startCamera = async () => {
    setError(null);
    setCapturedPhoto(null);
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { width: 640, height: 480, facingMode: "user" },
        audio: false
      });
      setStream(mediaStream);
      setCameraActive(true);
    } catch (err) {
      console.error("Erro ao acessar a webcam:", err);
      setError("Câmera indisponível: Permissão negada ou nenhum dispositivo de captura de vídeo encontrado.");
    }
  };

  // Desliga a Webcam
  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach((track) => track.stop());
    }
    setStream(null);
    setCameraActive(false);
  };

  // Captura o frame do vídeo em uma imagem estática base64
  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      const ctx = canvas.getContext("2d");
      
      if (ctx) {
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        // Inverte a imagem no canvas se o vídeo estiver espelhado
        ctx.translate(canvas.width, 0);
        ctx.scale(-1, 1);
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        
        const dataUrl = canvas.toDataURL("image/jpeg", 0.9);
        setCapturedPhoto(dataUrl);
        stopCamera();
      }
    }
  };

  // Limpa a foto tirada para capturar outra
  const handleRecapture = () => {
    setCapturedPhoto(null);
    startCamera();
  };

  // Converte a imagem base64 capturada em um Blob para envio multipart/form-data
  const dataURItoBlob = (dataURI: string) => {
    const byteString = atob(dataURI.split(",")[1]);
    const mimeString = dataURI.split(",")[0].split(":")[1].split(";")[0];
    const ab = new ArrayBuffer(byteString.length);
    const ia = new Uint8Array(ab);
    for (let i = 0; i < byteString.length; i++) {
      ia[i] = byteString.charCodeAt(i);
    }
    return new Blob([ab], { type: mimeString });
  };

  // Submete o cadastro ou edição
  const handleSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setError(null);
    setSuccess(null);

    if (!firebaseUser || !firebaseUser.email) return;

    if (!department.trim()) {
      setError("O campo Departamento é obrigatório.");
      return;
    }

    if (!isRegistered && !capturedPhoto) {
      setError("É obrigatório capturar uma foto com a webcam para efetuar o primeiro cadastro.");
      return;
    }

    setSubmitting(true);
    const API_URL = getApiUrl();
    const apiKey = getApiKey();

    try {
      if (!isRegistered) {
        // Fluxo 1: Criar novo cadastro de Professor (Auto-cadastro)
        const registerResponse = await fetch(`${API_URL}/api/teachers/register`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "X-User-Email": firebaseUser.email,
            "x-api-key": apiKey,
          },
          body: JSON.stringify({
            name,
            phone,
            department
          }),
        });

        if (!registerResponse.ok) {
          const errData = await registerResponse.json();
          throw new Error(errData.detail || "Erro ao realizar o cadastro do professor.");
        }

        // Fluxo 2: Upload da Foto de Perfil
        if (capturedPhoto) {
          const photoBlob = dataURItoBlob(capturedPhoto);
          const formData = new FormData();
          formData.append("file", photoBlob, "profile.jpg");

          const photoResponse = await fetch(`${API_URL}/api/teachers/me/photo`, {
            method: "POST",
            headers: {
              "X-User-Email": firebaseUser.email,
              "x-api-key": apiKey,
            },
            body: formData,
          });

          if (!photoResponse.ok) {
            throw new Error("Dados salvos, mas houve uma falha ao enviar a foto de perfil.");
          }
        }

        setSuccess("Cadastro realizado com sucesso!");
        setTimeout(() => {
          router.push("/dashboard");
        }, 1500);

      } else {
        // Fluxo 3: Atualização de Dados (Edição)
        const updateResponse = await fetch(`${API_URL}/api/teachers/me`, {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
            "X-User-Email": firebaseUser.email,
            "x-api-key": apiKey,
          },
          body: JSON.stringify({
            phone,
            department
          }),
        });

        if (!updateResponse.ok) {
          const errData = await updateResponse.json();
          throw new Error(errData.detail || "Erro ao atualizar dados cadastrais.");
        }

        // Fluxo 4: Atualização da Foto (Se capturada nova)
        if (capturedPhoto) {
          const photoBlob = dataURItoBlob(capturedPhoto);
          const formData = new FormData();
          formData.append("file", photoBlob, "profile.jpg");

          const photoResponse = await fetch(`${API_URL}/api/teachers/me/photo`, {
            method: "POST",
            headers: {
              "X-User-Email": firebaseUser.email,
              "x-api-key": apiKey,
            },
            body: formData,
          });

          if (!photoResponse.ok) {
            throw new Error("Dados cadastrais salvos, mas falhou ao atualizar a foto de perfil.");
          }
        }

        setSuccess("Perfil atualizado com sucesso!");
        setCapturedPhoto(null);
        setIsEditing(false);
        checkTeacherProfile(firebaseUser.email); // Recarrega os dados salvos
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Ocorreu um erro ao submeter as alterações.");
    } finally {
      setSubmitting(false);
    }
  };

  const handleCancelEdit = () => {
    stopCamera();
    setCapturedPhoto(null);
    if (firebaseUser && firebaseUser.email) {
      checkTeacherProfile(firebaseUser.email);
    }
  };

  if (loading) {
    return (
      <div className="flex-1 w-full flex flex-col items-center justify-center bg-[#F1F5F9] py-20 gap-4">
        <RefreshCw className="w-8 h-8 text-primary animate-spin" />
        <span className="text-sm font-medium text-text-secondary">Carregando dados cadastrais...</span>
      </div>
    );
  }

  return (
    <div className="flex-1 w-full bg-[#F1F5F9] px-4 py-8 md:py-12 flex flex-col items-center">
      
      {/* Container Principal */}
      <div className="w-full max-w-4xl bg-white rounded-2xl border border-[#E2E8F0] shadow-md p-6 md:p-8">
        
        {/* Cabeçalho da Seção */}
        <div className="border-b border-[#E2E8F0] pb-6 mb-8 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-text-primary">
              {!isRegistered ? "Auto-cadastro do Professor" : "Perfil do Professor"}
            </h1>
            <p className="text-sm text-text-secondary mt-1">
              {!isRegistered 
                ? "Conclua seu cadastro institucional obrigatório para liberar acesso ao sistema." 
                : "Consulte e gerencie seus dados cadastrais e foto de perfil."
              }
            </p>
          </div>
          
          {/* Badge de Status Cadastral */}
          <div>
            {!isRegistered ? (
              <span className="bg-amber-100 text-amber-700 px-3.5 py-1.5 rounded-full text-xs font-semibold border border-amber-200">
                Cadastro Pendente
              </span>
            ) : (
              <span className="bg-green-100 text-green-700 px-3.5 py-1.5 rounded-full text-xs font-semibold border border-green-200">
                Perfil Ativo
              </span>
            )}
          </div>
        </div>

        {/* Mensagens de Alerta */}
        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 rounded-xl p-4 flex items-start gap-2.5 text-sm mb-6 animate-in fade-in duration-200">
            <AlertCircle className="w-5 h-5 shrink-0 text-red-500 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        {success && (
          <div className="bg-green-50 border border-green-200 text-green-700 rounded-xl p-4 flex items-start gap-2.5 text-sm mb-6 animate-in fade-in duration-200">
            <CheckCircle2 className="w-5 h-5 shrink-0 text-green-500 mt-0.5" />
            <span>{success}</span>
          </div>
        )}

        {/* Formulário Principal em Grid */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
          
          {/* Lado Esquerdo - Dados Textuais (Col 7) */}
          <div className="md:col-span-7 flex flex-col gap-5">
            <h2 className="text-lg font-semibold text-text-primary border-b border-[#F1F5F9] pb-2 mb-1">
              Dados Pessoais
            </h2>

            {/* Input Nome */}
            <div className="flex flex-col gap-1.5">
              <label className="text-sm font-semibold text-text-primary flex items-center gap-1.5">
                <User className="w-4 h-4 text-text-secondary" />
                Nome Completo
              </label>
              <input
                type="text"
                value={name}
                disabled
                className="w-full bg-[#F8FAFC] border border-[#E2E8F0] text-text-secondary rounded-xl p-3 text-sm cursor-not-allowed"
              />
              <span className="text-[11px] text-text-secondary opacity-75">
                Nome fornecido pela sua conta institucional do Google.
              </span>
            </div>

            {/* Input E-mail */}
            <div className="flex flex-col gap-1.5">
              <label className="text-sm font-semibold text-text-primary flex items-center gap-1.5">
                <Building2 className="w-4 h-4 text-text-secondary" />
                E-mail Institucional
              </label>
              <input
                type="email"
                value={email}
                disabled
                className="w-full bg-[#F8FAFC] border border-[#E2E8F0] text-text-secondary rounded-xl p-3 text-sm cursor-not-allowed"
              />
            </div>

            {/* Input Telefone/Ramal */}
            <div className="flex flex-col gap-1.5">
              <label className="text-sm font-semibold text-text-primary flex items-center gap-1.5">
                <Phone className="w-4 h-4 text-text-secondary" />
                Telefone ou Ramal
              </label>
              <input
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                disabled={!isEditing}
                placeholder="Ex: (67) 3456-7890 ou Ramal 1234"
                className={`w-full border rounded-xl p-3 text-sm transition-all focus:outline-none focus:ring-2 focus:ring-primary/20 ${
                  isEditing 
                    ? "bg-white border-[#CBD5E1] focus:border-primary text-text-primary" 
                    : "bg-[#F8FAFC] border-[#E2E8F0] text-text-secondary cursor-not-allowed"
                }`}
              />
            </div>

            {/* Input Departamento */}
            <div className="flex flex-col gap-1.5">
              <label className="text-sm font-semibold text-text-primary flex items-center gap-1.5">
                <Building2 className="w-4 h-4 text-text-secondary" />
                Departamento ou Área Acadêmica *
              </label>
              <input
                type="text"
                value={department}
                onChange={(e) => setDepartment(e.target.value)}
                disabled={!isEditing}
                required
                placeholder="Ex: DIAT, DEG, Informática, Eletrotécnica"
                className={`w-full border rounded-xl p-3 text-sm transition-all focus:outline-none focus:ring-2 focus:ring-primary/20 ${
                  isEditing 
                    ? "bg-white border-[#CBD5E1] focus:border-primary text-text-primary" 
                    : "bg-[#F8FAFC] border-[#E2E8F0] text-text-secondary cursor-not-allowed"
                }`}
              />
            </div>

            {/* Botões de Ação na base do formulário */}
            <div className="pt-4 border-t border-[#F1F5F9] flex gap-3">
              {isEditing ? (
                <>
                  <button
                    type="button"
                    onClick={() => handleSubmit()}
                    disabled={submitting}
                    className="flex-1 bg-gradient-to-r from-primary to-blue-600 hover:opacity-95 text-white font-semibold py-3 px-4 rounded-xl shadow-sm flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-60"
                  >
                    {submitting ? (
                      <RefreshCw className="w-5 h-5 animate-spin" />
                    ) : (
                      <Save className="w-5 h-5" />
                    )}
                    <span>{!isRegistered ? "Finalizar Cadastro" : "Salvar Alterações"}</span>
                  </button>
                  {isRegistered && (
                    <button
                      type="button"
                      onClick={handleCancelEdit}
                      disabled={submitting}
                      className="border border-[#CBD5E1] hover:bg-[#F8FAFC] text-text-secondary font-semibold py-3 px-4 rounded-xl transition-all cursor-pointer"
                    >
                      Cancelar
                    </button>
                  )}
                </>
              ) : (
                <button
                  type="button"
                  onClick={() => {
                    console.log("Botão Editar Perfil clicado. Ativando modo de edição.");
                    setIsEditing(true);
                  }}
                  className="w-full bg-slate-800 hover:bg-slate-900 text-white font-semibold py-3 px-4 rounded-xl shadow-sm flex items-center justify-center gap-2 transition-all cursor-pointer"
                >
                  <Edit2 className="w-5 h-5" />
                  <span>Editar Perfil</span>
                </button>
              )}
            </div>
          </div>

          {/* Lado Direito - Foto de Perfil e Câmera (Col 5) */}
          <div className="md:col-span-5 flex flex-col items-center">
            <h2 className="w-full text-lg font-semibold text-text-primary border-b border-[#F1F5F9] pb-2 mb-6 text-center md:text-left">
              Foto de Perfil
            </h2>

            {/* Painel da Câmera / Imagem de Perfil */}
            <div className="relative w-full max-w-[280px] aspect-[4/3] bg-[#0F172A] border-2 border-[#CBD5E1] rounded-2xl overflow-hidden shadow-inner flex items-center justify-center">
              
              {/* Moldura de Alinhamento Facial (só aparece se a webcam estiver ativa) */}
              {cameraActive && !capturedPhoto && (
                <div className="absolute w-[120px] h-[160px] border-2 border-dashed border-white/60 rounded-[50%] pointer-events-none z-20 animate-pulse" />
              )}

              {/* Feed de Vídeo Ativo */}
              {cameraActive && !capturedPhoto && (
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  className="w-full h-full object-cover -scale-x-100 z-10"
                />
              )}

              {/* Exibição da Foto Capturada nesta sessão */}
              {capturedPhoto && (
                <div className="relative w-full h-full z-10">
                  <img
                    src={capturedPhoto}
                    alt="Foto Capturada"
                    className="w-full h-full object-cover"
                  />
                </div>
              )}

              {/* Exibição da Foto já cadastrada no Banco (se houver e não estiver tirando nova) */}
              {!cameraActive && !capturedPhoto && photoObjectUrl && (
                <div className="relative w-full h-full">
                  <img
                    src={photoObjectUrl}
                    alt="Foto de Perfil do Professor"
                    className="w-full h-full object-cover"
                  />
                </div>
              )}

              {/* Placeholder quando a câmera está desligada e não há foto */}
              {!cameraActive && !capturedPhoto && !photoObjectUrl && (
                <div className="flex flex-col items-center text-center p-6 gap-2 text-white/50">
                  <Camera className="w-12 h-12 stroke-[1.5]" />
                  <span className="text-xs font-semibold">Câmera Desativada</span>
                </div>
              )}
            </div>

            {/* Controles de Câmera (só aparecem se estiver em modo de edição) */}
            {isEditing && (
              <div className="w-full max-w-[280px] mt-4 flex flex-col gap-2">
                {!cameraActive && !capturedPhoto ? (
                  <button
                    type="button"
                    onClick={startCamera}
                    className="w-full bg-[#F1F5F9] hover:bg-[#E2E8F0] border border-[#CBD5E1] text-text-primary font-semibold py-2 px-4 rounded-xl text-sm flex items-center justify-center gap-2 transition-all cursor-pointer"
                  >
                    <Camera className="w-4 h-4" />
                    <span>{hasServerPhoto ? "Alterar Foto" : "Tirar Foto"}</span>
                  </button>
                ) : cameraActive && !capturedPhoto ? (
                  <button
                    type="button"
                    onClick={capturePhoto}
                    className="w-full bg-primary hover:bg-primary-hover text-white font-semibold py-2.5 px-4 rounded-xl text-sm flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md"
                  >
                    <Camera className="w-4 h-4" />
                    <span>Capturar Imagem</span>
                  </button>
                ) : (
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={handleRecapture}
                      className="flex-1 bg-[#F1F5F9] hover:bg-[#E2E8F0] border border-[#CBD5E1] text-text-primary font-semibold py-2 px-3 rounded-xl text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      <span>Refazer Foto</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setCapturedPhoto(null);
                        stopCamera();
                      }}
                      className="flex-1 bg-red-50 hover:bg-red-100 border border-red-200 text-red-700 font-semibold py-2 px-3 rounded-xl text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                    >
                      <XCircle className="w-3.5 h-3.5" />
                      <span>Descartar</span>
                    </button>
                  </div>
                )}
                <span className="text-[10px] text-text-secondary text-center leading-normal mt-1 block">
                  Posicione seu rosto de forma centralizada e sob boa iluminação para a sua foto de perfil.
                </span>
              </div>
            )}
          </div>
          
        </div>

        {/* Elemento oculto para processar a captura do canvas */}
        <canvas ref={canvasRef} className="hidden" />

      </div>
    </div>
  );
}
