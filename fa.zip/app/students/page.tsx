"use client";

import { useState, useEffect, useRef } from "react";
import { useRouter } from "next/navigation";
import { 
  User, 
  Search, 
  Filter, 
  Plus, 
  Edit, 
  Trash2, 
  Loader2, 
  AlertCircle, 
  Check, 
  BookOpen, 
  Camera, 
  Upload, 
  RefreshCw, 
  X 
} from "lucide-react";
import { onAuthStateChanged, User as FirebaseUser } from "firebase/auth";
import { auth } from "@/lib/firebase";

interface CourseUnit {
  id: number;
  name: string;
  code: string;
  classroom: string | null;
}

interface Student {
  id: number;
  name: string;
  matricula: string;
  created_at: string;
  course_units: CourseUnit[];
}

export default function StudentsManagementPage() {
  const router = useRouter();

  // Estados de Sessão do Firebase
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [checkingAuth, setCheckingAuth] = useState(true);

  // Dados Principais
  const [students, setStudents] = useState<Student[]>([]);
  const [courseUnits, setCourseUnits] = useState<CourseUnit[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  // Estados de Busca e Filtro
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedUcFilter, setSelectedUcFilter] = useState<string>("all");

  // Estados dos Modais
  const [showEditModal, setShowEditModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);

  // Estados do Formulário de Edição
  const [name, setName] = useState("");
  const [matricula, setMatricula] = useState("");
  const [selectedUcIds, setSelectedUcIds] = useState<number[]>([]);
  const [formError, setFormError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  // Estados de Atualização Biométrica (Foto/Câmera)
  const [updateBiometrics, setUpdateBiometrics] = useState(false);
  const [cameraActive, setCameraActive] = useState(false);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);

  const videoRef = useRef<HTMLVideoElement | null>(null);

  // Helper para obter URL da API
  const getApiUrl = () => {
    return process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
  };

  const getApiKey = () => {
    return process.env.NEXT_PUBLIC_API_KEY ?? "";
  };

  // Monitorar Estado de Autenticação
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      if (user) {
        setFirebaseUser(user);
        setCheckingAuth(false);
      } else {
        router.push("/");
      }
    });
    return () => unsubscribe();
  }, [router]);

  // Carregar Estudantes e UCs
  const loadData = async () => {
    if (!firebaseUser) return;
    setLoading(true);
    setError(null);

    const API_URL = getApiUrl();
    const userEmail = firebaseUser.email || "";
    const apiKey = getApiKey();

    try {
      const [studentsRes, coursesRes] = await Promise.all([
        fetch(`${API_URL}/api/students`, {
          headers: {
            "X-User-Email": userEmail,
            "x-api-key": apiKey,
          }
        }),
        fetch(`${API_URL}/api/course_units`, {
          headers: {
            "x-api-key": apiKey,
            "X-User-Email": userEmail,
          }
        })
      ]);

      if (!studentsRes.ok || !coursesRes.ok) {
        throw new Error("Não foi possível obter os dados do servidor.");
      }

      const studentsData = await studentsRes.json();
      const coursesData = await coursesRes.json();

      setStudents(studentsData);
      setCourseUnits(coursesData);
    } catch (err: any) {
      console.error(err);
      setError("Erro de conexão: Verifique se o servidor backend está online.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (firebaseUser) {
      loadData();
    }
  }, [firebaseUser]);

  // Gerenciar Stream da Câmera no Modal
  useEffect(() => {
    if (cameraActive && !capturedImage) {
      navigator.mediaDevices.getUserMedia({ video: { width: 400, height: 300 } })
        .then((s) => {
          setStream(s);
          if (videoRef.current) {
            videoRef.current.srcObject = s;
          }
        })
        .catch((err) => {
          console.error("Erro ao acessar a webcam:", err);
          setFormError("Não foi possível acessar a webcam. Verifique as permissões de câmera.");
          setCameraActive(false);
        });
    } else {
      stopCamera();
    }

    return () => stopCamera();
  }, [cameraActive, capturedImage]);

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
  };

  // Abrir Modal de Edição
  const handleOpenEdit = (student: Student) => {
    setSelectedStudent(student);
    setName(student.name);
    setMatricula(student.matricula);
    setSelectedUcIds(student.course_units.map(cu => cu.id));
    
    // Reset de biometria
    setUpdateBiometrics(false);
    setCameraActive(false);
    setCapturedImage(null);
    setSelectedFile(null);
    setFormError(null);
    
    setShowEditModal(true);
  };

  // Abrir Modal de Confirmação de Exclusão Lógica
  const handleOpenDelete = (student: Student) => {
    setSelectedStudent(student);
    setShowDeleteModal(true);
  };

  // Capturar Foto da Webcam
  const handleCapture = () => {
    if (videoRef.current) {
      const canvas = document.createElement("canvas");
      canvas.width = 400;
      canvas.height = 300;
      const ctx = canvas.getContext("2d");
      if (ctx) {
        ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL("image/jpeg");
        setCapturedImage(dataUrl);
        setCameraActive(false);
        stopCamera();
      }
    }
  };

  // Upload de Arquivo
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setSelectedFile(file);
      
      const reader = new FileReader();
      reader.onload = () => {
        setCapturedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // Alternar Seleção de UC no Checklist
  const handleUcToggle = (ucId: number) => {
    if (selectedUcIds.includes(ucId)) {
      setSelectedUcIds(selectedUcIds.filter(id => id !== ucId));
    } else {
      setSelectedUcIds([...selectedUcIds, ucId]);
    }
  };

  // Enviar Atualizações (PUT)
  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (!name.trim()) {
      setFormError("O nome do estudante é obrigatório.");
      return;
    }
    if (!matricula.trim()) {
      setFormError("A matrícula é obrigatória.");
      return;
    }
    if (selectedUcIds.length === 0) {
      setFormError("O estudante deve estar matriculado em pelo menos uma UC.");
      return;
    }

    setSubmitting(true);
    const API_URL = getApiUrl();
    const userEmail = firebaseUser?.email || "";
    const apiKey = getApiKey();

    try {
      const formData = new FormData();
      formData.append("name", name.trim());
      formData.append("matricula", matricula.trim());
      formData.append("course_unit_ids", selectedUcIds.join(","));

      if (updateBiometrics) {
        if (capturedImage) {
          // Converter dataURL em Blob/File
          const res = await fetch(capturedImage);
          const blob = await res.blob();
          formData.append("photo", blob, "photo.jpg");
        } else {
          setFormError("Por favor, tire uma foto ou selecione um arquivo de imagem para atualizar a biometria.");
          setSubmitting(false);
          return;
        }
      }

      const response = await fetch(`${API_URL}/api/students/${selectedStudent?.id}`, {
        method: "PUT",
        headers: {
          "x-api-key": apiKey,
          "X-User-Email": userEmail,
        },
        body: formData
      });

      if (response.ok) {
        setSuccess("Cadastro do estudante atualizado com sucesso!");
        setShowEditModal(false);
        loadData();
        
        setTimeout(() => {
          setSuccess(null);
        }, 4000);
      } else {
        const errData = await response.json();
        setFormError(errData.detail || "Erro ao atualizar estudante.");
      }
    } catch (err: any) {
      console.error(err);
      setFormError("Erro de comunicação com o servidor.");
    } finally {
      setSubmitting(false);
    }
  };

  // Desativar logicamente o estudante (DELETE)
  const handleDelete = async () => {
    if (!selectedStudent) return;
    setSubmitting(true);
    
    const API_URL = getApiUrl();
    const userEmail = firebaseUser?.email || "";
    const apiKey = getApiKey();

    try {
      const response = await fetch(`${API_URL}/api/students/${selectedStudent.id}`, {
        method: "DELETE",
        headers: {
          "x-api-key": apiKey,
          "X-User-Email": userEmail,
        }
      });

      if (response.ok) {
        setSuccess(`Estudante "${selectedStudent.name}" desativado com sucesso.`);
        setShowDeleteModal(false);
        setSelectedStudent(null);
        loadData();

        setTimeout(() => {
          setSuccess(null);
        }, 4000);
      } else {
        const errData = await response.json();
        alert(errData.detail || "Erro ao desativar estudante.");
      }
    } catch (err: any) {
      console.error(err);
      alert("Erro ao tentar desativar estudante.");
    } finally {
      setSubmitting(false);
    }
  };

  // Filtragem no Frontend
  const filteredStudents = students.filter(student => {
    const matchesSearch = 
      student.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      student.matricula.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesUc = 
      selectedUcFilter === "all" ||
      student.course_units.some(cu => cu.id === parseInt(selectedUcFilter));

    return matchesSearch && matchesUc;
  });

  if (checkingAuth) {
    return (
      <div className="flex-1 w-full flex flex-col items-center justify-center bg-[#F1F5F9] py-20 gap-4">
        <Loader2 className="w-8 h-8 text-primary animate-spin" />
        <span className="text-sm font-medium text-text-secondary">Verificando sessão...</span>
      </div>
    );
  }

  return (
    <div className="flex-1 bg-[#F8FAFC] py-8 px-4 md:px-8">
      <div className="max-w-6xl mx-auto">
        
        {/* Cabeçalho */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-2xl font-bold text-text-primary flex items-center gap-2">
              <User className="w-7 h-7 text-primary" />
              Gerenciar Estudantes
            </h1>
            <p className="text-sm text-text-secondary mt-1">
              Liste, busque, edite matrículas e desative estudantes cadastrados no sistema.
            </p>
          </div>
          <button
            onClick={() => router.push("/students/register")}
            className="inline-flex items-center gap-2 bg-primary hover:bg-indigo-700 text-white font-bold py-2.5 px-5 rounded-xl text-sm transition-all shadow-md cursor-pointer hover:translate-y-[-1px]"
          >
            <Plus className="w-4 h-4" />
            Novo Estudante
          </button>
        </div>

        {/* Notificação Temporária de Sucesso */}
        {success && (
          <div className="bg-green-50 border border-green-200 text-green-700 rounded-xl p-4 flex items-start gap-2.5 text-sm mb-6 animate-in fade-in duration-200">
            <Check className="w-5 h-5 shrink-0 text-green-500 mt-0.5" />
            <span>{success}</span>
          </div>
        )}

        {/* Painel de Filtros */}
        <div className="bg-white border border-[#E2E8F0] rounded-2xl p-4 shadow-sm flex flex-col md:flex-row gap-4 mb-6">
          <div className="flex-1 relative">
            <Search className="w-4 h-4 text-text-secondary absolute left-3.5 top-3.5" />
            <input
              type="text"
              placeholder="Buscar estudante por nome ou matrícula..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-[#CBD5E1] text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all text-text-primary"
            />
          </div>
          <div className="flex items-center gap-2 min-w-[200px]">
            <Filter className="w-4 h-4 text-text-secondary" />
            <select
              value={selectedUcFilter}
              onChange={(e) => setSelectedUcFilter(e.target.value)}
              className="w-full bg-white border border-[#CBD5E1] rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all text-text-primary font-medium"
            >
              <option value="all">Todas as Disciplinas</option>
              {courseUnits.map(cu => (
                <option key={cu.id} value={cu.id}>{cu.name}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Estados de Carregamento e Vazio */}
        {loading ? (
          <div className="py-20 flex flex-col items-center justify-center gap-3">
            <Loader2 className="w-8 h-8 text-primary animate-spin" />
            <span className="text-sm text-text-secondary font-medium">Carregando estudantes...</span>
          </div>
        ) : error ? (
          <div className="bg-red-50 border border-red-200 text-red-700 rounded-xl p-6 flex flex-col items-center gap-3 text-center mb-6">
            <AlertCircle className="w-8 h-8 text-red-500" />
            <span className="font-semibold">{error}</span>
            <button 
              onClick={loadData}
              className="mt-2 text-xs font-bold text-primary hover:underline"
            >
              Tentar Novamente
            </button>
          </div>
        ) : filteredStudents.length === 0 ? (
          <div className="border-2 border-dashed border-[#E2E8F0] rounded-2xl p-12 text-center flex flex-col items-center justify-center gap-4 bg-[#F8FAFC]/50">
            <div className="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center text-slate-400">
              <User className="w-8 h-8" />
            </div>
            <div>
              <h3 className="font-bold text-text-primary text-base">Nenhum estudante encontrado</h3>
              <p className="text-sm text-text-secondary mt-1 max-w-sm mx-auto">
                {searchQuery || selectedUcFilter !== "all" 
                  ? "Tente alterar os termos de busca ou filtros selecionados."
                  : "Nenhum estudante ativo cadastrado no sistema."}
              </p>
            </div>
          </div>
        ) : (
          /* Tabela de Estudantes */
          <div className="overflow-hidden border border-[#E2E8F0] rounded-2xl shadow-sm bg-white">
            <div className="overflow-x-auto">
              <table className="w-full border-collapse text-left text-sm">
                <thead>
                  <tr className="bg-[#F8FAFC] border-b border-[#E2E8F0]">
                    <th className="px-6 py-4 font-bold text-text-primary">Estudante</th>
                    <th className="px-6 py-4 font-bold text-text-primary">Matrícula</th>
                    <th className="px-6 py-4 font-bold text-text-primary">Disciplinas Vinculadas</th>
                    <th className="px-6 py-4 font-bold text-text-primary text-right">Ações</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#F1F5F9]">
                  {filteredStudents.map((student) => {
                    const initials = student.name
                      .split(" ")
                      .filter(n => n.length > 0)
                      .slice(0, 2)
                      .map(n => n[0].toUpperCase())
                      .join("");

                    return (
                      <tr key={student.id} className="hover:bg-[#F8FAFC]/50 transition-colors">
                        <td className="px-6 py-4 flex items-center gap-3">
                          {/* Avatar Circular */}
                          <div className="w-9 h-9 rounded-full bg-gradient-to-br from-indigo-500 to-blue-600 flex items-center justify-center text-white text-xs font-bold shadow-sm shrink-0">
                            {initials}
                          </div>
                          <span className="font-semibold text-text-primary">{student.name}</span>
                        </td>
                        <td className="px-6 py-4">
                          <span className="font-mono text-xs font-semibold bg-[#F1F5F9] border border-[#E2E8F0] px-2 py-0.5 rounded text-text-secondary">
                            {student.matricula}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex flex-wrap gap-1.5 max-w-[400px]">
                            {student.course_units.length > 0 ? (
                              student.course_units.map(cu => (
                                <span 
                                  key={cu.id}
                                  className="text-[10px] font-bold bg-indigo-50 border border-indigo-100 text-primary px-2 py-0.5 rounded-full"
                                >
                                  {cu.name}
                                </span>
                              ))
                            ) : (
                              <span className="text-xs text-text-secondary italic">Sem UCs</span>
                            )}
                          </div>
                        </td>
                        <td className="px-6 py-4 text-right">
                          <div className="inline-flex gap-2">
                            <button
                              onClick={() => handleOpenEdit(student)}
                              className="p-1.5 hover:bg-slate-100 rounded-lg text-text-secondary hover:text-primary transition-all cursor-pointer"
                              title="Editar Estudante"
                            >
                              <Edit className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => handleOpenDelete(student)}
                              className="p-1.5 hover:bg-red-50 rounded-lg text-text-secondary hover:text-red-600 transition-all cursor-pointer"
                              title="Desativar Estudante"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ================= MODAL DE EDIÇÃO DE ESTUDANTE ================= */}
        {showEditModal && (
          <div 
            className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4 overflow-y-auto animate-in fade-in duration-200"
            onClick={() => {
              if (!submitting) {
                setShowEditModal(false);
                setSelectedStudent(null);
              }
            }}
          >
            <div 
              className="bg-white rounded-3xl border border-[#E2E8F0] p-6 md:p-8 w-full max-w-lg shadow-2xl relative my-8 animate-in zoom-in-95 duration-200"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Botão de Fechar */}
              <button
                type="button"
                disabled={submitting}
                onClick={() => {
                  setShowEditModal(false);
                  setSelectedStudent(null);
                }}
                className="absolute right-4 top-4 p-1.5 text-text-secondary hover:bg-slate-100 rounded-xl transition-all cursor-pointer disabled:opacity-50"
              >
                <X className="w-5 h-5" />
              </button>

              <h2 className="text-xl font-bold text-text-primary mb-1">
                Editar Estudante
              </h2>
              <p className="text-xs text-text-secondary mb-6">
                Modifique os dados de matrícula, adicione novas disciplinas ou atualize a foto biométrica.
              </p>

              {formError && (
                <div className="bg-red-50 border border-red-200 text-red-700 rounded-xl p-3.5 flex items-start gap-2 text-xs mb-5 animate-in fade-in duration-200">
                  <AlertCircle className="w-4 h-4 shrink-0 text-red-500 mt-0.5" />
                  <span>{formError}</span>
                </div>
              )}

              <form onSubmit={handleUpdate} className="flex flex-col gap-4">
                {/* Nome */}
                <div className="flex flex-col gap-1.5">
                  <label htmlFor="student-name" className="text-xs font-bold text-text-primary">
                    Nome Completo
                  </label>
                  <input
                    type="text"
                    id="student-name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    disabled={submitting}
                    placeholder="Nome completo do estudante"
                    className="w-full px-4 py-2.5 rounded-xl border border-[#CBD5E1] text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all text-text-primary disabled:bg-[#F1F5F9]"
                  />
                </div>

                {/* Matrícula */}
                <div className="flex flex-col gap-1.5">
                  <label htmlFor="student-matricula" className="text-xs font-bold text-text-primary">
                    Matrícula
                  </label>
                  <input
                    type="text"
                    id="student-matricula"
                    value={matricula}
                    onChange={(e) => setMatricula(e.target.value)}
                    disabled={submitting}
                    placeholder="Número de matrícula do estudante"
                    className="w-full px-4 py-2.5 rounded-xl border border-[#CBD5E1] text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all text-text-primary disabled:bg-[#F1F5F9]"
                  />
                </div>

                {/* Checklist de UCs */}
                <div className="flex flex-col gap-2">
                  <label className="text-xs font-bold text-text-primary">
                    Matrícula em Unidades Curriculares (UCs)
                  </label>
                  <div className="max-h-[140px] overflow-y-auto border border-[#E2E8F0] rounded-xl p-3 flex flex-col gap-2">
                    {courseUnits.map(cu => (
                      <label 
                        key={cu.id} 
                        className="flex items-center gap-2 text-xs font-semibold text-text-primary hover:bg-slate-50 p-1.5 rounded-lg transition-colors cursor-pointer"
                      >
                        <input
                          type="checkbox"
                          checked={selectedUcIds.includes(cu.id)}
                          onChange={() => handleUcToggle(cu.id)}
                          disabled={submitting}
                          className="w-4 h-4 text-primary focus:ring-primary border-[#CBD5E1] rounded transition-all"
                        />
                        <span>{cu.name} ({cu.code})</span>
                      </label>
                    ))}
                  </div>
                </div>

                {/* Seção Biométrica */}
                <div className="border-t border-[#F1F5F9] pt-4 mt-2">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xs font-bold text-text-primary">Atualizar Foto/Biometria Facial?</span>
                    <button
                      type="button"
                      disabled={submitting}
                      onClick={() => {
                        setUpdateBiometrics(!updateBiometrics);
                        setCameraActive(false);
                        setCapturedImage(null);
                        setSelectedFile(null);
                      }}
                      className={`text-xs font-bold px-3 py-1 rounded-full border transition-all cursor-pointer ${
                        updateBiometrics 
                          ? "bg-indigo-50 border-indigo-200 text-primary" 
                          : "bg-white border-[#CBD5E1] text-text-secondary hover:bg-slate-50"
                      }`}
                    >
                      {updateBiometrics ? "Atualizar" : "Manter Atual"}
                    </button>
                  </div>

                  {updateBiometrics && (
                    <div className="bg-[#F8FAFC] border border-[#E2E8F0] rounded-2xl p-4 flex flex-col gap-4">
                      {/* Câmera / Upload */}
                      {!capturedImage && !cameraActive && (
                        <div className="flex gap-3 justify-center">
                          <button
                            type="button"
                            onClick={() => setCameraActive(true)}
                            className="inline-flex items-center gap-1.5 bg-white border border-[#CBD5E1] text-text-primary hover:bg-slate-50 font-semibold py-2 px-4 rounded-xl text-xs transition-all shadow-sm cursor-pointer"
                          >
                            <Camera className="w-4 h-4 text-text-secondary" />
                            Usar Webcam
                          </button>
                          <label className="inline-flex items-center gap-1.5 bg-white border border-[#CBD5E1] text-text-primary hover:bg-slate-50 font-semibold py-2 px-4 rounded-xl text-xs transition-all shadow-sm cursor-pointer">
                            <Upload className="w-4 h-4 text-text-secondary" />
                            Upload de Arquivo
                            <input 
                              type="file" 
                              accept="image/*" 
                              className="hidden" 
                              onChange={handleFileChange}
                            />
                          </label>
                        </div>
                      )}

                      {/* Webcam Ativa */}
                      {cameraActive && !capturedImage && (
                        <div className="flex flex-col items-center gap-3">
                          <div className="w-[320px] h-[240px] rounded-2xl overflow-hidden bg-black relative border-2 border-primary shadow-inner">
                            <video 
                              ref={videoRef}
                              autoPlay 
                              playsInline 
                              className="w-full h-full object-cover scale-x-[-1]"
                            />
                          </div>
                          <div className="flex gap-2">
                            <button
                              type="button"
                              onClick={handleCapture}
                              className="bg-primary hover:bg-indigo-700 text-white font-bold py-1.5 px-4 rounded-xl text-xs transition-all cursor-pointer shadow-md"
                            >
                              Tirar Foto
                            </button>
                            <button
                              type="button"
                              onClick={() => setCameraActive(false)}
                              className="bg-white border border-[#CBD5E1] text-text-primary hover:bg-slate-50 font-semibold py-1.5 px-4 rounded-xl text-xs transition-all cursor-pointer"
                            >
                              Cancelar
                            </button>
                          </div>
                        </div>
                      )}

                      {/* Visualização de Foto Capturada */}
                      {capturedImage && (
                        <div className="flex flex-col items-center gap-3">
                          <div className="w-[200px] h-[150px] rounded-2xl overflow-hidden bg-slate-100 border border-[#E2E8F0] shadow-sm relative">
                            <img 
                              src={capturedImage} 
                              alt="Biometria capturada" 
                              className="w-full h-full object-cover"
                            />
                            <button
                              type="button"
                              onClick={() => {
                                setCapturedImage(null);
                                setSelectedFile(null);
                                setCameraActive(false);
                              }}
                              className="absolute top-2 right-2 p-1 bg-black/65 hover:bg-black/80 rounded-full text-white transition-all cursor-pointer"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          </div>
                          <span className="text-[10px] text-text-secondary italic">Rosto pronto para upload biométrico</span>
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* Botões de Ação do Form */}
                <div className="flex gap-3 border-t border-[#F1F5F9] pt-5 mt-2">
                  <button
                    type="button"
                    disabled={submitting}
                    onClick={() => {
                      setShowEditModal(false);
                      setSelectedStudent(null);
                    }}
                    className="flex-1 border border-[#CBD5E1] hover:bg-[#F8FAFC] text-text-primary font-semibold py-2.5 rounded-xl text-sm transition-all cursor-pointer disabled:opacity-50"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    disabled={submitting}
                    className="flex-1 bg-primary hover:bg-indigo-700 text-white font-bold py-2.5 rounded-xl text-sm transition-all shadow-md flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-60"
                  >
                    {submitting && <Loader2 className="w-4 h-4 animate-spin" />}
                    Salvar Alterações
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* ================= MODAL DE CONFIRMAÇÃO DE EXCLUSÃO (DESATIVAÇÃO LÓGICA) ================= */}
        {showDeleteModal && (
          <div 
            className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-in fade-in duration-200"
            onClick={() => {
              if (!submitting) {
                setShowDeleteModal(false);
                setSelectedStudent(null);
              }
            }}
          >
            <div 
              className="bg-white rounded-3xl border border-[#E2E8F0] p-6 md:p-8 w-full max-w-sm shadow-2xl relative text-center animate-in zoom-in-95 duration-200"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="w-12 h-12 rounded-full bg-red-50 text-red-600 flex items-center justify-center mx-auto mb-4">
                <Trash2 className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-text-primary">
                Desativar Estudante?
              </h3>
              <p className="text-sm text-text-secondary mt-2">
                Tem certeza de que deseja desativar o estudante <span className="font-bold text-text-primary">"{selectedStudent?.name}"</span>?
              </p>
              
              <div className="bg-amber-50 border border-amber-200 text-amber-800 rounded-xl p-3.5 text-xs text-left mt-4 font-medium flex items-start gap-2.5">
                <AlertCircle className="w-4 h-4 shrink-0 text-amber-600 mt-0.5" />
                <span>
                  <strong>Atenção:</strong> O estudante será inativado e não poderá mais marcar presença no totem. No entanto, o seu histórico passado de frequências será totalmente preservado no PostgreSQL.
                </span>
              </div>

              {/* Botões do Modal */}
              <div className="flex gap-3 mt-6">
                <button
                  type="button"
                  disabled={submitting}
                  onClick={() => {
                    setShowDeleteModal(false);
                    setSelectedStudent(null);
                  }}
                  className="flex-1 border border-[#CBD5E1] hover:bg-[#F8FAFC] text-text-primary font-semibold py-2.5 rounded-xl text-sm transition-all cursor-pointer disabled:opacity-50"
                >
                  Cancelar
                </button>
                <button
                  onClick={handleDelete}
                  disabled={submitting}
                  className="flex-1 bg-red-600 hover:bg-red-700 text-white font-semibold py-2.5 rounded-xl text-sm transition-all shadow-md flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-60"
                >
                  {submitting && <Loader2 className="w-4 h-4 animate-spin" />}
                  Desativar
                </button>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
