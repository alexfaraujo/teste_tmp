import type { NextConfig } from "next";

const nextConfig: any = {
  images: {
    remotePatterns: [
      {
        protocol: "http",
        hostname: "**",
      },
      {
        protocol: "https",
        hostname: "**",
      },
    ],
  },
  // Preservando a sua configuração manual para acesso local no celular
  allowedDevOrigins: ['192.168.1.21','chamadaback.ifms.pro.br'],
};

export default nextConfig as NextConfig;
