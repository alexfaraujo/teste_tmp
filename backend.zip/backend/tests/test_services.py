import math
from datetime import datetime, timezone, timedelta
from uuid import uuid4
import pytest

from src.models import Sonda, LogSonda
from src.services import _build_sonda_response, LogService


def test_build_sonda_response_no_logs():
    """Valida o status 'sem_dados' quando a sonda não possui medições registradas."""
    sonda = Sonda(
        id=uuid4(),
        usuario_id="user_123",
        nome_identificador="Sonda Teste 01",
        api_key_hash="hash123",
        api_key_prefix="sb_live_1234",
        irrigacao_diurna=False,
        indice_irrigar=35.0,
        intervalo_envio_segundos=600,
        ativo=True,
    )
    sonda.logs = []
    
    res = _build_sonda_response(sonda)
    assert res.status_conectividade == "sem_dados"
    assert res.alerta_bateria is False


def test_build_sonda_response_online():
    """Valida o status 'online' quando o último log está dentro da janela de tolerância."""
    now = datetime.now(timezone.utc)
    sonda = Sonda(
        id=uuid4(),
        usuario_id="user_123",
        nome_identificador="Sonda Teste Online",
        api_key_hash="hash123",
        api_key_prefix="sb_live_1234",
        irrigacao_diurna=False,
        indice_irrigar=35.0,
        intervalo_envio_segundos=600,  # tolerância = 900s (15 min)
        ativo=True,
    )
    log_recente = LogSonda(
        id=1,
        sonda_id=sonda.id,
        nivel_bateria=85.0,
        temperatura=25.0,
        umidade_bruta=500,
        indice_umidade=40.0,
        received_at=now - timedelta(seconds=300),  # Envio há 5 minutos
    )
    sonda.logs = [log_recente]

    res = _build_sonda_response(sonda)
    assert res.status_conectividade == "online"
    assert res.alerta_bateria is False


def test_build_sonda_response_offline_and_low_battery():
    """Valida o status 'offline' e alerta de bateria quando a bateria está abaixo de 20%."""
    now = datetime.now(timezone.utc)
    sonda = Sonda(
        id=uuid4(),
        usuario_id="user_123",
        nome_identificador="Sonda Alerta",
        api_key_hash="hash123",
        api_key_prefix="sb_live_1234",
        irrigacao_diurna=False,
        indice_irrigar=35.0,
        intervalo_envio_segundos=600,
        ativo=True,
    )
    log_antigo_fraco = LogSonda(
        id=1,
        sonda_id=sonda.id,
        nivel_bateria=12.5,  # Alerta de bateria < 20%
        temperatura=30.0,
        umidade_bruta=300,
        indice_umidade=15.0,
        received_at=now - timedelta(seconds=1200),  # > 900s -> Offline
    )
    sonda.logs = [log_antigo_fraco]

    res = _build_sonda_response(sonda)
    assert res.status_conectividade == "offline"
    assert res.alerta_bateria is True


def test_build_sonda_response_with_explicit_ultimo_log_and_hardware_mac():
    """Valida a resolução O(1) passando ultimo_log diretamente sem carregar sonda.logs (Opções A2 e C1)."""
    now = datetime.now(timezone.utc)
    sonda = Sonda(
        id=uuid4(),
        usuario_id="user_123",
        nome_identificador="Sonda Campus IFMS 01",
        codigo_hardware="164:207:18:255:59:",
        api_key_hash="hash123",
        api_key_prefix="sb_live_",
        irrigacao_diurna=False,
        indice_irrigar=35.0,
        intervalo_envio_segundos=600,
        ativo=True,
    )
    ultimo_log = LogSonda(
        id=15700,
        sonda_id=sonda.id,
        nivel_bateria=0.0,
        temperatura=0.0,
        umidade_bruta=772,
        indice_umidade=116.61,
        received_at=now - timedelta(seconds=120),
    )

    res = _build_sonda_response(sonda, ultimo_log=ultimo_log)
    assert res.codigo_hardware == "164:207:18:255:59:"
    assert res.status_conectividade == "online"
    assert res.alerta_bateria is True


def test_dataset_csv_parsing_and_imputation_b1():
    """Valida a preparação integral das 15.698 linhas do CSV aplicando as regras A2 e B1."""
    from src.scripts.import_dataset import DEFAULT_CSV_PATH, parse_and_prepare_csv_rows

    uid_1 = uuid4()
    uid_2 = uuid4()
    sonda_map = {
        "164:207:18:255:59:": uid_1,
        "72:63:218:96:82:": uid_2,
    }

    rows = parse_and_prepare_csv_rows(DEFAULT_CSV_PATH, sonda_map)
    assert len(rows) == 15698

    # Verifica que todas as datas e índices foram preenchidos sem None
    assert all(r["received_at"] is not None and r["received_at"].tzinfo is not None for r in rows)
    assert all(r["indice_umidade"] is not None for r in rows)

    by_id = {r["id"]: r for r in rows}
    # Imputação exata das 2 linhas sem indiceUmidade (id=2379 -> 81.36 e id=3264 -> 75.59)
    assert by_id[2379]["indice_umidade"] == 81.36
    assert by_id[3264]["indice_umidade"] == 75.59

    # Preservação dos valores originais fora de [0, 100] (Opção B1)
    assert by_id[4]["indice_umidade"] == 116.61
    assert by_id[412]["indice_umidade"] == -144.07

    # Ordem cronológica preservada nas 8 linhas iniciais sem dataHora (id=3 a id=10 < id=11)
    assert by_id[3]["received_at"] < by_id[10]["received_at"] < by_id[11]["received_at"]
