import hashlib
from urllib.parse import quote_plus
import pytest

from src.core.config import Settings
from src.core.security import generate_api_key, hash_api_key


def test_generate_api_key_format():
    """Testa a geração de API Keys brutas e seus hashes SHA-256."""
    raw_key, hashed_key = generate_api_key(prefix="sb_live_")

    # Verifica que a chave pura começa com o prefixo
    assert raw_key.startswith("sb_live_")
    assert len(raw_key) > 20

    # Verifica que o hash possui 64 caracteres hexadecimais
    assert len(hashed_key) == 64
    assert hash_api_key(raw_key) == hashed_key


def test_hash_api_key_consistency():
    """Verifica que o hashing de uma chave é estritamente determinístico."""
    key = "sb_live_1234567890abcdef"
    expected = hashlib.sha256(key.encode("utf-8")).hexdigest()
    assert hash_api_key(key) == expected


def test_special_character_password_encoding():
    """Valida se senhas com caracteres especiais (@, #, $) são tratadas via quote_plus na montagem da URL."""
    custom_settings = Settings(
        postgres_user="user_teste",
        postgres_password="minha@senha#123",
        postgres_server="127.0.0.1",
        postgres_port=5432,
        postgres_db="meu_db",
        database_url="",
    )
    # O caracter @ deve ser convertido em %40 e o # em %23 na URL
    assert "user_teste:minha%40senha%23123@127.0.0.1:5432/meu_db" in custom_settings.database_url
