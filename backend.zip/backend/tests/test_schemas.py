import pytest
from datetime import datetime, timezone
from uuid import uuid4
from pydantic import ValidationError

from src.schemas import (
    TelemetryCreateSchema,
    ProbeConfigSchema,
    SondaCreateSchema,
    PaginationMetadataSchema,
    DashboardSummarySchema,
    UsuarioUpdateSchema,
)


def test_telemetry_create_schema_valid():
    """Valida que o schema de criação de telemetria aceita dados corretos em snake_case."""
    data = {
        "nivel_bateria": 85.5,
        "temperatura": 24.3,
        "umidade_bruta": 512,
        "indice_umidade": 42.0,
    }
    schema = TelemetryCreateSchema(**data)
    assert schema.nivel_bateria == 85.5
    assert schema.temperatura == 24.3
    assert schema.umidade_bruta == 512
    assert schema.indice_umidade == 42.0


def test_telemetry_create_schema_invalid_battery():
    """Valida que o nível de bateria recusa valores fora do intervalo [0, 100]."""
    data = {
        "nivel_bateria": 150.0,  # Inválido
        "temperatura": 25.0,
        "umidade_bruta": 400,
        "indice_umidade": 30.0,
    }
    with pytest.raises(ValidationError):
        TelemetryCreateSchema(**data)


def test_probe_config_schema_valid():
    """Valida o DTO de configuração operacional da sonda."""
    config = ProbeConfigSchema(
        irrigacao_diurna=True,
        indice_irrigar=35.0,
        intervalo_envio_segundos=600,
    )
    assert config.irrigacao_diurna is True
    assert config.indice_irrigar == 35.0
    assert config.intervalo_envio_segundos == 600


def test_sonda_create_schema_default_values():
    """Valida os valores default para cadastro de sonda."""
    sonda = SondaCreateSchema(nome_identificador="Sonda Pivot 01")
    assert sonda.nome_identificador == "Sonda Pivot 01"
    assert sonda.codigo_hardware is None
    assert sonda.irrigacao_diurna is False
    assert sonda.indice_irrigar == 35.0
    assert sonda.intervalo_envio_segundos == 600


def test_sonda_create_schema_with_codigo_hardware():
    """Valida o cadastro de sonda informando o endereço MAC / código físico do hardware (Opção A2)."""
    sonda = SondaCreateSchema(
        nome_identificador="Sonda Campus IFMS 01",
        codigo_hardware="164:207:18:255:59:",
    )
    assert sonda.codigo_hardware == "164:207:18:255:59:"


def test_telemetry_create_schema_real_world_humidity_bounds():
    """Valida que valores reais de campo de indice_umidade (< 0 ou > 100) são aceitos (Opção B1)."""
    neg_schema = TelemetryCreateSchema(
        nivel_bateria=0.0,
        temperatura=0.0,
        umidade_bruta=3,
        indice_umidade=-144.07,
    )
    high_schema = TelemetryCreateSchema(
        nivel_bateria=0.0,
        temperatura=0.0,
        umidade_bruta=772,
        indice_umidade=116.61,
    )
    assert neg_schema.indice_umidade == -144.07
    assert high_schema.indice_umidade == 116.61


def test_usuario_update_schema_validation():
    """Valida o comprimento mínimo do nome do produtor."""
    with pytest.raises(ValidationError):
        UsuarioUpdateSchema(nome="A")  # Mínimo 2 caracteres
