import pytest
from fastapi.testclient import TestClient

from src.core.config import settings
from src.main import app

client = TestClient(app)


def test_healthcheck_root():
    """Valida o endpoint de healthcheck da raiz '/'."""
    response = client.get("/")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "online"
    assert data["docs"] == "/docs"


def test_probe_config_unauthorized():
    """Valida que a rota IoT sem X-API-Key barra o acesso com status de não autorizado."""
    response = client.get("/api/v1/probe/config")
    assert response.status_code in [401, 403]


def test_dashboard_summary_unauthorized():
    """Valida que a rota do dashboard sem token Bearer barra o acesso."""
    response = client.get("/api/v1/dashboard/summary")
    assert response.status_code in [401, 403]


def test_web_route_authorized_with_app_api_key():
    """Valida que a rota web /api/v1/users/me autoriza o acesso ao passar a APP_API_KEY do .env."""
    headers = {"Authorization": f"Bearer {settings.app_api_key}"}
    response = client.get("/api/v1/users/me", headers=headers)
    assert response.status_code == 200
    data = response.json()
    assert data["email"] == "produtor.teste@exemplo.com"
    assert data["perfil_completo"] is True
