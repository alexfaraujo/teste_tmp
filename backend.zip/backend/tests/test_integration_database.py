from datetime import datetime, timezone, timedelta
from uuid import uuid4
import pytest
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker

from src.core.config import settings
from src.core.security import hash_api_key
from src.models import Usuario, Sonda, LogSonda
from src.schemas import (
    SondaCreateSchema,
    SondaUpdateConfigSchema,
    TelemetryCreateSchema,
    UsuarioUpdateSchema,
)
from src.services import (
    DashboardService,
    IoTService,
    LogService,
    SondaService,
    UsuarioService,
)


@pytest.mark.asyncio
async def test_full_lifecycle_postgres_real():
    """
    Testa o ciclo de vida completo da aplicação de irrigação contra o banco PostgreSQL local real:
    1. Usuário: auto-provisionamento, consulta de perfil e onboarding (perfil_completo = True).
    2. Sonda: criação de sonda, validação de hash SHA-256 e exibição única de API Key.
    3. Telemetria IoT: recepção de medições, gravação no PostgreSQL e piggybacking de limiares.
    4. Conectividade e Alerta: verificação dinâmica de status 'online', 'offline' e alerta de bateria < 20%.
    5. Dashboard & Paginação: métricas consolidadas e paginação de histórico de logs sob demanda.
    6. Soft Delete: remoção lógica da sonda (deleted_at IS NOT NULL) sem perda física de logs.
    """
    engine = create_async_engine(settings.database_url, echo=False)
    async_session = async_sessionmaker(engine, expire_on_commit=False)

    async with async_session() as session:
        # 1. Usuário & Onboarding
        test_uid = f"user_pytest_{uuid4().hex[:10]}"
        user = Usuario(
            id=test_uid,
            email=f"{test_uid}@fazenda.com",
            nome="Produtor Teste Pytest",
            perfil_completo=False,
        )
        session.add(user)
        await session.commit()

        # Atualizar onboarding
        updated_user = await UsuarioService.update_user_profile(
            session, user, UsuarioUpdateSchema(nome="João da Silva Pytest")
        )
        assert updated_user.perfil_completo is True
        assert updated_user.nome == "João da Silva Pytest"

        # 2. Cadastro de Sonda
        hw_mac = f"AA:BB:CC:{uuid4().hex[:6]}:"
        sonda_create_dto = SondaCreateSchema(
            nome_identificador="Sonda Teste PostgreSQL Real 01",
            codigo_hardware=hw_mac,
            irrigacao_diurna=False,
            indice_irrigar=35.0,
            intervalo_envio_segundos=600,
        )
        sonda_res = await SondaService.create_sonda(session, user.id, sonda_create_dto)
        assert sonda_res.api_key.startswith("sb_live_")
        assert sonda_res.codigo_hardware == hw_mac
        assert sonda_res.status_conectividade == "sem_dados"

        sonda_id = sonda_res.id

        # 3. Processamento de Telemetria IoT com Piggybacking
        sonda_orm = await SondaService.get_sonda_by_id(session, user.id, sonda_id)
        telemetry_dto = TelemetryCreateSchema(
            nivel_bateria=15.0,  # Bateria fraca (< 20%) para disparar alerta
            temperatura=28.4,
            umidade_bruta=450,
            indice_umidade=40.0,
        )
        telemetry_res = await IoTService.process_telemetry(session, sonda_orm, telemetry_dto)
        assert telemetry_res.status == "success"
        assert telemetry_res.config.irrigacao_diurna is False
        assert telemetry_res.config.indice_irrigar == 35.0

        # 4. Verificação de Conectividade Online e Alerta de Bateria
        sonda_reconsultada = await SondaService.get_sonda_by_id(session, user.id, sonda_id)
        assert sonda_reconsultada.status_conectividade == "online"
        assert sonda_reconsultada.alerta_bateria is True

        # 5. Dashboard Summary
        summary = await DashboardService.get_dashboard_summary(session, user.id)
        assert summary.total_sondas >= 1
        assert summary.sondas_online >= 1
        assert summary.alertas_bateria >= 1
        assert len(summary.ultimas_medicoes) >= 1

        # 6. Histórico Paginado de Logs
        logs_paginados = await LogService.get_paginated_logs(
            db=session,
            user_id=user.id,
            sonda_id=sonda_id,
            page=1,
            page_size=10,
        )
        assert logs_paginados.pagination.total_items == 1
        assert logs_paginados.items[0].nivel_bateria == 15.0

        # 7. Atualização de Configuração da Sonda
        config_update = SondaUpdateConfigSchema(
            irrigacao_diurna=True,
            indice_irrigar=40.0,
            intervalo_envio_segundos=1200,
        )
        sonda_configurada = await SondaService.update_sonda_config(
            session, user.id, sonda_id, config_update
        )
        assert sonda_configurada.irrigacao_diurna is True
        assert sonda_configurada.indice_irrigar == 40.0

        # 8. Soft Delete
        await SondaService.soft_delete_sonda(session, user.id, sonda_id)
        
        # Verificar que a sonda foi desativada e não aparece nas listagens ativas
        sondas_ativas = await SondaService.list_sondas_by_user(session, user.id)
        assert not any(s.id == sonda_id for s in sondas_ativas)

    await engine.dispose()
