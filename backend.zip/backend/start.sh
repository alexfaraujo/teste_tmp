#!/usr/bin/env bash
# =============================================================================
# SCRIPT DE INICIALIZAÇÃO RÁPIDA (LINUX / BASH)
# Backend de Irrigação Inteligente (FastAPI + PostgreSQL)
# =============================================================================

set -e

echo "🌱 Iniciando o ambiente do Backend de Irrigação Inteligente..."

# 1. Verificar/Criar ambiente virtual Python
if [ ! -d "venv" ]; then
    echo "📦 Criando ambiente virtual Python (venv)..."
    python3 -m venv venv
fi

# 2. Ativar o ambiente virtual
source venv/bin/activate

# 3. Atualizar pip e instalar dependências
echo "📥 Instalando/Atualizando dependências a partir do requirements.txt..."
pip install --upgrade pip
pip install -r requirements.txt

# 4. Copiar .env se não existir
if [ ! -f ".env" ]; then
    echo "📄 Arquivo .env não encontrado. Copiando a partir do .env.example..."
    cp .env.example .env
fi

# 5. Criar e sincronizar banco de dados e tabelas no PostgreSQL
echo "🗄️ Inicializando e sincronizando o banco de dados PostgreSQL..."
python3 -m src.core.init_db

# 6. Obter HOST e PORT do .env ou usar fallbacks 0.0.0.0 e 2065
HOST=$(grep -v '^#' .env | grep -E '^\s*HOST\s*=' | head -n 1 | cut -d '=' -f2 | tr -d '"' | tr -d "'" | xargs || echo "0.0.0.0")
HOST=${HOST:-0.0.0.0}

PORT=$(grep -v '^#' .env | grep -E '^\s*PORT\s*=' | head -n 1 | cut -d '=' -f2 | tr -d '"' | tr -d "'" | xargs || echo "2065")
PORT=${PORT:-2065}

# 7. Iniciar servidor FastAPI com Uvicorn no HOST 0.0.0.0 na PORTA 2065
echo "🚀 Servidor FastAPI iniciando no HOST $HOST na PORTA $PORT..."
echo "🌐 Documentação interativa Swagger disponível em: http://$HOST:$PORT/docs"
exec uvicorn src.main:app --host "$HOST" --port "$PORT"
