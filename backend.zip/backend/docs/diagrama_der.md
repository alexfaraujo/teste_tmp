# Diagrama DER — Banco de Dados de Irrigação (PostgreSQL)

Este documento contém o Diagrama de Entidade-Relacionamento (DER) em sintaxe **Mermaid.js** para o banco de dados PostgreSQL do sistema de irrigação inteligente.

---

## 1. Diagrama DER (Mermaid.js)

```mermaid
erDiagram
    usuarios ||--o{ sondas : "possui (1:N)"
    sondas ||--o{ logs_sondas : "registra (1:N)"

    usuarios {
        VARCHAR_128 id PK "Firebase UID"
        VARCHAR_255 email UK "E-mail do Gmail"
        VARCHAR_255 nome "Nome do Produtor"
        BOOLEAN perfil_completo "Flag de onboarding"
        BOOLEAN status "Status do usuário"
        TIMESTAMPTZ created_at "Data de criação"
        TIMESTAMPTZ deleted_at "Soft delete"
    }

    sondas {
        UUID id PK "Identificador único da sonda"
        VARCHAR_128 usuario_id FK "Chave estrangeira -> usuarios.id"
        VARCHAR_100 nome_identificador "Nome customizado"
        VARCHAR_64 codigo_hardware UK "Endereço MAC ou ID físico do hardware"
        VARCHAR_64 api_key_hash UK "Hash SHA-256 da API Key"
        VARCHAR_8 api_key_prefix "Prefixo identificador da chave"
        BOOLEAN irrigacao_diurna "Permite irrigar de dia"
        REAL indice_irrigar "Limiar de disparo (%)"
        INTEGER intervalo_envio_segundos "Frequência de envio em segundos"
        BOOLEAN ativo "Flag de ativação da sonda"
        TIMESTAMPTZ created_at "Data de cadastro"
        TIMESTAMPTZ updated_at "Data de atualização"
        TIMESTAMPTZ deleted_at "Soft delete"
    }

    logs_sondas {
        BIGSERIAL id PK "Identificador do log"
        UUID sonda_id FK "Chave estrangeira -> sondas.id"
        REAL nivel_bateria "Nível da bateria (0-100%)"
        REAL temperatura "Temperatura em graus Celsius"
        INTEGER umidade_bruta "Valor analógico bruto ADC"
        REAL indice_umidade "Índice de umidade calibrado (%)"
        TIMESTAMPTZ received_at "Carimbo de data/hora UTC"
        TIMESTAMPTZ deleted_at "Soft delete"
    }
```

---

## 2. Detalhes das Relacionamentos

- **`usuarios` -> `sondas` (1:N):** Um usuário cadastrado pode ter zero ou múltiplas sondas de irrigação sob sua conta (`usuario_id`).
- **`sondas` -> `logs_sondas` (1:N):** Cada sonda gera registros periódicos de telemetria à medida que envia leituras via rádio rfid/WiFi (`sonda_id`).
- **Soft Delete:** Nenhuma tabela utiliza exclusão física. Registros inativados recebem carimbo de data/hora em `deleted_at`.
