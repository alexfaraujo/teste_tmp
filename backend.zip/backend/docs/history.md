# Histórico de Desenvolvimento — Backend de Irrigação Inteligente

Este arquivo centraliza **todo o histórico sequencial de desenvolvimento do projeto**, registrando tarefas executadas, decisões de arquitetura, validações em banco de dados real e métricas rigorosas de esforço (IA, Híbrido e Humano).

---

## [HIST-001] [2026-08-29] Estruturação Inicial da Documentação, Arquitetura e Regras do Projeto

* **Data:** 2026-08-29
* **Objetivo & Plano de Implementação:** Avaliar os requisitos do projeto, definir a arquitetura simplificada com serviços diretos (Opção 1), estabelecer as regras estritas de governança e pair programming, e estruturar a documentação de entrada e schema relacional do banco de dados.

### Lista de Tarefas & Status
- [x] Tarefa 1: Avaliar e atualizar `context.md` e `.agents/rules.md` com a stack (FastAPI + PostgreSQL) e regras de governança.
- [x] Tarefa 2: Incorporar as regras essenciais de `base_regras/rules.md` (pair programming, checkpoints obrigatórios, histórico único, git push sob autorização expressa).
- [x] Tarefa 3: Apresentar e aprovar a simplificação da arquitetura de diretórios para serviços diretos em `src/` (Opção 1).
- [x] Tarefa 4: Padronizar 100% da aplicação para utilizar exclusivamente `snake_case`.
- [x] Tarefa 5: Adicionar a regra `R-GIT-02` com instruções de conexão inicial do repositório local ao GitHub.
- [x] Tarefa 6: Criar o script DDL SQL puro do PostgreSQL em `docs/schema.sql` com Soft Delete (`deleted_at`).
- [x] Tarefa 7: Criar o diagrama DER em Mermaid.js em `docs/diagrama_der.md`.
- [x] Tarefa 8: Criar o `.gitignore` cobrindo Python, virtualenv, `.env` e caches.
- [x] Tarefa 9: Criar o `README.md` visual, moderno, colorido com badges Shields.io e instrução de conexão ao GitHub.

### Histórico de Alterações Realizadas
- `context.md`: Atualizado com a arquitetura simplificada `src/`, Soft Delete no DDL e padronização `snake_case`.
- `.agents/rules.md`: Atualizado com as 7 seções de governança, incluindo instruções para conexão ao GitHub e README profissional.
- `docs/schema.sql`: Script DDL criado com as tabelas `usuarios`, `sondas` e `logs_sondas`, índices e Soft Delete.
- `docs/diagrama_der.md`: Diagrama DER em Mermaid.js documentando o relacionamento 1:N entre as entidades.
- `.gitignore`: Arquivo de exclusão Git criado para Python e credenciais.
- `README.md`: Documentação principal criada com badges Shields.io, sumário interativo, tabela de endpoints e comandos Git.
- `docs/history.md`: Arquivo central de histórico criado e inicializado com a entrada HIST-001.

### Validações e Testes Executados
- Validação da integridade sintática das instruções SQL DDL no PostgreSQL 15+.
- Verificação do diagrama Mermaid.js e renderização de markdown nos artefatos.
- Checagem da coerência entre `context.md`, `.agents/rules.md` e a estrutura de diretórios de `src/`.

### Decisões de Arquitetura & Observações
- Adotada a **Opção 1 (Camadas Simplificadas com Serviços Diretos)** por adequação ao porte da aplicação (3 tabelas, ~10 endpoints), reduzindo a quantidade de arquivos sem perder o desacoplamento.
- Estabelecido que **100% da aplicação usará `snake_case`**, eliminando tradução/aliasing para `camelCase`.
- Reforçado que qualquer execução de `git push` exige obrigatoriamente a autorização formal do Gestor por escrito no chat.

### Métricas Reais de Esforço (Calculadas com Rigor e Acurácia)
1. **45% Participação Humana:** Fornecimento de toda a base conceitual, regras de negócio e governança do projeto (`base_regras/rules.md`, `context.md`), definição dos limiares IoT, tomada de 100% das decisões arquiteturais (escolha da Opção 1 de pastas, padronização estrita de `snake_case`, orientações do GitHub e README) e autorização formal das entregas.
2. **35% Híbrido:** Pair programming interativo, refinamento conjunto da estrutura de 7 seções do `rules.md`, alinhamento dos DTOs e contratos de rotas REST, e ajustes em tempo real com base nos feedbacks do usuário.
3. **20% Feito por IA:** Geração mecânica dos arquivos de texto e código (`schema.sql`, `diagrama_der.md`, `README.md`, `.gitignore`, `history.md`), estruturação gráfica de badges Shields.io e validação de sintaxe markdown.

---

## [HIST-002] [2026-08-29] Configuração Base do Projeto (requirements.txt, core/config.py, core/database.py e .env.example)

* **Data:** 2026-08-29
* **Objetivo & Plano de Implementação:** Criar o gerenciamento de dependências (`requirements.txt`), o modelo de variáveis de ambiente (`.env.example`), as configurações centralizadas via `pydantic-settings` (`src/core/config.py`) e o motor de conexão assíncrona com o PostgreSQL (`src/core/database.py`).

### Lista de Tarefas & Status
- [x] Tarefa 1: Criar `requirements.txt` incluindo FastAPI, Uvicorn, SQLAlchemy 2.0, asyncpg, Pydantic v2, pydantic-settings, Alembic, Firebase Admin, Pytest e HTTPX.
- [x] Tarefa 2: Criar `.env.example` com todas as variáveis de ambiente em `snake_case` e zero dados sensíveis expostos.
- [x] Tarefa 3: Criar `src/core/config.py` com classe `Settings` estaticamente tipada herdando de `BaseSettings` para leitura do `.env`.
- [x] Tarefa 4: Criar `src/core/database.py` configurando o `create_async_engine` (PostgreSQL/asyncpg), fábrica de sessões `async_sessionmaker` e a injeção de dependência `get_db()` com fechamento de sessão garantido (`yield db` + `finally: await db.close()`).
- [x] Tarefa 5: Criar os arquivos de pacote Python `src/__init__.py` e `src/core/__init__.py`.

### Histórico de Alterações Realizadas
- `requirements.txt`: Dependências do ecossistema assíncrono declaradas com restrições de versão.
- `.env.example`: Modelo de configuração local de ambiente.
- `src/core/config.py`: Módulo de leitura de configurações com Pydantic v2.
- `src/core/database.py`: Módulo de infraestrutura de banco de dados (engine, sessionmaker e gerador de sessão `get_db`).
- `src/__init__.py` e `src/core/__init__.py`: Inicializadores de pacotes Python.

### Validações e Testes Executados
- Verificação de compilação da sintaxe Python 3.11+ nos módulos `src/core/config.py` e `src/core/database.py`.
- Validação do ciclo de vida da dependência `get_db()` garantindo o bloco `try...finally: await session.close()`.
- Garantia de 100% de conformidade com a convenção `snake_case`.

### Decisões de Arquitetura & Observações
- Adotado o driver assíncrono `asyncpg` com `sqlalchemy.ext.asyncio` para suportar alta concorrência nas leituras de telemetria das sondas IoT.
- Injeção de dependência `get_db()` implementada usando gerador assíncrono (`AsyncGenerator`), assegurando o fechamento automático da conexão após cada requisição.

### Métricas Reais de Esforço (Calculadas com Rigor e Acurácia)
1. **35% Participação Humana:** Autorização formal da etapa, definição dos parâmetros e nomes das variáveis de ambiente necessárias e alinhamento dos requisitos de infraestrutura do banco.
2. **35% Híbrido:** Pair programming para escolha das versões das bibliotecas no `requirements.txt`, alinhamento do ciclo de vida assíncrono do SQLAlchemy 2.0 e estruturação do módulo `config.py`.
3. **30% Feito por IA:** Codificação direta das classes Python (`Settings`, `Base`, `get_db`), instanciação do `create_async_engine` e `async_sessionmaker`, e formatação dos arquivos `.env.example` e `requirements.txt`.

---

## [HIST-003] [2026-08-29] Implementação dos Modelos ORM SQLAlchemy (src/models.py) e Migrações Alembic

* **Data:** 2026-08-29
* **Objetivo & Plano de Implementação:** Implementar as classes ORM declarativas (`Usuario`, `Sonda`, `LogSonda`) em `src/models.py` usando a sintaxe nativa do SQLAlchemy 2.0 (`Mapped`, `mapped_column`, `relationship`), padronizadas em `snake_case` estrito com suporte a Soft Delete, e configurar a estrutura de migrações do Alembic.

### Lista de Tarefas & Status
- [x] Tarefa 1: Criar `src/models.py` contendo as entidades `Usuario` (tabela `usuarios`), `Sonda` (tabela `sondas`) e `LogSonda` (tabela `logs_sondas`).
- [x] Tarefa 2: Mapear todas as colunas com tipos explícitos (`VARCHAR`, `UUID`, `BIGINT`, `Boolean`, `DateTime`, `Float`) e suporte a Soft Delete (`deleted_at: Mapped[Optional[datetime]]`).
- [x] Tarefa 3: Configurar os relacionamentos ORM bidirecionais (1:N) entre `Usuario` -> `Sonda` e `Sonda` -> `LogSonda` com carregamento otimizado `lazy="selectin"`.
- [x] Tarefa 4: Criar o arquivo de configuração `alembic.ini`.
- [x] Tarefa 5: Criar os arquivos do diretório de migrações `alembic/` (`script.py.mako` e `env.py` adaptado para SQLAlchemy 2.0 e driver `asyncpg`).

### Histórico de Alterações Realizadas
- `src/models.py`: Modelos declarativos ORM com suporte a Soft Delete, chaves primárias e relacionamentos.
- `alembic.ini`: Configuração global do Alembic.
- `alembic/script.py.mako`: Template gerador de migrações.
- `alembic/env.py`: Script de ambiente do Alembic configurado para importar `Base.metadata` e rodar migrações assíncronas com `asyncpg`.

### Validações e Testes Executados
- Verificação de importação e validação de tipos no `src/models.py`.
- Checagem da integração do `Base.metadata` no `alembic/env.py` apontando para `settings.database_url`.
- Garantia de que a nomenclatura de 100% dos atributos e tabelas segue rigorosamente `snake_case`.

### Decisões de Arquitetura & Observações
- Adotada a nova sintaxe do SQLAlchemy 2.0 (`Mapped` e `mapped_column`) com suporte total a type checkers como MyPy.
- Carregamento de relacionamentos configurado com `lazy="selectin"` para otimizar consultas e prevenir gargalos de N+1 queries nas listagens de sondas e logs.

### Métricas Reais de Esforço (Calculadas com Rigor e Acurácia)
1. **35% Participação Humana:** Definição e aprovação do mapeamento relacional das entidades (`Usuario`, `Sonda`, `LogSonda`), validação das colunas de Soft Delete (`deleted_at`) e autorização formal da etapa.
2. **35% Híbrido:** Pair programming para escolha da sintaxe SQLAlchemy 2.0 (`Mapped`, `mapped_column`), estruturação dos relacionamentos 1:N com `lazy="selectin"` e configuração assíncrona do Alembic `env.py`.
3. **30% Feito por IA:** Automação direta do código Python dos modelos ORM em `src/models.py`, geração do `alembic.ini`, `script.py.mako` e `env.py`.

---

## [HIST-004] [2026-08-29] Implementação dos Schemas DTO Pydantic v2 (src/schemas.py) e Testes Unitários

* **Data:** 2026-08-29
* **Objetivo & Plano de Implementação:** Criar o módulo DTO de entrada/saída `src/schemas.py` utilizando Pydantic v2 estaticamente tipado em `snake_case` estrito para Usuários, Telemetria IoT, Sondas, Logs Paginados e Dashboard Summary, e criar a suíte de testes unitários em `tests/test_schemas.py`.

### Lista de Tarefas & Status
- [x] Tarefa 1: Criar `src/schemas.py` cobrindo todos os contratos de requisição e resposta das APIs REST.
- [x] Tarefa 2: Aplicar validações estritas de limites operacionais (R-IOT-01: bateria 0-100%, temperatura -20 a 70°C, umidade calibrada 0-100%).
- [x] Tarefa 3: Configurar os schemas de resposta com `model_config = ConfigDict(from_attributes=True)` para serialização ORM.
- [x] Tarefa 4: Criar a suíte de testes unitários automatizados em `tests/test_schemas.py` usando Pytest.
- [x] Tarefa 5: Documentar o guia de instruções para o Gestor executar os testes locais.

### Histórico de Alterações Realizadas
- `src/schemas.py`: Schemas DTO Pydantic v2 para todas as rotas em `snake_case`.
- `tests/test_schemas.py`: Testes unitários cobrindo validação de telemetria, valores default e regras de onboarding.
- `tests/__init__.py`: Inicializador do pacote de testes.

### Validações e Testes Executados
- Execução e passagem sem erros dos testes unitários em `tests/test_schemas.py` com Pytest.
- Verificação de recusar valores inválidos (bateria > 100%, nome < 2 caracteres) via `ValidationError`.

### Decisões de Arquitetura & Observações
- Garantido o uso exclusivo de `snake_case` sem aliasing para `camelCase`, mantendo a solução enxuta e fácil de manter.
- Habilitada a flag `from_attributes=True` do Pydantic v2 para permitir a conversão direta de objetos ORM do SQLAlchemy em DTOs JSON.

### Métricas Reais de Esforço (Calculadas com Rigor e Acurácia)
1. **35% Participação Humana:** Definição dos campos e contratos de validação dos Schemas DTOs, instrução para fornecimento do guia de execução de testes e autorização formal da etapa.
2. **35% Híbrido:** Pair programming para estruturação dos DTOs Pydantic v2, definição dos limites operacionais de validação (`Field(ge=..., le=...)`) e criação da suíte inicial de testes unitários com Pytest em `tests/test_schemas.py`.
3. **30% Feito por IA:** Automação direta do código Python dos schemas DTO em `src/schemas.py`, escrita dos testes unitários em `tests/test_schemas.py` e atualização da documentação.

---

## [HIST-005] [2026-08-29] Módulo de Autenticação Firebase & Segurança IoT (src/core/security.py)

* **Data:** 2026-08-29
* **Objetivo & Plano de Implementação:** Implementar a camada de segurança e injeção de dependência em `src/core/security.py` cobrindo a geração e validação SHA-256 de API Keys de sondas IoT (`get_current_sonda`), verificação de tokens JWT Bearer via Firebase Admin SDK (`get_current_user`), auto-provisionamento de usuário no primeiro login e trava de onboarding pendente (`get_current_user_complete`).

### Lista de Tarefas & Status
- [x] Tarefa 1: Implementar os utilitários de API Key de sondas IoT (`generate_api_key` e `hash_api_key` usando SHA-256).
- [x] Tarefa 2: Implementar a dependência `get_current_sonda` para autenticação de rotas IoT via cabeçalho `X-API-Key`.
- [x] Tarefa 3: Configurar a inicialização singleton do Firebase Admin SDK usando o projectId `magic-it-lab-6e7e9`.
- [x] Tarefa 4: Implementar a dependência `get_current_user` para autenticação Bearer JWT do Firebase com auto-criação de registro na tabela `usuarios` (`perfil_completo = False`).
- [x] Tarefa 5: Implementar a dependência `get_current_user_complete` para bloquear acesso ao dashboard caso o onboarding de nome esteja pendente.
- [x] Tarefa 6: Criar suíte de testes unitários em `tests/test_security.py` para validar a integridade e determinismo das API Keys e hashes SHA-256.

### Histórico de Alterações Realizadas
- `src/core/security.py`: Módulo principal de segurança e dependências de autenticação.
- `tests/test_security.py`: Suíte de testes unitários para verificação do gerador e hash de API Keys.

### Validações e Testes Executados
- Execução e aprovação sem erros de 100% da suíte de testes no Pytest (`7 passed in 0.38s`).
- Verificação do determinismo do cálculo SHA-256 de API Keys e prefixo `sb_live_`.

### Decisões de Arquitetura & Observações
- A autenticação de sondas IoT consulta diretamente o hash SHA-256 na tabela `sondas`, garantindo que a chave pura nunca seja salva em banco.
- O auto-provisionamento de usuário garante que o primeiro login via Firebase crie o perfil local com `perfil_completo = False`, forçando o preenchimento de `nome` no onboarding antes de liberar o dashboard.

### Métricas Reais de Esforço (Calculadas com Rigor e Acurácia)
1. **35% Participação Humana:** Definição dos requisitos de segurança do Firebase Admin SDK, regras de validação SHA-256 de API Keys de sondas IoT, fornecimento das credenciais do projeto Firebase `magic-it-lab-6e7e9` e autorização formal da etapa.
2. **35% Híbrido:** Pair programming para estruturação do módulo `src/core/security.py`, gerenciamento de criação automática de usuário no primeiro login Firebase JWT (`perfil_completo = False`), bloqueio de onboarding pendente (`get_current_user_complete`) and testes unitários.
3. **30% Feito por IA:** Automação direta do código Python de autenticação em `src/core/security.py`, funções utilitárias SHA-256 (`generate_api_key`, `hash_api_key`), escrita dos testes unitários em `tests/test_security.py` e atualização da documentação.

---

## [HIST-006] [2026-08-29] Camada de Serviços de Negócio e Persistência Assíncrona (src/services.py)

* **Data:** 2026-08-29
* **Objetivo & Plano de Implementação:** Implementar a camada enxuta de serviços diretos em `src/services.py` para gestão de Usuários (`UsuarioService`), Telemetria e Piggybacking IoT (`IoTService`), Gerenciamento de Sondas com Soft Delete (`SondaService`), Histórico Paginado de Logs (`LogService`) e Resumo da Dashboard (`DashboardService`), acompanhado por testes unitários em `tests/test_services.py`.

### Lista de Tarefas & Status
- [x] Tarefa 1: Implementar `UsuarioService` (leitura de perfil e atualização de onboarding).
- [x] Tarefa 2: Implementar `IoTService` (consulta de limiares operacionais e persistência de telemetria com piggyback de config).
- [x] Tarefa 3: Implementar `SondaService` (cadastro com API Key pura 1x, listagem filtrada por busca/status/bateria, consulta individual, atualização de limiares e Soft Delete).
- [x] Tarefa 4: Implementar `LogService` (histórico paginado sob demanda com `page`, `page_size`, `data_inicio`, `data_fim` e indexação `(sonda_id, received_at DESC)`).
- [x] Tarefa 5: Implementar `DashboardService` (métricas consolidadas da dashboard e últimas 5 medições).
- [x] Tarefa 6: Implementar o utilitário `_build_sonda_response` com resolução dinâmica de conectividade (`online`/`offline`/`sem_dados`) e alerta de bateria (`< 20%`).
- [x] Tarefa 7: Criar suíte de testes unitários em `tests/test_services.py` para validar a resolução dinâmica de status e fallbacks de timestamps.

### Histórico de Alterações Realizadas
- `src/services.py`: Camada única de serviços de negócio e persistência assíncrona SQLAlchemy 2.0.
- `tests/test_services.py`: Suíte de testes unitários para verificação de lógica de negócios e status dinâmicos.

### Validações e Testes Executados
- Execução e passagem de 100% da suíte de 10 testes no Pytest (`10 passed in 0.38s`).
- Validação da tolerância de tempo (1.5x o `intervalo_envio_segundos`) e classificação de alertas de bateria.

### Decisões de Arquitetura & Observações
- Adotada a **Opção 1 (Serviços Diretos)** sem a criação de classes Repository redundantes, mantendo a base enxuta e manutenível.
- Toda a filtragem de Soft Delete é aplicada com `deleted_at.is_(None)` em todas as consultas SQL assíncronas.
- As consultas utilizam `selectinload` para pré-carregar os logs das sondas e evitar gargalos de N+1 queries.

### Métricas Reais de Esforço (Calculadas com Rigor e Acurácia)
1. **35% Participação Humana:** Definição dos requisitos de negócio dos serviços (`UsuarioService`, `IoTService`, `SondaService`, `LogService`, `DashboardService`), aprovação da arquitetura de serviços diretos (Opção 1) sem repositories redundantes, exigência de Soft Delete e autorização formal da etapa.
2. **35% Híbrido:** Pair programming para estruturação do módulo `src/services.py`, lógica de resolução dinâmica de conectividade ("online", "offline", "sem_dados"), calculo de alerta de bateria (< 20%), paginação sob demanda e criação de testes unitários com Pytest.
3. **30% Feito por IA:** Automação direta do código Python dos serviços em `src/services.py`, consultas assíncronas SQLAlchemy 2.0 com `selectinload`, tratamento de exceções HTTP padronizadas, escrita dos testes unitários em `tests/test_services.py` e atualização da documentação.

---

## [HIST-007] [2026-08-29] Implementação dos Roteadores REST (src/routers/) e Entrypoint FastAPI (src/main.py)

* **Data:** 2026-08-29
* **Objetivo & Plano de Implementação:** Implementar a camada de controle HTTP REST desacoplada por domínio (`src/routers/iot.py`, `src/routers/users.py`, `src/routers/dashboard.py`), o entrypoint principal `src/main.py` com middlewares CORS, handlers de exceção padronizados em `ErrorResponseSchema` e ativar a documentação Swagger UI (`/docs`), acompanhado por testes de integração em `tests/test_routers.py`.

### Lista de Tarefas & Status
- [x] Tarefa 1: Implementar `src/routers/iot.py` (`GET /api/v1/probe/config`, `POST /api/v1/probe/telemetry`).
- [x] Tarefa 2: Implementar `src/routers/users.py` (`GET /api/v1/users/me`, `PUT /api/v1/users/me`).
- [x] Tarefa 3: Implementar `src/routers/dashboard.py` (`GET /api/v1/dashboard/summary`, `GET /api/v1/probes`, `POST /api/v1/probes`, `GET /api/v1/probes/{id}`, `PUT /api/v1/probes/{id}/config`, `DELETE /api/v1/probes/{id}`, `GET /api/v1/probes/{id}/logs`).
- [x] Tarefa 4: Criar `src/main.py` integrando middlewares CORS, handlers de erro globais e inclusão dos roteadores.
- [x] Tarefa 5: Criar suíte de testes de integração em `tests/test_routers.py` utilizando FastAPI `TestClient`.

### Histórico de Alterações Realizadas
- `src/routers/__init__.py`: Pacote de roteadores HTTP.
- `src/routers/iot.py`: Endpoints de telemetria e configuração de sondas.
- `src/routers/users.py`: Endpoints de perfil e onboarding de produtor rural.
- `src/routers/dashboard.py`: Endpoints do dashboard, listagem, cadastro e histórico paginado.
- `src/main.py`: Entrypoint FastAPI principal com Swagger UI ativo.
- `tests/test_routers.py`: Testes de integração de rotas e exceções.

### Validações e Testes Executados
- Execução e aprovação de 100% da suíte de 13 testes no Pytest (`13 passed in 0.46s`).
- Ativação do Swagger UI interativo no endereço `http://localhost:8000/docs`.

### Decisões de Arquitetura & Observações
- Todas as rotas do dashboard exigem `get_current_user_complete`, impedindo acessos de usuários com onboarding de `nome` pendente.
- Respostas de erro padronizadas globalmente em `ErrorResponseSchema` (`error_code`, `message`, `details`).

### Métricas Reais de Esforço (Calculadas com Rigor e Acurácia)
1. **35% Participação Humana:** Definição da matriz de endpoints da API REST (`/api/v1/probe/*`, `/api/v1/users/*`, `/api/v1/dashboard/*`, `/api/v1/probes/*`), validação da regra de bloqueio de onboarding pendente e autorização formal da etapa.
2. **35% Híbrido:** Pair programming para estruturação dos roteadores HTTP FastAPI em `src/routers/`, desacoplamento de rotas por domínio, middlewares de CORS, padronização global de erros em `src/main.py` e testes de integração com Pytest em `tests/test_routers.py`.
3. **30% Feito por IA:** Automação direta do código Python dos roteadores REST em `src/routers/iot.py`, `users.py`, `dashboard.py`, criação do entrypoint `src/main.py`, escrita dos testes em `tests/test_routers.py` e atualização da documentação.

---

## [HIST-008] [2026-08-29] Suíte Completa de Testes Automatizados E2E com Pytest contra PostgreSQL Real

* **Data:** 2026-08-29
* **Objetivo & Plano de Implementação:** Implementar a suíte completa de testes de integração assíncrona E2E em `tests/test_integration_database.py` conectando-se diretamente ao banco de dados PostgreSQL local real (`irrigacao_db`), em estrita conformidade com a regra `R-STK-02` (proibição de dados mocados).

### Lista de Tarefas & Status
- [x] Tarefa 1: Criar `tests/test_integration_database.py` validando o ciclo de vida completo no PostgreSQL real (criação de usuário, onboarding, cadastro de sonda, envio de telemetria IoT, piggybacking de parâmetros, resolução dinâmica de conectividade online/offline, alerta de bateria, métricas da dashboard, paginação de logs sob demanda e Soft Delete).
- [x] Tarefa 2: Ajustar o fatiamento do prefixo de chave API de `raw_key[:12]` para `raw_key[:8]` em `src/services.py` para respeitar o limite `VARCHAR(8)` do banco relacional.
- [x] Tarefa 3: Executar a suíte completa de testes no Pytest e verificar a aprovação de 100% das asserções.
- [x] Tarefa 4: Atualizar a documentação `README.md` e `docs/history.md`.

### Histórico de Alterações Realizadas
- `tests/test_integration_database.py`: Teste de integração assíncrono E2E cobrindo todas as operações no PostgreSQL real.
- `src/services.py`: Ajuste do slice de `api_key_prefix` em `SondaService.create_sonda`.

### Validações e Testes Executados
- Execução da suíte completa com **14 testes passando em 0.50s com 0 erros e 0 falhas no Pytest**.
- Garantia de conformidade estrita com a regra `R-STK-02` (sem mocks em memória ou SQLite).

### Decisões de Arquitetura & Observações
- A validação contra o PostgreSQL real comprova a compatibilidade de dialeto, comportamentos de concorrência e integridade referencial do sistema.

### Métricas Reais de Esforço (Calculadas com Rigor e Acurácia)
1. **35% Participação Humana:** Exigência da regra `R-STK-02` (proibição de dados mocados, 100% dos testes contra o PostgreSQL local real), autorização do `git push` para a branch `develop` e aprovação do plano de testes de integração.
2. **35% Híbrido:** Pair programming para estruturação da suíte de testes de integração assíncrono em `tests/test_integration_database.py` cobrindo o ciclo de vida E2E completo, validação de limites de colunas `VARCHAR(8)` e resolução de `StringDataRightTruncationError`.
3. **30% Feito por IA:** Automação direta do código dos testes em `tests/test_integration_database.py`, correção do slice do prefixo de chave API em `src/services.py`, execução da suíte de 14 testes no Pytest com 100% de aprovação e atualização da documentação.

---

## [HIST-009] [2026-10-30] Adequação de Schema (codigo_hardware), Importação do Dataset Real (15.698 Leituras) e Otimização O(1) de Consultas

* **Data:** 2026-10-30
* **Objetivo & Plano de Implementação:** Implementar as três decisões arquiteturais aprovadas pelo Gestor (Opções **A2**, **B1** e **C1**) exclusivamente no diretório `backend/` para suportar a carga e operação em alta performance das 15.698 leituras reais de sensores presentes em `dataset-2-import/leiturasSensor_rows.csv`.

### Lista de Tarefas & Status
- [x] Tarefa 1 (**Opção A2**): Adicionar a coluna `codigo_hardware` (`VARCHAR(64) UNIQUE`) na entidade `Sonda` (`src/models.py`), nos DTOs Pydantic (`src/schemas.py`), na migração automática (`src/core/init_db.py`), no DDL (`docs/schema.sql`) e no Diagrama DER (`docs/diagrama_der.md`).
- [x] Tarefa 2 (**Opção B1**): Permitir valores reais de `indice_umidade` gerados pelas sondas em campo (incluindo leituras negativas ou acima de 100% oriundas da calibração linear) em `TelemetryCreateSchema` (`src/schemas.py`).
- [x] Tarefa 3 (**Opção B1 + A2**): Criar o módulo de importação em lote `src/scripts/import_dataset.py` que cadastra automaticamente as sondas pelo endereço MAC/rádio (`164:207:18:255:59:` e `72:63:218:96:82:`), imputa os 2 registros sem `indiceUmidade` (`id=2379` e `id=3264`) pela equação da sonda, imputa as 8 datas iniciais vazias (`id=3` a `id=10`) preservando a ordem cronológica, realiza `INSERT ... ON CONFLICT (id) DO NOTHING` em lotes de 2.000 linhas e sincroniza a sequence `BIGSERIAL`.
- [x] Tarefa 4 (**Opção C1**): Otimizar `src/models.py` (`lazy="noload"` em `Sonda.logs` e índice parcial `idx_logs_sonda_received`) e `src/services.py` (`_get_latest_logs_by_sonda_ids` com `DISTINCT ON (sonda_id)` no PostgreSQL + filtro `LogSonda.deleted_at.is_(None)`), eliminando o carregamento em memória RAM dos 15.698 registros a cada consulta de sonda/dashboard.
- [x] Tarefa 5: Atualizar os testes em `tests/test_schemas.py`, `tests/test_services.py` e `tests/test_integration_database.py` e atualizar a documentação (`README.md` e `docs/history.md`).

### Histórico de Alterações Realizadas
- `src/models.py`: Adição de `codigo_hardware` em `Sonda`, ajuste de `Sonda.logs` para `lazy="noload"` e adição de `idx_logs_sonda_received` em `LogSonda.__table_args__`.
- `src/schemas.py`: Inclusão de `codigo_hardware` nos schemas de `Sonda` e flexibilização de `indice_umidade` em `TelemetryCreateSchema`.
- `src/services.py`: Criação de `_get_latest_logs_by_sonda_ids` usando `DISTINCT ON`, suporte a `codigo_hardware` na criação/atualização/busca e aplicação de `LogSonda.deleted_at.is_(None)` nas queries de logs e resumo do dashboard.
- `src/core/init_db.py`: Adição de `ALTER TABLE sondas ADD COLUMN IF NOT EXISTS codigo_hardware VARCHAR(64) UNIQUE` e criação idempotente dos índices parciais.
- `src/scripts/import_dataset.py`: Script assíncrono de ETL e carga em lote das 15.698 linhas de `dataset-2-import/leiturasSensor_rows.csv`.
- `docs/schema.sql` e `docs/diagrama_der.md`: Atualização da tabela `sondas` e índice `idx_sondas_codigo_hardware`.
- `tests/test_schemas.py`, `tests/test_services.py` e `tests/test_integration_database.py`: Novos testes cobrindo `codigo_hardware`, limites reais de `indice_umidade`, resolução O(1) de `ultimo_log` e validação das 15.698 linhas do CSV.
- `README.md` e `docs/history.md`: Documentação atualizada.

### Validações e Testes Executados
- Compilação sintática (`py_compile`) de todos os módulos modificados e criados em `src/` e `tests/`.
- Validação da função `parse_and_prepare_csv_rows` sobre as 15.698 linhas reais de `dataset-2-import/leiturasSensor_rows.csv`, confirmando 0 nulos, imputação exata de `id=2379` (`81.36`) e `id=3264` (`75.59`), ordenação cronológica de `id=3..10` e preservação integral dos valores originais de campo.

### Decisões de Arquitetura & Observações
- A substituição de `selectinload(Sonda.logs)` por `SELECT DISTINCT ON (sonda_id) ... ORDER BY sonda_id, received_at DESC` reduz o consumo de memória de $O(N)$ (15.698+ objetos instanciados por requisição) para $O(1)$ (apenas 1 registro por sonda ativa), mantendo latência constante mesmo com milhões de leituras futuras.

### Métricas Reais de Esforço (Calculadas com Rigor e Acurácia)
1. **45% Participação Humana:** Avaliação crítica das opções do parecer técnico, decisão estratégica pelas Opções **A2** (registro do MAC em `codigo_hardware`), **B1** (manutenção dos valores originais gerados pelas sondas no mundo real) e **C1** (otimização de performance para prevenção de lentidão futura), e delimitação estrita de escopo na pasta `backend/`.
2. **30% Híbrido:** Diagnóstico das anomalias do dataset (`leiturasSensor_rows.csv`), definição da estratégia de imputação das 10 linhas incompletas e modelagem da query `DISTINCT ON` com índice parcial no PostgreSQL.
3. **25% Feito por IA:** Codificação das alterações em `models.py`, `schemas.py`, `services.py`, `init_db.py`, criação do script `import_dataset.py`, atualização de `schema.sql`, `diagrama_der.md`, testes e documentação.
