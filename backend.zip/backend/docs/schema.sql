-- =============================================================================
-- SCRIPT DDL: Backend de Irrigação Inteligente (PostgreSQL 15+)
-- Data de Criação: 2026-08-29
-- Padrão de Nomenclatura: snake_case Estrito
-- Estratégia de Remoção: Soft Delete (deleted_at TIMESTAMPTZ)
-- =============================================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- -----------------------------------------------------------------------------
-- Tabela: usuarios
-- Armazena o perfil básico dos usuários autenticados via Firebase Auth (UID)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS usuarios (
    id VARCHAR(128) PRIMARY KEY, -- Firebase UID
    email VARCHAR(255) NOT NULL UNIQUE,
    nome VARCHAR(255) NOT NULL,
    perfil_completo BOOLEAN NOT NULL DEFAULT FALSE,
    status BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMPTZ DEFAULT NULL
);

-- -----------------------------------------------------------------------------
-- Tabela: sondas
-- Armazena o cadastro e limiares operacionais dos nós IoT integrados em campo
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS sondas (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    usuario_id VARCHAR(128) NOT NULL REFERENCES usuarios(id),
    nome_identificador VARCHAR(100) NOT NULL,
    codigo_hardware VARCHAR(64) UNIQUE DEFAULT NULL,
    api_key_hash VARCHAR(64) NOT NULL UNIQUE,
    api_key_prefix VARCHAR(8) NOT NULL,
    irrigacao_diurna BOOLEAN NOT NULL DEFAULT FALSE,
    indice_irrigar REAL NOT NULL DEFAULT 35.0,
    intervalo_envio_segundos INTEGER NOT NULL DEFAULT 600,
    ativo BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMPTZ DEFAULT NULL
);

-- -----------------------------------------------------------------------------
-- Tabela: logs_sondas
-- Armazena a série temporal de leituras de telemetria recebidas das sondas
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS logs_sondas (
    id BIGSERIAL PRIMARY KEY,
    sonda_id UUID NOT NULL REFERENCES sondas(id),
    nivel_bateria REAL NOT NULL,
    temperatura REAL NOT NULL,
    umidade_bruta INTEGER NOT NULL,
    indice_umidade REAL NOT NULL,
    received_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMPTZ DEFAULT NULL
);

-- -----------------------------------------------------------------------------
-- Índices de Alta Performance para Autenticação, Séries Temporais e Soft Delete
-- -----------------------------------------------------------------------------
CREATE INDEX IF NOT EXISTS idx_usuarios_status_deleted 
    ON usuarios(status, deleted_at);

CREATE INDEX IF NOT EXISTS idx_sondas_usuario_id 
    ON sondas(usuario_id) 
    WHERE deleted_at IS NULL;

CREATE INDEX IF NOT EXISTS idx_sondas_codigo_hardware 
    ON sondas(codigo_hardware) 
    WHERE deleted_at IS NULL;

CREATE INDEX IF NOT EXISTS idx_sondas_api_key_hash 
    ON sondas(api_key_hash) 
    WHERE ativo = TRUE AND deleted_at IS NULL;

CREATE INDEX IF NOT EXISTS idx_logs_sonda_received 
    ON logs_sondas(sonda_id, received_at DESC) 
    WHERE deleted_at IS NULL;
