<p align="center">
  <img src="https://img.shields.io/badge/Python-3.11%2B-3776AB?style=for-the-badge&logo=python&logoColor=white" alt="Python Version" />
  <img src="https://img.shields.io/badge/FastAPI-0.100%2B-009688?style=for-the-badge&logo=fastapi&logoColor=white" alt="FastAPI Framework" />
  <img src="https://img.shields.io/badge/PostgreSQL-15%2B-4169E1?style=for-the-badge&logo=postgresql&logoColor=white" alt="PostgreSQL Database" />
  <img src="https://img.shields.io/badge/SQLAlchemy-2.0-CC292B?style=for-the-badge&logo=sqlalchemy&logoColor=white" alt="SQLAlchemy ORM" />
  <img src="https://img.shields.io/badge/Pydantic-v2-E92063?style=for-the-badge&logo=pydantic&logoColor=white" alt="Pydantic v2" />
  <img src="https://img.shields.io/badge/Firebase_Auth-JWT-FFCA28?style=for-the-badge&logo=firebase&logoColor=black" alt="Firebase Auth" />
  <img src="https://img.shields.io/badge/Security-LGPD_Compliant-success?style=for-the-badge&logo=shield" alt="LGPD Security" />
</p>

<h1 align="center">🐍 Backend de Irrigação Inteligente (FastAPI + PostgreSQL)</h1>

<p align="center">
  <b>API RESTful assíncrona para telemetria IoT em tempo real de sondas agrícolas e gerenciamento de irrigação via dashboard web.</b>
</p>

---

## 📋 Sumário Interativo

- [📌 Visão Geral do Sistema](#-visão-geral-do-sistema)
- [🏗️ Arquitetura Simplificada do Módulo Backend](#️-arquitetura-simplificada-do-módulo-backend)
- [🗄️ Modelo Relacional e DDL](#️-modelo-relacional-e-ddl)
- [🔌 Matriz de Endpoints da API](#-matriz-de-endpoints-da-api)
- [🚀 Instruções de Execução Bare-Metal](#-instruções-de-execução-bare-metal)
- [🧪 Credenciais e Chaves de Teste Local (Swagger UI)](#-credenciais-e-chaves-de-teste-local-swagger-ui)
- [📊 Status do Desenvolvimento Incremental](#-status-do-desenvolvimento-incremental)

---

## 📌 Visão Geral do Sistema

O backend de irrigação inteligente atende a dois clientes principais:
1. **Nós IoT (Sondas / Válvulas em Campo):** Dispositivos ESP32 que consultam limiares operacionais (`irrigacao_diurna`, `indice_irrigar`, `intervalo_envio_segundos`) e submetem dados de telemetria.
2. **Dashboard Web (Produtor Agrícola):** Interface gerencial onde o usuário autenticado acompanha o status de conectividade (online/offline), histórico paginado de leituras e alertas operacionais.

---

## 🏗️ Arquitetura Simplificada do Módulo Backend

O projeto adota uma **arquitetura enxuta com serviços diretos (Opção 1)** em `backend/src/`. Toda a aplicação utiliza a convenção **`snake_case`**.

```
backend/
├── src/
│   ├── core/                # Configurações (.env), conexão com PostgreSQL e autenticação
│   │   ├── config.py
│   │   ├── database.py
│   │   └── security.py
│   ├── models.py            # Modelos ORM SQLAlchemy declarativos (Usuario, Sonda, LogSonda)
│   ├── schemas.py           # DTOs Pydantic v2 (User, Probe, Telemetry, Dashboard)
│   ├── services.py          # Regras de negócio e persistência SQLAlchemy 2.0 assíncrona
│   ├── routers/
│   │   ├── iot.py           # /api/v1/probe (telemetria e config de sondas)
│   │   ├── users.py         # /api/v1/users (perfil e onboarding)
│   │   └── dashboard.py     # /api/v1/dashboard e /api/v1/probes (gerenciamento)
│   ├── scripts/
│   │   ├── seed_data.py     # Carga de dados de teste local
│   │   └── import_dataset.py # Importação em lote do dataset real (15.698 leituras)
│   └── main.py              # Entrypoint do FastAPI (CORS, middlewares, routers)
├── tests/                   # Suíte de testes automatizados com Pytest
├── docs/                    # DDL, Diagrama DER e Histórico
├── .env.example
├── start.sh
├── setup.ps1
└── requirements.txt
```

---

## 🚀 Instruções de Execução

Executar a partir da pasta `backend/` ou da raiz do monorepo:

```bash
# Execução direta via script automatizado:
./start.sh

# Ou manualmente:
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python3 -m src.core.init_db
uvicorn src.main:app --reload --port 8000
```

### 📥 Importação do Dataset Real (`dataset-2-import/leiturasSensor_rows.csv`)

Para importar as **15.698 leituras reais** das sondas de campo (cadastrando automaticamente os endereços físicos `codigo_hardware` `164:207:18:255:59:` e `72:63:218:96:82:`):

```bash
python3 -m src.scripts.import_dataset
```

---

## 🧪 Credenciais e Chaves de Teste Local (Swagger UI)

Para validar manualmente os endpoints no **Swagger UI (`http://localhost:8000/docs`)**:

```bash
python3 -m src.scripts.seed_data
```

### 🗝️ Valores de Teste Pronto para Uso no Swagger:

* **Autenticação Web/Dashboard (`HTTPBearer`):**
  ```text
  irrigacao_master_secret_2026
  ```
* **Autenticação IoT das Sondas (`X-API-Key`):**
  ```text
  sb_live_1234567890abcdef12345678
  ```
* **UUID da Sonda de Teste (`sonda_id`):**
  ```text
  22836d5a-0a8d-4148-9ca2-5eddf5d3951c
  ```

---

## 📊 Status do Desenvolvimento Incremental

- [x] **[HIST-001]** Estruturação Inicial da Documentação, Arquitetura Simplificada e Regras.
- [x] **[HIST-002]** Configuração Base do Projeto (`requirements.txt`, `core/config.py`, `core/database.py`).
- [x] **[HIST-003]** Implementação dos Modelos ORM SQLAlchemy (`models.py`) e Migrações Alembic.
- [x] **[HIST-004]** Implementação dos Schemas Pydantic v2 DTO (`schemas.py`) em `snake_case`.
- [x] **[HIST-005]** Módulo de Autenticação Firebase & Segurança IoT (`core/security.py`).
- [x] **[HIST-006]** Camada de Serviços de Negócio (`services.py`).
- [x] **[HIST-007]** Implementação dos Roteadores REST (`routers/iot.py`, `users.py`, `dashboard.py`) e Entrypoint (`main.py`).
- [x] **[HIST-008]** Testes Automatizados com Pytest contra PostgreSQL local real.
- [x] **[HIST-009]** Adequação do Banco de Dados (`codigo_hardware`), Pipeline ETL de Importação do Dataset Real (`import_dataset.py`) e Otimização O(1) de Consultas de Séries Temporais.

> 📝 **Histórico Detalhado & Métricas de IA:** Consulte [backend/docs/history.md](file:///Users/alexaraujo/Downloads/irrigacao_smart-develop/backend/docs/history.md).

> 🚀 **CI/CD Status:** Deploy automático via SSH homologado na branch `main`.
