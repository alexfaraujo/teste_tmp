# =============================================================================
# SCRIPT DE INICIALIZAÇÃO RÁPIDA (WINDOWS / POWERSHELL)
# Backend de Irrigação Inteligente (FastAPI + PostgreSQL)
# =============================================================================

Write-Host "🌱 Iniciando o ambiente do Backend de Irrigação Inteligente..." -ForegroundColor Green

# 1. Verificar/Criar ambiente virtual Python
if (-not (Test-Path -Path "venv")) {
    Write-Host "📦 Criando ambiente virtual Python (venv)..." -ForegroundColor Yellow
    python -m venv venv
}

# 2. Ativar ambiente virtual
& .\venv\Scripts\Activate.ps1

# 3. Atualizar pip e instalar dependências
Write-Host "📥 Instalando/Atualizando dependências..." -ForegroundColor Yellow
python -m pip install --upgrade pip
pip install -r requirements.txt

# 4. Copiar .env se não existir
if (-not (Test-Path -Path ".env")) {
    Write-Host "📄 Copiando .env.example para .env..." -ForegroundColor Yellow
    Copy-Item -Path ".env.example" -Destination ".env"
}

# 5. Criar e sincronizar banco de dados e tabelas no PostgreSQL
Write-Host "🗄️ Inicializando e sincronizando o banco de dados PostgreSQL..." -ForegroundColor Yellow
python -m src.core.init_db

# 6. Iniciar servidor FastAPI
Write-Host "🚀 Servidor FastAPI iniciando..." -ForegroundColor Green
Write-Host "🌐 Swagger UI disponível em: http://localhost:8000/docs" -ForegroundColor Cyan
uvicorn src.main:app --reload --port 8000
