import asyncio
import os
import sys
import asyncpg
from sqlalchemy import text
from sqlalchemy.ext.asyncio import create_async_engine

from src.core.config import settings
from src.core.database import Base
from src.models import Usuario, Sonda, LogSonda  # Garantir importação dos modelos


def _get_safe_db_url() -> str:
    """Retorna a URL do banco de dados com a senha mascarada para exibição segura em logs."""
    url = settings.database_url
    if settings.postgres_password and settings.postgres_password in url:
        return url.replace(settings.postgres_password, "****")
    return url


async def create_database_if_not_exists():
    """
    Verifica se o banco de dados PostgreSQL especificado no .env existe.
    Se não existir, conecta-se ao banco padrão 'postgres' e cria o banco automaticamente.
    """
    sys.stdout.write(f"🔍 Verificando banco de dados '{settings.postgres_db}' em {settings.postgres_server}:{settings.postgres_port}...\n")
    sys.stdout.flush()

    try:
        conn = await asyncpg.connect(
            user=settings.postgres_user,
            password=settings.postgres_password,
            host=settings.postgres_server,
            port=settings.postgres_port,
            database="postgres",
        )

        db_exists = await conn.fetchval(
            "SELECT 1 FROM pg_database WHERE datname = $1", settings.postgres_db
        )

        if not db_exists:
            sys.stdout.write(f"⚙️ Criando banco de dados '{settings.postgres_db}'...\n")
            sys.stdout.flush()
            await conn.execute(f'CREATE DATABASE "{settings.postgres_db}" OWNER "{settings.postgres_user}"')
            sys.stdout.write(f"✅ Banco de dados '{settings.postgres_db}' criado com sucesso!\n")
            sys.stdout.flush()
        else:
            sys.stdout.write(f"✅ Banco de dados '{settings.postgres_db}' já existe.\n")
            sys.stdout.flush()

        await conn.close()

    except Exception as exc:
        sys.stderr.write(f"⚠️ Aviso na verificação/criação do banco de dados: {exc}\n")
        sys.stderr.write("Tentando prosseguir com a verificação de criação das tabelas...\n")
        sys.stderr.flush()


async def init_tables():
    """
    Inicializa/atualiza o schema do banco de dados relacional criando todas as tabelas
    mapeadas no SQLAlchemy 2.0 (usuarios, sondas, logs_sondas) caso ainda não existam.
    Exibe logs diagnósticos extremamente detalhados em caso de falha de acesso ou permissão.
    """
    sys.stdout.write("🏗️ Garantindo criação e atualização das tabelas no banco de dados...\n")
    sys.stdout.flush()

    try:
        engine = create_async_engine(settings.database_url, echo=False)
        async with engine.begin() as conn:
            # Tenta conceder permissões no schema public se o usuário tiver privilégios de owner
            try:
                await conn.execute(text(f'GRANT ALL ON SCHEMA public TO "{settings.postgres_user}";'))
            except Exception:
                pass
            await conn.run_sync(Base.metadata.create_all)
            # Garante migração idempotente da coluna codigo_hardware e índices de alta performance em bancos existentes
            await conn.execute(
                text(
                    "ALTER TABLE sondas ADD COLUMN IF NOT EXISTS codigo_hardware VARCHAR(64) UNIQUE;"
                )
            )
            await conn.execute(
                text(
                    "CREATE INDEX IF NOT EXISTS idx_sondas_codigo_hardware ON sondas(codigo_hardware) WHERE deleted_at IS NULL;"
                )
            )
            await conn.execute(
                text(
                    "CREATE INDEX IF NOT EXISTS idx_logs_sonda_received ON logs_sondas(sonda_id, received_at DESC) WHERE deleted_at IS NULL;"
                )
            )
        await engine.dispose()
        sys.stdout.write("✅ Tabelas sincronizadas com sucesso no PostgreSQL!\n")
        sys.stdout.flush()

    except Exception as exc:
        err_msg = str(exc)
        err_type = exc.__class__.__name__

        sys.stderr.write("\n" + "=" * 80 + "\n")
        sys.stderr.write("❌ DIAGNÓSTICO DE ERRO DE CONEXÃO / CRIAÇÃO DE TABELAS POSTGRESQL\n")
        sys.stderr.write("=" * 80 + "\n")
        sys.stderr.write("📌 PARÂMETROS UTILIZADOS NA CONEXÃO:\n")
        sys.stderr.write(f"   • Servidor (Host): {settings.postgres_server}\n")
        sys.stderr.write(f"   • Porta:           {settings.postgres_port}\n")
        sys.stderr.write(f"   • Banco de Dados:  {settings.postgres_db}\n")
        sys.stderr.write(f"   • Usuário:         {settings.postgres_user}\n")
        sys.stderr.write(f"   • URL (Mascarada): {_get_safe_db_url()}\n\n")

        sys.stderr.write(f"🔴 CLASSE DO ERRO: {err_type}\n")
        sys.stderr.write(f"🔴 MENSAGEM DE ERRO DETALHADA:\n   {err_msg}\n\n")

        sys.stderr.write("💡 ORIENTAÇÕES DE DIAGNÓSTICO E CORREÇÃO:\n")

        if "permission denied" in err_msg.lower() or "insufficientprivilege" in err_msg.lower():
            sys.stderr.write("   👉 MOTIVO: O usuário não possui permissão para criar tabelas no schema 'public' ou criar objetos no banco.\n")
            sys.stderr.write("   🛠️ CORREÇÃO (Execute no terminal do servidor como administrador superuser):\n")
            sys.stderr.write(f"      sudo -u postgres psql -d {settings.postgres_db} -c \"GRANT ALL ON SCHEMA public TO {settings.postgres_user}; ALTER SCHEMA public OWNER TO {settings.postgres_user}; GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO {settings.postgres_user};\"\n")

        elif "password authentication failed" in err_msg.lower() or "authentication" in err_msg.lower():
            sys.stderr.write(f"   👉 MOTIVO: A senha informada no .env para o usuário '{settings.postgres_user}' é incorreta ou rejeitada pelo PostgreSQL.\n")
            sys.stderr.write("   🛠️ CORREÇÃO: Verifique a variável POSTGRES_PASSWORD no .env ou redefina a senha do usuário com:\n")
            sys.stderr.write(f"      sudo -u postgres psql -c \"ALTER USER {settings.postgres_user} WITH PASSWORD '{settings.postgres_password}';\"\n")

        elif "database" in err_msg.lower() and "does not exist" in err_msg.lower():
            sys.stderr.write(f"   👉 MOTIVO: O banco de dados '{settings.postgres_db}' não existe no servidor.\n")
            sys.stderr.write("   🛠️ CORREÇÃO: Crie o banco de dados manualmente executando:\n")
            sys.stderr.write(f"      sudo -u postgres psql -c \"CREATE DATABASE {settings.postgres_db} OWNER {settings.postgres_user};\"\n")

        elif "role" in err_msg.lower() and "does not exist" in err_msg.lower():
            sys.stderr.write(f"   👉 MOTIVO: O usuário/role '{settings.postgres_user}' não existe no PostgreSQL.\n")
            sys.stderr.write("   🛠️ CORREÇÃO: Crie o usuário no PostgreSQL executando:\n")
            sys.stderr.write(f"      sudo -u postgres psql -c \"CREATE USER {settings.postgres_user} WITH PASSWORD '{settings.postgres_password}'; GRANT ALL PRIVILEGES ON DATABASE {settings.postgres_db} TO {settings.postgres_user};\"\n")

        elif "could not connect to server" in err_msg.lower() or "connection refused" in err_msg.lower():
            sys.stderr.write("   👉 MOTIVO: O serviço do PostgreSQL não está rodando no servidor ou não escuta na porta configurada.\n")
            sys.stderr.write("   🛠️ CORREÇÃO: Verifique o status do serviço PostgreSQL com:\n")
            sys.stderr.write("      sudo systemctl status postgresql\n")
            sys.stderr.write("      sudo systemctl start postgresql\n")

        else:
            sys.stderr.write("   👉 MOTIVO: Erro inesperado ao executar Base.metadata.create_all.\n")
            sys.stderr.write("   🛠️ CORREÇÃO: Verifique os parâmetros no .env e as permissões de acesso ao banco de dados relacional.\n")

        sys.stderr.write("=" * 80 + "\n\n")
        sys.stderr.flush()
        raise exc


async def main():
    await create_database_if_not_exists()
    await init_tables()


if __name__ == "__main__":
    asyncio.run(main())
