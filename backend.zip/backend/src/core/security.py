import hashlib
import os
import secrets
from typing import Optional, Tuple

import firebase_admin
from firebase_admin import auth, credentials
from fastapi import Depends, HTTPException, Security, status
from fastapi.security import APIKeyHeader, HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from src.core.config import settings
from src.core.database import get_db
from src.models import Sonda, Usuario


# =============================================================================
# INICIALIZAÇÃO DO FIREBASE ADMIN SDK
# =============================================================================
def _init_firebase_admin():
    """Inicializa o Firebase Admin SDK apenas uma vez (singleton)."""
    if not firebase_admin._apps:
        cred_path = settings.firebase_credentials_path
        if os.path.exists(cred_path):
            cred = credentials.Certificate(cred_path)
            firebase_admin.initialize_app(cred)
        else:
            # Fallback para desenvolvimento local sem arquivo de chave de serviço
            firebase_admin.initialize_app(options={"projectId": settings.firebase_project_id})


_init_firebase_admin()

# Esquemas de Segurança FastAPI
bearer_scheme = HTTPBearer(auto_error=True)
api_key_header = APIKeyHeader(name="X-API-Key", auto_error=True)


# =============================================================================
# UTILITÁRIOS DE SEGURANÇA E API KEY IOT (SHA-256)
# =============================================================================
def generate_api_key(prefix: str = "sb_live_") -> Tuple[str, str]:
    """
    Gera uma chave API pura (exibida apenas 1x) e seu respectivo hash SHA-256.
    Retorna: (raw_key, hashed_key)
    """
    raw_key = f"{prefix}{secrets.token_hex(24)}"
    hashed_key = hash_api_key(raw_key)
    return raw_key, hashed_key


def hash_api_key(raw_key: str) -> str:
    """Calcula o hash SHA-256 hexadecimal da chave API recebida."""
    return hashlib.sha256(raw_key.encode("utf-8")).hexdigest()


# =============================================================================
# DEPENDÊNCIAS DE AUTENTICAÇÃO IOT (SONDA / ESP32)
# =============================================================================
async def get_current_sonda(
    x_api_key: str = Security(api_key_header),
    db: AsyncSession = Depends(get_db),
) -> Sonda:
    """
    Injeção de dependência para rotas IoT (/api/v1/probe/*).
    Valida a API Key recebida no cabeçalho X-API-Key contra o hash SHA-256 salvo no banco.
    """
    if not x_api_key:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={
                "error_code": "UNAUTHORIZED",
                "message": "Cabeçalho X-API-Key ausente",
                "details": [],
            },
        )

    hashed_key = hash_api_key(x_api_key)
    stmt = select(Sonda).where(
        Sonda.api_key_hash == hashed_key,
        Sonda.ativo.is_(True),
        Sonda.deleted_at.is_(None),
    )
    result = await db.execute(stmt)
    sonda = result.scalar_one_or_none()

    if not sonda:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={
                "error_code": "UNAUTHORIZED",
                "message": "API Key inválida ou sonda inativa",
                "details": [],
            },
        )

    return sonda


# =============================================================================
# DEPENDÊNCIAS DE AUTENTICAÇÃO DE USUÁRIO (FIREBASE AUTH)
# =============================================================================
async def get_current_user(
    auth_credentials: HTTPAuthorizationCredentials = Depends(bearer_scheme),
    db: AsyncSession = Depends(get_db),
) -> Usuario:
    """
    Injeção de dependência para rotas protegidas (/api/v1/*).
    Valida o token JWT Bearer do Firebase Auth. Se o usuário não existir no banco local,
    cria automaticamente a conta inicial com perfil_completo = False.
    """
    token = auth_credentials.credentials

    # 1. Autenticação Direta Mestre via APP_API_KEY (.env)
    if settings.app_api_key and token == settings.app_api_key:
        master_uid = "user_teste_demo_123"
        stmt = select(Usuario).where(Usuario.id == master_uid, Usuario.deleted_at.is_(None))
        result = await db.execute(stmt)
        user = result.scalar_one_or_none()

        if not user:
            user = Usuario(
                id=master_uid,
                email="produtor.teste@exemplo.com",
                nome="João Silva (Produtor Mestre)",
                perfil_completo=True,
            )
            db.add(user)
            await db.commit()
            await db.refresh(user)

        return user

    # 2. Autenticação Padrão via Firebase Auth (JWT)
    try:
        # Decodifica e valida o token Firebase JWT
        decoded_token = auth.verify_id_token(token)
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={
                "error_code": "INVALID_TOKEN",
                "message": "Token de autenticação inválido ou expirado",
                "details": [{"reason": str(exc)}],
            },
        )

    uid = decoded_token.get("uid")
    email = decoded_token.get("email", "")

    if not uid:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={
                "error_code": "INVALID_TOKEN",
                "message": "UID ausente no token fornecido",
                "details": [],
            },
        )

    # Consulta o usuário no banco de dados relacional local
    stmt = select(Usuario).where(Usuario.id == uid, Usuario.deleted_at.is_(None))
    result = await db.execute(stmt)
    user = result.scalar_one_or_none()

    # Se o usuário autenticado no Firebase ainda não estiver salvo no banco, cria o registro inicial
    if not user:
        nome_inicial = email.split("@")[0] if email else f"Produtor_{uid[:8]}"
        user = Usuario(
            id=uid,
            email=email,
            nome=nome_inicial,
            perfil_completo=False,
            status=True,
        )
        db.add(user)
        await db.commit()
        await db.refresh(user)

    if not user.status:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "error_code": "USER_DISABLED",
                "message": "Conta de usuário desativada",
                "details": [],
            },
        )

    return user


async def get_current_user_complete(
    current_user: Usuario = Depends(get_current_user),
) -> Usuario:
    """
    Dependência que bloqueia o acesso ao dashboard caso o onboarding de usuário esteja pendente.
    """
    if not current_user.perfil_completo:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "error_code": "ONBOARDING_REQUIRED",
                "message": "Perfil incompleto. Por favor, conclua o onboarding antes de acessar o dashboard.",
                "details": [],
            },
        )
    return current_user
