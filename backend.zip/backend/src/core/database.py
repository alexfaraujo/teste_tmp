from typing import AsyncGenerator
from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy.orm import DeclarativeBase

from src.core.config import settings


# Base declarativa para todos os modelos ORM SQLAlchemy 2.0
class Base(DeclarativeBase):
    pass


# Engine assíncrono conectado ao PostgreSQL via asyncpg
engine: AsyncEngine = create_async_engine(
    settings.database_url,
    echo=settings.debug,
    future=True,
    pool_pre_ping=True,
)

# Fábrica de sessões assíncronas
AsyncSessionLocal = async_sessionmaker(
    bind=engine,
    class_=AsyncSession,
    expire_on_commit=False,
    autoflush=False,
)


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """
    Injeção de dependência do FastAPI para gerenciamento seguro de sessões assíncronas.
    Garante o encerramento da conexão (db.close()) e previne vazamentos de conexões/recursos.
    """
    async with AsyncSessionLocal() as session:
        try:
            yield session
        finally:
            await session.close()
