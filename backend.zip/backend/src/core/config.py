import os
from urllib.parse import quote_plus
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """
    Configurações centralizadas da aplicação carregadas exclusivamente a partir de variáveis de ambiente (.env).
    Garante tipo estático, validação Pydantic v2 e zero segredos hardcoded no código.
    Trata automaticamente caracteres especiais em senhas (ex: @, #, $, /) via urllib.parse.quote_plus.
    """
    # Aplicação FastAPI
    project_name: str = "Backend de Irrigacao Inteligente"
    environment: str = "development"
    debug: bool = True
    host: str = "0.0.0.0"
    port: int = 2065

    # Chave Mestre de Autenticação da Aplicação Web (Carregada via .env)
    app_api_key: str = ""

    # Configurações de Conexão com o Banco de Dados PostgreSQL (Carregadas via .env)
    postgres_server: str = "127.0.0.1"
    postgres_port: int = 5432
    postgres_user: str = "irrigacao_user"
    postgres_password: str = ""
    postgres_db: str = "irrigacao_db"
    database_url: str = ""

    # Autenticação Firebase (Carregado via .env)
    firebase_project_id: str = ""
    firebase_api_key: str = ""
    firebase_auth_domain: str = ""
    firebase_storage_bucket: str = ""
    firebase_messaging_sender_id: str = ""
    firebase_app_id: str = ""
    firebase_credentials_path: str = "firebase_credentials.json"

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore"
    )

    def model_post_init(self, __context):
        if not self.database_url:
            encoded_user = quote_plus(self.postgres_user) if self.postgres_user else ""
            encoded_password = quote_plus(self.postgres_password) if self.postgres_password else ""
            self.database_url = f"postgresql+asyncpg://{encoded_user}:{encoded_password}@{self.postgres_server}:{self.postgres_port}/{self.postgres_db}"


# Instância única global de configurações
settings = Settings()
