# Módulo de configurações e infraestrutura core
