import uuid
from datetime import datetime
from typing import List, Optional
from sqlalchemy import (
    BIGINT,
    VARCHAR,
    Boolean,
    DateTime,
    Float,
    ForeignKey,
    Index,
    Integer,
    String,
    func,
    text,
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from src.core.database import Base


class Usuario(Base):
    """
    Modelo ORM mapeado para a tabela 'usuarios'.
    Representa os produtores autenticados via Firebase Auth (UID).
    """
    __tablename__ = "usuarios"

    id: Mapped[str] = mapped_column(VARCHAR(128), primary_key=True)  # Firebase UID
    email: Mapped[str] = mapped_column(VARCHAR(255), unique=True, nullable=False)
    nome: Mapped[str] = mapped_column(VARCHAR(255), nullable=False)
    perfil_completo: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    status: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    deleted_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True, default=None
    )

    # Relacionamento 1:N com Sonda
    sondas: Mapped[List["Sonda"]] = relationship(
        "Sonda", back_populates="usuario", lazy="selectin"
    )


class Sonda(Base):
    """
    Modelo ORM mapeado para a tabela 'sondas'.
    Representa o nó físico integrado em campo (sensor + válvula) e seus limiares.
    """
    __tablename__ = "sondas"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    usuario_id: Mapped[str] = mapped_column(
        VARCHAR(128), ForeignKey("usuarios.id"), nullable=False, index=True
    )
    nome_identificador: Mapped[str] = mapped_column(VARCHAR(100), nullable=False)
    codigo_hardware: Mapped[Optional[str]] = mapped_column(
        VARCHAR(64), unique=True, nullable=True, default=None, index=True
    )
    api_key_hash: Mapped[str] = mapped_column(VARCHAR(64), unique=True, nullable=False, index=True)
    api_key_prefix: Mapped[str] = mapped_column(VARCHAR(8), nullable=False)
    irrigacao_diurna: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    indice_irrigar: Mapped[float] = mapped_column(Float, default=35.0, nullable=False)
    intervalo_envio_segundos: Mapped[int] = mapped_column(Integer, default=600, nullable=False)
    ativo: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False
    )
    deleted_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True, default=None
    )

    # Relacionamentos (logs usa lazy="noload" por padrão para evitar pré-carregamento em memória de séries temporais)
    usuario: Mapped["Usuario"] = relationship("Usuario", back_populates="sondas")
    logs: Mapped[List["LogSonda"]] = relationship(
        "LogSonda", back_populates="sonda", lazy="noload"
    )


class LogSonda(Base):
    """
    Modelo ORM mapeado para a tabela 'logs_sondas'.
    Armazena a série temporal de leituras de telemetria recebidas.
    """
    __tablename__ = "logs_sondas"
    __table_args__ = (
        Index(
            "idx_logs_sonda_received",
            "sonda_id",
            text("received_at DESC"),
            postgresql_where=text("deleted_at IS NULL"),
        ),
    )

    id: Mapped[int] = mapped_column(BIGINT, primary_key=True, autoincrement=True)
    sonda_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("sondas.id"), nullable=False, index=True
    )
    nivel_bateria: Mapped[float] = mapped_column(Float, nullable=False)
    temperatura: Mapped[float] = mapped_column(Float, nullable=False)
    umidade_bruta: Mapped[int] = mapped_column(Integer, nullable=False)
    indice_umidade: Mapped[float] = mapped_column(Float, nullable=False)
    received_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False, index=True
    )
    deleted_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True, default=None
    )

    # Relacionamento com Sonda
    sonda: Mapped["Sonda"] = relationship("Sonda", back_populates="logs")
