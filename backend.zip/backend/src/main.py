import logging
from fastapi import FastAPI, HTTPException, Request, status
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from src.core.config import settings
from src.routers import dashboard, iot, users

# Configuração básica de logs
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("irrigacao_backend")

app = FastAPI(
    title=settings.project_name,
    version="1.0.0",
    description="API RESTful assíncrona para telemetria IoT de sondas agrícolas e dashboard de irrigação.",
    docs_url="/docs",
    redoc_url="/redoc",
)

# Configuração de CORS para permitir requisições do frontend web
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Inclusão dos roteadores por domínio
app.include_router(iot.router)
app.include_router(users.router)
app.include_router(dashboard.router)


# =============================================================================
# HANDLERS GLOBAIS DE EXCEÇÕES (PADRONIZAÇÃO EM SNAKE_CASE)
# =============================================================================
@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    """Padroniza exceções HTTP no formato ErrorResponseSchema."""
    if isinstance(exc.detail, dict) and "error_code" in exc.detail:
        return JSONResponse(status_code=exc.status_code, content=exc.detail)
    
    status_code = exc.status_code
    detail_str = str(exc.detail)

    if detail_str in ["Not authenticated", "Could not validate credentials"]:
        status_code = status.HTTP_401_UNAUTHORIZED
        error_code = "UNAUTHORIZED"
        message = "Não autenticado ou token ausente"
    elif status_code == status.HTTP_401_UNAUTHORIZED:
        error_code = "UNAUTHORIZED"
        message = detail_str
    elif status_code == status.HTTP_403_FORBIDDEN:
        error_code = "FORBIDDEN"
        message = detail_str
    elif status_code == status.HTTP_404_NOT_FOUND:
        error_code = "NOT_FOUND"
        message = detail_str
    else:
        error_code = "HTTP_ERROR"
        message = detail_str

    return JSONResponse(
        status_code=status_code,
        content={
            "error_code": error_code,
            "message": message,
            "details": [],
        },
    )


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    """Padroniza erros de validação Pydantic v2 / FastAPI."""
    errors = []
    for err in exc.errors():
        loc = " -> ".join([str(l) for l in err.get("loc", [])])
        msg = err.get("msg", "")
        errors.append({"field": loc, "error": msg})

    return JSONResponse(
        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        content={
            "error_code": "VALIDATION_ERROR",
            "message": "Parâmetros ou payload de requisição inválidos",
            "details": errors,
        },
    )


@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """Captura exceções não tratadas prevenindo vazamento de rastros de pilha."""
    logger.error(f"Exceção não tratada na rota {request.url}: {exc}", exc_info=True)
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={
            "error_code": "INTERNAL_SERVER_ERROR",
            "message": "Erro interno inesperado no servidor",
            "details": [],
        },
    )


# =============================================================================
# ROTA DE VERIFICAÇÃO DE SAÚDE (HEALTHCHECK)
# =============================================================================
@app.get("/", tags=["Healthcheck"])
async def root_healthcheck():
    return {
        "status": "online",
        "app_name": settings.project_name,
        "environment": settings.environment,
        "docs": "/docs",
    }
