import asyncio
import csv
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional
from uuid import UUID, uuid5, NAMESPACE_DNS

from sqlalchemy import select, text
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine

from src.core.config import settings
from src.core.init_db import create_database_if_not_exists, init_tables
from src.core.security import generate_api_key
from src.models import LogSonda, Sonda, Usuario

# Caminho padrão relativo à raiz do monorepo
DEFAULT_CSV_PATH = (
    Path(__file__).resolve().parents[3] / "dataset-2-import" / "leiturasSensor_rows.csv"
)

# Metadados padrão para cadastro automático das sondas identificadas pelo MAC/rádio do dataset
HARDWARE_PROBES_METADATA: Dict[str, str] = {
    "164:207:18:255:59:": "Sonda Campus IFMS 01 (164:207:18:255:59:)",
    "72:63:218:96:82:": "Sonda Campus IFMS 02 (72:63:218:96:82:)",
}


def impute_indice_umidade(umidade_bruta: int) -> float:
    """
    Calcula o índice de umidade calibrado pela equação linear do sensor em campo
    quando o valor estiver ausente no CSV (Opção B1).
    """
    return round((umidade_bruta - 428) / 2.95, 2)


def parse_timestamp_utc(raw_dt: str) -> datetime:
    """Converte string dataHora do CSV para datetime timezone-aware em UTC."""
    dt = datetime.fromisoformat(raw_dt.strip())
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt


def parse_and_prepare_csv_rows(
    csv_path: Path,
    sonda_uuid_map: Dict[str, UUID],
) -> List[Dict[str, Any]]:
    """
    Lê o arquivo CSV de telemetria legada (camelCase), converte para snake_case
    e aplica o tratamento de anomalias da Opção B1:
      - Preserva 100% dos valores originais de indiceUmidade (incluindo < 0 e > 100).
      - Imputa os 2 registros com indiceUmidade vazio via fórmula linear da sonda.
      - Imputa os 8 registros iniciais sem dataHora com timestamps sequenciais imediatamente
        anteriores à primeira leitura datada (2026-09-05 13:30:02 UTC).
    """
    with open(csv_path, mode="r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        raw_rows = list(reader)

    # Localiza o primeiro timestamp válido do dataset para ancorar as linhas iniciais sem dataHora
    first_valid_dt: Optional[datetime] = None
    for row in raw_rows:
        if row.get("dataHora") and row["dataHora"].strip():
            first_valid_dt = parse_timestamp_utc(row["dataHora"])
            break

    if first_valid_dt is None:
        first_valid_dt = datetime.now(timezone.utc)

    # Conta quantas linhas iniciais não possuem dataHora para espaçá-las em ordem cronológica
    missing_dt_indices = [
        idx
        for idx, r in enumerate(raw_rows)
        if not r.get("dataHora") or not r["dataHora"].strip()
    ]
    total_missing_dt = len(missing_dt_indices)
    missing_dt_rank = {
        row_idx: rank for rank, row_idx in enumerate(missing_dt_indices)
    }

    prepared_rows: List[Dict[str, Any]] = []

    for idx, row in enumerate(raw_rows):
        codigo_hw = row["sondaId"].strip()
        if codigo_hw not in sonda_uuid_map:
            raise ValueError(f"Código de hardware não mapeado: {codigo_hw}")

        row_id = int(row["id"].strip())
        nivel_bateria = float(row["nivelBateria"].strip())
        temperatura = float(row["temperatura"].strip())
        umidade_bruta = int(row["umidadeBruta"].strip())

        raw_indice = row.get("indiceUmidade", "").strip()
        if raw_indice == "":
            indice_umidade = impute_indice_umidade(umidade_bruta)
        else:
            indice_umidade = float(raw_indice)

        raw_dt = row.get("dataHora", "").strip()
        if raw_dt == "":
            # Imputa timestamps retroativos espaçados em 1 minuto antes da primeira leitura com data
            minutes_before = total_missing_dt - missing_dt_rank[idx]
            received_at = first_valid_dt - timedelta(minutes=minutes_before)
        else:
            received_at = parse_timestamp_utc(raw_dt)

        prepared_rows.append(
            {
                "id": row_id,
                "sonda_id": sonda_uuid_map[codigo_hw],
                "nivel_bateria": nivel_bateria,
                "temperatura": temperatura,
                "umidade_bruta": umidade_bruta,
                "indice_umidade": indice_umidade,
                "received_at": received_at,
                "deleted_at": None,
            }
        )

    return prepared_rows


async def import_csv_dataset(csv_path: Path = DEFAULT_CSV_PATH) -> int:
    """
    Executa a carga completa e idempotente do dataset CSV para o PostgreSQL local.
    Retorna o total de linhas processadas do dataset.
    """
    if not csv_path.exists():
        raise FileNotFoundError(f"Arquivo CSV não encontrado em: {csv_path}")

    await create_database_if_not_exists()
    await init_tables()

    engine = create_async_engine(settings.database_url, echo=False)
    async_session = async_sessionmaker(engine, expire_on_commit=False)

    async with async_session() as session:
        # 1. Garante usuário padrão proprietário das sondas importadas
        user_id = "user_teste_demo_123"
        user = await session.get(Usuario, user_id)
        if not user:
            user = Usuario(
                id=user_id,
                email="produtor.teste@exemplo.com",
                nome="Gestor Campus IFMS",
                perfil_completo=True,
                status=True,
            )
            session.add(user)
            await session.commit()

        # 2. Descobre todos os códigos de hardware únicos presentes no CSV
        with open(csv_path, mode="r", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            unique_hw_codes = sorted({r["sondaId"].strip() for r in reader if r.get("sondaId")})

        sonda_uuid_map: Dict[str, UUID] = {}

        # 3. Garante o registro de cada sonda pelo codigo_hardware (Opção A2)
        for idx, hw_code in enumerate(unique_hw_codes, start=1):
            stmt = select(Sonda).where(Sonda.codigo_hardware == hw_code)
            result = await session.execute(stmt)
            sonda = result.scalar_one_or_none()

            if not sonda:
                raw_key, hashed_key = generate_api_key(prefix="sb_live_")
                deterministic_uuid = uuid5(NAMESPACE_DNS, f"irrigacao-smart-sonda-{hw_code}")
                nome = HARDWARE_PROBES_METADATA.get(
                    hw_code, f"Sonda Campus IFMS {idx:02d} ({hw_code})"
                )
                sonda = Sonda(
                    id=deterministic_uuid,
                    usuario_id=user.id,
                    nome_identificador=nome,
                    codigo_hardware=hw_code,
                    api_key_hash=hashed_key,
                    api_key_prefix=raw_key[:8],
                    irrigacao_diurna=False,
                    indice_irrigar=35.0,
                    intervalo_envio_segundos=1800,
                    ativo=True,
                )
                session.add(sonda)
                await session.commit()
                await session.refresh(sonda)
                print(
                    f"✅ Sonda criada: {sonda.nome_identificador} | UUID: {sonda.id} | MAC: {sonda.codigo_hardware} | API Key: {raw_key}"
                )
            else:
                print(
                    f"ℹ️ Sonda já cadastrada: {sonda.nome_identificador} | UUID: {sonda.id} | MAC: {sonda.codigo_hardware}"
                )

            sonda_uuid_map[hw_code] = sonda.id

        # 4. Prepara os registros aplicando a Opção B1
        prepared_rows = parse_and_prepare_csv_rows(csv_path, sonda_uuid_map)

        # 5. Inserção em lotes (batch insert) idempotente via ON CONFLICT (id) DO NOTHING
        batch_size = 2000
        for start in range(0, len(prepared_rows), batch_size):
            batch = prepared_rows[start : start + batch_size]
            stmt = (
                pg_insert(LogSonda)
                .values(batch)
                .on_conflict_do_nothing(index_elements=["id"])
            )
            await session.execute(stmt)

        await session.commit()

        # 6. Sincroniza a sequence BIGSERIAL do PostgreSQL com o maior ID importado
        await session.execute(
            text(
                "SELECT setval(pg_get_serial_sequence('logs_sondas', 'id'), COALESCE((SELECT MAX(id) FROM logs_sondas), 1), true);"
            )
        )
        await session.commit()

        print(
            f"🎉 Importação concluída com sucesso! {len(prepared_rows)} leituras processadas no PostgreSQL."
        )

    await engine.dispose()
    return len(prepared_rows)


if __name__ == "__main__":
    asyncio.run(import_csv_dataset())
