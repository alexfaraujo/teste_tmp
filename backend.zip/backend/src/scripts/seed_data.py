import asyncio
from uuid import uuid4
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker

from src.core.config import settings
from src.core.security import hash_api_key
from src.models import Usuario, Sonda, LogSonda


async def seed():
    engine = create_async_engine(settings.database_url, echo=False)
    async_session = async_sessionmaker(engine, expire_on_commit=False)

    async with async_session() as session:
        # 1. Cria ou reutiliza usuário de teste
        user_id = "user_teste_demo_123"
        user = await session.get(Usuario, user_id)

        if not user:
            user = Usuario(
                id=user_id,
                email="produtor.teste@exemplo.com",
                nome="João Silva (Produtor Rural)",
                perfil_completo=True,
            )
            session.add(user)
            await session.commit()
            print(f"✅ Usuário de teste criado: {user.email} (ID: {user.id})")
        else:
            print(f"ℹ️ Usuário de teste já existia: {user.email}")

        # 2. Cria sonda de teste com API Key conhecida
        api_key_pura = "sb_live_1234567890abcdef12345678"
        key_hash = hash_api_key(api_key_pura)

        sonda = Sonda(
            id=uuid4(),
            usuario_id=user.id,
            nome_identificador="Sonda Talhão 01 - Pivô Central",
            api_key_hash=key_hash,
            api_key_prefix="sb_live_",  # Exatamente 8 caracteres
            irrigacao_diurna=False,
            indice_irrigar=35.0,
            intervalo_envio_segundos=600,
            ativo=True,
        )
        session.add(sonda)
        await session.commit()

        print("\n" + "=" * 75)
        print("🎉 DADOS DE TESTE GERADOS COM SUCESSO NO POSTGRESQL LOCAL!")
        print("=" * 75)
        print("\n📌 VALORES EXATOS PARA USAR NO SWAGGER UI (http://localhost:8000/docs):\n")
        print("1️⃣ TESTAR ROTAS IOT (/api/v1/probe/*):")
        print(f"   • X-API-Key (copiar e colar no Authorize do Swagger):")
        print(f"     {api_key_pura}")
        print("\n2️⃣ CONSULTAR/ALTERAR SONDA CRIADA (/api/v1/probes/{id}):")
        print(f"   • sonda_id (copiar e colar no campo sonda_id do Swagger):")
        print(f"     {sonda.id}")
        print("=" * 75 + "\n")

    await engine.dispose()


if __name__ == "__main__":
    asyncio.run(seed())
