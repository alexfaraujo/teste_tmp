# Script de carga inicial e dados de teste local
