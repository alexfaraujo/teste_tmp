import math
from datetime import datetime, timezone
from typing import Dict, List, Optional
from uuid import UUID

from fastapi import HTTPException, status
from sqlalchemy import func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from src.core.security import generate_api_key
from src.models import LogSonda, Sonda, Usuario
from src.schemas import (
    DashboardSummarySchema,
    LogSondaResponseSchema,
    PaginatedLogsResponseSchema,
    PaginationMetadataSchema,
    ProbeConfigSchema,
    SondaCreateResponseSchema,
    SondaCreateSchema,
    SondaResponseSchema,
    SondaUpdateConfigSchema,
    TelemetryCreateSchema,
    TelemetryResponsePiggybackSchema,
    UsuarioResponseSchema,
    UsuarioUpdateSchema,
)


# =============================================================================
# HELPER DE RESOLUÇÃO DINÂMICA DE CONECTIVIDADE E BATERIA (OTIMIZADO O(1))
# =============================================================================
async def _get_latest_logs_by_sonda_ids(
    db: AsyncSession, sonda_ids: List[UUID]
) -> Dict[UUID, LogSonda]:
    """
    Busca exclusivamente o último log ativo de cada sonda diretamente no PostgreSQL
    utilizando DISTINCT ON (sonda_id) e o índice composto (sonda_id, received_at DESC).
    Evita o carregamento de milhares de registros históricos em memória RAM.
    """
    if not sonda_ids:
        return {}

    stmt = (
        select(LogSonda)
        .distinct(LogSonda.sonda_id)
        .where(
            LogSonda.sonda_id.in_(sonda_ids),
            LogSonda.deleted_at.is_(None),
        )
        .order_by(LogSonda.sonda_id, LogSonda.received_at.desc())
    )
    result = await db.execute(stmt)
    ultimos_logs = result.scalars().all()
    return {log.sonda_id: log for log in ultimos_logs}


def _build_sonda_response(
    sonda: Sonda, ultimo_log: Optional[LogSonda] = None
) -> SondaResponseSchema:
    """
    Computa o status de conectividade e o alerta de bateria em tempo de execução
    a partir do último log registrado para a sonda.
    """
    now = datetime.now(timezone.utc)

    # Fallback para testes unitários em memória que atribuem sonda.logs diretamente
    if ultimo_log is None:
        loaded_logs = sonda.__dict__.get("logs")
        if loaded_logs:
            ultimo_log = max(loaded_logs, key=lambda l: l.received_at)

    status_conectividade = "sem_dados"
    alerta_bateria = False

    if ultimo_log is not None:
        tolerancia_segundos = sonda.intervalo_envio_segundos * 1.5

        # Garante timezone aware no cálculo de diferença
        received_at = ultimo_log.received_at
        if received_at.tzinfo is None:
            received_at = received_at.replace(tzinfo=timezone.utc)

        diff_segundos = (now - received_at).total_seconds()

        if diff_segundos <= tolerancia_segundos:
            status_conectividade = "online"
        else:
            status_conectividade = "offline"

        if ultimo_log.nivel_bateria < 20.0:
            alerta_bateria = True

    created_at = sonda.created_at or now
    updated_at = sonda.updated_at or now

    return SondaResponseSchema(
        id=sonda.id,
        usuario_id=sonda.usuario_id,
        nome_identificador=sonda.nome_identificador,
        codigo_hardware=getattr(sonda, "codigo_hardware", None),
        api_key_prefix=sonda.api_key_prefix,
        irrigacao_diurna=sonda.irrigacao_diurna,
        indice_irrigar=sonda.indice_irrigar,
        intervalo_envio_segundos=sonda.intervalo_envio_segundos,
        ativo=sonda.ativo,
        status_conectividade=status_conectividade,
        alerta_bateria=alerta_bateria,
        created_at=created_at,
        updated_at=updated_at,
    )


# =============================================================================
# SERVIÇO DE USUÁRIO (PRODUTOR RURAL)
# =============================================================================
class UsuarioService:
    @staticmethod
    async def get_user_profile(user: Usuario) -> UsuarioResponseSchema:
        return UsuarioResponseSchema.model_validate(user)

    @staticmethod
    async def update_user_profile(
        db: AsyncSession, user: Usuario, update_dto: UsuarioUpdateSchema
    ) -> UsuarioResponseSchema:
        user.nome = update_dto.nome
        user.perfil_completo = True
        user.updated_at = datetime.now(timezone.utc)

        db.add(user)
        await db.commit()
        await db.refresh(user)

        return UsuarioResponseSchema.model_validate(user)


# =============================================================================
# SERVIÇO IOT & TELEMETRIA (SONDA / ESP32)
# =============================================================================
class IoTService:
    @staticmethod
    async def get_probe_config(sonda: Sonda) -> ProbeConfigSchema:
        return ProbeConfigSchema(
            irrigacao_diurna=sonda.irrigacao_diurna,
            indice_irrigar=sonda.indice_irrigar,
            intervalo_envio_segundos=sonda.intervalo_envio_segundos,
        )

    @staticmethod
    async def process_telemetry(
        db: AsyncSession, sonda: Sonda, telemetry_dto: TelemetryCreateSchema
    ) -> TelemetryResponsePiggybackSchema:
        now = datetime.now(timezone.utc)

        # Cria a série temporal de telemetria
        log = LogSonda(
            sonda_id=sonda.id,
            nivel_bateria=telemetry_dto.nivel_bateria,
            temperatura=telemetry_dto.temperatura,
            umidade_bruta=telemetry_dto.umidade_bruta,
            indice_umidade=telemetry_dto.indice_umidade,
            received_at=now,
        )

        db.add(log)
        await db.commit()
        await db.refresh(log)

        # Monta a resposta com piggybacking dos parâmetros operacionais atualizados
        config = await IoTService.get_probe_config(sonda)
        return TelemetryResponsePiggybackSchema(
            status="success",
            received_at=log.received_at,
            config=config,
        )


# =============================================================================
# SERVIÇO DE GERENCIAMENTO DE SONDAS (DASHBOARD)
# =============================================================================
class SondaService:
    @staticmethod
    async def create_sonda(
        db: AsyncSession, user_id: str, sonda_dto: SondaCreateSchema
    ) -> SondaCreateResponseSchema:
        # Gera chave API pura e seu hash SHA-256
        raw_key, hashed_key = generate_api_key(prefix="sb_live_")
        api_key_prefix = raw_key[:8]

        sonda = Sonda(
            usuario_id=user_id,
            nome_identificador=sonda_dto.nome_identificador,
            codigo_hardware=sonda_dto.codigo_hardware,
            api_key_hash=hashed_key,
            api_key_prefix=api_key_prefix,
            irrigacao_diurna=sonda_dto.irrigacao_diurna,
            indice_irrigar=sonda_dto.indice_irrigar,
            intervalo_envio_segundos=sonda_dto.intervalo_envio_segundos,
            ativo=True,
        )

        db.add(sonda)
        await db.commit()
        await db.refresh(sonda)

        base_response = _build_sonda_response(sonda, ultimo_log=None)
        response_dict = base_response.model_dump()
        response_dict["api_key"] = raw_key

        return SondaCreateResponseSchema(**response_dict)

    @staticmethod
    async def list_sondas_by_user(
        db: AsyncSession,
        user_id: str,
        status_filter: str = "todos",
        alerta_bateria_filter: str = "todos",
        busca: Optional[str] = None,
    ) -> List[SondaResponseSchema]:
        stmt = select(Sonda).where(
            Sonda.usuario_id == user_id, Sonda.deleted_at.is_(None)
        )

        if busca:
            stmt = stmt.where(
                or_(
                    Sonda.nome_identificador.ilike(f"%{busca}%"),
                    Sonda.codigo_hardware.ilike(f"%{busca}%"),
                )
            )

        result = await db.execute(stmt)
        sondas = result.scalars().all()

        ultimos_logs_map = await _get_latest_logs_by_sonda_ids(
            db, [s.id for s in sondas]
        )
        responses = [
            _build_sonda_response(s, ultimo_log=ultimos_logs_map.get(s.id))
            for s in sondas
        ]

        # Filtragem em memória dos valores computados dinamicamente
        if status_filter != "todos":
            responses = [r for r in responses if r.status_conectividade == status_filter]

        if alerta_bateria_filter == "apenas_alertas":
            responses = [r for r in responses if r.alerta_bateria is True]

        return responses

    @staticmethod
    async def get_sonda_by_id(
        db: AsyncSession, user_id: str, sonda_id: UUID
    ) -> SondaResponseSchema:
        stmt = select(Sonda).where(
            Sonda.id == sonda_id,
            Sonda.usuario_id == user_id,
            Sonda.deleted_at.is_(None),
        )
        result = await db.execute(stmt)
        sonda = result.scalar_one_or_none()

        if not sonda:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail={
                    "error_code": "ENTITY_NOT_FOUND",
                    "message": "Sonda não encontrada ou não pertence ao usuário",
                    "details": [],
                },
            )

        ultimos_logs_map = await _get_latest_logs_by_sonda_ids(db, [sonda.id])
        return _build_sonda_response(sonda, ultimo_log=ultimos_logs_map.get(sonda.id))

    @staticmethod
    async def update_sonda_config(
        db: AsyncSession,
        user_id: str,
        sonda_id: UUID,
        config_dto: SondaUpdateConfigSchema,
    ) -> SondaResponseSchema:
        stmt = select(Sonda).where(
            Sonda.id == sonda_id,
            Sonda.usuario_id == user_id,
            Sonda.deleted_at.is_(None),
        )
        result = await db.execute(stmt)
        sonda = result.scalar_one_or_none()

        if not sonda:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail={
                    "error_code": "ENTITY_NOT_FOUND",
                    "message": "Sonda não encontrada para atualização",
                    "details": [],
                },
            )

        if config_dto.codigo_hardware is not None:
            sonda.codigo_hardware = config_dto.codigo_hardware
        if config_dto.irrigacao_diurna is not None:
            sonda.irrigacao_diurna = config_dto.irrigacao_diurna
        if config_dto.indice_irrigar is not None:
            sonda.indice_irrigar = config_dto.indice_irrigar
        if config_dto.intervalo_envio_segundos is not None:
            sonda.intervalo_envio_segundos = config_dto.intervalo_envio_segundos

        sonda.updated_at = datetime.now(timezone.utc)

        db.add(sonda)
        await db.commit()
        await db.refresh(sonda)

        ultimos_logs_map = await _get_latest_logs_by_sonda_ids(db, [sonda.id])
        return _build_sonda_response(sonda, ultimo_log=ultimos_logs_map.get(sonda.id))

    @staticmethod
    async def soft_delete_sonda(db: AsyncSession, user_id: str, sonda_id: UUID) -> bool:
        stmt = select(Sonda).where(
            Sonda.id == sonda_id,
            Sonda.usuario_id == user_id,
            Sonda.deleted_at.is_(None),
        )
        result = await db.execute(stmt)
        sonda = result.scalar_one_or_none()

        if not sonda:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail={
                    "error_code": "ENTITY_NOT_FOUND",
                    "message": "Sonda não encontrada para remoção",
                    "details": [],
                },
            )

        sonda.deleted_at = datetime.now(timezone.utc)
        sonda.ativo = False

        db.add(sonda)
        await db.commit()

        return True


# =============================================================================
# SERVIÇO DE LOGS DE TELEMETRIA E PAGINAÇÃO
# =============================================================================
class LogService:
    @staticmethod
    async def get_paginated_logs(
        db: AsyncSession,
        user_id: str,
        sonda_id: UUID,
        page: int = 1,
        page_size: int = 20,
        data_inicio: Optional[datetime] = None,
        data_fim: Optional[datetime] = None,
    ) -> PaginatedLogsResponseSchema:
        # Garante pertencimento e existência da sonda sem carregar histórico em memória
        await SondaService.get_sonda_by_id(db, user_id, sonda_id)

        # Monta a query base de contagem e busca filtrando Soft Delete (deleted_at IS NULL)
        base_filters = [
            LogSonda.sonda_id == sonda_id,
            LogSonda.deleted_at.is_(None),
        ]
        count_stmt = select(func.count(LogSonda.id)).where(*base_filters)
        data_stmt = select(LogSonda).where(*base_filters)

        if data_inicio:
            count_stmt = count_stmt.where(LogSonda.received_at >= data_inicio)
            data_stmt = data_stmt.where(LogSonda.received_at >= data_inicio)

        if data_fim:
            count_stmt = count_stmt.where(LogSonda.received_at <= data_fim)
            data_stmt = data_stmt.where(LogSonda.received_at <= data_fim)

        # Executa contagem total de registros
        total_result = await db.execute(count_stmt)
        total_items = total_result.scalar_one()

        # Calcula a paginação sob demanda
        offset = (page - 1) * page_size
        total_pages = math.ceil(total_items / page_size) if total_items > 0 else 0

        data_stmt = (
            data_stmt.order_by(LogSonda.received_at.desc())
            .offset(offset)
            .limit(page_size)
        )
        data_result = await db.execute(data_stmt)
        logs = data_result.scalars().all()

        items = [LogSondaResponseSchema.model_validate(log) for log in logs]
        pagination = PaginationMetadataSchema(
            page=page,
            page_size=page_size,
            total_items=total_items,
            total_pages=total_pages,
        )

        return PaginatedLogsResponseSchema(items=items, pagination=pagination)


# =============================================================================
# SERVIÇO DE DASHBOARD SUMMARY
# =============================================================================
class DashboardService:
    @staticmethod
    async def get_dashboard_summary(
        db: AsyncSession, user_id: str
    ) -> DashboardSummarySchema:
        sondas = await SondaService.list_sondas_by_user(db, user_id)

        total_sondas = len(sondas)
        sondas_online = len([s for s in sondas if s.status_conectividade == "online"])
        sondas_offline = len([s for s in sondas if s.status_conectividade == "offline"])
        alertas_bateria = len([s for s in sondas if s.alerta_bateria is True])

        # Busca as últimas 5 medições ativas de todas as sondas ativas do usuário
        sonda_ids = [s.id for s in sondas]
        ultimas_medicoes: List[LogSondaResponseSchema] = []

        if sonda_ids:
            stmt = (
                select(LogSonda)
                .where(
                    LogSonda.sonda_id.in_(sonda_ids),
                    LogSonda.deleted_at.is_(None),
                )
                .order_by(LogSonda.received_at.desc())
                .limit(5)
            )
            result = await db.execute(stmt)
            logs = result.scalars().all()
            ultimas_medicoes = [LogSondaResponseSchema.model_validate(l) for l in logs]

        return DashboardSummarySchema(
            total_sondas=total_sondas,
            sondas_online=sondas_online,
            sondas_offline=sondas_offline,
            alertas_bateria=alertas_bateria,
            ultimas_medicoes=ultimas_medicoes,
        )
