from datetime import datetime
from typing import Any, Dict, List, Optional
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


# =============================================================================
# SCHEMAS DE ERRO PADRONIZADOS
# =============================================================================
class ErrorResponseSchema(BaseModel):
    """Payload JSON padronizado para exceções e erros HTTP globais."""
    error_code: str = Field(..., json_schema_extra={"example": "ENTITY_NOT_FOUND"})
    message: str = Field(..., json_schema_extra={"example": "Sonda não encontrada ou não pertence ao usuário"})
    details: Optional[List[Dict[str, Any]]] = Field(default=[], json_schema_extra={"example": []})


# =============================================================================
# SCHEMAS DE USUÁRIO (PRODUTOR RURAL)
# =============================================================================
class UsuarioBaseSchema(BaseModel):
    email: str = Field(..., description="E-mail do usuário autenticado no Firebase")
    nome: str = Field(..., min_length=2, max_length=255, description="Nome do produtor rural")


class UsuarioUpdateSchema(BaseModel):
    """DTO para preenchimento de onboarding e atualização de perfil (PUT /api/v1/users/me)."""
    nome: str = Field(..., min_length=2, max_length=255, description="Nome atualizado do produtor")


class UsuarioResponseSchema(UsuarioBaseSchema):
    """DTO de resposta para o perfil do usuário."""
    id: str = Field(..., description="Firebase UID")
    perfil_completo: bool = Field(..., description="Indica se o onboarding foi concluído")
    status: bool = Field(..., description="Status do usuário na plataforma")
    created_at: datetime = Field(..., description="Data/hora de criação do perfil")

    model_config = ConfigDict(from_attributes=True)


# =============================================================================
# SCHEMAS DE CONFIGURAÇÃO E TELEMETRIA IOT (SONDA / ESP32)
# =============================================================================
class ProbeConfigSchema(BaseModel):
    """DTO com limiares operacionais retornados para o microcontrolador ESP32."""
    irrigacao_diurna: bool = Field(..., description="Se True, permite acionar irrigação durante o dia")
    indice_irrigar: float = Field(..., ge=0.0, le=100.0, description="Limiar de umidade (%) para disparo de irrigação")
    intervalo_envio_segundos: int = Field(..., ge=10, description="Intervalo entre leituras de telemetria (segundos)")

    model_config = ConfigDict(from_attributes=True)


class TelemetryCreateSchema(BaseModel):
    """DTO de entrada para submissão de telemetria da sonda (POST /api/v1/probe/telemetry)."""
    nivel_bateria: float = Field(..., ge=0.0, le=100.0, description="Percentual da bateria (0 a 100%) ou tensão")
    temperatura: float = Field(..., ge=-20.0, le=70.0, description="Temperatura ambiente (°C)")
    umidade_bruta: int = Field(..., ge=0, description="Valor analógico bruto retornado pelo conversor ADC")
    indice_umidade: float = Field(..., description="Índice de umidade calibrado (%) calculado pelo sensor em campo")


class TelemetryResponsePiggybackSchema(BaseModel):
    """DTO de resposta de telemetria com piggyback de limiares operacionais (HTTP 201)."""
    status: str = Field(default="success", description="Status do recebimento da telemetria")
    received_at: datetime = Field(..., description="Carimbo de data/hora UTC gerado pelo backend")
    config: ProbeConfigSchema = Field(..., description="Parâmetros operacionais atualizados")


# =============================================================================
# SCHEMAS DE GERENCIAMENTO DE SONDAS (DASHBOARD)
# =============================================================================
class SondaCreateSchema(BaseModel):
    """DTO para cadastro de nova sonda (POST /api/v1/probes)."""
    nome_identificador: str = Field(..., min_length=2, max_length=100, description="Nome de identificação da sonda")
    codigo_hardware: Optional[str] = Field(
        default=None,
        max_length=64,
        description="Identificador físico / endereço MAC ou rádio do hardware da sonda (ex: 164:207:18:255:59:)",
    )
    irrigacao_diurna: bool = Field(default=False, description="Permite irrigação diurna")
    indice_irrigar: float = Field(default=35.0, ge=0.0, le=100.0, description="Limiar de acionamento (%)")
    intervalo_envio_segundos: int = Field(default=600, ge=10, le=86400, description="Intervalo de envio em segundos")


class SondaResponseSchema(BaseModel):
    """DTO de resposta com detalhes da sonda e métricas computadas dinamicamente."""
    id: UUID = Field(..., description="Identificador único da sonda")
    usuario_id: str = Field(..., description="ID do usuário proprietário")
    nome_identificador: str = Field(..., description="Nome de identificação")
    codigo_hardware: Optional[str] = Field(default=None, description="Identificador físico / MAC do hardware da sonda")
    api_key_prefix: str = Field(..., description="Prefixo de identificação da API Key (ex.: sb_live_)")
    irrigacao_diurna: bool = Field(..., description="Permissão de irrigação diurna")
    indice_irrigar: float = Field(..., description="Limiar de acionamento (%)")
    intervalo_envio_segundos: int = Field(..., description="Intervalo de envio em segundos")
    ativo: bool = Field(..., description="Status de ativação da sonda")
    status_conectividade: str = Field(..., description="Resolução dinâmica: online | offline | sem_dados")
    alerta_bateria: bool = Field(..., description="True se a última bateria for < 20.0%")
    created_at: datetime = Field(..., description="Data de cadastro")
    updated_at: datetime = Field(..., description="Data da última alteração de limiares")

    model_config = ConfigDict(from_attributes=True)


class SondaCreateResponseSchema(SondaResponseSchema):
    """DTO de resposta do cadastro de sonda exibindo a API Key pura (exibida apenas uma vez)."""
    api_key: str = Field(..., description="Chave de API gerada pura (guarde em local seguro, exibida apenas 1x)")


class SondaUpdateConfigSchema(BaseModel):
    """DTO para atualização dos limiares de acionamento (PUT /api/v1/probes/{id}/config)."""
    codigo_hardware: Optional[str] = Field(default=None, max_length=64, description="Identificador físico / MAC da sonda")
    irrigacao_diurna: Optional[bool] = Field(default=None, description="Permissão de irrigação diurna")
    indice_irrigar: Optional[float] = Field(default=None, ge=0.0, le=100.0, description="Novo limiar de acionamento")
    intervalo_envio_segundos: Optional[int] = Field(default=None, ge=10, le=86400, description="Novo intervalo em segundos")


# =============================================================================
# SCHEMAS DE HISTÓRICO DE LOGS E PAGINAÇÃO
# =============================================================================
class LogSondaResponseSchema(BaseModel):
    """DTO de resposta para leitura de telemetria individual."""
    id: int = Field(..., description="ID sequencial do log")
    sonda_id: UUID = Field(..., description="UUID da sonda remetente")
    nivel_bateria: float = Field(..., description="Nível de bateria (%)")
    temperatura: float = Field(..., description="Temperatura ambiente (°C)")
    umidade_bruta: int = Field(..., description="Leitura analógica bruta ADC")
    indice_umidade: float = Field(..., description="Índice de umidade calibrado (%)")
    received_at: datetime = Field(..., description="Data/hora UTC do recebimento")

    model_config = ConfigDict(from_attributes=True)


class PaginationMetadataSchema(BaseModel):
    """Metadados de paginação de relatórios e histórico."""
    page: int = Field(..., ge=1, description="Número da página atual")
    page_size: int = Field(..., ge=1, description="Quantidade de itens por página")
    total_items: int = Field(..., ge=0, description="Total de registros encontrados")
    total_pages: int = Field(..., ge=0, description="Total de páginas disponíveis")


class PaginatedLogsResponseSchema(BaseModel):
    """DTO de resposta paginada para o histórico de logs da sonda (GET /api/v1/probes/{id}/logs)."""
    items: List[LogSondaResponseSchema] = Field(..., description="Lista de logs da página atual")
    pagination: PaginationMetadataSchema = Field(..., description="Metadados de paginação")


# =============================================================================
# SCHEMAS DE DASHBOARD SUMMARY
# =============================================================================
class DashboardSummarySchema(BaseModel):
    """DTO de resposta consolidada para a tela inicial da Dashboard (GET /api/v1/dashboard/summary)."""
    total_sondas: int = Field(..., description="Total de sondas cadastradas do usuário")
    sondas_online: int = Field(..., description="Quantidade de sondas com conectividade online")
    sondas_offline: int = Field(..., description="Quantidade de sondas offline")
    alertas_bateria: int = Field(..., description="Quantidade de sondas com alerta de bateria baixa (< 20%)")
    ultimas_medicoes: List[LogSondaResponseSchema] = Field(..., description="Últimas medições registradas")
