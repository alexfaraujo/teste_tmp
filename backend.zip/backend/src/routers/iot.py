from fastapi import APIRouter, Depends, status
from sqlalchemy.ext.asyncio import AsyncSession

from src.core.database import get_db
from src.core.security import get_current_sonda
from src.models import Sonda
from src.schemas import (
    ErrorResponseSchema,
    ProbeConfigSchema,
    TelemetryCreateSchema,
    TelemetryResponsePiggybackSchema,
)
from src.services import IoTService

router = APIRouter(prefix="/api/v1/probe", tags=["IoT & Telemetria (Sonda ESP32)"])


@router.get(
    "/config",
    response_model=ProbeConfigSchema,
    summary="Consulta limiares operacionais da sonda",
    description="Retorna os parâmetros atualizados de acionamento de irrigação e intervalo de envio para o microcontrolador ESP32.",
    responses={
        401: {"model": ErrorResponseSchema, "description": "API Key inválida ou ausente"},
    },
)
async def get_probe_config(
    sonda: Sonda = Depends(get_current_sonda),
):
    return await IoTService.get_probe_config(sonda)


@router.post(
    "/telemetry",
    response_model=TelemetryResponsePiggybackSchema,
    status_code=status.HTTP_201_CREATED,
    summary="Envia dados de telemetria da sonda",
    description="Registra medições de bateria, temperatura e umidade. Retorna confirmação e piggybacking dos limiares operacionais.",
    responses={
        401: {"model": ErrorResponseSchema, "description": "API Key inválida ou ausente"},
        422: {"model": ErrorResponseSchema, "description": "Payload de telemetria inválido"},
    },
)
async def submit_telemetry(
    telemetry_dto: TelemetryCreateSchema,
    sonda: Sonda = Depends(get_current_sonda),
    db: AsyncSession = Depends(get_db),
):
    return await IoTService.process_telemetry(db, sonda, telemetry_dto)
