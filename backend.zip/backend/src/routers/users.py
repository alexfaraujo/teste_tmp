from fastapi import APIRouter, Depends, status
from sqlalchemy.ext.asyncio import AsyncSession

from src.core.database import get_db
from src.core.security import get_current_user
from src.models import Usuario
from src.schemas import ErrorResponseSchema, UsuarioResponseSchema, UsuarioUpdateSchema
from src.services import UsuarioService

router = APIRouter(prefix="/api/v1/users", tags=["Perfil & Onboarding de Usuários"])


@router.get(
    "/me",
    response_model=UsuarioResponseSchema,
    summary="Obtém o perfil do produtor rural autenticado",
    description="Retorna os dados cadastrais do usuário autenticado via Firebase Auth e o status da flag perfil_completo.",
    responses={
        401: {"model": ErrorResponseSchema, "description": "Token Firebase JWT inválido ou expirado"},
    },
)
async def get_my_profile(
    current_user: Usuario = Depends(get_current_user),
):
    return await UsuarioService.get_user_profile(current_user)


@router.put(
    "/me",
    response_model=UsuarioResponseSchema,
    summary="Completa onboarding ou atualiza nome do perfil",
    description="Permite que o produtor informe ou atualize seu nome, marcando perfil_completo = True e liberando acesso ao dashboard.",
    responses={
        401: {"model": ErrorResponseSchema, "description": "Token Firebase JWT inválido ou expirado"},
        422: {"model": ErrorResponseSchema, "description": "Dados de entrada inválidos"},
    },
)
async def update_my_profile(
    update_dto: UsuarioUpdateSchema,
    current_user: Usuario = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    return await UsuarioService.update_user_profile(db, current_user, update_dto)
