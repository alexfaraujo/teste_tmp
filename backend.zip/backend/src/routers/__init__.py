# Pacote de roteadores HTTP FastAPI
