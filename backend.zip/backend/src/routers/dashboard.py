from datetime import datetime
from typing import List, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.ext.asyncio import AsyncSession

from src.core.database import get_db
from src.core.security import get_current_user_complete
from src.models import Usuario
from src.schemas import (
    DashboardSummarySchema,
    ErrorResponseSchema,
    PaginatedLogsResponseSchema,
    SondaCreateResponseSchema,
    SondaCreateSchema,
    SondaResponseSchema,
    SondaUpdateConfigSchema,
)
from src.services import DashboardService, LogService, SondaService

router = APIRouter(prefix="/api/v1", tags=["Dashboard & Gerenciamento de Sondas"])


# =============================================================================
# RESUMO DA DASHBOARD
# =============================================================================
@router.get(
    "/dashboard/summary",
    response_model=DashboardSummarySchema,
    summary="Resumo executivo do dashboard",
    description="Retorna cards consolidados de conectividade, alertas de bateria e as últimas 5 medições de telemetria.",
    responses={
        401: {"model": ErrorResponseSchema, "description": "Não autenticado"},
        403: {"model": ErrorResponseSchema, "description": "Perfil incompleto ou conta desativada"},
    },
)
async def get_dashboard_summary(
    current_user: Usuario = Depends(get_current_user_complete),
    db: AsyncSession = Depends(get_db),
):
    return await DashboardService.get_dashboard_summary(db, current_user.id)


# =============================================================================
# GERENCIAMENTO DE SONDAS
# =============================================================================
@router.get(
    "/probes",
    response_model=List[SondaResponseSchema],
    summary="Lista as sondas cadastradas do produtor",
    description="Lista as sondas pertencentes ao usuário com suporte a filtros de status, alertas de bateria e busca por nome.",
    responses={
        401: {"model": ErrorResponseSchema, "description": "Não autenticado"},
        403: {"model": ErrorResponseSchema, "description": "Perfil incompleto"},
    },
)
async def list_probes(
    status: str = Query(
        default="todos",
        pattern="^(todos|online|offline)$",
        description="Filtro de conectividade: todos | online | offline",
    ),
    alerta_bateria: str = Query(
        default="todos",
        pattern="^(todos|apenas_alertas)$",
        description="Filtro de bateria: todos | apenas_alertas",
    ),
    busca: Optional[str] = Query(
        default=None,
        description="Filtro de busca parcial pelo nome da sonda",
    ),
    current_user: Usuario = Depends(get_current_user_complete),
    db: AsyncSession = Depends(get_db),
):
    return await SondaService.list_sondas_by_user(
        db=db,
        user_id=current_user.id,
        status_filter=status,
        alerta_bateria_filter=alerta_bateria,
        busca=busca,
    )


@router.post(
    "/probes",
    response_model=SondaCreateResponseSchema,
    status_code=status.HTTP_201_CREATED,
    summary="Cadastra uma nova sonda agrícola",
    description="Gera uma nova sonda e retorna sua API Key pura (exibida apenas 1 vez para gravação no ESP32).",
    responses={
        401: {"model": ErrorResponseSchema, "description": "Não autenticado"},
        403: {"model": ErrorResponseSchema, "description": "Perfil incompleto"},
        422: {"model": ErrorResponseSchema, "description": "Dados de cadastro inválidos"},
    },
)
async def create_probe(
    sonda_dto: SondaCreateSchema,
    current_user: Usuario = Depends(get_current_user_complete),
    db: AsyncSession = Depends(get_db),
):
    return await SondaService.create_sonda(db, current_user.id, sonda_dto)


@router.get(
    "/probes/{sonda_id}",
    response_model=SondaResponseSchema,
    summary="Obtém detalhes operacionais de uma sonda específica",
    description="Retorna dados detalhados da sonda, limiares de acionamento e status dinâmico.",
    responses={
        401: {"model": ErrorResponseSchema, "description": "Não autenticado"},
        403: {"model": ErrorResponseSchema, "description": "Perfil incompleto"},
        404: {"model": ErrorResponseSchema, "description": "Sonda não encontrada"},
    },
)
async def get_probe_by_id(
    sonda_id: UUID,
    current_user: Usuario = Depends(get_current_user_complete),
    db: AsyncSession = Depends(get_db),
):
    return await SondaService.get_sonda_by_id(db, current_user.id, sonda_id)


@router.put(
    "/probes/{sonda_id}/config",
    response_model=SondaResponseSchema,
    summary="Atualiza os limiares de irrigação da sonda",
    description="Permite que o produtor ajuste irrigacao_diurna, indice_irrigar e intervalo_envio_segundos.",
    responses={
        401: {"model": ErrorResponseSchema, "description": "Não autenticado"},
        403: {"model": ErrorResponseSchema, "description": "Perfil incompleto"},
        404: {"model": ErrorResponseSchema, "description": "Sonda não encontrada"},
    },
)
async def update_probe_config(
    sonda_id: UUID,
    config_dto: SondaUpdateConfigSchema,
    current_user: Usuario = Depends(get_current_user_complete),
    db: AsyncSession = Depends(get_db),
):
    return await SondaService.update_sonda_config(db, current_user.id, sonda_id, config_dto)


@router.delete(
    "/probes/{sonda_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Remove uma sonda (Soft Delete)",
    description="Realiza a exclusão lógica da sonda (deleted_at = now, ativo = False) sem apagar histórico.",
    responses={
        401: {"model": ErrorResponseSchema, "description": "Não autenticado"},
        403: {"model": ErrorResponseSchema, "description": "Perfil incompleto"},
        404: {"model": ErrorResponseSchema, "description": "Sonda não encontrada"},
    },
)
async def delete_probe(
    sonda_id: UUID,
    current_user: Usuario = Depends(get_current_user_complete),
    db: AsyncSession = Depends(get_db),
):
    await SondaService.soft_delete_sonda(db, current_user.id, sonda_id)
    return None


# =============================================================================
# HISTÓRICO PAGINADO DE LOGS
# =============================================================================
@router.get(
    "/probes/{sonda_id}/logs",
    response_model=PaginatedLogsResponseSchema,
    summary="Consulta o histórico paginado de telemetria da sonda",
    description="Retorna leituras temporais de bateria, temperatura e umidade com suporte a paginação e filtro por intervalo de datas.",
    responses={
        401: {"model": ErrorResponseSchema, "description": "Não autenticado"},
        403: {"model": ErrorResponseSchema, "description": "Perfil incompleto"},
        404: {"model": ErrorResponseSchema, "description": "Sonda não encontrada"},
    },
)
async def get_probe_logs(
    sonda_id: UUID,
    page: int = Query(default=1, ge=1, description="Número da página (>= 1)"),
    page_size: int = Query(default=20, ge=10, le=100, description="Registros por página (10 a 100)"),
    data_inicio: Optional[datetime] = Query(default=None, description="Filtro de data/hora inicial (UTC)"),
    data_fim: Optional[datetime] = Query(default=None, description="Filtro de data/hora final (UTC)"),
    current_user: Usuario = Depends(get_current_user_complete),
    db: AsyncSession = Depends(get_db),
):
    return await LogService.get_paginated_logs(
        db=db,
        user_id=current_user.id,
        sonda_id=sonda_id,
        page=page,
        page_size=page_size,
        data_inicio=data_inicio,
        data_fim=data_fim,
    )
