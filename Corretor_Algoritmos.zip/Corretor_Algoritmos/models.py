from sqlalchemy import create_engine, Column, Integer, String, DateTime, ForeignKey, Table, Boolean, Float, JSON
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash

Base = declarative_base()

class BaseModel(Base):
    __abstract__ = True
    
    id = Column(Integer, primary_key=True)
    data_registro = Column(DateTime, default=datetime.now)
    ativo = Column(Boolean, default=True)  # Campo para soft delete

    def soft_delete(self):
        self.ativo = False

# Tabela de associação entre Estudante e Classe
estudante_classe = Table('estudante_classe',
    Base.metadata,
    Column('id_estudante', Integer, ForeignKey('estudante.id'), primary_key=True),
    Column('id_classe', Integer, ForeignKey('classe.id'), primary_key=True),
    Column('data_registro', DateTime, default=datetime.now)
)

# Adicionar nova tabela de associação entre Atividade e Classe
atividade_classe = Table('atividade_classe',
    Base.metadata,
    Column('id_atividade', Integer, ForeignKey('atividade.id'), primary_key=True),
    Column('id_classe', Integer, ForeignKey('classe.id'), primary_key=True),
    Column('data_registro', DateTime, default=datetime.now)
)

class Estudante(BaseModel):
    __tablename__ = 'estudante'
    
    nome = Column(String(100), nullable=False)
    email = Column(String(100), unique=True, nullable=False)
    classes = relationship("Classe", secondary=estudante_classe, back_populates="estudantes")
    atividades_realizadas = relationship("AtividadeRealizada", back_populates="estudante")

class Classe(BaseModel):
    __tablename__ = 'classe'
    
    codigo_classe = Column(String(20), unique=True, nullable=False)
    unidade_curricular = Column(String(100), nullable=False)
    ano = Column(Integer, nullable=False)
    semestre = Column(Integer, nullable=False)
    estudantes = relationship("Estudante", secondary=estudante_classe, back_populates="classes")
    # Adicionar relacionamento com atividades
    atividades = relationship("Atividade", secondary=atividade_classe, back_populates="classes")

class CasoTeste(BaseModel):
    __tablename__ = 'caso_teste'
    
    id_atividade = Column(Integer, ForeignKey('atividade.id'), nullable=False)
    entrada = Column(String(1000), nullable=False)  # Dados de entrada
    saida_esperada = Column(String(1000), nullable=False)  # Saída esperada
    peso = Column(Float, default=1.0)  # Peso do teste no cálculo da nota
    ordem = Column(Integer, nullable=False)  # Ordem de execução
    visivel = Column(Boolean, default=True)  # Se o caso de teste é visível para o estudante
    
    atividade = relationship("Atividade", back_populates="casos_teste")

class Atividade(BaseModel):
    __tablename__ = 'atividade'
    
    codigo = Column(String(20), unique=True, nullable=False)
    descricao = Column(String(500), nullable=False)
    nivel_atividade = Column(Integer, nullable=False)
    tempo_limite = Column(Float, default=1.0)  # Tempo limite em segundos
    memoria_limite = Column(Integer, default=256)  # Limite de memória em MB
    casos_teste = relationship("CasoTeste", back_populates="atividade", order_by="CasoTeste.ordem")
    atividades_realizadas = relationship("AtividadeRealizada", back_populates="atividade")
    classes = relationship("Classe", secondary=atividade_classe, back_populates="atividades")

class AtividadeRealizada(BaseModel):
    __tablename__ = 'atividade_realizada'
    
    id_estudante = Column(Integer, ForeignKey('estudante.id'), nullable=False)
    id_atividade = Column(Integer, ForeignKey('atividade.id'), nullable=False)
    nome_arquivo = Column(String(255), nullable=False)
    resultado_compilacao = Column(String(500))
    resultado_execucao = Column(String(500))
    resultados_testes = Column(JSON)  # Armazenar resultados de cada caso de teste
    nota = Column(Float)  # Nota calculada com base nos testes
    
    estudante = relationship("Estudante", back_populates="atividades_realizadas")
    atividade = relationship("Atividade", back_populates="atividades_realizadas")

class Configuracao(BaseModel):
    __tablename__ = 'configuracao'
    
    chave = Column(String(50), unique=True, nullable=False)
    valor = Column(String(255), nullable=False)
    descricao = Column(String(500))

class Admin(BaseModel):
    __tablename__ = 'admin'
    
    username = Column(String(50), unique=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    nome = Column(String(100), nullable=False)
    email = Column(String(100), unique=True, nullable=False)
    ultimo_acesso = Column(DateTime)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
        
    def check_password(self, password):
        return check_password_hash(self.password_hash, password) 