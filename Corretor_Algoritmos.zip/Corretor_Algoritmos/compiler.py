import subprocess
import os
import json
import time
from threading import Timer
from utils import validate_c_code
from models import Log
from flask import current_app
from database import get_session
from datetime import datetime
from flask import request

class CCompiler:
    def __init__(self, arquivo_url, user_email=None, db_session=None, user_ip=None):
        self.arquivo_url = arquivo_url
        self.nome_executavel = "programa"
        self.resultado_compilacao = ""
        self.resultado_execucao = ""
        self.resultados_testes = []
        self.nota = 0.0
        self.user_email = user_email
        self.db_session = db_session
        self.user_ip = user_ip

    def compilar(self):
        try:
            # Ler o conteúdo do arquivo
            with open(self.arquivo_url, 'r') as f:
                codigo = f.read()

            # Validar o código antes de compilar
            print('DEBUG: Chamando validate_c_code...')
            is_safe, error_message, violation_details = validate_c_code(codigo)
            print(f'DEBUG: is_safe={is_safe}, error_message={error_message}, violation_details={violation_details}')
            if not is_safe:
                # Mensagens para o log
                mensagem_usuario = "Erro de compilação: Código contém construções não permitidas. Verifique a sintaxe e tente novamente."
                nome_arquivo = os.path.basename(self.arquivo_url)
                detalhes_log = f"Mensagem exibida: {mensagem_usuario} | Violação: {violation_details} | Arquivo: {nome_arquivo}"

                # Registrar log de violação de segurança
                if self.user_email and self.db_session:
                    try:
                        log = Log(
                            tipo='seguranca_falha',
                            username=self.user_email,
                            ip=self.user_ip or '0.0.0.0',
                            data_hora=datetime.now(),
                            detalhes=detalhes_log
                        )
                        self.db_session.add(log)
                        self.db_session.commit()
                        print(f"Log de segurança registrado para {self.user_email}: {detalhes_log}")
                    except Exception as e:
                        print(f"Erro ao registrar log de segurança: {str(e)}")
                        self.db_session.rollback()

                return {
                    'compilacao': mensagem_usuario,
                    'execucao': "Não foi possível executar devido a erros na compilação",
                    'resultados_testes': [],
                    'nota': 0.0
                }

            # Compila o arquivo .c usando gcc
            processo_compilacao = subprocess.run(
                ['gcc', self.arquivo_url, '-o', self.nome_executavel],
                capture_output=True,
                text=True
            )

            self.resultado_compilacao = processo_compilacao.stderr or "Compilação bem-sucedida!"

            if processo_compilacao.returncode != 0:
                return {
                    'compilacao': self.resultado_compilacao,
                    'execucao': "Não foi possível executar devido a erros na compilação",
                    'resultados_testes': [],
                    'nota': 0.0
                }

            return {
                'compilacao': self.resultado_compilacao,
                'execucao': "Compilação bem-sucedida",
                'resultados_testes': [],
                'nota': 0.0
            }

        except Exception as e:
            return {
                'compilacao': f"Erro durante o processo: {str(e)}",
                'execucao': "Não foi possível executar devido a erros",
                'resultados_testes': [],
                'nota': 0.0
            }

    def executar_teste(self, entrada, saida_esperada, tempo_limite=1.0):
        try:
            processo = subprocess.Popen(
                [f'./{self.nome_executavel}'],
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )

            try:
                saida, erro = processo.communicate(input=entrada, timeout=tempo_limite)
                if erro:
                    return {
                        'status': 'erro',
                        'mensagem': f'Erro durante execução: {erro}',
                        'saida_obtida': ''
                    }

                # Normalizar quebras de linha e espaços
                saida = saida.strip()
                saida_esperada = saida_esperada.strip()

                if saida == saida_esperada:
                    return {
                        'status': 'sucesso',
                        'mensagem': 'Saída correta',
                        'saida_obtida': saida
                    }
                else:
                    return {
                        'status': 'erro',
                        'mensagem': 'Saída incorreta',
                        'saida_obtida': saida
                    }

            except subprocess.TimeoutExpired:
                processo.kill()
                return {
                    'status': 'erro',
                    'mensagem': f'Tempo limite excedido ({tempo_limite}s)',
                    'saida_obtida': ''
                }

        except Exception as e:
            return {
                'status': 'erro',
                'mensagem': f'Erro ao executar teste: {str(e)}',
                'saida_obtida': ''
            }

    def executar_casos_teste(self, casos_teste, tempo_limite=1.0):
        try:
            resultado_compilacao = self.compilar()
            if "bem-sucedida" not in resultado_compilacao['compilacao']:
                return resultado_compilacao

            nota_total = 0
            peso_total = sum(caso.peso for caso in casos_teste)
            resultados = []

            for caso in casos_teste:
                resultado = self.executar_teste(caso.entrada, caso.saida_esperada, tempo_limite)
                resultado['peso'] = caso.peso
                resultado['visivel'] = caso.visivel
                resultado['entrada'] = caso.entrada
                resultado['saida_esperada'] = caso.saida_esperada
                
                if resultado['status'] == 'sucesso':
                    nota_total += caso.peso
                
                resultados.append(resultado)

            # Calcular nota final (0 a 10)
            nota_final = (nota_total / peso_total * 10) if peso_total > 0 else 0

            return {
                'compilacao': resultado_compilacao['compilacao'],
                'execucao': "Execução completa",
                'resultados_testes': resultados,
                'nota': round(nota_final, 2)
            }
        finally:
            # Remover o executável apenas depois de todos os testes
            if os.path.exists(self.nome_executavel):
                os.remove(self.nome_executavel) 