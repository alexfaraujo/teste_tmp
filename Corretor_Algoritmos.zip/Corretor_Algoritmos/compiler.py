import subprocess
import os
import json
import time
from threading import Timer

class CCompiler:
    def __init__(self, arquivo_url):
        self.arquivo_url = arquivo_url
        self.nome_executavel = "programa"
        self.resultado_compilacao = ""
        self.resultado_execucao = ""
        self.resultados_testes = []
        self.nota = 0.0

    def compilar(self):
        try:
            # Compila o arquivo .c usando gcc
            processo_compilacao = subprocess.run(
                ['gcc', self.arquivo_url, '-o', self.nome_executavel],
                capture_output=True,
                text=True
            )

            self.resultado_compilacao = processo_compilacao.stderr or "Compilação bem-sucedida!"

            if processo_compilacao.returncode != 0:
                return {
                    'compilacao': self.resultado_compilacao,
                    'execucao': "Não foi possível executar devido a erros na compilação",
                    'resultados_testes': [],
                    'nota': 0.0
                }

            return {
                'compilacao': self.resultado_compilacao,
                'execucao': "Compilação bem-sucedida",
                'resultados_testes': [],
                'nota': 0.0
            }

        except Exception as e:
            return {
                'compilacao': f"Erro durante o processo: {str(e)}",
                'execucao': "Não foi possível executar devido a erros",
                'resultados_testes': [],
                'nota': 0.0
            }

    def executar_teste(self, entrada, saida_esperada, tempo_limite=1.0):
        try:
            processo = subprocess.Popen(
                [f'./{self.nome_executavel}'],
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )

            try:
                saida, erro = processo.communicate(input=entrada, timeout=tempo_limite)
                if erro:
                    return {
                        'status': 'erro',
                        'mensagem': f'Erro durante execução: {erro}',
                        'saida_obtida': ''
                    }

                # Normalizar quebras de linha e espaços
                saida = saida.strip()
                saida_esperada = saida_esperada.strip()

                if saida == saida_esperada:
                    return {
                        'status': 'sucesso',
                        'mensagem': 'Saída correta',
                        'saida_obtida': saida
                    }
                else:
                    return {
                        'status': 'erro',
                        'mensagem': 'Saída incorreta',
                        'saida_obtida': saida
                    }

            except subprocess.TimeoutExpired:
                processo.kill()
                return {
                    'status': 'erro',
                    'mensagem': f'Tempo limite excedido ({tempo_limite}s)',
                    'saida_obtida': ''
                }

        except Exception as e:
            return {
                'status': 'erro',
                'mensagem': f'Erro ao executar teste: {str(e)}',
                'saida_obtida': ''
            }

    def executar_casos_teste(self, casos_teste, tempo_limite=1.0):
        try:
            resultado_compilacao = self.compilar()
            if "bem-sucedida" not in resultado_compilacao['compilacao']:
                return resultado_compilacao

            nota_total = 0
            peso_total = sum(caso.peso for caso in casos_teste)
            resultados = []

            for caso in casos_teste:
                resultado = self.executar_teste(caso.entrada, caso.saida_esperada, tempo_limite)
                resultado['peso'] = caso.peso
                resultado['visivel'] = caso.visivel
                resultado['entrada'] = caso.entrada
                resultado['saida_esperada'] = caso.saida_esperada
                
                if resultado['status'] == 'sucesso':
                    nota_total += caso.peso
                
                resultados.append(resultado)

            # Calcular nota final (0 a 10)
            nota_final = (nota_total / peso_total * 10) if peso_total > 0 else 0

            return {
                'compilacao': resultado_compilacao['compilacao'],
                'execucao': "Execução completa",
                'resultados_testes': resultados,
                'nota': round(nota_final, 2)
            }
        finally:
            # Remover o executável apenas depois de todos os testes
            if os.path.exists(self.nome_executavel):
                os.remove(self.nome_executavel) 