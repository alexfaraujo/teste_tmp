#!/bin/bash

# Verifica se o ambiente virtual existe, se não, cria
if [ ! -d "venv" ]; then
    echo "Criando ambiente virtual..."
    python3 -m venv ../.venv
fi

# Ativa o ambiente virtual
echo "Ativando ambiente virtual..."
source ../.venv/bin/activate

# Instala as dependências
echo "Instalando dependências..."
pip install -r requirements.txt

# Cria arquivo .env se não existir
if [ ! -f ".env" ]; then
    echo "Criando arquivo .env..."
    cat > .env << EOL
FLASK_APP=app.py
FLASK_ENV=production
SECRET_KEY=$(openssl rand -hex 32)
DATABASE_URL=sqlite:///atividades.db
EOL
fi

# Inicia o servidor Gunicorn na porta 2058
echo "Iniciando servidor na porta 2058..."
gunicorn --bind 0.0.0.0:2058 app:app 