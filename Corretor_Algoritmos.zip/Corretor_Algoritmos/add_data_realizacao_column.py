import sqlite3
from datetime import datetime

def add_column():
    conn = sqlite3.connect('atividades.db')
    cursor = conn.cursor()
    
    try:
        # Verificar se a coluna já existe
        cursor.execute("PRAGMA table_info(atividade_realizada)")
        columns = [column[1] for column in cursor.fetchall()]
        
        if 'data_realizacao' not in columns:
            # Adicionar a coluna data_realizacao sem valor padrão
            cursor.execute('''
                ALTER TABLE atividade_realizada 
                ADD COLUMN data_realizacao DATETIME
            ''')
            
            # Atualizar registros existentes com a data_registro
            cursor.execute('''
                UPDATE atividade_realizada 
                SET data_realizacao = data_registro 
                WHERE data_realizacao IS NULL
            ''')
            
            print("Coluna data_realizacao adicionada e registros atualizados com sucesso!")
        else:
            print("A coluna data_realizacao já existe!")
        
        conn.commit()
    except Exception as e:
        print(f"Erro ao adicionar coluna: {str(e)}")
    finally:
        conn.close()

if __name__ == "__main__":
    add_column() 