from database import get_db
from models import Log
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

def limpar_logs():
    # Conectar ao banco de dados
    engine = create_engine('sqlite:///atividades.db')
    Session = sessionmaker(bind=engine)
    session = Session()

    try:
        # Contar registros antes da limpeza
        total_antes = session.query(Log).count()
        
        # Remover todos os registros
        session.query(Log).delete()
        session.commit()
        
        print(f"Limpeza concluída com sucesso!")
        print(f"Total de registros removidos: {total_antes}")
        
    except Exception as e:
        print(f"Erro ao limpar tabela: {str(e)}")
        session.rollback()
    finally:
        session.close()

if __name__ == '__main__':
    limpar_logs() 