import os
import subprocess
from utils import validate_c_code  # Adiciona a importação
from models import Log  # Para registrar o log
from extensions import db  # Para acessar a sessão do banco

class CCompiler:
    def __init__(self, arquivo_url, user_email=None, user_ip=None):
        self.arquivo_url = arquivo_url
        self.user_email = user_email
        self.user_ip = user_ip
        print(f"Caminho do arquivo para compilação: {self.arquivo_url}")  # Log para debug

    def compilar(self):
        """Compila o código C e retorna o resultado"""
        try:
            # Verifica se o arquivo existe
            if not os.path.exists(self.arquivo_url):
                print(f"Erro: Arquivo não encontrado em {self.arquivo_url}")  # Log para debug
                return {
                    'compilacao': 'Erro: Arquivo não encontrado',
                    'execucao': 'Não foi possível executar devido a erros na compilação',
                    'resultados_testes': [],
                    'nota': 0.0
                }

            # Lê o conteúdo do arquivo
            with open(self.arquivo_url, 'r') as f:
                codigo = f.read()
                print(f"Conteúdo do arquivo:\n{codigo}")  # Log para debug

            # Validação de segurança
            is_safe, error_message, violation_details = validate_c_code(codigo)
            print(f'DEBUG: is_safe={is_safe}, error_message={error_message}, violation_details={violation_details}')
            if not is_safe:
                # Registrar log de violação de segurança
                try:
                    log = Log(
                        tipo='violacao_seguranca',
                        username=self.user_email or 'desconhecido',
                        ip=self.user_ip or '0.0.0.0',
                        data_hora=db.func.now(),
                        detalhes=f"Violação: {violation_details} | Arquivo: {os.path.basename(self.arquivo_url)}"
                    )
                    db.session.add(log)
                    db.session.commit()
                    print(f"Log de segurança registrado para {self.user_email}: {violation_details}")
                except Exception as e:
                    print(f"Erro ao registrar log de segurança: {str(e)}")
                    db.session.rollback()
                return {
                    'compilacao': error_message,
                    'execucao': 'Não foi possível executar devido a erros na compilação',
                    'resultados_testes': [],
                    'nota': 0.0
                }

            # Verifica se o código contém a função main
            if 'main' not in codigo:
                print("Erro: Função main() não encontrada no código")  # Log para debug
                return {
                    'compilacao': 'Erro: Função main() não encontrada no código',
                    'execucao': 'Não foi possível executar devido a erros na compilação',
                    'resultados_testes': [],
                    'nota': 0.0
                }

            # Compila o código
            print(f"Comando de compilação: gcc {self.arquivo_url} -o {self.arquivo_url}.out")  # Log para debug
            resultado = subprocess.run(
                ['gcc', self.arquivo_url, '-o', self.arquivo_url + '.out'],
                capture_output=True,
                text=True
            )
            print(f"Resultado da compilação: {resultado.returncode}")  # Log para debug
            print(f"Saída da compilação: {resultado.stdout}")  # Log para debug
            print(f"Erro da compilação: {resultado.stderr}")  # Log para debug

            if resultado.returncode == 0:
                return {
                    'compilacao': 'Compilação bem-sucedida',
                    'execucao': '',
                    'resultados_testes': [],
                    'nota': 0.0
                }
            else:
                return {
                    'compilacao': resultado.stderr,
                    'execucao': 'Não foi possível executar devido a erros na compilação',
                    'resultados_testes': [],
                    'nota': 0.0
                }

        except Exception as e:
            print(f"Erro durante a compilação: {str(e)}")  # Log para debug
            return {
                'compilacao': f'Erro durante a compilação: {str(e)}',
                'execucao': 'Não foi possível executar devido a erros na compilação',
                'resultados_testes': [],
                'nota': 0.0
            }

    def executar(self, entrada=None):
        """Executa o código compilado e retorna o resultado"""
        try:
            if not os.path.exists(self.arquivo_url + '.out'):
                return {'sucesso': False, 'saida': '', 'erro': 'Arquivo executável não encontrado'}

            # Garantir que a entrada seja uma string e adicionar quebra de linha se necessário
            if entrada is not None:
                if not entrada.endswith('\n'):
                    entrada += '\n'
                print(f"Executando com entrada: {repr(entrada)}")  # Log para debug

            # Executa o código
            resultado = subprocess.run(
                [self.arquivo_url + '.out'],
                input=entrada,
                capture_output=True,
                text=True,
                encoding='utf-8',  # Especifica a codificação
                timeout=5
            )

            print(f"Código de retorno: {resultado.returncode}")  # Log para debug
            print(f"Saída: {repr(resultado.stdout)}")  # Log para debug
            print(f"Erro: {repr(resultado.stderr)}")  # Log para debug

            if resultado.returncode == 0:
                return {'sucesso': True, 'saida': resultado.stdout, 'erro': ''}
            else:
                return {'sucesso': False, 'saida': '', 'erro': resultado.stderr}

        except subprocess.TimeoutExpired:
            return {'sucesso': False, 'saida': '', 'erro': 'Tempo limite de execução excedido (5 segundos)'}
        except Exception as e:
            return {'sucesso': False, 'saida': '', 'erro': f'Erro durante a execução: {str(e)}'}

    def testar(self, casos_teste):
        """Executa os testes e retorna os resultados"""
        try:
            # Verifica se o arquivo executável existe
            if not os.path.exists(self.arquivo_url + '.out'):
                return []

            resultados = []
            for caso in casos_teste:
                # Executa o código com o caso de teste
                resultado = subprocess.run(
                    [self.arquivo_url + '.out'],
                    input=caso.entrada,
                    capture_output=True,
                    text=True
                )

                if resultado.returncode == 0 and resultado.stdout.strip() == caso.saida_esperada.strip():
                    status = 'sucesso'
                    mensagem = 'Saída correta'
                else:
                    status = 'erro'
                    mensagem = 'Saída incorreta'

                # Se o caso de teste não é visível, oculta os valores sensíveis
                if not caso.visivel:
                    resultado_teste = {
                        'status': status,
                        'mensagem': mensagem,
                        'saida_obtida': '***OCULTO***',
                        'peso': caso.peso,
                        'visivel': caso.visivel,
                        'entrada': '***OCULTO***',
                        'saida_esperada': '***OCULTO***'
                    }
                else:
                    resultado_teste = {
                        'status': status,
                        'mensagem': mensagem,
                        'saida_obtida': resultado.stdout,
                        'peso': caso.peso,
                        'visivel': caso.visivel,
                        'entrada': caso.entrada,
                        'saida_esperada': caso.saida_esperada
                    }
                resultados.append(resultado_teste)

            return resultados

        except Exception as e:
            return [{
                'status': 'erro',
                'mensagem': f'Erro durante os testes: {str(e)}',
                'saida_obtida': '',
                'peso': 0,
                'visivel': True,
                'entrada': '',
                'saida_esperada': ''
            }] 