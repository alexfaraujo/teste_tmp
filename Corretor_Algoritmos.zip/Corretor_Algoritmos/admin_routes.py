from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from models import (
    Admin, Classe, Estudante, Atividade, Configuracao, AtividadeRealizada,
    estudante_classe, CasoTeste, Log, atividade_classe
)
from database import get_session, validar_estudante, validar_atividade
from auth import login_required, check_brute_force, registrar_log
from datetime import datetime, timedelta
from sqlalchemy import func, case, literal, desc, distinct
import csv
from io import TextIOWrapper
import os
from werkzeug.utils import secure_filename
import json
from compiler import CCompiler

admin_bp = Blueprint('admin', __name__, url_prefix='/admin')

def init_admin(app):
    # Registrar o filtro no ambiente Jinja2
    app.jinja_env.filters['nivel_texto'] = get_nivel_texto

@admin_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        ip = request.remote_addr
        
        if check_brute_force(username, ip):
            flash('Muitas tentativas de login. Tente novamente mais tarde.', 'error')
            registrar_log('login_falha', username, ip, 'Tentativas excedidas')
            return redirect(url_for('admin.login'))
        
        db = get_session()
        try:
            admin = db.query(Admin).filter_by(username=username).first()
            
            if admin and admin.check_password(password):
                session['admin_id'] = admin.id
                session['admin_name'] = admin.nome
                session['last_activity'] = datetime.now().isoformat()
                admin.ultimo_acesso = datetime.now()
                db.commit()
                registrar_log('login_sucesso', username, ip)
                return redirect(url_for('admin.dashboard'))
            else:
                flash('Usuário ou senha inválidos', 'error')
                registrar_log('login_falha', username, ip, 'Credenciais inválidas')
                return redirect(url_for('admin.login'))
        finally:
            db.close()
    
    return render_template('admin/login.html')

@admin_bp.route('/logout')
def logout():
    if 'admin_id' in session:
        db = get_session()
        try:
            admin = db.query(Admin).get(session['admin_id'])
            if admin:
                registrar_log('logout', admin.username, request.remote_addr)
        finally:
            db.close()
        session.clear()
    return redirect(url_for('admin.login'))

@admin_bp.route('/')
@login_required
def dashboard():
    db = get_session()
    try:
        # Parâmetros de paginação
        page = request.args.get('page', 1, type=int)
        per_page = 20  # registros por página
        
        # Obter estatísticas gerais
        stats = {
            'total_estudantes': db.query(Estudante).filter_by(ativo=True).count(),
            'total_atividades': db.query(Atividade).filter_by(ativo=True).count(),
            'total_classes': db.query(Classe).filter_by(ativo=True).count(),
            'total_envios': db.query(AtividadeRealizada).filter_by(ativo=True).count()
        }
        
        # Buscar configuração de limite de tentativas
        config = db.query(Configuracao).filter_by(
            chave='limite_tentativas_atividade',
            ativo=True
        ).first()
        limite_tentativas = int(config.valor) if config else 5
        
        # Base query com filtros
        query = db.query(
            AtividadeRealizada.id_estudante,
            AtividadeRealizada.id_atividade,
            Estudante,
            Atividade,
            func.count(AtividadeRealizada.id).label('total_tentativas'),
            func.max(AtividadeRealizada.data_registro).label('ultima_tentativa'),
            func.max(case(
                (AtividadeRealizada.resultado_compilacao.like('%bem-sucedida%'), True),
                else_=False
            )).label('teve_sucesso')
        ).join(
            Estudante, AtividadeRealizada.id_estudante == Estudante.id
        ).join(
            Atividade, AtividadeRealizada.id_atividade == Atividade.id
        ).filter(
            AtividadeRealizada.ativo == True
        )

        # Aplicar filtros da busca
        if request.args.get('estudante'):
            query = query.filter(Estudante.nome.ilike(f"%{request.args['estudante']}%"))
        
        if request.args.get('atividade'):
            query = query.filter(Atividade.codigo.ilike(f"%{request.args['atividade']}%"))
            
        if request.args.get('classe'):
            query = query.join(
                estudante_classe,
                Estudante.id == estudante_classe.c.id_estudante
            ).filter(
                estudante_classe.c.id_classe == request.args['classe']
            )

        # Agrupar e ordenar
        query = query.group_by(
            AtividadeRealizada.id_estudante,
            AtividadeRealizada.id_atividade,
            Estudante.id,
            Atividade.id
        ).order_by(desc('ultima_tentativa'))

        # Contar total de registros antes da paginação
        total_registros = query.count()
        
        # Aplicar paginação
        atividades_recentes = query.offset((page - 1) * per_page).limit(per_page).all()
        
        # Calcular total de páginas
        total_paginas = (total_registros + per_page - 1) // per_page

        # Buscar classes para o filtro
        classes = db.query(Classe).filter_by(ativo=True).all()

        return render_template('admin/dashboard.html',
                             stats=stats,
                             atividades_recentes=atividades_recentes,
                             classes=classes,
                             page=page,
                             total_paginas=total_paginas,
                             total_registros=total_registros,
                             per_page=per_page,
                             limite_tentativas=limite_tentativas)
    finally:
        db.close()

# CRUD Atividades
@admin_bp.route('/atividades')
@login_required
def atividades():
    db = get_session()
    try:
        atividades = db.query(Atividade).filter_by(ativo=True).all()
        
        # Buscar datas de início e fim para cada atividade
        datas_por_atividade = {}
        for atividade in atividades:
            datas_por_atividade[atividade.id] = {}
            for classe in atividade.classes:
                result = db.execute(
                    atividade_classe.select().where(
                        (atividade_classe.c.id_atividade == atividade.id) &
                        (atividade_classe.c.id_classe == classe.id)
                    )
                ).first()
                if result:
                    datas_por_atividade[atividade.id][classe.id] = {
                        'data_inicio': result.data_inicio,
                        'data_fim': result.data_fim
                    }
        
        return render_template('admin/atividades/index.html', 
                             atividades=atividades,
                             datas_por_atividade=datas_por_atividade)
    finally:
        db.close()

@admin_bp.route('/atividades/nova', methods=['GET', 'POST'])
@login_required
def nova_atividade():
    db = get_session()
    try:
        if request.method == 'POST':
            atividade = Atividade(
                codigo=request.form['codigo'],
                descricao=request.form['descricao'],
                nivel_atividade=int(request.form['nivel'])
            )
            
            # Primeiro, adicionar a atividade para obter o ID
            db.add(atividade)
            db.flush()  # Isso gera o ID da atividade sem fazer commit
            
            # Adicionar às classes selecionadas com suas datas
            classes_ids = request.form.getlist('classes')
            for classe_id in classes_ids:
                data_inicio = request.form.get(f'data_inicio_{classe_id}')
                data_fim = request.form.get(f'data_fim_{classe_id}')
                
                if not data_inicio or not data_fim:
                    flash('Por favor, preencha as datas de início e fim para todas as classes selecionadas')
                    return redirect(url_for('admin.nova_atividade'))
                
                data_inicio = datetime.strptime(data_inicio, '%Y-%m-%dT%H:%M')
                data_fim = datetime.strptime(data_fim, '%Y-%m-%dT%H:%M')
                
                # Verificar se data_fim é posterior a data_inicio
                if data_fim <= data_inicio:
                    flash('A data de fim deve ser posterior à data de início')
                    return redirect(url_for('admin.nova_atividade'))
                
                # Inserir na tabela atividade_classe com as datas
                db.execute(
                    atividade_classe.insert().values(
                        id_atividade=atividade.id,
                        id_classe=classe_id,
                        data_inicio=data_inicio,
                        data_fim=data_fim
                    )
                )
            
            db.commit()
            flash('Atividade criada com sucesso!')
            return redirect(url_for('admin.atividades'))
            
        # Para o formulário GET, buscar todas as classes ativas disponíveis
        classes = db.query(Classe).filter_by(ativo=True).all()
        return render_template('admin/atividades/form.html', 
                             classes=classes,
                             atividade=None,
                             datas_por_classe={})
    except Exception as e:
        db.rollback()
        flash(f'Erro ao criar atividade: {str(e)}')
        return redirect(url_for('admin.atividades'))
    finally:
        db.close()

@admin_bp.route('/atividades/editar/<int:id>', methods=['GET', 'POST'])
@login_required
def editar_atividade(id):
    db = get_session()
    try:
        atividade = db.query(Atividade).get(id)
        if not atividade:
            flash('Atividade não encontrada')
            return redirect(url_for('admin.atividades'))
            
        if request.method == 'POST':
            atividade.codigo = request.form['codigo']
            atividade.descricao = request.form['descricao']
            atividade.nivel_atividade = int(request.form['nivel'])
            
            # Remover todas as associações existentes
            db.execute(atividade_classe.delete().where(atividade_classe.c.id_atividade == atividade.id))
            
            # Adicionar novas associações com suas datas
            classes_ids = request.form.getlist('classes')
            for classe_id in classes_ids:
                data_inicio = request.form.get(f'data_inicio_{classe_id}')
                data_fim = request.form.get(f'data_fim_{classe_id}')
                
                if not data_inicio or not data_fim:
                    flash('Por favor, preencha as datas de início e fim para todas as classes selecionadas')
                    return redirect(url_for('admin.editar_atividade', id=id))
                
                data_inicio = datetime.strptime(data_inicio, '%Y-%m-%dT%H:%M')
                data_fim = datetime.strptime(data_fim, '%Y-%m-%dT%H:%M')
                
                # Verificar se data_fim é posterior a data_inicio
                if data_fim <= data_inicio:
                    flash('A data de fim deve ser posterior à data de início')
                    return redirect(url_for('admin.editar_atividade', id=id))
                
                # Inserir na tabela atividade_classe com as datas
                db.execute(
                    atividade_classe.insert().values(
                        id_atividade=atividade.id,
                        id_classe=classe_id,
                        data_inicio=data_inicio,
                        data_fim=data_fim
                    )
                )
            
            db.commit()
            flash('Atividade atualizada com sucesso!')
            return redirect(url_for('admin.atividades'))
            
        # Para o formulário GET
        classes = db.query(Classe).filter_by(ativo=True).all()
        
        # Buscar as datas de início e fim para cada classe associada
        datas_por_classe = {}
        for classe in atividade.classes:
            result = db.execute(
                atividade_classe.select().where(
                    (atividade_classe.c.id_atividade == atividade.id) &
                    (atividade_classe.c.id_classe == classe.id)
                )
            ).first()
            if result:
                datas_por_classe[classe.id] = {
                    'data_inicio': result.data_inicio.strftime('%Y-%m-%dT%H:%M'),
                    'data_fim': result.data_fim.strftime('%Y-%m-%dT%H:%M')
                }
        
        return render_template('admin/atividades/form.html', 
                             atividade=atividade,
                             classes=classes,
                             datas_por_classe=datas_por_classe)
    except Exception as e:
        db.rollback()
        flash(f'Erro ao editar atividade: {str(e)}')
        return redirect(url_for('admin.atividades'))
    finally:
        db.close()

@admin_bp.route('/atividades/excluir/<int:id>')
@login_required
def excluir_atividade(id):
    db = get_session()
    try:
        atividade = db.query(Atividade).get(id)
        if atividade:
            # Verificar se existem atividades realizadas
            if len(atividade.atividades_realizadas) > 0:
                flash('Não é possível excluir uma atividade que já possui entregas')
                return redirect(url_for('admin.atividades'))
                
            atividade.soft_delete()  # Em vez de db.delete(atividade)
            db.commit()
            flash('Atividade excluída com sucesso!')
        else:
            flash('Atividade não encontrada')
    except Exception as e:
        db.rollback()
        flash(f'Erro ao excluir atividade: {str(e)}')
    finally:
        db.close()
    return redirect(url_for('admin.atividades'))

# CRUD Classes
@admin_bp.route('/classes')
@login_required
def classes():
    db = get_session()
    try:
        classes = db.query(Classe).filter_by(ativo=True).all()
        return render_template('admin/classes/index.html', classes=classes)
    finally:
        db.close()

@admin_bp.route('/classes/nova', methods=['GET', 'POST'])
@login_required
def nova_classe():
    if request.method == 'POST':
        db = get_session()
        try:
            classe = Classe(
                codigo_classe=request.form['codigo_classe'],
                unidade_curricular=request.form['unidade_curricular'],
                ano=int(request.form['ano']),
                semestre=int(request.form['semestre'])
            )
            db.add(classe)
            db.commit()
            flash('Classe criada com sucesso!')
            return redirect(url_for('admin.classes'))
        except Exception as e:
            db.rollback()
            flash(f'Erro ao criar classe: {str(e)}')
        finally:
            db.close()
    return render_template('admin/classes/form.html')

@admin_bp.route('/classes/editar/<int:id>', methods=['GET', 'POST'])
@login_required
def editar_classe(id):
    db = get_session()
    try:
        classe = db.query(Classe).get(id)
        if not classe:
            flash('Classe não encontrada')
            return redirect(url_for('admin.classes'))
            
        if request.method == 'POST':
            classe.codigo_classe = request.form['codigo_classe']
            classe.unidade_curricular = request.form['unidade_curricular']
            classe.ano = int(request.form['ano'])
            classe.semestre = int(request.form['semestre'])
            
            db.commit()
            flash('Classe atualizada com sucesso!')
            return redirect(url_for('admin.classes'))
            
        return render_template('admin/classes/form.html', classe=classe)
    except Exception as e:
        db.rollback()
        flash(f'Erro ao editar classe: {str(e)}')
        return redirect(url_for('admin.classes'))
    finally:
        db.close()

@admin_bp.route('/classes/excluir/<int:id>')
@login_required
def excluir_classe(id):
    db = get_session()
    try:
        classe = db.query(Classe).get(id)
        if classe:
            classe.soft_delete()  # Usar soft delete em vez de delete
            db.commit()
            flash('Classe excluída com sucesso!')
        else:
            flash('Classe não encontrada')
    except Exception as e:
        db.rollback()
        flash(f'Erro ao excluir classe: {str(e)}')
    finally:
        db.close()
    return redirect(url_for('admin.classes'))

# CRUD Estudantes
@admin_bp.route('/estudantes')
@login_required
def estudantes():
    db = get_session()
    try:
        # Query base com contagem de atividades distintas e total de tentativas
        query = db.query(
            Estudante,
            func.count(distinct(AtividadeRealizada.id_atividade)).label('total_atividades'),
            func.count(AtividadeRealizada.id).label('total_tentativas')
        ).outerjoin(
            AtividadeRealizada,
            (AtividadeRealizada.id_estudante == Estudante.id) & 
            (AtividadeRealizada.ativo == True)
        ).filter(
            Estudante.ativo == True
        ).group_by(
            Estudante.id
        )
        
        # Aplicar filtros
        if nome_filtro := request.args.get('nome'):
            query = query.filter(Estudante.nome.ilike(f'%{nome_filtro}%'))
            
        if classe_filtro := request.args.get('classe'):
            query = query.join(
                estudante_classe,
                Estudante.id == estudante_classe.c.id_estudante
            ).filter(
                estudante_classe.c.id_classe == classe_filtro
            )
        
        # Ordenar por nome
        query = query.order_by(Estudante.nome)
        
        # Buscar estudantes e classes para o filtro
        estudantes = query.all()
        classes = db.query(Classe).filter_by(ativo=True).all()
        
        return render_template('admin/estudantes/index.html', 
                             estudantes=estudantes,
                             classes=classes)
    finally:
        db.close()

@admin_bp.route('/estudantes/novo', methods=['GET', 'POST'])
@login_required
def novo_estudante():
    db = get_session()
    try:
        if request.method == 'POST':
            estudante = Estudante(
                nome=request.form['nome'],
                email=request.form['email']
            )
            
            # Adicionar às classes selecionadas
            classes_ids = request.form.getlist('classes')
            classes = db.query(Classe).filter(Classe.id.in_(classes_ids)).all()
            estudante.classes.extend(classes)
            
            db.add(estudante)
            db.commit()
            flash('Estudante criado com sucesso!')
            return redirect(url_for('admin.estudantes'))
            
        # Para o formulário GET, buscar todas as classes ativas disponíveis
        classes = db.query(Classe).filter_by(ativo=True).all()
        return render_template('admin/estudantes/form.html', classes=classes)
    except Exception as e:
        db.rollback()
        flash(f'Erro ao criar estudante: {str(e)}')
        return redirect(url_for('admin.estudantes'))
    finally:
        db.close()

@admin_bp.route('/estudantes/editar/<int:id>', methods=['GET', 'POST'])
@login_required
def editar_estudante(id):
    db = get_session()
    try:
        estudante = db.query(Estudante).filter_by(id=id, ativo=True).first()
        if not estudante:
            flash('Estudante não encontrado')
            return redirect(url_for('admin.estudantes'))
            
        if request.method == 'POST':
            estudante.nome = request.form['nome']
            estudante.email = request.form['email']
            
            # Atualizar classes
            classes_ids = request.form.getlist('classes')
            classes = db.query(Classe).filter(Classe.id.in_(classes_ids)).all()
            estudante.classes = classes
            
            db.commit()
            flash('Estudante atualizado com sucesso!')
            return redirect(url_for('admin.estudantes'))
            
        # Para o formulário GET
        classes = db.query(Classe).filter_by(ativo=True).all()
        return render_template('admin/estudantes/form.html', 
                             estudante=estudante,
                             classes=classes)
    except Exception as e:
        db.rollback()
        flash(f'Erro ao editar estudante: {str(e)}')
        return redirect(url_for('admin.estudantes'))
    finally:
        db.close()

@admin_bp.route('/estudantes/excluir/<int:id>')
@login_required
def excluir_estudante(id):
    db = get_session()
    try:
        estudante = db.query(Estudante).get(id)
        if estudante:
            estudante.soft_delete()  # Usar soft delete em vez de delete
            db.commit()
            flash('Estudante excluído com sucesso!')
        else:
            flash('Estudante não encontrado')
    except Exception as e:
        db.rollback()
        flash(f'Erro ao excluir estudante: {str(e)}')
    finally:
        db.close()
    return redirect(url_for('admin.estudantes'))

# CRUD Configurações
@admin_bp.route('/configuracoes')
@login_required
def configuracoes():
    db = get_session()
    try:
        configuracoes = db.query(Configuracao).all()
        return render_template('admin/configuracoes/index.html', configuracoes=configuracoes)
    finally:
        db.close()

@admin_bp.route('/configuracoes/nova', methods=['GET', 'POST'])
@login_required
def nova_configuracao():
    if request.method == 'POST':
        db = get_session()
        try:
            configuracao = Configuracao(
                chave=request.form['chave'],
                valor=request.form['valor'],
                descricao=request.form['descricao']
            )
            db.add(configuracao)
            db.commit()
            flash('Configuração criada com sucesso!')
            return redirect(url_for('admin.configuracoes'))
        except Exception as e:
            db.rollback()
            flash(f'Erro ao criar configuração: {str(e)}')
        finally:
            db.close()
    return render_template('admin/configuracoes/form.html')

@admin_bp.route('/configuracoes/editar/<int:id>', methods=['GET', 'POST'])
@login_required
def editar_configuracao(id):
    db = get_session()
    try:
        configuracao = db.query(Configuracao).get(id)
        if not configuracao:
            flash('Configuração não encontrada')
            return redirect(url_for('admin.configuracoes'))
            
        if request.method == 'POST':
            configuracao.valor = request.form['valor']
            configuracao.descricao = request.form['descricao']
            
            db.commit()
            flash('Configuração atualizada com sucesso!')
            return redirect(url_for('admin.configuracoes'))
            
        return render_template('admin/configuracoes/form.html', configuracao=configuracao)
    except Exception as e:
        db.rollback()
        flash(f'Erro ao editar configuração: {str(e)}')
        return redirect(url_for('admin.configuracoes'))
    finally:
        db.close()

@admin_bp.route('/configuracoes/excluir/<int:id>')
@login_required
def excluir_configuracao(id):
    db = get_session()
    try:
        configuracao = db.query(Configuracao).get(id)
        if configuracao:
            configuracao.soft_delete()  # Usar soft delete em vez de delete
            db.commit()
            flash('Configuração excluída com sucesso!')
        else:
            flash('Configuração não encontrada')
    except Exception as e:
        db.rollback()
        flash(f'Erro ao excluir configuração: {str(e)}')
    finally:
        db.close()
    return redirect(url_for('admin.configuracoes'))

@admin_bp.route('/atividades/visualizar/<int:id_estudante>/<int:id_atividade>')
@login_required
def visualizar_atividade(id_estudante, id_atividade):
    db = get_session()
    try:
        estudante = db.query(Estudante).get(id_estudante)
        atividade = db.query(Atividade).get(id_atividade)
        
        if not estudante or not atividade:
            flash('Estudante ou atividade não encontrada')
            return redirect(url_for('admin.dashboard'))
            
        # Buscar todas as tentativas desta atividade para este estudante
        tentativas = (db.query(AtividadeRealizada)
                     .filter_by(
                         id_estudante=id_estudante,
                         id_atividade=id_atividade,
                         ativo=True
                     )
                     .order_by(AtividadeRealizada.data_registro)
                     .all())
        
        # Calcular estatísticas
        total_tentativas = len(tentativas)
        tentativas_sucesso = sum(1 for t in tentativas if 'bem-sucedida' in t.resultado_compilacao)
        tentativas_erro = total_tentativas - tentativas_sucesso
        
        resumo = {
            'total': total_tentativas,
            'sucesso': tentativas_sucesso,
            'erro': tentativas_erro
        }
        
        return render_template('admin/atividades/visualizar.html',
                             estudante=estudante,
                             atividade=atividade,
                             tentativas=tentativas,
                             resumo=resumo)
    finally:
        db.close()

@admin_bp.route('/atividades/casos-teste/<int:id>', methods=['GET', 'POST'])
@login_required
def casos_teste(id):
    db = get_session()
    try:
        atividade = db.query(Atividade).get(id)
        if not atividade:
            flash('Atividade não encontrada')
            return redirect(url_for('admin.atividades'))
            
        if request.method == 'POST':
            # Remover casos de teste existentes
            for caso in atividade.casos_teste:
                db.delete(caso)
            
            # Adicionar novos casos de teste
            entradas = request.form.getlist('entradas[]')
            saidas = request.form.getlist('saidas[]')
            pesos = request.form.getlist('pesos[]')
            ordens = request.form.getlist('ordens[]')
            visiveis = request.form.getlist('visiveis[]')
            
            for i in range(len(entradas)):
                caso = CasoTeste(
                    id_atividade=id,
                    entrada=entradas[i],
                    saida_esperada=saidas[i],
                    peso=float(pesos[i]),
                    ordem=int(ordens[i]),
                    visivel=str(i) in visiveis
                )
                db.add(caso)
            
            db.commit()
            flash('Casos de teste atualizados com sucesso!')
            return redirect(url_for('admin.atividades'))
            
        return render_template('admin/atividades/casos_teste.html', atividade=atividade)
    except Exception as e:
        db.rollback()
        flash(f'Erro ao gerenciar casos de teste: {str(e)}')
        return redirect(url_for('admin.atividades'))
    finally:
        db.close()

@admin_bp.route('/estudantes/importar', methods=['POST'])
@login_required
def importar_estudantes():
    if 'arquivo' not in request.files:
        flash('Nenhum arquivo enviado', 'error')
        return redirect(url_for('admin.estudantes'))
    
    arquivo = request.files['arquivo']
    if not arquivo.filename.endswith('.csv'):
        flash('Por favor, envie um arquivo CSV', 'error')
        return redirect(url_for('admin.estudantes'))
    
    db = get_session()
    estudantes_para_adicionar = []  # Lista para acumular estudantes válidos
    
    try:
        csv_file = TextIOWrapper(arquivo, encoding='utf-8')
        reader = csv.DictReader(csv_file)
        
        resultados = {
            'total': 0,
            'sucesso': 0,
            'ignorados': 0,
            'erros': []
        }
        
        for row in reader:
            try:
                resultados['total'] += 1
                
                # Validar dados obrigatórios
                if not all(key in row for key in ['nome', 'email', 'classe']):
                    raise ValueError("Campos obrigatórios faltando")
                
                # Buscar classe pelo código
                classe = db.query(Classe).filter_by(
                    codigo_classe=row['classe'].strip(),
                    ativo=True
                ).first()
                
                if not classe:
                    raise ValueError(f"Classe não encontrada: {row['classe']}")
                
                # Verificar se estudante já existe
                estudante_existente = db.query(Estudante).filter_by(
                    email=row['email'].strip()
                ).first()
                
                if estudante_existente:
                    # Verificar se já está inscrito na classe
                    if classe in estudante_existente.classes:
                        resultados['ignorados'] += 1
                        continue  # Pula para o próximo registro
                    else:
                        # Adicionar estudante existente à nova classe
                        estudante_existente.classes.append(classe)
                        resultados['sucesso'] += 1
                else:
                    # Criar novo estudante
                    novo_estudante = Estudante(
                        nome=row['nome'].strip(),
                        email=row['email'].strip()
                    )
                    novo_estudante.classes.append(classe)
                    estudantes_para_adicionar.append(novo_estudante)
                    resultados['sucesso'] += 1
                
            except Exception as e:
                resultados['erros'].append(f"Linha {resultados['total']}: {str(e)}")
        
        if resultados['erros']:
            # Se houver erros, fazer rollback
            db.rollback()
            for erro in resultados['erros']:
                flash(erro, 'error')
        else:
            # Adicionar todos os novos estudantes
            for estudante in estudantes_para_adicionar:
                db.add(estudante)
            
            # Commit das alterações
            db.commit()
            
            mensagem = (
                f"Importação concluída! "
                f"{resultados['sucesso']} estudantes processados, "
                f"{resultados['ignorados']} ignorados (já inscritos)."
            )
            flash(mensagem, 'success')
            
    except Exception as e:
        db.rollback()
        flash(f'Erro ao processar arquivo: {str(e)}', 'error')
    finally:
        db.close()
    
    return redirect(url_for('admin.estudantes'))

@admin_bp.route('/perfil', methods=['GET', 'POST'])
@login_required
def perfil():
    db = get_session()
    try:
        admin = db.query(Admin).get(session['admin_id'])
        if not admin:
            flash('Administrador não encontrado')
            return redirect(url_for('admin.dashboard'))
            
        if request.method == 'POST':
            senha_atual = request.form.get('senha_atual')
            nova_senha = request.form.get('nova_senha')
            confirmar_senha = request.form.get('confirmar_senha')
            
            # Verificar senha atual
            if not admin.check_password(senha_atual):
                flash('Senha atual incorreta')
                return render_template('admin/perfil.html', admin=admin)
                
            # Validar nova senha
            if nova_senha != confirmar_senha:
                flash('As novas senhas não coincidem')
                return render_template('admin/perfil.html', admin=admin)
                
            if len(nova_senha) < 6:
                flash('A nova senha deve ter pelo menos 6 caracteres')
                return render_template('admin/perfil.html', admin=admin)
                
            # Atualizar senha
            admin.set_password(nova_senha)
            db.commit()
            flash('Senha alterada com sucesso!')
            return redirect(url_for('admin.dashboard'))
            
        return render_template('admin/perfil.html', admin=admin)
    except Exception as e:
        db.rollback()
        flash(f'Erro ao atualizar perfil: {str(e)}')
        return redirect(url_for('admin.dashboard'))
    finally:
        db.close()

def get_nivel_texto(nivel):
    niveis = {
        1: 'Básico',
        2: 'Intermediário',
        3: 'Avançado',
        4: 'Especialista',
        5: 'Desafio'
    }
    return niveis.get(nivel, 'Desconhecido')

@admin_bp.route('/logs')
@login_required
def logs():
    db = get_session()
    try:
        # Parâmetros de paginação
        page = request.args.get('page', 1, type=int)
        per_page = 50  # logs por página
        
        # Base query com filtros
        query = db.query(Log).order_by(Log.data_hora.desc())
        
        # Aplicar filtros
        if request.args.get('tipo'):
            query = query.filter(Log.tipo == request.args['tipo'])
            
        if request.args.get('username'):
            query = query.filter(Log.username.ilike(f"%{request.args['username']}%"))
            
        if request.args.get('ip'):
            query = query.filter(Log.ip.ilike(f"%{request.args['ip']}%"))
            
        if request.args.get('data_inicio'):
            data_inicio = datetime.strptime(request.args['data_inicio'], '%Y-%m-%d')
            query = query.filter(Log.data_hora >= data_inicio)
            
        if request.args.get('data_fim'):
            data_fim = datetime.strptime(request.args['data_fim'], '%Y-%m-%d') + timedelta(days=1)
            query = query.filter(Log.data_hora < data_fim)
        
        # Contar total de registros antes da paginação
        total_registros = query.count()
        
        # Aplicar paginação
        logs = query.offset((page - 1) * per_page).limit(per_page).all()
        
        # Calcular total de páginas
        total_paginas = (total_registros + per_page - 1) // per_page
        
        # Preparar lista de tipos de logs para o filtro
        tipos_logs = [
            'login_sucesso',
            'login_falha',
            'logout',
            'seguranca_falha'
        ]

        return render_template('admin/logs/index.html',
                             logs=logs,
                             pagina_atual=page,
                             total_paginas=total_paginas,
                             tipos_logs=tipos_logs,
                             filtro_tipo=request.args.get('tipo'),
                             filtro_username=request.args.get('username'),
                             filtro_ip=request.args.get('ip'),
                             filtro_data_inicio=request.args.get('data_inicio'),
                             filtro_data_fim=request.args.get('data_fim'))
    finally:
        db.close() 