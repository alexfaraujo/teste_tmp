from functools import wraps
from flask import session, redirect, url_for, flash
from datetime import datetime, timedelta
from models import Admin

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'admin_id' not in session:
            return redirect(url_for('admin.login'))
        
        # Verificar tempo de inatividade (30 minutos)
        if 'last_activity' in session:
            last_activity = datetime.fromisoformat(session['last_activity'])
            if datetime.now() - last_activity > timedelta(minutes=30):
                session.clear()
                flash('Sessão expirada. Por favor, faça login novamente.')
                return redirect(url_for('admin.login'))
        
        # Atualizar último acesso
        session['last_activity'] = datetime.now().isoformat()
        return f(*args, **kwargs)
    return decorated_function

def check_brute_force():
    if 'login_attempts' not in session:
        session['login_attempts'] = 0
        session['first_attempt'] = datetime.now().isoformat()
    
    # Resetar tentativas após 15 minutos
    first_attempt = datetime.fromisoformat(session['first_attempt'])
    if datetime.now() - first_attempt > timedelta(minutes=15):
        session['login_attempts'] = 0
        session['first_attempt'] = datetime.now().isoformat()
    
    # Bloquear após 5 tentativas
    if session['login_attempts'] >= 5:
        return False
    return True 