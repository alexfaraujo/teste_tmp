from functools import wraps
from flask import session, redirect, url_for, flash, request
from models import Admin, Log
from database import get_session
from datetime import datetime, timedelta

def registrar_log(tipo, username, ip, detalhes=None):
    db = get_session()
    try:
        log = Log(
            tipo=tipo,
            username=username,
            ip=ip,
            detalhes=detalhes
        )
        db.add(log)
        db.commit()
    finally:
        db.close()

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'admin_id' not in session:
            flash('Por favor, faça login para acessar esta página', 'error')
            return redirect(url_for('admin.login'))
        return f(*args, **kwargs)
    return decorated_function

def check_brute_force(username, ip):
    db = get_session()
    try:
        # Verificar tentativas de login nos últimos 5 minutos
        cinco_minutos_atras = datetime.now() - timedelta(minutes=5)
        tentativas = db.query(Log).filter(
            Log.tipo == 'login_falha',
            Log.username == username,
            Log.ip == ip,
            Log.data_hora >= cinco_minutos_atras
        ).count()
        
        return tentativas >= 5  # Limite de 5 tentativas em 5 minutos
    finally:
        db.close() 