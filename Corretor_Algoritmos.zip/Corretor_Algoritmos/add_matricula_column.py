import sqlite3

# Conectar ao banco de dados
conn = sqlite3.connect('atividades.db')
cursor = conn.cursor()

try:
    # Adicionar a coluna matricula
    cursor.execute('ALTER TABLE estudante ADD COLUMN matricula VARCHAR(20)')
    
    # Commit das alterações
    conn.commit()
    print("Coluna 'matricula' adicionada com sucesso à tabela 'estudante'")
    
except sqlite3.OperationalError as e:
    if "duplicate column name" in str(e):
        print("A coluna 'matricula' já existe na tabela 'estudante'")
    else:
        print(f"Erro ao adicionar coluna: {e}")
finally:
    # Fechar conexão
    conn.close() 