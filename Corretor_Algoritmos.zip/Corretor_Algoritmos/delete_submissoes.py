import sqlite3

# Conectar ao banco de dados
conn = sqlite3.connect('atividades.db')
cursor = conn.cursor()

# Verificar se a tabela existe
cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='submissoes'")
if cursor.fetchone():
    # Se a tabela existir, deletá-la
    cursor.execute("DROP TABLE submissoes")
    print("Tabela 'submissoes' deletada com sucesso!")
else:
    print("Tabela 'submissoes' não existe no banco de dados.")

# Salvar as alterações e fechar a conexão
conn.commit()
conn.close() 