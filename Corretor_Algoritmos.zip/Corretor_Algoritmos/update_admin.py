from database import get_db
from models import Admin
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

def update_admin():
    # Conectar ao banco de dados
    engine = create_engine('sqlite:///atividades.db')
    Session = sessionmaker(bind=engine)
    session = Session()

    try:
        # Remover todos os admins existentes
        session.query(Admin).delete()
        
        # Criar novo admin
        novo_admin = Admin(
            username='admin',
            nome='Administrador',
            email='admin@ifms.edu.br'
        )
        novo_admin.set_password('admin$01')
        
        # Adicionar e commitar
        session.add(novo_admin)
        session.commit()
        
        print("Admin atualizado com sucesso!")
        print("Username: admin")
        print("Senha: admin$01")
        
    except Exception as e:
        print(f"Erro ao atualizar admin: {str(e)}")
        session.rollback()
    finally:
        session.close()

if __name__ == '__main__':
    update_admin() 