import re
import os
import subprocess
import tempfile

# Lista de funções e comandos proibidos em C
FORBIDDEN_C_FUNCTIONS = [
    'system', 'popen', 'exec', 'fork', 'spawn',
    'systemctl', 'sudo', 'su', 'chmod', 'chown',
    'rm', 'del', 'delete', 'format', 'mkfs',
    'dd', 'cat', 'echo','fprintf',
    'sprintf', 'snprintf', 'vsprintf', 'vsnprintf',
    'fopen', 'fclose', 'fread', 'fwrite', 'fseek',
    'ftell', 'rewind', 'fgetc', 'fputc', 'fgets',
    'fputs', 'getc', 'putc', 'putchar',
    'gets', 'puts', 'fscanf', 'sscanf',
    'vscanf', 'vfscanf', 'vsscanf', 'perror',
    'strerror', 'tmpfile', 'tmpnam', 'tempnam',
    'mktemp', 'mkstemp', 'mkdtemp', 'realpath',
    'canonicalize_file_name', 'readlink',
    'symlink', 'link', 'unlink', 'remove',
    'rename', 'mkdir', 'rmdir', 'chdir',
    'getcwd', 'getwd', 'get_current_dir_name',
    'opendir', 'readdir', 'closedir', 'rewinddir',
    'telldir', 'seekdir', 'scandir', 'alphasort',
    'versionsort', 'ftw', 'nftw', 'glob', 'globfree',
    'wordexp', 'wordfree', 'fnmatch', 'fnmatch',
    'regcomp', 'regexec', 'regerror', 'regfree',
    'dlopen', 'dlclose', 'dlsym', 'dlerror',
    'backtrace', 'backtrace_symbols', 'backtrace_symbols_fd',
    'dladdr', 'dladdr1', 'dlinfo', 'dlvsym',
    'dl_iterate_phdr', 'dlopen1', 'dlmopen',
    'dlsym1', 'dlvsym1', 'dladdr1', 'dlinfo1',
    'dl_iterate_phdr1', 'dlopen2', 'dlmopen2',
    'dlsym2', 'dlvsym2', 'dladdr2', 'dlinfo2',
    'dl_iterate_phdr2', 'dlopen3', 'dlmopen3',
    'dlsym3', 'dlvsym3', 'dladdr3', 'dlinfo3',
    'dl_iterate_phdr3', 'dlopen4', 'dlmopen4',
    'dlsym4', 'dlvsym4', 'dladdr4', 'dlinfo4',
    'dl_iterate_phdr4', 'dlopen5', 'dlmopen5',
    'dlsym5', 'dlvsym5', 'dladdr5', 'dlinfo5',
    'dl_iterate_phdr5', 'dlopen6', 'dlmopen6',
    'dlsym6', 'dlvsym6', 'dladdr6', 'dlinfo6',
    'dl_iterate_phdr6', 'dlopen7', 'dlmopen7',
    'dlsym7', 'dlvsym7', 'dladdr7', 'dlinfo7',
    'dl_iterate_phdr7', 'dlopen8', 'dlmopen8',
    'dlsym8', 'dlvsym8', 'dladdr8', 'dlinfo8',
    'dl_iterate_phdr8', 'dlopen9', 'dlmopen9',
    'dlsym9', 'dlvsym9', 'dladdr9', 'dlinfo9',
    'dl_iterate_phdr9', 'dlopen10', 'dlmopen10',
    'dlsym10', 'dlvsym10', 'dladdr10', 'dlinfo10',
    'dl_iterate_phdr10'
]

# Lista de comandos do sistema proibidos
FORBIDDEN_SYSTEM_COMMANDS = [
    'rm', 'del', 'delete', 'format', 'mkfs',
    'dd', 'cat', 'echo', 'printf', 'fprintf',
    'sprintf', 'snprintf', 'vsprintf', 'vsnprintf',
    'fopen', 'fclose', 'fread', 'fwrite', 'fseek',
    'ftell', 'rewind', 'fgetc', 'fputc', 'fgets',
    'fputs', 'getc', 'putc', 'getchar', 'putchar',
    'gets', 'puts', 'scanf', 'fscanf', 'sscanf',
    'vscanf', 'vfscanf', 'vsscanf', 'perror',
    'strerror', 'tmpfile', 'tmpnam', 'tempnam',
    'mktemp', 'mkstemp', 'mkdtemp', 'realpath',
    'canonicalize_file_name', 'readlink',
    'symlink', 'link', 'unlink', 'remove',
    'rename', 'mkdir', 'rmdir', 'chdir',
    'getcwd', 'getwd', 'get_current_dir_name',
    'opendir', 'readdir', 'closedir', 'rewinddir',
    'telldir', 'seekdir', 'scandir', 'alphasort',
    'versionsort', 'ftw', 'nftw', 'glob', 'globfree',
    'wordexp', 'wordfree', 'fnmatch', 'fnmatch',
    'regcomp', 'regexec', 'regerror', 'regfree',
    'dlopen', 'dlclose', 'dlsym', 'dlerror',
    'backtrace', 'backtrace_symbols', 'backtrace_symbols_fd',
    'dladdr', 'dladdr1', 'dlinfo', 'dlvsym',
    'dl_iterate_phdr', 'dlopen1', 'dlmopen',
    'dlsym1', 'dlvsym1', 'dladdr1', 'dlinfo1',
    'dl_iterate_phdr1', 'dlopen2', 'dlmopen2',
    'dlsym2', 'dlvsym2', 'dladdr2', 'dlinfo2',
    'dl_iterate_phdr2', 'dlopen3', 'dlmopen3',
    'dlsym3', 'dlvsym3', 'dladdr3', 'dlinfo3',
    'dl_iterate_phdr3', 'dlopen4', 'dlmopen4',
    'dlsym4', 'dlvsym4', 'dladdr4', 'dlinfo4',
    'dl_iterate_phdr4', 'dlopen5', 'dlmopen5',
    'dlsym5', 'dlvsym5', 'dladdr5', 'dlinfo5',
    'dl_iterate_phdr5', 'dlopen6', 'dlmopen6',
    'dlsym6', 'dlvsym6', 'dladdr6', 'dlinfo6',
    'dl_iterate_phdr6', 'dlopen7', 'dlmopen7',
    'dlsym7', 'dlvsym7', 'dladdr7', 'dlinfo7',
    'dl_iterate_phdr7', 'dlopen8', 'dlmopen8',
    'dlsym8', 'dlvsym8', 'dladdr8', 'dlinfo8',
    'dl_iterate_phdr8', 'dlopen9', 'dlmopen9',
    'dlsym9', 'dlvsym9', 'dladdr9', 'dlinfo9',
    'dl_iterate_phdr9', 'dlopen10', 'dlmopen10',
    'dlsym10', 'dlvsym10', 'dladdr10', 'dlinfo10',
    'dl_iterate_phdr10'
]

def validate_c_code(code):
    """
    Valida o código C para garantir que não contém funções ou operações proibidas.
    Retorna (is_safe, error_message, violation_details)
    """
    # Usar a lista global de funções proibidas
    for func in FORBIDDEN_C_FUNCTIONS:
        # Regex para pegar chamadas de função, mesmo com espaços
        pattern = rf"\b{re.escape(func)}\s*\("
        if re.search(pattern, code):
            return False, "Erro de compilação: Código contém construções não permitidas. Verifique a sintaxe e tente novamente.", f"Função proibida detectada: {func}"

    # Lista de operações perigosas (mantida localmente)
    dangerous_operations = [
        'asm', '__asm__', 'asm volatile', '__asm__ volatile',
        'syscall', 'sysenter', 'int 0x80', 'int 0x2e',
        'rdtsc', 'cpuid', 'inb', 'outb', 'inw', 'outw', 'inl', 'outl',
        'cli', 'sti', 'hlt', 'lgdt', 'lidt', 'lldt', 'lmsw', 'ltr',
        'sgdt', 'sidt', 'sldt', 'smsw', 'str', 'verr', 'verw',
        'invlpg', 'invpcid', 'invept', 'invvpid', 'vmcall', 'vmclear',
        'vmfunc', 'vmlaunch', 'vmptrld', 'vmptrst', 'vmread', 'vmresume',
        'vmwrite', 'vmxoff', 'vmxon', 'xsave', 'xsaveopt', 'xrstor',
        'xgetbv', 'xsetbv', 'rdrand', 'rdseed', 'prefetch', 'prefetchw',
        'clflush', 'clflushopt', 'clwb', 'pcommit', 'movnti', 'movntq',
        'movntdq', 'movntpd', 'movntps', 'sfence', 'mfence', 'lfence',
        'pause', 'monitor', 'mwait', 'rdpmc', 'rdtscp', 'sysret',
        'sysenter', 'sysexit', 'swapgs', 'wrmsr', 'rdmsr', 'wrpkru',
        'rdpkru', 'xsave', 'xsaveopt', 'xrstor', 'xgetbv', 'xsetbv'
    ]

    for op in dangerous_operations:
        if op in code:
            return False, "Erro de compilação: Código contém construções não permitidas. Verifique a sintaxe e tente novamente.", f"Operação perigosa detectada: {op}"

    return True, None, None

def compile_and_run_c(code, input_data=None, timeout=1.0, memory_limit=256):
    """
    Compila e executa código C com validação de segurança.
    Retorna (sucesso, saída, erro) onde:
    - sucesso: booleano indicando se a execução foi bem-sucedida
    - saída: string com a saída do programa
    - erro: string com mensagem de erro ou None
    """
    # Validar o código antes de compilar
    is_safe, error_message, violation_details = validate_c_code(code)
    if not is_safe:
        return False, None, error_message

    # Criar diretório temporário
    with tempfile.TemporaryDirectory() as temp_dir:
        # Criar arquivo de código fonte
        source_file = os.path.join(temp_dir, 'program.c')
        with open(source_file, 'w') as f:
            f.write(code)
        
        # Criar arquivo de entrada se fornecido
        input_file = None
        if input_data:
            input_file = os.path.join(temp_dir, 'input.txt')
            with open(input_file, 'w') as f:
                f.write(input_data)
        
        # Compilar o código
        executable = os.path.join(temp_dir, 'program')
        compile_cmd = ['gcc', '-o', executable, source_file]
        
        try:
            compile_result = subprocess.run(
                compile_cmd,
                capture_output=True,
                text=True,
                timeout=5.0
            )
            
            if compile_result.returncode != 0:
                return False, None, f"Erro de compilação: {compile_result.stderr}"
            
            # Executar o programa
            run_cmd = [executable]
            if input_file:
                with open(input_file, 'r') as f:
                    run_result = subprocess.run(
                        run_cmd,
                        stdin=f,
                        capture_output=True,
                        text=True,
                        timeout=timeout
                    )
            else:
                run_result = subprocess.run(
                    run_cmd,
                    capture_output=True,
                    text=True,
                    timeout=timeout
                )
            
            if run_result.returncode != 0:
                return False, None, f"Erro de execução: {run_result.stderr}"
            
            return True, run_result.stdout, None
            
        except subprocess.TimeoutExpired:
            return False, None, "Tempo limite de execução excedido"
        except Exception as e:
            return False, None, f"Erro inesperado: {str(e)}" 