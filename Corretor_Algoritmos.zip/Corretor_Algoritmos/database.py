from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from extensions import db
from flask import current_app
import os

def get_session():
    """Retorna uma sessão do banco de dados"""
    return db.session

def init_db():
    """Inicializa o banco de dados criando todas as tabelas"""
    from models import (
        Estudante, Classe, Atividade, CasoTeste, 
        AtividadeRealizada, Configuracao, Admin, Log,
        estudante_classe, atividade_classe
    )
    
    # Criar todas as tabelas
    db.create_all()

def get_db():
    return db.session

def validar_estudante(session, email):
    from models import Estudante
    print(f"Validando estudante com email: {email}")  # Log para debug
    estudante = session.query(Estudante).filter_by(email=email, ativo=True).first()
    print(f"Resultado da query: {estudante}")  # Log para debug
    return estudante

def validar_atividade(session, codigo):
    from models import Atividade
    return session.query(Atividade).filter_by(codigo=codigo, ativo=True).first()

def get_config(db, chave):
    from models import Configuracao
    config = db.query(Configuracao).filter(Configuracao.chave == chave).first()
    return config.valor if config else None

def verificar_limite_tentativas(db, id_estudante, id_atividade):
    from models import AtividadeRealizada, Configuracao
    # Buscar configuração de limite de tentativas
    config = db.query(Configuracao).filter_by(
        chave='limite_tentativas_atividade',
        ativo=True
    ).first()
    
    limite_tentativas = int(config.valor) if config else 5  # valor padrão se não encontrar config
    
    # Contar tentativas do estudante para esta atividade
    tentativas = db.query(AtividadeRealizada).filter_by(
        id_estudante=id_estudante,
        id_atividade=id_atividade,
        ativo=True
    ).count()
    
    return tentativas < limite_tentativas, limite_tentativas, tentativas 