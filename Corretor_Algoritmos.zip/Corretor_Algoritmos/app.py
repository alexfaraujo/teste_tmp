from flask import Flask, render_template, request, flash, redirect, url_for, jsonify, current_app
from compilador import CCompiler
import os
from datetime import datetime
from database import (
    init_db, validar_estudante, validar_atividade, 
    verificar_limite_tentativas
)
from models import AtividadeRealizada, Atividade, Estudante, Classe, Log
from admin_routes import admin_bp, init_admin
from extensions import db
import json
from werkzeug.utils import secure_filename
import subprocess
import re
from utils import validate_c_code

app = Flask(__name__)
app.secret_key = 'sua_chave_secreta_aqui'  # Use uma chave segura em produção

# Configuração do banco de dados
basedir = os.path.abspath(os.path.dirname(__file__))
app.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///{os.path.join(basedir, "atividades.db")}'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Configuração para upload de arquivos
app.config['UPLOAD_FOLDER'] = os.path.join(basedir, 'temp')
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Inicializa o banco de dados
db.init_app(app)
with app.app_context():
    init_db()

# Registrar blueprint do admin e inicializar
app.register_blueprint(admin_bp)
init_admin(app)

@app.template_filter('from_json')
def from_json(value):
    try:
        return json.loads(value)
    except:
        return []

@app.template_filter('format_json')
def format_json(value):
    """Formata JSON com indentação e caracteres especiais corretos"""
    return json.dumps(value, indent=2, ensure_ascii=False)

def formatar_json_para_db(value):
    """Formata JSON para salvar no banco de dados, preservando caracteres especiais"""
    return json.dumps(value, ensure_ascii=False)

def criar_diretorio(email, codigo_atividade):
    # Remove @ e domínio do email
    nome_pasta = email.split('@')[0]
    # Cria o caminho completo
    caminho = os.path.join(current_app.root_path, 'algoritmos', nome_pasta, codigo_atividade)
    # Cria os diretórios se não existirem
    os.makedirs(caminho, exist_ok=True)
    return caminho

def gerar_nome_arquivo():
    # Obtém a data e hora atual formatada
    data_hora = datetime.now().strftime('%Y%m%d-%H%M%S')
    # Gera o novo nome do arquivo
    novo_nome = f"{data_hora}.c"
    return novo_nome

def criar_resumo_execucao(resultados_testes, is_admin=False):
    resumo_execucao = []
    for i, teste in enumerate(resultados_testes, 1):
        resumo_teste = {
            'numero': i,
            'status': teste['status'],
            'mensagem': teste['mensagem'],
            'saida_obtida': teste['saida_obtida'],
            'peso': teste['peso'],
            'visivel': teste['visivel'],
            'entrada': teste['entrada'],
            'saida_esperada': teste['saida_esperada']
        }
        resumo_execucao.append(resumo_teste)
    return resumo_execucao

@app.route('/')
def index():
    return redirect(url_for('user_dashboard'))

@app.route('/user_dashboard', methods=['GET', 'POST'])
def user_dashboard():
    try:
        atividades = None
        email = None
        
        if request.method == 'POST':
            email = request.form.get('email')
            print(f"Email recebido: {email}")  # Log para debug
            
            if not email:
                flash('Email é obrigatório', 'error')
                return redirect(url_for('user_dashboard'))
            
            # Buscar atividades disponíveis para o email na data atual
            estudante = validar_estudante(db.session, email)
            print(f"Estudante encontrado: {estudante}")  # Log para debug
            
            if not estudante:
                flash('Estudante não encontrado', 'error')
                return redirect(url_for('user_dashboard'))
            
            atividades = []
            for classe in estudante.classes:
                for atividade in classe.atividades:
                    if (atividade.data_inicio <= datetime.now() and 
                        atividade.data_fim >= datetime.now()):
                        # Verificar se já foi realizada
                        realizada = db.session.query(AtividadeRealizada).filter_by(
                            id_estudante=estudante.id,
                            id_atividade=atividade.id
                        ).first()
                        
                        # Verificar tentativas restantes
                        _, limite, tentativas = verificar_limite_tentativas(
                            db.session,
                            estudante.id,
                            atividade.id
                        )
                        
                        # Adicionar informações de tentativas à atividade
                        atividade.tentativas_usadas = tentativas
                        atividade.tentativas_limite = limite
                        atividade.tentativas_restantes = limite - tentativas
                        
                        # Alterar status para 'Enviada para correção' se houver tentativa
                        atividade.status = 'Enviada para correção' if realizada else 'pendente'
                        atividades.append(atividade)
            
            print(f"Atividades encontradas: {len(atividades)}")  # Log para debug
        
        return render_template('user_dashboard.html', atividades=atividades, email=email)
    except Exception as e:
        print(f"Erro ao carregar dashboard: {str(e)}")  # Log para debug
        flash(f'Erro ao carregar dashboard: {str(e)}', 'error')
        return redirect(url_for('user_dashboard'))

@app.route('/submit_activity', methods=['GET', 'POST'])
def submit_activity():
    if request.method == 'POST':
        # Verificar se é um POST para processar arquivo ou apenas para mostrar o formulário
        if 'arquivo' in request.files:
            try:
                print("Iniciando processamento da submissão...")
                email = request.form.get('email')
                codigo = request.form.get('codigo')
                arquivo = request.files.get('arquivo')
                
                print(f"Email recebido: {email}")
                print(f"Código recebido: {codigo}")
                print(f"Arquivo recebido: {arquivo.filename if arquivo else 'None'}")
                
                if not email or not codigo or not arquivo:
                    flash('Email, código da atividade e arquivo são obrigatórios', 'error')
                    return redirect(url_for('user_dashboard'))
                
                # Validar estudante
                estudante = validar_estudante(db.session, email)
                if not estudante:
                    flash('Estudante não encontrado ou inativo', 'error')
                    return redirect(url_for('user_dashboard'))
                
                # Validar atividade
                atividade = validar_atividade(db.session, codigo)
                if not atividade:
                    flash('Atividade não encontrada ou inativa', 'error')
                    return redirect(url_for('user_dashboard'))

                # Verificar limite de tentativas ANTES de qualquer processamento
                pode_tentar, limite, tentativas = verificar_limite_tentativas(
                    db.session, 
                    estudante.id, 
                    atividade.id
                )
                
                if not pode_tentar:
                    # Buscar a última tentativa do estudante sem fazer nenhum processamento novo
                    ultima_tentativa = db.session.query(AtividadeRealizada).filter_by(
                        id_estudante=estudante.id,
                        id_atividade=atividade.id,
                        ativo=True
                    ).order_by(AtividadeRealizada.data_registro.desc()).first()
                    
                    return render_template(
                        'resultado_atividade.html',
                        atividade=atividade,
                        ultima_tentativa=ultima_tentativa,
                        limite_excedido=True,
                        limite=limite,
                        tentativas=tentativas
                    )

                # Se chegou aqui, ainda tem tentativas disponíveis
                # Definir caminho do arquivo antes de ler o conteúdo
                nome_pasta = email.split('@')[0]
                caminho_algoritmos = os.path.join(app.root_path, 'algoritmos', nome_pasta, codigo)
                os.makedirs(caminho_algoritmos, exist_ok=True)
                nome_arquivo = gerar_nome_arquivo()
                caminho_arquivo_algoritmos = os.path.join(caminho_algoritmos, nome_arquivo)

                # Ler o conteúdo do arquivo
                conteudo = arquivo.read().decode('utf-8')
                print(f"Conteúdo do arquivo recebido:\n{conteudo}")  # Log para debug

                # Validar código C antes de salvar/compilar
                if not validate_c_code(conteudo):
                    print("Código inválido detectado")
                    atividade_realizada = AtividadeRealizada(
                        id_estudante=estudante.id,
                        id_atividade=atividade.id,
                        nome_arquivo=nome_arquivo,
                        resultado_compilacao="Erro de compilação: Código contém construções não permitidas",
                        resultado_execucao="",
                        resultados_testes="[]",
                        nota=0.0
                    )
                    db.session.add(atividade_realizada)
                    db.session.commit()
                    return render_template('resultado_atividade.html', atividade=atividade, resultado=atividade_realizada)

                # Se passou na validação, salva o arquivo e segue o fluxo normal
                with open(caminho_arquivo_algoritmos, 'w') as f:
                    f.write(conteudo)
                
                print(f"Caminho do arquivo salvo: {caminho_arquivo_algoritmos}")  # Log para debug
                print(f"Conteúdo do arquivo salvo:")  # Log para debug
                with open(caminho_arquivo_algoritmos, 'r') as f:
                    print(f.read())  # Log para debug
                
                # Compilar e executar
                compilador = CCompiler(
                    arquivo_url=caminho_arquivo_algoritmos,
                    user_email=email,
                    user_ip=request.remote_addr
                )
                resultado_compilacao = compilador.compilar()
                print(f"Resultado da compilação: {resultado_compilacao}")  # Log para debug

                # Preparar entrada de teste (se houver)
                entrada_teste = None
                if hasattr(atividade, 'casos_teste') and atividade.casos_teste:
                    try:
                        print(f"Tipo de casos_teste: {type(atividade.casos_teste)}")
                        print(f"Quantidade de casos_teste: {len(atividade.casos_teste)}")
                        print(f"Primeiro caso de teste: {atividade.casos_teste[0]}")
                        entrada_teste = atividade.casos_teste[0].entrada
                        print(f"Entrada do caso de teste: {entrada_teste}")
                        if entrada_teste and not entrada_teste.endswith('\n'):
                            entrada_teste += '\n'
                    except Exception as e:
                        print(f"Erro ao obter entrada de teste: {e}")
                        entrada_teste = None
                # Se não houver casos de teste, definir entrada padrão para teste manual
                if not entrada_teste:
                    entrada_teste = "10\n20\n"  # Exemplo para dois inteiros
                    print(f"Entrada padrão definida para teste: {entrada_teste}")

                # Se compilou, executa; senão, salva erro de compilação
                if 'Compilação bem-sucedida' in resultado_compilacao['compilacao']:
                    resultado_execucao = compilador.executar(entrada=entrada_teste)
                    resultado_execucao_str = resultado_execucao['saida'] if resultado_execucao['sucesso'] else resultado_execucao['erro']
                    # Executar testes automáticos
                    resultados_testes = []
                    nota = 0.0
                    if hasattr(atividade, 'casos_teste') and atividade.casos_teste:
                        resultados_testes = compilador.testar(atividade.casos_teste)
                        print(f"Resultados dos testes: {resultados_testes}")
                        nota = sum(t['peso'] for t in resultados_testes if t['status'] == 'sucesso')
                else:
                    resultado_execucao_str = resultado_compilacao['execucao']
                    resultados_testes = []
                    nota = 0.0
                print(f"Saída da execução: {resultado_execucao_str}")

                # Salvar resultados
                atividade_realizada = AtividadeRealizada(
                    id_estudante=estudante.id,
                    id_atividade=atividade.id,
                    nome_arquivo=nome_arquivo,  # Usa o nome do arquivo gerado
                    resultado_compilacao=resultado_compilacao['compilacao'],
                    resultado_execucao=resultado_execucao_str,
                    resultados_testes=formatar_json_para_db(resultados_testes),
                    nota=nota
                )
                db.session.add(atividade_realizada)
                db.session.commit()

                return render_template('resultado_atividade.html', atividade=atividade, resultado=atividade_realizada)

            except Exception as e:
                print(f"Erro ao processar submissão: {str(e)}")  # Log para debug
                flash(f'Erro ao processar submissão: {str(e)}', 'error')
                return redirect(url_for('user_dashboard'))
        
        # Se não tem arquivo, é um POST para mostrar o formulário
        codigo = request.form.get('codigo')
        email = request.form.get('email')
        
        if not codigo:
            flash('Código da atividade é obrigatório', 'error')
            return redirect(url_for('user_dashboard'))
        
        atividade = validar_atividade(db.session, codigo)
        if not atividade:
            flash('Atividade não encontrada ou inativa', 'error')
            return redirect(url_for('user_dashboard'))
        
        # Se tiver email, verificar limite de tentativas
        tentativas = None
        limite = None
        if email:
            estudante = validar_estudante(db.session, email)
            if estudante:
                _, limite, tentativas = verificar_limite_tentativas(
                    db.session,
                    estudante.id,
                    atividade.id
                )
        
        return render_template(
            'submit_activity.html',
            atividade=atividade,
            email=email,
            tentativas=tentativas,
            limite=limite
        )
    
    return redirect(url_for('user_dashboard'))

if __name__ == '__main__':
    app.run(debug=True, port=5001, host='0.0.0.0') 