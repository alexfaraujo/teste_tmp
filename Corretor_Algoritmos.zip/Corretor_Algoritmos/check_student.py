import sqlite3

def check_student(email):
    conn = sqlite3.connect('atividades.db')
    cursor = conn.cursor()
    
    # Consulta todos os campos da tabela estudante para o email específico
    cursor.execute('''
        SELECT id, nome, email, ativo, data_registro 
        FROM estudante 
        WHERE email = ?
    ''', (email,))
    
    student = cursor.fetchone()
    
    if student:
        print("\nEstudante encontrado:")
        print(f"ID: {student[0]}")
        print(f"Nome: {student[1]}")
        print(f"Email: {student[2]}")
        print(f"Ativo: {student[3]}")
        print(f"Data Registro: {student[4]}")
    else:
        print("\nEstudante não encontrado!")
        
        # Listar todos os estudantes para verificação
        print("\nLista de todos os estudantes:")
        cursor.execute('SELECT email FROM estudante')
        students = cursor.fetchall()
        for s in students:
            print(f"- {s[0]}")
    
    conn.close()

if __name__ == "__main__":
    email = "alex.araujo@ifms.edu.br"
    check_student(email) 