"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { 
  BookOpen, 
  Plus, 
  Edit, 
  Trash2, 
  Loader2, 
  AlertCircle, 
  Check, 
  Building,
  Clock,
  Eye
} from "lucide-react";
import { onAuthStateChanged, User as FirebaseUser } from "firebase/auth";
import { auth } from "@/lib/firebase";

interface CourseUnit {
  id: number;
  name: string;
  code: string;
  workload: number | null;
  classroom: string | null;
  created_at: string;
}

export default function CoursesPage() {
  const router = useRouter();

  // Estados de Sessão do Firebase
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [checkingAuth, setCheckingAuth] = useState(true);

  // Estados das Unidades Curriculares
  const [courseUnits, setCourseUnits] = useState<CourseUnit[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  // Estados dos Modais
  const [showFormModal, setShowFormModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [modalMode, setModalMode] = useState<"create" | "edit">("create");
  const [selectedUnit, setSelectedUnit] = useState<CourseUnit | null>(null);

  // Estados do Modal de Resumo (Estudantes Matriculados)
  const [showSummaryModal, setShowSummaryModal] = useState(false);
  const [summaryStudents, setSummaryStudents] = useState<any[]>([]);
  const [loadingSummary, setLoadingSummary] = useState(false);
  const [summaryError, setSummaryError] = useState<string | null>(null);

  // Estados dos Inputs do Formulário
  const [name, setName] = useState("");
  const [code, setCode] = useState("");
  const [workload, setWorkload] = useState("");
  const [classroom, setClassroom] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  // Resolve dinamicamente a API URL baseada no hostname de acesso
  const getApiUrl = () => {
    const envUrl = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
    if (envUrl && !envUrl.includes("localhost") && !envUrl.includes("127.0.0.1")) {
      return envUrl;
    }
    if (typeof window !== "undefined") {
      const hostname = window.location.hostname;
      if (hostname !== "localhost" && hostname !== "127.0.0.1" && /^[0-9.]+$/.test(hostname)) {
        return `http://${hostname}:8000`;
      }
    }
    return envUrl;
  };

  const getApiKey = () => {
    return process.env.NEXT_PUBLIC_API_KEY ?? "";
  };

  // 1. Monitorar estado de autenticação do Firebase
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      if (user) {
        setFirebaseUser(user);
      } else {
        router.push("/");
      }
      setCheckingAuth(false);
    });

    return () => unsubscribe();
  }, [router]);

  // 2. Carregar Unidades Curriculares do backend
  const loadCourseUnits = async () => {
    try {
      setLoading(true);
      setError(null);
      const API_URL = getApiUrl();
      const apiKey = getApiKey();
      const userEmail = firebaseUser?.email || "";
      const response = await fetch(`${API_URL}/api/course_units`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": apiKey,
          "X-User-Email": userEmail,
        },
      });

      if (response.ok) {
        const data = await response.json();
        setCourseUnits(data);
      } else {
        throw new Error("Erro ao obter a lista de disciplinas.");
      }
    } catch (err: any) {
      console.error(err);
      setError("Não foi possível carregar as disciplinas. Verifique a conexão com o servidor.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (firebaseUser) {
      loadCourseUnits();
    }
  }, [firebaseUser]);

  // 3. Abrir modal de criação
  const handleOpenCreate = () => {
    setModalMode("create");
    setSelectedUnit(null);
    setName("");
    setCode("");
    setWorkload("");
    setClassroom("");
    setFormError(null);
    setShowFormModal(true);
  };

  // 4. Abrir modal de edição com dados populados
  const handleOpenEdit = (unit: CourseUnit) => {
    setModalMode("edit");
    setSelectedUnit(unit);
    setName(unit.name);
    setCode(unit.code);
    setWorkload(unit.workload ? unit.workload.toString() : "");
    setClassroom(unit.classroom || "");
    setFormError(null);
    setShowFormModal(true);
  };

  // 5. Abrir modal de confirmação de exclusão
  const handleOpenDelete = (unit: CourseUnit) => {
    setSelectedUnit(unit);
    setShowDeleteModal(true);
  };

  // 5.5 Abrir modal de resumo e buscar estudantes
  const handleOpenSummary = async (unit: CourseUnit) => {
    setSelectedUnit(unit);
    setShowSummaryModal(true);
    setLoadingSummary(true);
    setSummaryError(null);
    setSummaryStudents([]);
    
    try {
      const API_URL = getApiUrl();
      const apiKey = getApiKey();
      const userEmail = firebaseUser?.email || "";
      const response = await fetch(`${API_URL}/api/course_units/${unit.id}/students`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": apiKey,
          "X-User-Email": userEmail,
        },
      });

      if (response.ok) {
        const data = await response.json();
        setSummaryStudents(data);
      } else {
        throw new Error("Erro ao obter a lista de estudantes matriculados.");
      }
    } catch (err: any) {
      console.error(err);
      setSummaryError("Não foi possível carregar a lista de estudantes desta UC.");
    } finally {
      setLoadingSummary(false);
    }
  };

  // 6. Submeter formulário (Adicionar / Editar)
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    // Validações básicas de frontend
    if (!name.trim()) {
      setFormError("O nome completo da disciplina é obrigatório.");
      return;
    }
    if (!code.trim()) {
      setFormError("O código identificador único da disciplina é obrigatório.");
      return;
    }

    setSubmitting(true);
    const API_URL = getApiUrl();
    const apiKey = getApiKey();
    const userEmail = firebaseUser?.email || "";

    try {
      const payload = {
        name: name.trim(),
        code: code.trim().toUpperCase(),
        workload: workload ? parseInt(workload, 10) : null,
        classroom: classroom.trim() || null,
      };

      const url = modalMode === "create" 
        ? `${API_URL}/api/course_units`
        : `${API_URL}/api/course_units/${selectedUnit?.id}`;

      const method = modalMode === "create" ? "POST" : "PUT";

      const response = await fetch(url, {
        method: method,
        headers: {
          "Content-Type": "application/json",
          "x-api-key": apiKey,
          "X-User-Email": userEmail,
        },
        body: JSON.stringify(payload),
      });

      const data = await response.json();

      if (response.ok) {
        setSuccess(
          modalMode === "create" 
            ? `UC "${name}" criada com sucesso!` 
            : `UC "${name}" atualizada com sucesso!`
        );
        setShowFormModal(false);
        loadCourseUnits();
        
        // Limpa mensagem de sucesso após 3 segundos
        setTimeout(() => setSuccess(null), 3000);
      } else {
        throw new Error(data.detail || "Erro ao processar requisição.");
      }
    } catch (err: any) {
      console.error(err);
      setFormError(err.message || "Falha ao salvar dados. Verifique a chave de API ou conexão.");
    } finally {
      setSubmitting(false);
    }
  };

  // 7. Excluir Unidade Curricular
  const handleDelete = async () => {
    if (!selectedUnit) return;
    setSubmitting(true);
    const API_URL = getApiUrl();
    const apiKey = getApiKey();
    const userEmail = firebaseUser?.email || "";

    try {
      const response = await fetch(`${API_URL}/api/course_units/${selectedUnit.id}`, {
        method: "DELETE",
        headers: {
          "x-api-key": apiKey,
          "X-User-Email": userEmail,
        },
      });

      if (response.ok) {
        setSuccess(`UC "${selectedUnit.name}" excluída com sucesso!`);
        setShowDeleteModal(false);
        setSelectedUnit(null);
        loadCourseUnits();
        
        // Limpa mensagem de sucesso após 3 segundos
        setTimeout(() => setSuccess(null), 3000);
      } else {
        const data = await response.json().catch(() => ({}));
        throw new Error(data.detail || "Erro ao deletar disciplina.");
      }
    } catch (err: any) {
      console.error(err);
      alert(err.message || "Erro de conexão ao remover disciplina.");
    } finally {
      setSubmitting(false);
    }
  };

  if (checkingAuth) {
    return (
      <div className="flex-1 w-full flex flex-col items-center justify-center bg-[#F1F5F9] py-20 gap-4">
        <Loader2 className="w-8 h-8 text-primary animate-spin" />
        <span className="text-sm font-medium text-text-secondary">Verificando autenticação...</span>
      </div>
    );
  }

  return (
    <div className="flex-1 w-full px-4 py-8 md:py-12 flex flex-col items-center bg-[#F1F5F9]">
      <div className="w-full max-w-4xl rounded-2xl border border-[#E2E8F0] p-6 md:p-8 bg-white shadow-md relative">
        
        {/* Cabeçalho da Página */}
        <div className="border-b border-[#E2E8F0] pb-6 mb-8 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-primary/10 rounded-2xl text-primary">
              <BookOpen className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-text-primary">
                Gerenciar Unidades Curriculares (UCs)
              </h1>
              <p className="text-sm text-text-secondary mt-1">
                Liste, cadastre e edite as disciplinas e locais das aulas.
              </p>
            </div>
          </div>
          
          <button
            onClick={handleOpenCreate}
            className="inline-flex items-center gap-2 bg-primary hover:bg-primary-hover text-white font-semibold py-2.5 px-4 rounded-xl text-sm transition-all shadow-sm hover:shadow cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            Nova UC
          </button>
        </div>

        {/* Notificação Temporária de Sucesso */}
        {success && (
          <div className="bg-green-50 border border-green-200 text-green-700 rounded-xl p-4 flex items-start gap-2.5 text-sm mb-6 animate-in fade-in duration-200">
            <Check className="w-5 h-5 shrink-0 text-green-500 mt-0.5" />
            <span>{success}</span>
          </div>
        )}

        {/* Estado de Carregamento */}
        {loading ? (
          <div className="py-20 flex flex-col items-center justify-center gap-3">
            <Loader2 className="w-8 h-8 text-primary animate-spin" />
            <span className="text-sm text-text-secondary font-medium">Carregando disciplinas...</span>
          </div>
        ) : error ? (
          <div className="bg-red-50 border border-red-200 text-red-700 rounded-xl p-6 flex flex-col items-center gap-3 text-center mb-6">
            <AlertCircle className="w-8 h-8 text-red-500" />
            <span className="font-semibold">{error}</span>
            <button 
              onClick={loadCourseUnits}
              className="mt-2 text-xs font-bold text-primary hover:underline"
            >
              Tentar Novamente
            </button>
          </div>
        ) : courseUnits.length === 0 ? (
          /* Listagem Vazia */
          <div className="border-2 border-dashed border-[#E2E8F0] rounded-2xl p-12 text-center flex flex-col items-center justify-center gap-4 bg-[#F8FAFC]/50">
            <div className="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center text-slate-400">
              <BookOpen className="w-8 h-8" />
            </div>
            <div>
              <h3 className="font-bold text-text-primary text-base">Nenhuma Unidade Curricular cadastrada</h3>
              <p className="text-sm text-text-secondary mt-1 max-w-sm">
                Adicione suas disciplinas clicando no botão "+ Nova UC" acima para vincular os estudantes e gerenciar as frequências.
              </p>
            </div>
            <button
              onClick={handleOpenCreate}
              className="mt-2 text-sm font-semibold text-primary hover:underline"
            >
              Cadastrar primeira disciplina agora &rarr;
            </button>
          </div>
        ) : (
          /* Listagem Grid / Tabela */
          <div className="overflow-hidden border border-[#E2E8F0] rounded-2xl shadow-sm bg-white">
            <div className="overflow-x-auto">
              <table className="w-full border-collapse text-left text-sm">
                <thead>
                  <tr className="bg-[#F8FAFC] border-b border-[#E2E8F0]">
                    <th className="px-6 py-4 font-bold text-text-primary">Nome da UC</th>
                    <th className="px-6 py-4 font-bold text-text-primary">Código Único</th>
                    <th className="px-6 py-4 font-bold text-text-primary">Carga Horária</th>
                    <th className="px-6 py-4 font-bold text-text-primary">Sala / Local</th>
                    <th className="px-6 py-4 font-bold text-text-primary text-right">Ações</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#F1F5F9]">
                  {courseUnits.map((unit) => (
                    <tr 
                      key={unit.id}
                      className="hover:bg-[#F8FAFC]/50 transition-colors"
                    >
                      <td className="px-6 py-4 font-semibold text-text-primary">
                        {unit.name}
                      </td>
                      <td className="px-6 py-4">
                        <span className="font-mono text-xs font-semibold bg-[#F1F5F9] border border-[#E2E8F0] px-2 py-0.5 rounded text-text-secondary">
                          {unit.code}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-text-secondary font-medium">
                        {unit.workload ? `${unit.workload}h` : "—"}
                      </td>
                      <td className="px-6 py-4 text-text-secondary font-medium">
                        {unit.classroom || "—"}
                      </td>
                      <td className="px-6 py-4 text-right">
                        <div className="inline-flex gap-2">
                          <button
                            onClick={() => handleOpenSummary(unit)}
                            className="p-1.5 hover:bg-slate-100 rounded-lg text-text-secondary hover:text-indigo-600 transition-all cursor-pointer"
                            title="Ver Estudantes Matriculados"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleOpenEdit(unit)}
                            className="p-1.5 hover:bg-slate-100 rounded-lg text-text-secondary hover:text-primary transition-all cursor-pointer"
                            title="Editar UC"
                          >
                            <Edit className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleOpenDelete(unit)}
                            className="p-1.5 hover:bg-red-50 rounded-lg text-text-secondary hover:text-red-600 transition-all cursor-pointer"
                            title="Excluir UC"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ================= MODAL DE CADASTRO / EDIÇÃO ================= */}
        {showFormModal && (
          <div 
            className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-in fade-in duration-200"
            onClick={() => setShowFormModal(false)}
          >
            <div 
              className="bg-white rounded-3xl border border-[#E2E8F0] p-6 md:p-8 w-full max-w-md shadow-2xl relative animate-in zoom-in-95 duration-200"
              onClick={(e) => e.stopPropagation()}
            >
              <h2 className="text-xl font-bold text-text-primary flex items-center gap-2">
                <BookOpen className="w-5.5 h-5.5 text-primary" />
                {modalMode === "create" ? "Nova Unidade Curricular" : "Editar Unidade Curricular"}
              </h2>
              <p className="text-xs text-text-secondary mt-1">
                {modalMode === "create" 
                  ? "Insira os dados identificadores únicos da nova disciplina."
                  : "Atualize os campos desejados e salve as modificações."}
              </p>

              {formError && (
                <div className="bg-red-50 border border-red-200 text-red-700 rounded-xl p-3.5 flex items-start gap-2 text-xs mt-4 animate-in fade-in duration-150">
                  <AlertCircle className="w-4 h-4 shrink-0 text-red-500 mt-0.5" />
                  <span>{formError}</span>
                </div>
              )}

              <form onSubmit={handleSubmit} className="mt-5 flex flex-col gap-4">
                
                {/* Nome da Disciplina */}
                <div className="flex flex-col gap-1.5">
                  <label htmlFor="modal-uc-name" className="text-xs font-bold text-text-primary uppercase tracking-wide">
                    Nome da Disciplina *
                  </label>
                  <input
                    id="modal-uc-name"
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Ex: Processamento Paralelo"
                    className="w-full border border-[#CBD5E1] rounded-xl p-3 text-sm focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 bg-white text-text-primary"
                  />
                </div>

                {/* Código Único */}
                <div className="flex flex-col gap-1.5">
                  <label htmlFor="modal-uc-code" className="text-xs font-bold text-text-primary uppercase tracking-wide">
                    Código Identificador Único *
                  </label>
                  <input
                    id="modal-uc-code"
                    type="text"
                    required
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    placeholder="Ex: 20262001A"
                    className="w-full border border-[#CBD5E1] rounded-xl p-3 text-sm font-mono focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 bg-white text-text-primary"
                  />
                </div>

                {/* Grid Duplo: Carga Horária e Local */}
                <div className="grid grid-cols-2 gap-4">
                  
                  {/* Carga Horária */}
                  <div className="flex flex-col gap-1.5">
                    <label htmlFor="modal-uc-workload" className="text-xs font-bold text-text-primary uppercase tracking-wide flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-text-secondary" />
                      Carga Horária
                    </label>
                    <input
                      id="modal-uc-workload"
                      type="number"
                      min="1"
                      value={workload}
                      onChange={(e) => setWorkload(e.target.value)}
                      placeholder="Ex: 80"
                      className="w-full border border-[#CBD5E1] rounded-xl p-3 text-sm focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 bg-white text-text-primary"
                    />
                  </div>

                  {/* Sala / Local */}
                  <div className="flex flex-col gap-1.5">
                    <label htmlFor="modal-uc-classroom" className="text-xs font-bold text-text-primary uppercase tracking-wide flex items-center gap-1">
                      <Building className="w-3.5 h-3.5 text-text-secondary" />
                      Sala / Local
                    </label>
                    <input
                      id="modal-uc-classroom"
                      type="text"
                      value={classroom}
                      onChange={(e) => setClassroom(e.target.value)}
                      placeholder="Ex: Lab 3"
                      className="w-full border border-[#CBD5E1] rounded-xl p-3 text-sm focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 bg-white text-text-primary"
                    />
                  </div>

                </div>

                {/* Botões do Modal */}
                <div className="flex gap-3 mt-6">
                  <button
                    type="button"
                    onClick={() => setShowFormModal(false)}
                    className="flex-1 border border-[#CBD5E1] hover:bg-[#F8FAFC] text-text-primary font-semibold py-2.5 rounded-xl text-sm transition-all cursor-pointer"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    disabled={submitting}
                    className="flex-1 bg-primary hover:bg-primary-hover text-white font-semibold py-2.5 rounded-xl text-sm transition-all shadow-md flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-60"
                  >
                    {submitting && <Loader2 className="w-4 h-4 animate-spin" />}
                    Salvar UC
                  </button>
                </div>

              </form>
            </div>
          </div>
        )}

        {/* ================= MODAL DE CONFIRMAÇÃO DE EXCLUSÃO ================= */}
        {showDeleteModal && (
          <div 
            className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-in fade-in duration-200"
            onClick={() => setShowDeleteModal(false)}
          >
            <div 
              className="bg-white rounded-3xl border border-[#E2E8F0] p-6 md:p-8 w-full max-w-sm shadow-2xl relative text-center animate-in zoom-in-95 duration-200"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="w-12 h-12 rounded-full bg-red-50 text-red-600 flex items-center justify-center mx-auto mb-4">
                <Trash2 className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-text-primary">
                Excluir Unidade Curricular?
              </h3>
              <p className="text-sm text-text-secondary mt-2">
                Tem certeza de que deseja remover a disciplina <span className="font-bold text-text-primary">"{selectedUnit?.name}"</span>?
              </p>
              <p className="text-xs text-red-600 bg-red-50 border border-red-100 rounded-lg p-2.5 mt-3 font-medium">
                Atenção: Esta ação removerá a UC das matrículas de todos os estudantes associados e apagará os diários de chamada desta UC!
              </p>

              {/* Botões do Modal */}
              <div className="flex gap-3 mt-6">
                <button
                  type="button"
                  onClick={() => {
                    setShowDeleteModal(false);
                    setSelectedUnit(null);
                  }}
                  className="flex-1 border border-[#CBD5E1] hover:bg-[#F8FAFC] text-text-primary font-semibold py-2.5 rounded-xl text-sm transition-all cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  onClick={handleDelete}
                  disabled={submitting}
                  className="flex-1 bg-red-600 hover:bg-red-700 text-white font-semibold py-2.5 rounded-xl text-sm transition-all shadow-md flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-60"
                >
                  {submitting && <Loader2 className="w-4 h-4 animate-spin" />}
                  Excluir UC
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ================= MODAL DE RESUMO (ESTUDANTES MATRICULADOS) ================= */}
        {showSummaryModal && (
          <div 
            className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-in fade-in duration-200"
            onClick={() => {
              setShowSummaryModal(false);
              setSelectedUnit(null);
            }}
          >
            <div 
              className="bg-white rounded-3xl border border-[#E2E8F0] p-6 md:p-8 w-full max-w-md shadow-2xl relative animate-in zoom-in-95 duration-200 flex flex-col max-h-[85vh]"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Cabeçalho */}
              <div className="border-b border-[#F1F5F9] pb-4 mb-4">
                <h3 className="text-lg font-bold text-text-primary flex items-center gap-2">
                  <BookOpen className="w-5.5 h-5.5 text-primary" />
                  Estudantes Matriculados
                </h3>
                <p className="text-xs text-text-secondary mt-1">
                  Disciplina: <span className="font-semibold text-text-primary">{selectedUnit?.name}</span> ({selectedUnit?.code})
                </p>
              </div>

              {/* Corpo (Carregamento / Erro / Listagem) */}
              <div className="flex-1 overflow-y-auto pr-1 py-1">
                {loadingSummary ? (
                  <div className="py-12 flex flex-col items-center justify-center gap-2">
                    <Loader2 className="w-6 h-6 text-primary animate-spin" />
                    <span className="text-xs text-text-secondary font-medium">Buscando estudantes...</span>
                  </div>
                ) : summaryError ? (
                  <div className="bg-red-50 border border-red-200 text-red-700 rounded-xl p-4 flex items-start gap-2.5 text-xs">
                    <AlertCircle className="w-4 h-4 shrink-0 text-red-500 mt-0.5" />
                    <span>{summaryError}</span>
                  </div>
                ) : summaryStudents.length === 0 ? (
                  <div className="border-2 border-dashed border-[#E2E8F0] rounded-2xl p-8 text-center flex flex-col items-center justify-center gap-2 bg-[#F8FAFC]/50">
                    <span className="text-sm font-bold text-text-primary">Nenhum estudante matriculado</span>
                    <span className="text-xs text-text-secondary">
                      Use a tela de cadastro para associar estudantes a esta disciplina.
                    </span>
                  </div>
                ) : (
                  <div className="flex flex-col gap-2.5">
                    {summaryStudents.map((student) => {
                      const initials = student.name
                        .split(" ")
                        .filter((n: string) => n.length > 0)
                        .slice(0, 2)
                        .map((n: string) => n[0].toUpperCase())
                        .join("");

                      return (
                        <div 
                          key={student.id} 
                          className="flex items-center gap-3 p-3 rounded-2xl border border-[#F1F5F9] bg-[#F8FAFC]/30 hover:bg-[#F8FAFC]/80 transition-all"
                        >
                          <div className="w-9 h-9 rounded-full bg-gradient-to-br from-indigo-500 to-blue-600 flex items-center justify-center text-white text-xs font-bold shadow-sm shrink-0">
                            {initials}
                          </div>
                          
                          <div className="flex-1 min-w-0">
                            <h4 className="text-xs font-semibold text-text-primary truncate" title={student.name}>
                              {student.name}
                            </h4>
                            <p className="text-[10px] text-text-secondary mt-0.5 font-mono">
                              Matrícula: {student.matricula}
                            </p>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Rodapé / Fechar */}
              <div className="border-t border-[#F1F5F9] pt-4 mt-4">
                <button
                  onClick={() => {
                    setShowSummaryModal(false);
                    setSelectedUnit(null);
                  }}
                  className="w-full bg-[#F1F5F9] hover:bg-[#E2E8F0] border border-[#CBD5E1] text-text-primary font-semibold py-2 px-4 rounded-xl text-xs transition-all cursor-pointer"
                >
                  Fechar Painel
                </button>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
