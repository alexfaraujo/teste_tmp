"use client";

import { useState, useEffect, useRef } from "react";
import { useRouter } from "next/navigation";
import { 
  Camera, 
  Play, 
  ArrowLeft, 
  CheckCircle2, 
  XCircle, 
  AlertCircle, 
  Clock, 
  Lock, 
  Volume2, 
  BookOpen,
  LogOut,
  RefreshCw,
  Sun,
  ShieldAlert
} from "lucide-react";
import { onAuthStateChanged, User as FirebaseUser } from "firebase/auth";
import { auth } from "@/lib/firebase";

interface CourseUnit {
  id: number;
  name: string;
  code: string;
}

interface PresenceInfo {
  id: number;
  name: string;
  matricula: string;
  time: string;
  uc: string;
}

export default function TotemKioskPage() {
  const router = useRouter();

  // Estados de Sessão do Firebase
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [checkingAuth, setCheckingAuth] = useState(true);

  // Estados da Tela Inicial (Configuração)
  const [allUCs, setAllUCs] = useState<CourseUnit[]>([]);
  const [selectedUC, setSelectedUC] = useState<CourseUnit | null>(null);
  const [pin, setPin] = useState("1234");
  const [loadingUCs, setLoadingUCs] = useState(true);
  const [setupError, setSetupError] = useState<string | null>(null);

  // Estados do Totem Quiosque Ativo
  const [totemActive, setTotemActive] = useState(false);
  const [scanStatus, setScanStatus] = useState<"idle" | "processing" | "success" | "error">("idle");
  const [currentStep, setCurrentStep] = useState<number>(0); // 0: aguardando, 1: detectando, 2: extraindo, 3: comparando
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [lastSuccessStudent, setLastSuccessStudent] = useState<{ name: string; matricula: string; time: string } | null>(null);
  const [recentPresences, setRecentPresences] = useState<PresenceInfo[]>([]);

  // Estados da Webcam e Ring Light
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [cameraActive, setCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [ringLightActive, setRingLightActive] = useState(false);

  // Modais e Proteção por PIN
  const [showPinModal, setShowPinModal] = useState(false);
  const [enteredPin, setEnteredPin] = useState("");
  const [pinError, setPinError] = useState<string | null>(null);

  // Relógio e Data do Cabeçalho
  const [currentTime, setCurrentTime] = useState("");
  const [currentDate, setCurrentDate] = useState("");

  // Helper para obter URL da API do Backend local ou Wi-Fi
  const getApiUrl = () => {
    const envUrl = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
    if (envUrl && !envUrl.includes("localhost") && !envUrl.includes("127.0.0.1")) {
      return envUrl;
    }
    if (typeof window !== "undefined") {
      const hostname = window.location.hostname;
      if (hostname !== "localhost" && hostname !== "127.0.0.1" && /^[0-9.]+$/.test(hostname)) {
        return `http://${hostname}:8000`;
      }
    }
    return envUrl;
  };

  const getApiKey = () => {
    return process.env.NEXT_PUBLIC_API_KEY ?? "";
  };

  // 1. Monitorar estado de autenticação do Firebase
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      if (user) {
        setFirebaseUser(user);
        fetchUCs(user.email || "");
      } else {
        router.push("/");
      }
      setCheckingAuth(false);
    });
    return () => unsubscribe();
  }, []);

  // 2. Relógio em tempo real do Totem
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(now.toLocaleTimeString("pt-BR"));
      setCurrentDate(
        now.toLocaleDateString("pt-BR", {
          weekday: "long",
          day: "numeric",
          month: "long",
          year: "numeric",
        })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  // 3. Buscar UCs cadastradas do backend
  const fetchUCs = async (emailOverride?: string) => {
    const API_URL = getApiUrl();
    const apiKey = getApiKey();
    const userEmail = emailOverride || firebaseUser?.email || "";
    try {
      setLoadingUCs(true);
      setSetupError(null);
      const res = await fetch(`${API_URL}/api/course_units`, {
        headers: {
          "x-api-key": apiKey,
          "X-User-Email": userEmail,
        }
      });
      if (res.ok) {
        const data = await res.json();
        setAllUCs(data);
        if (data.length > 0) {
          setSelectedUC(data[0]);
        }
      } else {
        setSetupError("Falha ao obter as disciplinas (UCs) do servidor.");
      }
    } catch (err) {
      setSetupError("Erro de conexão ao carregar UCs.");
    } finally {
      setLoadingUCs(false);
    }
  };

  const streamRef = useRef<MediaStream | null>(null);

  // Efeito para vincular a stream ao elemento video quando montado no DOM
  useEffect(() => {
    if (videoRef.current && stream) {
      videoRef.current.srcObject = stream;
    }
  }, [stream, cameraActive]);

  // 4. Iniciar Stream de Vídeo da Câmera
  const startCamera = async () => {
    setCameraError(null);
    try {
      const constraints = {
        video: {
          facingMode: "user",
          width: { ideal: 640 },
          height: { ideal: 480 }
        },
        audio: false
      };
      const mediaStream = await navigator.mediaDevices.getUserMedia(constraints);
      streamRef.current = mediaStream;
      setStream(mediaStream);
      setCameraActive(true);
    } catch (err) {
      console.error("Erro ao iniciar webcam:", err);
      setCameraError("Webcam não detectada ou permissão negada. O simulador continuará disponível.");
    }
  };

  // 5. Parar Stream de Vídeo da Câmera
  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    setStream(null);
    setCameraActive(false);
  };

  // 6. Monitorar ativação do Totem para abrir a câmera
  useEffect(() => {
    if (totemActive) {
      startCamera();
    } else {
      stopCamera();
    }
    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop());
        streamRef.current = null;
      }
    };
  }, [totemActive]);

  // 7. Loop do Escaneamento Contínuo (Auto-capture a cada 2 segundos)
  useEffect(() => {
    if (!totemActive || scanStatus !== "idle" || !cameraActive || showPinModal) return;

    const interval = setInterval(() => {
      captureAndVerify();
    }, 2000);

    return () => clearInterval(interval);
  }, [totemActive, scanStatus, cameraActive, showPinModal]);

  // 8. Capturar imagem do frame e verificar presença
  const captureAndVerify = async () => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas || !selectedUC) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Configurar canvas para extrair foto pura
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;

    // Desenhar a câmera crua sem qualquer overlay ou espelhamento para o backend processar perfeitamente
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

    canvas.toBlob(
      async (blob) => {
        if (!blob) return;
        await sendAttendanceRequest(blob);
      },
      "image/jpeg",
      0.95
    );
  };

  // 9. Chamada para a API `POST /api/attendance`
  const sendAttendanceRequest = async (blob: Blob) => {
    if (!selectedUC) return;
    const API_URL = getApiUrl();
    const apiKey = getApiKey();
    const userEmail = firebaseUser?.email || "";

    setScanStatus("processing");
    setCurrentStep(1); // 1. Localizando face...

    const formData = new FormData();
    formData.append("course_unit_id", selectedUC.id.toString());
    formData.append("photo", blob, "photo.jpg");

    try {
      // Pequeno delay visual para mostrar as etapas do scanner simuladas
      await new Promise((resolve) => setTimeout(resolve, 500));
      setCurrentStep(2); // 2. Extraindo biometria...

      await new Promise((resolve) => setTimeout(resolve, 500));
      setCurrentStep(3); // 3. Validando identidade...

      const response = await fetch(`${API_URL}/api/attendance`, {
        method: "POST",
        headers: {
          "x-api-key": apiKey,
          "X-User-Email": userEmail,
        },
        body: formData,
      });

      if (response.ok) {
        const data = await response.json();
        handleSuccess(data);
      } else {
        const errData = await response.json().catch(() => ({ detail: "Erro desconhecido" }));
        const errorDetail = typeof errData.detail === "string" ? errData.detail : "Erro na validação facial";
        handleFailure(errorDetail);
      }
    } catch (err) {
      handleFailure("Falha de conexão com o servidor.");
    }
  };

  // 10. Manipular sucesso de presença
  const handleSuccess = (data: any) => {
    setScanStatus("success");
    const timeNow = new Date().toLocaleTimeString("pt-BR");
    
    const newSuccess = {
      name: data.student.name,
      matricula: data.student.matricula,
      time: timeNow
    };
    
    setLastSuccessStudent(newSuccess);

    // Adiciona na lista de confirmações recentes
    const newPresence: PresenceInfo = {
      id: Date.now(),
      name: data.student.name,
      matricula: data.student.matricula,
      time: timeNow,
      uc: selectedUC?.name || ""
    };
    setRecentPresences((prev) => [newPresence, ...prev.slice(0, 4)]);

    // Sintetizar voz (TTS)
    if ("speechSynthesis" in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance("Presença confirmada.");
      utterance.lang = "pt-BR";
      window.speechSynthesis.speak(utterance);
    }

    // Aguardar 4 segundos e resetar para continuar escaneando
    setTimeout(() => {
      setScanStatus("idle");
      setCurrentStep(0);
      setLastSuccessStudent(null);
    }, 4000);
  };

  // 11. Manipular falha de presença
  const handleFailure = (detail: string) => {
    // Se não detectou rosto, volta a escanear silenciosamente sem travar a tela em vermelho
    if (detail.includes("Nenhuma face detectada") || detail.includes("Nenhum rosto detectado")) {
      setScanStatus("idle");
      setCurrentStep(0);
      return;
    }

    // Outros erros (Liveness, duplicidade, não matriculado) mostram o card vermelho
    setScanStatus("error");
    setErrorMessage(detail);

    // Sintetizar áudio de falha (opcional, apenas leitor de texto de aviso)
    if ("speechSynthesis" in window) {
      window.speechSynthesis.cancel();
      let spokenMessage = "Falha na leitura.";
      if (detail.includes("não possui matrícula")) {
        spokenMessage = "Estudante sem matrícula.";
      } else if (detail.includes("fraude") || detail.includes("vivacidade")) {
        spokenMessage = "Vivacidade inválida.";
      } else if (detail.includes("já registrada")) {
        spokenMessage = "Presença já registrada.";
      } else if (detail.includes("não reconhecida") || detail.includes("Não reconhecido")) {
        spokenMessage = "Pessoa não reconhecida.";
      }

      const utterance = new SpeechSynthesisUtterance(spokenMessage);
      utterance.lang = "pt-BR";
      window.speechSynthesis.speak(utterance);
    }

    // Aguardar 4 segundos e resetar
    setTimeout(() => {
      setScanStatus("idle");
      setCurrentStep(0);
      setErrorMessage(null);
    }, 4000);
  };



  // 13. Fluxo de Saída Segura (Inserção de PIN)
  const handleExitKiosk = () => {
    if (enteredPin === pin) {
      stopCamera();
      setTotemActive(false);
      setShowPinModal(false);
      setEnteredPin("");
      setPinError(null);
      setRecentPresences([]);
      router.push("/dashboard");
    } else {
      setPinError("PIN incorreto. Acesso negado.");
    }
  };

  if (checkingAuth) {
    return (
      <div className="min-h-screen bg-[#F8FAFC] flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <RefreshCw className="w-8 h-8 text-primary animate-spin" />
          <span className="text-sm font-semibold text-text-secondary">Autenticando sessão...</span>
        </div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen font-sans flex flex-col transition-colors duration-500 ${
      ringLightActive ? "bg-white" : "bg-[#F8FAFC]"
    }`}>
      {/* Estilos Auxiliares para Animações Geométricas e Efeito de Scanner */}
      <style>{`
        @keyframes scan {
          0% { top: 0%; }
          100% { top: 100%; }
        }
        .animate-scan {
          animation: scan 2s infinite alternate linear;
        }
        .geometric-bg {
          background-image: radial-gradient(circle at 10% 20%, rgba(226, 232, 240, 0.4) 0%, transparent 60%),
                            radial-gradient(circle at 90% 80%, rgba(226, 232, 240, 0.4) 0%, transparent 60%);
        }
      `}</style>

      {/* TELA DE CONFIGURAÇÃO DO TOTEM */}
      {!totemActive && (
        <div className="flex-1 flex items-center justify-center px-4 py-12 geometric-bg">
          <div className="bg-white border border-[#E2E8F0] shadow-xl rounded-3xl p-8 max-w-md w-full animate-in fade-in zoom-in duration-300">
            
            {/* Cabeçalho de Setup */}
            <div className="flex flex-col items-center mb-8">
              <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mb-4">
                <BookOpen className="w-8 h-8 text-primary" />
              </div>
              <h1 className="text-2xl font-extrabold text-text-primary tracking-tight">
                Iniciar Totem Quiosque
              </h1>
              <p className="text-sm text-text-secondary text-center mt-2">
                Configure a disciplina e defina um PIN para gerenciar a chamada na entrada da sala.
              </p>
            </div>

            {setupError && (
              <div className="bg-red-50 border border-red-200 text-red-700 rounded-xl p-4 flex items-start gap-2.5 text-sm mb-6">
                <AlertCircle className="w-5 h-5 shrink-0 text-red-500 mt-0.5" />
                <span>{setupError}</span>
              </div>
            )}

            {/* Formulário de Configuração */}
            <div className="flex flex-col gap-5">
              
              {/* Dropdown de UCs */}
              <div className="flex flex-col gap-1.5">
                <label className="text-sm font-bold text-text-primary flex items-center gap-1.5">
                  <BookOpen className="w-4 h-4 text-text-secondary" />
                  Selecione a Disciplina (UC)
                </label>
                {loadingUCs ? (
                  <div className="h-12 border border-[#CBD5E1] rounded-xl flex items-center justify-center bg-gray-50 text-xs text-text-secondary">
                    <RefreshCw className="w-4 h-4 animate-spin mr-2" />
                    Buscando disciplinas no banco...
                  </div>
                ) : allUCs.length === 0 ? (
                  <div className="p-3 border border-dashed border-red-300 bg-red-50 rounded-xl text-xs text-red-700 text-center">
                    Nenhuma UC cadastrada. Por favor, cadastre primeiro na tela de UCs.
                  </div>
                ) : (
                  <select
                    value={selectedUC ? selectedUC.id : ""}
                    onChange={(e) => {
                      const found = allUCs.find(u => u.id === parseInt(e.target.value));
                      if (found) setSelectedUC(found);
                    }}
                    className="w-full h-12 border border-[#CBD5E1] rounded-xl px-4 text-sm transition-all focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 bg-white text-text-primary font-medium"
                  >
                    {allUCs.map((uc) => (
                      <option key={uc.id} value={uc.id}>
                        {uc.name} ({uc.code})
                      </option>
                    ))}
                  </select>
                )}
              </div>

              {/* PIN de 4 dígitos */}
              <div className="flex flex-col gap-1.5">
                <label className="text-sm font-bold text-text-primary flex items-center gap-1.5">
                  <Lock className="w-4 h-4 text-text-secondary" />
                  Defina um PIN de Saída (4 dígitos)
                </label>
                <input
                  type="text"
                  maxLength={4}
                  value={pin}
                  onChange={(e) => {
                    const val = e.target.value.replace(/\D/g, ""); // Apenas números
                    setPin(val);
                  }}
                  placeholder="Ex: 1234"
                  className="w-full border border-[#CBD5E1] rounded-xl p-3 text-sm transition-all focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 bg-white text-text-primary font-bold tracking-widest text-center"
                />
              </div>

              {/* Ações */}
              <div className="flex items-center gap-3 mt-4">
                <button
                  type="button"
                  onClick={() => router.push("/dashboard")}
                  className="flex-1 border border-[#CBD5E1] hover:bg-[#F8FAFC] text-text-primary font-bold py-3 rounded-xl text-sm flex items-center justify-center gap-2 transition-all shadow-sm"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Voltar</span>
                </button>
                <button
                  type="button"
                  disabled={!selectedUC || pin.length !== 4}
                  onClick={() => setTotemActive(true)}
                  className="flex-1 bg-gradient-to-r from-primary to-blue-600 hover:opacity-95 disabled:opacity-50 text-white font-bold py-3 rounded-xl text-sm flex items-center justify-center gap-2 transition-all shadow-md"
                >
                  <Play className="w-4 h-4 fill-current" />
                  <span>Iniciar Totem</span>
                </button>
              </div>

            </div>

          </div>
        </div>
      )}

      {/* TELA DO TOTEM QUIOSQUE ATIVO */}
      {totemActive && (
        <div className="flex-1 flex flex-col geometric-bg">
          
          {/* Cabeçalho do Totem */}
          <header className={`border-b px-6 py-4 flex items-center justify-between transition-colors duration-500 ${
            ringLightActive ? "border-gray-200 bg-white" : "border-[#E2E8F0] bg-white/80 backdrop-blur-md"
          }`}>
            <div className="flex items-center gap-3">
              <div className="relative w-8 h-8 rounded-full overflow-hidden bg-primary flex items-center justify-center text-white font-bold text-sm">
                CF
              </div>
              <div className="flex flex-col">
                <span className="text-sm font-extrabold text-text-primary tracking-tight">
                  Totem de Frequência
                </span>
                <span className="text-[10px] text-text-secondary font-medium">
                  Chamada Inteligente
                </span>
              </div>
            </div>

            {/* Badge da Disciplina */}
            {selectedUC && (
              <div className="hidden sm:flex items-center gap-2 bg-primary/10 border border-primary/20 text-primary px-3 py-1.5 rounded-full text-xs font-bold shadow-sm animate-in fade-in duration-200">
                <BookOpen className="w-3.5 h-3.5" />
                <span>UC: {selectedUC.name} ({selectedUC.code})</span>
              </div>
            )}

            {/* Relógio e Ações */}
            <div className="flex items-center gap-5">
              <div className="flex flex-col items-end">
                <span className="text-sm font-black text-text-primary tracking-tighter" id="totem-clock">
                  {currentTime}
                </span>
                <span className="text-[9px] text-text-secondary uppercase font-semibold">
                  {currentDate}
                </span>
              </div>

              <button
                type="button"
                onClick={() => setShowPinModal(true)}
                className="bg-red-50 border border-red-200 text-red-600 hover:bg-red-100 font-bold p-2 sm:px-3 sm:py-2 rounded-xl text-xs flex items-center gap-1.5 transition-all shadow-sm"
              >
                <LogOut className="w-4 h-4" />
                <span className="hidden sm:inline">Sair do Totem</span>
              </button>
            </div>
          </header>

          {/* Área de Visualização e Logs */}
          <main className="flex-1 grid grid-cols-1 md:grid-cols-12 gap-6 max-w-6xl w-full mx-auto p-4 sm:p-6 items-center">
            
            {/* Lado Esquerdo - Câmera do Totem (Col 6) */}
            <div className="md:col-span-6 flex flex-col items-center gap-4">
              
              {/* Box Câmera com Ring Light */}
              <div className={`relative w-full max-w-[400px] aspect-[4/3] bg-[#0F172A] rounded-3xl overflow-hidden flex items-center justify-center transition-all duration-500 border-8 ${
                ringLightActive 
                  ? "border-white shadow-[0_0_45px_rgba(255,255,255,1)]" 
                  : "border-[#E2E8F0] shadow-2xl"
              }`}>
                
                {/* Linha Geométrica de Varredura Laser */}
                {cameraActive && scanStatus === "idle" && (
                  <div className="absolute left-0 right-0 h-1 bg-gradient-to-r from-transparent via-primary to-transparent pointer-events-none z-30 animate-scan" />
                )}

                {/* Elipse Guia do Rosto */}
                {cameraActive && scanStatus === "idle" && (
                  <div className="absolute w-[180px] h-[240px] border-2 border-dashed border-white/60 rounded-[50%] pointer-events-none z-30 animate-pulse" />
                )}

                {/* Máscara de Foco / Ring Light (Capa inteira externa à elipse) */}
                {cameraActive && scanStatus === "idle" && (
                  <div 
                    className="absolute inset-0 z-20 pointer-events-none transition-all duration-300"
                    style={{
                      background: ringLightActive
                        ? "radial-gradient(ellipse 90px 120px at center, transparent 99%, rgba(255, 255, 255, 1) 100%)"
                        : "radial-gradient(ellipse 90px 120px at center, transparent 99%, rgba(15, 23, 42, 0.6) 100%)",
                    }}
                  />
                )}

                {/* Feed de Vídeo Nativo */}
                {cameraActive && (
                  <video
                    ref={videoRef}
                    autoPlay
                    playsInline
                    className="w-full h-full object-cover -scale-x-100 z-10"
                  />
                )}

                {/* Feedbacks de Resultados Visuais por cima da Câmera (Cards de Status) */}
                {scanStatus === "success" && lastSuccessStudent && (
                  <div className="absolute inset-0 bg-green-700/90 z-40 flex flex-col items-center justify-center text-white p-6 animate-in fade-in zoom-in duration-300">
                    <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center shadow-lg mb-4 text-green-600">
                      <CheckCircle2 className="w-12 h-12" />
                    </div>
                    <span className="text-sm font-extrabold uppercase bg-white/20 px-3 py-1 rounded-full tracking-wider mb-2">
                      Acesso Liberado!
                    </span>
                    <h2 className="text-2xl font-black tracking-tight text-center">
                      {lastSuccessStudent.name}
                    </h2>
                    <p className="text-xs text-white/80 mt-1">
                      Matrícula: {lastSuccessStudent.matricula}
                    </p>
                    <p className="text-[10px] text-white/60 mt-2 font-mono">
                      Frequência registrada às {lastSuccessStudent.time}
                    </p>
                  </div>
                )}

                {scanStatus === "error" && errorMessage && (
                  <div className="absolute inset-0 bg-red-700/95 z-40 flex flex-col items-center justify-center text-white p-6 animate-in fade-in zoom-in duration-300">
                    <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center shadow-lg mb-4 text-red-600">
                      <XCircle className="w-12 h-12" />
                    </div>
                    <span className="text-sm font-extrabold uppercase bg-white/20 px-3 py-1 rounded-full tracking-wider mb-2">
                      Não Reconhecido!
                    </span>
                    <p className="text-base font-bold text-center leading-snug max-w-xs">
                      {errorMessage}
                    </p>
                    <p className="text-xs text-white/70 mt-4 text-center font-medium">
                      Por favor, olhe para o visor ou chame o professor.
                    </p>
                  </div>
                )}

                {/* Exibição em caso de falha de inicialização de câmera */}
                {!cameraActive && !cameraError && (
                  <div className="flex flex-col items-center text-white/50 gap-2.5 z-10 p-6 text-center">
                    <Camera className="w-10 h-10 animate-pulse text-primary" />
                    <span className="text-sm font-semibold">Inicializando webcam...</span>
                    <span className="text-xs opacity-75">Certifique-se de conceder acesso</span>
                  </div>
                )}

                {cameraError && (
                  <div className="flex flex-col items-center text-white/70 gap-2.5 z-10 p-6 text-center max-w-xs">
                    <ShieldAlert className="w-10 h-10 text-yellow-500" />
                    <span className="text-sm font-bold text-yellow-500">Aviso de Câmera</span>
                    <span className="text-xs text-white/60 leading-relaxed">{cameraError}</span>
                  </div>
                )}
              </div>

              {/* Botão Ring Light e Canvas Invisível */}
              <canvas ref={canvasRef} className="hidden" />
              
              <button
                type="button"
                onClick={() => setRingLightActive(!ringLightActive)}
                className={`py-2.5 px-5 rounded-2xl text-xs font-bold flex items-center gap-2 transition-all shadow-md ${
                  ringLightActive
                    ? "bg-amber-500 hover:bg-amber-600 text-white"
                    : "bg-white hover:bg-gray-50 border border-[#CBD5E1] text-text-primary"
                }`}
              >
                <Sun className="w-4 h-4 fill-current" />
                <span>{ringLightActive ? "Desativar Iluminação" : "Ativar Ring Light"}</span>
              </button>

            </div>

            {/* Lado Direito - Status Panel / Log de Presenças (Col 6) */}
            <div className="md:col-span-6 flex flex-col gap-5 self-stretch justify-center">
              
              {/* Painel de Processamento do Scanner */}
              <div className="bg-white border border-[#E2E8F0] shadow-xl rounded-3xl p-6">
                
                {/* Idle / Passos */}
                {scanStatus !== "success" && scanStatus !== "error" && (
                  <div className="flex flex-col gap-4">
                    <h3 className="text-base font-extrabold text-text-primary tracking-tight border-b border-[#F1F5F9] pb-2 flex items-center gap-2">
                      <Volume2 className="w-5 h-5 text-primary" />
                      Status do Reconhecimento
                    </h3>
                    
                    <div className="flex flex-col gap-3">
                      <div className={`flex items-center gap-3 p-3 rounded-xl border transition-all ${
                        scanStatus === "processing" && currentStep === 1 
                          ? "bg-primary/5 border-primary/20 text-primary font-bold" 
                          : "bg-gray-50/50 border-gray-100 text-text-secondary"
                      }`}>
                        <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-black ${
                          scanStatus === "processing" && currentStep >= 1 ? "bg-primary text-white" : "bg-gray-200 text-text-secondary"
                        }`}>
                          1
                        </div>
                        <span className="text-xs">Localizando face na imagem...</span>
                      </div>

                      <div className={`flex items-center gap-3 p-3 rounded-xl border transition-all ${
                        scanStatus === "processing" && currentStep === 2 
                          ? "bg-primary/5 border-primary/20 text-primary font-bold" 
                          : "bg-gray-50/50 border-gray-100 text-text-secondary"
                      }`}>
                        <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-black ${
                          scanStatus === "processing" && currentStep >= 2 ? "bg-primary text-white" : "bg-gray-200 text-text-secondary"
                        }`}>
                          2
                        </div>
                        <span className="text-xs">Extraindo biometria facial...</span>
                      </div>

                      <div className={`flex items-center gap-3 p-3 rounded-xl border transition-all ${
                        scanStatus === "processing" && currentStep === 3 
                          ? "bg-primary/5 border-primary/20 text-primary font-bold" 
                          : "bg-gray-50/50 border-gray-100 text-text-secondary"
                      }`}>
                        <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-black ${
                          scanStatus === "processing" && currentStep >= 3 ? "bg-primary text-white" : "bg-gray-200 text-text-secondary"
                        }`}>
                          3
                        </div>
                        <span className="text-xs">Validando identidade e matrícula...</span>
                      </div>
                    </div>
                  </div>
                )}

                {/* Cartão de Sucesso Explicativo Lateral */}
                {scanStatus === "success" && lastSuccessStudent && (
                  <div className="flex flex-col items-center text-center py-4 animate-in fade-in duration-300">
                    <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center text-green-600 mb-2">
                      <CheckCircle2 className="w-6 h-6" />
                    </div>
                    <h4 className="text-lg font-black text-green-700 leading-tight">Presença Registrada!</h4>
                    <p className="text-xs text-text-secondary mt-2 max-w-xs">
                      O rosto de <strong>{lastSuccessStudent.name}</strong> foi reconhecido. A chamada foi atualizada no diário eletrônico.
                    </p>
                  </div>
                )}

                {/* Cartão de Erro Explicativo Lateral */}
                {scanStatus === "error" && errorMessage && (
                  <div className="flex flex-col items-center text-center py-4 animate-in fade-in duration-300">
                    <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center text-red-600 mb-2">
                      <XCircle className="w-6 h-6" />
                    </div>
                    <h4 className="text-lg font-black text-red-700 leading-tight">Falha na Leitura</h4>
                    <p className="text-xs text-text-secondary mt-2 max-w-xs">
                      {errorMessage}
                    </p>
                  </div>
                )}

              </div>

              {/* Registro Recente de Presenças na Sessão */}
              <div className="bg-white border border-[#E2E8F0] shadow-xl rounded-3xl p-6 flex flex-col gap-3">
                <h4 className="text-xs font-bold text-text-secondary uppercase tracking-wider">
                  Últimos Confirmados nesta aula
                </h4>
                
                {recentPresences.length === 0 ? (
                  <div className="py-6 text-center text-xs text-text-secondary border border-dashed border-[#E2E8F0] rounded-2xl bg-gray-50/30">
                    Nenhuma presença confirmada nesta sessão ainda.
                  </div>
                ) : (
                  <div className="flex flex-col gap-2.5">
                    {recentPresences.map((pres) => (
                      <div key={pres.id} className="flex items-center justify-between p-2.5 rounded-xl border border-gray-50 bg-[#F8FAFC]/50 text-xs">
                        <div className="flex items-center gap-2">
                          <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
                          <span className="font-semibold text-text-primary">{pres.name}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] text-text-secondary font-mono bg-white border border-[#E2E8F0] px-1.5 py-0.5 rounded">
                            {pres.matricula}
                          </span>
                          <span className="text-[10px] text-text-secondary font-semibold">
                            {pres.time}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>



            </div>

          </main>

          {/* Rodapé do Quiosque */}
          <footer className={`text-center py-4 border-t text-xs text-text-secondary transition-colors duration-500 ${
            ringLightActive ? "border-gray-200 bg-white" : "border-[#E2E8F0] bg-white/80"
          }`}>
            <p>
              Desenvolvido por <span className="text-primary font-bold">Magic IT Lab</span> | Totem de Chamada Inteligente © 2026
            </p>
          </footer>

        </div>
      )}

      {/* MODAL DE ENTRADA DO PIN PARA SAÍDA */}
      {showPinModal && (
        <div className="fixed inset-0 bg-[#0F172A]/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white border border-[#E2E8F0] shadow-2xl rounded-3xl p-6 max-w-sm w-full animate-in fade-in zoom-in duration-200">
            
            <div className="flex flex-col items-center mb-6">
              <div className="w-12 h-12 bg-red-50 rounded-full flex items-center justify-center text-red-600 mb-3">
                <Lock className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-extrabold text-text-primary tracking-tight">
                Sair do Modo Quiosque
              </h3>
              <p className="text-xs text-text-secondary text-center mt-1">
                Insira o PIN de 4 dígitos configurado pelo professor para voltar ao painel.
              </p>
            </div>

            {pinError && (
              <div className="bg-red-50 border border-red-200 text-red-700 rounded-xl p-3 text-xs text-center mb-4">
                {pinError}
              </div>
            )}

            <div className="flex flex-col gap-4">
              <input
                type="password"
                maxLength={4}
                value={enteredPin}
                onChange={(e) => {
                  const val = e.target.value.replace(/\D/g, "");
                  setEnteredPin(val);
                }}
                placeholder="••••"
                className="w-full border border-[#CBD5E1] rounded-xl p-3 text-lg font-bold tracking-widest text-center focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 bg-white text-text-primary"
              />

              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setShowPinModal(false);
                    setEnteredPin("");
                    setPinError(null);
                  }}
                  className="flex-1 border border-[#CBD5E1] hover:bg-[#F8FAFC] text-text-primary font-bold py-2.5 rounded-xl text-xs transition-all"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  onClick={handleExitKiosk}
                  className="flex-1 bg-red-600 hover:bg-red-700 text-white font-bold py-2.5 rounded-xl text-xs transition-all"
                >
                  Confirmar PIN
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
