import os
from pathlib import Path
from typing import List
from pydantic_settings import BaseSettings, SettingsConfigDict

_REPO_ROOT = Path(__file__).resolve().parents[4]
_DEFAULT_UPLOAD_DIR = str(_REPO_ROOT / "storage" / "uploads")


class Settings(BaseSettings):
    """Configurações centrais da aplicação carregadas do arquivo .env."""

    # Aplicação
    PROJECT_NAME: str = "EasyEvent API"
    VERSION: str = "1.0.0"
    ENVIRONMENT: str = "development"
    DEBUG: bool = True
    HOST: str = "127.0.0.1"
    PORT: int = 8000

    # CORS
    CORS_ORIGINS: List[str] = [
        "http://localhost:3000",
        "http://localhost:3001",
        "http://localhost:3002",
        "http://localhost:3003",
        "http://127.0.0.1:3000",
        "http://127.0.0.1:3001",
        "http://127.0.0.1:3002",
        "http://127.0.0.1:3003",
    ]

    # Banco de Dados PostgreSQL (asyncpg nativo)
    DATABASE_URL: str = "postgresql+asyncpg://fecitel_user:fecitel_secret_2026@127.0.0.1:5432/fecitel_db"

    # Segurança e Criptografia
    JWT_SECRET_KEY: str = "sua_chave_secreta_super_segura_de_no_minimo_32_caracteres_fecitel"
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_HOURS: int = 12
    API_KEY: str = "fecitel_secret_api_key_2026"
    API_KEY_NAME: str = "X-API-Key"

    # Servidor SMTP de Notificações por E-mail
    SMTP_HOST: str = "localhost"
    SMTP_PORT: int = 25
    SMTP_USER: str = "notificacoes@fecitel.ifms.edu.br"
    SMTP_PASSWORD: str = ""
    SMTP_FROM: str = "nao-responda@fecitel.ifms.edu.br"

    @property
    def smtp_host(self) -> str:
        return self.SMTP_HOST

    @property
    def smtp_port(self) -> int:
        return self.SMTP_PORT

    @property
    def email_address(self) -> str:
        return self.SMTP_FROM

    # Uploads e Arquivos
    UPLOAD_DIR: str = _DEFAULT_UPLOAD_DIR
    MAX_FILE_SIZE_MB: int = 20

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore"
    )


settings = Settings()
