#!/usr/bin/env python3
"""
EasyEvent - Utilitário Interativo de Limpeza e Reset do Banco de Dados (Ambiente de Testes)
Permite ao desenvolvedor/administrador escolher granularmente quais dados deseja excluir
(Projetos, Participantes, Avaliações/Notas, Áreas, Critérios ou Reset Completo).
"""

import os
import sys

# Auto-detecção de ambiente virtual: se executado com python do sistema, invoca o venv do backend
script_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.abspath(os.path.join(script_dir, ".."))
backend_dir = os.path.join(project_root, "apps", "backend")
venv_python = os.path.join(backend_dir, ".venv", "bin", "python")

if sys.prefix == sys.base_prefix and os.path.exists(venv_python) and sys.executable != venv_python:
    os.execv(venv_python, [venv_python] + sys.argv)

sys.path.insert(0, backend_dir)

import asyncio
from datetime import datetime
from typing import Dict, List, Optional, Tuple
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from app.core.config import settings
from app.core.security import get_password_hash

# Cores ANSI para o terminal
C_RESET = "\033[0m"
C_BOLD = "\033[1m"
C_RED = "\033[91m"
C_GREEN = "\033[92m"
C_YELLOW = "\033[93m"
C_BLUE = "\033[94m"
C_CYAN = "\033[96m"
C_GRAY = "\033[90m"


def print_banner():
    print(f"\n{C_CYAN}{C_BOLD}{'=' * 72}")
    print("   EASYEVENT — UTILITÁRIO DE LIMPEZA E RESET DO BANCO DE DADOS")
    print("   Ambiente Local de Testes e Homologação")
    print(f"{'=' * 72}{C_RESET}")
    print(f"{C_GRAY}Banco Conectado: {settings.DATABASE_URL.split('@')[-1]}{C_RESET}\n")


async def get_engine():
    # Cria engine sem echo de SQL para manter o terminal limpo
    return create_async_engine(settings.DATABASE_URL, echo=False, future=True)


async def get_recent_events(session: AsyncSession) -> List[Tuple[int, str, int]]:
    stmt = text("SELECT id, name, year FROM events WHERE deleted_at IS NULL ORDER BY id DESC LIMIT 15")
    res = await session.execute(stmt)
    return res.fetchall()


async def get_table_counts(session: AsyncSession) -> Dict[str, int]:
    tables = [
        "events", "event_administrators", "schools", "education_levels",
        "knowledge_areas", "subareas", "evaluation_criteria", "awards", "award_criteria",
        "people", "event_participants", "event_participant_roles",
        "person_subareas", "person_education_levels",
        "projects", "project_members", "evaluator_allocations",
        "evaluations", "evaluation_items"
    ]
    counts = {}
    for t in tables:
        try:
            res = await session.execute(text(f'SELECT count(*) FROM "{t}"'))
            counts[t] = res.scalar() or 0
        except Exception:
            counts[t] = 0
    return counts


def print_stats_table(counts: Dict[str, int]):
    print(f"\n{C_BOLD}📊 Contagem Atual de Registros no Banco de Dados:{C_RESET}")
    print(f"{C_GRAY}{'─' * 55}{C_RESET}")
    groups = [
        ("Eventos & Estrutura", ["events", "event_administrators", "schools", "education_levels"]),
        ("Áreas & Critérios", ["knowledge_areas", "subareas", "evaluation_criteria", "awards", "award_criteria"]),
        ("Pessoas & Participantes", ["people", "event_participants", "event_participant_roles", "person_subareas", "person_education_levels"]),
        ("Trabalhos & Avaliações", ["projects", "project_members", "evaluator_allocations", "evaluations", "evaluation_items"]),
    ]
    for group_name, tbls in groups:
        print(f"{C_CYAN}{C_BOLD}[ {group_name} ]{C_RESET}")
        for t in tbls:
            val = counts.get(t, 0)
            color = C_GREEN if val > 0 else C_GRAY
            print(f"  • {t:28}: {color}{val:>6}{C_RESET}")
    print(f"{C_GRAY}{'─' * 55}{C_RESET}\n")


def ask_confirmation(prompt: str) -> bool:
    print(f"\n{C_YELLOW}{C_BOLD}⚠️  {prompt}{C_RESET}")
    ans = input(f"{C_BOLD}Confirma a exclusão dos dados acima? [digite 's' ou 'sim' para confirmar]: {C_RESET}").strip().lower()
    return ans in ("s", "sim", "y", "yes")


async def select_event_scope(session: AsyncSession) -> Optional[int]:
    """Pergunta ao usuário se deseja aplicar a todos os eventos ou a um evento específico."""
    events = await get_recent_events(session)
    print(f"\n{C_BOLD}Defina o Escopo da Operação:{C_RESET}")
    print(f"  {C_CYAN}[0]{C_RESET} Aplicar a {C_BOLD}TODOS os eventos{C_RESET} cadastrados")
    if events:
        print(f"\n  {C_GRAY}Eventos Recentes:{C_RESET}")
        for e in events:
            print(f"  {C_CYAN}[{e[0]}]{C_RESET} {e[1]} ({e[2]})")
    
    choice = input(f"\n{C_BOLD}Digite o ID do evento desejado (ou 0 para Todos): {C_RESET}").strip()
    if not choice or choice == "0":
        return None
    try:
        eid = int(choice)
        return eid
    except ValueError:
        print(f"{C_RED}ID inválido. Aplicando a TODOS os eventos.{C_RESET}")
        return None


# -------------------------------------------------------------
# OPERAÇÕES DE EXCLUSÃO GRANULAR
# -------------------------------------------------------------

async def delete_projects(session: AsyncSession, event_id: Optional[int] = None):
    scope_desc = f"do Evento #{event_id}" if event_id else "de TODOS os eventos"
    print(f"\n{C_BOLD}Preparando exclusão de Trabalhos Científicos / Projetos {scope_desc}...{C_RESET}")

    filter_proj = "WHERE p.event_id = :eid" if event_id else ""
    filter_proj_direct = "WHERE event_id = :eid" if event_id else ""
    params = {"eid": event_id} if event_id else {}

    # Pré-contagem
    c_items = (await session.execute(text(f"""
        SELECT count(*) FROM evaluation_items WHERE evaluation_id IN (
            SELECT e.id FROM evaluations e JOIN projects p ON e.project_id = p.id {filter_proj}
        )
    """), params)).scalar() or 0

    c_evals = (await session.execute(text(f"""
        SELECT count(*) FROM evaluations WHERE project_id IN (
            SELECT id FROM projects {filter_proj_direct}
        )
    """), params)).scalar() or 0

    c_allocs = (await session.execute(text(f"""
        SELECT count(*) FROM evaluator_allocations WHERE project_id IN (
            SELECT id FROM projects {filter_proj_direct}
        )
    """), params)).scalar() or 0

    c_members = (await session.execute(text(f"""
        SELECT count(*) FROM project_members WHERE project_id IN (
            SELECT id FROM projects {filter_proj_direct}
        )
    """), params)).scalar() or 0

    c_projs = (await session.execute(text(f"SELECT count(*) FROM projects {filter_proj_direct}"), params)).scalar() or 0

    print(f"  • Itens de Notas (evaluation_items): {C_RED}{c_items}{C_RESET}")
    print(f"  • Avaliações (evaluations):           {C_RED}{c_evals}{C_RESET}")
    print(f"  • Alocações (evaluator_allocations):  {C_RED}{c_allocs}{C_RESET}")
    print(f"  • Membros de Equipe (project_members): {C_RED}{c_members}{C_RESET}")
    print(f"  • Projetos (projects):                {C_RED}{c_projs}{C_RESET}")

    if (c_items + c_evals + c_allocs + c_members + c_projs) == 0:
        print(f"{C_YELLOW}Nenhum projeto encontrado para excluir no escopo selecionado.{C_RESET}")
        return

    if not ask_confirmation("Esta ação excluirá permanentemente todos os trabalhos científicos e notas vinculadas!"):
        print(f"{C_GRAY}Operação cancelada pelo usuário.{C_RESET}")
        return

    # Executa exclusão em cascata
    await session.execute(text(f"""
        DELETE FROM evaluation_items WHERE evaluation_id IN (
            SELECT e.id FROM evaluations e JOIN projects p ON e.project_id = p.id {filter_proj}
        )
    """), params)

    await session.execute(text(f"""
        DELETE FROM evaluations WHERE project_id IN (
            SELECT id FROM projects {filter_proj_direct}
        )
    """), params)

    await session.execute(text(f"""
        DELETE FROM evaluator_allocations WHERE project_id IN (
            SELECT id FROM projects {filter_proj_direct}
        )
    """), params)

    await session.execute(text(f"""
        DELETE FROM project_members WHERE project_id IN (
            SELECT id FROM projects {filter_proj_direct}
        )
    """), params)

    await session.execute(text(f"DELETE FROM projects {filter_proj_direct}"), params)
    await session.commit()

    print(f"\n{C_GREEN}{C_BOLD}✅ Sucesso: {c_projs} projetos e todos os registros vinculados foram excluídos com sucesso!{C_RESET}")


async def delete_evaluations_and_allocations(session: AsyncSession, event_id: Optional[int] = None):
    scope_desc = f"do Evento #{event_id}" if event_id else "de TODOS os eventos"
    print(f"\n{C_BOLD}Preparando Reset de Avaliações, Notas e Alocações {scope_desc}...{C_RESET}")

    filter_proj = "WHERE p.event_id = :eid" if event_id else ""
    filter_event = "WHERE event_id = :eid" if event_id else ""
    params = {"eid": event_id} if event_id else {}

    c_items = (await session.execute(text(f"""
        SELECT count(*) FROM evaluation_items WHERE evaluation_id IN (
            SELECT e.id FROM evaluations e JOIN projects p ON e.project_id = p.id {filter_proj}
        )
    """), params)).scalar() or 0

    c_evals = (await session.execute(text(f"""
        SELECT count(*) FROM evaluations WHERE project_id IN (
            SELECT id FROM projects {filter_event}
        )
    """), params)).scalar() or 0

    c_allocs = (await session.execute(text(f"SELECT count(*) FROM evaluator_allocations {filter_event}"), params)).scalar() or 0

    print(f"  • Itens de Notas (evaluation_items): {C_RED}{c_items}{C_RESET}")
    print(f"  • Avaliações (evaluations):           {C_RED}{c_evals}{C_RESET}")
    print(f"  • Alocações (evaluator_allocations):  {C_RED}{c_allocs}{C_RESET}")
    print(f"  • Os projetos terão status redefinido para HOMOLOGATED.")
    print(f"  • A presença de avaliador na sala dos avaliadores será resetada.")

    if (c_items + c_evals + c_allocs) == 0:
        print(f"{C_YELLOW}Nenhuma avaliação ou alocação para limpar.{C_RESET}")
        return

    if not ask_confirmation("Esta ação apagará todas as notas e alocações sem remover os projetos nem as pessoas!"):
        print(f"{C_GRAY}Operação cancelada pelo usuário.{C_RESET}")
        return

    await session.execute(text(f"""
        DELETE FROM evaluation_items WHERE evaluation_id IN (
            SELECT e.id FROM evaluations e JOIN projects p ON e.project_id = p.id {filter_proj}
        )
    """), params)

    await session.execute(text(f"""
        DELETE FROM evaluations WHERE project_id IN (
            SELECT id FROM projects {filter_event}
        )
    """), params)

    await session.execute(text(f"DELETE FROM evaluator_allocations {filter_event}"), params)

    # Redefine status de projetos que estavam em avaliação
    await session.execute(text(f"""
        UPDATE projects SET status = 'HOMOLOGATED' 
        {filter_event} {"AND" if filter_event else "WHERE"} status IN ('UNDER_EVALUATION', 'EVALUATED')
    """), params)

    # Reseta presença na sala dos avaliadores
    await session.execute(text(f"""
        UPDATE event_participants SET evaluator_presence_confirmed = FALSE, evaluator_presence_confirmed_at = NULL
        {filter_event}
    """), params)

    await session.commit()
    print(f"\n{C_GREEN}{C_BOLD}✅ Sucesso: Notas, avaliações e alocações zeradas. Os projetos estão prontos para nova rodada de julgamento!{C_RESET}")


async def delete_participants(session: AsyncSession, event_id: Optional[int] = None):
    scope_desc = f"do Evento #{event_id}" if event_id else "de TODOS os eventos"
    print(f"\n{C_BOLD}Preparando exclusão de Participantes (Estudantes, Orientadores e Avaliadores) {scope_desc}...{C_RESET}")
    print(f"{C_BLUE}ℹ️  Contas de Administradores (ADMIN e donos de eventos) serão rigorosamente PRESERVADAS.{C_RESET}")

    filter_event = "WHERE event_id = :eid" if event_id else ""
    params = {"eid": event_id} if event_id else {}

    c_roles = (await session.execute(text(f"SELECT count(*) FROM event_participant_roles {filter_event}"), params)).scalar() or 0
    c_parts = (await session.execute(text(f"SELECT count(*) FROM event_participants {filter_event}"), params)).scalar() or 0
    c_subareas = (await session.execute(text(f"SELECT count(*) FROM person_subareas {filter_event}"), params)).scalar() or 0
    c_levels = (await session.execute(text(f"SELECT count(*) FROM person_education_levels {filter_event}"), params)).scalar() or 0

    print(f"  • Vínculos de Papéis (event_participant_roles):    {C_RED}{c_roles}{C_RESET}")
    print(f"  • Participações no Evento (event_participants):    {C_RED}{c_parts}{C_RESET}")
    print(f"  • Subáreas de Avaliadores (person_subareas):       {C_RED}{c_subareas}{C_RESET}")
    print(f"  • Níveis de Avaliadores (person_education_levels): {C_RED}{c_levels}{C_RESET}")
    print(f"  • Membros de Equipes de Projetos vinculados serão desvinculados.")

    if (c_roles + c_parts) == 0:
        print(f"{C_YELLOW}Nenhum participante encontrado no escopo selecionado.{C_RESET}")
        return

    if not ask_confirmation("Esta ação excluirá os participantes (alunos, professores e avaliadores) e desvinculará de equipes!"):
        print(f"{C_GRAY}Operação cancelada pelo usuário.{C_RESET}")
        return

    # Desvincula avaliações e alocações desses participantes
    if event_id:
        await session.execute(text("""
            DELETE FROM evaluation_items WHERE evaluation_id IN (
                SELECT id FROM evaluations WHERE evaluator_id IN (
                    SELECT person_id FROM event_participants WHERE event_id = :eid
                )
            )
        """), params)
        await session.execute(text("""
            DELETE FROM evaluations WHERE evaluator_id IN (
                SELECT person_id FROM event_participants WHERE event_id = :eid
            )
        """), params)
        await session.execute(text("DELETE FROM evaluator_allocations WHERE event_id = :eid"), params)
        await session.execute(text("""
            DELETE FROM project_members WHERE person_id IN (
                SELECT person_id FROM event_participants WHERE event_id = :eid
            )
        """), params)
    else:
        await session.execute(text("DELETE FROM evaluation_items"))
        await session.execute(text("DELETE FROM evaluations"))
        await session.execute(text("DELETE FROM evaluator_allocations"))
        await session.execute(text("DELETE FROM project_members"))

    await session.execute(text(f"DELETE FROM person_subareas {filter_event}"), params)
    await session.execute(text(f"DELETE FROM person_education_levels {filter_event}"), params)
    await session.execute(text(f"DELETE FROM event_participant_roles {filter_event}"), params)
    await session.execute(text(f"DELETE FROM event_participants {filter_event}"), params)

    # Exclui pessoas órfãs que não são ADMIN e não têm mais nenhuma participação em nenhum evento
    orphan_stmt = text("""
        DELETE FROM people 
        WHERE role != 'ADMIN'
        AND id NOT IN (SELECT COALESCE(owner_id, 0) FROM events)
        AND id NOT IN (SELECT person_id FROM event_administrators)
        AND id NOT IN (SELECT person_id FROM event_participants)
        AND id NOT IN (SELECT person_id FROM project_members)
    """)
    deleted_people_res = await session.execute(orphan_stmt)
    await session.commit()

    print(f"\n{C_GREEN}{C_BOLD}✅ Sucesso: Participantes excluídos do evento e {deleted_people_res.rowcount} registros de pessoas órfãs limpos!{C_RESET}")


async def delete_all_registrations(session: AsyncSession, event_id: Optional[int] = None):
    """Limpeza completa de inscritos: Projetos + Participantes juntos."""
    scope_desc = f"do Evento #{event_id}" if event_id else "de TODOS os eventos"
    print(f"\n{C_BOLD}Limpeza Completa de Inscritos (Projetos + Membros + Participantes) {scope_desc}...{C_RESET}")
    print(f"{C_BLUE}ℹ️  A estrutura da feira (Áreas, Subáreas, Critérios e Premiações) será mantida intacta.{C_RESET}")

    if not ask_confirmation("Deseja realmente limpar TODOS os trabalhos científicos e participantes inscritos?"):
        print(f"{C_GRAY}Operação cancelada pelo usuário.{C_RESET}")
        return

    await delete_projects(session, event_id)
    await delete_participants(session, event_id)
    print(f"\n{C_GREEN}{C_BOLD}✅ Limpeza completa de inscritos concluída com sucesso!{C_RESET}")


async def delete_areas_and_subareas(session: AsyncSession, event_id: Optional[int] = None):
    scope_desc = f"do Evento #{event_id}" if event_id else "de TODOS os eventos"
    print(f"\n{C_BOLD}Preparando exclusão de Áreas e Subáreas Temáticas {scope_desc}...{C_RESET}")

    filter_event = "WHERE event_id = :eid" if event_id else ""
    params = {"eid": event_id} if event_id else {}

    c_areas = (await session.execute(text(f"SELECT count(*) FROM knowledge_areas {filter_event}"), params)).scalar() or 0
    c_subs = (await session.execute(text(f"""
        SELECT count(*) FROM subareas WHERE area_id IN (
            SELECT id FROM knowledge_areas {filter_event}
        )
    """), params)).scalar() or 0

    print(f"  • Grandes Áreas (knowledge_areas): {C_RED}{c_areas}{C_RESET}")
    print(f"  • Subáreas (subareas):             {C_RED}{c_subs}{C_RESET}")
    print(f"  • Vínculos em person_subareas serão removidos.")

    if (c_areas + c_subs) == 0:
        print(f"{C_YELLOW}Nenhuma área temática encontrada no escopo.{C_RESET}")
        return

    if not ask_confirmation("Atenção: se houver projetos vinculados a essas subáreas, eles devem ser excluídos antes!"):
        print(f"{C_GRAY}Operação cancelada pelo usuário.{C_RESET}")
        return

    try:
        await session.execute(text(f"DELETE FROM person_subareas {filter_event}"), params)
        await session.execute(text(f"""
            DELETE FROM subareas WHERE area_id IN (
                SELECT id FROM knowledge_areas {filter_event}
            )
        """), params)
        await session.execute(text(f"DELETE FROM knowledge_areas {filter_event}"), params)
        await session.commit()
        print(f"\n{C_GREEN}{C_BOLD}✅ Sucesso: {c_areas} áreas e {c_subs} subáreas foram excluídas!{C_RESET}")
    except Exception as err:
        await session.rollback()
        print(f"\n{C_RED}{C_BOLD}❌ Erro ao excluir áreas: {err}{C_RESET}")
        print(f"{C_YELLOW}Dica: Se houver trabalhos vinculados a essas subáreas, use a Opção 2 (Limpar Projetos) primeiro.{C_RESET}")


async def delete_criteria_and_awards(session: AsyncSession, event_id: Optional[int] = None):
    scope_desc = f"do Evento #{event_id}" if event_id else "de TODOS os eventos"
    print(f"\n{C_BOLD}Preparando exclusão de Critérios de Avaliação e Premiações {scope_desc}...{C_RESET}")

    filter_event = "WHERE event_id = :eid" if event_id else ""
    params = {"eid": event_id} if event_id else {}

    c_awards = (await session.execute(text(f"SELECT count(*) FROM awards {filter_event}"), params)).scalar() or 0
    c_crit = (await session.execute(text(f"SELECT count(*) FROM evaluation_criteria {filter_event}"), params)).scalar() or 0
    c_links = (await session.execute(text(f"""
        SELECT count(*) FROM award_criteria WHERE award_id IN (
            SELECT id FROM awards {filter_event}
        )
    """), params)).scalar() or 0

    print(f"  • Vínculos de Premiação (award_criteria): {C_RED}{c_links}{C_RESET}")
    print(f"  • Premiações e Troféus (awards):          {C_RED}{c_awards}{C_RESET}")
    print(f"  • Critérios da Ficha (evaluation_criteria): {C_RED}{c_crit}{C_RESET}")

    if (c_awards + c_crit) == 0:
        print(f"{C_YELLOW}Nenhum critério ou premiação encontrada no escopo.{C_RESET}")
        return

    if not ask_confirmation("Esta ação excluirá os itens da ficha de avaliação e os prêmios configurados!"):
        print(f"{C_GRAY}Operação cancelada pelo usuário.{C_RESET}")
        return

    await session.execute(text(f"""
        DELETE FROM award_criteria WHERE award_id IN (
            SELECT id FROM awards {filter_event}
        )
    """), params)
    await session.execute(text(f"DELETE FROM awards {filter_event}"), params)
    await session.execute(text(f"""
        DELETE FROM evaluation_items WHERE criterion_id IN (
            SELECT id FROM evaluation_criteria {filter_event}
        )
    """), params)
    await session.execute(text(f"DELETE FROM evaluation_criteria {filter_event}"), params)
    await session.commit()

    print(f"\n{C_GREEN}{C_BOLD}✅ Sucesso: Critérios e premiações excluídos com sucesso!{C_RESET}")


async def delete_test_events(session: AsyncSession):
    """Exclui eventos criados automaticamente por suítes de testes (com 'test' no nome)."""
    print(f"\n{C_BOLD}Localizando eventos de testes automatizados ('%test%')...{C_RESET}")

    stmt = text("SELECT id, name, year FROM events WHERE name ILIKE '%test%' ORDER BY id DESC")
    res = await session.execute(stmt)
    test_events = res.fetchall()

    if not test_events:
        print(f"{C_YELLOW}Nenhum evento com termo 'Test' encontrado no banco de dados.{C_RESET}")
        return

    print(f"Foram encontrados {C_RED}{len(test_events)}{C_RESET} eventos de testes no banco de dados.")
    for e in test_events[:10]:
        print(f"  • ID #{e[0]}: {e[1]} ({e[2]})")
    if len(test_events) > 10:
        print(f"  ... e mais {len(test_events) - 10} eventos de teste.")

    if not ask_confirmation(f"Deseja excluir permanentemente todos os {len(test_events)} eventos de teste e seus dados operacionais?"):
        print(f"{C_GRAY}Operação cancelada pelo usuário.{C_RESET}")
        return

    ids = [e[0] for e in test_events]
    print(f"{C_CYAN}Excluindo dados vinculados aos eventos de teste em lote...{C_RESET}")

    await session.execute(text("""
        DELETE FROM evaluation_items WHERE evaluation_id IN (
            SELECT e.id FROM evaluations e JOIN projects p ON e.project_id = p.id
            JOIN events ev ON p.event_id = ev.id WHERE ev.name ILIKE '%test%'
        )
    """))
    await session.execute(text("""
        DELETE FROM evaluations WHERE project_id IN (
            SELECT p.id FROM projects p JOIN events ev ON p.event_id = ev.id WHERE ev.name ILIKE '%test%'
        )
    """))
    await session.execute(text("""
        DELETE FROM evaluator_allocations WHERE event_id IN (
            SELECT id FROM events WHERE name ILIKE '%test%'
        )
    """))
    await session.execute(text("""
        DELETE FROM project_members WHERE project_id IN (
            SELECT p.id FROM projects p JOIN events ev ON p.event_id = ev.id WHERE ev.name ILIKE '%test%'
        )
    """))
    await session.execute(text("""
        DELETE FROM projects WHERE event_id IN (
            SELECT id FROM events WHERE name ILIKE '%test%'
        )
    """))
    await session.execute(text("""
        DELETE FROM person_subareas WHERE event_id IN (
            SELECT id FROM events WHERE name ILIKE '%test%'
        )
    """))
    await session.execute(text("""
        DELETE FROM person_education_levels WHERE event_id IN (
            SELECT id FROM events WHERE name ILIKE '%test%'
        )
    """))
    await session.execute(text("""
        DELETE FROM event_participant_roles WHERE event_id IN (
            SELECT id FROM events WHERE name ILIKE '%test%'
        )
    """))
    await session.execute(text("""
        DELETE FROM event_participants WHERE event_id IN (
            SELECT id FROM events WHERE name ILIKE '%test%'
        )
    """))
    await session.execute(text("""
        DELETE FROM award_criteria WHERE award_id IN (
            SELECT a.id FROM awards a JOIN events ev ON a.event_id = ev.id WHERE ev.name ILIKE '%test%'
        )
    """))
    await session.execute(text("""
        DELETE FROM awards WHERE event_id IN (
            SELECT id FROM events WHERE name ILIKE '%test%'
        )
    """))
    await session.execute(text("""
        DELETE FROM evaluation_criteria WHERE event_id IN (
            SELECT id FROM events WHERE name ILIKE '%test%'
        )
    """))
    await session.execute(text("""
        DELETE FROM subareas WHERE area_id IN (
            SELECT ka.id FROM knowledge_areas ka JOIN events ev ON ka.event_id = ev.id WHERE ev.name ILIKE '%test%'
        )
    """))
    await session.execute(text("""
        DELETE FROM knowledge_areas WHERE event_id IN (
            SELECT id FROM events WHERE name ILIKE '%test%'
        )
    """))
    await session.execute(text("""
        DELETE FROM education_levels WHERE event_id IN (
            SELECT id FROM events WHERE name ILIKE '%test%'
        )
    """))
    await session.execute(text("""
        DELETE FROM event_administrators WHERE event_id IN (
            SELECT id FROM events WHERE name ILIKE '%test%'
        )
    """))
    del_ev = await session.execute(text("DELETE FROM events WHERE name ILIKE '%test%'"))
    await session.commit()

    print(f"\n{C_GREEN}{C_BOLD}✅ Sucesso: {del_ev.rowcount} eventos de teste e todas as suas dependências foram excluídos com sucesso!{C_RESET}")


async def reset_single_event(session: AsyncSession):
    """Zera todos os dados operacionais de um evento mantendo apenas sua ficha e administradores."""
    events = await get_recent_events(session)
    print(f"\n{C_BOLD}Selecione o Evento para Reset Total:{C_RESET}")
    for e in events:
        print(f"  {C_CYAN}[{e[0]}]{C_RESET} {e[1]} ({e[2]})")
    
    choice = input(f"\n{C_BOLD}Digite o ID do evento a ser zerado (ou 'c' para cancelar): {C_RESET}").strip()
    if choice.lower() in ("c", "cancelar", ""):
        return
    try:
        eid = int(choice)
    except ValueError:
        print(f"{C_RED}ID inválido.{C_RESET}")
        return

    ev_info = (await session.execute(text("SELECT name, year FROM events WHERE id = :eid"), {"eid": eid})).fetchone()
    if not ev_info:
        print(f"{C_RED}Evento #{eid} não encontrado.{C_RESET}")
        return

    print(f"\n{C_YELLOW}{C_BOLD}Você selecionou: Evento #{eid} — {ev_info[0]} ({ev_info[1]}){C_RESET}")
    print("O Reset excluirá: Projetos, Membros, Participantes, Notas, Alocações, Subáreas e Critérios desse evento.")
    print("Serão mantidos apenas: o registro do Evento e seus Administradores.")

    if not ask_confirmation(f"Deseja resetar completamente os dados do evento '{ev_info[0]}'?"):
        print(f"{C_GRAY}Operação cancelada.{C_RESET}")
        return

    await delete_projects(session, eid)
    await delete_participants(session, eid)
    await delete_criteria_and_awards(session, eid)
    await delete_areas_and_subareas(session, eid)
    print(f"\n{C_GREEN}{C_BOLD}✅ Evento #{eid} resetado com sucesso!{C_RESET}")


async def delete_all_events_except(session: AsyncSession):
    """Exclui todos os eventos cadastrados no banco, exceto o ID informado pelo usuário."""
    print(f"\n{C_BOLD}{C_RED}🗑️  Excluir Todos os Eventos (Exceto o ID Preservado){C_RESET}")
    
    stmt = text("SELECT id, name, year FROM events ORDER BY id ASC")
    res = await session.execute(stmt)
    all_events = res.fetchall()

    if not all_events:
        print(f"{C_YELLOW}Nenhum evento encontrado no banco de dados.{C_RESET}")
        return

    print(f"\n{C_BOLD}Eventos Atualmente Cadastrados no Banco:{C_RESET}")
    for e in all_events:
        print(f"  {C_CYAN}[ID #{e[0]}]{C_RESET} {e[1]} ({e[2]})")

    choice = input(f"\n{C_BOLD}Digite o ID do Evento que você deseja PRESERVAR/MANTER (ou 'c' para cancelar): {C_RESET}").strip()
    if choice.lower() in ("c", "cancelar", ""):
        print(f"{C_GRAY}Operação cancelada pelo usuário.{C_RESET}")
        return

    try:
        keep_id = int(choice)
    except ValueError:
        print(f"{C_RED}ID inválido. Operação cancelada.{C_RESET}")
        return

    kept_event = next((e for e in all_events if e[0] == keep_id), None)
    if not kept_event:
        print(f"{C_RED}Evento com ID #{keep_id} não foi encontrado no banco de dados. Operação abortada.{C_RESET}")
        return

    events_to_delete = [e for e in all_events if e[0] != keep_id]
    if not events_to_delete:
        print(f"\n{C_GREEN}O evento #{keep_id} ({kept_event[1]}) é o ÚNICO evento cadastrado no banco de dados. Nenhum outro evento para excluir.{C_RESET}")
        return

    print(f"\n{C_YELLOW}{C_BOLD}Plano de Exclusão:{C_RESET}")
    print(f"  {C_GREEN}✔ EVENTO PRESERVADO:{C_RESET} [ID #{keep_id}] {kept_event[1]} ({kept_event[2]})")
    print(f"  {C_RED}✖ EVENTOS QUE SERÃO EXCLUÍDOS ({len(events_to_delete)} eventos):{C_RESET}")
    for e in events_to_delete:
        print(f"    • ID #{e[0]}: {e[1]} ({e[2]})")

    print(f"\n{C_RED}Todas as dependências dos eventos excluídos serão apagadas (Projetos, Avaliações, Participantes, Critérios, Áreas, etc.).{C_RESET}")
    if not ask_confirmation(f"Deseja realmente apagar todos os {len(events_to_delete)} eventos acima e MANTER APENAS o Evento #{keep_id}?"):
        print(f"{C_GRAY}Operação cancelada pelo usuário.{C_RESET}")
        return

    print(f"\n{C_CYAN}Excluindo dependências e eventos em cascata...{C_RESET}")
    params = {"keep_id": keep_id}

    # 1. Notas e Avaliações
    await session.execute(text("""
        DELETE FROM evaluation_items WHERE evaluation_id IN (
            SELECT e.id FROM evaluations e JOIN projects p ON e.project_id = p.id WHERE p.event_id != :keep_id
        )
    """), params)
    await session.execute(text("""
        DELETE FROM evaluations WHERE project_id IN (
            SELECT p.id FROM projects p WHERE p.event_id != :keep_id
        )
    """), params)
    await session.execute(text("DELETE FROM evaluator_allocations WHERE event_id != :keep_id"), params)

    # 2. Projetos e Membros
    await session.execute(text("""
        DELETE FROM project_members WHERE project_id IN (
            SELECT p.id FROM projects p WHERE p.event_id != :keep_id
        )
    """), params)
    await session.execute(text("DELETE FROM projects WHERE event_id != :keep_id"), params)

    # 3. Participantes e Vínculos
    await session.execute(text("DELETE FROM person_subareas WHERE event_id != :keep_id"), params)
    await session.execute(text("DELETE FROM person_education_levels WHERE event_id != :keep_id"), params)
    await session.execute(text("DELETE FROM event_participant_roles WHERE event_id != :keep_id"), params)
    await session.execute(text("DELETE FROM event_participants WHERE event_id != :keep_id"), params)

    # 4. Critérios, Prêmios e Estrutura
    await session.execute(text("""
        DELETE FROM award_criteria WHERE award_id IN (
            SELECT a.id FROM awards a WHERE a.event_id != :keep_id
        )
    """), params)
    await session.execute(text("DELETE FROM awards WHERE event_id != :keep_id"), params)
    await session.execute(text("DELETE FROM evaluation_criteria WHERE event_id != :keep_id"), params)
    await session.execute(text("""
        DELETE FROM subareas WHERE area_id IN (
            SELECT ka.id FROM knowledge_areas ka WHERE ka.event_id != :keep_id
        )
    """), params)
    await session.execute(text("DELETE FROM knowledge_areas WHERE event_id != :keep_id"), params)
    await session.execute(text("DELETE FROM education_levels WHERE event_id != :keep_id"), params)
    await session.execute(text("DELETE FROM event_administrators WHERE event_id != :keep_id"), params)

    # 5. Excluir os eventos
    del_res = await session.execute(text("DELETE FROM events WHERE id != :keep_id"), params)

    # 6. Limpar pessoas órfãs que não sejam administradores globais e não tenham nenhum vínculo com o evento preservado
    await session.execute(text("""
        DELETE FROM people
        WHERE role != 'ADMIN'
          AND id NOT IN (SELECT person_id FROM event_participants WHERE event_id = :keep_id)
          AND id NOT IN (SELECT person_id FROM event_administrators WHERE event_id = :keep_id)
          AND id NOT IN (
              SELECT pm.person_id FROM project_members pm JOIN projects p ON pm.project_id = p.id WHERE p.event_id = :keep_id
          )
    """), params)

    await session.commit()
    print(f"\n{C_GREEN}{C_BOLD}✅ Sucesso: {del_res.rowcount} eventos excluídos! Apenas o Evento #{keep_id} ({kept_event[1]}) foi mantido intacto no banco de dados.{C_RESET}")


async def reset_entire_database(session: AsyncSession):
    """Limpa todas as tabelas operacionais e recria o Administrador Mestre para ambiente de testes limpo."""
    print(f"\n{C_RED}{C_BOLD}{'!' * 60}")
    print("   ATENÇÃO: RESET GERAL DO BANCO DE DADOS (AMBIENTE DE TESTES)")
    print("   Esta ação apagará TODOS os dados de TODAS as tabelas!")
    print(f"{'!' * 60}{C_RESET}\n")

    if not ask_confirmation("TEM CERTEZA ABSOLUTA QUE DESEJA ZERAR TODO O BANCO DE DADOS?"):
        print(f"{C_GRAY}Operação abortada com segurança.{C_RESET}")
        return

    print(f"{C_CYAN}Limpando todas as tabelas operacionais em cascata...{C_RESET}")

    tables_in_order = [
        "snack_deliveries", "snack_moments",
        "evaluation_items", "evaluations", "evaluator_allocations",
        "project_members", "projects",
        "person_subareas", "person_education_levels", "event_participant_roles", "event_participants",
        "award_criteria", "awards", "evaluation_criteria",
        "subareas", "knowledge_areas", "education_levels",
        "event_administrators", "events", "registration_verifications",
        "people"
    ]

    for t in tables_in_order:
        try:
            await session.execute(text(f'DELETE FROM "{t}"'))
        except Exception as e:
            print(f"{C_YELLOW}Erro ao limpar {t}: {e}{C_RESET}")

    # Recria o Administrador Geral padrão para testes
    admin_hash = get_password_hash("admin123")
    await session.execute(text("""
        INSERT INTO people (name, email, role, password_hash, barcode, created_at, updated_at)
        VALUES ('Administrador FECITEL', 'admin@fecitel.ifms.edu.br', 'ADMIN', :pwd, 'BC-ADMIN-01', NOW(), NOW())
    """), {"pwd": admin_hash})

    await session.commit()
    print(f"\n{C_GREEN}{C_BOLD}✅ Banco de dados completamente limpo!{C_RESET}")
    print(f"{C_BOLD}Administrador Padrão Recriado:{C_RESET}")
    print(f"  • E-mail: {C_CYAN}admin@fecitel.ifms.edu.br{C_RESET}")
    print(f"  • Senha:  {C_CYAN}admin123{C_RESET}\n")


# -------------------------------------------------------------
# MENU PRINCIPAL
# -------------------------------------------------------------

async def main_menu():
    engine = await get_engine()
    
    while True:
        print_banner()
        print(f"{C_BOLD}Selecione a ação desejada:{C_RESET}")
        print(f"  {C_CYAN}[1]{C_RESET} 📊 Ver Contadores / Estatísticas Atuais do Banco")
        print(f"  {C_CYAN}[2]{C_RESET} 🔬 Limpar Trabalhos Científicos / Projetos (e notas/membros)")
        print(f"  {C_CYAN}[3]{C_RESET} 👥 Limpar Participantes (Alunos, Orientadores, Avaliadores)")
        print(f"  {C_CYAN}[4]{C_RESET} 📦 Limpeza Geral de Inscritos (Projetos + Participantes)")
        print(f"  {C_CYAN}[5]{C_RESET} 📝 Limpar Apenas Avaliações e Notas (Reset da Banca Avaliadora)")
        print(f"  {C_CYAN}[6]{C_RESET} 🏷️  Limpar Áreas e Subáreas do Conhecimento")
        print(f"  {C_CYAN}[7]{C_RESET} 🏆 Limpar Critérios de Avaliação e Premiações")
        print(f"  {C_CYAN}[8]{C_RESET} 🧹 Limpar Eventos de Testes Automatizados (Eventos com 'Test' no nome)")
        print(f"  {C_CYAN}[9]{C_RESET} 💣 Reset Total de um Evento Específico")
        print(f"  {C_CYAN}[10]{C_RESET} 🗑️  Remover TODOS os Eventos (Exceto o Evento Informado)")
        print(f"  {C_CYAN}[11]{C_RESET} ⚠️  Reset Geral do Banco de Dados (Zera tudo e recria Admin)")
        print(f"  {C_RED}[0]{C_RESET} 🚪 Sair")

        choice = input(f"\n{C_BOLD}Opção desejada [0-11]: {C_RESET}").strip()

        if choice == "0":
            print(f"\n{C_GREEN}Encerrando utilitário. Bons testes!{C_RESET}\n")
            break

        async with AsyncSession(engine) as session:
            try:
                if choice == "1":
                    counts = await get_table_counts(session)
                    print_stats_table(counts)
                elif choice == "2":
                    eid = await select_event_scope(session)
                    await delete_projects(session, eid)
                elif choice == "3":
                    eid = await select_event_scope(session)
                    await delete_participants(session, eid)
                elif choice == "4":
                    eid = await select_event_scope(session)
                    await delete_all_registrations(session, eid)
                elif choice == "5":
                    eid = await select_event_scope(session)
                    await delete_evaluations_and_allocations(session, eid)
                elif choice == "6":
                    eid = await select_event_scope(session)
                    await delete_areas_and_subareas(session, eid)
                elif choice == "7":
                    eid = await select_event_scope(session)
                    await delete_criteria_and_awards(session, eid)
                elif choice == "8":
                    await delete_test_events(session)
                elif choice == "9":
                    await reset_single_event(session)
                elif choice == "10":
                    await delete_all_events_except(session)
                elif choice == "11":
                    await reset_entire_database(session)
                else:
                    print(f"{C_RED}Opção inválida. Escolha um número de 0 a 11.{C_RESET}")
            except Exception as e:
                await session.rollback()
                print(f"\n{C_RED}{C_BOLD}❌ Ocorreu um erro durante a execução: {e}{C_RESET}")

        input(f"\n{C_GRAY}Pressione [Enter] para voltar ao menu principal...{C_RESET}")


if __name__ == "__main__":
    try:
        asyncio.run(main_menu())
    except KeyboardInterrupt:
        print(f"\n\n{C_YELLOW}Operação interrompida pelo usuário.{C_RESET}\n")
