"""popula_cursos

Revision ID: 09f65363b2d2
Revises: 0bfdcae4b2bc
Create Date: 2026-06-05 20:21:39.786444

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '09f65363b2d2'
down_revision: Union[str, Sequence[str], None] = '0bfdcae4b2bc'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Upgrade schema."""
    op.execute("""
        INSERT INTO cursos (nome) VALUES 
        ('Medicina'),
        ('Enfermagem'),
        ('Odontologia'),
        ('Fisioterapia'),
        ('Psicologia'),
        ('Nutrição'),
        ('Ciências Biológicas'),
        ('Biomedicina'),
        ('Técnico em Informática'),
        ('Análise e Desenvolvimento de Sistemas')
        ON CONFLICT (nome) DO NOTHING;
    """)

def downgrade() -> None:
    """Downgrade schema."""
    op.execute("""
        DELETE FROM cursos WHERE nome IN (
            'Medicina', 'Enfermagem', 'Odontologia', 'Fisioterapia', 'Psicologia', 'Nutrição',
            'Ciências Biológicas', 'Biomedicina', 'Técnico em Informática', 'Análise e Desenvolvimento de Sistemas'
        );
    """)
