import random
import string
from datetime import datetime
from sqlalchemy.orm import Session

def gerar_codigo_acesso(db: Session) -> str:
    from app.models.pessoa import CodigoAcesso
    ano_atual = str(datetime.now().year)[-2:]
    
    # Gargalo Potencial: Em um cenário com muitos usuários cadastrados, este loop de
    # tentativa e erro no banco pode gerar lentidão e múltiplas requisições (colisão).
    while True:
        letras_iniciais = "".join(random.choices(string.ascii_uppercase, k=2))
        letra_final = random.choice(string.ascii_uppercase)
        codigo = f"{letras_iniciais}{ano_atual}{letra_final}"
        
        if not db.query(CodigoAcesso).filter(CodigoAcesso.codigo == codigo).first():
            return codigo
