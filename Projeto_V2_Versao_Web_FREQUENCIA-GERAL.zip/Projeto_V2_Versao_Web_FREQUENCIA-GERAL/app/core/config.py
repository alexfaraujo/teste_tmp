from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    environment: str
    secret_key: str
    db_user: str
    db_password: str
    db_host: str
    db_port: int
    db_name: str
    email_address: str
    pagination_limit: int
    max_image_pixels: int
    max_image_resize_width: int
    max_image_resize_height: int
    mailtrap_token: str
    mailtrap_inbox_id: int | None = None

    @property
    def database_url(self) -> str:
        return f"postgresql://{self.db_user}:{self.db_password}@{self.db_host}:{self.db_port}/{self.db_name}"

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8")

settings = Settings()
