from sqlalchemy import Column, Integer, String, Date, Time, DECIMAL, DateTime, ForeignKey, UniqueConstraint
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from app.db.base import Base

class Evento(Base):
    __tablename__ = "eventos"
    
    id = Column(Integer, primary_key=True, index=True)
    codigo = Column(String(6), unique=True, index=True, nullable=False)
    data_inicio = Column(Date, nullable=False)
    hora_inicio = Column(Time, nullable=False)
    nome = Column(String, nullable=False)
    local = Column(String, nullable=False)
    carga_horaria = Column(DECIMAL(5, 2), nullable=False)
    criado_em = Column(DateTime(timezone=True), server_default=func.now())
    deleted_at = Column(DateTime(timezone=True), nullable=True)
    logo = Column(String, nullable=True)

    organizadores = relationship("EventoOrganizador", back_populates="evento")
    presencas = relationship("Presenca", back_populates="evento")
    fotos = relationship("PhotoEvent", back_populates="evento")
    relatos = relationship("ReportEvent", back_populates="evento")

    @property
    def hora_termino(self):
        from datetime import datetime, timedelta
        dt = datetime.combine(datetime.today(), self.hora_inicio)
        dt_end = dt + timedelta(hours=float(self.carga_horaria))
        return dt_end.time()

class EventoOrganizador(Base):
    __tablename__ = "eventos_organizadores"
    __table_args__ = (UniqueConstraint('evento_id', 'pessoa_id', name='uq_evento_pessoa'),)
    
    id = Column(Integer, primary_key=True, index=True)
    evento_id = Column(Integer, ForeignKey("eventos.id"), index=True, nullable=False)
    pessoa_id = Column(Integer, ForeignKey("pessoas.id"), index=True, nullable=False)

    evento = relationship("Evento", back_populates="organizadores")
    pessoa = relationship("Pessoa", back_populates="eventos_organizados")
