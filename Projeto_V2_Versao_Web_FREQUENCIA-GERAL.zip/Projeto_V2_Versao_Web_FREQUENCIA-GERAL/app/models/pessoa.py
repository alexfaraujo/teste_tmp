from sqlalchemy import Column, Integer, String, ForeignKey, DateTime
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from app.db.base import Base

class Curso(Base):
    __tablename__ = "cursos"
    
    id = Column(Integer, primary_key=True, index=True)
    nome = Column(String, unique=True, nullable=False)
    
    pessoas = relationship("Pessoa", back_populates="curso")

class Pessoa(Base):
    __tablename__ = "pessoas"
    
    id = Column(Integer, primary_key=True, index=True)
    nome = Column(String, nullable=False)
    curso_id = Column(Integer, ForeignKey("cursos.id"), index=True)
    telefone = Column(String)
    email = Column(String, unique=True, index=True, nullable=False)
    foto = Column(String)

    curso = relationship("Curso", back_populates="pessoas")
    codigo_acesso = relationship("CodigoAcesso", back_populates="pessoa", uselist=False)
    eventos_organizados = relationship("EventoOrganizador", back_populates="pessoa")
    presencas = relationship("Presenca", back_populates="pessoa")
    fotos = relationship("PhotoEvent", back_populates="pessoa")
    relatos = relationship("ReportEvent", back_populates="pessoa")

class CodigoAcesso(Base):
    __tablename__ = "codigos_acesso"
    
    id = Column(Integer, primary_key=True, index=True)
    pessoa_id = Column(Integer, ForeignKey("pessoas.id"), unique=True, index=True, nullable=False)
    codigo = Column(String(6), unique=True, index=True, nullable=False)
    criado_em = Column(DateTime(timezone=True), server_default=func.now())

    pessoa = relationship("Pessoa", back_populates="codigo_acesso")
