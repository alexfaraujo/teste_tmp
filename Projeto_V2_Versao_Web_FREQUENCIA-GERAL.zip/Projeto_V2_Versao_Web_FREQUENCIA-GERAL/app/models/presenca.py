from sqlalchemy import Column, Integer, String, ForeignKey, DateTime
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from app.db.base import Base

class Presenca(Base):
    __tablename__ = "presencas"
    
    id = Column(Integer, primary_key=True, index=True)
    pessoa_id = Column(Integer, ForeignKey("pessoas.id"), index=True, nullable=False)
    evento_id = Column(Integer, ForeignKey("eventos.id"), index=True, nullable=False)
    registrado_em = Column(DateTime(timezone=True), server_default=func.now())
    endereco_ip = Column(String)

    pessoa = relationship("Pessoa", back_populates="presencas")
    evento = relationship("Evento", back_populates="presencas")

class PhotoEvent(Base):
    __tablename__ = "photos_event"
    
    id = Column(Integer, primary_key=True, index=True)
    evento_id = Column(Integer, ForeignKey("eventos.id"), index=True, nullable=False)
    pessoa_id = Column(Integer, ForeignKey("pessoas.id"), index=True, nullable=False)
    caminho_arquivo = Column(String, nullable=False)
    data_upload = Column(DateTime(timezone=True), server_default=func.now())
    status = Column(String, default="ativo")
    descricao = Column(String)

    pessoa = relationship("Pessoa", back_populates="fotos")
    evento = relationship("Evento", back_populates="fotos")

class ReportEvent(Base):
    __tablename__ = "reports_event"
    
    id = Column(Integer, primary_key=True, index=True)
    evento_id = Column(Integer, ForeignKey("eventos.id"), index=True, nullable=False)
    pessoa_id = Column(Integer, ForeignKey("pessoas.id"), index=True, nullable=False)
    relato = Column(String, nullable=False)
    data_upload = Column(DateTime(timezone=True), server_default=func.now())
    status = Column(String, default="ativo")

    pessoa = relationship("Pessoa", back_populates="relatos")
    evento = relationship("Evento", back_populates="relatos")
