from pydantic import BaseModel, EmailStr
from typing import Optional

class PessoaBase(BaseModel):
    nome: str
    telefone: Optional[str] = None
    email: EmailStr

class PessoaCreate(PessoaBase):
    curso_id: Optional[int] = None

class PessoaResponse(PessoaBase):
    id: int
    curso_id: Optional[int] = None
    foto: Optional[str] = None

    class Config:
        from_attributes = True

class LoginRequest(BaseModel):
    codigo_acesso: str
