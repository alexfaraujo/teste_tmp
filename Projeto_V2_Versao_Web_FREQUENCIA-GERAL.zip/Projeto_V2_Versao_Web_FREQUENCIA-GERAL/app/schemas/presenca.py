from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class PresencaBase(BaseModel):
    evento_id: int

class PresencaResponse(BaseModel):
    id: int
    pessoa_id: int
    evento_id: int
    registrado_em: datetime
    endereco_ip: Optional[str] = None

    class Config:
        from_attributes = True

class PhotoUploadResponse(BaseModel):
    id: int
    evento_id: int
    pessoa_id: int
    caminho_arquivo: str
    status: str

    class Config:
        from_attributes = True

class ReportUploadResponse(BaseModel):
    id: int
    evento_id: int
    pessoa_id: int
    status: str

    class Config:
        from_attributes = True
