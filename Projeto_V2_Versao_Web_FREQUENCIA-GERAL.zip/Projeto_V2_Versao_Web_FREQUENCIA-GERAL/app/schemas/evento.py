from pydantic import BaseModel
from typing import Optional, List
from datetime import date, time, datetime
from decimal import Decimal

class EventoBase(BaseModel):
    nome: str
    local: str
    data_inicio: date
    hora_inicio: time
    carga_horaria: Decimal

class EventoCreate(EventoBase):
    organizadores_ids: List[int]

class EventoResponse(EventoBase):
    id: int
    codigo: str
    criado_em: datetime
    logo: Optional[str] = None

    class Config:
        from_attributes = True

class EventoUpdate(BaseModel):
    nome: Optional[str] = None
    local: Optional[str] = None
    data_inicio: Optional[date] = None
    hora_inicio: Optional[time] = None
    carga_horaria: Optional[Decimal] = None
