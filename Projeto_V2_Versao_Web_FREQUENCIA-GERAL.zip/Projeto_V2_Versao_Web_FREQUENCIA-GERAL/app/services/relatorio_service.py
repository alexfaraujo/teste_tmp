import os
import subprocess
import threading
from odf.opendocument import load
from odf.table import Table, TableRow, TableCell, TableColumn
from odf.text import P
from odf.style import Style, ParagraphProperties
from odf import teletype
from odf.element import Text
from odf.draw import Frame, Image
from datetime import datetime
from PIL import Image as PILImage

class RelatorioService:
    # Semáforo para limitar instâncias concorrentes do LibreOffice (Evita OOM Kill)
    _pdf_semaphore = threading.Semaphore(2)

    @staticmethod
    def gerar_pdf(caminho_odt: str, diretorio_saida: str) -> str:
        comando = [
            "libreoffice",
            "--headless",
            "--convert-to",
            "pdf",
            "--outdir",
            diretorio_saida,
            caminho_odt
        ]
        with RelatorioService._pdf_semaphore:
            subprocess.run(comando, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        nome_base = os.path.basename(caminho_odt)
        nome_sem_extensao = os.path.splitext(nome_base)[0]
        return os.path.join(diretorio_saida, f"{nome_sem_extensao}.pdf")

    @staticmethod
    def clone_element(element):
        if isinstance(element, Text):
            return Text(element.data)
        new_el = element.__class__(qname=element.qname, qattributes=element.attributes)
        for child in element.childNodes:
            cloned_child = RelatorioService.clone_element(child)
            if isinstance(cloned_child, Text):
                new_el.appendChild(cloned_child)
            else:
                new_el.addElement(cloned_child)
        return new_el

    @staticmethod
    def preencher_frequencia_base(doc, evento, presencas):
        # Substituir placeholders de texto
        for p in doc.getElementsByType(P):
            text = teletype.extractText(p)
            if '{{eventos.nome}}' in text:
                new_text = text.replace('{{eventos.nome}}', evento.nome)
                p.childNodes = []
                teletype.addTextToElement(p, new_text)
                
            if '{{eventos.data}}' in text:
                data_fmt = evento.data_inicio.strftime('%d/%m/%Y')
                new_text = text.replace('{{eventos.data}}', data_fmt)
                p.childNodes = []
                teletype.addTextToElement(p, new_text)
                
            if '{{eventos.local}}' in text:
                new_text = text.replace('{{eventos.local}}', evento.local)
                p.childNodes = []
                teletype.addTextToElement(p, new_text)
                
            if '{{eventos.horario}}' in text:
                new_text = text.replace('{{eventos.horario}}', evento.hora_inicio.strftime('%H:%M'))
                p.childNodes = []
                teletype.addTextToElement(p, new_text)

            if '{{eventos.logo}}' in text:
                if evento.logo:
                    logo_path = evento.logo.lstrip('/')
                else:
                    logo_path = os.path.join("static", "img", "logo_ifms_horizontal.png")
                
                if os.path.exists(logo_path):
                    href = doc.addPicture(logo_path)
                    
                    try:
                        with PILImage.open(logo_path) as img:
                            w_px, h_px = img.size
                    except Exception:
                        w_px, h_px = 150, 50
                        
                    max_h_px = 150
                    scale = min(1.0, max_h_px / float(h_px)) if h_px > 0 else 1.0
                    
                    final_h_px = h_px * scale
                    final_w_px = w_px * scale
                    
                    # Convert px to cm (assuming 96 dpi)
                    px_to_cm = 2.54 / 96.0
                    w_cm = final_w_px * px_to_cm
                    h_cm = final_h_px * px_to_cm
                    
                    frame = Frame(width=f"{w_cm:.2f}cm", height=f"{h_cm:.2f}cm")
                    image = Image(href=href)
                    frame.addElement(image)
                    p.childNodes = []
                    p.addElement(frame)
                else:
                    new_text = text.replace('{{eventos.logo}}', '')
                    p.childNodes = []
                    teletype.addTextToElement(p, new_text)

        # Substituir tabela
        tables = doc.getElementsByType(Table)
        for table in tables:
            rows = table.getElementsByType(TableRow)
            template_row = None
            for row in rows:
                cells = row.getElementsByType(TableCell)
                row_text = ""
                for cell in cells:
                    row_text += teletype.extractText(cell)
                if '{{pessoas.nome}}' in row_text:
                    template_row = row
                    break
            
            if template_row:
                for presenca in presencas:
                    new_row = RelatorioService.clone_element(template_row)
                    for cell in new_row.getElementsByType(TableCell):
                        for p in cell.getElementsByType(P):
                            text = teletype.extractText(p)
                            if '{{pessoas.nome}}' in text:
                                new_text = text.replace('{{pessoas.nome}}', presenca.pessoa.nome)
                                p.childNodes = []
                                teletype.addTextToElement(p, new_text)
                            if '{{pessoas.curso}}' in text:
                                curso_nome = presenca.pessoa.curso.nome if presenca.pessoa.curso else '-'
                                new_text = text.replace('{{pessoas.curso}}', curso_nome)
                                p.childNodes = []
                                teletype.addTextToElement(p, new_text)
                            if '{{presencas.registrado_em}}' in text:
                                # handle timezone awareness properly if needed
                                reg_dt = presenca.registrado_em.astimezone() if presenca.registrado_em.tzinfo else presenca.registrado_em
                                reg_fmt = reg_dt.strftime('%H:%M:%S')
                                new_text = text.replace('{{presencas.registrado_em}}', reg_fmt)
                                p.childNodes = []
                                teletype.addTextToElement(p, new_text)
                    table.insertBefore(new_row, template_row)
                table.removeChild(template_row)
                break
        return doc

    @staticmethod
    def gerar_relatorio_presenca(evento, presencas):
        template_path = os.path.join("static", "template_relatorios", "template_lista_frequencia.odt")
        doc = load(template_path)
        doc = RelatorioService.preencher_frequencia_base(doc, evento, presencas)
        
        output_dir = os.path.join("static", "reports")
        os.makedirs(output_dir, exist_ok=True)
        
        output_odt = os.path.join(output_dir, f"relatorio_evento_{evento.id}.odt")
        doc.save(output_odt)
        
        pdf_path = RelatorioService.gerar_pdf(output_odt, output_dir)
        return pdf_path

    @staticmethod
    def gerar_relatorio_galeria(evento, presencas, fotos):
        template_path = os.path.join("static", "template_relatorios", "template_lista_frequencia.odt")
        doc = load(template_path)
        doc = RelatorioService.preencher_frequencia_base(doc, evento, presencas)
        
        # Add Page Break
        page_break_style = Style(name="PageBreak", family="paragraph")
        page_break_style.addElement(ParagraphProperties(breakbefore="page"))
        doc.automaticstyles.addElement(page_break_style)
        doc.text.addElement(P(stylename=page_break_style))
        
        title_style = Style(name="TitleStyle", family="paragraph")
        title_style.addElement(ParagraphProperties(textalign="center", margintop="0.5cm", marginbottom="0.5cm"))
        doc.automaticstyles.addElement(title_style)
        
        doc.text.addElement(P(text="Galeria de Fotos", stylename=title_style))
        
        gallery_table = Table(name="GalleryTable")
        gallery_table.addElement(TableColumn(numbercolumnsrepeated=2))
        
        current_row = None
        for i, foto in enumerate(fotos):
            if i % 2 == 0:
                current_row = TableRow()
                gallery_table.addElement(current_row)
                
            cell = TableCell()
            
            # Adicionar imagem
            # Needs to add image to the ODT zip, and create a Frame
            abs_img_path = os.path.join("static", foto.caminho_arquivo)
            if os.path.exists(abs_img_path):
                # We add the file to the ODT pictures folder
                href = doc.addPicture(abs_img_path)
                frame = Frame(width="8cm", height="8cm")
                image = Image(href=href)
                frame.addElement(image)
                p_img = P(stylename=title_style)
                p_img.addElement(frame)
                cell.addElement(p_img)
            
            # Adicionar descrição
            desc = foto.descricao if foto.descricao else ""
            autor = f"Por: {foto.pessoa.nome.split()[0]}"
            p_desc = P(text=f"{desc} ({autor})", stylename=title_style)
            cell.addElement(p_desc)
            
            current_row.addElement(cell)
            
        doc.text.addElement(gallery_table)
        
        output_dir = os.path.join("static", "reports")
        os.makedirs(output_dir, exist_ok=True)
        
        output_odt = os.path.join(output_dir, f"relatorio_galeria_evento_{evento.id}.odt")
        doc.save(output_odt)
        
        pdf_path = RelatorioService.gerar_pdf(output_odt, output_dir)
        return pdf_path

    @staticmethod
    def gerar_relatorio_relatos(evento, presencas, relatos):
        template_path = os.path.join("static", "template_relatorios", "template_lista_frequencia.odt")
        doc = load(template_path)
        doc = RelatorioService.preencher_frequencia_base(doc, evento, presencas)
        
        page_break_style = Style(name="PageBreak", family="paragraph")
        page_break_style.addElement(ParagraphProperties(breakbefore="page"))
        doc.automaticstyles.addElement(page_break_style)
        doc.text.addElement(P(stylename=page_break_style))
        
        title_style = Style(name="TitleStyle", family="paragraph")
        title_style.addElement(ParagraphProperties(textalign="center", margintop="0.5cm", marginbottom="0.5cm"))
        doc.automaticstyles.addElement(title_style)
        
        doc.text.addElement(P(text="Relatos do Evento", stylename=title_style))
        
        name_style = Style(name="NameStyle", family="paragraph")
        name_style.addElement(ParagraphProperties(margintop="0.5cm"))
        doc.automaticstyles.addElement(name_style)
        
        text_style = Style(name="TextStyle", family="paragraph")
        text_style.addElement(ParagraphProperties(marginbottom="0.5cm"))
        doc.automaticstyles.addElement(text_style)
        
        for relato in relatos:
            # We don't have native bold in simple odfpy without span styles, so we'll just format nicely
            reg_dt = relato.data_upload.astimezone() if relato.data_upload.tzinfo else relato.data_upload
            header_text = f"Participante: {relato.pessoa.nome} | Enviado em: {reg_dt.strftime('%d/%m/%Y %H:%M')}"
            
            doc.text.addElement(P(text=header_text, stylename=name_style))
            
            # Split lines for proper paragraphing
            lines = relato.relato.split('\n')
            for line in lines:
                doc.text.addElement(P(text=line, stylename=text_style))
                
            doc.text.addElement(P(text="---------------------------------------------------", stylename=text_style))
            
        output_dir = os.path.join("static", "reports")
        os.makedirs(output_dir, exist_ok=True)
        
        output_odt = os.path.join(output_dir, f"relatorio_relatos_evento_{evento.id}.odt")
        doc.save(output_odt)
        
        pdf_path = RelatorioService.gerar_pdf(output_odt, output_dir)
        return pdf_path

    @staticmethod
    def gerar_relatorio_completo(evento, presencas, fotos, relatos):
        template_path = os.path.join("static", "template_relatorios", "template_lista_frequencia.odt")
        doc = load(template_path)
        
        # 1. Lista de Presença
        doc = RelatorioService.preencher_frequencia_base(doc, evento, presencas)
        
        page_break_style = Style(name="PageBreak", family="paragraph")
        page_break_style.addElement(ParagraphProperties(breakbefore="page"))
        doc.automaticstyles.addElement(page_break_style)
        
        title_style = Style(name="TitleStyle", family="paragraph")
        title_style.addElement(ParagraphProperties(textalign="center", margintop="0.5cm", marginbottom="0.5cm"))
        doc.automaticstyles.addElement(title_style)
        
        # 2. Galeria de Fotos
        if fotos:
            doc.text.addElement(P(stylename=page_break_style))
            doc.text.addElement(P(text="Galeria de Fotos", stylename=title_style))
            
            gallery_table = Table(name="GalleryTable")
            gallery_table.addElement(TableColumn(numbercolumnsrepeated=2))
            
            current_row = None
            for i, foto in enumerate(fotos):
                if i % 2 == 0:
                    current_row = TableRow()
                    gallery_table.addElement(current_row)
                    
                cell = TableCell()
                
                abs_img_path = os.path.join("static", foto.caminho_arquivo)
                if os.path.exists(abs_img_path):
                    href = doc.addPicture(abs_img_path)
                    frame = Frame(width="8cm", height="8cm")
                    image = Image(href=href)
                    frame.addElement(image)
                    p_img = P(stylename=title_style)
                    p_img.addElement(frame)
                    cell.addElement(p_img)
                
                desc = foto.descricao if foto.descricao else ""
                autor = f"Por: {foto.pessoa.nome.split()[0]}"
                p_desc = P(text=f"{desc} ({autor})", stylename=title_style)
                cell.addElement(p_desc)
                
                current_row.addElement(cell)
                
            doc.text.addElement(gallery_table)
            
        # 3. Relatos
        if relatos:
            doc.text.addElement(P(stylename=page_break_style))
            doc.text.addElement(P(text="Relatos do Evento", stylename=title_style))
            
            name_style = Style(name="NameStyle", family="paragraph")
            name_style.addElement(ParagraphProperties(margintop="0.5cm"))
            doc.automaticstyles.addElement(name_style)
            
            text_style = Style(name="TextStyle", family="paragraph")
            text_style.addElement(ParagraphProperties(marginbottom="0.5cm"))
            doc.automaticstyles.addElement(text_style)
            
            for relato in relatos:
                reg_dt = relato.data_upload.astimezone() if relato.data_upload.tzinfo else relato.data_upload
                header_text = f"Participante: {relato.pessoa.nome} | Enviado em: {reg_dt.strftime('%d/%m/%Y %H:%M')}"
                
                doc.text.addElement(P(text=header_text, stylename=name_style))
                
                lines = relato.relato.split('\n')
                for line in lines:
                    doc.text.addElement(P(text=line, stylename=text_style))
                    
                doc.text.addElement(P(text="---------------------------------------------------", stylename=text_style))
        
        output_dir = os.path.join("static", "reports")
        os.makedirs(output_dir, exist_ok=True)
        
        output_odt = os.path.join(output_dir, f"relatorio_completo_evento_{evento.id}.odt")
        doc.save(output_odt)
        
        pdf_path = RelatorioService.gerar_pdf(output_odt, output_dir)
        return pdf_path
