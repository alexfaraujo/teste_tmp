import os
import mailtrap as mt
from app.core.config import settings

class EmailService:
    @staticmethod
    def send_access_code(to_email: str, nome: str, codigo: str):
        if not settings.mailtrap_token or settings.mailtrap_token == "your_mailtrap_token_here":
            print(f"[{to_email}] Mailtrap Token not set. Mocking email send for access code: {codigo}")
            return False
            
        try:
            # If the user is using Transactional but hasn't verified their domain, 
            # Mailtrap requires sending from hello@demomailtrap.com
            # If they are using Sandbox, any sender works.
            sender_email = settings.email_address
            if "gmail.com" in sender_email and not settings.mailtrap_inbox_id:
                sender_email = "hello@demomailtrap.com"
                
            mail = mt.Mail(
                sender=mt.Address(email=sender_email, name="Falaqueufui Sistema"),
                to=[mt.Address(email=to_email, name=nome)],
                subject="Seu Código de Acesso - Falaqueufui",
                text=f"Olá {nome},\n\nSeu código de acesso ao sistema Falaqueufui é: {codigo}\n\nGuarde este código, pois ele é sua chave de acesso.",
                category="Access Code"
            )

            # Switch between Sandbox (Testing) and Transactional (Production) automatically
            if settings.mailtrap_inbox_id:
                client = mt.MailtrapClient(token=settings.mailtrap_token, sandbox=True, inbox_id=settings.mailtrap_inbox_id)
            else:
                client = mt.MailtrapClient(token=settings.mailtrap_token)
                
            client.send(mail)
            return True
        except Exception as e:
            print(f"Error sending email to {to_email}: {e}")
            return False
