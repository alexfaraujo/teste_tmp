import os
from PIL import Image, ImageFilter, ImageOps
from app.core.config import settings

def process_image_for_gallery(input_path: str, output_path: str, watermark_path: str = None):
    """
    Processa a imagem para formato quadrado padrão (1000x1000).
    A imagem original é ajustada, colocada no centro, e o excedente preenchido com blur.
    Adiciona marca d'água e moldura branca.
    """
    # Trava global contra Decompression Bombs
    Image.MAX_IMAGE_PIXELS = settings.max_image_pixels
    
    try:
        with Image.open(input_path) as img:
            img = ImageOps.exif_transpose(img)
            img = img.convert("RGB")
            
            # Reduz as dimensões brutas ANTES de qualquer processamento pesado na RAM
            img.thumbnail((settings.max_image_resize_width, settings.max_image_resize_height), Image.Resampling.LANCZOS)
            
            # Base quadrada (1000x1000)
            target_size = (1000, 1000)
            
            # 1. Criar o fundo com blur
            # Redimensionar para cobrir todo o fundo, cortando o excesso se necessário
            bg_ratio = max(target_size[0] / img.width, target_size[1] / img.height)
            bg_size = (int(img.width * bg_ratio), int(img.height * bg_ratio))
            bg_img = img.resize(bg_size, Image.Resampling.LANCZOS)
            
            # Cortar o centro para ficar 1000x1000
            left = (bg_img.width - target_size[0]) / 2
            top = (bg_img.height - target_size[1]) / 2
            right = (bg_img.width + target_size[0]) / 2
            bottom = (bg_img.height + target_size[1]) / 2
            bg_img = bg_img.crop((left, top, right, bottom))
            
            # Aplicar o blur intenso
            bg_img = bg_img.filter(ImageFilter.GaussianBlur(radius=20))
            
            # 2. Imagem principal
            # Ajustar para caber dentro de 900x900 para deixar margem
            fg_img = img.copy()
            fg_img.thumbnail((900, 900), Image.Resampling.LANCZOS)
            
            # 3. Moldura Branca
            # Criar uma imagem branca um pouco maior que a fg_img (10 pixels de borda)
            border_size = 10
            frame_size = (fg_img.width + border_size*2, fg_img.height + border_size*2)
            frame_img = Image.new("RGB", frame_size, "white")
            frame_img.paste(fg_img, (border_size, border_size))
            
            # Colar a moldura com a imagem no centro do fundo
            offset = ((target_size[0] - frame_img.width) // 2, (target_size[1] - frame_img.height) // 2)
            bg_img.paste(frame_img, offset)
            
            # 4. Marca d'água
            if watermark_path and os.path.exists(watermark_path):
                with Image.open(watermark_path) as wm:
                    wm = wm.convert("RGBA")
                    # Redimensionar a marca d'água se for muito grande
                    wm.thumbnail((200, 200), Image.Resampling.LANCZOS)
                    # Colar no canto inferior direito
                    margin = 20
                    wm_pos = (target_size[0] - wm.width - margin, target_size[1] - wm.height - margin)
                    # O terceiro argumento no paste com imagem RGBA atua como máscara para transparência
                    bg_img.paste(wm, wm_pos, mask=wm)
            
            # Salvar o resultado
            os.makedirs(os.path.dirname(output_path), exist_ok=True)
            bg_img.save(output_path, "JPEG", quality=85)
            
            return True
    except Exception as e:
        print(f"Erro ao processar imagem: {e}")
        return False
