from fastapi import APIRouter, Depends, Request, Form, UploadFile, File, BackgroundTasks
from fastapi.responses import RedirectResponse, HTMLResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session, joinedload, selectinload
from datetime import date, datetime
from sqlalchemy import func, case
import random
import string
import os
import time
import math
from PIL import Image, ImageOps
from app.db.database import get_db
from app.models.pessoa import CodigoAcesso, Pessoa, Curso
from app.models.evento import Evento, EventoOrganizador
from app.models.presenca import Presenca
from app.services.email_service import EmailService

from app.core.config import settings

from datetime import date

router = APIRouter(tags=["auth"])
templates = Jinja2Templates(directory="app/templates")
templates.env.globals['EMAIL_ADDRESS'] = settings.email_address

@router.get("/", response_class=HTMLResponse)
def index(request: Request):
    if "user_id" in request.session:
        return RedirectResponse(url="/perfil", status_code=303)
    return templates.TemplateResponse(request=request, name="login.html")

@router.post("/login")
def login(request: Request, access_key: str = Form(...), db: Session = Depends(get_db)):
    # The code format check isn't strictly necessary since we check exact match, 
    # but upper it just in case user types in lowercase
    access_key = access_key.upper()
    codigo = db.query(CodigoAcesso).filter(CodigoAcesso.codigo == access_key).first()
    if codigo:
        request.session["user_id"] = codigo.pessoa_id
        return RedirectResponse(url="/perfil", status_code=303)
    return RedirectResponse(url="/?error=invalid_key", status_code=303)

@router.get("/cadastro", response_class=HTMLResponse)
def cadastro_form(request: Request, db: Session = Depends(get_db)):
    if "user_id" in request.session:
        return RedirectResponse(url="/perfil", status_code=303)
    cursos = db.query(Curso).order_by(Curso.nome.asc()).all()
    return templates.TemplateResponse(request=request, name="cadastro.html", context={"cursos": cursos})

def generate_access_code(db: Session) -> str:
    year_suffix = str(datetime.now().year)[-2:]
    chars = string.ascii_uppercase + "123456789"
    max_attempts = 5000
    for _ in range(max_attempts):
        parte = "".join(random.choices(chars, k=4))
        code = f"{parte}{year_suffix}"
        # Check uniqueness
        if not db.query(CodigoAcesso).filter(CodigoAcesso.codigo == code).first():
            return code
    return None

@router.post("/cadastro")
def criar_cadastro(
    request: Request, 
    nome: str = Form(...),
    email: str = Form(...),
    telefone: str = Form(...),
    curso_id: int = Form(...),
    background_tasks: BackgroundTasks = BackgroundTasks(),
    db: Session = Depends(get_db)
):
    # Verifica email unico
    if db.query(Pessoa).filter(Pessoa.email == email).first():
        return RedirectResponse(url="/cadastro?error=Email+já+cadastrado", status_code=303)
    
    nova_pessoa = Pessoa(nome=nome, email=email, telefone=telefone, curso_id=curso_id)
    db.add(nova_pessoa)
    db.flush() # obtem o ID
    
    codigo = generate_access_code(db)
    if not codigo:
        db.rollback()
        return RedirectResponse(url="/cadastro?error=Não+há+chaves+disponíveis.+Contate+o+suporte.", status_code=303)
    novo_codigo = CodigoAcesso(pessoa_id=nova_pessoa.id, codigo=codigo)
    db.add(novo_codigo)
    
    db.commit()
    
    # Send email asynchronously
    background_tasks.add_task(EmailService.send_access_code, to_email=nova_pessoa.email, nome=nova_pessoa.nome, codigo=codigo)
    
    # In production this code would be sent by email. 
    # For now we flash it in the URL to show to the user.
    return RedirectResponse(url=f"/cadastro?success_code={codigo}", status_code=303)

@router.get("/reenviar-codigo", response_class=HTMLResponse)
def reenviar_codigo_form(request: Request):
    if "user_id" in request.session:
        return RedirectResponse(url="/perfil", status_code=303)
    return templates.TemplateResponse(request=request, name="reenviar_codigo.html")

@router.post("/reenviar-codigo")
def processar_reenvio(request: Request, background_tasks: BackgroundTasks, email: str = Form(...), db: Session = Depends(get_db)):
    pessoa = db.query(Pessoa).filter(Pessoa.email == email).first()
    if not pessoa:
        return RedirectResponse(url="/reenviar-codigo?error=not_found", status_code=303)
    
    # Retrieve existing code
    if pessoa.codigo_acesso:
        codigo = pessoa.codigo_acesso.codigo
        # Send email asynchronously
        background_tasks.add_task(EmailService.send_access_code, to_email=pessoa.email, nome=pessoa.nome, codigo=codigo)
        # In a real scenario we send email. Here we show it.
        return RedirectResponse(url=f"/reenviar-codigo?success_code={codigo}", status_code=303)
    return RedirectResponse(url="/reenviar-codigo?error=no_code", status_code=303)

@router.get("/editar-perfil", response_class=HTMLResponse)
def editar_perfil_form(request: Request, db: Session = Depends(get_db)):
    if "user_id" not in request.session:
        return RedirectResponse(url="/", status_code=303)
        
    user_id = request.session["user_id"]
    user = db.query(Pessoa).filter(Pessoa.id == user_id).first()
    
    if not user:
        return RedirectResponse(url="/", status_code=303)
        
    return templates.TemplateResponse(request=request, name="editar_perfil.html", context={"user": user})

@router.post("/editar-perfil")
def atualizar_perfil(
    request: Request, 
    nome: str = Form(...),
    telefone: str = Form(""),
    foto: UploadFile = File(None),
    db: Session = Depends(get_db)
):
    if "user_id" not in request.session:
        return RedirectResponse(url="/", status_code=303)
        
    user_id = request.session["user_id"]
    user = db.query(Pessoa).filter(Pessoa.id == user_id).first()
    
    if not user:
        return RedirectResponse(url="/", status_code=303)
        
    user.nome = nome
    user.telefone = telefone
    
    if foto and foto.filename:
        # Validate allowed extensions
        ext = foto.filename.split(".")[-1].lower()
        if ext in ["jpg", "jpeg", "png", "gif"]:
            # Setup path
            photo_dir = os.path.join("static", "photo")
            os.makedirs(photo_dir, exist_ok=True)
            
            timestamp = int(time.time())
            filename = f"user_{user_id}_{timestamp}.{ext}"
            filepath = os.path.join(photo_dir, filename)
            
            # Use PIL to resize to 512px max
            try:
                img = Image.open(foto.file)
                img = ImageOps.exif_transpose(img)
                if img.mode in ("RGBA", "P") and ext in ("jpg", "jpeg"):
                    img = img.convert("RGB")
                    
                max_size = 512
                if img.width > max_size or img.height > max_size:
                    img.thumbnail((max_size, max_size), Image.Resampling.LANCZOS)
                
                img.save(filepath)
                # Save relative path to DB
                user.foto = f"photo/{filename}"
            except Exception as e:
                print(f"Error saving image: {e}")
                
    db.commit()
    return RedirectResponse(url="/perfil", status_code=303)

@router.get("/logout")
def logout(request: Request):
    request.session.pop("user_id", None)
    return RedirectResponse(url="/", status_code=303)

@router.get("/perfil", response_class=HTMLResponse)
def perfil(request: Request, db: Session = Depends(get_db)):
    if "user_id" not in request.session:
        return RedirectResponse(url="/", status_code=303)
    
    user_id = request.session["user_id"]
    
    # Fetch user
    user = db.query(Pessoa).filter(Pessoa.id == user_id).first()
    if not user:
        request.session.pop("user_id", None)
        return RedirectResponse(url="/", status_code=303)
        
    today = date.today()
    
    # Meus eventos (onde sou organizador e é hoje)
    meus_eventos = db.query(Evento).options(
        selectinload(Evento.presencas),
        selectinload(Evento.fotos),
        selectinload(Evento.relatos)
    ).join(EventoOrganizador).filter(
        EventoOrganizador.pessoa_id == user_id,
        Evento.data_inicio == today,
        Evento.deleted_at.is_(None)
    ).all()
    
    # Presenças hoje
    presencas_hoje = db.query(Presenca).options(
        joinedload(Presenca.evento).selectinload(Evento.fotos),
        joinedload(Presenca.evento).selectinload(Evento.relatos)
    ).join(Evento).filter(
        Presenca.pessoa_id == user_id,
        func.date(Presenca.registrado_em) == today
    ).all()
    
    return templates.TemplateResponse(
        request=request, 
        name="perfil.html", 
        context={
            "user": user, 
            "meus_eventos": meus_eventos, 
            "presencas_hoje": presencas_hoje
        }
    )

@router.get("/historico", response_class=HTMLResponse)
def historico(
    request: Request, 
    filter: str = "responsible", 
    search: str = "", 
    ano: str = "", 
    page: int = 1, 
    db: Session = Depends(get_db)
):
    if "user_id" not in request.session:
        return RedirectResponse(url="/", status_code=303)
        
    user_id = request.session["user_id"]
    user = db.query(Pessoa).filter(Pessoa.id == user_id).first()
    
    if not user:
        return RedirectResponse(url="/", status_code=303)

    if filter == "participant":
        # Eventos onde o usuario tem presenca
        query_presencas = db.query(Presenca).options(
            joinedload(Presenca.evento).selectinload(Evento.organizadores),
            joinedload(Presenca.evento).selectinload(Evento.fotos),
            joinedload(Presenca.evento).selectinload(Evento.relatos),
            joinedload(Presenca.evento).selectinload(Evento.presencas)
        ).join(Evento).filter(
            Presenca.pessoa_id == user_id,
            Evento.deleted_at.is_(None)
        )
        
        if search:
            query_presencas = query_presencas.filter(Evento.nome.ilike(f"%{search}%"))
        if ano:
            query_presencas = query_presencas.filter(func.extract('year', Evento.data_inicio) == int(ano))
            
        hoje = date.today()
        prioridade_temporal = case(
            (Evento.data_inicio == hoje, 0),
            (Evento.data_inicio > hoje, 1),
            else_=2
        )
        
        query_presencas = query_presencas.order_by(
            prioridade_temporal,
            Evento.data_inicio.desc(),
            Evento.hora_inicio.desc()
        )
        
        total_items = query_presencas.count()
        limit = settings.pagination_limit
        total_pages = math.ceil(total_items / limit) if total_items > 0 else 1
        page = max(1, min(page, total_pages))
        offset = (page - 1) * limit
        
        presencas = query_presencas.offset(offset).limit(limit).all()
        historico_eventos = [p.evento for p in presencas]
    else:
        # Default: Eventos onde o usuario é organizador (filter == "responsible")
        filter = "responsible"
        query_eventos = db.query(Evento).options(
            selectinload(Evento.presencas),
            selectinload(Evento.organizadores),
            selectinload(Evento.fotos),
            selectinload(Evento.relatos)
        ).join(EventoOrganizador).filter(
            EventoOrganizador.pessoa_id == user_id,
            Evento.deleted_at.is_(None)
        )
        
        if search:
            query_eventos = query_eventos.filter(Evento.nome.ilike(f"%{search}%"))
        if ano:
            query_eventos = query_eventos.filter(func.extract('year', Evento.data_inicio) == int(ano))
            
        hoje = date.today()
        prioridade_temporal = case(
            (Evento.data_inicio == hoje, 0),
            (Evento.data_inicio > hoje, 1),
            else_=2
        )
        
        query_eventos = query_eventos.order_by(
            prioridade_temporal,
            Evento.data_inicio.desc(),
            Evento.hora_inicio.desc()
        )
        
        total_items = query_eventos.count()
        limit = settings.pagination_limit
        total_pages = math.ceil(total_items / limit) if total_items > 0 else 1
        page = max(1, min(page, total_pages))
        offset = (page - 1) * limit
        
        historico_eventos = query_eventos.offset(offset).limit(limit).all()

    # Passamos o organizador de cada evento para o template conseguir identificar se o user é organizador ou participante daquele evento
    
    return templates.TemplateResponse(
        request=request, 
        name="historico.html", 
        context={
            "user": user,
            "historico_eventos": historico_eventos,
            "current_filter": filter,
            "search": search,
            "ano": ano,
            "page": page,
            "total_pages": total_pages,
            "total_items": total_items,
            "hoje": date.today()
        }
    )
