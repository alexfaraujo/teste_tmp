from fastapi import APIRouter, Depends, Request, Form, Query, UploadFile, File
from typing import Optional
from fastapi.responses import RedirectResponse, HTMLResponse, FileResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session, joinedload
from sqlalchemy.sql import func
from datetime import datetime, timedelta
from typing import List
import uuid
import os
from app.db.database import get_db
from app.models.evento import Evento, EventoOrganizador
from app.models.pessoa import Pessoa
from app.models.presenca import Presenca, PhotoEvent, ReportEvent
from app.services.relatorio_service import RelatorioService

from app.core.config import settings

router = APIRouter(prefix="/evento", tags=["evento"])
templates = Jinja2Templates(directory="app/templates")
templates.env.globals['EMAIL_ADDRESS'] = settings.email_address

@router.get("/novo", response_class=HTMLResponse)
def novo_evento_form(request: Request, db: Session = Depends(get_db)):
    if "user_id" not in request.session:
        return RedirectResponse(url="/", status_code=303)
    user_id = request.session["user_id"]
    return templates.TemplateResponse(request=request, name="evento_form.html", context={"evento": None, "current_orgs": [], "current_user_id": user_id})

@router.get("/pesquisar_usuarios")
def pesquisar_usuarios(request: Request, q: str = Query(..., min_length=2), db: Session = Depends(get_db)):
    if "user_id" not in request.session:
        return []
    users = db.query(Pessoa).filter(Pessoa.nome.ilike(f"%{q}%")).limit(15).all()
    return [{"id": u.id, "nome": u.nome, "email": u.email} for u in users]

@router.post("/novo")
def criar_evento(
    request: Request, 
    nome: str = Form(...),
    local: str = Form(...),
    data_inicio: str = Form(...),
    hora_inicio: str = Form(...),
    carga_horaria: float = Form(...),
    organizadores_ids: List[int] = Form(default=[]),
    logo: Optional[UploadFile] = File(None),
    db: Session = Depends(get_db)
):
    if "user_id" not in request.session:
        return RedirectResponse(url="/", status_code=303)
    
    user_id = request.session["user_id"]
    
    data_obj = datetime.strptime(data_inicio, "%Y-%m-%d").date()
    
    import random
    import string
    chars = string.ascii_uppercase + "123456789"
    ano_str = str(data_obj.year)[-2:]
    
    max_attempts = 5000
    codigo_evento = None
    for _ in range(max_attempts):
        parte1 = ''.join(random.choices(chars, k=2))
        parte2 = ''.join(random.choices(chars, k=2))
        temp_code = f"{parte1}{ano_str}{parte2}"
        if not db.query(Evento).filter(Evento.codigo == temp_code).first():
            codigo_evento = temp_code
            break
            
    if not codigo_evento:
        return RedirectResponse(url="/evento/novo?error=Não+há+chaves+de+evento+disponíveis.+Contate+o+suporte.", status_code=303)
    
    try:
        parsed_hora = datetime.strptime(hora_inicio, "%H:%M:%S").time()
    except ValueError:
        parsed_hora = datetime.strptime(hora_inicio, "%H:%M").time()

    novo_evento = Evento(
        nome=nome,
        local=local,
        data_inicio=datetime.strptime(data_inicio, "%Y-%m-%d").date(),
        hora_inicio=parsed_hora,
        carga_horaria=carga_horaria,
        codigo=codigo_evento
    )
    
    # Processamento de logo
    if logo and logo.filename:
        ext = logo.filename.split('.')[-1].lower()
        if ext in ['png', 'jpg', 'jpeg']:
            logo_filename = f"{codigo_evento}_logo.{ext}"
            logo_dir = os.path.join("static", "img", "logos")
            os.makedirs(logo_dir, exist_ok=True)
            logo_path = os.path.join(logo_dir, logo_filename)
            with open(logo_path, "wb") as f:
                f.write(logo.file.read())
            novo_evento.logo = f"/static/img/logos/{logo_filename}"

    db.add(novo_evento)
    db.flush() # Para pegar o id
    
    # Adicionar organizadores (garantindo que o criador está na lista)
    ids_to_add = set(organizadores_ids)
    ids_to_add.add(user_id)
    
    for o_id in ids_to_add:
        organizador = EventoOrganizador(evento_id=novo_evento.id, pessoa_id=o_id)
        db.add(organizador)
    
    db.commit()
    return RedirectResponse(url="/perfil", status_code=303)

@router.get("/editar/{evento_id}", response_class=HTMLResponse)
def editar_evento_form(request: Request, evento_id: int, db: Session = Depends(get_db)):
    if "user_id" not in request.session:
        return RedirectResponse(url="/", status_code=303)
    
    user_id = request.session["user_id"]
    evento = db.query(Evento).join(EventoOrganizador).filter(
        Evento.id == evento_id,
        EventoOrganizador.pessoa_id == user_id,
        Evento.deleted_at.is_(None)
    ).first()
    
    if not evento:
        return RedirectResponse(url="/perfil?error=Acesso+negado", status_code=303)
        
    current_orgs = [org.pessoa for org in evento.organizadores if org.pessoa_id != user_id]
        
    return templates.TemplateResponse(request=request, name="evento_form.html", context={"evento": evento, "current_orgs": current_orgs, "current_user_id": user_id})

@router.post("/editar/{evento_id}")
def editar_evento(
    request: Request, 
    evento_id: int,
    nome: str = Form(...),
    local: str = Form(...),
    data_inicio: str = Form(...),
    hora_inicio: str = Form(...),
    carga_horaria: float = Form(...),
    organizadores_ids: List[int] = Form(default=[]),
    logo: Optional[UploadFile] = File(None),
    db: Session = Depends(get_db)
):
    if "user_id" not in request.session:
        return RedirectResponse(url="/", status_code=303)
        
    user_id = request.session["user_id"]
    evento = db.query(Evento).join(EventoOrganizador).filter(
        Evento.id == evento_id,
        EventoOrganizador.pessoa_id == user_id,
        Evento.deleted_at.is_(None)
    ).first()
    
    if not evento:
        return RedirectResponse(url="/perfil?error=Acesso+negado", status_code=303)
        
    try:
        parsed_hora = datetime.strptime(hora_inicio, "%H:%M:%S").time()
    except ValueError:
        parsed_hora = datetime.strptime(hora_inicio, "%H:%M").time()
        
    evento.nome = nome
    evento.local = local
    evento.data_inicio = datetime.strptime(data_inicio, "%Y-%m-%d").date()
    evento.hora_inicio = parsed_hora
    evento.carga_horaria = carga_horaria
    
    # Processamento de logo
    if logo and logo.filename:
        ext = logo.filename.split('.')[-1].lower()
        if ext in ['png', 'jpg', 'jpeg']:
            logo_filename = f"{evento.codigo}_logo.{ext}"
            logo_dir = os.path.join("static", "img", "logos")
            os.makedirs(logo_dir, exist_ok=True)
            logo_path = os.path.join(logo_dir, logo_filename)
            with open(logo_path, "wb") as f:
                f.write(logo.file.read())
            evento.logo = f"/static/img/logos/{logo_filename}"
    
    # Atualizar organizadores no banco (garantindo que o criador/atual está na lista)
    ids_to_add = set(organizadores_ids)
    ids_to_add.add(user_id)
    
    db.query(EventoOrganizador).filter(EventoOrganizador.evento_id == evento.id).delete()
    for o_id in ids_to_add:
        org = EventoOrganizador(evento_id=evento.id, pessoa_id=o_id)
        db.add(org)
        
    db.commit()
    
    return RedirectResponse(url="/perfil", status_code=303)

@router.post("/excluir/{evento_id}")
def excluir_evento(request: Request, evento_id: int, db: Session = Depends(get_db)):
    if "user_id" not in request.session:
        return RedirectResponse(url="/", status_code=303)
        
    user_id = request.session["user_id"]
    evento = db.query(Evento).join(EventoOrganizador).filter(
        Evento.id == evento_id,
        EventoOrganizador.pessoa_id == user_id,
        Evento.deleted_at.is_(None)
    ).first()
    
    if not evento:
        return RedirectResponse(url="/perfil?error=Acesso+negado", status_code=303)
        
    # Verificar presenças
    tem_presencas = db.query(Presenca).filter(Presenca.evento_id == evento_id).first()
    if tem_presencas:
        return RedirectResponse(url="/perfil?error=Não+é+possível+excluir+um+evento+com+presenças", status_code=303)
        
    evento.deleted_at = func.now()
    db.commit()
    return RedirectResponse(url="/perfil", status_code=303)

@router.get("/painel/{evento_id}", response_class=HTMLResponse)
def painel_evento(request: Request, evento_id: int, db: Session = Depends(get_db)):
    if "user_id" not in request.session:
        return RedirectResponse(url="/", status_code=303)
        
    user_id = request.session["user_id"]
    
    # Check if user is organizer
    evento = db.query(Evento).join(EventoOrganizador).filter(
        Evento.id == evento_id,
        EventoOrganizador.pessoa_id == user_id,
        Evento.deleted_at.is_(None)
    ).first()
    
    if not evento:
        return RedirectResponse(url="/perfil?error=Acesso+negado", status_code=303)
        
    presencas = db.query(Presenca).options(joinedload(Presenca.pessoa).joinedload(Pessoa.curso)).filter(Presenca.evento_id == evento_id).all()
    fotos = db.query(PhotoEvent).options(joinedload(PhotoEvent.pessoa)).filter(PhotoEvent.evento_id == evento_id, PhotoEvent.status == 'ativo').all()
    relatos = db.query(ReportEvent).options(joinedload(ReportEvent.pessoa)).filter(ReportEvent.evento_id == evento_id, ReportEvent.status == 'ativo').all()
    
    # Moderation window: 72 hours from the START of the event
    from datetime import timezone
    start_dt = datetime.combine(evento.data_inicio, evento.hora_inicio).astimezone()
    is_moderation_open = False
    
    now = datetime.now(timezone.utc).astimezone()
        
    if now <= start_dt + timedelta(hours=72):
        is_moderation_open = True
        
    return templates.TemplateResponse(request=request, name="evento_painel.html", context={
        "evento": evento,
        "presencas": presencas,
        "fotos": fotos,
        "relatos": relatos,
        "is_moderation_open": is_moderation_open
    })

@router.get("/{evento_id}/relatorio")
def relatorio_presenca(request: Request, evento_id: int, db: Session = Depends(get_db)):
    if "user_id" not in request.session:
        return RedirectResponse(url="/", status_code=303)
        
    evento = db.query(Evento).join(EventoOrganizador).filter(
        Evento.id == evento_id,
        EventoOrganizador.pessoa_id == request.session["user_id"]
    ).first()
    
    if not evento:
        return RedirectResponse(url="/perfil?error=Acesso+negado", status_code=303)
        
    presencas = db.query(Presenca).options(joinedload(Presenca.pessoa).joinedload(Pessoa.curso)).filter(Presenca.evento_id == evento_id).all()
    pdf_path = RelatorioService.gerar_relatorio_presenca(evento, presencas)
    
    if os.path.exists(pdf_path):
        return FileResponse(pdf_path, media_type='application/pdf', filename=f"Lista_Presenca_{evento.codigo}.pdf")
    return RedirectResponse(url=f"/evento/painel/{evento_id}?error=Falha+ao+gerar+PDF", status_code=303)

@router.get("/{evento_id}/relatorio_galeria")
def relatorio_galeria(request: Request, evento_id: int, db: Session = Depends(get_db)):
    if "user_id" not in request.session:
        return RedirectResponse(url="/", status_code=303)
        
    evento = db.query(Evento).join(EventoOrganizador).filter(
        Evento.id == evento_id,
        EventoOrganizador.pessoa_id == request.session["user_id"]
    ).first()
    
    if not evento:
        return RedirectResponse(url="/perfil?error=Acesso+negado", status_code=303)
        
    presencas = db.query(Presenca).options(joinedload(Presenca.pessoa).joinedload(Pessoa.curso)).filter(Presenca.evento_id == evento_id).all()
    fotos = db.query(PhotoEvent).options(joinedload(PhotoEvent.pessoa)).filter(PhotoEvent.evento_id == evento_id, PhotoEvent.status == 'ativo').all()
    
    pdf_path = RelatorioService.gerar_relatorio_galeria(evento, presencas, fotos)
    
    if os.path.exists(pdf_path):
        return FileResponse(pdf_path, media_type='application/pdf', filename=f"Galeria_{evento.codigo}.pdf")
    return RedirectResponse(url=f"/evento/painel/{evento_id}?error=Falha+ao+gerar+PDF", status_code=303)

@router.get("/{evento_id}/relatorio_relatos")
def relatorio_relatos(request: Request, evento_id: int, db: Session = Depends(get_db)):
    if "user_id" not in request.session:
        return RedirectResponse(url="/", status_code=303)
        
    evento = db.query(Evento).join(EventoOrganizador).filter(
        Evento.id == evento_id,
        EventoOrganizador.pessoa_id == request.session["user_id"]
    ).first()
    
    if not evento:
        return RedirectResponse(url="/perfil?error=Acesso+negado", status_code=303)
        
    presencas = db.query(Presenca).options(joinedload(Presenca.pessoa).joinedload(Pessoa.curso)).filter(Presenca.evento_id == evento_id).all()
    relatos = db.query(ReportEvent).options(joinedload(ReportEvent.pessoa)).filter(ReportEvent.evento_id == evento_id, ReportEvent.status == 'ativo').all()
    
    pdf_path = RelatorioService.gerar_relatorio_relatos(evento, presencas, relatos)
    
    if os.path.exists(pdf_path):
        return FileResponse(pdf_path, media_type='application/pdf', filename=f"Relatos_{evento.codigo}.pdf")
    return RedirectResponse(url=f"/evento/painel/{evento_id}?error=Falha+ao+gerar+PDF", status_code=303)

@router.get("/{evento_id}/relatorio_completo")
def relatorio_completo(request: Request, evento_id: int, db: Session = Depends(get_db)):
    if "user_id" not in request.session:
        return RedirectResponse(url="/", status_code=303)
        
    evento = db.query(Evento).join(EventoOrganizador).filter(
        Evento.id == evento_id,
        EventoOrganizador.pessoa_id == request.session["user_id"]
    ).first()
    
    if not evento:
        return RedirectResponse(url="/perfil?error=Acesso+negado", status_code=303)
        
    presencas = db.query(Presenca).options(joinedload(Presenca.pessoa).joinedload(Pessoa.curso)).filter(Presenca.evento_id == evento_id).all()
    fotos = db.query(PhotoEvent).options(joinedload(PhotoEvent.pessoa)).filter(PhotoEvent.evento_id == evento_id, PhotoEvent.status == 'ativo').all()
    relatos = db.query(ReportEvent).options(joinedload(ReportEvent.pessoa)).filter(ReportEvent.evento_id == evento_id, ReportEvent.status == 'ativo').all()
    
    pdf_path = RelatorioService.gerar_relatorio_completo(evento, presencas, fotos, relatos)
    
    if os.path.exists(pdf_path):
        return FileResponse(pdf_path, media_type='application/pdf', filename=f"Relatorio_Completo_{evento.codigo}.pdf")
    return RedirectResponse(url=f"/evento/painel/{evento_id}?error=Falha+ao+gerar+PDF", status_code=303)
