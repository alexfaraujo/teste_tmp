from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from starlette.middleware.sessions import SessionMiddleware
from app.core.config import settings
from app.api import routes_auth, routes_eventos, routes_presenca

def create_app() -> FastAPI:
    app = FastAPI(
        title="Falaqueufui",
        version="2.0.0",
        description="API para gestão de eventos, registro de presença e upload de fotos/relatórios."
    )
    
    app.mount("/static", StaticFiles(directory="static"), name="static")
    
    app.add_middleware(SessionMiddleware, secret_key=settings.secret_key)
    
    app.include_router(routes_auth.router)
    app.include_router(routes_eventos.router)
    app.include_router(routes_presenca.router)
    
    return app
