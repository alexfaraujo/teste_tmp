---
trigger: always_on
---

## 4. Funcionalidades e Regras de Negócio (Lógica do App) 

### 4.1. Autenticação e Autorização
*   **Login (`/login`):** O usuário insere um "código de acesso" (Access Key). Se o código existir na tabela `codigos_acesso`, a sessão do usuário é iniciada e vinculada ao `pessoa_id`. Manter a sessão ativa até que o usuário faça logout ou feche o navegador. Não é necessário armazenar o estado do login em JWT ou banco de dados. O estado deve ser armazenado em variáveis de sessão.
*   **Permissões de Criação de Evento:** Apenas usuários pertecentes a relação `eventos_organizadores` pode gerenciar os eventos dos quais ele é organizador. Ou seja, somente aquele que estiver cadastrado na relação `eventos_organizadores` com o `evento_id` e `pessoa_id` corretos poderá gerenciar aquele evento. A pessoa que criar um evento deve ser automaticamente inserida como organizadora daquele evento. Qualquer pessoa cadastrada no sistema pode criar um evento novo e indicar os organizadores daquele evento, escolhendo pessoas do cadastro de usuários existente. O próprio usuário que criar o evento já será automaticamente um organizador daquele evento. Não existe evento sem organizador.

### 4.2. Gestão de Eventos (`/evento/novo`, `/evento/editar`, `/evento/excluir`)
*   Todos os usuários do sistema podem criar eventos definindo nome, data, horário, local e carga horária (em horas).
*   A exclusão de eventos é **lógica** (preenche o campo `deleted_at`) quando o usuário excluir um evento do qual ele é organizador.
*   **Bloqueio de Exclusão:** Um evento não pode ser excluído se já houver pelo menos uma presença registrada.
*   Apenas as pessoas pertecentes a relação `eventos_organizadores` podem editar ou excluir um evento do qual ele é organizador.

### 4.3. Registro de Frequência (`/frequencia`)
*   O usuário insere o ID do evento para registrar presença.
*   **Validações Críticas:**
    *   A data atual deve ser exatamente igual à data do evento.
    *   O horário atual deve estar entre o horário de início (`horario`) e o horário de término (calculado somando a `carga_horaria` ao horário de início). Incluindo uma hora de tolerância após o horário de término.
    *   Impede registros duplicados. Ou seja, se o usuário já tiver registrado presença no evento, ele não poderá registrar presença novamente. O usuário não deve registrar presença em mais de um evento que tenham data e horário sobrepostos. Caso ele se apresente em um novo evento que tenha data e horário sobreposto, o sistema deve recusar o registro de presença do usuário. Portanto, antes de registrar a presença no evento, o sistema deve verificar se o usuário já registrou presença em algum evento que tenha data e horário sobrepostos.
*   **Auto-registro do Organizador não deve existir:** O organizador deve registrar sua frequência no evento, como todos os demais participantes. As mesmas regras valem para ele.  

### 4.4. Upload, Processamento de Imagens e envio dos relatos
*   **Foto de Perfil (`/upload_foto`):** Salva em `static/photo`. Se a imagem for maior que 512px, é redimensionada. O usuário só pode fazer upload se tiver sessão ativa após autenticado.
*   **Fotos de Eventos (`/upload_event_photo`):** Limite de **10 fotos por usuário por evento**. A contagem das fotos deve considerar o status (ativo/inativo). Fotos ativas contam para o limite, fotos inativas não contam para o limite. As fotos só podem ser enviadas se o usuário tiver sessão ativa após autenticado. O usuário só pode enviar até 10 fotos por evento.
    *   **Processamento Gráfico Avançado (`process_image_for_gallery`):** Quando a imagem vai ser renderizada nos relatórios, ela é processada para um formato quadrado padrão (1000x1000). A imagem original é ajustada (thumbnail), colocada no centro, e o espaço excedente é preenchido com a própria imagem ampliada e com efeito de desfoque (*blur*). Adicionalmente, aplica-se uma marca d'água (`logo_transp.png`) no canto inferior direito e uma moldura branca.
*   **Envio de Relatos (`/report`):** O usuário pode enviar um relato por evento. O relato deve ser enviado em formato de texto longo. O relato deve ser enviado em até 24 horas após o término do evento. Caso contrário, o relato não será enviado. Deve ter uma opção para o usuário clicar e poder escrever o relato em uma caixa de texto. Após 24 horas um relato enviado não pode mais ser editado. O envio do relato só pode ser feito se o usuário tiver com sessão ativa após autenticado. O usuário só pode enviar um relato por evento.

### 4.5. Painel do Evento e Moderação (`/painel/<id>`)
*   O organizador tem acesso a um painel com a lista de presenças, todas as fotos e relatórios enviados pelos participantes.
*   **Regras de Exclusão/Moderação (`/delete_photo`, `/delete_report`):**
    *   O **Autor** (quem fez o upload) pode excluir sua própria foto/relatório em até **24 horas** após o upload.
    *   O **Organizador** do evento atua como moderador e pode excluir qualquer foto/relatório em até **72 horas** a partir do horário de início do evento.
    *   A exclusão altera o `status` para `'inativo'` (Soft delete).

### 4.6. Geração Automática de Documentos (`/relatorio`, `/relatorio_galeria`)
*   **Relatório de Presenças:** O sistema carrega o template `template_lista_frequencia.odt`. Substitui as variáveis (ex: `{{eventos.nome}}`, `{{eventos.data}}`) com os dados do banco. Ele varre a tabela do template para encontrar as tags (ex: `{{pessoas.nome}}`), clona a linha do template para cada participante presente, insere os dados, e remove a linha original.
*   **Galeria de Fotos:** Similar ao relatório de presença, mas adiciona as imagens processadas (quadradas com fundo desfocado) em uma estrutura de tabela de duas colunas. Inclui a legenda (`descricao`) abaixo de cada foto. Apresentar apenas as fotos com status ativo.
*   **Relatório de Relatos:** Similar ao relatório de presença, mas adiciona os relatos em uma estrutura de tabela de uma coluna. Onde serão apresentados os relatos na ordem crescente de criação. Apenas relatos ativos serão apresentados.
*   **Conversão para PDF:** Após salvar o arquivo `.odt` modificado em `static/reports`, o sistema chama o subprocesso do sistema operacional executando o LibreOffice em modo headless (`libreoffice --headless --convert-to pdf`) para gerar a versão final em PDF para o usuário baixar.

## 5. dicas
*   **Timezones:** A aplicação deve usar o horário do cliente (`datetime.now(timezone.utc).astimezone()`) para validação da janela de presença de eventos.
*   **Responsividade:** A aplicação deve ser responsiva e funcionar em diferentes tamanhos de tela. Todos os botões, cores e layouts devem ser pensados para facilitar a utilização em diferentes tamanhos de tela.
*   **Formulários:** Todos os formulários devem ter validação de campos obrigatórios. Se um campo obrigatório não for preenchido, o sistema deve retornar um erro.
*   **Mensagens de Erro:** Todas as mensagens de erro devem ser claras e objetivas, informando ao usuário o que aconteceu e como corrigir. 
*   **Interface do Usuário:** A interface do usuário deve ser intuitiva e fácil de usar. 
*   **Campo da Chave de Acesso:** O campo para a chave de acesso do usuário no sistema deve ser configurado do tipo password para habilitar opção do navegador salvar a senha para usos futuros.
*   **Cor dos botões:** usar cores intuitivas para os botões. Por exemplo, um botão de excluir deve ser vermelho, um botão de editar deve ser azul, um botão de salvar deve ser verde, etc. Seguir as classes do Bootstrap 5.
*   **Exibição dos eventos:** Os eventos devem ser apresentados em ordem decrescente de data e hora de início. Ex: Evento 1: 01/01/2026 às 11:00. Evento 2: 01/01/2026 às 10:00. Evento 3: 01/01/2026 às 09:00.
*   **Perfil do usuário**: O usuário deve ter uma tela de perfil com os dados do seu cadastro e a opção de editar os dados. Deve conter a foto de perfil, o nome, o email e o telefone. O email não pode ser editado pelo usuário. O usuário não pode alterar a chave de acesso. O usuário não pode alterar o status de sua conta (ativo/inativo).
*   **Rodapé com informações**: O rodapé deve conter informações sobre a aplicação, como o nome, a versão e o ano de lançamento. Além das informações de contato do suporte técnico.
*   **Mensagens de erro e sucesso:** As mensagens de erro e sucesso devem ser exibidas em um local visível para o usuário, de forma clara e objetiva. Seguir as classes do Bootstrap 5.
*   **Botão de sair**: O botão de sair deve estar presente em todas as páginas do sistema, de forma visível e acessível.
*   **Manter arquivo com plano de implementação:** Deve existir um arquivo no diretório docs_aa do projeto chamado `plano_de_implementacao.md` com todas as etapas necessárias para a implementação do projeto. Cada etapa deve conter: o título da etapa, uma breve descrição, os arquivos que precisam ser criados ou modificados e as etapas necessárias para a implementação da etapa. Seguir a numeração do plano de implementação. Este arquivo deve estar sempre atualizado.
*   **Manter arquivo com lista de tarefas (To-Do List):** Deve existir um arquivo no diretório docs_aa do projeto chamado `to_do_list.md` com todas as tarefas que precisam ser implementadas no projeto. Este arquivo deve estar sempre atualizado.
*   **Manter arquivo com as explicações da Aplicação em ordem cronológica:** Deve existir um arquivo no diretório docs_aa do projeto chamado `explicacoes_aplicacao.md` com todas as explicações da aplicação em ordem cronológica, desde o início até o ponto atual de desenvolvimento. Este arquivo deve estar sempre atualizado.
*   **Manter arquivo com o resumo técnico do sistema:** Deve existir um arquivo no diretório docs_aa do projeto chamado `resumo_tecnico.md` com o resumo técnico do sistema, incluindo arquitetura, funcionalidades, regras de negócio, etc. Este arquivo deve estar sempre atualizado.
*   **Manter arquivo de requirements.txt atualizado:** Deve existir um arquivo no diretório raiz do projeto chamado `requirements.txt` com todas as dependências do projeto. Este arquivo deve estar sempre atualizado.
*   **Manter arquivo shellscript para execução do projeto:** Deve existir um arquivo no diretório raiz do projeto chamado `run.sh` com todas as instruções necessárias para a execução do projeto. Este arquivo deve estar sempre atualizado. Não usar docker neste projeto.
*   **Ambiente para testes:** Deve existir um arquivo no diretório raiz do projeto chamado `.env` com todas as variáveis de ambiente necessárias para a execução do projeto. Este arquivo deve estar sempre atualizado.
*   **Criar e usar .venv:** usar o venv (virtual environment) para gerenciar as dependências do projeto. Sempre ativar o .venv antes de executar qualquer comando relacionado ao projeto.
*   **Idioma oficial:** O idioma oficial do sistema é o Português (Brasil). Nomes de variáveis e funções devem estar em inglês, usando padrão de nomes snake_case.
*   **Código limpo:** Implementar código limpo e modular. Sem comentários no código. Só comentários essenciais.