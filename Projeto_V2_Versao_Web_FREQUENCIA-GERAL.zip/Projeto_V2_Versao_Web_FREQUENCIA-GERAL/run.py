import socket
import uvicorn
from app import create_app

app = create_app()

def get_local_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        # Tenta conectar a um IP genérico para descobrir a interface de rede ativa
        s.connect(('10.255.255.255', 1))
        IP = s.getsockname()[0]
    except Exception:
        IP = '127.0.0.1'
    finally:
        s.close()
    return IP

if __name__ == "__main__":
    print(f"\\n=======================================================")
    print(f"Servidor rodando localmente em: http://127.0.0.1:5000")
    print(f"Acesso pela REDE LOCAL (Celulares/Outros PCs): http://{get_local_ip()}:5000")
    print(f"=======================================================\\n")
    uvicorn.run("run:app", host="0.0.0.0", port=5000, reload=True)
