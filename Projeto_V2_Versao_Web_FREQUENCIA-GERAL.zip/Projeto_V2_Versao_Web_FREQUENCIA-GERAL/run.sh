#!/bin/bash

source .venv/bin/activate
pip install -r requirements.txt

# Aplica as migrações (cria/atualiza tabelas se não existirem)
echo "Verificando e aplicando migrações do banco de dados..."
alembic upgrade head

echo "Iniciando a aplicação..."
python run.py
