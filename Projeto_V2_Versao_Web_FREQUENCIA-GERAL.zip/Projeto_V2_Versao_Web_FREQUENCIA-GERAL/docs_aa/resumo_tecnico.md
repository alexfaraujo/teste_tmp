# Resumo Técnico do Sistema

**Sistema de Registro de Frequência e Gestão de Eventos**

## Arquitetura
A aplicação é uma API construída usando **FastAPI** rodando com **Uvicorn**. Emprega **PostgreSQL** como banco de dados principal gerenciado com o ORM **SQLAlchemy**. O frontend é renderizado pelo servidor (Server-Side Rendering) utilizando **Jinja2** e o framework **Bootstrap 5** em arquivos HTML.

## Funcionalidades Principais
1. **Autenticação:** Ocorre através de códigos de acesso alfanuméricos de 5 dígitos (único por pessoa). Gerenciado no servidor via sessões e sem JWT persistido no banco.
2. **Gestão de Eventos:** Criação, edição e exclusão de eventos com exclusão lógica (soft delete). Apenas organizadores atrelados ao evento tem permissão de moderação.
3. **Registro de Frequência:** Presença registrada via validações temporais (dentro da janela de carga horária do evento) impedindo duplicação e concorrências no mesmo horário.
4. **Relatórios e Processamento Gráfico:** Relatórios em formato `.odt` utilizando `odfpy` exportados via `libreoffice --headless` para `.pdf`. As imagens sobem por upload e são manipuladas com redimensionamento, blur para background e marca d'água via `Pillow`.
