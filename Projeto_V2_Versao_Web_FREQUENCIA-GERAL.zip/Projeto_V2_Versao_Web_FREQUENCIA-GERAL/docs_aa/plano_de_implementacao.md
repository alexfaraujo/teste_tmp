# Plano de Implementação: Sistema de Registro de Frequência

Este plano baseia-se estritamente nas Etapas 1 e 2 do `context.md`, organizando a ordem de criação e desenvolvimento da arquitetura e estrutura de arquivos.

## Etapa 1: Configuração do Ambiente e Dependências
- **Descrição:** Preparar o ambiente virtual, controle de versão e instalar todas as dependências tecnológicas fundamentais.
- **Arquivos a serem criados/modificados:**
  - `.venv/` (criação via comando)
  - `.gitignore` (ignorar `.env`, `.venv`, `__pycache__`, etc.)
  - `.env` (variáveis de ambiente, conexão ao PostgreSQL)
  - `requirements.txt` (FastAPI, Uvicorn, SQLAlchemy, psycopg2, Jinja2, Pillow, odfpy, etc.)
  - `run.sh` (script bash para facilitar a inicialização do ambiente e uvicorn)
- **Ações Necessárias:**
  - Criar o arquivo de variáveis de ambiente.
  - Fixar as bibliotecas fundamentais em `requirements.txt`.
  - Criar script executável `run.sh` contendo ativação do venv e chamada do servidor.

## Etapa 2: Estrutura Base de Diretórios e Ponto de Entrada
- **Descrição:** Criar os diretórios do projeto e o script principal de execução do servidor web Uvicorn.
- **Arquivos a serem criados/modificados:**
  - `run.py`
  - `app/__init__.py`
  - Diretórios: `app/core/`, `app/db/`, `app/models/`, `app/schemas/`, `app/api/`, `app/services/`, `app/templates/`
  - Diretórios extras: `alembic/`, `scripts/`, `static/`, `tests/`
- **Ações Necessárias:**
  - Executar criação das pastas.
  - Desenvolver o `run.py` para fazer a inicialização do app FastAPI pelo Uvicorn.

## Etapa 3: Configurações Globais e Banco de Dados (ORM)
- **Descrição:** Configurar parâmetros globais, segurança, e criar a conexão com o banco de dados via SQLAlchemy.
- **Arquivos a serem criados/modificados:**
  - `app/core/config.py` (Carregamento de variáveis de ambiente)
  - `app/core/security.py` (Lógica de autenticação e validação)
  - `app/db/database.py` (Engine e SessionMaker)
  - `app/db/base.py` (Base declarativa)
- **Ações Necessárias:**
  - Configurar classe `Settings` usando Pydantic.
  - Instanciar a conexão PostgreSQL baseada no `.env`.
  - Configurar a inicialização do banco.

## Etapa 4: Modelos do Banco de Dados
- **Descrição:** Criar os arquivos de modelo de dados mapeados pelo SQLAlchemy.
- **Arquivos a serem criados/modificados:**
  - `app/models/pessoa.py`
  - `app/models/evento.py`
  - `app/models/presenca.py`
- **Ações Necessárias:**
  - Estruturar cada classe mapeando os atributos conforme a regra de negócios.
  - Relacionar as chaves estrangeiras.

## Etapa 5: Schemas de Validação de Dados (Pydantic)
- **Descrição:** Criar os esquemas de dados usados para conversão e validação de requisições e respostas da API.
- **Arquivos a serem criados/modificados:**
  - `app/schemas/` (Modelos Pydantic baseados nos models SQLAlchemy)
- **Ações Necessárias:**
  - Criar classes Pydantic refletindo a estrutura de entrada e saída.

## Etapa 6: Serviços e Processamentos (Lógica de Negócios)
- **Descrição:** Desenvolver as integrações com bibliotecas de terceiros (Processamento de imagens e geração de PDFs).
- **Arquivos a serem criados/modificados:**
  - `app/services/relatorio_service.py` (Lógica `odfpy` + `libreoffice`)
  - `app/services/imagem_service.py` (Lógica Pillow)
- **Ações Necessárias:**
  - Escrever os serviços isolando a manipulação de imagens (redimensionamento, blur, marca d'água).
  - Escrever o gerador de relatórios (leitura de template `.odt` e geração de `.pdf`).

## Etapa 7: Rotas da API (Endpoints)
- **Descrição:** Estruturar as rotas do FastAPI mapeando para os recursos do banco e templates.
- **Arquivos a serem criados/modificados:**
  - `app/api/routes_auth.py`
  - `app/api/routes_eventos.py`
  - `app/api/routes_presenca.py`
- **Ações Necessárias:**
  - Definir as rotas chamando templates Jinja ou retornando JSON (conforme o uso no Frontend).
  - Incluir a lógica de autenticação nas rotas privadas.

## Etapa 8: Templates e Arquivos Estáticos
- **Descrição:** Criação das páginas HTML com Jinja2 e Bootstrap 5.
- **Arquivos a serem criados/modificados:**
  - `app/templates/` (Layouts base, login, painéis, visualizações de eventos).
  - `static/` (Arquivos estáticos base como CSS, imagens padronizadas e ícones).
- **Ações Necessárias:**
  - Desenvolver o layout web focado em responsividade.

## Etapa 9: Migrações de Banco de Dados e Testes
- **Descrição:** Estruturação dos utilitários de migração Alembic e os testes automatizados.
- **Arquivos a serem criados/modificados:**
  - `alembic/` (Diretório de env.py e revisões do alembic)
  - `tests/unit/` e `tests/integration/`
- **Ações Necessárias:**
  - Inicializar alembic.
  - Implementar testes iniciais para garantir a sanidade da API.

## Etapa 10: Finalizar Autenticação e Layout Base
- **Descrição:** Implementar a lógica real de sessão e a tela de perfil do usuário.
- **Ações Necessárias:**
  - Ajustar `routes_auth.py` para salvar sessão vinculada ao `pessoa_id`.
  - Criar `app/templates/perfil.html` focado na exibição dos dados do usuário logado.

## Etapa 11: Gestão de Eventos (Backend e Frontend)
- **Descrição:** Implementação de endpoints e telas para listagem, criação, edição e exclusão (lógica) de eventos.
- **Ações Necessárias:**
  - Garantir que a exclusão falhe se houver presenças.
  - Restringir edição/exclusão apenas para organizadores.

## Etapa 12: Registro de Frequência
- **Descrição:** Implementação da regra de negócios de validação de janela de horário de eventos.
- **Ações Necessárias:**
  - Validar se o horário atual está dentro da carga horária do evento + tolerância de 1 hora.
  - Bloquear registros sobrepostos e duplicados.

## Etapa 13: Upload e Processamento de Imagens e Relatos
- **Descrição:** Lógica de uploads de fotos com limitação de 10 fotos por evento e upload de relato único.
- **Ações Necessárias:**
  - Processar as fotos com Pillow para criar um thumbnail quadrado (1000x1000) com blur de fundo e marca d'água.
  - Validar as janelas de 24 horas para relato e exclusão própria pelo autor, e 72 horas para exclusão pelo organizador.

## Etapa 14: Painel do Organizador e Geração de Documentos
- **Descrição:** Visualização de todos os registros (fotos, presenças e relatos) do evento e geração de PDFs.
- **Ações Necessárias:**
  - Integração do headless libreoffice (`odfpy`) para preencher e gerar PDFs dos relatórios.
  - Tela do Painel do Organizador.
