# To-Do List

- [x] Aprovação do plano de implementação pelo usuário.
- [x] Etapa 1: Criar .env, .gitignore, requirements.txt, e run.sh.
- [x] Etapa 2: Estruturar diretórios (app, static, alembic, tests) e criar run.py e __init__.py.
- [x] Etapa 3: Criar arquivos base de db (config.py, security.py, database.py, base.py).
- [x] Etapa 4: Criar os Models do banco de dados (pessoa.py, evento.py, presenca.py).
- [x] Etapa 5: Criar os schemas pydantic para a validação.
- [x] Etapa 6: Criar services para imagem_service.py e relatorio_service.py.
- [x] Etapa 7: Criar rotas do FastAPI (routes_auth.py, routes_eventos.py, routes_presenca.py).
- [x] Etapa 8: Estruturar a renderização em Jinja2 dentro de templates/.
- [x] Etapa 9: Configurar Alembic para as migrações do PostgreSQL.
- [x] Etapa 10: Finalizar Autenticação e Layout Base.
- [x] Etapa 11: Gestão de Eventos (Backend e Frontend).
- [x] Etapa 12: Registro de Frequência.
- [x] Etapa 13: Upload e Processamento de Imagens e Relatos.
- [x] Etapa 14: Painel do Organizador e Geração de Documentos.
