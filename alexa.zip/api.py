from fastapi import FastAPI, HTTPException, Header, Depends
from pydantic import BaseModel
from typing import Optional
import os
from dotenv import load_dotenv
from alexa_speaker import AlexaSpeaker

# Load environment variables
load_dotenv()

app = FastAPI(title="Alexa Voice Monkey API", version="1.0.0")

# Security: API Key Dependency
API_KEY_NAME = "X-API-KEY"
APP_API_KEY = os.getenv("APP_API_KEY")

if not APP_API_KEY:
    raise RuntimeError("APP_API_KEY not found in environment variables. Please set it in .env")

async def verify_api_key(x_api_key: str = Header(...)):
    if x_api_key != APP_API_KEY:
        raise HTTPException(status_code=403, detail="Invalid API Key")
    return x_api_key

# Request Model
class SpeakRequest(BaseModel):
    text: str
    device: Optional[str] = None # Optional, defaults to env var if not provided
    token: Optional[str] = None # Optional, defaults to env var if not provided

@app.post("/speak", dependencies=[Depends(verify_api_key)])
async def speak_to_alexa(request: SpeakRequest):
    """
    Send a text-to-speech command to an Alexa device.
    Requires X-API-KEY header.
    """
    # 1. Determine Credentials
    # Use request token if provided, else fallback to env var
    token = request.token if request.token else os.getenv("VOICE_MONKEY_TOKEN")
    # Use request device if provided, else fallback to env var
    target_device = request.device if request.device else os.getenv("VOICE_MONKEY_DEVICE")

    if not token or not target_device:
        raise HTTPException(status_code=400, detail="Missing credentials. Please provide 'token' and 'device' in the request body, or set defaults in .env.")

    # 2. Initialize Speaker
    try:
        alexa = AlexaSpeaker(token, target_device)
        response = alexa.speak(request.text)
        
        if response.status_code == 200:
            return {"status": "success", "message": "Request sent to Alexa", "device": target_device}
        else:
            raise HTTPException(status_code=response.status_code, detail=f"Voice Monkey API Error: {response.text}")

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/health")
async def health_check():
    return {"status": "ok"}
