import requests
import urllib.parse

class AlexaSpeaker:
    """
    A class to interact with the Voice Monkey API v2 to control Alexa devices.
    """
    API_URL = "https://api-v2.voicemonkey.io/announcement"
    FLOW_URL = "https://api-v2.voicemonkey.io/flow/trigger"

    def __init__(self, token: str, device: str):
        """
        Initialize the AlexaSpeaker.

        Args:
            token (str): The Voice Monkey API token (API v2).
            device (str): The name of the device to target (or group).
        """
        self.token = token
        self.device = device

    def speak(self, text: str) -> requests.Response:
        """
        Send a text-to-speech announcement to the configured Alexa device.

        Args:
            text (str): The text to be spoken by Alexa.

        Returns:
            requests.Response: The response object from the API call.
        """
        payload = {
            "token": self.token,
            "device": self.device,
            "text": text
        }
        
        try:
            # Try sending via GET request which is widely supported for this API
            params = payload
            response = requests.get(self.API_URL, params=params)
            response.raise_for_status()
            return response
        except requests.exceptions.RequestException as e:
            print(f"Error sending announcement to Voice Monkey: {e}")
            raise

    def trigger_flow(self, flow_id: str) -> requests.Response:
        """
        Trigger a Voice Monkey flow.

        Args:
            flow_id (str): The ID of the flow to trigger.

        Returns:
            requests.Response: The response object from the API call.
        """
        payload = {
            "token": self.token,
            "flow": flow_id
        }

        try:
            response = requests.post(self.FLOW_URL, data=payload)
            response.raise_for_status()
            return response
        except requests.exceptions.RequestException as e:
            print(f"Error triggering flow: {e}")
            raise
