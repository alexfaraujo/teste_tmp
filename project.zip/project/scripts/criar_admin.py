import os
import sys

# Adiciona o diretório raiz do projeto ao PYTHONPATH
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, project_root)

from app import create_app, db
from app.models.usuario import Usuario

def main():
    app = create_app()
    
    with app.app_context():
        # Criar as tabelas
        db.create_all()
        
        # Criar usuário admin se não existir
        if not Usuario.query.filter_by(username='admin').first():
            admin = Usuario(username='admin')
            admin.set_password('senha123')
            db.session.add(admin)
            db.session.commit()
            print('Usuário admin criado com sucesso!')
        else:
            print('Usuário admin já existe!')

if __name__ == '__main__':
    main() 