from flask import Flask, redirect, url_for, request

app = Flask(__name__)

k = 'axdfFG%$vf01009287jkfkjdhdh$cdasdkfhds'
@app.route("/parte2")
def download():
    if request.args.get('k') == k:
        return redirect(url_for('static', filename='project.zip'))
    else:
        return 'Its Working!'

if __name__ == '__main__':
  app.run(debug=False, host='0.0.0.0', port=2065) # Executa a aplicação
