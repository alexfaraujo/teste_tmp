from flask import Blueprint, render_template, url_for
from app.models.noticia import Noticia
from datetime import datetime

bp = Blueprint('public', __name__)

@bp.route('/')
def index():
    agora = datetime.utcnow()
    noticias_ativas = Noticia.query.filter(
        Noticia.data_inicio <= agora,
        Noticia.data_fim >= agora
    ).order_by(Noticia.data_inicio.desc()).all()
    
    imagem_padrao = url_for('static', filename='imgs/ifms-tl-marca-2015.png')
    return render_template('public/index.html', noticias=noticias_ativas, imagem_padrao=imagem_padrao) 