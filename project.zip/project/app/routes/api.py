from flask import Blueprint, jsonify, request
from app.models.noticia import Noticia
from datetime import datetime
from app import db

bp = Blueprint('api', __name__, url_prefix='/api')

@bp.route('/noticias', methods=['GET'])
def listar_noticias():
    noticias_ativas = Noticia.query.filter(
        Noticia.data_inicio <= datetime.utcnow(),
        Noticia.data_fim >= datetime.utcnow()
    ).order_by(Noticia.data_inicio.desc()).all()
    
    return jsonify([{
        'id': n.id,
        'titulo': n.titulo,
        'conteudo': n.conteudo,
        'imagem': n.imagem,
        'data_inicio': n.data_inicio.isoformat(),
        'data_fim': n.data_fim.isoformat()
    } for n in noticias_ativas])

@bp.route('/noticias/<int:id>', methods=['GET'])
def obter_noticia(id):
    noticia = Noticia.query.get_or_404(id)
    return jsonify({
        'id': noticia.id,
        'titulo': noticia.titulo,
        'conteudo': noticia.conteudo,
        'imagem': noticia.imagem,
        'data_inicio': noticia.data_inicio.isoformat(),
        'data_fim': noticia.data_fim.isoformat()
    }) 