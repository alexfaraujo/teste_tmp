#!/bin/bash

# Configurações padrão
HOST=${HOST:-0.0.0.0}
PORT=${PORT:-2057}

# Ativar ambiente virtual (se estiver usando)
python3 -m venv ../.venv
source ../.venv/bin/activate

# Instalar dependências
pip install -r requirements.txt

# Executar migrações do banco de dados
flask db upgrade

# Iniciar o Gunicorn
echo "Iniciando servidor em :"
#HOST= PORT= gunicorn -c gunicorn_config.py "app:create_app()"
python run.py
