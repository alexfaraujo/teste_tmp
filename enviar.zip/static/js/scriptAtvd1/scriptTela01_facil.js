function returnToLevelSelection(level, stars) {
    localStorage.setItem(`${level}Stars`, stars);
    window.location.href = '../../templates/atividade1/niveis_atvd1.html?${level}=${stars}';
}


// Função para iniciar um novo jogo
function startNewGame() {
    // Limpar a tabela 1
    var table1 = document.getElementById("table1");
    table1.innerHTML = "";

    colorizeTable();
    // Redefinir a barra de progresso
    resetProgressBars();

    function colorizeTable() {
        // Limpar a tabela 1
        var table1 = document.getElementById("table1");
        table1.innerHTML = "";

        // Criando a tabela 1 
        var row = document.createElement("div");
        row.classList.add("row");
        for (var j = 1; j <= 10; j++) {
            var cell = document.createElement("div");
            cell.classList.add("cell");
            cell.innerHTML = j;
            row.appendChild(cell);
        }
        table1.appendChild(row);
    
        // Criar e colorir a nova tabela (apenas 1 linha)
        var table2 = document.createElement("div");
        var row = document.createElement("div");
        row.classList.add("row");
        var sequenceCount = 0; // Contador para controlar sequência
        for (var j = 1; j <= 10; j++) {
            var cell = document.createElement("div");
            cell.classList.add("cell");
            var randomNum = Math.round(Math.random());
            
            // Controle de sequência (máximo 2 números seguidos)
            if (randomNum == 1) {
                sequenceCount++;
                if (sequenceCount > 2) {
                    randomNum = 0;
                    sequenceCount = 0;
                }
            } else {
                sequenceCount = 0;
            }
            
            cell.innerHTML = randomNum;
            row.appendChild(cell);
        }
        table2.appendChild(row);
    
        // Colorindo as células da tabela 1 de acordo com os valores da tabela 2
        var cells1 = document.querySelectorAll("#table1 .cell");
        var cells2 = table2.querySelectorAll(".cell");
        for (var i = 0; i < cells1.length; i++) {
            if (cells2[i].innerHTML == "1") {
                cells1[i].classList.add("blue");
                cells1[i].innerHTML = "";
                cells1[i].contentEditable = true;
    
                // Adicionando o event listener para permitir apenas números
                cells1[i].addEventListener("keydown", function (event) {
                    if (!(event.key >= "0" && event.key <= "9") && event.keyCode !== 8 && event.keyCode !== 46) {
                        event.preventDefault();
                    }
                });
            } else {
                cells1[i].classList.remove("blue");
                cells1[i].innerHTML = i + 1;
                cells1[i].contentEditable = false;
            }
        }

        setupEnterNavigation();
    }

    function resetProgressBars() {
        var progressBar = document.getElementById("progress-bar");
        var progressPercent = document.getElementById("progress-percent");
        var errorProgressBar = document.getElementById("error-progress-bar");
        var errorProgressPercent = document.getElementById("error-progress-percent");
        var starProgressBar = document.getElementById("star-progress-bar");
        var starProgressPercent = document.getElementById("star-progress-percent");

        progressBar.value = 0;
        progressPercent.textContent = "0%";
        errorProgressBar.value = 0;
        errorProgressPercent.textContent = "0%";
        starProgressBar.value = 0;
        starProgressPercent.textContent = "";
    }

    function setupEnterNavigation() {
        var cells = document.querySelectorAll(".cell");
        cells.forEach(function(cell) {
            cell.addEventListener("keydown", function(event) {
                if (event.key === "Enter") {
                    event.preventDefault();
                    var nextCellIndex = Array.prototype.indexOf.call(cells, cell) + 1;
                    var foundEditable = false;
                    while (nextCellIndex < cells.length && !foundEditable) {
                        if (cells[nextCellIndex].getAttribute("contenteditable") === "true") {
                            foundEditable = true;
                            cells[nextCellIndex].focus();
                        }
                        else {
                            nextCellIndex++;
                        }
                    }
                }
            });
        });
    }
}

// Obtendo o botão "Novo Jogo" e adicionando um evento de clique
var newGameButton = document.getElementById("new-game-button");
newGameButton.addEventListener("click", startNewGame);

function verifyTable() {
    // Verifica se todas as células estão preenchidas
    var cells1 = document.querySelectorAll("#table1 .cell");
    var isTableComplete = true;
    for (var i = 0; i < cells1.length; i++) {
        if (cells1[i].innerHTML === "") {
            isTableComplete = false;
            break;
        }
    }

    if (!isTableComplete) {
        modal.style.display = "block";
        return;
    }

    // Verifica se todas as células já estão travadas
    var allCellsLocked = true;
    cells1.forEach(function(cell) {
        if (cell.contentEditable === "true") {
            allCellsLocked = false;
        }
    });

    if (allCellsLocked) {
        return;
    }

    cells1.forEach(function (cell) {
        cell.classList.remove("correct", "incorrect", "animated", "flash", "pulse", "border-danger", "border-success", "cell-correct", "cell-incorrect");
    });

    var isTableCorrect = true;
    for (var i = 0; i < cells1.length; i++) {
        var cell1Value = cells1[i].innerHTML;
        var cell1CorrectValue = i + 1;

        if (cells1[i].getAttribute('contenteditable') === "true") {
            if (cell1Value == cell1CorrectValue) {
                cells1[i].classList.remove("cell-incorrect");
                cells1[i].classList.add("cell-correct", "animated", "flash", "border-success");
            } else {
                cells1[i].classList.remove("cell-correct");
                cells1[i].classList.add("cell-incorrect", "animated", "pulse", "border-danger");
                isTableCorrect = false;
            }
        }
    }

    if (isTableCorrect) {
        modal3.style.display = "block";
    } else {
        modal2.style.display = "block";
    }
    
    // Atualiza a barra de progresso
    updateProgressBar();
}

function updateProgressBar() {
    var cells1 = document.querySelectorAll("#table1 .cell");
    var totalCells = cells1.length;
    var correctCells = 0;
    var editableCells = 0;
    var isTableComplete = true;
    var matriculaElement = document.getElementById("matricula");
    var matricula = matriculaElement.getAttribute("data-matricula");

    for (var i = 0; i < cells1.length; i++) {
        if (cells1[i].innerHTML === "") {
            isTableComplete = false;
            break;
        }
    }

    if (!isTableComplete) return;

    for (var i = 0; i < totalCells; i++) {
        var cell = cells1[i];
        if (cell.contentEditable === "true") {
            editableCells++;
            var cellValue = cell.innerHTML;
            var cellCorrectValue = i + 1;

            if (cellValue == cellCorrectValue) {
                correctCells++;
            }
        }
    }

    var percentage = (correctCells / editableCells) * 100;
    var errorPercentage = ((editableCells - correctCells) / editableCells) * 100;

    var progressBar = document.getElementById("progress-bar");
    var progressPercent = document.getElementById("progress-percent");
    var errorProgressBar = document.getElementById("error-progress-bar");
    var errorProgressPercent = document.getElementById("error-progress-percent");

    progressBar.value = percentage;
    progressPercent.textContent = percentage.toFixed(0) + "%";
    errorProgressBar.value = errorPercentage;
    errorProgressPercent.textContent = errorPercentage.toFixed(0) + "%";
    updateStarProgressBar(percentage);

    // Enviando as informações para o servidor
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "/inserir_dados", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            console.log(xhr.responseText);
        }
    };
    
    var currentTime = new Date();
    var formattedDate = currentTime.toISOString().split('T')[0];
    var formattedTime = currentTime.toTimeString().split(' ')[0];
    var activity = "Sequência numérica (Fácil)";
    
    var data = "cod=" + matricula + "&data=" + formattedDate + "&hora=" + formattedTime +
               "&atividade=" + activity + "&qtd_corretas=" + correctCells + 
               "&qtd_incorretas=" + (editableCells - correctCells) + 
               "&porc_acertos=" + Math.round(percentage);
    
    xhr.send(data);
    
    // Travando a edição das células
    cells1.forEach(function(cell) {
        cell.contentEditable = false;
    });

    // Retorna o número de estrelas para atualizar o nível
    return updateStarProgressBar(percentage);
}

function updateStarProgressBar(percentage) {
    var starProgressBar = document.getElementById("star-progress-bar");
    var starProgressPercent = document.getElementById("star-progress-percent");
    var gifElement = document.getElementById("gif-element");

    var starsValue = Math.ceil((percentage / 100) * 5);

    if(starsValue == 5 && percentage != 100) {
        starsValue--;
    }

    starProgressBar.value = starsValue;
    starProgressPercent.textContent = starsValue;

    var gifSrc;
    if (starsValue === 1) {
        gifSrc = "https://media.tenor.com/7LoMkEwSwcQAAAAi/star.gif";
    } else if (starsValue === 2) {
        gifSrc = "https://media.tenor.com/EIVs78DyGHsAAAAi/star.gif";
    } else if (starsValue === 3) {
        gifSrc = "https://media.tenor.com/R_nXqV_bIf8AAAAi/dtar.gif";
    } else if (starsValue === 4) {
        gifSrc = "https://media.tenor.com/_UE6DkuikesAAAAi/star.gif";
    } else if(starsValue == 0) {
        gifElement.src = "";
    }

    gifElement.src = gifSrc;

    
    //para subir de nivel
    if (starsValue === 5 && percentage === 100) {
        setTimeout(() => {
            returnToLevelSelection('facil', 5);
        }, 4000); // Delay para mostrar a animação
    }

    return starsValue;
}

// função para voltar à pagina de niveis com estrelas
function returnToLevelSelection(level, stars) 
{
    localStorage.setItem(`${level}Stars`, stars);
    window.location.href = `../../templates/atividade1/niveis_atvd1.html?${level}=${stars}`;
}


// --------------------MODAL---------------------------------
var modal = document.getElementById("myModal");
var modal3 = document.getElementById("myModal3");
var modal2 = document.getElementById("myModal2");

var span = document.getElementsByClassName("close")[0];
var span3 = document.getElementsByClassName("close3")[0];
var span2 = document.getElementsByClassName("close2")[0];

span.onclick = function() { modal.style.display = "none"; }
span3.onclick = function() { modal3.style.display = "none"; }
span2.onclick = function() { modal2.style.display = "none"; }

window.onclick = function(event) {
    if (event.target == modal) modal.style.display = "none";
    if (event.target == modal3) modal3.style.display = "none";
    if (event.target == modal2) modal2.style.display = "none";
}
// --------------------FIM MODAL---------------------------------

// ---------------------- audio ---------------------------------
const playButton = document.getElementById('playButton');
const audio = document.getElementById('audio');

playButton.addEventListener('click', function () {
    audio.play();
});