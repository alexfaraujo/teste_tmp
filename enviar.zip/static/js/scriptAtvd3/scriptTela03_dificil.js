var generatedNumbers = [];
var modal = document.getElementById("myModal");
var modal2 = document.getElementById("myModal2");
var modal3 = document.getElementById("myModal3")

function returnToLevelSelection(level, stars) {
    localStorage.setItem(`${level}Stars`, stars);
    window.location.href = `../../templates/atividade3/niveis_atvd3.html?${level}=${stars}`;
}

// Função para permitir apenas números
function allowNumbersOnly(event) {
    var key = event.key;
    // Verifica se a tecla é um número ou uma tecla de controle (como Backspace ou Delete)
    if (!(key >= "0" && key <= "9") && event.keyCode !== 8 && event.keyCode !== 46) {
        event.preventDefault();
    }
}

// Função para iniciar um novo jogo
function startNewGame() 
{
    var table1 = document.getElementById("table1");
    table1.innerHTML = "";
    generatedNumbers = [];

    // Criar cabeçalhos da tabela
    let headerRow = document.createElement("div");
    headerRow.className = "row header-row";

    let headerNumber = document.createElement("div");
    headerNumber.className = "cell header-cell";
    headerNumber.textContent = "Número";
    headerRow.appendChild(headerNumber);

    let headerCentena = document.createElement("div");
    headerCentena.className = "cell header-cell";
    headerCentena.textContent = "Centena";
    headerRow.appendChild(headerCentena);

    let headerDezena = document.createElement("div");
    headerDezena.className = "cell header-cell";
    headerDezena.textContent = "Dezena";
    headerRow.appendChild(headerDezena);

    let headerUnidade = document.createElement("div");
    headerUnidade.className = "cell header-cell";
    headerUnidade.textContent = "Unidade";
    headerRow.appendChild(headerUnidade);

    table1.appendChild(headerRow);

    var numerosSorteados = []; 
    function gerarNumeroUnico() 
    {
        var numero;
        do {
            numero = Math.floor(Math.random() * 999) + 1;
        } while (numerosSorteados.includes(numero));
        
        numerosSorteados.push(numero);
        return numero;
    }

    for (let i = 0; i < 7; i++) {
        let randomNumber = gerarNumeroUnico();
        generatedNumbers.push(randomNumber);

        let row = document.createElement("div");
        row.className = "row";

        let cellNumber = document.createElement("div");
        cellNumber.className = "cell number";
        cellNumber.textContent = randomNumber;
        row.appendChild(cellNumber);

        // Criar células para centena, dezena e unidade
        for (let j = 1; j <= 3; j++) {
            let cell = document.createElement("div");
            cell.className = "cell input-cell";
            cell.setAttribute("contenteditable", "true");
            cell.dataset.position = j;

            // Adicionar evento para permitir apenas números
            cell.addEventListener("keydown", allowNumbersOnly);

            // Se a célula é editável, adicione o evento
            if (j > 0) {
                cell.classList.add("blue");
                cell.innerHTML = "";
                cell.contentEditable = true;
                cell.focus();
                cell.addEventListener("keydown", allowNumbersOnly); // Adiciona o evento de permitir apenas números
            }

            row.appendChild(cell);
        }

        table1.appendChild(row);
    }

    // ação tab no botão enter
    var cells = document.querySelectorAll(".cell");
    // Adiciona um listener para o evento "keydown" em cada célula
    cells.forEach(function(cell) {
        cell.addEventListener("keydown", function(event) {
            if (event.key === "Enter") {
                event.preventDefault(); // Previne o comportamento padrão de saltar para a próxima linha
                var nextCellIndex = Array.prototype.indexOf.call(cells, cell) + 1; // Obtém o índice da próxima célula
                var foundEditable = false; // Inicializa o flag para indicar se a próxima célula editável foi encontrada
                while (nextCellIndex < cells.length && !foundEditable) {
                    if (cells[nextCellIndex].getAttribute("contenteditable") === "true") {
                        foundEditable = true; // Muda o valor do flag para true
                        cells[nextCellIndex].focus(); // Foca no próximo elemento
                    } else {
                        nextCellIndex++; // Passa para a próxima célula
                    }
                }
            }
        });
    });

    // Inicializar progresso como 0
    updateProgress(0, 0);
    resetStarProgress();
}

// Obtendo o botão "Novo Jogo" e adicionando um evento de clique
document.getElementById("new-game-button").addEventListener("click", startNewGame);
document.getElementById("verify-button").addEventListener("click", verifyTable);


// Função para verificar se todos os campos estão preenchidos
function checkIfTableComplete() {
    var cells = document.querySelectorAll("#table1 .input-cell");
    for (var i = 0; i < cells.length; i++) {
        if (cells[i].textContent.trim() === "") {
            modal.style.display = "block"; // Exibe o modal de aviso
            return false;
        }
    }
    return true;
}

// Função para verificar as respostas
function verifyTable() {
    if (!checkIfTableComplete()) {
        return;
    }

    let table1 = document.getElementById("table1");
    let rows = table1.getElementsByClassName("row");
    let correctCount = 0;
    let totalCount = generatedNumbers.length * 3;

    for (let i = 1; i < rows.length; i++) {
        let number = generatedNumbers[i - 1];
        let row = rows[i];

        let centenas = Math.floor(number / 100);
        let dezenas = Math.floor((number % 100) / 10);
        let unidades = number % 10;

        let expectedValues = [centenas, dezenas, unidades];

        let cells = row.getElementsByClassName("input-cell");
        for (let j = 0; j < cells.length; j++) {
            let cell = cells[j];
            let userValue = parseInt(cell.textContent.trim(), 10);

            if (userValue === expectedValues[j]) {
                cell.classList.add("cell-correct");
                cell.classList.remove("cell-incorrect");
                correctCount++;
            } else {
                cell.classList.add("cell-incorrect");
                cell.classList.remove("cell-correct");
            }
        }
    }

    let incorrectCount = totalCount - correctCount;
    updateProgress(correctCount, incorrectCount);
    

     // Verifica se acertou tudo (100% de acertos)
    if (correctCount === totalCount) {
        modal3.style.display = "block";
        setTimeout(() => {
            returnToLevelSelection('dificil', 5);
        }, 4000);   
    }
}


// Atualizar barra de progresso
function updateProgress(correct, incorrect) {
    let total = correct + incorrect;
    let correctPercent = Math.round((correct / total) * 100) || 0;
    let incorrectPercent = Math.round((incorrect / total) * 100) || 0;

    document.getElementById("progress-bar").value = correctPercent;
    document.getElementById("progress-percent").textContent = correctPercent + "%";

    document.getElementById("error-progress-bar").value = incorrectPercent;
    document.getElementById("error-progress-percent").textContent = incorrectPercent + "%";

    updateStarProgress(correct);
}

function updateStarProgress(correct) {
    let starBar = document.getElementById("star-progress-bar");
    let totalEditableCells = generatedNumbers.length * 3;
    let starCount = Math.round((correct / totalEditableCells) * 5);
    
    if(starCount == 5 && correct != totalEditableCells) {
        starCount = 4;
    }
    
    starBar.value = starCount;
    document.getElementById("star-progress-percent").textContent = starCount;

    // Configura o GIF correspondente
    let gifElement = document.getElementById("gif-element");
    if (gifElement) {
        if (starCount === 5) {
            gifElement.src = "https://media.tenor.com/WBya4tWP0agAAAAi/star.gif";
        } else if (starCount === 4) {
            gifElement.src = "https://media.tenor.com/_UE6DkuikesAAAAi/star.gif";
        } else if (starCount === 3) {
            gifElement.src = "https://media.tenor.com/R_nXqV_bIf8AAAAi/dtar.gif";
        } else if (starCount === 2) {
            gifElement.src = "https://media.tenor.com/EIVs78DyGHsAAAAi/star.gif";
        } else if (starCount === 1) {
            gifElement.src = "https://media.tenor.com/7LoMkEwSwcQAAAAi/star.gif";
        } else if(starCount === 0)
        {
            gifElement.src = "";
        }
    }

    return starCount;
}
 ////FECHAMENTO DO MODAIS
// Para o primeiro modal
document.getElementsByClassName("close")[0].onclick = function() {
    modal.style.display = "none";
}

// Para o segundo modal
document.getElementsByClassName("close2")[0].onclick = function() {
    modal2.style.display = "none";
}

// Para o terceiro modal
document.getElementsByClassName("close3")[0].onclick = function() {
    modal3.style.display = "none";
}
 ////FIM DO FECHAMENTO DO MODAIS


// Resetar progresso de estrelas
function resetStarProgress() {
    document.getElementById("star-progress-bar").value = 0;
    document.getElementById("star-progress-percent").textContent = "0";
}

// ---------------------- audio ---------------------------------
const playButton = document.getElementById('playButton');
const audio = document.getElementById('audio');

playButton.addEventListener('click', function () {
    audio.play();
});
