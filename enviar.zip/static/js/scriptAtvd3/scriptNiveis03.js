document.addEventListener('DOMContentLoaded', function() {
    const urlParams = new URLSearchParams(window.location.search);
    let updated = false;
    
    ['facil', 'intermediario', 'dificil'].forEach(nivel => {
        if (urlParams.has(nivel)) {
            const newStars = Math.min(5, Math.max(0, parseInt(urlParams.get(nivel)) || 0));
            const currentStars = parseInt(localStorage.getItem(`${nivel}Stars`)) || 0;
            
            // Sempre mantém o valor mais alto de estrelas
            if (newStars > currentStars) {
                localStorage.setItem(`${nivel}Stars`, newStars);
                updated = true;
            }
        }
    });
    
    updateAllProgress();
});

function updateAllProgress() {
    ['facil', 'intermediario', 'dificil'].forEach(level => {
        const stars = parseInt(localStorage.getItem(`${level}Stars`)) || 0;
        updateProgress(level, stars);
    });
    
    if (parseInt(localStorage.getItem('facilStars')) >= 5) setupLevelButton('intermediario');
    if (parseInt(localStorage.getItem('intermediarioStars')) >= 5) setupLevelButton('dificil');
    
    setupLevelButton('facil');
}

function updateProgress(level, stars) {
    const progressBar = document.getElementById(`${level}-progress`);
    const starsContainer = document.getElementById(`${level}-stars`);
    
    if (progressBar) progressBar.value = stars;
    
    if (starsContainer) {
        // Limpa o conteúdo anterior
        starsContainer.innerHTML = '';
        
        // Cria o elemento do ícone
        const icon = document.createElement('i');
        
        if (stars >= 5) {
            // Ícone de concluído com animação (pulse do Font Awesome)
            icon.className = 'fas fa-check-circle fa-beat-fade';
            icon.style.color = '#4CAF50'; // Verde
            icon.title = 'Nível concluído!';
        } else {
            icon.className = 'fas fa-spinner fa-pulse';
            icon.style.color = '#FFC107'; 
            icon.title = 'Em progresso...';
        }
        
        // Adiciona o ícone ao container
        starsContainer.appendChild(icon);
        
    }
}

function setupLevelButton(level) {
    const button = document.getElementById(`${level}-button`);
    const lock = document.getElementById(`${level}-lock`);
    
    if (button) {
        button.disabled = false;
        button.textContent = 'Jogar';
        button.onclick = function() {
            window.location.href = getLevelUrl(level);
        };
    }
    if (lock) lock.style.display = 'none';
}

function getLevelUrl(level) {
    const matricula = "{{ matricula }}";
    return `../../templates/atividade3/atividade3_${level}.html?matricula=${matricula}`;
}