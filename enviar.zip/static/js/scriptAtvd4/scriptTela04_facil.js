var generatedNumbers = [];
var correctAnswers = [];
var modal = document.getElementById("myModal");
var modal2 = document.getElementById("myModal2");
var modal3 = document.getElementById("myModal3");

function returnToLevelSelection(level, stars) {
    localStorage.setItem(`${level}Stars`, stars);
    window.location.href = '../niveis_atvd4.html?${level}=${stars}';
}


// Função para permitir apenas números
function allowNumbersOnly(event) {
    var key = event.key;
    if (!(key >= "0" && key <= "9") && event.keyCode !== 8 && event.keyCode !== 46) {
        event.preventDefault();
    }
}

// Função para iniciar um novo jogo
function startNewGame() 
{
    var table1 = document.getElementById("table1");
    table1.innerHTML = "";
    table1.style.display = "flex";
    table1.style.flexDirection = "column";
    table1.style.gap = "20px";
    
    generatedNumbers = [];
    correctAnswers = [];

    // Cria duas linhas (row) para as subtabelas
    let row1 = document.createElement("div");
    row1.style.display = "flex";
    row1.style.justifyContent = "center";
    row1.style.gap = "30px";
    
    let row2 = document.createElement("div");
    row2.style.display = "flex";
    row2.style.justifyContent = "center";
    row2.style.gap = "30px";

    let paresSorteados = new Set(); 
    function gerarParUnico() 
    {
        let novoNum1, novoNum2;
        let parKey;
    
        do {
            novoNum1 = Math.floor(Math.random() * 20) + 10; 
            novoNum2 = Math.floor(Math.random() * 9) + 1; 
            parKey = `${novoNum1},${novoNum2}`; 
        } while (paresSorteados.has(parKey)); 
    
        paresSorteados.add(parKey); 
    
         
        if (paresSorteados.size > 10) { 
            paresSorteados = new Set(); 
        }
    
        return { num1: novoNum1, num2: novoNum2 };
    }

    for (let i = 0; i < 6; i++) {
        let { num1, num2 } = gerarParUnico();  

        // Separa os dígitos
        let dezena = Math.floor(num1 / 10);
        let unidade = num1 % 10;

        generatedNumbers.push([num1, num2]);
        correctAnswers.push(num1 + num2); 

        // Container da operação (vertical)
        let operationContainer = document.createElement("div");
        operationContainer.style.display = "flex";
        operationContainer.style.flexDirection = "column";
        operationContainer.style.alignItems = "center";
        operationContainer.style.gap = "5px";

        // --- LINHA 1: TÍTULOS ---
        let titlesRow = document.createElement("div");
        titlesRow.style.display = "flex";
        titlesRow.style.gap = "10px";

        let dezenaTitle = document.createElement("div");
        dezenaTitle.className = "cell";
        dezenaTitle.textContent = "Dezena";
        dezenaTitle.style.fontWeight = "bold";

        let unidadeTitle = document.createElement("div");
        unidadeTitle.className = "cell";
        unidadeTitle.textContent = "Unidade";
        unidadeTitle.style.fontWeight = "bold";

        titlesRow.appendChild(dezenaTitle);
        titlesRow.appendChild(unidadeTitle);
        operationContainer.appendChild(titlesRow);

        // --- LINHA 2: DÍGITOS ---
        let digitsRow = document.createElement("div");
        digitsRow.style.display = "flex";
        digitsRow.style.gap = "10px";

        let dezenaCell = document.createElement("div");
        dezenaCell.className = "cell";
        dezenaCell.textContent = dezena;

        let unidadeCell = document.createElement("div");
        unidadeCell.className = "cell";
        unidadeCell.textContent = unidade;

        digitsRow.appendChild(dezenaCell);
        digitsRow.appendChild(unidadeCell);
        operationContainer.appendChild(digitsRow);

        // --- LINHA 3: OPERADOR ---
        let operatorRow = document.createElement("div");
        operatorRow.style.display = "flex";
        operatorRow.style.alignItems = "center";
        operatorRow.style.gap = "10px";

        let plusCell = document.createElement("div"); 
        plusCell.className = "cell";
        plusCell.textContent = "+";
        plusCell.style.fontWeight = "bold";

        let secondNumCell = document.createElement("div");
        secondNumCell.className = "cell";
        secondNumCell.textContent = num2;

        operatorRow.appendChild(plusCell);
        operatorRow.appendChild(secondNumCell);
        operationContainer.appendChild(operatorRow);

        // --- LINHA 4: RESULTADO ---
        let resultCell = document.createElement("div");
        resultCell.className = "cell input-cell";
        resultCell.setAttribute("contenteditable", "true");
        resultCell.style.backgroundColor = "#2eb2ff9a";
        resultCell.style.width = "212px";
        resultCell.addEventListener("keydown", allowNumbersOnly);
        operationContainer.appendChild(resultCell);

        if (i < 3) {
            row1.appendChild(operationContainer);
        } else {
            row2.appendChild(operationContainer);
        }
    }

    table1.appendChild(row1);
    table1.appendChild(row2);

    // Configuração do Enter para navegar entre células
    var cells = document.querySelectorAll(".cell");
    cells.forEach(function(cell) {
        cell.addEventListener("keydown", function(event) {
            if (event.key === "Enter") {
                event.preventDefault();
                var nextCellIndex = Array.prototype.indexOf.call(cells, cell) + 1;
                var foundEditable = false;
                while (nextCellIndex < cells.length && !foundEditable) {
                    if (cells[nextCellIndex].getAttribute("contenteditable") === "true") {
                        foundEditable = true;
                        cells[nextCellIndex].focus();
                    } else {
                        nextCellIndex++;
                    }
                }
            }
        });
    });

    updateProgress(0, 0);
    resetStarProgress();
}

// Obtendo o botão "Novo Jogo" e adicionando um evento de clique
document.getElementById("new-game-button").addEventListener("click", startNewGame);
document.getElementById("verify-button").addEventListener("click", verifyTable);

// Função para verificar as respostas
function verifyTable() {
    if (!checkIfTableComplete()) {
        return;
    }

    let correctCount = 0;
    let inputCells = document.querySelectorAll(".input-cell");
    let totalCells = inputCells.length;
    
    for (let i = 0; i < inputCells.length; i++) {
        let cell = inputCells[i];
        let userValue = parseInt(cell.textContent.trim()) || 0;
        let correctValue = correctAnswers[i];

        cell.classList.remove("cell-correct", "cell-incorrect");
        cell.style.backgroundColor = "";

        if (userValue === correctValue) {
            cell.classList.add("cell-correct");
            correctCount++;
        } else {
            cell.classList.add("cell-incorrect");
        }
        
        cell.setAttribute("contenteditable", "false");
    }

    // Atualiza progresso
    let incorrectCount = totalCells - correctCount;
    updateProgress(correctCount, incorrectCount);
    //atualiza a barra de progresso de estrelas
    updateStarProgress(correctCount); 
    
    // Verifica se acertou tudo (100% de acertos)
    if (correctCount === totalCells) {
        modal3.style.display = "block";
        setTimeout(() => {
            returnToLevelSelection('facil', 5);
        }, 4000);
    }else{
        modal2.style.display = "block";
    }
}

// Atualizar barra de progresso 
function updateProgress(correct, incorrect) {
    let total = correct + incorrect;
    let correctPercent = total > 0 ? Math.round((correct / total) * 100) : 0;
    let incorrectPercent = total > 0 ? Math.round((incorrect / total) * 100) : 0;

    document.getElementById("progress-bar").value = correctPercent;
    document.getElementById("progress-percent").textContent = `${correctPercent}%`;
    
    document.getElementById("error-progress-bar").value = incorrectPercent;
    document.getElementById("error-progress-percent").textContent = `${incorrectPercent}%`;
}

// Atualizar progresso de estrelas 
function updateStarProgress(correct) {
    let total = generatedNumbers.length;
    let starCount = 0;
    
    if (total > 0) {
        //se a pessoa acertar mais que 80% mas não acertar 100% nao recebera 5 estrelas
        if(starCount == 5 && correct != 100)
        {
            starCount--;
        }else{
            starCount = Math.min(Math.floor((correct / total) * 5), 5);
        }
    }
    
    
    document.getElementById("star-progress-bar").value = starCount;
    document.getElementById("star-progress-percent").textContent = `${starCount}`; // Mostra a fração de estrelas
    
    // Configura o GIF correspondente
    let gifElement = document.getElementById("gif-element");
    if (gifElement) {
        if (starCount === 5) {
            gifElement.src = "https://media.tenor.com/WBya4tWP0agAAAAi/star.gif";
        } else if (starCount === 4) {
            gifElement.src = "https://media.tenor.com/_UE6DkuikesAAAAi/star.gif";
        } else if (starCount === 3) {
            gifElement.src = "https://media.tenor.com/R_nXqV_bIf8AAAAi/dtar.gif";
        } else if (starCount === 2) {
            gifElement.src = "https://media.tenor.com/EIVs78DyGHsAAAAi/star.gif";
        } else if (starCount === 1) {
            gifElement.src = "https://media.tenor.com/7LoMkEwSwcQAAAAi/star.gif";
        } else if(starCount === 0) {
            gifElement.src = "";
        }
    }

 
    return starCount;
}

// função para voltar à seleção com estrelas 
function returnToLevelSelection(level, stars) {
    localStorage.setItem(`${level}Stars`, stars);
    window.location.href = `../../templates/atividade4/niveis_atvd4.html?${level}=${stars}`;
}

// Função para verificar se todos os campos estão preenchidos
function checkIfTableComplete() {
    let inputCells = document.querySelectorAll(".input-cell");
    let allFilled = true;
    
    inputCells.forEach(cell => {
        if (cell.textContent.trim() === "") {
            cell.style.border = "2px solid";
            allFilled = false;
        } else {
            cell.style.border = "";
        }
    });
    
    if (!allFilled) {
        showWarningImage();
    }
    
    return allFilled;
}

function showWarningImage() {
    modal.style.display = "block"; // Usa o modal1 definido no início
}

////FECHAMENTO DO MODAIS
// Para o primeiro modal
document.getElementsByClassName("close")[0].onclick = function() {
    modal.style.display = "none";
}

// Para o segundo modal
document.getElementsByClassName("close2")[0].onclick = function() {
    modal2.style.display = "none";
}

// Para o terceiro modal
document.getElementsByClassName("close3")[0].onclick = function() {
    modal3.style.display = "none";
}
 ////FIM DO FECHAMENTO DO MODAIS

// Resetar progresso de estrelas
function resetStarProgress() {
    document.getElementById("star-progress-bar").value = 0;
    document.getElementById("star-progress-percent").textContent = "";
}


// Audio
const playButton = document.getElementById('playButton');
const audio = document.getElementById('audio');

playButton.addEventListener('click', function () {
    audio.play();
});