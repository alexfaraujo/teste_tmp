function returnToLevelSelection(level, stars) {
    localStorage.setItem(`${level}Stars`, stars);
    window.location.href = '../../templates/atividade2/niveis_atvd2.html?${level}=${stars}';
}

var generatedNumbers = [];
// Função para iniciar um novo jogo
function startNewGame() {
    // Limpar a tabela 1
    var table1 = document.getElementById("table1");
    table1.innerHTML = "";
    colorizeTable();
    // Redefinir a barra de progresso
    var progressBar = document.getElementById("progress-bar");
    var progressPercent = document.getElementById("progress-percent");
    var errorProgressBar = document.getElementById("error-progress-bar");
    var errorProgressPercent = document.getElementById("error-progress-percent");
    var starProgressBar = document.getElementById("star-progress-bar");
    var starProgressPercent = document.getElementById("star-progress-percent");

    progressBar.value = 0;
    progressPercent.textContent = "0%";
    errorProgressBar.value = 0;
    errorProgressPercent.textContent = "0%";
    starProgressBar.value = 0;
    starProgressPercent.textContent = "";

    function colorizeTable() {
        generatedNumbers = []; // Limpa a matriz
        // Limpar a tabela 1
        var table1 = document.getElementById("table1");
        table1.innerHTML = "";

        // Função para permitir apenas números
        function allowNumbersOnly(event) {
            // Obtém o código da tecla pressionada
            var key = event.key;
            // Verifica se a tecla é um número ou uma tecla de controle
            if (!(event.key >= "0" && event.key <= "9") && event.keyCode !== 8 && event.keyCode !== 46) {
                event.preventDefault();
            }
        }

        var numerosSorteados = []; // Array para armazenar os números já sorteados para que nao haja repeticao
        function gerarNumeroUnico() 
        {
            var numero;
            do {
                numero = Math.floor(Math.random() * 83) + 15;
            } while (numerosSorteados.includes(numero));
        
            numerosSorteados.push(numero);
            return numero;
        }
        
        // Função para gerar uma sequência aleatória de 3 números
        for (var i = 0; i < 5; i++) {
            var row = document.createElement("div");
            row.classList.add("row");
            var rowNumbers = [];
            // Gerando os três números consecutivos para a linha atual
            var startNumber = gerarNumeroUnico(); //variavel que recebe numeros aleatorio sem repeticao
            for (var j = 0; j < 3; j++) {
                var cell = document.createElement("div");
                cell.classList.add("cell");
                var number = startNumber + j;
                cell.innerHTML = number;
                row.appendChild(cell);
                rowNumbers.push(number); // Adicione o número à matriz da linha

                // Colorir as colunas 1 e 3 de azul
                if (j === 0 || j === 2) {
                    cell.classList.add("blue");
                    cell.innerHTML = "";
                    cell.contentEditable = true; 
                    cell.focus(); 
                    cell.addEventListener("keydown", allowNumbersOnly); // Adicionar evento para permitir apenas números
                   
                }
            }
            
            table1.appendChild(row);
            generatedNumbers.push(rowNumbers); // Adicione a matriz da linha à matriz principal
        }
    
         // ação tab no botão enter"
        var cells = document.querySelectorAll(".cell");
        // Adiciona um listener para o evento "keydown" em cada célula
        cells.forEach(function(cell) {
            cell.addEventListener("keydown", function(event) {
                if (event.key === "Enter") {
                    event.preventDefault(); // Previne o comportamento padrão de saltar para a próxima linha
                    var nextCellIndex = Array.prototype.indexOf.call(cells, cell) + 1; // Obtém o índice da próxima célula
                    var foundEditable = false; // Inicializa o flag para indicar se a próxima célula editável foi encontrada
                    while (nextCellIndex < cells.length && !foundEditable) {
                        if (cells[nextCellIndex].getAttribute("contenteditable") === "true") {
                        foundEditable = true; // Muda o valor do flag para true
                        cells[nextCellIndex].focus(); // Foca no próximo elemento
                        }
                        else {
                        nextCellIndex++; // Passa para a próxima célula
                        }
                    }
                }
            });
        });

    }
    // Obtendo o botão e adicionando um evento
    var newGameButton = document.getElementById("new-game-button");
    newGameButton.addEventListener("click", colorizeTable);
        
}

// Obtendo o botão "Novo Jogo" e adicionando um evento de clique
var newGameButton = document.getElementById("new-game-button");
newGameButton.addEventListener("click", startNewGame);


function verifyTable() {
    // Verifica se todas as células estão preenchidas
    var cells1 = document.querySelectorAll("#table1 .cell");
    var isTableComplete = true;
    var isTableCorrect = true;
    for (var i = 0; i < cells1.length; i++) {
        if (cells1[i].innerHTML === "") {
        isTableComplete = false;
        break;
        }
    }

    if (!isTableComplete) {
        // Se não estiver completa, exibe um alerta
        modal.style.display = "block";
        return;
    }

    // Verifica se todas as células já estão travadas
    var allCellsLocked = true;
    cells1.forEach(function(cell) {
        if (cell.contentEditable === "true") {
            allCellsLocked = false;
        }
    });

    if (allCellsLocked) {
        // Todas as células já estão travadas.
        return;
    }
    // Remove todas as classes de estilo adicionadas anteriormente
    cells1.forEach(function (cell) {
        cell.classList.remove("correct", "incorrect", "animated", "flash", "pulse", "border-danger", "border-success", "cell-correct", "cell-incorrect");
    });

    var allCellsCorrect = true;
    for (var i = 0; i < cells1.length; i++) {
        var cell = cells1[i];
        if (cell.classList.contains("blue")) {
            var cellValue = parseInt(cell.innerHTML, 10);
            var rowIndex = Math.floor(i / 3);
            var cellIndex = i % 3;
            if (cellValue == generatedNumbers[rowIndex][cellIndex]) {
                cells1[i].classList.remove("cell-incorrect");
                cells1[i].classList.add("cell-correct", "animated", "flash", "border-success");
            } else {
                cells1[i].classList.remove("cell-correct");
                cells1[i].classList.add("cell-incorrect", "animated", "pulse", "border-danger");
                isTableCorrect = false;
            }
        }
    }

    if (isTableCorrect) {
        modal3.style.display = "block";
    } else{
        modal2.style.display = "block";
    }
}
var matricula = "{{ matricula }}";

function updateProgressBar(matricula) 
{
    var cells1 = document.querySelectorAll("#table1 .cell");
    var totalCells = cells1.length;
    var correctCells = 0;
    var incorrectCells = 0;
    var editableCells = 0;
    var isTableComplete = true;
    var matriculaElement = document.getElementById("matricula");
    var matricula = matriculaElement.getAttribute("data-matricula");


    for (var i = 0; i < cells1.length; i++) {
        if (cells1[i].innerHTML === "") {
            isTableComplete = false;
            break;
        }
    }

    if (!isTableComplete) {
        // Se não estiver completa, exibe um alerta ou trata conforme necessário
        return;
    }

    for (var i = 0; i < totalCells; i++) {
        var cell = cells1[i];
        if (cell.contentEditable === "true") {
            editableCells++;
            var cellValue = parseInt(cell.innerHTML, 10);
            var rowIndex = Math.floor(i / 3);
            var cellIndex = i % 3;

            if (cellValue === generatedNumbers[rowIndex][cellIndex]) {
                correctCells++;
            } else {
                incorrectCells++;
            }
        }
    }

    var percentage = (correctCells / editableCells) * 100;
    var errorPercentage = (incorrectCells / editableCells) * 100;

    var progressBar = document.getElementById("progress-bar");
    var progressPercent = document.getElementById("progress-percent");
    var errorProgressBar = document.getElementById("error-progress-bar");
    var errorProgressPercent = document.getElementById("error-progress-percent");

    progressBar.value = percentage;
    progressPercent.textContent = percentage.toFixed(0) + "%";
    errorProgressBar.value = errorPercentage;
    errorProgressPercent.textContent = errorPercentage.toFixed(0) + "%";
    updateStarProgressBar(percentage);

    // Enviando as informações para o servidor
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "/inserir_dados_atividade_2", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            console.log(xhr.responseText);  // Exibir resposta do servidor
        }
    };
    
    var currentTime = new Date();
    var formattedDate = currentTime.toISOString().split('T')[0];
    var formattedTime = currentTime.toTimeString().split(' ')[0];
    var activity = "Antecessor e sucessor"; // 
    
    // Montar os dados como uma string de consulta
    var data_2 = "cod=" + matricula + "&data=" + formattedDate + "&hora=" + formattedTime +
               "&atividade=" + activity + "&qtd_corretas=" + correctCells + 
               "&qtd_incorretas=" + (editableCells - correctCells) + 
               "&porc_acertos=" + Math.round(percentage);
    
    xhr.send(data_2);

    // Travando a edição das células
    var cells1 = document.querySelectorAll("#table1 .cell");
    cells1.forEach(function(cell) {
        cell.contentEditable = false;
    });

    return {
        totalEditableCells: editableCells,
        totalCorrectEditableCells: correctCells,
        totalIncorrectEditableCells: editableCells - correctCells,
        correctCells: correctCells,
        editableCells: editableCells,
    };
}

function updateStarProgressBar(percentage) {
    // Encontrar a barra de progresso das estrelas e o elemento de porcentagem
    var starProgressBar = document.getElementById("star-progress-bar");
    var starProgressPercent = document.getElementById("star-progress-percent");
    var gifElement = document.getElementById("gif-element"); // Elemento de imagem do GIF

    // Calcular o valor das estrelas com base na porcentagem (de 1 a 5)
    var starsValue = Math.ceil((percentage / 100) * 5);

    //se a pessoa acertar mais que 80% mas não acertar 100% nao recebera 5 estrelas
    if(starsValue == 5 && percentage != 100)
    {
        starsValue--;
    }
    // Definir o valor da barra de progresso das estrelas
    starProgressBar.value = starsValue;
    // Definir o texto da porcentagem
    starProgressPercent.textContent = starsValue;

    // Escolher qual GIF exibir com base em starsValue
    var gifSrc;
    if (starsValue === 1) {
        gifSrc = "https://media.tenor.com/7LoMkEwSwcQAAAAi/star.gif";
    } else if (starsValue === 2) {
        gifSrc = "https://media.tenor.com/EIVs78DyGHsAAAAi/star.gif";
    } else if (starsValue === 3) {
        gifSrc = "https://media.tenor.com/R_nXqV_bIf8AAAAi/dtar.gif";
    } else if (starsValue === 4) {
        gifSrc = "https://media.tenor.com/_UE6DkuikesAAAAi/star.gif";
    } else if(starsValue === 0){
        gifElement.src = "";
    }

    // Definir a origem do GIF com base na escolha acima
    gifElement.src = gifSrc;

     //para subir de nivel
    if (starsValue === 5 && percentage === 100) {
        setTimeout(() => {
            returnToLevelSelection('intermediario', 5);
        }, 4000); // Delay para mostrar a animação
    }

    return starsValue; // Retorna o valor das estrelas
    
}

// função para voltar à seleção com estrelas 
function returnToLevelSelection(level, stars) {
    localStorage.setItem(`${level}Stars`, stars);
    window.location.href = `../../templates/atividade2/niveis_atvd2.html?${level}=${stars}`;
}


// --------------------MODAL---------------------------------
// Get the modal
var modal = document.getElementById("myModal");

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
    modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}


// Get the modal
var modal3 = document.getElementById("myModal3");

// Get the button that opens the modal
var btn3 = document.getElementById("myBtn3");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close3")[0];

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
    modal3.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal3) {
        modal3.style.display = "none";
    }
}

// Get the modal
var modal2 = document.getElementById("myModal2");

// Get the button that opens the modal
var btn2 = document.getElementById("myBtn2");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close2")[0];

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
    modal2.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal2) {
        modal2.style.display = "none";
    }
}
// --------------------FIM MODAL---------------------------------

// ---------------------- audio ---------------------------------
const playButton = document.getElementById('playButton');
const audio = document.getElementById('audio');

playButton.addEventListener('click', function () {
    audio.play();
});