var generatedNumbers = [];
var parContainer = document.getElementById("par_numeros");
var imparContainer = document.getElementById("impar_numeros");

var modal = document.getElementById("myModal");
var modal2 = document.getElementById("myModal2");
var modal3 = document.getElementById("myModal3");

function returnToLevelSelection(level, stars) {
    localStorage.setItem(`${level}Stars`, stars);
    window.location.href = `../../templates/atividade7/niveis_atvd7.html?${level}=${stars}`;
}

function allowNumbersOnly(event) {
    var key = event.key;
    if (!(key >= "0" && key <= "9") && event.keyCode !== 8 && event.keyCode !== 46) {
        event.preventDefault();
    }
}

function gerarNumeroUnico() {
    var numero;
    do {
        numero = Math.floor(Math.random() * 10) + 1;
    } while (generatedNumbers.includes(numero));
    return numero;
}

function startNewGame() {
    generatedNumbers = [];

    resetContainers();
    resetStarProgress();
    resetUpdateProgress();

    document.getElementById("par").innerHTML = "<div class='cell header-cell'>Par</div>";
    document.getElementById("impar").innerHTML = "<div class='cell header-cell'>Ímpar</div>";
    document.getElementById("num").innerHTML = "";

    // gerar 10 números únicos
    for (let i = 0; i < 10; i++) {
        let numero = gerarNumeroUnico();
        generatedNumbers.push(numero);
         
        let cellNumeros = document.createElement("div");
        cellNumeros.className = "cell draggable-number";
        cellNumeros.textContent = numero;
        cellNumeros.draggable = true;
        cellNumeros.dataset.number = numero; // Armazena o número como atributo
        cellNumeros.id = `num-${i}`;

        // adiciona eventos de drag
        cellNumeros.addEventListener('dragstart', function(e) {
            e.dataTransfer.setData('text/plain', e.target.id); //dataTrasfer armazena dados durante o ato de mover
        });

        document.getElementById("num").appendChild(cellNumeros);
    }

    // configura áreas de soltar (Par e Ímpar)
    setupDropZones();
}

function setupDropZones() {

    [parContainer, imparContainer].forEach(container => {
        container.addEventListener('dragover', function(e) {
            e.preventDefault(); //permite que o elemento seja solto no container
        });

        container.addEventListener('drop', function(e) {
            e.preventDefault();
            
            const id = e.dataTransfer.getData('text/plain');
            const draggedElement = document.getElementById(id);
            
            // verifica se o elemento está sendo movido para uma área diferente
            if (draggedElement && draggedElement.parentNode !== container) {
                container.appendChild(draggedElement);
            }
        });
    });
}

// Adicionar eventos aos botões
document.getElementById("new-game-button").addEventListener("click", startNewGame);
document.getElementById("verify-button").addEventListener("click", verifyParImpar);

function verifyParImpar() {
    const numContainer = document.getElementById("num");
    // verificar se há números não movidos
    if (numContainer.children.length > 0) {
        modal.style.display = "block";
        return;
    }

    let correctCount = 0;
    const totalNumbers = 10; 

    // Verificar todos os números movidos
    document.querySelectorAll('.draggable-number').forEach(numElement => {
        const num = parseInt(numElement.textContent);
        const parentId = numElement.parentElement.id;
        const isCorrect = (num % 2 === 0 && parentId === "par_numeros") || 
                        (num % 2 !== 0 && parentId === "impar_numeros");

        numElement.classList.toggle('cell-correct', isCorrect);
        numElement.classList.toggle('cell-incorrect', !isCorrect);
        
        if(isCorrect) correctCount++;
    });

    const incorrectCount = totalNumbers - correctCount;
    updateProgress(correctCount, incorrectCount);

    if (correctCount === totalNumbers) {
        modal3.style.display = "block";
        setTimeout(() => returnToLevelSelection('facil', 5), 4000);
    } else {
        modal2.style.display = "block";
    }
}

function updateStarProgress(correct) {
    const starBar = document.getElementById("star-progress-bar");
    const totalNumbers = 10; 
    
    let starCount = Math.round((correct / totalNumbers) * 5);

    if(starCount === 5 && correct != totalNumbers) {
        starCount = 4;
    }

    starBar.value = starCount;
    document.getElementById("star-progress-percent").textContent = starCount;

    // Atualizar GIFs
    let gifElement = document.getElementById("gif-element");
    if (gifElement) {
        if (starCount === 5) {
            gifElement.src = "https://media.tenor.com/WBya4tWP0agAAAAi/star.gif";
        } else if (starCount === 4) {
            gifElement.src = "https://media.tenor.com/_UE6DkuikesAAAAi/star.gif";
        } else if (starCount === 3) {
            gifElement.src = "https://media.tenor.com/R_nXqV_bIf8AAAAi/dtar.gif";
        } else if (starCount === 2) {
            gifElement.src = "https://media.tenor.com/EIVs78DyGHsAAAAi/star.gif";
        } else if (starCount === 1) {
            gifElement.src = "https://media.tenor.com/7LoMkEwSwcQAAAAi/star.gif";
        } else {
            gifElement.src = "";
        }
    }
    
    return starCount;
}

// Atualizar barra de progresso
function updateProgress(correct, incorrect) {
    const correctPercent = Math.round((correct / 10) * 100);
    const incorrectPercent = Math.round((incorrect / 10) * 100);

    document.getElementById("progress-bar").value = correctPercent;
    document.getElementById("progress-percent").textContent = `${correctPercent}%`;
    
    document.getElementById("error-progress-bar").value = incorrectPercent;
    document.getElementById("error-progress-percent").textContent = `${incorrectPercent}%`;

    updateStarProgress(correct);
}

 ////FECHAMENTO DO MODAIS
// Para o primeiro modal
document.getElementsByClassName("close")[0].onclick = function() {
    modal.style.display = "none";
}

// Para o segundo modal
document.getElementsByClassName("close2")[0].onclick = function() {
    modal2.style.display = "none";
}

// Para o terceiro modal
document.getElementsByClassName("close3")[0].onclick = function() {
    modal3.style.display = "none";
}
 ////FIM DO FECHAMENTO DO MODAIS


// Resetar progresso de estrelas
function resetStarProgress() {
    document.getElementById("star-progress-bar").value = 0;
    document.getElementById("star-progress-percent").textContent = "0";
}

function resetUpdateProgress(){
    document.getElementById("progress-bar").value = 0;
    document.getElementById("progress-percent").textContent = ``;
    
    document.getElementById("error-progress-bar").value = 0;
    document.getElementById("error-progress-percent").textContent = ``;
}

function resetContainers(){
    while (parContainer.firstChild) {
        parContainer.removeChild(parContainer.firstChild);
    }
    while (imparContainer.firstChild) {
        imparContainer.removeChild(imparContainer.firstChild);
    }
}

// ---------------------- audio ---------------------------------
const playButton = document.getElementById('playButton');
const audio = document.getElementById('audio');

playButton.addEventListener('click', function () {
    audio.play();
});
