// Variáveis globais necessárias
var generatedNumbers = [];
var modal = document.getElementById("myModal");
var modal2 = document.getElementById("myModal2");
var modal3 = document.getElementById("myModal3");

function returnToLevelSelection(level, stars) {
    localStorage.setItem(`${level}Stars`, stars);
    window.location.href = '../niveis_atvd6.html?${level}=${stars}';
}

// Função para permitir apenas números
function allowNumbersOnly(event) {
    var key = event.key;
    if (!(key >= "0" && key <= "9") && event.keyCode !== 8 && event.keyCode !== 46) {
        event.preventDefault();
    }
}

// Função para verificar se todos os campos estão preenchidos
function checkIfTableComplete() {
    var cells = document.querySelectorAll("#table1 .input-cell");
    for (var i = 0; i < cells.length; i++) {
        if (cells[i].textContent.trim() === "") {
            modal.style.display = "block";
            return false;
        }
    }
    return true;
}

// Função para iniciar um novo jogo
function startNewGame() 
{
    var table1 = document.getElementById("table1");
    table1.innerHTML = "";
    generatedNumbers = [];

    // Criar cabeçalhos da tabela
    let headerRow = document.createElement("div");
    headerRow.className = "row header-row";

    let headerNumber = document.createElement("div");
    headerNumber.className = "cell header-cell";
    headerNumber.textContent = "87";
    headerRow.appendChild(headerNumber);

    let headerNula = document.createElement("div");
    headerNula.className = "cell header-cell";
    headerNula.textContent = "=";
    headerRow.appendChild(headerNula);

    let headerDezena = document.createElement("div");
    headerDezena.className = "cell header-cell";
    headerDezena.textContent = "80";
    headerRow.appendChild(headerDezena);

    let headerNula2 = document.createElement("div");
    headerNula2.className = "cell header-cell";
    headerNula2.textContent = "+";
    headerRow.appendChild(headerNula2);

    let headerUnidade = document.createElement("div");
    headerUnidade.className = "cell header-cell";
    headerUnidade.textContent = "7";
    headerRow.appendChild(headerUnidade);

    table1.appendChild(headerRow);

    var numerosSorteados = []; 
    {
        var numero;
        do {
            numero = Math.floor(Math.random() * 99) + 1;
        } while (numerosSorteados.includes(numero));
        
        numerosSorteados.push(numero);
        return numero;
    }

    for (let i = 0; i < 6; i++) {
        let randomNumber = gerarNumeroUnico();
        generatedNumbers.push(randomNumber);

        let row = document.createElement("div");
        row.className = "row";

        let cellNumber = document.createElement("div");
        cellNumber.className = "cell number";
        cellNumber.textContent = randomNumber;
        row.appendChild(cellNumber);

        // criar células para dezena e unidade
        for (let j = 1; j <= 3; j++) {
            if(j == 1)
            {
                let igualCell = document.createElement("div");
                igualCell.className = "cell";
                igualCell.textContent = "=";
    
                row.appendChild(igualCell);
            }
            if(j == 2)
            {
                let plusCell = document.createElement("div");
                plusCell.className = "cell";
                plusCell.textContent = "+";

                row.appendChild(plusCell);
            }else{
                let cell = document.createElement("div");
                cell.className = "cell input-cell";
                cell.setAttribute("contenteditable", "true");
                cell.dataset.position = j;
                cell.addEventListener("keydown", allowNumbersOnly);
                cell.classList.add("blue");
                cell.innerHTML = "";
                row.appendChild(cell);
            }
        }

        table1.appendChild(row);
    }

    // Ação tab no botão enter
    var cells = document.querySelectorAll(".cell");
    cells.forEach(function(cell) {
        cell.addEventListener("keydown", function(event) {
            if (event.key === "Enter") {
                event.preventDefault();
                var nextCellIndex = Array.prototype.indexOf.call(cells, cell) + 1;
                var foundEditable = false;
                while (nextCellIndex < cells.length && !foundEditable) {
                    if (cells[nextCellIndex].getAttribute("contenteditable") === "true") {
                        foundEditable = true;
                        cells[nextCellIndex].focus();
                    } else {
                        nextCellIndex++;
                    }
                }
            }
        });
    });

    // Inicializar progresso
    updateProgress(0, 0);
    resetStarProgress();
}

// Função para verificar as respostas
function verifyTable() {
    if (!checkIfTableComplete()) {
        return;
    }

    let table1 = document.getElementById("table1");
    let rows = table1.getElementsByClassName("row");
    let correctCount = 0;
    let totalCount = generatedNumbers.length * 2; // Apenas 2 colunas

    for (let i = 1; i < rows.length; i++) {
        let number = generatedNumbers[i - 1];
        let row = rows[i];

        let dezenas = Math.floor(number / 10) * 10;
        let unidades = number % 10;

        let expectedValues = [dezenas, unidades];

        let cells = row.getElementsByClassName("input-cell");
        for (let j = 0; j < cells.length; j++) {
            let cell = cells[j];
            let userValue = parseInt(cell.textContent.trim(), 10);

            if (userValue === expectedValues[j]) {
                cell.classList.add("cell-correct");
                cell.classList.remove("cell-incorrect");
                correctCount++;
            } else {
                cell.classList.add("cell-incorrect");
                cell.classList.remove("cell-correct");
            }
        }
    }

    let incorrectCount = totalCount - correctCount;
    updateProgress(correctCount, incorrectCount);
    
     // Verifica se acertou tudo (100% de acertos)
    if (correctCount === totalCount) {
        modal3.style.display = "block";
        setTimeout(() => {
            returnToLevelSelection('facil', 5);
        }, 4000);   
    }else {
        modal2.style.display = "block";
    }
}

// Atualizar barra de progresso
function updateProgress(correct, incorrect) {
    let total = correct + incorrect;
    let correctPercent = Math.round((correct / total) * 100) || 0;
    let incorrectPercent = Math.round((incorrect / total) * 100) || 0;

    document.getElementById("progress-bar").value = correctPercent;
    document.getElementById("progress-percent").textContent = correctPercent + "%";

    document.getElementById("error-progress-bar").value = incorrectPercent;
    document.getElementById("error-progress-percent").textContent = incorrectPercent + "%";

    updateStarProgress(correct);
}

function updateStarProgress(correct) {
    let starBar = document.getElementById("star-progress-bar");
    let totalEditableCells = generatedNumbers.length * 2; // Ajustado para 2 colunas
    let starCount = Math.round((correct / totalEditableCells) * 5);
    
    // Ajuste para não dar 5 estrelas se não acertar tudo
    if(starCount === 5 && correct !== totalEditableCells) {
        starCount = 4;
    }
    
    starBar.value = starCount;
    document.getElementById("star-progress-percent").textContent = starCount;

    let gifElement = document.getElementById("gif-element");
    if (gifElement) {
        if (starCount === 5) {
            gifElement.src = "https://media.tenor.com/WBya4tWP0agAAAAi/star.gif";
        } else if (starCount === 4) {
            gifElement.src = "https://media.tenor.com/_UE6DkuikesAAAAi/star.gif";
        } else if (starCount === 3) {
            gifElement.src = "https://media.tenor.com/R_nXqV_bIf8AAAAi/dtar.gif";
        } else if (starCount === 2) {
            gifElement.src = "https://media.tenor.com/EIVs78DyGHsAAAAi/star.gif";
        } else if (starCount === 1) {
            gifElement.src = "https://media.tenor.com/7LoMkEwSwcQAAAAi/star.gif";
        } else {
            gifElement.src = "";
        }
    }

    return starCount;
}

// função para voltar à seleção com estrelas 
function returnToLevelSelection(level, stars) {
    localStorage.setItem(`${level}Stars`, stars);
    window.location.href = `../../templates/atividade6/niveis_atvd6.html?${level}=${stars}`;
}

// Fechamento dos modais
document.getElementsByClassName("close")[0].onclick = function() {
    modal.style.display = "none";
}

document.getElementsByClassName("close2")[0].onclick = function() {
    modal2.style.display = "none";
}

document.getElementsByClassName("close3")[0].onclick = function() {
    modal3.style.display = "none";
}

// Resetar progresso de estrelas
function resetStarProgress() {
    document.getElementById("star-progress-bar").value = 0;
    document.getElementById("star-progress-percent").textContent = "0";
}

// Configuração de áudio
const playButton = document.getElementById('playButton');
const audio = document.getElementById('audio');

playButton.addEventListener('click', function() {
    audio.play();
});

// Event listeners para os botões
document.getElementById("new-game-button").addEventListener("click", startNewGame);
document.getElementById("verify-button").addEventListener("click", verifyTable);