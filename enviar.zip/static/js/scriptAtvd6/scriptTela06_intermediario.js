var generatedNumbers = [];
var modal = document.getElementById("myModal");
var modal2 = document.getElementById("myModal2");
var modal3 = document.getElementById("myModal3");

// Função para voltar à seleção de nível 
function returnToLevelSelection(level, stars) {
    localStorage.setItem(`${level}Stars`, stars);
    window.location.href = `../../templates/atividade6/niveis_atvd6.html?${level}=${stars}`;
}

// Função para permitir apenas números 
function allowNumbersOnly(event) {
    var key = event.key;
    if (!(key >= "0" && key <= "9") && event.keyCode !== 8 && event.keyCode !== 46) {
        event.preventDefault();
    }
}

function startNewGame() {
    var table1 = document.getElementById("table1");
    table1.innerHTML = "";
    generatedNumbers = [];

    
    // Criar cabeçalhos da tabela 
    let headerRow = document.createElement("div");
    headerRow.className = "row header-row";

    let headerCentena = document.createElement("div");
    headerCentena.className = "cell header-cell";
    headerCentena.textContent = "Centenas";
    headerRow.appendChild(headerCentena);

    let headerPlus1 = document.createElement("div");
    headerPlus1.className = "cell header-cell";
    headerPlus1.textContent = "";
    headerRow.appendChild(headerPlus1);

    let headerDezena = document.createElement("div");
    headerDezena.className = "cell header-cell";
    headerDezena.textContent = "Dezenas";
    headerRow.appendChild(headerDezena);

    let headerPlus2 = document.createElement("div");
    headerPlus2.className = "cell header-cell";
    headerPlus2.textContent = "";
    headerRow.appendChild(headerPlus2);

    let headerUnidade = document.createElement("div");
    headerUnidade.className = "cell header-cell";
    headerUnidade.textContent = "Unidades";
    headerRow.appendChild(headerUnidade);

    let headerIgual = document.createElement("div");
    headerIgual.className = "cell header-cell";
    headerIgual.textContent = "";
    headerRow.appendChild(headerIgual);

    // coluna para a resposta
    let headerResposta = document.createElement("div");
    headerResposta.className = "cell header-cell";
    headerResposta.textContent = "Resultado";
    headerRow.appendChild(headerResposta);

    table1.appendChild(headerRow);
    
    // Cria resposta pronta como exemplo 
    let respostaRow = document.createElement("div");
    respostaRow.className = "row header-row";

    let headerCentena2 = document.createElement("div");
    headerCentena2.className = "cell header-cell";
    headerCentena2.textContent = "6";
    respostaRow.appendChild(headerCentena2);

    let headerPlus3 = document.createElement("div");
    headerPlus3.className = "cell header-cell";
    headerPlus3.textContent = "+";
    respostaRow.appendChild(headerPlus3);

    let headerDezena2 = document.createElement("div");
    headerDezena2.className = "cell header-cell";
    headerDezena2.textContent = "8";
    respostaRow.appendChild(headerDezena2);

    let headerPlus4 = document.createElement("div");
    headerPlus4.className = "cell header-cell";
    headerPlus4.textContent = "+";
    respostaRow.appendChild(headerPlus4);

    let headerUnidade2 = document.createElement("div");
    headerUnidade2.className = "cell header-cell";
    headerUnidade2.textContent = "2";
    respostaRow.appendChild(headerUnidade2);

    let headerIgual2 = document.createElement("div");
    headerIgual2.className = "cell header-cell";
    headerIgual2.textContent = "=";
    respostaRow.appendChild(headerIgual2);

    // coluna para a resposta
    let headerResposta2 = document.createElement("div");
    headerResposta2.className = "cell header-cell";
    headerResposta2.textContent = "682";
    respostaRow.appendChild(headerResposta2);

    table1.appendChild(respostaRow);
    
    var numerosSorteados = [];
    function gerarNumeroUnico() {
        var numero;
        do {
            numero = Math.floor(Math.random() * 900) + 100;
        } while (numerosSorteados.includes(numero));
        numerosSorteados.push(numero);
        return numero;
    }

    // Preencher linhas da tabela
    for (let i = 0; i < 6; i++) {
        let randomNumber = gerarNumeroUnico();
        generatedNumbers.push(randomNumber);

        // Decompor o número
        let centenas = Math.floor(randomNumber / 100); 
        let dezenas = Math.floor((randomNumber % 100) / 10);  
        let unidades = randomNumber % 10;  

        let row = document.createElement("div");
        row.className = "row";

        // Partes decompostas (não editáveis)
        let cellCentena = document.createElement("div");
        cellCentena.className = "cell";
        cellCentena.textContent = centenas;
        row.appendChild(cellCentena);

        let plusCell1 = document.createElement("div");
        plusCell1.className = "cell";
        plusCell1.textContent = "+";
        row.appendChild(plusCell1);

        let cellDezena = document.createElement("div");
        cellDezena.className = "cell";
        cellDezena.textContent = dezenas;
        row.appendChild(cellDezena);

        let plusCell2 = document.createElement("div");
        plusCell2.className = "cell";
        plusCell2.textContent = "+";
        row.appendChild(plusCell2);

        let cellUnidade = document.createElement("div");
        cellUnidade.className = "cell";
        cellUnidade.textContent = unidades;
        row.appendChild(cellUnidade);

        let igualCell = document.createElement("div");
        igualCell.className = "cell";
        igualCell.textContent = "=";
        row.appendChild(igualCell);

        let cellResposta = document.createElement("div");
        cellResposta.className = "cell input-cell";
        cellResposta.setAttribute("contenteditable", "true");
        cellResposta.classList.add("blue");
        cellResposta.addEventListener("keydown", allowNumbersOnly);
        row.appendChild(cellResposta);

        table1.appendChild(row);
    }

    // Configurar navegação com "Enter" 
    var cells = document.querySelectorAll(".input-cell");
    cells.forEach(function(cell) {
        cell.addEventListener("keydown", function(event) {
            if (event.key === "Enter") {
                event.preventDefault();
                var nextCell = Array.prototype.indexOf.call(cells, cell) + 1;
                if (nextCell < cells.length) cells[nextCell].focus();
            }
        });
    });

    // Resetar progresso
    updateProgress(0, 0);
    resetStarProgress();
}


function verifyTable() {
    if (!checkIfTableComplete()) return;

    let table1 = document.getElementById("table1");
    let rows = table1.querySelectorAll(".row:not(.header-row)");
    let correctCount = 0;
    let totalCount = generatedNumbers.length;

    rows.forEach((row, index) => {
        let respostaCell = row.querySelector(".input-cell");
        let respostaUsuario = parseInt(respostaCell.textContent.trim(), 10);
        let numeroEsperado = generatedNumbers[index];

        if (respostaUsuario === numeroEsperado) {
            respostaCell.classList.add("cell-correct");
            correctCount++;
        } else {
            respostaCell.classList.add("cell-incorrect");
        }
    });

    // Atualizar progresso 
    let incorrectCount = totalCount - correctCount;
    updateProgress(correctCount, incorrectCount);

    // Feedback de estrelas 
    if (correctCount === totalCount) {
        modal3.style.display = "block";
        setTimeout(() => returnToLevelSelection('intermediario', 5), 4000);
    }else {
        modal2.style.display = "block";
    }
}


function checkIfTableComplete() {
    var cells = document.querySelectorAll(".input-cell");
    for (var cell of cells) {
        if (cell.textContent.trim() === "") {
            modal.style.display = "block";
            return false;
        }
    }
    return true;
}

function updateProgress(correct, incorrect) {
    let total = correct + incorrect;
    let correctPercent = Math.round((correct / total) * 100) || 0;
    let incorrectPercent = Math.round((incorrect / total) * 100) || 0;

    document.getElementById("progress-bar").value = correctPercent;
    document.getElementById("progress-percent").textContent = correctPercent + "%";

    document.getElementById("error-progress-bar").value = incorrectPercent;
    document.getElementById("error-progress-percent").textContent = incorrectPercent + "%";

    updateStarProgress(correct);
}

function updateStarProgress(correct) {
    let starBar = document.getElementById("star-progress-bar");
    let totalEditableCells = generatedNumbers.length;
    let starCount = Math.round((correct / totalEditableCells) * 5);
    
    // Ajuste para não dar 5 estrelas se não acertar tudo
    if(starCount === 5 && correct !== totalEditableCells) {
        starCount = 4;
    }
    
    starBar.value = starCount;
    document.getElementById("star-progress-percent").textContent = starCount;

    let gifElement = document.getElementById("gif-element");
    if (gifElement) {
        if (starCount === 5) {
            gifElement.src = "https://media.tenor.com/WBya4tWP0agAAAAi/star.gif";
        } else if (starCount === 4) {
            gifElement.src = "https://media.tenor.com/_UE6DkuikesAAAAi/star.gif";
        } else if (starCount === 3) {
            gifElement.src = "https://media.tenor.com/R_nXqV_bIf8AAAAi/dtar.gif";
        } else if (starCount === 2) {
            gifElement.src = "https://media.tenor.com/EIVs78DyGHsAAAAi/star.gif";
        } else if (starCount === 1) {
            gifElement.src = "https://media.tenor.com/7LoMkEwSwcQAAAAi/star.gif";
        } else {
            gifElement.src = "";
        }
    }

    return starCount;
}

function resetStarProgress() {
    localStorage.setItem(`${level}Stars`, stars);
    window.location.href = `../../templates/atividade6/niveis_atvd6.html?${level}=${stars}`;
}

// Event listeners 
document.getElementById("new-game-button").addEventListener("click", startNewGame);
document.getElementById("verify-button").addEventListener("click", verifyTable);

// Fechar modais 
document.getElementsByClassName("close")[0].onclick = function() { modal.style.display = "none"; };
document.getElementsByClassName("close2")[0].onclick = function() { modal2.style.display = "none"; };
document.getElementsByClassName("close3")[0].onclick = function() { modal3.style.display = "none"; };

// Áudio 
const playButton = document.getElementById('playButton');
const audio = document.getElementById('audio');
playButton.addEventListener('click', function() { audio.play(); });