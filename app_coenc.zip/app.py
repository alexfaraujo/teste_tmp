from flask import Flask, render_template
import json
import os

app = Flask(__name__)
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_FILE = os.path.join(BASE_DIR, 'dashboard_data.json')

@app.route('/')
def dashboard():
    data = {}
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, 'r') as f:
            data = json.load(f)
            
    # Sort history by semester descending
    if 'history' in data:
        data['history'] = sorted(data['history'], key=lambda x: x['Semestre'], reverse=True)
        
    return render_template('dashboard.html', data=data)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')
