import sys
import os
import cv2
import numpy as np
from app.vision import VisionEngine

def main():
    if len(sys.argv) < 2:
        print("Uso: python test_vision.py <caminho_da_imagem>")
        print("Exemplo: python test_vision.py minha_foto.jpg")
        print("\nGerando uma imagem de teste sintética com uma face fictícia (apenas para teste estrutural)...")
        # Criar uma imagem preta de teste
        img = np.zeros((480, 640, 3), dtype=np.uint8)
        # Desenhar uma cabeça
        cv2.ellipse(img, (320, 240), (100, 130), 0, 0, 360, (255, 255, 255), -1)
        # Desenhar olhos (landmarks fictícios)
        cv2.circle(img, (280, 210), 10, (0, 0, 0), -1)
        cv2.circle(img, (360, 210), 10, (0, 0, 0), -1)
        # Nariz
        cv2.circle(img, (320, 250), 8, (0, 0, 0), -1)
        # Boca
        cv2.ellipse(img, (320, 300), (35, 15), 0, 0, 180, (0, 0, 0), -1)
        
        temp_img_path = "sintetica_temp.jpg"
        cv2.imwrite(temp_img_path, img)
        image_path = temp_img_path
        print(f"Imagem sintética criada em: {image_path}")
    else:
        image_path = sys.argv[1]
        if not os.path.exists(image_path):
            print(f"Erro: O arquivo de imagem '{image_path}' não existe.")
            sys.exit(1)

    print("Inicializando a Engine de Visão (carregando os 4 modelos ONNX)...")
    try:
        engine = VisionEngine()
        print("Engine inicializada com sucesso!")
    except Exception as e:
        print(f"Erro ao inicializar a Engine: {e}")
        sys.exit(1)

    # Carregar imagem
    print(f"Carregando a imagem: {image_path}")
    img = cv2.imread(image_path)
    if img is None:
        print("Erro: Não foi possível ler a imagem.")
        sys.exit(1)

    print(f"Dimensões da imagem original: {img.shape[1]}x{img.shape[0]}")
    
    # 1. Detecção Facial
    print("Executando detecção facial (SCRFD)...")
    bboxes, scores, kpss = engine.detect_faces(img, threshold=0.5)
    
    print(f"Faces detectadas: {len(bboxes)}")
    
    # Copiar a imagem para desenhar os resultados
    img_draw = img.copy()
    
    for i, (bbox, score, kps) in enumerate(zip(bboxes, scores, kpss)):
        x1, y1, x2, y2 = bbox
        print(f"\n--- Face #{i+1} ---")
        print(f"Confiança de Detecção: {score:.4f}")
        print(f"Bounding Box: [{x1:.1f}, {y1:.1f}, {x2:.1f}, {y2:.1f}]")
        
        # 2. Testar Vivacidade (Liveness)
        print("Executando teste de vivacidade (MiniFASNet)...")
        liveness_score = engine.check_liveness(img, bbox)
        is_real = liveness_score > 0.85
        print(f"Score de Vivacidade: {liveness_score:.4f} (Real: {is_real})")
        
        # 3. Testar Alinhamento Facial
        print("Executando alinhamento afim da face (112x112)...")
        aligned = engine.align_face(img, kps)
        aligned_path = f"aligned_face_{i+1}.jpg"
        cv2.imwrite(aligned_path, aligned)
        print(f"Face alinhada salva em: {aligned_path}")
        
        # 4. Extração de Embedding (ArcFace)
        print("Extraindo embedding de 512 dimensões...")
        embedding = engine.extract_embedding(aligned)
        print(f"Embedding gerado com sucesso!")
        print(f"Dimensão do Embedding: {embedding.shape}")
        print(f"Primeiros 5 valores do embedding normalizado: {embedding[:5]}")
        print(f"Norma L2 do embedding: {np.linalg.norm(embedding):.4f}")
        
        # Desenhar bounding box e landmarks na imagem de resultado
        color = (0, 255, 0) if is_real else (0, 0, 255) # Verde para Real, Vermelho para Fake
        label = "Real" if is_real else "Fake"
        
        # Desenhar caixa
        cv2.rectangle(img_draw, (int(x1), int(y1)), (int(x2), int(y2)), color, 2)
        # Adicionar texto
        text = f"{label} ({liveness_score:.2f})"
        cv2.putText(img_draw, text, (int(x1), int(y1) - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)
        
        # Desenhar os 5 keypoints (azul)
        for kp in kps:
            cv2.circle(img_draw, (int(kp[0]), int(kp[1])), 4, (255, 0, 0), -1)

    # Salvar imagem resultante
    result_path = "test_result.jpg"
    cv2.imwrite(result_path, img_draw)
    print(f"\nImagem de resultado desenhada salva em: {result_path}")
    
    # Remover arquivo temporário se gerado
    if len(sys.argv) < 2 and os.path.exists("sintetica_temp.jpg"):
        os.remove("sintetica_temp.jpg")
        print("Arquivo temporário sintetica_temp.jpg removido.")

if __name__ == "__main__":
    main()
