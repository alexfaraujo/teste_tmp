import os
import urllib.request

MODELS_DIR = "models"
MODELS = {
    "scrfd_2.5g_bn_kps.onnx": "https://huggingface.co/OwlMaster/AllFilesRope/resolve/d783e61585b3d83a85c91ca8a3b299e8ade94d72/scrfd_2.5g_bnkps.onnx",
    "w600k_mbf.onnx": "https://huggingface.co/deepghs/insightface/resolve/main/buffalo_s/w600k_mbf.onnx",
    "anti_spoof_1.8g.onnx": "https://github.com/yakhyo/face-anti-spoofing/releases/download/weights/MiniFASNetV1SE.onnx",
    "anti_spoof_2.7g.onnx": "https://github.com/yakhyo/face-anti-spoofing/releases/download/weights/MiniFASNetV2.onnx"
}

def report_progress(block_num, block_size, total_size):
    read_so_far = block_num * block_size
    if total_size > 0:
        percent = min(100, read_so_far * 100 / total_size)
        print(f"Progresso: {percent:.1f}% ({read_so_far / (1024*1024):.1f} MB de {total_size / (1024*1024):.1f} MB)", end="\r")
    else:
        print(f"Baixando: {read_so_far / (1024*1024):.1f} MB", end="\r")

def download_file(url, dest_path):
    print(f"\nIniciando download de: {url}\nDestino: {dest_path}")
    try:
        # Define um User-Agent para evitar que servidores bloqueiem a requisição padrão do Python
        opener = urllib.request.build_opener()
        opener.addheaders = [('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3')]
        urllib.request.install_opener(opener)
        
        urllib.request.urlretrieve(url, dest_path, report_progress)
        print(f"\n[OK] Modelo baixado com sucesso!")
    except Exception as e:
        print(f"\n[ERRO] Falha ao baixar o modelo: {e}")

def main():
    if not os.path.exists(MODELS_DIR):
        os.makedirs(MODELS_DIR)
        print(f"Diretório '{MODELS_DIR}' criado.")

    for name, url in MODELS.items():
        dest_path = os.path.join(MODELS_DIR, name)
        if os.path.exists(dest_path):
            # Verifica se o arquivo tem um tamanho razoável (evita arquivos corrompidos com 0 bytes)
            if os.path.getsize(dest_path) > 1024 * 100: 
                print(f"O modelo '{name}' já existe. Pulando download.")
                continue
            else:
                print(f"O modelo '{name}' parece estar corrompido (tamanho muito pequeno). Baixando novamente...")
        
        download_file(url, dest_path)

if __name__ == "__main__":
    main()
