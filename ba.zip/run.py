import uvicorn
from app.config import settings

def main():
    print(f"Iniciando o servidor FastAPI na porta {settings.PORT}...")
    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=settings.PORT,
        reload=True
    )

if __name__ == "__main__":
    main()
