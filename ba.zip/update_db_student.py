import os
import sys
from sqlalchemy import create_engine, text

# Ajusta path de forma absoluta
sys.path.append("/home/alex/Documentos/Chamada-Facial/backend")

from app.config import settings

def run_migration():
    print(f"Conectando ao banco em: {settings.DATABASE_URL}")
    engine = create_engine(settings.DATABASE_URL)
    
    queries = [
        "ALTER TABLE students ADD COLUMN IF NOT EXISTS is_active BOOLEAN NOT NULL DEFAULT TRUE;"
    ]
    
    with engine.connect() as conn:
        for query in queries:
            conn.execute(text(query))
            print(f"Executado: {query}")
        conn.commit()
    print("Migração concluída com sucesso!")

if __name__ == "__main__":
    run_migration()
