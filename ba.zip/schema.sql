-- Ativação da extensão pgvector para suporte a busca vetorial de 512 dimensões
CREATE EXTENSION IF NOT EXISTS vector;

-- Tabela de estudantes
CREATE TABLE IF NOT EXISTS students (
    id SERIAL PRIMARY KEY,
    teacher_id INT REFERENCES teachers(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    matricula VARCHAR(50) NOT NULL,
    face_embedding vector(512) NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_students_teacher_matricula UNIQUE (teacher_id, matricula)
);

-- Tabela de professores
CREATE TABLE IF NOT EXISTS teachers (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    phone VARCHAR(50),
    department VARCHAR(255),
    -- Campo legado de nome; armazena apenas identificador interno do arquivo, não URL pública.
    photo_url VARCHAR(512),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de Unidades Curriculares (disciplinas)
CREATE TABLE IF NOT EXISTS course_units (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    code VARCHAR(50) UNIQUE NOT NULL,
    teacher_id INT REFERENCES teachers(id) ON DELETE SET NULL,
    workload INT,
    classroom VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela associativa de matrículas (Muitos-para-Muitos entre Estudantes e Unidades Curriculares)
CREATE TABLE IF NOT EXISTS student_course_units (
    student_id INT REFERENCES students(id) ON DELETE CASCADE,
    course_unit_id INT REFERENCES course_units(id) ON DELETE CASCADE,
    enrolled_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (student_id, course_unit_id)
);

-- Tabela de registro de presenças (frequência)
CREATE TABLE IF NOT EXISTS attendance (
    id SERIAL PRIMARY KEY,
    student_id INT REFERENCES students(id) ON DELETE CASCADE,
    course_unit_id INT REFERENCES course_units(id) ON DELETE CASCADE,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(20) NOT NULL DEFAULT 'present',
    confidence DOUBLE PRECISION NOT NULL
);

-- Compatibilidade com bancos existentes: garante a coluna teacher_id na tabela course_units
ALTER TABLE course_units ADD COLUMN IF NOT EXISTS teacher_id INT REFERENCES teachers(id) ON DELETE SET NULL;
ALTER TABLE course_units ADD COLUMN IF NOT EXISTS workload INT;
ALTER TABLE course_units ADD COLUMN IF NOT EXISTS classroom VARCHAR(100);

-- Compatibilidade com bancos existentes: escopo de estudante por professor
ALTER TABLE students ADD COLUMN IF NOT EXISTS teacher_id INT REFERENCES teachers(id) ON DELETE CASCADE;

-- Backfill seguro: define teacher_id para estudantes vinculados a UCs de um único professor.
WITH student_teacher_map AS (
        SELECT
                scu.student_id,
                MIN(cu.teacher_id) AS teacher_id,
                COUNT(DISTINCT cu.teacher_id) AS teacher_count
        FROM student_course_units scu
        JOIN course_units cu ON cu.id = scu.course_unit_id
        WHERE cu.teacher_id IS NOT NULL
        GROUP BY scu.student_id
)
UPDATE students s
SET teacher_id = stm.teacher_id
FROM student_teacher_map stm
WHERE s.id = stm.student_id
    AND s.teacher_id IS NULL
    AND stm.teacher_count = 1;

DO $$
BEGIN
    IF EXISTS (
        SELECT 1
        FROM pg_constraint
        WHERE conname = 'students_matricula_key'
          AND conrelid = 'students'::regclass
    ) THEN
        ALTER TABLE students DROP CONSTRAINT students_matricula_key;
    END IF;
END $$;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint
        WHERE conname = 'uq_students_teacher_matricula'
          AND conrelid = 'students'::regclass
    ) THEN
        ALTER TABLE students
        ADD CONSTRAINT uq_students_teacher_matricula UNIQUE (teacher_id, matricula);
    END IF;
END $$;

-- Índices de otimização de consultas
CREATE INDEX IF NOT EXISTS idx_students_matricula ON students(matricula);
CREATE INDEX IF NOT EXISTS idx_students_teacher ON students(teacher_id);
CREATE INDEX IF NOT EXISTS idx_students_teacher_matricula ON students(teacher_id, matricula);
CREATE INDEX IF NOT EXISTS idx_course_units_code ON course_units(code);
CREATE INDEX IF NOT EXISTS idx_attendance_student ON attendance(student_id);
CREATE INDEX IF NOT EXISTS idx_attendance_course_unit ON attendance(course_unit_id);
CREATE INDEX IF NOT EXISTS idx_teachers_email ON teachers(email);
CREATE INDEX IF NOT EXISTS idx_course_units_teacher ON course_units(teacher_id);
