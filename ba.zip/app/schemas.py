from pydantic import BaseModel, Field
from datetime import datetime
from typing import List, Optional

# Schemas para Unidades Curriculares (CourseUnit)
class CourseUnitBase(BaseModel):
    name: str = Field(..., max_length=255, description="Nome da Unidade Curricular")
    code: str = Field(..., max_length=50, description="Código identificador único (ex: AED101)")
    workload: Optional[int] = Field(None, description="Carga Horária da UC em horas")
    classroom: Optional[str] = Field(None, max_length=100, description="Sala ou Local de aula")

class CourseUnitCreate(CourseUnitBase):
    pass

class CourseUnitResponse(CourseUnitBase):
    id: int
    created_at: datetime

    class Config:
        from_attributes = True

# Schemas para Estudantes (Student)
class StudentBase(BaseModel):
    name: str = Field(..., max_length=255, description="Nome completo do estudante")
    matricula: str = Field(..., max_length=50, description="Número de matrícula único")

class StudentResponse(StudentBase):
    id: int
    created_at: datetime
    course_units: List[CourseUnitResponse] = []

    class Config:
        from_attributes = True

class StudentShortResponse(StudentBase):
    id: int
    created_at: datetime

    class Config:
        from_attributes = True

# Schemas para Frequência/Presença (Attendance)
class AttendanceResponse(BaseModel):
    id: int
    student_id: int
    course_unit_id: int
    timestamp: datetime
    status: str
    confidence: float
    student: StudentShortResponse
    course_unit: CourseUnitResponse

    class Config:
        from_attributes = True

# Schemas para Professor (Teacher)
class TeacherBase(BaseModel):
    name: str = Field(..., max_length=255, description="Nome completo do professor")
    email: str = Field(..., max_length=255, description="Email institucional único")
    phone: Optional[str] = Field(None, max_length=50, description="Telefone de contato ou ramal")
    department: Optional[str] = Field(None, max_length=255, description="Departamento ou Área Acadêmica")

class TeacherCreate(BaseModel):
    name: str = Field(..., max_length=255, description="Nome completo do professor")
    phone: Optional[str] = Field(None, max_length=50, description="Telefone de contato ou ramal")
    department: Optional[str] = Field(None, max_length=255, description="Departamento ou Área Acadêmica")

class TeacherUpdate(BaseModel):
    phone: Optional[str] = Field(None, max_length=50, description="Telefone de contato ou ramal")
    department: Optional[str] = Field(None, max_length=255, description="Departamento ou Área Acadêmica")

class TeacherResponse(TeacherBase):
    id: int
    photo_key: Optional[str] = None
    created_at: datetime

    class Config:
        from_attributes = True
