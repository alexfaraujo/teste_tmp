from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    DATABASE_URL: str
    API_KEY: str
    PORT: int
    RECOGNITION_THRESHOLD: float
    LIVENESS_THRESHOLD: float
    ALLOWED_DOMAINS: str = "ifms.edu.br"

    @property
    def allowed_domains_list(self) -> list[str]:
        return [d.strip().lower() for d in self.ALLOWED_DOMAINS.split(",") if d.strip()]

    # Carrega variáveis do arquivo .env ou do ambiente do sistema operacional
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore"
    )

settings = Settings()
