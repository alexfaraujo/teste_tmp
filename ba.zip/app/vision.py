import os
import cv2
import numpy as np
import onnxruntime as ort

class VisionEngine:
    """
    Engine de Visão Computacional para o Sistema de Chamada Facial.
    Encapsula:
    1. Detecção facial com SCRFD (strides 8, 16, 32)
    2. Alinhamento afim 112x112
    3. Detecção de vivacidade (liveness/anti-spoofing) com MiniFASNetV1SE e MiniFASNetV2
    4. Extração de embeddings faciais com ArcFace (MobileFaceNet)
    """
    
    def __init__(self, models_dir: str = "models"):
        # Forçar o uso do CPUExecutionProvider para compatibilidade local estável
        providers = ["CPUExecutionProvider"]
        
        # Caminhos dos modelos ONNX
        scrfd_path = os.path.join(models_dir, "scrfd_2.5g_bn_kps.onnx")
        arcface_path = os.path.join(models_dir, "w600k_mbf.onnx")
        liveness_1_path = os.path.join(models_dir, "anti_spoof_1.8g.onnx")
        liveness_2_path = os.path.join(models_dir, "anti_spoof_2.7g.onnx")
        
        # Validar existência dos modelos
        for path in [scrfd_path, arcface_path, liveness_1_path, liveness_2_path]:
            if not os.path.exists(path):
                raise FileNotFoundError(
                    f"Modelo ONNX não encontrado em: {path}. "
                    "Por favor, execute o script download_models.py primeiro."
                )
                
        # Inicializar sessões ONNX Runtime
        self.det_session = ort.InferenceSession(scrfd_path, providers=providers)
        self.rec_session = ort.InferenceSession(arcface_path, providers=providers)
        self.liveness_1_session = ort.InferenceSession(liveness_1_path, providers=providers)
        self.liveness_2_session = ort.InferenceSession(liveness_2_path, providers=providers)
        
        # Parâmetros internos do SCRFD
        self.fmc = 3
        self._feat_stride_fpn = [8, 16, 32]
        self._num_anchors = 2
        self.center_cache = {}
        
        # Coordenadas canônicas de referência para alinhamento afim (112x112)
        # Ordem dos landmarks: olho esquerdo, olho direito, nariz, canto esquerdo da boca, canto direito da boca
        self.src_pts = np.array([
            [30.2946, 51.6963],
            [65.5318, 51.5014],
            [48.0252, 71.7366],
            [33.5493, 92.3655],
            [62.7299, 92.2041]
        ], dtype=np.float32)

    def _softmax(self, x: np.ndarray) -> np.ndarray:
        """Calcula a função softmax de forma estável."""
        e_x = np.exp(x - np.max(x, axis=1, keepdims=True))
        return e_x / np.sum(e_x, axis=1, keepdims=True)

    def _distance2bbox(self, points: np.ndarray, distance: np.ndarray) -> np.ndarray:
        """Decodifica as distâncias previstas em caixas delimitadoras [x1, y1, x2, y2]."""
        x1 = points[:, 0] - distance[:, 0]
        y1 = points[:, 1] - distance[:, 1]
        x2 = points[:, 0] + distance[:, 2]
        y2 = points[:, 1] + distance[:, 3]
        return np.stack([x1, y1, x2, y2], axis=-1)

    def _distance2kps(self, points: np.ndarray, distance: np.ndarray) -> np.ndarray:
        """Decodifica as distâncias previstas nos 5 keypoints faciais."""
        preds = []
        for i in range(0, distance.shape[1], 2):
            px = points[:, i % 2] + distance[:, i]
            py = points[:, i % 2 + 1] + distance[:, i + 1]
            preds.append(px)
            preds.append(py)
        return np.stack(preds, axis=-1)

    def _get_anchors(self, H_feat: int, W_feat: int, stride: int) -> np.ndarray:
        """Gera e faz cache dos centros das âncoras para o SCRFD."""
        key = (H_feat, W_feat, stride)
        if key in self.center_cache:
            return self.center_cache[key]
            
        anchor_centers = np.stack(np.mgrid[:H_feat, :W_feat][::-1], axis=-1).astype(np.float32)
        anchor_centers = (anchor_centers * stride).reshape((-1, 2))
        
        if self._num_anchors > 1:
            anchor_centers = np.stack([anchor_centers] * self._num_anchors, axis=1).reshape((-1, 2))
            
        self.center_cache[key] = anchor_centers
        return anchor_centers

    def detect_faces(self, img: np.ndarray, threshold: float = 0.5, nms_threshold: float = 0.4):
        """
        Detecta faces na imagem usando o modelo SCRFD.
        
        Args:
            img: Imagem em formato BGR (padrão OpenCV).
            threshold: Limiar de confiança para detecção.
            nms_threshold: Limiar para supressão de não-máximos (NMS).
            
        Returns:
            Tuple[np.ndarray, np.ndarray, np.ndarray]: 
                - Bounding boxes (caixas delimitadoras) de formato [x1, y1, x2, y2]
                - Scores de confiança
                - Landmarks faciais de formato (N, 5, 2)
        """
        H_orig, W_orig, _ = img.shape
        
        # Redimensionar imagens muito grandes para garantir escala ideal do detector
        # Usamos uma maior dimensão alvo de 640 pixels (conforme padrão de treinamento do SCRFD)
        target_max_dim = 640
        det_scale = 1.0
        if max(H_orig, W_orig) > target_max_dim:
            det_scale = float(target_max_dim) / max(H_orig, W_orig)
            H_new = int(H_orig * det_scale)
            W_new = int(W_orig * det_scale)
            img_det = cv2.resize(img, (W_new, H_new))
        else:
            img_det = img.copy()
            
        H, W, _ = img_det.shape
        
        # Converter para RGB para o modelo
        img_rgb = cv2.cvtColor(img_det, cv2.COLOR_BGR2RGB)
        
        # Normalização do SCRFD: (X - 127.5) / 128.0
        blob = (img_rgb.astype(np.float32) - 127.5) / 128.0
        blob = np.transpose(blob, (2, 0, 1))
        blob = np.expand_dims(blob, axis=0)
        
        # Executar a inferência no detector
        output_names = [o.name for o in self.det_session.get_outputs()]
        input_name = self.det_session.get_inputs()[0].name
        net_outs = self.det_session.run(output_names, {input_name: blob})
        
        scores_list = []
        bboxes_list = []
        kpss_list = []
        
        for idx, stride in enumerate(self._feat_stride_fpn):
            scores = net_outs[idx]
            bbox_preds = net_outs[idx + self.fmc] * stride
            kps_preds = net_outs[idx + self.fmc * 2] * stride
            
            # Calcular dimensões do feature map dinamicamente
            total_anchors = scores.shape[0]
            # Determinar a largura do feature map baseado no stride
            W_feat = int(np.ceil(W / stride))
            # Deduzir a altura garantindo correspondência exata com o tensor de saída
            H_feat = (total_anchors // self._num_anchors) // W_feat
            
            # Obter ou gerar centros de âncoras correspondentes
            anchor_centers = self._get_anchors(H_feat, W_feat, stride)
            
            # Filtrar por confiança mínima
            keep_inds = np.where(scores >= threshold)[0]
            if len(keep_inds) > 0:
                scores_keep = scores[keep_inds, 0]
                bboxes = self._distance2bbox(anchor_centers[keep_inds], bbox_preds[keep_inds])
                kpss = self._distance2kps(anchor_centers[keep_inds], kps_preds[keep_inds])
                
                scores_list.append(scores_keep)
                bboxes_list.append(bboxes)
                kpss_list.append(kpss)
                
        if len(scores_list) == 0:
            return np.empty((0, 4)), np.empty((0,)), np.empty((0, 5, 2))
            
        scores_all = np.concatenate(scores_list, axis=0)
        bboxes_all = np.concatenate(bboxes_list, axis=0)
        kpss_all = np.concatenate(kpss_list, axis=0)
        
        # Converter para o formato xywh exigido pelo cv2.dnn.NMSBoxes
        bboxes_xywh = []
        for box in bboxes_all:
            x1, y1, x2, y2 = box
            bboxes_xywh.append([float(x1), float(y1), float(x2 - x1), float(y2 - y1)])
            
        # Executar NMS do OpenCV
        indices = cv2.dnn.NMSBoxes(
            bboxes_xywh, 
            scores_all.tolist(), 
            threshold, 
            nms_threshold
        )
        
        if len(indices) == 0:
            return np.empty((0, 4)), np.empty((0,)), np.empty((0, 5, 2))
            
        indices = np.array(indices).flatten()
        
        final_bboxes = bboxes_all[indices]
        final_scores = scores_all[indices]
        final_kpss = kpss_all[indices].reshape((-1, 5, 2))
        
        # Projetar as coordenadas de volta para o tamanho original da imagem
        if det_scale != 1.0:
            final_bboxes = final_bboxes / det_scale
            final_kpss = final_kpss / det_scale
            
        return final_bboxes, final_scores, final_kpss

    def align_face(self, img: np.ndarray, kps: np.ndarray) -> np.ndarray:
        """
        Alinha a face em uma imagem de 112x112 usando uma transformação afim de similaridade.
        
        Args:
            img: Imagem em formato BGR.
            kps: Landmarks da face, formato (5, 2).
            
        Returns:
            np.ndarray: Imagem recortada e alinhada de 112x112 pixels.
        """
        # Calcular a matriz afim de similaridade com base nos 5 landmarks
        M, _ = cv2.estimateAffinePartial2D(kps, self.src_pts)
        
        if M is None:
            # Caso falhe, realiza um recorte simples centralizado
            # como plano de contingência
            x1, y1 = np.min(kps, axis=0)
            x2, y2 = np.max(kps, axis=0)
            w = x2 - x1
            h = y2 - y1
            cx, cy = (x1 + x2) / 2, (y1 + y2) / 2
            side = max(w, h) * 1.5
            x1_crop = max(0, int(cx - side/2))
            y1_crop = max(0, int(cy - side/2))
            x2_crop = min(img.shape[1], int(cx + side/2))
            y2_crop = min(img.shape[0], int(cy + side/2))
            crop = img[y1_crop:y2_crop, x1_crop:x2_crop]
            return cv2.resize(crop, (112, 112))
            
        # Warp da imagem para a imagem canônica 112x112
        aligned = cv2.warpAffine(img, M, (112, 112))
        return aligned

    def _crop_face_for_liveness(self, img: np.ndarray, bbox: np.ndarray, scale: float) -> np.ndarray:
        """Recorta e redimensiona a região da face para vivacidade aplicando o fator de escala."""
        src_h, src_w = img.shape[:2]
        x1, y1, x2, y2 = bbox
        
        w = x2 - x1
        h = y2 - y1
        x = x1
        y = y1
        
        # Limita a escala para evitar recortes fora dos limites da imagem
        s = min((src_h - 1) / h, min((src_w - 1) / w, scale))
        new_w = w * s
        new_h = h * s
        
        center_x = x + w / 2
        center_y = y + h / 2
        
        crop_x1 = max(0, int(center_x - new_w / 2))
        crop_y1 = max(0, int(center_y - new_h / 2))
        crop_x2 = min(src_w - 1, int(center_x + new_w / 2))
        crop_y2 = min(src_h - 1, int(center_y + new_h / 2))
        
        cropped = img[crop_y1:crop_y2+1, crop_x1:crop_x2+1]
        return cv2.resize(cropped, (80, 80))

    def check_liveness(self, img: np.ndarray, bbox: np.ndarray) -> float:
        """
        Executa a validação de vivacidade (anti-spoofing) da face usando as duas redes MiniFASNet.
        
        Args:
            img: Imagem em formato BGR.
            bbox: Bounding box de formato [x1, y1, x2, y2].
            
        Returns:
            float: Score de vivacidade (probabilidade de ser face real, de 0.0 a 1.0).
        """
        # Preparar crops correspondentes às escalas usadas no treinamento
        # MiniFASNetV1SE utiliza escala 4.0
        face_v1 = self._crop_face_for_liveness(img, bbox, 4.0)
        blob_v1 = face_v1.astype(np.float32)
        blob_v1 = np.transpose(blob_v1, (2, 0, 1))
        blob_v1 = np.expand_dims(blob_v1, axis=0)
        
        # MiniFASNetV2 utiliza escala 2.7
        face_v2 = self._crop_face_for_liveness(img, bbox, 2.7)
        blob_v2 = face_v2.astype(np.float32)
        blob_v2 = np.transpose(blob_v2, (2, 0, 1))
        blob_v2 = np.expand_dims(blob_v2, axis=0)
        
        # Executar inferências ONNX
        input_name_1 = self.liveness_1_session.get_inputs()[0].name
        out_1 = self.liveness_1_session.run(None, {input_name_1: blob_v1})[0]
        
        input_name_2 = self.liveness_2_session.get_inputs()[0].name
        out_2 = self.liveness_2_session.run(None, {input_name_2: blob_v2})[0]
        
        # Converter para probabilidades por Softmax
        prob_1 = self._softmax(out_1)[0]
        prob_2 = self._softmax(out_2)[0]
        
        # Média dos scores de vivacidade de ambos os modelos (índice 1 representa face real)
        real_prob_1 = prob_1[1]
        real_prob_2 = prob_2[1]
        
        liveness_score = (real_prob_1 + real_prob_2) / 2.0
        return float(liveness_score)

    def extract_embedding(self, aligned_face: np.ndarray) -> np.ndarray:
        """
        Extrai o vetor de embedding (512 dimensões) da face alinhada usando ArcFace.
        
        Args:
            aligned_face: Imagem da face alinhada e recortada em tamanho 112x112 em BGR.
            
        Returns:
            np.ndarray: Vetor de embedding de 512 dimensões normalizado L2.
        """
        # Converter para RGB
        face_rgb = cv2.cvtColor(aligned_face, cv2.COLOR_BGR2RGB)
        
        # Normalização do ArcFace: (X - 127.5) / 128.0
        blob = (face_rgb.astype(np.float32) - 127.5) / 128.0
        blob = np.transpose(blob, (2, 0, 1))
        blob = np.expand_dims(blob, axis=0)
        
        # Executar inferência
        input_name = self.rec_session.get_inputs()[0].name
        embedding = self.rec_session.run(None, {input_name: blob})[0]
        
        # Normalização L2 do vetor final
        embedding = embedding.flatten()
        norm = np.linalg.norm(embedding)
        if norm > 0:
            embedding = embedding / norm
            
        return embedding
