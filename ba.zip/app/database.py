from datetime import datetime
from typing import List, Optional
from sqlalchemy import create_engine, String, Integer, DateTime, ForeignKey, Float, Table, Column, Boolean
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship, sessionmaker
from pgvector.sqlalchemy import Vector
from app.config import settings

# Inicialização do Engine e Sessionmaker
engine = create_engine(
    settings.DATABASE_URL,
    pool_pre_ping=True
)

SessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine
)

# Classe Base do Declarative
class Base(DeclarativeBase):
    pass

# Tabela associativa Muitos-para-Muitos para matrículas
student_course_units = Table(
    "student_course_units",
    Base.metadata,
    Column("student_id", Integer, ForeignKey("students.id", ondelete="CASCADE"), primary_key=True),
    Column("course_unit_id", Integer, ForeignKey("course_units.id", ondelete="CASCADE"), primary_key=True),
    Column("enrolled_at", DateTime, default=datetime.utcnow)
)

# Modelo Teacher (Professores)
class Teacher(Base):
    __tablename__ = "teachers"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True, nullable=False)
    phone: Mapped[str] = mapped_column(String(50), nullable=True)
    department: Mapped[str] = mapped_column(String(255), nullable=True)
    # Mantemos o nome físico da coluna legado (photo_url) para compatibilidade,
    # mas semanticamente armazenamos apenas um identificador interno do arquivo.
    photo_storage_key: Mapped[Optional[str]] = mapped_column("photo_url", String(512), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    @property
    def photo_key(self) -> Optional[str]:
        return self.photo_storage_key

    # Relacionamento Um-para-Muitos com CourseUnit
    course_units: Mapped[List["CourseUnit"]] = relationship(
        back_populates="teacher",
        cascade="all, delete-orphan"
    )

    # Relacionamento Um-para-Muitos com Student
    students: Mapped[List["Student"]] = relationship(
        back_populates="teacher",
        cascade="all, delete-orphan"
    )

# Modelo Student (Estudantes)
class Student(Base):
    __tablename__ = "students"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    teacher_id: Mapped[int] = mapped_column(ForeignKey("teachers.id", ondelete="CASCADE"), index=True, nullable=False)
    matricula: Mapped[str] = mapped_column(String(50), index=True, nullable=False)
    face_embedding: Mapped[list] = mapped_column(Vector(512), nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    # Relacionamento com Teacher (dono do cadastro)
    teacher: Mapped[Teacher] = relationship(back_populates="students")

    # Relacionamento Muitos-para-Muitos
    course_units: Mapped[List["CourseUnit"]] = relationship(
        secondary=student_course_units,
        back_populates="students"
    )

    # Relacionamento Um-para-Muitos com Attendance
    attendances: Mapped[List["Attendance"]] = relationship(
        back_populates="student",
        cascade="all, delete-orphan"
    )

# Modelo CourseUnit (Unidades Curriculares / Disciplinas)
class CourseUnit(Base):
    __tablename__ = "course_units"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    code: Mapped[str] = mapped_column(String(50), unique=True, index=True, nullable=False)
    teacher_id: Mapped[int] = mapped_column(ForeignKey("teachers.id", ondelete="SET NULL"), nullable=True)
    workload: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    classroom: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    # Relacionamento Muitos-para-Muitos
    students: Mapped[List[Student]] = relationship(
        secondary=student_course_units,
        back_populates="course_units"
    )

    # Relacionamento Um-para-Muitos com Attendance
    attendances: Mapped[List["Attendance"]] = relationship(
        back_populates="course_unit",
        cascade="all, delete-orphan"
    )

    # Relacionamento com Teacher
    teacher: Mapped[Teacher] = relationship(back_populates="course_units")

# Modelo Attendance (Presenças / Frequências)
class Attendance(Base):
    __tablename__ = "attendance"

    id: Mapped[int] = mapped_column(primary_key=True)
    student_id: Mapped[int] = mapped_column(ForeignKey("students.id", ondelete="CASCADE"), index=True, nullable=False)
    course_unit_id: Mapped[int] = mapped_column(ForeignKey("course_units.id", ondelete="CASCADE"), index=True, nullable=False)
    timestamp: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    status: Mapped[str] = mapped_column(String(20), default="present", nullable=False)
    confidence: Mapped[float] = mapped_column(Float, nullable=False)

    # Relacionamentos ORM
    student: Mapped[Student] = relationship(back_populates="attendances")
    course_unit: Mapped[CourseUnit] = relationship(back_populates="attendances")

# Dependência do FastAPI para obter sessão do banco de dados
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
