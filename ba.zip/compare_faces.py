import sys
import os
import cv2
import numpy as np
from app.vision import VisionEngine

def main():
    if len(sys.argv) < 3:
        print("Uso: python compare_faces.py <imagem1> <imagem2> [limiar]")
        print("Exemplo: python compare_faces.py joao1.jpg joao2.jpg 0.5")
        sys.exit(1)
        
    img_path1 = sys.argv[1]
    img_path2 = sys.argv[2]
    
    # Limiar padrão para ArcFace (0.50 de similaridade cosseno)
    threshold = 0.50
    if len(sys.argv) >= 4:
        try:
            threshold = float(sys.argv[3])
        except ValueError:
            print(f"Limiar inválido '{sys.argv[3]}'. Usando padrão 0.50.")
            
    # Validar arquivos
    for path in [img_path1, img_path2]:
        if not os.path.exists(path):
            print(f"Erro: O arquivo '{path}' não existe.")
            sys.exit(1)
            
    print("Inicializando a Engine de Visão (ONNX)...")
    try:
        engine = VisionEngine()
    except Exception as e:
        print(f"Erro ao inicializar a Engine: {e}")
        sys.exit(1)
        
    # Carregar imagens
    print(f"Lendo imagens: \n  1. {img_path1}\n  2. {img_path2}")
    img1 = cv2.imread(img_path1)
    img2 = cv2.imread(img_path2)
    
    if img1 is None or img2 is None:
        print("Erro: Não foi possível carregar uma das imagens.")
        sys.exit(1)
        
    # Processar Imagem 1
    print("\n[Processando Imagem 1...]")
    bboxes1, scores1, kpss1 = engine.detect_faces(img1, threshold=0.5)
    if len(bboxes1) == 0:
        print("Erro: Nenhuma face encontrada na Imagem 1.")
        sys.exit(1)
    print(f"  Faces detectadas: {len(bboxes1)}")
    # Selecionar a face com maior confiança
    best_idx1 = np.argmax(scores1)
    bbox1 = bboxes1[best_idx1]
    score1 = scores1[best_idx1]
    kps1 = kpss1[best_idx1]
    liveness1 = engine.check_liveness(img1, bbox1)
    print(f"  Face selecionada (confiança: {score1:.4f})")
    print(f"  Score de Vivacidade (Liveness): {liveness1:.4f}")
    
    # Processar Imagem 2
    print("\n[Processando Imagem 2...]")
    bboxes2, scores2, kpss2 = engine.detect_faces(img2, threshold=0.5)
    if len(bboxes2) == 0:
        print("Erro: Nenhuma face encontrada na Imagem 2.")
        sys.exit(1)
    print(f"  Faces detectadas: {len(bboxes2)}")
    # Selecionar a face com maior confiança
    best_idx2 = np.argmax(scores2)
    bbox2 = bboxes2[best_idx2]
    score2 = scores2[best_idx2]
    kps2 = kpss2[best_idx2]
    liveness2 = engine.check_liveness(img2, bbox2)
    print(f"  Face selecionada (confiança: {score2:.4f})")
    print(f"  Score de Vivacidade (Liveness): {liveness2:.4f}")
    
    # Alinhamento Afim (112x112)
    aligned1 = engine.align_face(img1, kps1)
    aligned2 = engine.align_face(img2, kps2)
    
    # Salvar recortes alinhados para auditoria
    aligned_path1 = "aligned_img1.jpg"
    aligned_path2 = "aligned_img2.jpg"
    cv2.imwrite(aligned_path1, aligned1)
    cv2.imwrite(aligned_path2, aligned2)
    print(f"\nRecortes alinhados salvos para verificação: \n  - {aligned_path1}\n  - {aligned_path2}")
    
    # Extrair Embeddings (ArcFace)
    print("\nExtraindo vetores de características (embeddings)...")
    emb1 = engine.extract_embedding(aligned1)
    emb2 = engine.extract_embedding(aligned2)
    
    # Como os vetores estão normalizados L2, a similaridade de cosseno
    # é simplesmente o produto escalar (dot product).
    similarity = np.dot(emb1, emb2)
    distance = 1.0 - similarity
    
    print("\n" + "="*40)
    print("           RESULTADO DA COMPARAÇÃO      ")
    print("="*40)
    print(f"Similaridade de Cosseno : {similarity:.4f}")
    print(f"Distância de Cosseno    : {distance:.4f}")
    print(f"Limiar de Aceitação     : {threshold:.4f}")
    print("-"*40)
    
    is_same = similarity >= threshold
    if is_same:
        print(" VEREDICTO: SÃO A MESMA PESSOA! (✓)")
    else:
        print(" VEREDICTO: SÃO PESSOAS DIFERENTES! (✗)")
    print("="*40)

if __name__ == "__main__":
    main()
