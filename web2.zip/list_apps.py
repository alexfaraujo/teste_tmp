from app import create_app
from app.models import AplicativoAutorizado

app = create_app('default')

with app.app_context():
    apps = AplicativoAutorizado.query.all()
    if not apps:
        print("Nenhum aplicativo autorizado encontrado no banco de dados.")
    else:
        print(f"Encontrados {len(apps)} aplicativos registrados:")
        for a in apps:
            print(f"- Nome: {a.nome_app}, Ativo: {a.ativo}")
