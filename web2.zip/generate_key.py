import secrets
from app import create_app, db
from app.models import AplicativoAutorizado

app = create_app()

with app.app_context():
    # Generate a random API key
    raw_key = secrets.token_urlsafe(32)
    
    # Create the app entry
    nome_app = "Teste Curl"
    
    # Check if exists
    existing = AplicativoAutorizado.query.filter_by(nome_app=nome_app).first()
    if existing:
        db.session.delete(existing)
        db.session.commit()
        
    new_app = AplicativoAutorizado(nome_app=nome_app, ativo=True)
    # The setter will hash it
    new_app.api_key = raw_key
    
    db.session.add(new_app)
    db.session.commit()
    
    print(f"\n=== API Key Gerada ===")
    print(f"App: {nome_app}")
    print(f"Key: {raw_key}")
    print("======================\n")
