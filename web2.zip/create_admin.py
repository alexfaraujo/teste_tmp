import os
import sys
from sqlalchemy import text
from app import create_app, db
from app.models import UsuarioSistema
import subprocess

def init_db():
    print("[-] Verificando banco de dados...")
    
    # Create app to get config
    app = create_app()
    
    with app.app_context():
        # 1. Try to run migrations (creates tables if they don't exist)
        print("[-] Executando migrações...")
        try:
            subprocess.check_call(["flask", "db", "upgrade"])
            print("[+] Banco de dados atualizado.")
        except subprocess.CalledProcessError:
            print("[!] Erro ao executar migrações. Verifique se o banco de dados existe e as credenciais estão corretas.")
            sys.exit(1)

        # 2. Check for existing admin
        print("[-] Verificando usuário admin...")
        # We assume the first user or any user is enough to skip, but user asked for admin specifically.
        # Let's check if table is empty or if we want to force admin creation.
        # The prompt said "popular ele com os dados do usuário admin que irá usar o sistema".
        
        # Check if any user exists
        user_count = UsuarioSistema.query.count()
        
        if user_count > 0:
            print(f"[!] Já existem {user_count} usuários cadastrados. Pulando criação de admin.")
            return

        # 3. Interactive Admin Creation
        print("\n=== Configuração do Primeiro Usuário (Admin) ===")
        print("Nenhum usuário encontrado. Vamos criar o administrador do sistema.")
        
        while True:
            nome = input("Nome Completo: ").strip()
            if nome: break
            print("Nome é obrigatório.")
            
        while True:
            email = input("Email: ").strip()
            if email: 
                # Basic validation could go here
                break
            print("Email é obrigatório.")
            
        confirm = input(f"\nConfirma os dados?\nNome: {nome}\nEmail: {email}\n(S/n): ").lower()
        
        if confirm == 'n':
            print("Operação cancelada.")
            sys.exit(0)
            
        try:
            # Create user
            admin = UsuarioSistema(
                email=email,
                nome_completo=nome,
                ativo=True,
                # Add other necessary fields if any. 
                # Assuming 'role' is not in the model based on previous view_file of models.py 
                # (It had UsuarioSistema with email, nome_completo, ativo).
                # Wait, previous seed had 'role' but models.py didn't show it?
                # Let's re-check models.py content from history.
                # History Step 57: models.py class UsuarioSistema: id, email, nome_completo, ativo, data_cadastro. No 'role'.
                # So just these fields.
            )
            db.session.add(admin)
            db.session.commit()
            print(f"\n[+] Usuário admin '{nome}' ({email}) criado com sucesso!")
            
        except Exception as e:
            print(f"\n[!] Erro ao criar usuário: {e}")
            db.session.rollback()
            sys.exit(1)

if __name__ == "__main__":
    try:
        init_db()
    except KeyboardInterrupt:
        print("\n\nOperação interrompida pelo usuário.")
        sys.exit(0)
