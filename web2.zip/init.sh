#!/bin/bash

# Exit immediately if a command exits with a non-zero status
set -e

echo "=========================================="
echo "   Inicializando Sistema Policia TL Web   "
echo "=========================================="

# 1. Activate Virtual Environment
echo "[1/3] Ativando ambiente virtual..."
source /home/alex/Documentos/venv_geral/bin/activate

# 2. Install Dependencies
echo "[2/3] Verificando dependências..."
pip install -r requirements.txt > /dev/null 2>&1
echo "Dependências instaladas."

# 3. Initialize Database and Create Admin
echo "[3/3] Configurando Banco de Dados..."
python create_admin.py

echo "=========================================="
echo "   Sistema Inicializado com Sucesso!      "
echo "=========================================="
echo ""
echo "Iniciando o servidor da aplicação com Gunicorn..."
exec gunicorn -w 4 -b 0.0.0.0:5000 run:app
