from sqlalchemy import event
from flask_login import current_user
from app.extensions import db
from app.models import AuditoriaOperacao, MulherProtegida
import json
from datetime import datetime, date

def to_dict(model):
    """Helper to convert model to dict for JSON storage."""
    data = {}
    for column in model.__table__.columns:
        value = getattr(model, column.name)
        if isinstance(value, (datetime, date)):
            value = value.isoformat()
        data[column.name] = value
    return data

def create_audit_entry(mapper, connection, target, operation):
    try:
        if not current_user or not current_user.is_authenticated:
            user_id = None
        else:
            user_id = current_user.id
        
        state_before = None
        state_after = None

        if operation == 'DELETE':
            state_before = json.dumps(to_dict(target))
        elif operation == 'INSERT':
            state_after = json.dumps(to_dict(target))
        elif operation == 'UPDATE':
            from sqlalchemy import inspect
            inspector = inspect(target)
            dict_before = {}
            dict_after = {}
            
            for attr in inspector.attrs:
                key = attr.key
                history = attr.history
                
                if history.has_changes():
                    old_val = history.deleted[0] if history.deleted else None
                    new_val = history.added[0] if history.added else None
                    
                    if key.startswith('_'):
                        from app.utils.crypto import CryptoService
                        display_key = key[1:]
                        try:
                            if old_val: old_val = CryptoService.decrypt(old_val)
                            if new_val: new_val = CryptoService.decrypt(new_val)
                        except:
                            pass
                    else:
                        display_key = key

                    if isinstance(old_val, (datetime, date)): old_val = old_val.isoformat()
                    if isinstance(new_val, (datetime, date)): new_val = new_val.isoformat()
                    
                    dict_before[display_key] = old_val
                    dict_after[display_key] = new_val
                else:
                    
                    val = getattr(target, key)
                    
                    if key.startswith('_'):
                        from app.utils.crypto import CryptoService
                        display_key = key[1:]
                        try:
                            if val: val = CryptoService.decrypt(val)
                        except:
                            pass
                    else:
                        display_key = key

                    if isinstance(val, (datetime, date)): val = val.isoformat()
                    dict_before[display_key] = val
                    dict_after[display_key] = val

            state_before = json.dumps(dict_before)
            state_after = json.dumps(dict_after)

        audit = AuditoriaOperacao(
            usuario_id=user_id,
            tabela_afetada=target.__tablename__,
            registro_id=target.id,
            tipo_operacao=operation,
            dados_antigos=state_before,
            dados_novos=state_after,
            data_operacao=datetime.utcnow()
        )
        
        connection.execute(
            AuditoriaOperacao.__table__.insert().values(
                usuario_id=user_id,
                tabela_afetada=target.__tablename__,
                registro_id=target.id,
                tipo_operacao=operation,
                dados_antigos=state_before,
                dados_novos=state_after,
                data_operacao=datetime.utcnow()
            )
        )
    except Exception as e:
        print(f"Error creating audit entry: {e}")

def register_audit_events(app):
    event.listen(MulherProtegida, 'after_insert', lambda m, c, t: create_audit_entry(m, c, t, 'INSERT'))
    event.listen(MulherProtegida, 'after_update', lambda m, c, t: create_audit_entry(m, c, t, 'UPDATE'))
    event.listen(MulherProtegida, 'after_delete', lambda m, c, t: create_audit_entry(m, c, t, 'DELETE'))
