from app.models import LogAcesso
from app.extensions import db
from datetime import datetime, timedelta
from flask import current_app

class AlertService:
    @staticmethod
    def check_suspicious_activity(ip_address):
        """
        Checks if there are > 5 failed login attempts from this IP in the last 10 minutes.
        """
        ten_minutes_ago = datetime.utcnow() - timedelta(minutes=10)
        
        failed_attempts = LogAcesso.query.filter(
            LogAcesso.ip_origem == ip_address,
            LogAcesso.status_acesso.like('FALHA%'),
            LogAcesso.data_evento >= ten_minutes_ago
        ).count()

        if failed_attempts > 50:
            AlertService.send_alert_email(ip_address, failed_attempts)
            return True
        return False

    @staticmethod
    def send_alert_email(ip_address, count):
        """
        Mock function to send email to admin.
        In production, use Flask-Mail or an external API.
        """
        print(f"!!! SECURITY ALERT !!! Detected {count} failed login attempts from IP {ip_address} in the last 10 minutes.")
