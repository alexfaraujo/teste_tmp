from flask_admin import AdminIndexView, expose
from flask_admin.contrib.sqla import ModelView
from flask_login import current_user
from flask import redirect, url_for, flash

from wtforms import StringField, TextAreaField
from wtforms.validators import DataRequired

class SecureAdminIndexView(AdminIndexView):
    def is_accessible(self):
        return current_user.is_authenticated and getattr(current_user, 'ativo', False)

    def inaccessible_callback(self, name, **kwargs):
        flash("Faça login para acessar o painel.", "warning")
        return redirect(url_for('auth.login'))

class SecureModelView(ModelView):
    def is_accessible(self):
        return current_user.is_authenticated and getattr(current_user, 'ativo', False)

    def inaccessible_callback(self, name, **kwargs):
        return redirect(url_for('auth.login'))

class MulherProtegidaView(SecureModelView):
    column_list = ('nome_completo', 'cpf', 'data_nascimento', 'data_atualizacao')
    
    form_excluded_columns = ('_nome_completo', '_cpf', '_data_nascimento', '_telefone_contato', 
                             '_endereco_residencial', '_nome_agressor', '_numero_processo', 
                             '_restricoes_impostas', 'created_at', 'updated_at', 'data_registro', 'data_atualizacao')

    form_extra_fields = {
        'nome_completo': StringField('Nome Completo', validators=[DataRequired()]),
        'cpf': StringField('CPF', validators=[DataRequired()]),
        'data_nascimento': StringField('Data de Nascimento (DD/MM/AAAA)'),
        'telefone_contato': StringField('Telefone de Contato'),
        'endereco_residencial': StringField('Endereço Residencial'),
        'nome_agressor': StringField('Nome do Agressor'),
        'numero_processo': StringField('Número do Processo'),
        'restricoes_impostas': TextAreaField('Restrições Impostas')
    }

    form_columns = ('nome_completo', 'cpf', 'data_nascimento', 'telefone_contato', 
                    'endereco_residencial', 'nome_agressor', 'numero_processo', 
                    'restricoes_impostas', 'data_expedicao', 'validade_medida')
    
    column_searchable_list = []

    column_labels = {
        'nome_completo': 'Nome Completo',
        'cpf': 'CPF',
        'data_nascimento': 'Data de Nascimento',

        'data_atualizacao': 'Última Atualização',
        'telefone_contato': 'Telefone',
        'endereco_residencial': 'Endereço',
        'nome_agressor': 'Nome do Agressor',
        'numero_processo': 'Nº Processo',
        'restricoes_impostas': 'Restrições',
        'data_expedicao': 'Data Expedição',
        'validade_medida': 'Validade',
        'data_registro': 'Data Registro'
    }

    def on_model_change(self, form, model, is_created):
        pass

class UsuarioSistemaView(SecureModelView):
    column_list = ('email', 'nome_completo', 'ativo', 'data_cadastro')
    form_columns = ('email', 'nome_completo', 'ativo')
    
    column_labels = {
        'email': 'E-mail',
        'nome_completo': 'Nome Completo',
        'ativo': 'Ativo?',
        'data_cadastro': 'Data de Cadastro'
    }
    
    can_create = True
    can_edit = True
    can_delete = True

class AplicativoAutorizadoView(SecureModelView):
    column_list = ('nome_app', 'ativo', 'data_criacao')
    form_columns = ('nome_app', 'api_key', 'ativo')
    
    column_labels = {
        'nome_app': 'Nome do Aplicativo',
        'api_key': 'Chave de API (Senha)',
        'ativo': 'Ativo?',
        'data_criacao': 'Data de Criação'
    }
    
    form_extra_fields = {
        'api_key': StringField('Chave de API', description='Defina a senha que o App usará. Ela será criptografada.', validators=[DataRequired()])
    }

    def on_model_change(self, form, model, is_created):
        pass

class AuditoriaView(SecureModelView):
    can_create = False
    can_edit = False
    can_delete = False
    
    column_list = ('data_operacao', 'usuario_id', 'tipo_operacao', 'tabela_afetada', 'dados_antigos', 'dados_novos')
    column_default_sort = ('data_operacao', True)
    
    column_labels = {
        'data_operacao': 'Data',
        'usuario_id': 'Usuário ID',
        'tipo_operacao': 'Operação',
        'tabela_afetada': 'Tabela',
        'dados_antigos': 'Antes',
        'dados_novos': 'Depois'
    }
    
    def _format_json(view, context, model, name):
        value = getattr(model, name)
        if not value:
            return ''
        import json
        try:
            data = json.loads(value)
            return json.dumps(data, indent=2, ensure_ascii=False)
        except:
            return value

    column_formatters = {
        'dados_antigos': _format_json,
        'dados_novos': _format_json
    }

class LogAcessoView(SecureModelView):
    can_create = False
    can_edit = False
    can_delete = False
    
    column_list = ('data_evento', 'origem_acesso', 'identificador', 'ip_origem', 'status_acesso', 'detalhe_auditoria')
    column_default_sort = ('data_evento', True)
    
    column_labels = {
        'data_evento': 'Data/Hora',
        'origem_acesso': 'Origem',
        'identificador': 'Usuário/App',
        'ip_origem': 'IP',
        'status_acesso': 'Status',
        'detalhe_auditoria': 'Detalhes'
    }
