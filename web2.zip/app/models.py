from app.extensions import db
from flask_login import UserMixin
from datetime import datetime
from app.utils.crypto import CryptoService
import json

class UsuarioSistema(UserMixin, db.Model):
    __tablename__ = 'usuarios_sistema'
    
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    nome_completo = db.Column(db.String(100), nullable=False)
    ativo = db.Column(db.Boolean, default=True)
    data_cadastro = db.Column(db.DateTime, default=datetime.utcnow)

    @property
    def is_active(self):
        return self.ativo

    def __repr__(self):
        return f'<UsuarioSistema {self.email}>'

class AplicativoAutorizado(db.Model):
    __tablename__ = 'aplicativos_autorizados'

    id = db.Column(db.Integer, primary_key=True)
    nome_app = db.Column(db.String(100), nullable=False)
    api_key_hash = db.Column(db.String(255), nullable=False, unique=True)
    ativo = db.Column(db.Boolean, default=True)
    data_criacao = db.Column(db.DateTime, default=datetime.utcnow)

    @property
    def api_key(self):
        raise AttributeError('API Key is not readable')

    @api_key.setter
    def api_key(self, value):
        import hashlib
        self.api_key_hash = hashlib.sha256(value.encode('utf-8')).hexdigest()

class MulherProtegida(db.Model):
    __tablename__ = 'mulheres_protegidas'

    id = db.Column(db.Integer, primary_key=True)
    
    _nome_completo = db.Column('nome_completo', db.Text, nullable=False)
    _cpf = db.Column('cpf', db.Text, unique=True, nullable=False)
    cpf_hash = db.Column(db.String(64), unique=True, nullable=True)
    _data_nascimento = db.Column('data_nascimento', db.Text, nullable=True)
    _telefone_contato = db.Column('telefone_contato', db.Text, nullable=True)
    
    _endereco_residencial = db.Column('endereco_residencial', db.Text, nullable=True)
    
    _nome_agressor = db.Column('nome_agressor', db.Text, nullable=True)
    
    _numero_processo = db.Column('numero_processo', db.Text, nullable=True)
    _restricoes_impostas = db.Column('restricoes_impostas', db.Text, nullable=True)
    
    data_expedicao = db.Column(db.Date, nullable=True)
    validade_medida = db.Column(db.Date, nullable=True)
    
    data_registro = db.Column(db.DateTime, default=datetime.utcnow)
    data_atualizacao = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def _get_encrypted(self, field):
        return CryptoService.decrypt(field)

    def _set_encrypted(self, value):
        return CryptoService.encrypt(value)

    @property
    def nome_completo(self): return self._get_encrypted(self._nome_completo)
    @nome_completo.setter
    def nome_completo(self, value): self._nome_completo = self._set_encrypted(value)

    @property
    def cpf(self): return self._get_encrypted(self._cpf)
    @cpf.setter
    def cpf(self, value): 
        self._cpf = self._set_encrypted(value)
        if value:
            import hashlib
            self.cpf_hash = hashlib.sha256(value.encode('utf-8')).hexdigest()
        else:
            self.cpf_hash = None
    
    @property
    def data_nascimento(self): return self._get_encrypted(self._data_nascimento)
    @data_nascimento.setter
    def data_nascimento(self, value): self._data_nascimento = self._set_encrypted(value)

    @property
    def telefone_contato(self): return self._get_encrypted(self._telefone_contato)
    @telefone_contato.setter
    def telefone_contato(self, value): self._telefone_contato = self._set_encrypted(value)
    
    @property
    def endereco_residencial(self): return self._get_encrypted(self._endereco_residencial)
    @endereco_residencial.setter
    def endereco_residencial(self, value): self._endereco_residencial = self._set_encrypted(value)

    @property
    def nome_agressor(self): return self._get_encrypted(self._nome_agressor)
    @nome_agressor.setter
    def nome_agressor(self, value): self._nome_agressor = self._set_encrypted(value)
    
    @property
    def numero_processo(self): return self._get_encrypted(self._numero_processo)
    @numero_processo.setter
    def numero_processo(self, value): self._numero_processo = self._set_encrypted(value)

    @property
    def restricoes_impostas(self): return self._get_encrypted(self._restricoes_impostas)
    @restricoes_impostas.setter
    def restricoes_impostas(self, value): self._restricoes_impostas = self._set_encrypted(value)


class LogAcesso(db.Model):
    __tablename__ = 'logs_acesso'

    id = db.Column(db.Integer, primary_key=True)
    origem_acesso = db.Column(db.String(20), nullable=False)
    identificador = db.Column(db.String(255), nullable=False)
    ip_origem = db.Column(db.String(50), nullable=False)
    user_agent = db.Column(db.String(255), nullable=True)
    status_acesso = db.Column(db.String(50), nullable=False)
    detalhe_auditoria = db.Column(db.Text, nullable=True)
    data_evento = db.Column(db.DateTime, default=datetime.utcnow)

class AuditoriaOperacao(db.Model):
    __tablename__ = 'auditoria_operacoes'

    id = db.Column(db.Integer, primary_key=True)
    usuario_id = db.Column(db.Integer, db.ForeignKey('usuarios_sistema.id'), nullable=True)
    tabela_afetada = db.Column(db.String(50), nullable=False)
    registro_id = db.Column(db.Integer, nullable=True)
    tipo_operacao = db.Column(db.String(20), nullable=False)
    dados_antigos = db.Column(db.Text, nullable=True)
    dados_novos = db.Column(db.Text, nullable=True)
    data_operacao = db.Column(db.DateTime, default=datetime.utcnow)


class PedidoSocorro(db.Model):
    __tablename__ = 'pedidos_socorro'

    id = db.Column(db.Integer, primary_key=True)
    source = db.Column(db.String(50), nullable=False)
    user_id = db.Column(db.String(36), nullable=False) # UUID
    latitude = db.Column(db.Float, nullable=False)
    longitude = db.Column(db.Float, nullable=False)
    client_timestamp = db.Column(db.DateTime, nullable=True)
    metadata_alert = db.Column(db.Text, nullable=True) # JSON stored as text
    status = db.Column(db.String(20), default='PENDING', nullable=False)
    data_recebimento = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f'<PedidoSocorro {self.id} - {self.user_id}>'

