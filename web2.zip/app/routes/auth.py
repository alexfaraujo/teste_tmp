from flask import Blueprint, url_for, redirect, session, request, flash, render_template
from flask_login import login_user, logout_user, login_required, current_user
from app.extensions import oauth, db, login_manager
from app.models import UsuarioSistema, LogAcesso
from app.services.alert_service import AlertService
from datetime import datetime

auth_bp = Blueprint('auth', __name__)

@login_manager.user_loader
def load_user(user_id):
    return UsuarioSistema.query.get(int(user_id))

@auth_bp.route('/login')
def login():
    host = request.host.split(':')[0]
    if host == '0.0.0.0':
        redirect_uri = url_for('auth.authorize', _external=True).replace('0.0.0.0', 'localhost')
    else:
        redirect_uri = url_for('auth.authorize', _external=True)
    
    return oauth.google.authorize_redirect(redirect_uri)

@auth_bp.route('/authorize')
def authorize():
    ip_address = request.remote_addr
    
    if AlertService.check_suspicious_activity(ip_address):
        log = LogAcesso(
            origem_acesso='WEB',
            identificador='BLOCKED_IP',
            ip_origem=ip_address,
            status_acesso='FALHA_BLOQUEADO',
            detalhe_auditoria='Acesso bloqueado por tentativas excessivas',
            data_evento=datetime.utcnow()
        )
        db.session.add(log)
        db.session.commit()
        return "Acesso temporariamente bloqueado por segurança.", 403

    try:
        claims_options = {
            'iss': {
                'values': ['https://accounts.google.com', 'accounts.google.com']
            }
        }
        
        token = oauth.google.authorize_access_token(claims_options=claims_options)
        
        if 'id_token' in token:
            user_info = oauth.google.parse_id_token(token, nonce=None, claims_options=claims_options)
        else:
            user_info = oauth.google.userinfo()
            
        email = user_info.get('email')
        
        if not email:
             raise ValueError("Email not found in token")

        user = UsuarioSistema.query.filter_by(email=email).first()

        if user and user.ativo:
            login_user(user)
            
            log = LogAcesso(
                origem_acesso='WEB',
                identificador=email,
                ip_origem=ip_address,
                status_acesso='SUCESSO',
                user_agent=request.headers.get('User-Agent'),
                data_evento=datetime.utcnow()
            )
            db.session.add(log)
            db.session.commit()
            
            return redirect(url_for('admin.index'))
        else:
            log = LogAcesso(
                origem_acesso='WEB',
                identificador=email,
                ip_origem=ip_address,
                status_acesso='FALHA_NAO_AUTORIZADO',
                user_agent=request.headers.get('User-Agent'),
                detalhe_auditoria='Email não cadastrado ou inativo',
                data_evento=datetime.utcnow()
            )
            db.session.add(log)
            db.session.commit()
            
            AlertService.check_suspicious_activity(ip_address)
            
            return "Acesso Negado. Usuário não autorizado.", 403

    except Exception as e:
        log = LogAcesso(
            origem_acesso='WEB',
            identificador='UNKNOWN',
            ip_origem=ip_address,
            status_acesso='FALHA_ERRO',
            detalhe_auditoria=str(e),
            data_evento=datetime.utcnow()
        )
        db.session.add(log)
        db.session.commit()
        return f"Erro na autenticação: {str(e)}", 400

@auth_bp.route('/logout')
@login_required
def logout():
    logout_user()
    return "Deslogado com sucesso."
