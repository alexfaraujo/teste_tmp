from flask import Blueprint, request, jsonify
from app.models import AplicativoAutorizado, MulherProtegida, LogAcesso, PedidoSocorro
from app.extensions import db, csrf
import hashlib
from datetime import datetime

api_bp = Blueprint('api', __name__)

@api_bp.before_request
def check_csrf():
    if request.path.startswith('/api/'):
        csrf.exempt(api_bp)

def authenticate_api():
    api_key = request.headers.get('X-API-KEY')
    if not api_key:
        return None
    
    key_hash = hashlib.sha256(api_key.encode('utf-8')).hexdigest()
    
    app = AplicativoAutorizado.query.filter_by(api_key_hash=key_hash, ativo=True).first()
    return app

@api_bp.route('/v1/integracao/consultar-medida', methods=['POST'])
@csrf.exempt
def consultar_medida():
    app_auth = authenticate_api()
    
    data = request.get_json() or {}
    cpf_busca = data.get('cpf_busca')
    id_dispositivo = data.get('id_dispositivo', 'unknown')
    id_requisitante = data.get('id_requisitante', 'unknown')
    
    if not app_auth:
        log = LogAcesso(
            origem_acesso='API',
            identificador=f"App: {id_dispositivo} User: {id_requisitante}",
            ip_origem=request.remote_addr,
            user_agent=request.user_agent.string,
            status_acesso='FALHA_AUTH_API',
            detalhe_auditoria=f"Tentativa de acesso com chave inválida ou ausente."
        )
        db.session.add(log)
        db.session.commit()
        return jsonify({"erro": "Acesso não autorizado. Chave de API inválida."}), 401

    log = LogAcesso(
        origem_acesso='API',
        identificador=app_auth.nome_app,
        ip_origem=request.remote_addr,
        user_agent=request.user_agent.string,
        status_acesso='SUCESSO',
        detalhe_auditoria=f"Consulta CPF: {cpf_busca} | Disp: {id_dispositivo} | Req: {id_requisitante}"
    )
    db.session.add(log)
    db.session.commit()

    if not cpf_busca:
        return jsonify({"encontrado": false, "mensagem": "CPF não informado."}), 400

    cpf_hash = hashlib.sha256(cpf_busca.encode('utf-8')).hexdigest()
    mulher = MulherProtegida.query.filter_by(cpf_hash=cpf_hash).first()

    if mulher:
        return jsonify({
            "encontrado": True,
            "dados": {
                "nome": mulher.nome_completo,
                "medida_protetiva": {
                    "numero_processo": mulher.numero_processo,
                    "validade": mulher.validade_medida.strftime('%Y-%m-%d') if mulher.validade_medida else None,
                    "restricoes": mulher.restricoes_impostas,
                    "agressor": mulher.nome_agressor
                },
                "endereco": mulher.endereco_residencial,
                "telefone_emergencia": mulher.telefone_contato
            }
        }), 200
    else:
        return jsonify({
            "encontrado": False,
            "mensagem": "Nenhuma medida protetiva encontrada para este CPF."
        }), 400

@api_bp.route('/v1/alertas/novo', methods=['POST'])
@csrf.exempt
def receber_alerta():
    import json
    app_auth = authenticate_api()
    
    data = request.get_json() or {}
    
    # Extract fields
    source = data.get('source')
    user_id = data.get('user_id')
    location = data.get('location', {})
    latitude = location.get('latitude')
    longitude = location.get('longitude')
    client_timestamp_str = data.get('client_timestamp')
    metadata = data.get('metadata', {})
    
    # Log the attempt
    log_detail = f"Source: {source} | User: {user_id}"
    
    if not app_auth:
        log = LogAcesso(
            origem_acesso='API_SOS',
            identificador=f"Unknown",
            ip_origem=request.remote_addr,
            user_agent=request.user_agent.string,
            status_acesso='FALHA_AUTH_API',
            detalhe_auditoria=f"Tentativa de alerta sem auth válida. {log_detail}"
        )
        db.session.add(log)
        db.session.commit()
        return jsonify({"erro": "Acesso não autorizado."}), 401

    # Validate required fields
    if not all([source, user_id, latitude, longitude]):
        return jsonify({"erro": "Dados incompletos. source, user_id, latitude e longitude são obrigatórios."}), 400

    try:
        # Parse timestamp
        client_timestamp = None
        if client_timestamp_str:
            # Handle ISO format with timezone potentially
            try:
                client_timestamp = datetime.fromisoformat(client_timestamp_str)
            except ValueError:
                pass # Keep as None or handle error if strict

        # Create PedidoSocorro
        novo_pedido = PedidoSocorro(
            source=source,
            user_id=user_id,
            latitude=latitude,
            longitude=longitude,
            client_timestamp=client_timestamp,
            metadata_alert=json.dumps(metadata),
            status='PENDING'
        )
        
        db.session.add(novo_pedido)
        
        # Log success
        log = LogAcesso(
            origem_acesso='API_SOS',
            identificador=app_auth.nome_app,
            ip_origem=request.remote_addr,
            user_agent=request.user_agent.string,
            status_acesso='SUCESSO',
            detalhe_auditoria=f"Alerta recebido. ID: {novo_pedido.id} | {log_detail}"
        )
        db.session.add(log)
        db.session.commit()
        
        return jsonify({
            "mensagem": "Alerta recebido com sucesso.",
            "protocolo": novo_pedido.id,
            "status": "recebido"
        }), 201

    except Exception as e:
        db.session.rollback()
        return jsonify({"erro": f"Erro interno ao processar alerta: {str(e)}"}), 500

@api_bp.route('/v1/alertas', methods=['GET'])
@csrf.exempt
def listar_alertas():
    import json
    app_auth = authenticate_api()
    
    if not app_auth:
        return jsonify({"erro": "Acesso não autorizado."}), 401

    try:
        # Filter by status if provided
        status_filter = request.args.get('status')
        
        query = PedidoSocorro.query
        
        if status_filter:
            query = query.filter(PedidoSocorro.status == status_filter.upper())
            
        alertas = query.order_by(PedidoSocorro.data_recebimento.desc()).all()
        
        resultado = []
        for alerta in alertas:
            # Parse metadata if it's a string, otherwise use as is or empty dict
            metadata = {}
            if alerta.metadata_alert:
                try:
                    metadata = json.loads(alerta.metadata_alert)
                except:
                    metadata = {}
            
            # Format timestamp
            client_ts = None
            if alerta.client_timestamp:
                client_ts = alerta.client_timestamp.isoformat()

            resultado.append({
                "source": alerta.source,
                "user_id": alerta.user_id,
                "location": {
                    "latitude": alerta.latitude,
                    "longitude": alerta.longitude
                },
                "client_timestamp": client_ts,
                "metadata": metadata,
                "status": alerta.status, # Valid to include status even if not strictly in sample
                "protocolo": alerta.id
            })
            
        return jsonify(resultado), 200

    except Exception as e:
        return jsonify({"erro": f"Erro interno ao listar alertas: {str(e)}"}), 500
