from flask_admin import AdminIndexView, expose
from flask_login import current_user
from flask import redirect, url_for, flash
from sqlalchemy import func
from datetime import datetime, date

class SecureAdminIndexView(AdminIndexView):
    def is_accessible(self):
        return current_user.is_authenticated and getattr(current_user, 'ativo', False)

    def inaccessible_callback(self, name, **kwargs):
        if not current_user.is_authenticated:
             flash("Faça login para acessar.", "warning")
        return redirect(url_for('auth.login'))

    @expose('/')
    def index(self):
        if not self.is_accessible():
            return self.inaccessible_callback(name='index')

        from app.models import MulherProtegida, UsuarioSistema, LogAcesso, AuditoriaOperacao
        
        total_mulheres = MulherProtegida.query.count()
        total_usuarios = UsuarioSistema.query.count()
        
        total_falhas_hoje = LogAcesso.query.filter(
            LogAcesso.status_acesso.like('FALHA%'),
            func.date(LogAcesso.data_evento) == date.today()
        ).count()

        logs_recentes = LogAcesso.query.order_by(LogAcesso.data_evento.desc()).limit(5).all()
        auditorias_recentes = AuditoriaOperacao.query.order_by(AuditoriaOperacao.data_operacao.desc()).limit(5).all()

        return self.render('admin/dashboard.html', 
                           total_mulheres=total_mulheres,
                           total_usuarios=total_usuarios,
                           total_falhas_hoje=total_falhas_hoje,
                           logs_recentes=logs_recentes,
                           auditorias_recentes=auditorias_recentes)
