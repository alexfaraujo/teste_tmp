from cryptography.fernet import Fernet
from flask import current_app

class CryptoService:
    @staticmethod
    def encrypt(data):
        if not data:
            return None
        f = Fernet(current_app.config['ENCRYPTION_KEY'])
        return f.encrypt(data.encode('utf-8')).decode('utf-8')

    @staticmethod
    def decrypt(token):
        if not token:
            return None
        f = Fernet(current_app.config['ENCRYPTION_KEY'])
        try:
            return f.decrypt(token.encode('utf-8')).decode('utf-8')
        except Exception:
            return None
