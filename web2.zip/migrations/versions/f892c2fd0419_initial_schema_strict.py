"""Initial schema strict

Revision ID: f892c2fd0419
Revises: 
Create Date: 2025-12-15 19:57:46.074612

"""
from alembic import op
import sqlalchemy as sa


revision = 'f892c2fd0419'
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    op.create_table('aplicativos_autorizados',
    sa.Column('id', sa.Integer(), nullable=False),
    sa.Column('nome_app', sa.String(length=100), nullable=False),
    sa.Column('api_key_hash', sa.String(length=255), nullable=False),
    sa.Column('ativo', sa.Boolean(), nullable=True),
    sa.Column('data_criacao', sa.DateTime(), nullable=True),
    sa.PrimaryKeyConstraint('id'),
    sa.UniqueConstraint('api_key_hash')
    )
    op.create_table('logs_acesso',
    sa.Column('id', sa.Integer(), nullable=False),
    sa.Column('origem_acesso', sa.String(length=20), nullable=False),
    sa.Column('identificador', sa.String(length=255), nullable=False),
    sa.Column('ip_origem', sa.String(length=50), nullable=False),
    sa.Column('user_agent', sa.String(length=255), nullable=True),
    sa.Column('status_acesso', sa.String(length=50), nullable=False),
    sa.Column('detalhe_auditoria', sa.Text(), nullable=True),
    sa.Column('data_evento', sa.DateTime(), nullable=True),
    sa.PrimaryKeyConstraint('id')
    )
    op.create_table('mulheres_protegidas',
    sa.Column('id', sa.Integer(), nullable=False),
    sa.Column('nome_completo', sa.Text(), nullable=False),
    sa.Column('cpf', sa.Text(), nullable=False),
    sa.Column('data_nascimento', sa.Text(), nullable=True),
    sa.Column('telefone_contato', sa.Text(), nullable=True),
    sa.Column('endereco_residencial', sa.Text(), nullable=True),
    sa.Column('nome_agressor', sa.Text(), nullable=True),
    sa.Column('numero_processo', sa.Text(), nullable=True),
    sa.Column('restricoes_impostas', sa.Text(), nullable=True),
    sa.Column('data_expedicao', sa.Date(), nullable=True),
    sa.Column('validade_medida', sa.Date(), nullable=True),
    sa.Column('data_registro', sa.DateTime(), nullable=True),
    sa.Column('data_atualizacao', sa.DateTime(), nullable=True),
    sa.PrimaryKeyConstraint('id'),
    sa.UniqueConstraint('cpf')
    )
    op.create_table('usuarios_sistema',
    sa.Column('id', sa.Integer(), nullable=False),
    sa.Column('email', sa.String(length=120), nullable=False),
    sa.Column('nome_completo', sa.String(length=100), nullable=False),
    sa.Column('ativo', sa.Boolean(), nullable=True),
    sa.Column('data_cadastro', sa.DateTime(), nullable=True),
    sa.PrimaryKeyConstraint('id'),
    sa.UniqueConstraint('email')
    )
    op.create_table('auditoria_operacoes',
    sa.Column('id', sa.Integer(), nullable=False),
    sa.Column('usuario_id', sa.Integer(), nullable=True),
    sa.Column('tabela_afetada', sa.String(length=50), nullable=False),
    sa.Column('registro_id', sa.Integer(), nullable=True),
    sa.Column('tipo_operacao', sa.String(length=20), nullable=False),
    sa.Column('dados_antigos', sa.Text(), nullable=True),
    sa.Column('dados_novos', sa.Text(), nullable=True),
    sa.Column('data_operacao', sa.DateTime(), nullable=True),
    sa.ForeignKeyConstraint(['usuario_id'], ['usuarios_sistema.id'], ),
    sa.PrimaryKeyConstraint('id')
    )


def downgrade():
    op.drop_table('auditoria_operacoes')
    op.drop_table('usuarios_sistema')
    op.drop_table('mulheres_protegidas')
    op.drop_table('logs_acesso')
    op.drop_table('aplicativos_autorizados')
