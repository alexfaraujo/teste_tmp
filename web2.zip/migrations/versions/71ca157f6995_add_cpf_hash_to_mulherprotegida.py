"""Add cpf_hash to MulherProtegida

Revision ID: 71ca157f6995
Revises: f892c2fd0419
Create Date: 2025-12-15 21:49:33.696980

"""
from alembic import op
import sqlalchemy as sa


revision = '71ca157f6995'
down_revision = 'f892c2fd0419'
branch_labels = None
depends_on = None


def upgrade():
    with op.batch_alter_table('mulheres_protegidas', schema=None) as batch_op:
        batch_op.add_column(sa.Column('cpf_hash', sa.String(length=64), nullable=True))
        batch_op.create_unique_constraint(None, ['cpf_hash'])



def downgrade():
    with op.batch_alter_table('mulheres_protegidas', schema=None) as batch_op:
        batch_op.drop_constraint(None, type_='unique')
        batch_op.drop_column('cpf_hash')

