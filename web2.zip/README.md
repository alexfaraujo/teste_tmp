# Sistema de Gestão - Polícia TL

Este é um sistema web desenvolvido para gestão de ocorrências e monitoramento, focado na segurança pública. O sistema permite o cadastro de usuários, gestão de ocorrências (Mulher Protegida), e visualização de relatórios.

## Funcionalidades

- **Autenticação e Autorização**: Sistema de login seguro com diferentes níveis de acesso (Admin, Operador).
- **Gestão de Usuários**: Cadastro, edição e remoção de usuários.
- **Mulher Protegida**: Módulo para cadastro e acompanhamento de medidas protetivas.
- **Auditoria**: Registro de ações realizadas no sistema para segurança e rastreabilidade.
- **API Mobile**: Endpoints para integração com aplicativos móveis.

---

## Guia do Usuário

### Acesso ao Sistema
1. Acesse a URL fornecida pelo administrador.
2. Na tela de login, insira seu CPF e senha.
3. Clique em "Entrar".

### Painel Principal
Após o login, você verá o painel principal com as opções disponíveis para seu perfil.
- **Admin**: Acesso total a usuários, configurações e relatórios.
- **Operador**: Acesso focado no cadastro e consulta de ocorrências.

### Gestão de Ocorrências
1. Navegue até a seção "Mulher Protegida".
2. Para adicionar um novo registro, clique em "Novo".
3. Preencha os dados solicitados (Nome, CPF, Endereço, etc.).
4. Clique em "Salvar".

---

## Guia do Desenvolvedor

### Pré-requisitos
- Python 3.8+
- PostgreSQL
- Virtualenv (recomendado)

### Instalação

1. Clone o repositório:
   ```bash
   git clone <url-do-repositorio>
   cd Sistema-web
   ```

2. Crie e ative um ambiente virtual:
   ```bash
   python3 -m venv venv
   source venv/bin/activate  # Linux/Mac
   # ou
   venv\Scripts\activate  # Windows
   ```

3. Instale as dependências:
   ```bash
   pip install -r requirements.txt
   ```

### Configuração

1. Crie um arquivo `.env` na raiz do projeto com as seguintes variáveis:
   ```env
   FLASK_APP=run.py
   FLASK_ENV=development
   SECRET_KEY=sua_chave_secreta_aqui
   SQLALCHEMY_DATABASE_URI=postgresql://usuario:senha@localhost:5432/nome_do_banco
   JWT_SECRET_KEY=sua_chave_jwt
   ```

### Banco de Dados

1. Inicialize o banco de dados:
   ```bash
   flask db upgrade
   ```

2. (Opcional) Popule o banco com dados iniciais:
   ```bash
   python seed.py
   ```
   Isso criará um usuário admin padrão (verifique o arquivo `seed.py` ou `seeds/admin_seeder.py` para credenciais).

### Executando o Projeto

Para rodar o servidor de desenvolvimento:

```bash
python run.py
```
O sistema estará acessível em `http://localhost:5000`.

### Estrutura do Projeto

- `app/`: Código fonte da aplicação.
  - `models.py`: Modelos do banco de dados (SQLAlchemy).
  - `routes/`: Rotas e controllers.
  - `templates/`: Arquivos HTML (Jinja2).
  - `static/`: Arquivos CSS, JS e imagens.
  - `services/`: Lógica de negócios e serviços auxiliares.
- `migrations/`: Scripts de migração do banco de dados.
- `config.py`: Configurações da aplicação.

### API

A aplicação possui endpoints RESTful em `/api/`. A autenticação é feita via JWT.
Consulte a documentação da API (se disponível) ou o arquivo `app/routes/api.py` para detalhes dos endpoints.
