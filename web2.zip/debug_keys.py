from app import create_app
from app.models import AplicativoAutorizado
import hashlib

app = create_app('default')

with app.app_context():
    apps = AplicativoAutorizado.query.all()
    print("APPs no banco:")
    for a in apps:
        print(f"Nome: {a.nome_app}, Hash: {a.api_key_hash}")
        
    print("\nVerificando 'minha_chave_secreta':")
    key = "minha_chave_secreta"
    target_hash = hashlib.sha256(key.encode('utf-8')).hexdigest()
    print(f"Hash esperado: {target_hash}")
    
    match = AplicativoAutorizado.query.filter_by(api_key_hash=target_hash, ativo=True).first()
    if match:
        print(f"MATCH ENCONTRADO! App: {match.nome_app}")
    else:
        print("NENHUM match encontrado.")
