from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from models import Base, Estudante, Atividade, AtividadeRealizada, Configuracao

# Criar conexão com o banco de dados
DATABASE_URL = "sqlite:///atividades.db"
engine = create_engine(DATABASE_URL)

# Criar sessão
SessionLocal = sessionmaker(bind=engine)

def init_db():
    Base.metadata.create_all(engine)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def validar_estudante(db, email):
    return db.query(Estudante).filter_by(email=email, ativo=True).first()

def validar_atividade(db, codigo):
    return db.query(Atividade).filter_by(codigo=codigo, ativo=True).first()

def get_config(db, chave):
    config = db.query(Configuracao).filter(Configuracao.chave == chave).first()
    return config.valor if config else None

def verificar_limite_tentativas(db, id_estudante, id_atividade):
    # Buscar configuração de limite de tentativas
    config = db.query(Configuracao).filter_by(
        chave='limite_tentativas_atividade',
        ativo=True
    ).first()
    
    limite_tentativas = int(config.valor) if config else 5  # valor padrão se não encontrar config
    
    # Contar tentativas do estudante para esta atividade
    tentativas = db.query(AtividadeRealizada).filter_by(
        id_estudante=id_estudante,
        id_atividade=id_atividade,
        ativo=True
    ).count()
    
    return tentativas < limite_tentativas, limite_tentativas, tentativas 