import os
import sys

# Adicionar o diretório pai ao path do Python
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from database import SessionLocal, init_db
from models import AtividadeRealizada

def limpar_atividades_realizadas():
    db = SessionLocal()
    try:
        # Confirmar com o usuário
        print("ATENÇÃO: Isso irá remover TODAS as atividades realizadas do banco de dados.")
        print("Os arquivos .c enviados pelos estudantes serão mantidos.")
        confirmacao = input("Digite 'CONFIRMAR' para prosseguir: ")
        
        if confirmacao != "CONFIRMAR":
            print("Operação cancelada.")
            return
            
        # Contar registros antes
        total_antes = db.query(AtividadeRealizada).count()
        
        # Excluir todos os registros (soft delete)
        db.query(AtividadeRealizada).update({"ativo": False})
        
        # Commit das alterações
        db.commit()
        
        print(f"Operação concluída com sucesso!")
        print(f"Total de registros desativados: {total_antes}")
        
    except Exception as e:
        db.rollback()
        print(f"Erro ao limpar atividades: {str(e)}")
    finally:
        db.close()

if __name__ == "__main__":
    limpar_atividades_realizadas() 