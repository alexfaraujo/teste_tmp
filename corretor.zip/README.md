# Corretor de Algoritmos

Sistema web para correção automática de algoritmos.

## Requisitos

- Python 3.8+
- pip

## Instalação

1. Clone o repositório
2. Crie um ambiente virtual:
```bash
python -m venv venv
source venv/bin/activate  # Linux/Mac
# ou
.\venv\Scripts\activate  # Windows
```
3. Instale as dependências:
```bash
pip install -r requirements.txt
```

## Configuração

1. Crie um arquivo `.env` na raiz do projeto com as seguintes variáveis:
```
FLASK_APP=app.py
FLASK_ENV=production
SECRET_KEY=sua_chave_secreta
DATABASE_URL=sqlite:///atividades.db
```

## Execução

Para desenvolvimento:
```bash
flask run
```

Para produção:
```bash
gunicorn app:app
```

## Estrutura do Projeto

- `app.py` - Aplicação principal
- `models.py` - Modelos de dados
- `auth.py` - Autenticação
- `admin_routes.py` - Rotas administrativas
- `compiler.py` - Compilador de algoritmos
- `static/` - Arquivos estáticos
- `templates/` - Templates HTML
- `algoritmos/` - Algoritmos de exemplo 