from functools import wraps
from flask import session, redirect, url_for, flash, request
from datetime import datetime, timedelta
from models import Admin, Log
from database import SessionLocal

def registrar_log(tipo, username, detalhes=None):
    db = SessionLocal()
    try:
        log = Log(
            tipo=tipo,
            username=username,
            ip=request.remote_addr,
            detalhes=detalhes
        )
        db.add(log)
        db.commit()
    except Exception as e:
        db.rollback()
        print(f"Erro ao registrar log: {str(e)}")
    finally:
        db.close()

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'admin_id' not in session:
            return redirect(url_for('admin.login'))
        
        # Verificar tempo de inatividade (30 minutos)
        if 'last_activity' in session:
            last_activity = datetime.fromisoformat(session['last_activity'])
            if datetime.now() - last_activity > timedelta(minutes=30):
                session.clear()
                flash('Sessão expirada. Por favor, faça login novamente.')
                return redirect(url_for('admin.login'))
        
        # Atualizar último acesso
        session['last_activity'] = datetime.now().isoformat()
        return f(*args, **kwargs)
    return decorated_function

def check_brute_force():
    if 'login_attempts' not in session:
        session['login_attempts'] = 0
        session['last_attempt'] = datetime.now().isoformat()
    
    # Resetar tentativas após 15 minutos
    if 'last_attempt' in session:
        last_attempt = datetime.fromisoformat(session['last_attempt'])
        if datetime.now() - last_attempt > timedelta(minutes=15):
            session['login_attempts'] = 0
    
    session['login_attempts'] += 1
    session['last_attempt'] = datetime.now().isoformat()
    
    return session['login_attempts'] <= 5 