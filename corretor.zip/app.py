from flask import Flask, render_template, request, flash
from compiler import CCompiler
import os
from datetime import datetime
from database import (
    init_db, SessionLocal, validar_estudante, validar_atividade, 
    verificar_limite_tentativas
)
from models import AtividadeRealizada
from admin_routes import admin_bp, init_admin
import json

app = Flask(__name__)
app.secret_key = 'sua_chave_secreta_aqui'  # Use uma chave segura em produção

# Registrar blueprint do admin e inicializar
app.register_blueprint(admin_bp)
init_admin(app)

# Inicializa o banco de dados
init_db()

@app.template_filter('from_json')
def from_json(value):
    try:
        return json.loads(value)
    except:
        return []

def criar_diretorio(email, codigo_atividade):
    caminho = os.path.join('algoritmos', email, codigo_atividade)
    os.makedirs(caminho, exist_ok=True)
    return caminho

def gerar_nome_arquivo(codigo_atividade, arquivo_original):
    # Obtém o nome do arquivo original sem a extensão
    nome_arquivo = os.path.splitext(arquivo_original)[0]
    # Obtém a data e hora atual formatada
    data_hora = datetime.now().strftime('%Y%m%d-%H%M%S')
    # Gera o novo nome do arquivo
    novo_nome = f"{codigo_atividade}-{nome_arquivo}-{data_hora}.c"
    return novo_nome

def criar_resumo_execucao(resultados_testes, is_admin=False):
    resumo_execucao = []
    for i, teste in enumerate(resultados_testes, 1):
        resumo_teste = {
            'numero': i,
            'status': teste['status'],
            'mensagem': teste['mensagem'],
            'saida_obtida': teste['saida_obtida'],
            'peso': teste['peso'],
            'visivel': teste['visivel'],
            'entrada': teste['entrada'],
            'saida_esperada': teste['saida_esperada']
        }
        resumo_execucao.append(resumo_teste)
    return resumo_execucao

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        db = SessionLocal()
        try:
            email = request.form['email']
            codigo_atividade = request.form['codigo_atividade']
            arquivo = request.files['arquivo']

            # Validar arquivo
            if not arquivo or not arquivo.filename.endswith('.c'):
                flash('Por favor, envie um arquivo .c válido')
                return render_template('index.html')

            # Validar estudante
            estudante = validar_estudante(db, email)
            if not estudante:
                flash('Email não encontrado ou inativo. Verifique se você está cadastrado no sistema.')
                return render_template('index.html')

            # Validar atividade
            atividade = validar_atividade(db, codigo_atividade)
            if not atividade:
                flash('Código de atividade inválido ou atividade inativa. Verifique o código informado.')
                return render_template('index.html')

            # Verificar se a atividade está disponível para alguma das classes do estudante
            classes_estudante = set(estudante.classes)
            classes_atividade = set(atividade.classes)
            
            if not classes_estudante.intersection(classes_atividade):
                flash('Esta atividade não está disponível para suas classes. '
                      'Verifique se você está matriculado na classe correta.')
                return render_template('index.html')

            # Verificar limite de tentativas
            pode_enviar, limite, tentativas = verificar_limite_tentativas(
                db, estudante.id, atividade.id
            )
            
            if not pode_enviar:
                flash(f'Você já atingiu o limite de {limite} tentativas para esta atividade. ' 
                      f'Tentativas realizadas: {tentativas}')
                return render_template('index.html')

            # Gerar nome e salvar arquivo
            novo_nome_arquivo = gerar_nome_arquivo(codigo_atividade, arquivo.filename)
            caminho_diretorio = criar_diretorio(email, codigo_atividade)
            caminho_arquivo = os.path.join(caminho_diretorio, novo_nome_arquivo)
            arquivo.save(caminho_arquivo)

            # Compila e executa com casos de teste
            compilador = CCompiler(caminho_arquivo)
            resultado = compilador.executar_casos_teste(
                atividade.casos_teste,
                tempo_limite=atividade.tempo_limite
            )

            # Criar resumo para estudante (mantém testes ocultos)
            resumo_execucao = criar_resumo_execucao(resultado['resultados_testes'], is_admin=False)

            # Registrar atividade realizada
            atividade_realizada = AtividadeRealizada(
                id_estudante=estudante.id,
                id_atividade=atividade.id,
                nome_arquivo=novo_nome_arquivo,
                resultado_compilacao=str(resultado['compilacao'])[:500],
                resultado_execucao=json.dumps(resumo_execucao, ensure_ascii=False)[:500],
                resultados_testes=resultado['resultados_testes'],  # Salva todos os dados
                nota=resultado['nota']
            )
            
            try:
                db.add(atividade_realizada)
                db.commit()
                print("Atividade realizada registrada com sucesso!")
            except Exception as e:
                print(f"Erro ao registrar atividade: {str(e)}")
                db.rollback()
                raise

            # Após registrar a atividade com sucesso
            _, limite_tentativas, tentativa_atual = verificar_limite_tentativas(
                db, estudante.id, atividade.id
            )

            return render_template('resultado.html', 
                                 resultado=resultado,
                                 email=email,
                                 codigo_atividade=codigo_atividade,
                                 nome_arquivo=novo_nome_arquivo,
                                 nome_estudante=estudante.nome,
                                 tentativa_atual=tentativa_atual,
                                 limite_tentativas=limite_tentativas)

        except Exception as e:
            db.rollback()
            flash(f'Erro ao processar a requisição: {str(e)}')
            return render_template('index.html')
        finally:
            db.close()

    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True, port=5001, host='0.0.0.0') 