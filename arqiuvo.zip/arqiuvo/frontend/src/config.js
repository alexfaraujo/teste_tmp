/**
 * Configuração auxiliar de API para resolver dinamicamente o endereço do Backend FastAPI.
 * Evita o erro 'localhost' em dispositivos móveis conectados via IP da rede local (ex: http://192.168.x.x:3000).
 */
export const getApiUrl = (endpoint = '') => {
  const envUrl = import.meta.env.VITE_API_URL;
  if (envUrl) {
    return `${envUrl}${endpoint}`;
  }
  
  // Utiliza o mesmo hostname (IP da rede local ou localhost) que o usuário acessou no navegador
  const hostname = typeof window !== 'undefined' && window.location.hostname 
    ? window.location.hostname 
    : 'localhost';
    
  return `http://${hostname}:8000${endpoint}`;
};
