import React, { useState } from 'react';
import Splash from './components/Splash';
import Menu from './components/Menu';
import CameraView from './components/CameraView';
import QuizView from './components/QuizView';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState('splash'); // 'splash' | 'menu' | 'camera' | 'quiz'

  // Estatísticas do treinamento armazenadas na memória da sessão (reseta ao atualizar a página)
  const [stats, setStats] = useState({
    totalAttempts: 0,
    correctAnswers: 0
  });

  const handleQuizAnswer = (isCorrect) => {
    setStats((prev) => ({
      totalAttempts: prev.totalAttempts + 1,
      correctAnswers: prev.correctAnswers + (isCorrect ? 1 : 0)
    }));
  };

  return (
    <div style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column' }}>
      {currentScreen === 'splash' && (
        <Splash onStart={() => setCurrentScreen('menu')} />
      )}

      {currentScreen === 'menu' && (
        <div className="page-transition">
          <Menu
            stats={stats}
            onNavigate={(screen) => setCurrentScreen(screen)}
            onBack={() => setCurrentScreen('splash')}
          />
        </div>
      )}

      {currentScreen === 'camera' && (
        <div className="page-transition">
          <CameraView onBack={() => setCurrentScreen('menu')} />
        </div>
      )}

      {currentScreen === 'quiz' && (
        <div className="page-transition">
          <QuizView
            onAnswer={handleQuizAnswer}
            onBack={() => setCurrentScreen('menu')}
          />
        </div>
      )}
    </div>
  );
}
