import React, { useEffect } from 'react';

export default function CelebrationModal({ question, onNext }) {
  useEffect(() => {
    // Cria os confetes animados dinamicamente
    const container = document.createElement('div');
    container.className = 'confetti-container';
    document.body.appendChild(container);

    const colors = ['#0F9D76', '#F59E0B', '#3B82F6', '#EC4899', '#10B981', '#8B5CF6'];

    for (let i = 0; i < 40; i++) {
      const piece = document.createElement('div');
      piece.className = 'confetti-piece';
      piece.style.left = `${Math.random() * 100}%`;
      piece.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
      piece.style.animationDelay = `${Math.random() * 1.5}s`;
      piece.style.transform = `rotate(${Math.random() * 360}deg)`;
      container.appendChild(piece);
    }

    return () => {
      if (document.body.contains(container)) {
        document.body.removeChild(container);
      }
    };
  }, []);

  return (
    <div style={{
      position: 'absolute',
      inset: 0,
      backgroundColor: 'rgba(6, 78, 59, 0.75)',
      backdropFilter: 'blur(4px)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 1000,
      padding: 24
    }}>
      <div className="pop-in" style={{
        backgroundColor: '#FFFFFF',
        borderRadius: 28,
        padding: '32px 24px',
        textAlign: 'center',
        width: '100%',
        maxWidth: 360,
        boxShadow: '0 20px 40px rgba(0,0,0,0.2)'
      }}>
        <div style={{ fontSize: '4.5rem', marginBottom: 12 }}>
          🎉
        </div>

        <h3 style={{ fontSize: '1.8rem', color: '#064E3B', fontWeight: 900, marginBottom: 8 }}>
          Parabéns!
        </h3>

        <p style={{ fontSize: '1.1rem', color: '#059669', fontWeight: 700, marginBottom: 16 }}>
          Você acertou a emoção <br />
          <span style={{ fontSize: '1.4rem', color: '#064E3B' }}>
            "{question?.correct_option}" {question?.emoji}
          </span>
        </p>

        <p style={{ fontSize: '0.9rem', color: '#6B7280', marginBottom: 24 }}>
          Excelente trabalho de reconhecimento facial!
        </p>

        <button className="btn btn-primary" onClick={onNext}>
          Próxima Emoção ▶
        </button>
      </div>
    </div>
  );
}
