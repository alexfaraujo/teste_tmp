import React from 'react';

export default function Splash({ onStart }) {
  return (
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'space-between',
      height: '100%',
      padding: '48px 24px 32px 24px',
      textAlign: 'center',
      overflow: 'hidden'
    }}>
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
        {/* Ícone de Logo Sorridente com Animação Elastic Pop-In & Glow */}
        <div className="splash-logo-anim" style={{
          width: 140,
          height: 140,
          backgroundColor: '#0F9D76',
          borderRadius: 38,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          marginBottom: 28
        }}>
          <div style={{
            width: 90,
            height: 90,
            backgroundColor: '#FFFFFF',
            borderRadius: '50%',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: '3.2rem'
          }}>
            😊
          </div>
        </div>

        {/* Título, Badge e Slogan com Animação de Deslizar do Fundo */}
        <div className="splash-text-anim">
          <h1 style={{
            fontSize: '2.5rem',
            fontWeight: 900,
            color: '#064E3B',
            marginBottom: 8,
            lineHeight: 1.1,
            letterSpacing: '-0.5px'
          }}>
            Face Trainer
          </h1>

          <div className="badge-tea" style={{ marginBottom: 16 }}>
            TEA
          </div>

          <p style={{
            color: '#4B5563',
            fontSize: '1.15rem',
            fontWeight: 600,
            maxWidth: 280,
            lineHeight: 1.4
          }}>
            Aprenda emoções de um jeito divertido!
          </p>
        </div>
      </div>

      {/* Botões de Ação com Animação de Entrada Deslizante Staggered */}
      <div className="splash-actions-anim" style={{ width: '100%', display: 'flex', flexDirection: 'column', gap: 12 }}>
        <button className="btn btn-primary" onClick={onStart}>
          Começar ▶
        </button>

        <button className="btn btn-outline" disabled style={{ opacity: 0.6 }}>
          Já tenho conta (v2)
        </button>

        <span style={{ fontSize: '0.8rem', color: '#9CA3AF', marginTop: 8 }}>
          v1.0.0 • Protótipo Web
        </span>
      </div>
    </div>
  );
}
