import React from 'react';

export default function Menu({ stats, onNavigate, onBack }) {
  const totalAttempts = stats?.totalAttempts || 0;
  const correctAnswers = stats?.correctAnswers || 0;
  
  // Cálculo percentual da quantidade total de tentativas pelos acertos
  const percentage = totalAttempts > 0 
    ? Math.round((correctAnswers / totalAttempts) * 100) 
    : 0;

  return (
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      height: '100%',
      padding: '24px 20px',
      overflowY: 'auto'
    }}>
      {/* Header do Usuário */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginBottom: 20
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{
            width: 44,
            height: 44,
            borderRadius: '50%',
            backgroundColor: '#D1E7DD',
            color: '#0F9D76',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: '1.4rem'
          }}>
            🌿
          </div>
          <div>
            <span style={{ fontSize: '0.85rem', color: '#6B7280', fontWeight: 600 }}>Olá,</span>
            <h2 style={{ fontSize: '1.2rem', color: '#064E3B', fontWeight: 800, lineHeight: 1 }}>
              Aprendiz
            </h2>
          </div>
        </div>

        <button
          onClick={onBack}
          style={{
            background: 'none',
            border: 'none',
            fontSize: '1.4rem',
            cursor: 'pointer',
            padding: 8,
            color: '#0F9D76'
          }}
          title="Voltar ao início"
        >
          ⚙️
        </button>
      </div>

      {/* Banner de Desempenho Dinâmico em Memória */}
      <div style={{
        backgroundColor: '#064E3B',
        color: '#FFFFFF',
        borderRadius: 20,
        padding: '18px 20px',
        marginBottom: 24,
        boxShadow: '0 8px 20px rgba(6, 78, 59, 0.15)'
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
          <span style={{ fontWeight: 700, fontSize: '0.95rem' }}>Seu Desempenho</span>
          <span style={{ color: '#FBF06F', fontWeight: 800, fontSize: '0.9rem' }}>
            ★ [{correctAnswers}] estrelas
          </span>
        </div>
        <div style={{
          backgroundColor: 'rgba(255, 255, 255, 0.2)',
          borderRadius: 999,
          height: 10,
          overflow: 'hidden',
          marginTop: 8
        }}>
          <div style={{
            backgroundColor: '#F59E0B',
            width: `${percentage}%`,
            height: '100%',
            borderRadius: 999,
            transition: 'width 0.5s ease-in-out'
          }} />
        </div>
        <span style={{ fontSize: '0.75rem', color: '#A7F3D0', display: 'block', marginTop: 6, textAlign: 'right' }}>
          {totalAttempts === 0
            ? "Suba de nível praticando no Treinar!"
            : `${percentage}% de acerto (${correctAnswers}/${totalAttempts} tentativas)`}
        </span>
      </div>

      {/* Grid de 4 Botões / Funcionalidades */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: '1fr 1fr',
        gap: 16,
        marginBottom: 24
      }}>
        {/* 1. Treinar Emoções */}
        <div
          onClick={() => onNavigate('quiz')}
          style={{
            backgroundColor: '#FFFFFF',
            borderRadius: 20,
            padding: 20,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            textAlign: 'center',
            boxShadow: '0 4px 14px rgba(0,0,0,0.06)',
            cursor: 'pointer',
            border: '2px solid #D1E7DD',
            transition: 'all 0.2s ease'
          }}
          onMouseEnter={(e) => e.currentTarget.style.borderColor = '#0F9D76'}
          onMouseLeave={(e) => e.currentTarget.style.borderColor = '#D1E7DD'}
        >
          <div style={{ fontSize: '2.5rem', marginBottom: 8 }}>🎯</div>
          <span style={{ fontWeight: 800, color: '#064E3B', fontSize: '1.1rem' }}>Treinar</span>
          <span style={{ fontSize: '0.8rem', color: '#6B7280' }}>Emoções 🎯</span>
        </div>

        {/* 2. Câmera Ao Vivo */}
        <div
          onClick={() => onNavigate('camera')}
          style={{
            backgroundColor: '#FFFFFF',
            borderRadius: 20,
            padding: 20,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            textAlign: 'center',
            boxShadow: '0 4px 14px rgba(0,0,0,0.06)',
            cursor: 'pointer',
            border: '2px solid #D1E7DD',
            transition: 'all 0.2s ease'
          }}
          onMouseEnter={(e) => e.currentTarget.style.borderColor = '#0F9D76'}
          onMouseLeave={(e) => e.currentTarget.style.borderColor = '#D1E7DD'}
        >
          <div style={{ fontSize: '2.5rem', marginBottom: 8 }}>📷</div>
          <span style={{ fontWeight: 800, color: '#064E3B', fontSize: '1.1rem' }}>Câmera</span>
          <span style={{ fontSize: '0.8rem', color: '#6B7280' }}>Ao vivo 📷</span>
        </div>

        {/* 3. Troféus (Desabilitado v2) */}
        <div style={{
          backgroundColor: '#F9FAFB',
          borderRadius: 20,
          padding: 20,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          textAlign: 'center',
          opacity: 0.6,
          cursor: 'not-allowed',
          border: '2px dashed #E5E7EB',
          position: 'relative'
        }}>
          <span style={{
            position: 'absolute',
            top: 10,
            right: 10,
            fontSize: '0.65rem',
            backgroundColor: '#E5E7EB',
            color: '#4B5563',
            padding: '2px 8px',
            borderRadius: 999,
            fontWeight: 700
          }}>
            Em breve v2
          </span>
          <div style={{ fontSize: '2.5rem', marginBottom: 8, filter: 'grayscale(0.8)' }}>🏆</div>
          <span style={{ fontWeight: 800, color: '#6B7280', fontSize: '1.1rem' }}>Troféus</span>
          <span style={{ fontSize: '0.8rem', color: '#9CA3AF' }}>Conquistas 🏆</span>
        </div>

        {/* 4. Status (Desabilitado v2) */}
        <div style={{
          backgroundColor: '#F9FAFB',
          borderRadius: 20,
          padding: 20,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          textAlign: 'center',
          opacity: 0.6,
          cursor: 'not-allowed',
          border: '2px dashed #E5E7EB',
          position: 'relative'
        }}>
          <span style={{
            position: 'absolute',
            top: 10,
            right: 10,
            fontSize: '0.65rem',
            backgroundColor: '#E5E7EB',
            color: '#4B5563',
            padding: '2px 8px',
            borderRadius: 999,
            fontWeight: 700
          }}>
            Em breve v2
          </span>
          <div style={{ fontSize: '2.5rem', marginBottom: 8, filter: 'grayscale(0.8)' }}>📊</div>
          <span style={{ fontWeight: 800, color: '#6B7280', fontSize: '1.1rem' }}>Status</span>
          <span style={{ fontSize: '0.8rem', color: '#9CA3AF' }}>Progresso 📊</span>
        </div>
      </div>

      {/* Desafio do Dia Banner */}
      <div style={{
        backgroundColor: '#FFFFFF',
        borderRadius: 20,
        padding: 16,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        border: '1px solid #E5E7EB',
        boxShadow: '0 2px 8px rgba(0,0,0,0.04)'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ fontSize: '1.8rem' }}>📅</div>
          <div>
            <span style={{ fontSize: '0.85rem', fontWeight: 800, color: '#064E3B' }}>Desafio do Dia</span>
            <p style={{ fontSize: '0.75rem', color: '#6B7280' }}>Identifique emoções hoje!</p>
          </div>
        </div>
        <button
          onClick={() => onNavigate('quiz')}
          style={{
            backgroundColor: '#0F9D76',
            color: '#FFFFFF',
            border: 'none',
            borderRadius: 999,
            padding: '8px 16px',
            fontWeight: 700,
            fontSize: '0.85rem',
            cursor: 'pointer'
          }}
        >
          Iniciar ▶
        </button>
      </div>
    </div>
  );
}
