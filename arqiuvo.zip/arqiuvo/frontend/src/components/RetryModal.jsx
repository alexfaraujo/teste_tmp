import React from 'react';

export default function RetryModal({ onRetry }) {
  return (
    <div style={{
      position: 'absolute',
      inset: 0,
      backgroundColor: 'rgba(31, 41, 55, 0.75)',
      backdropFilter: 'blur(4px)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 1000,
      padding: 24
    }}>
      <div className="pop-in shake-animation" style={{
        backgroundColor: '#FFFFFF',
        borderRadius: 28,
        padding: '32px 24px',
        textAlign: 'center',
        width: '100%',
        maxWidth: 360,
        boxShadow: '0 20px 40px rgba(0,0,0,0.2)'
      }}>
        <div style={{ fontSize: '4.5rem', marginBottom: 12 }}>
          💪✨
        </div>

        <h3 style={{ fontSize: '1.6rem', color: '#B91C1C', fontWeight: 900, marginBottom: 8 }}>
          Quase lá!
        </h3>

        <p style={{ fontSize: '1.1rem', color: '#374151', fontWeight: 700, marginBottom: 16 }}>
          Tente novamente! Você consegue!
        </p>

        <p style={{ fontSize: '0.9rem', color: '#6B7280', marginBottom: 24 }}>
          Observe atentamente a boca e as sobrancelhas do emoji.
        </p>

        <button className="btn btn-primary" onClick={onRetry} style={{ backgroundColor: '#D97706' }}>
          🔄 Tentar Novamente
        </button>
      </div>
    </div>
  );
}
