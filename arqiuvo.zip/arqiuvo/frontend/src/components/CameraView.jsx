import React, { useState, useRef, useEffect } from 'react';
import { getApiUrl } from '../config';

const EMOTION_EMOJIS = {
  "Felicidade": "😊",
  "Tristeza": "😢",
  "Raiva": "😠",
  "Surpresa": "😲",
  "Medo": "😨",
  "Nojo": "🤢",
  "Neutro": "😐"
};

export default function CameraView({ onBack }) {
  const [cameraActive, setCameraActive] = useState(false);
  const [capturedImage, setCapturedImage] = useState(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const [isMobileHttp, setIsMobileHttp] = useState(false);

  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const fileInputRef = useRef(null);
  const mobileCameraInputRef = useRef(null);

  // Inicializa o feed de vídeo da webcam (requer HTTPS ou localhost)
  const startCamera = async () => {
    try {
      setError(null);
      
      // Verifica se está em contexto HTTP inseguro em dispositivo móvel
      const isLocalhost = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1';
      const isHttps = window.location.protocol === 'https:';
      
      if (!isHttps && !isLocalhost) {
        setIsMobileHttp(true);
      }

      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setIsMobileHttp(true);
        setCameraActive(false);
        return;
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: { ideal: 640 }, height: { ideal: 480 }, facingMode: 'user' }
      });
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setCameraActive(true);
      }
    } catch (err) {
      console.warn("Câmera via WebRTC não permitida sem HTTPS/localhost. Usando captura nativa do celular.", err);
      setIsMobileHttp(true);
      setCameraActive(false);
    }
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject;
      stream.getTracks().forEach(track => track.stop());
      videoRef.current.srcObject = null;
    }
    setCameraActive(false);
  };

  useEffect(() => {
    startCamera();
    return () => stopCamera();
  }, []);

  // Tira foto pelo canvas HTML5 (modo PC / WebRTC)
  const capturePhoto = () => {
    if (!videoRef.current || !canvasRef.current) return;
    const video = videoRef.current;
    const canvas = canvasRef.current;
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;

    const ctx = canvas.getContext('2d');
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

    canvas.toBlob((blob) => {
      if (blob) {
        const file = new File([blob], "captured_photo.jpg", { type: "image/jpeg" });
        const imageUrl = URL.createObjectURL(blob);
        setCapturedImage(imageUrl);
        stopCamera();
        sendImageToBackend(file);
      }
    }, "image/jpeg", 0.9);
  };

  // Trata envio de arquivo ou foto capturada pela câmera nativa do celular
  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const imageUrl = URL.createObjectURL(file);
      setCapturedImage(imageUrl);
      stopCamera();
      sendImageToBackend(file);
    }
  };

  // Envia foto para o Backend usando a URL dinâmica da API (resolve IP da rede local automaticamente)
  const sendImageToBackend = async (file) => {
    setLoading(true);
    setError(null);
    setResult(null);

    const formData = new FormData();
    formData.append("file", file);

    const apiUrl = getApiUrl('/classify');

    try {
      const response = await fetch(apiUrl, {
        method: "POST",
        body: formData
      });

      if (!response.ok) {
        throw new Error(`Erro na API (${response.status})`);
      }

      const data = await response.json();
      setResult(data);
    } catch (err) {
      console.error(err);
      setError(`Não foi possível conectar ao servidor Backend (${apiUrl}). Verifique se o computador e o celular estão na mesma rede Wi-Fi.`);
    } finally {
      setLoading(false);
    }
  };

  const resetPhoto = () => {
    setCapturedImage(null);
    setResult(null);
    setError(null);
    startCamera();
  };

  return (
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      height: '100%',
      padding: '20px',
      overflowY: 'auto'
    }}>
      {/* Inputs Ocultos para Captura Nativa de Câmera do Celular */}
      <input
        type="file"
        accept="image/*"
        capture="user"
        ref={mobileCameraInputRef}
        onChange={handleFileChange}
        style={{ display: 'none' }}
      />
      <input
        type="file"
        accept="image/*"
        ref={fileInputRef}
        onChange={handleFileChange}
        style={{ display: 'none' }}
      />

      {/* Top bar */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
        <button
          onClick={onBack}
          style={{
            backgroundColor: '#E5E7EB',
            border: 'none',
            borderRadius: '50%',
            width: 40,
            height: 40,
            cursor: 'pointer',
            fontSize: '1.2rem',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}
        >
          ←
        </button>
        <h3 style={{ fontSize: '1.2rem', fontWeight: 800, color: '#064E3B' }}>Câmera Ao Vivo</h3>
        <div style={{ width: 40 }} />
      </div>

      {/* Área Principal de Câmera / Preview */}
      <div style={{
        flex: 1,
        backgroundColor: '#FFFFFF',
        borderRadius: 24,
        padding: 16,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        boxShadow: '0 8px 24px rgba(0,0,0,0.06)',
        position: 'relative',
        overflow: 'hidden',
        minHeight: 320
      }}>
        <canvas ref={canvasRef} style={{ display: 'none' }} />

        {!capturedImage && (
          <div style={{ width: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
            {cameraActive ? (
              <>
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  muted
                  style={{
                    width: '100%',
                    maxHeight: 280,
                    objectFit: 'cover',
                    borderRadius: 16,
                    transform: 'scaleX(-1)',
                    backgroundColor: '#000000'
                  }}
                />
                <button
                  className="btn btn-primary"
                  onClick={capturePhoto}
                  style={{ marginTop: 16 }}
                >
                  📸 Tirar Foto
                </button>
              </>
            ) : (
              <div style={{
                textAlign: 'center',
                padding: '24px 16px',
                backgroundColor: '#F3F4F6',
                borderRadius: 20,
                width: '100%'
              }}>
                <div style={{ fontSize: '3.5rem', marginBottom: 12 }}>📱📸</div>
                <h4 style={{ color: '#064E3B', fontWeight: 800, fontSize: '1.1rem', marginBottom: 8 }}>
                  Tirar Foto com a Câmera do Celular
                </h4>
                <p style={{ fontSize: '0.85rem', color: '#4B5563', marginBottom: 16 }}>
                  Toque no botão abaixo para abrir a câmera do seu aplicativo móvel.
                </p>

                <button
                  className="btn btn-primary"
                  onClick={() => mobileCameraInputRef.current.click()}
                  style={{ width: '100%', marginBottom: 10 }}
                >
                  📷 Abrir Câmera do Celular
                </button>

                <button
                  className="btn btn-outline"
                  onClick={() => fileInputRef.current.click()}
                  style={{ width: '100%', fontSize: '0.9rem', padding: '12px 16px' }}
                >
                  📁 Galeria de Fotos
                </button>
              </div>
            )}
          </div>
        )}

        {capturedImage && (
          <div style={{ width: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
            <div style={{ position: 'relative', width: '100%', textAlign: 'center' }}>
              <img
                src={capturedImage}
                alt="Foto Capturada"
                style={{
                  width: '100%',
                  maxHeight: 280,
                  objectFit: 'contain',
                  borderRadius: 16,
                  border: '3px solid #0F9D76'
                }}
              />
            </div>

            {loading && (
              <div style={{ marginTop: 16, textAlign: 'center' }}>
                <span style={{ fontSize: '2rem', display: 'inline-block', animation: 'spin 1s infinite linear' }}>⏳</span>
                <p style={{ fontWeight: 700, color: '#0F9D76', marginTop: 8 }}>Classificando expressão no Backend...</p>
              </div>
            )}

            {result && result.face_detected && result.predictions.length > 0 && (
              <div className="pop-in" style={{
                marginTop: 16,
                backgroundColor: '#E6F4EA',
                borderRadius: 16,
                padding: '16px 24px',
                textAlign: 'center',
                width: '100%',
                border: '2px solid #0F9D76'
              }}>
                <span style={{ fontSize: '3rem', display: 'block' }}>
                  {EMOTION_EMOJIS[result.predictions[0].sentiment] || '😊'}
                </span>
                <h4 style={{ fontSize: '1.4rem', color: '#064E3B', fontWeight: 800, marginTop: 4 }}>
                  {result.predictions[0].sentiment}
                </h4>
                <p style={{ fontSize: '0.9rem', color: '#059669', fontWeight: 700 }}>
                  Confiança: {(result.predictions[0].confidence * 100).toFixed(1)}%
                </p>
              </div>
            )}

            {result && !result.face_detected && (
              <div className="pop-in" style={{
                marginTop: 16,
                backgroundColor: '#FEF2F2',
                borderRadius: 16,
                padding: 16,
                textAlign: 'center',
                width: '100%',
                border: '2px solid #F87171'
              }}>
                <span style={{ fontSize: '2.5rem' }}>🧐</span>
                <h4 style={{ fontSize: '1.1rem', color: '#991B1B', fontWeight: 800 }}>
                  Nenhuma face detectada na imagem
                </h4>
                <p style={{ fontSize: '0.85rem', color: '#7F1D1D' }}>
                  Tente posicionar a foto com o rosto em destaque e boa iluminação.
                </p>
              </div>
            )}

            <button
              className="btn btn-outline"
              onClick={resetPhoto}
              style={{ marginTop: 16 }}
            >
              🔄 Tirar Outra Foto
            </button>
          </div>
        )}

        {error && (
          <div style={{
            marginTop: 16,
            padding: 12,
            backgroundColor: '#FEF2F2',
            color: '#991B1B',
            borderRadius: 12,
            fontSize: '0.85rem',
            textAlign: 'center'
          }}>
            {error}
          </div>
        )}
      </div>
    </div>
  );
}
