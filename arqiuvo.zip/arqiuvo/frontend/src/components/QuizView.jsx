import React, { useState, useEffect, useRef } from 'react';
import CelebrationModal from './CelebrationModal';
import RetryModal from './RetryModal';
import { getApiUrl } from '../config';

// Algoritmo Fisher-Yates para embaralhar um array aleatoriamente
function shuffleArray(array) {
  const arr = [...array];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

// Embaralha tanto a ordem das questões quanto a ordem das 4 opções de cada questão
function prepareShuffledQuestions(rawQuestions) {
  if (!rawQuestions || rawQuestions.length === 0) return [];
  const shuffledQuestions = shuffleArray(rawQuestions);
  return shuffledQuestions.map((q) => ({
    ...q,
    options: shuffleArray(q.options)
  }));
}

// Fallback local com as 7 emoções de Ekman caso a API esteja indisponível
const FALLBACK_QUESTIONS = [
  {
    id: 1,
    emoji: "😊",
    emotion: "Felicidade",
    hint: "Dica: Os cantos da boca sobem e os olhos ficam iluminados!",
    options: ["Alegre", "Triste", "Bravo", "Surpreso"],
    correct_option: "Alegre"
  },
  {
    id: 2,
    emoji: "😢",
    emotion: "Tristeza",
    hint: "Dica: A boca fica caída para baixo e o olhar tristonho.",
    options: ["Alegre", "Triste", "Medo", "Neutro"],
    correct_option: "Triste"
  },
  {
    id: 3,
    emoji: "😠",
    emotion: "Raiva",
    hint: "Dica: As sobrancelhas ficam franzidas e os lábios apertados.",
    options: ["Bravo", "Alegre", "Nojo", "Surpreso"],
    correct_option: "Bravo"
  },
  {
    id: 4,
    emoji: "😲",
    emotion: "Surpresa",
    hint: "Dica: A boca fica aberta em formato de O e os olhos arregalados.",
    options: ["Surpreso", "Medo", "Alegre", "Triste"],
    correct_option: "Surpreso"
  },
  {
    id: 5,
    emoji: "😨",
    emotion: "Medo",
    hint: "Dica: Os olhos ficam bem abertos e a expressão sobressaltada.",
    options: ["Medo", "Nojo", "Alegre", "Bravo"],
    correct_option: "Medo"
  },
  {
    id: 6,
    emoji: "🤢",
    emotion: "Nojo",
    hint: "Dica: O nariz fica franzido expressando rejeição.",
    options: ["Nojo", "Surpreso", "Triste", "Neutro"],
    correct_option: "Nojo"
  },
  {
    id: 7,
    emoji: "😐",
    emotion: "Neutro",
    hint: "Dica: O rosto fica sereno sem expressão acentuada.",
    options: ["Neutro", "Alegre", "Bravo", "Triste"],
    correct_option: "Neutro"
  }
];

export default function QuizView({ onAnswer, onBack }) {
  const rawQuestionsRef = useRef(FALLBACK_QUESTIONS);
  const [questions, setQuestions] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState(null);
  const [showCelebration, setShowCelebration] = useState(false);
  const [showRetry, setShowRetry] = useState(false);
  const [loading, setLoading] = useState(true);

  // Busca as questões e inicializa o quiz embaralhando UMA ÚNICA VEZ ao carregar a tela
  useEffect(() => {
    let isMounted = true;

    async function loadQuizData() {
      const apiUrl = getApiUrl('/quiz/questions');
      let loadedQuestions = FALLBACK_QUESTIONS;

      try {
        const response = await fetch(apiUrl);
        if (response.ok) {
          const data = await response.json();
          if (data.questions && data.questions.length > 0) {
            loadedQuestions = data.questions;
          }
        }
      } catch (err) {
        console.warn("Não foi possível carregar o CSV do backend, usando fallback local.", err);
      }

      if (isMounted) {
        rawQuestionsRef.current = loadedQuestions;
        setQuestions(prepareShuffledQuestions(loadedQuestions));
        setLoading(false);
      }
    }

    loadQuizData();

    return () => {
      isMounted = false;
    };
  }, []);

  const currentQuestion = questions[currentIndex];

  const handleSelectOption = (option) => {
    setSelectedOption(option);
    const isCorrect = option === currentQuestion.correct_option;

    // Notifica o App para atualizar estatísticas de treino em memória
    if (onAnswer) {
      onAnswer(isCorrect);
    }

    if (isCorrect) {
      setShowCelebration(true);
    } else {
      setShowRetry(true);
    }
  };

  const handleNextQuestion = () => {
    setShowCelebration(false);
    setSelectedOption(null);
    if (currentIndex + 1 < questions.length) {
      setCurrentIndex(currentIndex + 1);
    } else {
      // Quando o quiz é concluído, re-embaralha todas as questões para um novo ciclo
      setQuestions(prepareShuffledQuestions(rawQuestionsRef.current));
      setCurrentIndex(0);
    }
  };

  const handleRetry = () => {
    setShowRetry(false);
    setSelectedOption(null);
  };

  if (loading || !currentQuestion) {
    return (
      <div style={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        height: '100%',
        padding: 20
      }}>
        <span style={{ fontSize: '3rem', animation: 'bounce 1s infinite' }}>🎯</span>
        <p style={{ marginTop: 16, fontWeight: 700, color: '#0F9D76' }}>Preparando o treino de emoções...</p>
      </div>
    );
  }

  return (
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      height: '100%',
      padding: '20px',
      position: 'relative',
      overflowY: 'auto'
    }}>
      {/* Top Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
        <button
          onClick={onBack}
          style={{
            backgroundColor: '#E5E7EB',
            border: 'none',
            borderRadius: '50%',
            width: 40,
            height: 40,
            cursor: 'pointer',
            fontSize: '1.2rem',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}
        >
          ←
        </button>

        <div style={{
          backgroundColor: '#064E3B',
          color: '#FFFFFF',
          padding: '4px 16px',
          borderRadius: 999,
          fontWeight: 800,
          fontSize: '0.85rem'
        }}>
          Nível 1
        </div>

        <span style={{ fontSize: '0.9rem', fontWeight: 800, color: '#0F9D76' }}>
          [{currentIndex + 1}]/[{questions.length}]
        </span>
      </div>

      {/* Card da Pergunta Principal */}
      <div style={{
        backgroundColor: '#FFFFFF',
        borderRadius: 24,
        padding: '24px 20px',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        textAlign: 'center',
        boxShadow: '0 8px 24px rgba(0,0,0,0.06)',
        marginBottom: 20,
        border: '2px solid #E5E7EB'
      }}>
        <h3 style={{ fontSize: '1.3rem', color: '#064E3B', fontWeight: 800, marginBottom: 4 }}>
          Qual é essa emoção?
        </h3>
        <p style={{ fontSize: '0.85rem', color: '#6B7280', marginBottom: 16 }}>
          Observe a boca e a expressão do emoji
        </p>

        {/* Emoji em Destaque */}
        <div key={currentQuestion.id + '-' + currentIndex} className="pop-in" style={{
          width: 130,
          height: 130,
          backgroundColor: '#E6F4EA',
          borderRadius: '50%',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          fontSize: '4.5rem',
          marginBottom: 16,
          boxShadow: '0 8px 20px rgba(15, 157, 118, 0.15)'
        }}>
          {currentQuestion.emoji}
        </div>

        {/* Dica */}
        <div style={{
          backgroundColor: '#ECFDF5',
          color: '#047857',
          padding: '8px 16px',
          borderRadius: 12,
          fontSize: '0.8rem',
          fontWeight: 700,
          border: '1px solid #A7F3D0'
        }}>
          💡 {currentQuestion.hint}
        </div>
      </div>

      {/* Grid de 4 Opções de Resposta (Ordem Embaralhada) */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: '1fr 1fr',
        gap: 12,
        marginBottom: 16
      }}>
        {currentQuestion.options.map((option, idx) => (
          <button
            key={idx}
            onClick={() => handleSelectOption(option)}
            style={{
              backgroundColor: '#FFFFFF',
              border: selectedOption === option ? '3px solid #0F9D76' : '2px solid #E5E7EB',
              borderRadius: 20,
              padding: '16px 12px',
              fontFamily: 'inherit',
              fontWeight: 800,
              fontSize: '1.05rem',
              color: '#064E3B',
              cursor: 'pointer',
              boxShadow: '0 4px 12px rgba(0,0,0,0.04)',
              transition: 'all 0.15s ease'
            }}
          >
            {option}
          </button>
        ))}
      </div>

      {/* Modais de Sucesso / Erro */}
      {showCelebration && (
        <CelebrationModal
          question={currentQuestion}
          onNext={handleNextQuestion}
        />
      )}

      {showRetry && (
        <RetryModal
          onRetry={handleRetry}
        />
      )}
    </div>
  );
}
