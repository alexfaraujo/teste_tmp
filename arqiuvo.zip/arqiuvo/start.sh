#!/usr/bin/env bash

# Script para inicializar simultaneamente o Backend FastAPI e o Frontend React + Vite do Face Trainer TEA.
set -eo pipefail

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${GREEN}[INFO] Iniciando o sistema Face Trainer TEA (Monorepo)...${NC}"

# Função para encerrar limpar todos os processos em segundo plano ao pressionar Ctrl+C
cleanup() {
    echo -e "\n${YELLOW}[AVISO] Encerrando o Backend FastAPI e o Frontend React...${NC}"
    kill 0 2>/dev/null || true
    exit 0
}
trap cleanup SIGINT SIGTERM EXIT

# 1. Garante que o ambiente virtual existe e instala dependências se necessário
if [ ! -d ".venv" ]; then
    echo -e "${YELLOW}[AVISO] Ambiente virtual (.venv) não encontrado. Criando ambiente...${NC}"
    python3 -m venv .venv
    source .venv/bin/activate
    pip install -r backend/requirements.txt
fi

# 2. Inicia o Backend FastAPI em segundo plano
echo -e "${BLUE}[BACKEND] Iniciando o servidor FastAPI em http://localhost:8000...${NC}"
(
    cd backend
    # shellcheck disable=SC1091
    source ../.venv/bin/activate
    exec uvicorn main:app --host 0.0.0.0 --port 8000 --reload
) &
BACKEND_PID=$!

# Aguarda 2 segundos para o servidor backend subir
sleep 2

# 3. Inicia o Frontend React + Vite
echo -e "${GREEN}[FRONTEND] Iniciando a aplicação Web React em http://localhost:3000...${NC}"
(
    cd frontend
    exec npm run dev
) &
FRONTEND_PID=$!

echo -e "\n${GREEN}======================================================================${NC}"
echo -e "${GREEN}      SISTEMA FACE TRAINER TEA INICIADO COM SUCESSO!${NC}"
echo -e "${GREEN}======================================================================${NC}"
echo -e "${GREEN}  👉 Frontend Web: http://localhost:3000${NC}"
echo -e "${BLUE}  👉 Backend API:  http://localhost:8000 (Swagger UI: http://localhost:8000/docs)${NC}"
echo -e "${YELLOW}  Pressione Ctrl+C a qualquer momento para encerrar todos os serviços.${NC}"
echo -e "${GREEN}======================================================================${NC}\n"

# Mantém o script aguardando a finalização dos processos
wait $BACKEND_PID $FRONTEND_PID
