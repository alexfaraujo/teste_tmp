import os
import cv2
import numpy as np
from fastapi.testclient import TestClient
from main import app
from src.config import UPLOAD_DIR

def create_sample_face_image(filename="test_face.jpg") -> str:
    """Cria uma imagem de teste sintética com uma face simples para validação do endpoint."""
    img = np.zeros((480, 640, 3), dtype=np.uint8)
    img[:] = (220, 220, 220)  # Fundo claro
    
    # Desenha feições simulando um rosto simples
    cv2.circle(img, (320, 240), 110, (180, 150, 120), -1)  # Cabeça
    cv2.circle(img, (270, 210), 12, (30, 30, 30), -1)      # Olho esquerdo
    cv2.circle(img, (370, 210), 12, (30, 30, 30), -1)      # Olho direito
    cv2.ellipse(img, (320, 275), (45, 25), 0, 0, 180, (30, 30, 30), 6) # Boca sorrindo
    
    cv2.imwrite(filename, img)
    return filename


def test_health_endpoint():
    """Valida o funcionamento do endpoint GET /health."""
    client = TestClient(app)
    response = client.get("/health")
    assert response.status_code == 200, f"Status code esperado 200, obteve {response.status_code}"
    data = response.json()
    assert data["status"] == "healthy", f"Status no JSON incorreto: {data}"
    print("[✔ TESTE PASSOU] GET /health retornou HTTP 200 OK e JSON de saúde válido.")


def test_quiz_endpoint():
    """Valida o funcionamento do endpoint GET /quiz/questions lendo o arquivo CSV."""
    client = TestClient(app)
    response = client.get("/quiz/questions")
    assert response.status_code == 200, f"Status code esperado 200, obteve {response.status_code}"
    data = response.json()
    assert data["status"] == "success", f"Status no JSON incorreto: {data}"
    assert "questions" in data and len(data["questions"]) > 0, "Lista de questões vazia."
    print(f"[✔ TESTE PASSOU] GET /quiz/questions retornou {len(data['questions'])} questões do CSV.")


def test_classify_endpoint():
    """Valida o funcionamento do endpoint POST /classify enviando uma imagem multipart/form-data."""
    sample_path = create_sample_face_image()
    try:
        client = TestClient(app)
        with open(sample_path, "rb") as image_file:
            response = client.post(
                "/classify",
                files={"file": ("test_face.jpg", image_file, "image/jpeg")}
            )
            
        assert response.status_code == 200, f"Status code esperado 200, obteve {response.status_code}: {response.text}"
        data = response.json()
        
        assert data["status"] == "success", f"Status da resposta não é 'success': {data}"
        assert "filename" in data, "Chave 'filename' ausente no JSON de resposta."
        assert "image_url" in data, "Chave 'image_url' ausente no JSON de resposta."
        assert "face_detected" in data, "Chave 'face_detected' ausente no JSON de resposta."
        assert "predictions" in data, "Chave 'predictions' ausente no JSON de resposta."
        
        # Verifica se a imagem foi salva fisicamente no diretório de UPLOAD_DIR
        saved_filepath = os.path.join(UPLOAD_DIR, data["filename"])
        assert os.path.exists(saved_filepath), f"O arquivo {saved_filepath} não foi encontrado na pasta uploads."
        
        print("[✔ TESTE PASSOU] POST /classify aceitou a imagem, salvou em UPLOAD_DIR e retornou o JSON formatado:")
        print(f"   -> Arquivo Salvo: {data['filename']}")
        print(f"   -> URL Estática: {data['image_url']}")
        print(f"   -> Face Detectada: {data['face_detected']}")
        print(f"   -> Predições: {data['predictions']}")
        
    finally:
        if os.path.exists(sample_path):
            os.remove(sample_path)


if __name__ == "__main__":
    print("=" * 70)
    print("      VALIDAÇÃO AUTOMATIZADA DOS ENDPOINTS FASTAPI (FER)")
    print("=" * 70)
    test_health_endpoint()
    test_quiz_endpoint()
    test_classify_endpoint()
    print("=" * 70)
    print("      TODOS OS TESTES DA API FORAM EXECUTADOS COM SUCESSO!")
    print("=" * 70)
