import cv2
from src.camera import Webcam
from src.detector import FaceDetector
from src.classifier import EmotionClassifier

def main():
    print("[INFO] Iniciando teste do módulo src/classifier.py...")
    print("[INFO] Como não há pesos salvos ainda, o modelo executará inferências reais com pesos aleatórios.")
    print("[INFO] Pressione a tecla 'q' em qualquer janela de vídeo para encerrar o teste.")
    
    try:
        detector = FaceDetector()
        classifier = EmotionClassifier()
    except Exception as e:
        print(f"[ERRO] Falha na inicialização dos módulos: {e}")
        return
        
    try:
        with Webcam() as camera:
            while True:
                ret, frame = camera.read_frame()
                if not ret or frame is None:
                    print("[ERRO] Falha ao capturar frame da webcam.")
                    break
                
                # Espelha o frame para visualização natural
                frame = cv2.flip(frame, 1)
                
                # Detecta rostos
                faces = detector.detect_faces(frame)
                
                # Desenha o HUD e os rótulos de teste para os rostos detectados
                for bbox in faces:
                    x, y, w, h = bbox
                    
                    # Extrai a Região de Interesse (ROI) do rosto
                    face_roi = detector.extract_roi(frame, bbox)
                    
                    if face_roi is not None and face_roi.size > 0:
                        # Executa a inferência de sentimento
                        label, confidence = classifier.classify(face_roi)
                        
                        # Print explicativo no terminal
                        print(f"[PREDIÇÃO] Rosto detectado -> Sentimento: {label} (Confiança: {confidence:.2f})")
                        
                        # Desenha retângulo simples no feed
                        cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 0, 0), 2)
                        
                        # Coloca texto do sentimento
                        text_str = f"{label} ({confidence * 100:.1f}%)"
                        cv2.putText(frame, text_str, (x, max(0, y - 10)),
                                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
                
                # Exibe a janela de teste
                cv2.imshow("Teste do Classificador", frame)
                
                # Encerra se 'q' for pressionado
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    print("[INFO] Tecla 'q' pressionada. Encerrando...")
                    break
    except Exception as e:
        print(f"[ERRO] Ocorreu uma exceção no teste: {e}")
    finally:
        detector.close()
        cv2.destroyAllWindows()
        print("[INFO] Teste finalizado e recursos liberados.")

if __name__ == "__main__":
    main()
