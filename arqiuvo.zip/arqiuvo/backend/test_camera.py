import cv2
from src.camera import Webcam

def main():
    print("[INFO] Iniciando teste do módulo src/camera.py...")
    print("[INFO] Pressione a tecla 'q' na janela de vídeo para encerrar o teste.")
    
    try:
        # Inicializa a câmera usando o gerenciador de contexto
        with Webcam() as camera:
            while True:
                ret, frame = camera.read_frame()
                if not ret or frame is None:
                    print("[ERRO] Falha ao capturar frame da webcam.")
                    break
                
                # Espelha o frame horizontalmente para visualização natural (efeito espelho)
                frame = cv2.flip(frame, 1)
                
                # Exibe o frame em uma janela
                cv2.imshow("Teste do Modulo de Camera", frame)
                
                # Aguarda 1ms; sai se 'q' for pressionado
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    print("[INFO] Tecla 'q' pressionada. Encerrando...")
                    break
    except Exception as e:
        print(f"[ERRO] Ocorreu uma exceção no teste: {e}")
    finally:
        # Garante o fechamento das janelas abertas pelo OpenCV
        cv2.destroyAllWindows()
        print("[INFO] Teste finalizado e recursos liberados.")

if __name__ == "__main__":
    main()
