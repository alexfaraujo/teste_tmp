import cv2
from src.camera import Webcam
from src.detector import FaceDetector

def main():
    print("[INFO] Iniciando teste do módulo src/detector.py...")
    print("[INFO] Pressione a tecla 'q' em qualquer janela de vídeo para encerrar o teste.")
    
    try:
        detector = FaceDetector()
    except Exception as e:
        print(f"[ERRO] Falha ao inicializar o FaceDetector: {e}")
        return
        
    try:
        with Webcam() as camera:
            while True:
                ret, frame = camera.read_frame()
                if not ret or frame is None:
                    print("[ERRO] Falha ao capturar frame da webcam.")
                    break
                
                # Espelha o frame para visualização natural
                frame = cv2.flip(frame, 1)
                
                # Detecta rostos
                faces = detector.detect_faces(frame)
                
                # Se algum rosto for detectado, processa e extrai a ROI
                for i, bbox in enumerate(faces):
                    x, y, w, h = bbox
                    
                    # Desenha um retângulo simples (verde) ao redor da face detectada
                    cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
                    
                    # Extrai a Região de Interesse (ROI) do rosto
                    face_roi = detector.extract_roi(frame, bbox)
                    
                    if face_roi is not None and face_roi.size > 0:
                        # Exibe a face recortada em uma janela dedicada
                        cv2.imshow(f"Face ROI {i}", face_roi)
                
                # Se não houver rostos detectados, fecha as janelas de ROI antigas
                if not faces:
                    # Tenta fechar as janelas do OpenCV se existirem
                    try:
                        cv2.destroyWindow("Face ROI 0")
                    except cv2.error:
                        pass
                
                # Exibe o feed completo com o retângulo
                cv2.imshow("Teste do Detector Facial", frame)
                
                # Sai se 'q' for pressionado
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    print("[INFO] Tecla 'q' pressionada. Encerrando...")
                    break
    except Exception as e:
        print(f"[ERRO] Ocorreu uma exceção no teste: {e}")
    finally:
        # Libera recursos
        detector.close()
        cv2.destroyAllWindows()
        print("[INFO] Teste finalizado e recursos liberados.")

if __name__ == "__main__":
    main()
