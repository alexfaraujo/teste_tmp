import os
import csv
import uuid
import cv2
import uvicorn
import numpy as np
from datetime import datetime
from contextlib import asynccontextmanager
from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware

from src.config import UPLOAD_DIR, API_HOST, API_PORT

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CSV_QUIZ_PATH = os.path.join(BASE_DIR, "data", "emojis_quiz.csv")

# Garante que o diretório de uploads estáticos exista
os.makedirs(UPLOAD_DIR, exist_ok=True)

from src.detector import FaceDetector
from src.classifier import EmotionClassifier

# Instanciação global dos modelos de IA
detector = FaceDetector()
classifier = EmotionClassifier()

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Gerencia o ciclo de vida da aplicação FastAPI, liberando recursos ao desligar."""
    print("[INFO] Servidor FastAPI inicializado com modelos FER prontos.")
    yield
    print("[INFO] Encerrando servidor FastAPI e liberando recursos do MediaPipe...")
    if detector:
        detector.close()

app = FastAPI(
    title="FER Web API - Reconhecimento de Expressões Faciais",
    description="API Backend Web para receber fotografias de aplicativos móveis, armazená-las, classificar emoções e disponibilizar o quiz de emojis.",
    version="1.0.0",
    lifespan=lifespan
)

# Configuração de CORS para permitir requisições de aplicativos móveis ou navegadores web
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Monta o diretório de uploads como rota estática para visualização pública (/static/...)
app.mount("/static", StaticFiles(directory=UPLOAD_DIR), name="static")


@app.get("/", tags=["Health"])
@app.get("/health", tags=["Health"])
def health_check():
    """Endpoint de verificação de integridade e status da API."""
    return {
        "status": "healthy",
        "service": "FER FastAPI Backend",
        "version": "1.0.0",
        "model_status": "loaded"
    }


@app.get("/quiz/questions", tags=["Quiz Emoções"])
@app.get("/api/v1/quiz/questions", tags=["Quiz Emoções"])
def get_quiz_questions():
    """
    Retorna a lista de emojis, dicas e opções do quiz de treinamento
    lidos diretamente do arquivo CSV estático em data/emojis_quiz.csv.
    """
    if not os.path.exists(CSV_QUIZ_PATH):
        raise HTTPException(status_code=404, detail="Arquivo CSV de quiz não encontrado no servidor.")
        
    questions = []
    try:
        with open(CSV_QUIZ_PATH, mode="r", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                questions.append({
                    "id": int(row["id"]),
                    "emoji": row["emoji"],
                    "emotion": row["emotion"],
                    "hint": row["hint"],
                    "options": [row["option_1"], row["option_2"], row["option_3"], row["option_4"]],
                    "correct_option": row["correct_option"]
                })
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro ao ler arquivo CSV de quiz: {e}")
        
    return {
        "status": "success",
        "total": len(questions),
        "questions": questions
    }


@app.post("/classify", tags=["Classificação FER"])
@app.post("/api/v1/classify", tags=["Classificação FER"])
async def classify_photo(file: UploadFile = File(...)):
    """
    Recebe uma fotografia enviada pela câmera do celular (multipart/form-data),
    salva a imagem na pasta estática 'uploads/', detecta a face e classifica o sentimento.
    
    Retorna o JSON com o resultado da classificação.
    """
    if not file or not file.filename:
        raise HTTPException(status_code=400, detail="Nenhum arquivo enviado.")
        
    # Extrai a extensão da imagem ou padroniza para .jpg
    ext = os.path.splitext(file.filename)[1]
    if not ext or ext.lower() not in [".jpg", ".jpeg", ".png", ".bmp", ".webp"]:
        ext = ".jpg"
        
    # Gera nome único para o arquivo salvo
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    unique_id = uuid.uuid4().hex[:8]
    saved_filename = f"img_{timestamp}_{unique_id}{ext}"
    saved_filepath = os.path.join(UPLOAD_DIR, saved_filename)
    
    # Salva o arquivo de imagem no disco estático
    try:
        content = await file.read()
        with open(saved_filepath, "wb") as f:
            f.write(content)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro ao salvar imagem no servidor: {e}")
        
    # Lê a imagem com OpenCV para processamento de IA
    img = cv2.imread(saved_filepath)
    if img is None:
        raise HTTPException(status_code=400, detail="Formato de imagem inválido ou corrompido.")
        
    # 1. Detecção Facial (MediaPipe BlazeFace)
    faces = detector.detect_faces(img)
    
    predictions = []
    if faces:
        for bbox in faces:
            # 2. Extração da ROI
            roi = detector.extract_roi(img, bbox)
            if roi is not None and roi.size > 0:
                # 3. Classificação FER (MobileNetV2)
                label, confidence = classifier.classify(roi)
                predictions.append({
                    "sentiment": label,
                    "confidence": round(float(confidence), 4),
                    "bbox": [int(b) for b in bbox]  # [x, y, width, height]
                })
                
    face_detected = len(predictions) > 0
    
    return {
        "status": "success",
        "message": "Fotografia processada e classificada com sucesso.",
        "filename": saved_filename,
        "image_url": f"/static/{saved_filename}",
        "face_detected": face_detected,
        "predictions": predictions
    }


if __name__ == "__main__":
    uvicorn.run("main:app", host=API_HOST, port=API_PORT, reload=True)
