import cv2
import time
from src.camera import Webcam
from src.detector import FaceDetector
from src.visualizer import Visualizer

def main():
    print("[INFO] Iniciando teste do módulo src/visualizer.py...")
    print("[INFO] As emoções e cores do HUD irão alternar a cada 2 segundos.")
    print("[INFO] Pressione a tecla 'q' na janela de vídeo para encerrar o teste.")
    
    try:
        detector = FaceDetector()
        visualizer = Visualizer()
    except Exception as e:
        print(f"[ERRO] Falha na inicialização dos módulos: {e}")
        return
        
    # Lista de sentimentos para alternar no teste
    emotions = ["Felicidade", "Neutro", "Surpresa", "Tristeza", "Raiva", "Nojo", "Medo"]
    emotion_index = 0
    last_switch_time = time.time()
    
    prev_time = time.time()
    
    try:
        with Webcam() as camera:
            while True:
                ret, frame = camera.read_frame()
                if not ret or frame is None:
                    print("[ERRO] Falha ao capturar frame da webcam.")
                    break
                
                # Espelha o frame para visualização natural
                frame = cv2.flip(frame, 1)
                
                # Alterna o sentimento simulado a cada 2 segundos
                current_time = time.time()
                if current_time - last_switch_time > 2.0:
                    emotion_index = (emotion_index + 1) % len(emotions)
                    last_switch_time = current_time
                    
                simulated_emotion = emotions[emotion_index]
                simulated_confidence = 0.85 + (0.02 * emotion_index) # Confiança simulada
                
                # Detecta rostos
                faces = detector.detect_faces(frame)
                
                # Desenha o HUD e os rótulos de teste para os rostos detectados
                for bbox in faces:
                    color = visualizer.get_color(simulated_emotion)
                    visualizer.draw_hud_box(frame, bbox, color)
                    visualizer.draw_label(frame, bbox, simulated_emotion, simulated_confidence, color)
                    
                # Calcula e exibe FPS
                fps = 1.0 / (current_time - prev_time)
                prev_time = current_time
                visualizer.draw_fps(frame, fps)
                
                # Exibe a janela de teste
                cv2.imshow("Teste do Visualizador HUD", frame)
                
                # Encerra se 'q' for pressionado
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    print("[INFO] Tecla 'q' pressionada. Encerrando...")
                    break
    except Exception as e:
        print(f"[ERRO] Ocorreu uma exceção no teste: {e}")
    finally:
        detector.close()
        cv2.destroyAllWindows()
        print("[INFO] Teste finalizado e recursos liberados.")

if __name__ == "__main__":
    main()
