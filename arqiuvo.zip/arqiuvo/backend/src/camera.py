import cv2
from src.config import CAMERA_INDEX, FRAME_WIDTH, FRAME_HEIGHT

class Webcam:
    """
    Gerencia o ciclo de vida da captura de vídeo da webcam.
    Implementa gerenciador de contexto para garantir liberação segura do hardware.
    """
    
    def __init__(self, camera_index: int = CAMERA_INDEX):
        self.camera_index = camera_index
        self.cap = None
        
    def __enter__(self):
        """Inicializa a webcam e define as resoluções de frame."""
        print(f"[INFO] Inicializando a webcam no índice {self.camera_index}...")
        self.cap = cv2.VideoCapture(self.camera_index)
        
        if not self.cap.isOpened():
            raise RuntimeError(f"Não foi possível abrir a webcam no índice {self.camera_index}.")
            
        # Define a resolução da câmera conforme configurado
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, FRAME_WIDTH)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, FRAME_HEIGHT)
        
        return self
        
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Garante a liberação da câmera ao encerrar o bloco with."""
        self.release()
        
    def read_frame(self):
        """
        Lê um frame da webcam.
        Retorna:
            ret (bool): Verdadeiro se o frame foi lido corretamente.
            frame (numpy.ndarray): O frame capturado, ou None se falhou.
        """
        if self.cap is None or not self.cap.isOpened():
            return False, None
            
        ret, frame = self.cap.read()
        return ret, frame
        
    def release(self):
        """Libera os recursos do VideoCapture."""
        if self.cap is not None:
            print("[INFO] Liberando recursos da webcam...")
            self.cap.release()
            self.cap = None
