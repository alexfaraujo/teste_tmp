import cv2
import numpy as np

class Visualizer:
    """Responsável por renderizar caixas delimitadoras estilizadas (HUD style) e rótulos de emoções."""
    
    def __init__(self):
        # Paleta de cores moderna (BGR) para cada sentimento:
        self.colors = {
            "Raiva": (59, 59, 220),       # Vermelho Carmesim
            "Nojo": (76, 154, 42),       # Verde Oliva/Musgo
            "Medo": (142, 68, 173),      # Roxo Ametista
            "Felicidade": (46, 204, 113),  # Verde Esmeralda
            "Tristeza": (220, 160, 41),    # Azul Aço/Frio
            "Surpresa": (255, 105, 180),  # Rosa Choque
            "Neutro": (149, 165, 166)     # Cinza Asbesto
        }
        self.default_color = (180, 180, 180) # Cinza claro padrão
        
    def get_color(self, label: str):
        """Retorna a cor correspondente à emoção ou a cor padrão."""
        return self.colors.get(label, self.default_color)
        
    def draw_hud_box(self, frame, bbox, color, thickness=2, length=15):
        """
        Desenha cantos estilizados (HUD) em vez de um retângulo sólido completo,
        dando um aspecto visual premium.
        """
        x, y, w, h = bbox
        
        # Cantos da caixa
        # Canto Superior Esquerdo
        cv2.line(frame, (x, y), (x + length, y), color, thickness)
        cv2.line(frame, (x, y), (x, y + length), color, thickness)
        
        # Canto Superior Direito
        cv2.line(frame, (x + w, y), (x + w - length, y), color, thickness)
        cv2.line(frame, (x + w, y), (x + w, y + length), color, thickness)
        
        # Canto Inferior Esquerdo
        cv2.line(frame, (x, y + h), (x + length, y + h), color, thickness)
        cv2.line(frame, (x, y + h), (x, y + h - length), color, thickness)
        
        # Canto Inferior Direito
        cv2.line(frame, (x + w, y + h), (x + w - length, y + h), color, thickness)
        cv2.line(frame, (x + w, y + h), (x + w, y + h - length), color, thickness)
        
        # Desenha uma borda bem fina e suave conectando os cantos
        cv2.rectangle(frame, (x, y), (x + w, y + h), color, 1, cv2.LINE_AA)
        
    def draw_label(self, frame, bbox, label, confidence=None, color=None):
        """
        Desenha uma faixa/pill de texto semi-transparente contendo o sentimento e confiança
        logo acima da face.
        """
        x, y, w, h = bbox
        if color is None:
            color = self.get_color(label)
            
        text = label
        if confidence is not None:
            text = f"{label} ({confidence * 100:.1f}%)"
            
        font = cv2.FONT_HERSHEY_SIMPLEX
        font_scale = 0.5
        thickness = 1
        
        # Obtém tamanho do texto
        (text_w, text_h), baseline = cv2.getTextSize(text, font, font_scale, thickness)
        
        # Configura as coordenadas da "pill" de fundo
        pad = 6
        rect_x1 = x
        rect_y1 = max(0, y - text_h - pad * 2)
        rect_x2 = x + text_w + pad * 2
        rect_y2 = y
        
        # Garante que o painel de texto caiba na tela
        if rect_x2 > frame.shape[1]:
            rect_x2 = frame.shape[1]
            
        # Cria uma cópia para aplicar transparência no retângulo de fundo
        overlay = frame.copy()
        cv2.rectangle(overlay, (rect_x1, rect_y1), (rect_x2, rect_y2), color, -1)
        
        # Blend para fundo translúcido (transparência de 75%)
        alpha = 0.75
        cv2.addWeighted(overlay, alpha, frame, 1 - alpha, 0, frame)
        
        # Renderiza o texto por cima em branco com antialiasing
        cv2.putText(frame, text, (rect_x1 + pad, rect_y2 - pad), font, font_scale, (255, 255, 255), thickness, cv2.LINE_AA)
        
    def draw_fps(self, frame, fps: float):
        """Exibe o contador de frames por segundo (FPS) no canto superior esquerdo."""
        text = f"FPS: {fps:.1f}"
        font = cv2.FONT_HERSHEY_SIMPLEX
        font_scale = 0.5
        color = (0, 255, 0)
        thickness = 1
        cv2.putText(frame, text, (10, 20), font, font_scale, color, thickness, cv2.LINE_AA)
