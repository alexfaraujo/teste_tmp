import os
import sys

# Garante que o diretório raiz esteja no PATH para evitar ModuleNotFoundError
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# Silencia avisos de depuração do TensorFlow
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

import cv2
import numpy as np
import tensorflow as tf
from tensorflow.keras import layers, models
from tensorflow.keras.callbacks import ModelCheckpoint, EarlyStopping, ReduceLROnPlateau
from src.config import INPUT_SHAPE, MODEL_PATH, EMOTION_LABELS
from src.classifier import EmotionClassifier

# Mapeamento do RAF-DB para o padrão de índices do nosso projeto:
# RAF-DB Labels: 1: Surprise, 2: Fear, 3: Disgust, 4: Happiness, 5: Sadness, 6: Anger, 7: Neutral
# Nossos Índices: 0: Raiva, 1: Nojo, 2: Medo, 3: Felicidade, 4: Tristeza, 5: Surpresa, 6: Neutro
RAF_TO_PROJECT_MAP = {
    6: 0,  # Anger -> Raiva
    3: 1,  # Disgust -> Nojo
    2: 2,  # Fear -> Medo
    4: 3,  # Happiness -> Felicidade
    5: 4,  # Sadness -> Tristeza
    1: 5,  # Surprise -> Surpresa
    7: 6   # Neutral -> Neutro
}

def load_raf_db_metadata(dataset_path: str):
    """
    Carrega o dataset RAF-DB. Suporta tanto o formato CSV/DATASET estruturado no disco
    quanto o formato clássico original com a pasta EmoLabel e Image/aligned.
    Retorna caminhos absolutos das imagens e seus respectivos rótulos (Índices do projeto).
    """
    train_csv = os.path.join(dataset_path, "train_labels.csv")
    test_csv = os.path.join(dataset_path, "test_labels.csv")
    
    train_paths, train_labels = [], []
    val_paths, val_labels = [], []
    
    # 1. Estrutura Personalizada (CSV + DATASET/train e DATASET/test)
    if os.path.exists(train_csv) and os.path.exists(test_csv):
        print("[INFO] Estrutura do dataset reconhecida: CSV + Subpastas de Classes.")
        
        # Processando treino
        with open(train_csv, 'r') as f:
            lines = f.readlines()
            for line in lines[1:]:  # Pula o cabeçalho 'image,label'
                line = line.strip()
                if not line:
                    continue
                parts = line.split(",")
                if len(parts) < 2:
                    continue
                img_name, label_str = parts[0], parts[1]
                label_raf = int(label_str)
                label_project = RAF_TO_PROJECT_MAP.get(label_raf, 6)
                
                # Caminho: DATASET/train/<label_raf>/<img_name>
                img_path = os.path.join(dataset_path, "DATASET", "train", str(label_raf), img_name)
                train_paths.append(img_path)
                train_labels.append(label_project)
                
        # Processando teste (validação)
        with open(test_csv, 'r') as f:
            lines = f.readlines()
            for line in lines[1:]:  # Pula o cabeçalho 'image,label'
                line = line.strip()
                if not line:
                    continue
                parts = line.split(",")
                if len(parts) < 2:
                    continue
                img_name, label_str = parts[0], parts[1]
                label_raf = int(label_str)
                label_project = RAF_TO_PROJECT_MAP.get(label_raf, 6)
                
                # Caminho: DATASET/test/<label_raf>/<img_name>
                img_path = os.path.join(dataset_path, "DATASET", "test", str(label_raf), img_name)
                val_paths.append(img_path)
                val_labels.append(label_project)
                
        return train_paths, train_labels, val_paths, val_labels
        
    # 2. Estrutura Clássica Fallback (list_patition_label.txt + Image/aligned)
    label_file = os.path.join(dataset_path, "EmoLabel", "list_patition_label.txt")
    images_dir = os.path.join(dataset_path, "Image", "aligned")
    
    if not os.path.exists(label_file) or not os.path.exists(images_dir):
        raise FileNotFoundError("Não foi possível encontrar train_labels.csv/test_labels.csv nem a estrutura clássica do RAF-DB.")
        
    print("[INFO] Estrutura do dataset reconhecida: Clássica (list_patition_label.txt).")
    with open(label_file, 'r') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            filename, label_str = line.split(" ")
            label_raf = int(label_str)
            label_project = RAF_TO_PROJECT_MAP.get(label_raf, 6)
            
            img_name = filename
            if not img_name.endswith("_aligned.jpg"):
                img_name = img_name.replace(".jpg", "_aligned.jpg")
                
            img_path = os.path.join(images_dir, img_name)
            
            if filename.startswith("train_"):
                train_paths.append(img_path)
                train_labels.append(label_project)
            elif filename.startswith("test_"):
                val_paths.append(img_path)
                val_labels.append(label_project)
                
    return train_paths, train_labels, val_paths, val_labels

def parse_image(img_path, label):
    """Lê a imagem do disco, converte para RGB, redimensiona e pré-processa."""
    image_string = tf.io.read_file(img_path)
    image = tf.image.decode_jpeg(image_string, channels=3)
    image = tf.image.resize(image, [INPUT_SHAPE[0], INPUT_SHAPE[1]])
    image = tf.keras.applications.mobilenet_v2.preprocess_input(image)
    return image, label

def create_dataset(image_paths, labels, batch_size=32, is_training=True):
    """Cria um pipeline otimizado do tf.data.Dataset."""
    labels_one_hot = tf.one_hot(labels, depth=7)
    dataset = tf.data.Dataset.from_tensor_slices((image_paths, labels_one_hot))
    
    if is_training:
        dataset = dataset.shuffle(buffer_size=len(image_paths))
        
    dataset = dataset.map(parse_image, num_parallel_calls=tf.data.AUTOTUNE)
    dataset = dataset.batch(batch_size)
    dataset = dataset.prefetch(buffer_size=tf.data.AUTOTUNE)
    return dataset

def generate_synthetic_data(num_samples=128):
    """Gera dados sintéticos para teste e validação quando o dataset real não estiver presente."""
    print("[INFO] Gerando dados sintéticos para demonstração e teste de compilação...")
    x = np.random.uniform(-1.0, 1.0, size=(num_samples, INPUT_SHAPE[0], INPUT_SHAPE[1], 3)).astype(np.float32)
    y = np.random.randint(0, 7, size=(num_samples,))
    y_one_hot = tf.one_hot(y, depth=7).numpy()
    return x, y_one_hot

class SaveClassifierCallback(tf.keras.callbacks.Callback):
    """Callback customizado para salvar apenas a rede de classificação (sem camadas de Data Augmentation)."""
    def __init__(self, classifier_model, filepath):
        super().__init__()
        self.classifier_model = classifier_model
        self.filepath = filepath
        self.best_val_loss = float('inf')

    def on_epoch_end(self, epoch, logs=None):
        val_loss = logs.get('val_loss', float('inf'))
        if val_loss < self.best_val_loss:
            self.best_val_loss = val_loss
            # Salva o modelo completo do classificador
            self.classifier_model.save(self.filepath)
            print(f"\n[INFO] Val Loss melhorou para {val_loss:.4f}. Modelo salvo em '{self.filepath}'")

def main():
    print("=" * 60)
    print("      TREINAMENTO DO MODELO FER COM MOBILENETV2")
    print("=" * 60)
    
    dataset_path = "datasets/raf-db"
    batch_size = 32
    epochs_warmup = 10
    epochs_finetune = 20
    
    # Cria diretório de destino dos modelos, caso não exista
    os.makedirs(os.path.dirname(MODEL_PATH), exist_ok=True)
    
    # 1. Carregamento dos dados
    use_synthetic = False
    class_weights = None
    try:
        print(f"[INFO] Buscando o dataset RAF-DB em '{dataset_path}'...")
        train_paths, train_labels, val_paths, val_labels = load_raf_db_metadata(dataset_path)
        print(f"[INFO] Dados carregados: {len(train_paths)} treino, {len(val_paths)} validação.")
        
        # Calcula pesos das classes para lidar com o desbalanceamento
        train_labels_arr = np.array(train_labels)
        total_samples = len(train_labels_arr)
        num_classes = 7
        class_counts = np.bincount(train_labels_arr, minlength=num_classes)
        class_weights = {}
        for i in range(num_classes):
            count = class_counts[i]
            class_weights[i] = total_samples / (num_classes * count) if count > 0 else 1.0
            
        print("[INFO] Pesos de classe calculados para balanceamento:")
        for idx, name in EMOTION_LABELS.items():
            print(f"  - {name}: {class_weights[idx]:.4f} (Qtd: {class_counts[idx]})")
            
        train_ds = create_dataset(train_paths, train_labels, batch_size=batch_size, is_training=True)
        val_ds = create_dataset(val_paths, val_labels, batch_size=batch_size, is_training=False)
    except Exception as e:
        print(f"[AVISO] Não foi possível carregar o dataset RAF-DB real: {e}")
        use_synthetic = True
        
        # Fallback de dados sintéticos
        x_train, y_train_onehot = generate_synthetic_data(128)
        y_train = np.argmax(y_train_onehot, axis=-1)
        x_val, y_val = generate_synthetic_data(64)
        
        # Calcula pesos para os dados sintéticos
        total_samples = len(y_train)
        num_classes = 7
        class_counts = np.bincount(y_train, minlength=num_classes)
        class_weights = {}
        for i in range(num_classes):
            count = class_counts[i]
            class_weights[i] = total_samples / (num_classes * count) if count > 0 else 1.0
            
        train_ds = tf.data.Dataset.from_tensor_slices((x_train, y_train_onehot)).batch(batch_size)
        val_ds = tf.data.Dataset.from_tensor_slices((x_val, y_val)).batch(batch_size)
        
    # 2. Inicialização do Modelo
    classifier = EmotionClassifier()
    model = classifier.model
    
    # Data Augmentation integrado ao treinamento para aumentar a robustez
    data_augmentation = tf.keras.Sequential([
        layers.RandomFlip("horizontal"),
        layers.RandomRotation(0.1),
        layers.RandomZoom(0.1),
    ])
    
    # Reconstrói aplicando o Data Augmentation na entrada
    inputs = tf.keras.Input(shape=INPUT_SHAPE)
    x = data_augmentation(inputs)
    # Reutiliza as camadas do classificador
    outputs = model(x)
    augmented_model = tf.keras.Model(inputs, outputs)
    
    # 3. Callbacks do Treinamento
    checkpoint = SaveClassifierCallback(model, MODEL_PATH)
    early_stopping = EarlyStopping(
        monitor="val_loss",
        patience=5,
        restore_best_weights=True,
        verbose=1
    )
    lr_reduction = ReduceLROnPlateau(
        monitor="val_loss",
        patience=3,
        factor=0.2,
        min_lr=1e-6,
        verbose=1
    )
    
    # 4. FASE 1: Warmup da Cabeça de Classificação (Extrator Congelado)
    print("\n[INFO] FASE 1: Treinamento da Cabeça de Classificação (Warmup)...")
    # Garante que a base MobileNetV2 esteja congelada
    for layer in augmented_model.layers:
        if layer.name == model.name:
            # Acessa o modelo base interno
            for sub_layer in layer.layers:
                if "mobilenetv2" in sub_layer.name:
                    sub_layer.trainable = False
                    
    augmented_model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=1e-3),
        loss="categorical_crossentropy",
        metrics=["accuracy"]
    )
    
    augmented_model.fit(
        train_ds,
        validation_data=val_ds,
        epochs=epochs_warmup,
        class_weight=class_weights,
        callbacks=[checkpoint, lr_reduction]
    )
    
    # 5. FASE 2: Fine-Tuning do Extrator de Características (Descongelamento parcial)
    print("\n[INFO] FASE 2: Descongelando camadas superiores da MobileNetV2 para Fine-Tuning...")
    # Descongela o modelo base interno por inteiro para ajuste fino leve
    for layer in augmented_model.layers:
        if layer.name == model.name:
            for sub_layer in layer.layers:
                if "mobilenetv2" in sub_layer.name:
                    sub_layer.trainable = True
                    
    # Compila com uma taxa de aprendizado extremamente baixa para evitar destruição de características da ImageNet
    augmented_model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=1e-5),
        loss="categorical_crossentropy",
        metrics=["accuracy"]
    )
    
    print("[INFO] Iniciando Fine-Tuning...")
    augmented_model.fit(
        train_ds,
        validation_data=val_ds,
        epochs=epochs_finetune,
        class_weight=class_weights,
        callbacks=[checkpoint, early_stopping, lr_reduction]
    )
    
    # Salva o modelo final com os melhores pesos restaurados pelo EarlyStopping
    print("[INFO] Salvando pesos finais restaurados pelo EarlyStopping...")
    model.save(MODEL_PATH)
    
    # 6. Avaliação Final
    print("\n[INFO] Carregando o melhor checkpoint salvo para avaliação final...")
    best_model = tf.keras.models.load_model(MODEL_PATH)
    val_loss, val_acc = best_model.evaluate(val_ds, verbose=0)
    
    print("\n" + "=" * 60)
    if use_synthetic:
        print("      RESULTADO FINAL DO TREINAMENTO SIMULADO (SINTÉTICO)")
    else:
        print("      RESULTADO FINAL DO TREINAMENTO REAL (RAF-DB)")
    print("=" * 60)
    print(f"Acurácia de Validação Final : {val_acc * 100:.2f}%")
    print(f"Taxa de Erro (Loss) Final   : {val_loss:.4f}")
    print(f"Melhor checkpoint salvo em  : '{MODEL_PATH}'")
    print("=" * 60)

if __name__ == "__main__":
    main()
