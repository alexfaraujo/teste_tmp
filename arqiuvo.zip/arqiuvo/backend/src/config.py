import os

# Configurações do Sistema FER
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# Parâmetros da Câmera (Legado / Testes Locais)
CAMERA_INDEX = 0          # Índice da webcam padrão
FRAME_WIDTH = 640         # Largura do frame de captura
FRAME_HEIGHT = 480        # Altura do frame de captura

# Parâmetros do Detector Facial (MediaPipe BlazeFace)
MIN_DETECTION_CONFIDENCE = 0.5  # Confiança mínima para detecção da face

# Parâmetros do Modelo de Classificação de Sentimentos (MobileNetV2)
INPUT_SHAPE = (224, 224, 3)  # Altura, Largura, Canais (RGB para MobileNetV2)
MODEL_PATH = os.path.join(BASE_DIR, "models", "mobilenetv2_fer_model.keras")  # Caminho absoluto derivado da raiz do backend

# Mapeamento das 7 Emoções Universais (Ekman)
EMOTION_LABELS = {
    0: "Raiva",
    1: "Nojo",
    2: "Medo",
    3: "Felicidade",
    4: "Tristeza",
    5: "Surpresa",
    6: "Neutro"
}

# Configurações do Server Backend Web (FastAPI)
UPLOAD_DIR = os.path.join(BASE_DIR, "uploads")    # Pasta estática para salvar imagens dos uploads do App Mobile
API_HOST = "0.0.0.0"      # Interface de escuta (acessível pela rede local para dispositivos móveis)
API_PORT = 8000           # Porta padrão do servidor Uvicorn/FastAPI
