import cv2
import mediapipe as mp
from src.config import MIN_DETECTION_CONFIDENCE

class FaceDetector:
    """
    Encapsula o detector facial do MediaPipe (BlazeFace).
    Fornece métodos para detecção de rostos e extração de região de interesse (ROI).
    """
    
    def __init__(self, min_detection_confidence: float = MIN_DETECTION_CONFIDENCE):
        self.mp_face_detection = mp.solutions.face_detection
        # Inicializa o detector facial do MediaPipe
        self.face_detection = self.mp_face_detection.FaceDetection(
            min_detection_confidence=min_detection_confidence,
            model_selection=0  # 0 para distâncias curtas (até 2m, ideal para webcam)
        )
        
    def detect_faces(self, frame):
        """
        Detecta rostos no frame de entrada.
        Retorna:
            list: Lista de tuplas (x, y, w, h) representando as caixas envolventes (bounding boxes).
        """
        if frame is None:
            return []
            
        h, w, _ = frame.shape
        # O MediaPipe espera imagens em formato RGB
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = self.face_detection.process(rgb_frame)
        
        faces = []
        if results.detections:
            for detection in results.detections:
                bbox_data = detection.location_data.relative_bounding_box
                
                # Converte as coordenadas normalizadas [0.0, 1.0] para pixels absolutos
                x = int(bbox_data.xmin * w)
                y = int(bbox_data.ymin * h)
                width = int(bbox_data.width * w)
                height = int(bbox_data.height * h)
                
                # Limita as coordenadas às dimensões reais do frame para evitar estouro de índices
                x_start = max(0, x)
                y_start = max(0, y)
                x_end = min(w, x + width)
                y_end = min(h, y + height)
                
                # Calcula largura e altura finais ajustadas dentro do frame
                final_w = x_end - x_start
                final_h = y_end - y_start
                
                # Apenas adiciona bounding boxes válidas
                if final_w > 0 and final_h > 0:
                    faces.append((x_start, y_start, final_w, final_h))
                    
        return faces
        
    def extract_roi(self, frame, bbox):
        """
        Recorta a região de interesse (ROI) do rosto no frame.
        Retorna:
            numpy.ndarray: Imagem recortada do rosto, ou None se inválida.
        """
        if frame is None or bbox is None:
            return None
            
        x, y, w, h = bbox
        
        # Garante recorte seguro (evitando fatiamento com dimensões nulas)
        if w <= 0 or h <= 0:
            return None
            
        roi = frame[y:y+h, x:x+w]
        return roi
        
    def close(self):
        """Libera os recursos internos do detector do MediaPipe."""
        if hasattr(self, 'face_detection') and self.face_detection is not None:
            self.face_detection.close()
            self.face_detection = None
