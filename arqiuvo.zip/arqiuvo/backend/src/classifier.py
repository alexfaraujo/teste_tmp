import os
# Silencia avisos de depuração do TensorFlow para manter a saída limpa
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

import cv2
import numpy as np
import tensorflow as tf
from tensorflow.keras import layers, models
from src.config import INPUT_SHAPE, MODEL_PATH, EMOTION_LABELS

class EmotionClassifier:
    """
    Define a arquitetura de Transfer Learning baseada em MobileNetV2 (pré-treinada na ImageNet)
    e gerencia o pré-processamento de imagens e inferência para Reconhecimento de Expressões Faciais.
    """
    
    def __init__(self, model_path: str = MODEL_PATH, input_shape: tuple = INPUT_SHAPE):
        self.model_path = model_path
        self.input_shape = input_shape
        self.classes = EMOTION_LABELS
        
        # Reconstrói a arquitetura da rede neural usando MobileNetV2
        self.model = self._build_model()
        
        # Tenta carregar o modelo completo pré-treinado para FER, caso exista na pasta models
        if os.path.exists(self.model_path):
            print(f"[INFO] Buscando modelo treinado em '{self.model_path}'...")
            try:
                # Tenta carregar o modelo completo primeiro para máxima compatibilidade
                self.model = tf.keras.models.load_model(self.model_path)
                print("[INFO] CONFIRMADO: Modelo treinado com reforço (RAF-DB) carregado com sucesso.")
            except Exception as e:
                print(f"[AVISO] Falha ao carregar modelo completo: {e}. Tentando carregar apenas os pesos...")
                try:
                    self.model.load_weights(self.model_path)
                    print("[INFO] CONFIRMADO: Pesos do modelo treinados com reforço carregados com sucesso.")
                except Exception as e2:
                    print(f"[ERRO] Falha crítica ao carregar pesos: {e2}.")
                    print("[AVISO] Utilizando modelo de base (ImageNet) + classificador aleatório (não treinado).")
        else:
            print(f"[AVISO] Arquivo de modelo/pesos '{self.model_path}' não encontrado.")
            print("[AVISO] Utilizando modelo de base (ImageNet) + classificador aleatório (modo simulação/mock).")
            
    def _build_model(self) -> models.Model:
        """Constrói o modelo usando MobileNetV2 pré-treinada como extrator de características."""
        # Carrega o modelo MobileNetV2 pré-treinado no ImageNet (exclui o topo/classificador)
        base_model = tf.keras.applications.MobileNetV2(
            input_shape=self.input_shape,
            include_top=False,
            weights='imagenet'
        )
        # Congela os pesos do extrator de características
        base_model.trainable = False
        
        # Define a nova cabeça de classificação para 7 emoções
        model = models.Sequential([
            base_model,
            layers.GlobalAveragePooling2D(),
            layers.Dense(128, activation='relu'),
            layers.Dropout(0.5),
            layers.Dense(7, activation='softmax')  # 7 emoções de Ekman
        ])
        
        # Compila o modelo
        model.compile(
            optimizer='adam',
            loss='categorical_crossentropy',
            metrics=['accuracy']
        )
        return model
        
    def pre_process(self, roi):
        """
        Pré-processa a ROI do rosto para MobileNetV2.
        1. Converte de BGR para RGB.
        2. Redimensiona para (224, 224).
        3. Normaliza usando a função nativa do MobileNetV2 (escala para [-1, 1]).
        4. Expande para a dimensão de lote (1, 224, 224, 3).
        """
        if roi is None or roi.size == 0:
            return None
            
        # Converte para RGB
        if len(roi.shape) == 2 or roi.shape[2] == 1:
            # Caso a imagem de entrada esteja em escala de cinza
            rgb_roi = cv2.cvtColor(roi, cv2.COLOR_GRAY2RGB)
        else:
            # OpenCV lê em BGR; converte para RGB para a MobileNetV2
            rgb_roi = cv2.cvtColor(roi, cv2.COLOR_BGR2RGB)
            
        # Redimensiona para o tamanho de entrada esperado (224x224)
        resized = cv2.resize(rgb_roi, (self.input_shape[0], self.input_shape[1]))
        
        # Normalização específica da MobileNetV2
        preprocessed = tf.keras.applications.mobilenet_v2.preprocess_input(resized.astype(np.float32))
        
        # Adiciona a dimensão de batch (1, 224, 224, 3)
        expanded = np.expand_dims(preprocessed, axis=0)
        
        return expanded
        
    def classify(self, roi):
        """
        Executa a classificação do sentimento a partir da ROI do rosto.
        Retorna:
            str: Rótulo da emoção mais provável.
            float: Confiança/probabilidade da emoção.
        """
        pre_processed = self.pre_process(roi)
        if pre_processed is None:
            return "Neutro", 0.0
            
        # Executa a inferência
        predictions = self.model.predict(pre_processed, verbose=0)
        
        # Identifica a classe de maior probabilidade
        max_idx = int(np.argmax(predictions[0]))
        label = self.classes.get(max_idx, "Neutro")
        confidence = float(predictions[0][max_idx])
        
        return label, confidence
