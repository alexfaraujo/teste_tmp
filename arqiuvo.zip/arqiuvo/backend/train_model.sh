#!/usr/bin/env bash

# Script para automatizar a configuração do ambiente, verificação do dataset RAF-DB e disparo do treinamento.
set -eo pipefail

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # Sem cor

echo -e "${GREEN}[INFO] Iniciando script de automação de treinamento FER (MobileNetV2)...${NC}"

# 1. Verifica se o ambiente virtual (.venv) existe
if [ ! -d ".venv" ]; then
    echo -e "${YELLOW}[AVISO] Ambiente virtual (.venv) não encontrado. Criando ambiente...${NC}"
    python3 -m venv .venv
    echo -e "${GREEN}[INFO] Ambiente virtual criado com sucesso.${NC}"
fi

# 2. Ativa o ambiente virtual (.venv)
echo -e "${GREEN}[INFO] Ativando ambiente virtual (.venv)...${NC}"
# shellcheck disable=SC1091
source .venv/bin/activate

# 3. Atualiza dependências
echo -e "${GREEN}[INFO] Verificando e instalando dependências...${NC}"
pip install --upgrade pip
pip install -r requirements.txt

# 4. Verifica se foi passado um arquivo zip do dataset por argumento
ZIP_PATH="$1"
DATASET_DIR="datasets/raf-db"

if [ -n "$ZIP_PATH" ]; then
    if [ -f "$ZIP_PATH" ]; then
        echo -e "${GREEN}[INFO] Arquivo zip fornecido: '$ZIP_PATH'. Extraindo para '$DATASET_DIR'...${NC}"
        mkdir -p "$DATASET_DIR"
        unzip -q "$ZIP_PATH" -d "$DATASET_DIR" || tar -xf "$ZIP_PATH" -C "$DATASET_DIR"
        echo -e "${GREEN}[INFO] Extração concluída com sucesso.${NC}"
    elif [ -d "$ZIP_PATH" ]; then
        echo -e "${GREEN}[INFO] Diretório fornecido: '$ZIP_PATH'. Vinculando para '$DATASET_DIR'...${NC}"
        mkdir -p "datasets"
        ln -sfn "$(realpath "$ZIP_PATH")" "$DATASET_DIR"
    else
        echo -e "${RED}[ERRO] O caminho fornecido '$ZIP_PATH' não é um arquivo ou diretório válido.${NC}"
        exit 1
    fi
fi

if [ ! -d "$DATASET_DIR" ] || ( [ ! -d "$DATASET_DIR/Image/aligned" ] && [ ! -f "$DATASET_DIR/train_labels.csv" ] ); then
    echo -e "${YELLOW}[AVISO] Diretório ou arquivos do dataset RAF-DB não encontrados.${NC}"
    echo -e "${YELLOW}[AVISO] Para realizar um treinamento com dados reais, coloque a base de dados na estrutura CSV (train_labels.csv, test_labels.csv, DATASET/) ou na estrutura clássica (EmoLabel/, Image/aligned/) dentro de '$DATASET_DIR', ou passe o caminho do arquivo .zip/pasta por argumento.${NC}"
    echo -e ""
    echo -e "${YELLOW}[AVISO] Como o dataset real não foi detectado, o script prosseguirá no modo de simulação com dados sintéticos/dummy.${NC}"
else
    echo -e "${GREEN}[INFO] Base de dados RAF-DB detectada e pronta em '$DATASET_DIR'.${NC}"
fi

# 5. Executa o script de treinamento
echo -e "${GREEN}[INFO] Iniciando rotina de treinamento do classificador...${NC}"
python src/train.py

echo -e "${GREEN}[INFO] Processo de treinamento finalizado!${NC}"
