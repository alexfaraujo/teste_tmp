#!/usr/bin/env bash

# Script para automatizar a configuração do ambiente, instalação de dependências e execução do servidor FastAPI Backend FER.
# Define regras rígidas de execução para falhar imediatamente se ocorrer algum erro.
set -eo pipefail

# Definições de Cores para logs amigáveis
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # Sem cor

echo -e "${GREEN}[INFO] Iniciando script de configuração e execução do servidor Backend Web FER...${NC}"

# 1. Verifica se o ambiente virtual (.venv) existe
if [ ! -d ".venv" ]; then
    echo -e "${YELLOW}[AVISO] Ambiente virtual (.venv) não encontrado. Criando ambiente virtual...${NC}"
    python3 -m venv .venv
    echo -e "${GREEN}[INFO] Ambiente virtual criado com sucesso.${NC}"
fi

# 2. Ativa o ambiente virtual (.venv)
echo -e "${GREEN}[INFO] Ativando ambiente virtual (.venv)...${NC}"
# shellcheck disable=SC1091
source .venv/bin/activate

# 3. Atualiza pip e instala dependências do requirements.txt
echo -e "${GREEN}[INFO] Verificando e instalando dependências...${NC}"
pip install --upgrade pip
pip install -r requirements.txt

# 4. Garante a existência das pastas estáticas e de modelos
if [ ! -d "models" ]; then
    mkdir -p models
    touch models/.gitkeep
fi

if [ ! -d "uploads" ]; then
    echo -e "${YELLOW}[AVISO] Pasta estática 'uploads/' não encontrada. Criando diretório...${NC}"
    mkdir -p uploads
    echo -e "${GREEN}[INFO] Pasta estática 'uploads/' criada com sucesso.${NC}"
fi

# 5. Execução do Servidor Web FastAPI via Uvicorn
echo -e "${GREEN}[INFO] Servidor Web disponível em http://localhost:8000${NC}"
echo -e "${GREEN}[INFO] Documentação Swagger interativa em http://localhost:8000/docs${NC}"
echo -e "${GREEN}[INFO] Iniciando Uvicorn na porta 8000 (0.0.0.0)...${NC}"

exec uvicorn main:app --host 0.0.0.0 --port 8000 --reload
