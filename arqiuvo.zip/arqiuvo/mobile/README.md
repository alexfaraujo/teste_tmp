# Mobile App - Face Trainer TEA (Versão Futura v2.0)

Este diretório está reservado para a versão nativa mobile (React Native / Flutter / Android Native) do aplicativo **Face Trainer TEA**.

## 📌 Escopo da Versão 2.0
- Autenticação e perfil de usuário.
- Histórico de progresso e estatísticas de treinamento.
- Conquistas e sistema de troféus.
- Integração nativa com câmera e sensores do smartphone.
