from fastapi import FastAPI, HTTPException, Body
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from datetime import datetime
import sqlite3

app = FastAPI()

# Mount static files
import os
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR = os.path.join(BASE_DIR, "static")
if not os.path.exists(STATIC_DIR):
    os.makedirs(STATIC_DIR)
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


# Configuration
API_KEY = "demo-key-123"  # In production, use environment variables

import os
from dotenv import load_dotenv
import httpx

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(BASE_DIR, ".env"))

DB_NAME = os.path.join(BASE_DIR, "padlock.db")


def init_db():
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS requests (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            api_key TEXT,
            device_id TEXT,
            timestamp TEXT,
            status TEXT DEFAULT 'pendente'
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT,
            device_id TEXT UNIQUE,
            data_cadastro TEXT,
            email TEXT,
            matricula TEXT,
            curso TEXT,
            turno TEXT,
            professor_responsavel TEXT,
            status_if5 TEXT DEFAULT 'pendente',
            status_orientador TEXT DEFAULT 'pendente',
            tipo_projeto TEXT,
            tema_projeto TEXT
        )
    ''')
    
    # Migration for existing databases
    try:
        cursor.execute('ALTER TABLE users ADD COLUMN tipo_projeto TEXT')
    except sqlite3.OperationalError:
        pass # Column likely exists
        
    try:
        cursor.execute('ALTER TABLE users ADD COLUMN tema_projeto TEXT')
    except sqlite3.OperationalError:
        pass # Column likely exists
        
    try:
        cursor.execute("ALTER TABLE requests ADD COLUMN status TEXT DEFAULT 'pendente'")
    except sqlite3.OperationalError:
        pass # Column likely exists
    
    try:
        cursor.execute("ALTER TABLE requests ADD COLUMN hora_abertura TEXT")
    except sqlite3.OperationalError:
        pass # Column likely exists
        
    try:
        cursor.execute("ALTER TABLE requests ADD COLUMN hora_fechamento TEXT")
    except sqlite3.OperationalError:
        pass # Column likely exists

    try:
        cursor.execute("ALTER TABLE requests ADD COLUMN user_id INTEGER")
    except sqlite3.OperationalError:
        pass # Column likely exists
        
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS external_devices (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT,
            api_key TEXT UNIQUE,
            status TEXT DEFAULT 'ativo'
        )
    ''')
    
    # Insert test device if it doesn't exist
    cursor.execute("INSERT OR IGNORE INTO external_devices (nome, api_key) VALUES (?, ?)", ('Dispositivo de Teste', 'chave_teste_123'))
        
    conn.commit()
    conn.close()

# Initialize DB on startup
init_db()

class UnlockRequest(BaseModel):
    apiKey: str
    timestamp: str | None = None
    deviceId: str | None = None

class UserRegister(BaseModel):
    nome: str
    device_id: str
    email: str
    matricula: str
    curso: str
    turno: str
    professor_responsavel: str
    tipo_projeto: str
    tema_projeto: str

class DeviceStatus(BaseModel):
    registered: bool
    status_if5: str | None = None
    status_orientador: str | None = None

class UserUpdate(BaseModel):
    status_if5: str | None = None
    status_orientador: str | None = None


@app.post("/unlock")
async def unlock(request: UnlockRequest):
    print(f"Received unlock request: {request}")
    print(f"Device ID: {request.deviceId}")
    
    if request.apiKey != API_KEY:
        raise HTTPException(status_code=403, detail="Invalid API Key")
    
    try:
        conn = sqlite3.connect(DB_NAME)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        # Check for existing pending requests
        cursor.execute("SELECT id, timestamp FROM requests WHERE status = 'pendente'")
        pending_rows = cursor.fetchall()
        
        for row in pending_rows:
            try:
                req_time = datetime.fromisoformat(row['timestamp'])
                time_diff = datetime.now() - req_time
                # If there is a pending request less than 60 seconds old
                if time_diff.total_seconds() <= 60:
                    conn.close()
                    raise HTTPException(status_code=409, detail="Existe uma solicitação em andamento. Por favor, aguarde a pessoa à sua frente entrar.")
                else:
                    # Expire old request
                     cursor.execute("UPDATE requests SET status = 'expirado' WHERE id = ?", (row['id'],))
            except ValueError:
                continue
        
        # Look up user_id
        cursor.execute("SELECT id FROM users WHERE device_id = ?", (request.deviceId,))
        user_row = cursor.fetchone()
        user_id = user_row['id'] if user_row else None

        # If we got here, we can insert the new request
        cursor.execute(
            'INSERT INTO requests (api_key, device_id, timestamp, status, user_id) VALUES (?, ?, ?, ?, ?)',
            (request.apiKey, request.deviceId, datetime.now().isoformat(), 'pendente', user_id)
        )
        conn.commit()
        conn.close()
    except HTTPException as he:
        raise he
    except Exception as e:
        print(f"Database error: {e}")
        # We generally don't want to fail the request if logging fails, but it's up to requirements.
        # For now, we'll proceed.

    return {
        "status": "success",
        "message": "Unlock request received successfully",
        "timestamp": datetime.now().isoformat()
    }

@app.get("/pending-requests")
async def check_pending_requests(device_key: str, status: str | None = None, request_id: int | None = None):
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row # Access columns by name
    cursor = conn.cursor()
    
    # Validate external device key
    cursor.execute("SELECT 1 FROM external_devices WHERE api_key = ? AND status = 'ativo'", (device_key,))
    if not cursor.fetchone():
        conn.close()
        raise HTTPException(status_code=401, detail="Invalid or inactive Device Key")
    
    # Get all pending requests
    cursor.execute("SELECT id, timestamp FROM requests WHERE status = 'pendente'")
    pending_rows = cursor.fetchall()
    
    has_valid_pending = False
    valid_request_id = None
    
    for row in pending_rows:
        try:
            req_time = datetime.fromisoformat(row['timestamp'])
            time_diff = datetime.now() - req_time
            # Check if older than 1 minute (60 seconds)
            if time_diff.total_seconds() > 60:
                print(f"Expiring request {row['id']} (Age: {time_diff.total_seconds()}s)")
                cursor.execute("UPDATE requests SET status = 'expirado' WHERE id = ?", (row['id'],))
            else:
                has_valid_pending = True
                valid_request_id = row['id']
                # Correctly identify the FIRST valid pending request or just the latest? 
                # Usually FIFO (queue), so the one with smallest ID (or oldest timestamp) should be processed first.
                # pending_rows fetches in default order (usually ID asc).
                # So we take the first valid one we encounter?
                # Let's assume we want to process the *oldest* valid request first. 
                # The loop iterates through them. We can just break on the first valid one if we want to return just that ID.
                # But we also want to expire others? 
                # Let's stick to: scan all to expire old ones, and keep the *last* valid one found? 
                # Or better: keep the *first* valid one found (FIFO).
                if valid_request_id and row['id'] > valid_request_id:
                     pass # We already have a valid earlier ID
                else:
                     valid_request_id = row['id']

        except ValueError:
            continue
            
    # If status update is requested
    if status:
        if request_id is None:
             conn.close()
             raise HTTPException(status_code=400, detail="request_id is required when updating status")

        current_time = datetime.now().isoformat()
        
        if status == 'aberto':
            cursor.execute("UPDATE requests SET status = 'aberto', hora_abertura = ? WHERE id = ? AND status = 'pendente'", (current_time, request_id))
            if cursor.rowcount > 0:
                print(f"Request {request_id} updated to 'aberto'")
            else:
                print(f"Request {request_id} update to 'aberto' failed (status not 'pendente' or ID invalid)")
                
        elif status == 'fechado':
            cursor.execute("UPDATE requests SET status = 'fechado', hora_fechamento = ? WHERE id = ?", (current_time, request_id))
            print(f"Request {request_id} updated to 'fechado'")
            
            # Send welcome message
            cursor.execute("SELECT user_id FROM requests WHERE id = ?", (request_id,))
            req_row = cursor.fetchone()
            if req_row and req_row['user_id']:
                await send_welcome_message(req_row['user_id'])
            
    conn.commit()
    conn.close()
    
    response = {"has_pending": has_valid_pending}
    if has_valid_pending and valid_request_id:
        response["request_id"] = valid_request_id
        
    return response

@app.get("/last-access/{device_id}")
async def get_last_access(device_id: str):
    try:
        conn = sqlite3.connect(DB_NAME)
        cursor = conn.cursor()
        cursor.execute(
            'SELECT timestamp FROM requests WHERE device_id = ? ORDER BY id DESC LIMIT 1',
            (device_id,)
        )
        row = cursor.fetchone()
        conn.close()
        
        return {"last_access": row[0] if row else None}
    except Exception as e:
        print(f"Database error: {e}")
        return {"last_access": None}

@app.get("/check-device/{device_id}")
async def check_device(device_id: str):
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute('SELECT status_if5, status_orientador FROM users WHERE device_id = ?', (device_id,))
    row = cursor.fetchone()
    conn.close()
    
    if row:
        return {
            "registered": True,
            "status_if5": row['status_if5'],
            "status_orientador": row['status_orientador']
        }
    else:
        return {
            "registered": False,
            "status_if5": None,
            "status_orientador": None
        }

@app.post("/register")
async def register_user(user: UserRegister):
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    try:
        cursor.execute('''
            INSERT INTO users (nome, device_id, data_cadastro, email, matricula, curso, turno, professor_responsavel, tipo_projeto, tema_projeto)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            user.nome,
            user.device_id,
            datetime.now().isoformat(),
            user.email,
            user.matricula,
            user.curso,
            user.turno,
            user.professor_responsavel,
            user.tipo_projeto,
            user.tema_projeto
        ))
        conn.commit()
        conn.close()
        return {"status": "success", "message": "User registered successfully"}
    except sqlite3.IntegrityError:
        conn.close()
        raise HTTPException(status_code=400, detail="Device ID already registered")
    except Exception as e:
        conn.close()
        print(f"Registration error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.get("/users")
async def get_users():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users")
    users = cursor.fetchall()
    conn.close()
    return users

@app.put("/users/{user_id}/status")
async def update_user_status(user_id: int, status_update: UserUpdate):
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    
    updates = []
    params = []
    
    if status_update.status_if5:
        updates.append("status_if5 = ?")
        params.append(status_update.status_if5)
        
    if status_update.status_orientador:
        updates.append("status_orientador = ?")
        params.append(status_update.status_orientador)
        
    if not updates:
        conn.close()
        return {"message": "No updates provided"}
        
    params.append(user_id)
    query = f"UPDATE users SET {', '.join(updates)} WHERE id = ?"
    
    cursor.execute(query, tuple(params))
    conn.commit()
    
    if cursor.rowcount == 0:
        conn.close()
        raise HTTPException(status_code=404, detail="User not found")
        
    conn.close()
    return {"status": "success", "message": "User status updated"}

@app.get("/")
async def root():
    return {"message": "Digital Padlock API is running"}

async def send_welcome_message(user_id: int):
    try:
        conn = sqlite3.connect(DB_NAME)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute("SELECT nome FROM users WHERE id = ?", (user_id,))
        user = cursor.fetchone()
        conn.close()
        
        if not user:
            print(f"User {user_id} not found for welcome message")
            return

        nome = user['nome']
        primeiro_nome = nome.split()[0] if nome else "Visitante"
        
        message_text = f"Olá {primeiro_nome}. Boas vindas ao Laboratório de Software IF5"
        
        url = os.getenv("SPEAK_API_URL")
        api_key = os.getenv("SPEAK_API_KEY")
        token = os.getenv("SPEAK_API_TOKEN")
        device = os.getenv("SPEAK_API_DEVICE")
        
        if not all([url, api_key, token, device]):
             print("Missing configuration for speak API")
             return

        headers = {
            "Content-Type": "application/json",
            "X-API-KEY": api_key
        }
        
        payload = {
            "text": message_text,
            "token": token,
            "device": device
        }
        
        async with httpx.AsyncClient() as client:
            response = await client.post(url, json=payload, headers=headers)
            if response.status_code == 200:
                print(f"Welcome message sent for {primeiro_nome}")
            else:
                print(f"Failed to send welcome message: {response.status_code} {response.text}")
                
    except Exception as e:
        print(f"Error sending welcome message: {e}")
