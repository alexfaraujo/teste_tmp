import os
from datetime import datetime, time
from typing import List, Optional
from contextlib import asynccontextmanager

import cv2
import numpy as np
from fastapi import FastAPI, Depends, File, UploadFile, Form, HTTPException, status, Security, Header, Response
from fastapi.responses import FileResponse
from fastapi.security.api_key import APIKeyHeader
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import select, func, update
from sqlalchemy.orm import Session

from app.config import settings
from app.database import get_db, Student, CourseUnit, Attendance, Teacher, AttendanceSession
from app.schemas import (
    CourseUnitCreate, CourseUnitResponse,
    StudentResponse, StudentEnrolledResponse, AttendanceResponse,
    TeacherCreate, TeacherUpdate, TeacherResponse,
    AttendanceSessionCreate, AttendanceSessionResponse, AttendanceSessionClose
)
from app.vision import VisionEngine

TEACHER_UPLOAD_DIR = "public/uploads/teachers"

# Configuração de autenticação por API Key (Header x-api-key)
API_KEY_NAME = "x-api-key"
api_key_header = APIKeyHeader(name=API_KEY_NAME, auto_error=False)

async def verify_api_key(api_key: str = Security(api_key_header)):
    """Dependência para verificar a chave de API nas rotas protegidas."""
    if api_key == settings.API_KEY:
        return api_key
    raise HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail="Acesso negado: Chave de API inválida ou ausente."
    )


async def get_current_teacher_email(
    x_user_email: str = Header(..., description="E-mail do professor conectado via Google OAuth")
) -> str:
    """
    Dependência para obter o e-mail do professor ativo.
    Valida se o domínio do e-mail institucional pertence à lista de domínios autorizados.
    """
    if not x_user_email:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Usuário não autenticado: e-mail ausente."
        )
    email_lower = x_user_email.strip().lower()

    if "@" not in email_lower:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Formato de e-mail inválido."
        )
    domain = email_lower.split("@")[1]

    if domain not in settings.allowed_domains_list:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"Acesso negado: Domínio do e-mail '{domain}' não está na lista de domínios autorizados."
        )
    return email_lower


def get_current_teacher(
    email: str = Depends(get_current_teacher_email),
    db: Session = Depends(get_db)
) -> Teacher:
    """Resolve o professor autenticado no banco para aplicar escopo de dados por dono."""
    stmt = select(Teacher).where(Teacher.email == email)
    teacher = db.scalars(stmt).first()
    if not teacher:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Cadastro do professor pendente. Por favor, realize o auto-cadastro."
        )
    return teacher

# Instância global do motor de visão
vision_engine: Optional[VisionEngine] = None

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Context manager para carregar modelos ONNX apenas na inicialização."""
    global vision_engine
    print("Iniciando a API e carregando modelos ONNX...")
    try:
        vision_engine = VisionEngine()
        print("Modelos ONNX carregados com sucesso!")
    except Exception as e:
        print(f"Erro crítico ao carregar modelos de IA: {e}")
        # Permite que a API inicie mesmo se falhar (útil para desenvolvimento ou testes sem modelos)
        pass
    yield
    print("Desligando a API...")

app = FastAPI(
    title="Sistema de Chamada Facial",
    description="API REST de controle de presenças utilizando biometria facial e pgvector.",
    version="1.0.0",
    lifespan=lifespan,
    dependencies=[Depends(verify_api_key)]
)

# Configuração de CORS para permitir acessos de frontends
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Garantir existência da pasta de uploads privados de professores
os.makedirs(TEACHER_UPLOAD_DIR, exist_ok=True)

# ----------------- ROTAS DE UNIDADES CURRICULARES (DISCIPLINAS) -----------------

@app.post(
    "/api/course_units",
    response_model=CourseUnitResponse,
    status_code=status.HTTP_201_CREATED,
    tags=["Unidades Curriculares"],
    dependencies=[Depends(verify_api_key)]
)
def create_course_unit(
    unit: CourseUnitCreate,
    teacher: Teacher = Depends(get_current_teacher),
    db: Session = Depends(get_db)
):
    """Cadastra uma nova Unidade Curricular (Disciplina) no sistema."""
    # Verificar se o código já existe
    stmt = select(CourseUnit).where(CourseUnit.code == unit.code)
    if db.scalars(stmt).first():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Código de Unidade Curricular '{unit.code}' já cadastrado."
        )
        
    db_unit = CourseUnit(
        name=unit.name,
        code=unit.code,
        workload=unit.workload,
        classroom=unit.classroom,
        teacher_id=teacher.id,
    )
    db.add(db_unit)
    db.commit()
    db.refresh(db_unit)
    return db_unit

@app.get(
    "/api/course_units",
    response_model=List[CourseUnitResponse],
    tags=["Unidades Curriculares"]
)
def list_course_units(
    teacher: Teacher = Depends(get_current_teacher),
    db: Session = Depends(get_db)
):
    """Lista todas as Unidades Curriculares cadastradas."""
    stmt = (
        select(CourseUnit)
        .where(CourseUnit.teacher_id == teacher.id)
        .order_by(CourseUnit.name)
    )
    return db.scalars(stmt).all()

@app.put(
    "/api/course_units/{unit_id}",
    response_model=CourseUnitResponse,
    tags=["Unidades Curriculares"],
    dependencies=[Depends(verify_api_key)]
)
def update_course_unit(
    unit_id: int,
    unit: CourseUnitCreate,
    teacher: Teacher = Depends(get_current_teacher),
    db: Session = Depends(get_db)
):
    """Atualiza os dados de uma Unidade Curricular (Disciplina) cadastrada."""
    stmt = select(CourseUnit).where(
        CourseUnit.id == unit_id,
        CourseUnit.teacher_id == teacher.id
    )
    db_unit = db.scalars(stmt).first()
    if not db_unit:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Unidade Curricular não encontrada."
        )
        
    # Verificar se o novo código já existe em outra UC
    stmt_code = select(CourseUnit).where((CourseUnit.code == unit.code) & (CourseUnit.id != unit_id))
    if db.scalars(stmt_code).first():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Código de Unidade Curricular '{unit.code}' já cadastrado para outra disciplina."
        )
        
    db_unit.name = unit.name
    db_unit.code = unit.code
    db_unit.workload = unit.workload
    db_unit.classroom = unit.classroom
    
    db.commit()
    db.refresh(db_unit)
    return db_unit

@app.delete(
    "/api/course_units/{unit_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    tags=["Unidades Curriculares"],
    dependencies=[Depends(verify_api_key)]
)
def delete_course_unit(
    unit_id: int,
    teacher: Teacher = Depends(get_current_teacher),
    db: Session = Depends(get_db)
):
    """Remove uma Unidade Curricular (Disciplina) cadastrada do sistema."""
    stmt = select(CourseUnit).where(
        CourseUnit.id == unit_id,
        CourseUnit.teacher_id == teacher.id
    )
    db_unit = db.scalars(stmt).first()
    if not db_unit:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Unidade Curricular não encontrada."
        )
        
    db.delete(db_unit)
    db.commit()
    return Response(status_code=status.HTTP_204_NO_CONTENT)

@app.get(
    "/api/course_units/{unit_id}/students",
    response_model=List[StudentEnrolledResponse],
    tags=["Unidades Curriculares"]
)
def list_students_enrolled_in_uc(
    unit_id: int,
    teacher: Teacher = Depends(get_current_teacher),
    db: Session = Depends(get_db)
):
    """Lista todos os estudantes matriculados em uma Unidade Curricular específica com suas métricas de frequência."""
    stmt = select(CourseUnit).where(
        CourseUnit.id == unit_id,
        CourseUnit.teacher_id == teacher.id
    )
    db_unit = db.scalars(stmt).first()
    if not db_unit:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Unidade Curricular não encontrada."
        )

    # 1. Carregar sessões de chamada da UC
    stmt_sessions = select(AttendanceSession).where(
        AttendanceSession.course_unit_id == unit_id
    )
    sessions = db.scalars(stmt_sessions).all()
    total_lessons = sum(s.lessons_count for s in sessions)

    # 2. Mapear as presenças de cada estudante matriculado nesta UC
    stmt_att = (
        select(Attendance.student_id, func.sum(AttendanceSession.lessons_count))
        .join(AttendanceSession, Attendance.attendance_session_id == AttendanceSession.id)
        .where(AttendanceSession.course_unit_id == unit_id)
        .group_by(Attendance.student_id)
    )
    presences_map = dict(db.execute(stmt_att).all())

    # 3. Construir resposta com contadores calculados
    response_data = []
    for student in db_unit.students:
        presences = presences_map.get(student.id, 0)
        absences = max(0, total_lessons - presences)
        frequency = (presences / total_lessons * 100) if total_lessons > 0 else 100.0

        response_data.append({
            "id": student.id,
            "name": student.name,
            "matricula": student.matricula,
            "created_at": student.created_at,
            "presences_count": presences,
            "absences_count": absences,
            "frequency_rate": round(frequency, 2)
        })

    return response_data


# ----------------- ROTAS DE ESTUDANTES -----------------

@app.post(
    "/api/students",
    response_model=StudentResponse,
    status_code=status.HTTP_201_CREATED,
    tags=["Estudantes"],
    dependencies=[Depends(verify_api_key)]
)
async def create_student(
    name: str = Form(..., description="Nome completo do estudante"),
    matricula: str = Form(..., description="Matrícula única do estudante"),
    course_unit_ids: str = Form(..., description="IDs das UCs separados por vírgula (ex: 1,2)"),
    photo: UploadFile = File(..., description="Foto de rosto frontal do estudante para biometria"),
    teacher: Teacher = Depends(get_current_teacher),
    db: Session = Depends(get_db)
):
    """Cadastra um estudante, extrai o embedding facial de sua foto e o matricula nas UCs fornecidas."""
    global vision_engine
    if vision_engine is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="O motor de visão não está inicializado."
        )

    # 1. Verificar se a matrícula já existe
    stmt_student = select(Student).where(
        Student.matricula == matricula,
        Student.teacher_id == teacher.id
    )
    if db.scalars(stmt_student).first():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Estudante com matrícula '{matricula}' já cadastrado."
        )

    # 2. Ler e decodificar a foto com OpenCV
    try:
        contents = await photo.read()
        nparr = np.frombuffer(contents, np.uint8)
        img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        if img is None:
            raise ValueError("Falha na decodificação de imagem.")
    except Exception:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Arquivo de foto inválido ou corrompido."
        )

    # 3. Processamento Facial (Detecção, Vivacidade, Alinhamento e Embedding)
    # Roda detecção facial
    bboxes, scores, kpss = vision_engine.detect_faces(img, threshold=0.5)
    if len(bboxes) == 0:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Nenhum rosto detectado na foto de cadastro."
        )
    if len(bboxes) > 1:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Mais de um rosto detectado. Use uma foto contendo apenas o seu rosto para o cadastro."
        )

    bbox = bboxes[0]
    kps = kpss[0]

    # Validação de Vivacidade (Liveness)
    liveness_score = vision_engine.check_liveness(img, bbox)
    if liveness_score < settings.LIVENESS_THRESHOLD:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"A foto de cadastro falhou no teste de vivacidade (Liveness: {liveness_score:.4f}). "
                   "Certifique-se de tirar uma foto real."
        )

    # Alinhar a face e extrair embedding
    aligned = vision_engine.align_face(img, kps)
    embedding = vision_engine.extract_embedding(aligned)

    # 4. Resolver as disciplinas (Course Units)
    try:
        cu_ids = [int(x.strip()) for x in course_unit_ids.split(",") if x.strip()]
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="IDs das disciplinas (course_unit_ids) devem ser inteiros separados por vírgula."
        )

    if not cu_ids:
         raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="É necessário matricular o estudante em pelo menos uma Unidade Curricular."
        )

    stmt_cus = select(CourseUnit).where(
        CourseUnit.id.in_(cu_ids),
        CourseUnit.teacher_id == teacher.id
    )
    db_course_units = db.scalars(stmt_cus).all()
    
    if len(db_course_units) != len(cu_ids):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Uma ou mais Unidades Curriculares especificadas não foram encontradas."
        )

    # 5. Criar e salvar o estudante
    # pgvector aceita o embedding como uma lista de floats ordinários
    db_student = Student(
        teacher_id=teacher.id,
        name=name,
        matricula=matricula,
        face_embedding=embedding.tolist()
    )
    db_student.course_units.extend(db_course_units)
    
    db.add(db_student)
    db.commit()
    db.refresh(db_student)
    
    return db_student

@app.get(
    "/api/students",
    response_model=List[StudentResponse],
    tags=["Estudantes"]
)
def list_students(
    teacher: Teacher = Depends(get_current_teacher),
    db: Session = Depends(get_db)
):
    """Lista todos os estudantes cadastrados com suas respectivas matrículas."""
    stmt = (
        select(Student)
        .where(
            Student.is_active == True,
            Student.teacher_id == teacher.id
        )
        .order_by(Student.name)
    )
    return db.scalars(stmt).all()


@app.put(
    "/api/students/{student_id}",
    response_model=StudentResponse,
    tags=["Estudantes"],
    dependencies=[Depends(verify_api_key)]
)
async def update_student(
    student_id: int,
    name: str = Form(..., description="Nome completo do estudante"),
    matricula: str = Form(..., description="Matrícula do estudante"),
    course_unit_ids: str = Form(..., description="IDs das UCs separados por vírgula (ex: 1,2)"),
    photo: Optional[UploadFile] = File(None, description="Nova foto de rosto frontal do estudante (opcional)"),
    teacher: Teacher = Depends(get_current_teacher),
    db: Session = Depends(get_db)
):
    """Atualiza as informações e matrículas de um estudante cadastrado. A biometria (foto) é opcional."""
    global vision_engine
    if vision_engine is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="O motor de visão não está inicializado."
        )

    # 1. Verificar se o estudante existe e está ativo
    stmt_student = select(Student).where(
        Student.id == student_id,
        Student.is_active == True,
        Student.teacher_id == teacher.id
    )
    db_student = db.scalars(stmt_student).first()
    if not db_student:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Estudante não encontrado ou inativo."
        )

    # 2. Verificar se a nova matrícula conflita com a de outro estudante ativo
    if matricula != db_student.matricula:
        stmt_conflict = select(Student).where(
            Student.matricula == matricula, 
            Student.id != student_id,
            Student.is_active == True,
            Student.teacher_id == teacher.id
        )
        conflict_student = db.scalars(stmt_conflict).first()
        if conflict_student:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Já existe outro estudante cadastrado com esta matrícula."
            )

    # 3. Resolver as disciplinas (Course Units)
    try:
        cu_ids = [int(x.strip()) for x in course_unit_ids.split(",") if x.strip()]
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="IDs das disciplinas devem ser inteiros separados por vírgula."
        )

    if not cu_ids:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="O estudante deve estar matriculado em pelo menos uma Unidade Curricular."
        )

    stmt_cus = select(CourseUnit).where(
        CourseUnit.id.in_(cu_ids),
        CourseUnit.teacher_id == teacher.id
    )
    db_course_units = db.scalars(stmt_cus).all()
    if len(db_course_units) != len(cu_ids):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Uma ou mais Unidades Curriculares especificadas não foram encontradas."
        )

    # 4. Processar foto biométrica opcional
    if photo is not None and photo.filename != "":
        try:
            contents = await photo.read()
            nparr = np.frombuffer(contents, np.uint8)
            img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            if img is None:
                raise ValueError()
        except Exception:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Nova foto enviada está corrompida ou é inválida."
            )

        bboxes, scores, kpss = vision_engine.detect_faces(img, threshold=0.5)
        if len(bboxes) == 0:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Nenhum rosto foi detectado na nova foto enviada."
            )
        
        best_idx = np.argmax(scores)
        bbox = bboxes[best_idx]
        kps = kpss[best_idx]

        # Validar vivacidade
        liveness_score = vision_engine.check_liveness(img, bbox)
        if liveness_score < settings.LIVENESS_THRESHOLD:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Detecção de vivacidade facial falhou na nova foto (Liveness: {liveness_score:.4f})."
            )

        aligned = vision_engine.align_face(img, kps)
        embedding = vision_engine.extract_embedding(aligned)
        db_student.face_embedding = embedding.tolist()

    # 5. Salvar atualizações
    db_student.name = name
    db_student.matricula = matricula
    
    # Atualizar lista de UCs
    db_student.course_units = db_course_units
    
    db.commit()
    db.refresh(db_student)
    
    return db_student


@app.delete(
    "/api/students/{student_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    tags=["Estudantes"],
    dependencies=[Depends(verify_api_key)]
)
def delete_student(
    student_id: int,
    teacher: Teacher = Depends(get_current_teacher),
    db: Session = Depends(get_db)
):
    """Desativa logicamente um estudante no sistema (exclusão lógica)."""
    stmt = select(Student).where(
        Student.id == student_id,
        Student.is_active == True,
        Student.teacher_id == teacher.id
    )
    db_student = db.scalars(stmt).first()
    if not db_student:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Estudante não encontrado ou já desativado."
        )
        
    db_student.is_active = False
    db.commit()
    return Response(status_code=status.HTTP_204_NO_CONTENT)


# ----------------- ROTAS DE CHAMADA FACIAL / PRESENÇA -----------------

@app.post(
    "/api/attendance",
    response_model=AttendanceResponse,
    status_code=status.HTTP_201_CREATED,
    tags=["Chamada Facial"],
    dependencies=[Depends(verify_api_key)]
)
async def register_attendance(
    attendance_session_id: int = Form(..., description="ID da sessão de chamada"),
    photo: UploadFile = File(..., description="Foto da chamada contendo a face do aluno"),
    teacher: Teacher = Depends(get_current_teacher),
    db: Session = Depends(get_db)
):
    """
    Registra a presença do aluno. Detecta a face, valida a vivacidade,
    realiza a busca vetorial por similaridade de cosseno e valida a matrícula ativa na UC da sessão.
    """
    global vision_engine
    if vision_engine is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="O motor de visão não está inicializado."
        )

    # 1. Validar existência da sessão e se a UC pertence ao professor conectado
    stmt_session = select(AttendanceSession).join(CourseUnit).where(
        AttendanceSession.id == attendance_session_id,
        CourseUnit.teacher_id == teacher.id
    )
    attendance_session = db.scalars(stmt_session).first()
    if not attendance_session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Sessão de chamada não encontrada."
        )

    if not attendance_session.is_active:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Esta sessão de chamada já foi encerrada."
        )

    course_unit = attendance_session.course_unit

    # 2. Ler e decodificar a foto
    try:
        contents = await photo.read()
        nparr = np.frombuffer(contents, np.uint8)
        img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        if img is None:
            raise ValueError()
    except Exception:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Foto de chamada inválida ou corrompida."
        )

    # 3. Inferência facial
    bboxes, scores, kpss = vision_engine.detect_faces(img, threshold=0.5)
    if len(bboxes) == 0:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Nenhuma face detectada na foto da chamada."
        )
        
    # Selecionar a face com maior confiança (em selfies/entradas 1:1)
    best_idx = np.argmax(scores)
    bbox = bboxes[best_idx]
    kps = kpss[best_idx]

    # 4. Validação de vivacidade (Anti-Spoofing)
    liveness_score = vision_engine.check_liveness(img, bbox)
    if liveness_score < settings.LIVENESS_THRESHOLD:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Tentativa de fraude detectada: vivacidade facial abaixo do limiar "
                   f"(Liveness: {liveness_score:.4f})."
        )

    # 5. Alinhamento e Extração de Embedding
    aligned = vision_engine.align_face(img, kps)
    embedding = vision_engine.extract_embedding(aligned)

    # 6. Busca vetorial via pgvector
    distance_expr = Student.face_embedding.cosine_distance(embedding.tolist())
    stmt_match = (
        select(Student, distance_expr.label("distance"))
        .where(
            Student.is_active == True,
            Student.teacher_id == teacher.id
        )
        .order_by("distance")
        .limit(1)
    )
    result = db.execute(stmt_match).first()

    if result is None or result.distance > settings.RECOGNITION_THRESHOLD:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Face não reconhecida no banco de dados da instituição."
        )

    student = result.Student
    distance = result.distance
    confidence = 1.0 - distance

    # 7. Validar se o estudante está de fato matriculado nesta disciplina (UC)
    is_enrolled = any(cu.id == course_unit.id for cu in student.course_units)
    if not is_enrolled:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"O estudante '{student.name}' foi reconhecido, "
                   f"mas não possui matrícula ativa na disciplina '{course_unit.name}'."
        )

    # 8. Impedir registro de presença duplicado nesta sessão de chamada
    stmt_dup = select(Attendance).where(
        Attendance.student_id == student.id,
        Attendance.attendance_session_id == attendance_session_id
    )
    existing_attendance = db.scalars(stmt_dup).first()
    if existing_attendance:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Presença já registrada para o estudante '{student.name}' "
                   f"nesta aula às {existing_attendance.timestamp.strftime('%H:%M:%S')}."
        )

    # 9. Persistir o registro de presença
    db_attendance = Attendance(
        student_id=student.id,
        course_unit_id=course_unit.id,
        attendance_session_id=attendance_session_id,
        confidence=float(confidence),
        status="present"
    )
    db.add(db_attendance)
    db.commit()
    db.refresh(db_attendance)

    return db_attendance


# ----------------- ROTAS DE SESSÕES DE CHAMADA (OPÇÃO B) -----------------

@app.post(
    "/api/attendance/sessions",
    response_model=AttendanceSessionResponse,
    tags=["Sessões de Chamada"],
    dependencies=[Depends(verify_api_key)]
)
def create_attendance_session(
    session_in: AttendanceSessionCreate,
    teacher: Teacher = Depends(get_current_teacher),
    db: Session = Depends(get_db)
):
    """Cria uma nova sessão de chamada para o totem, aplicando a trava de carga horária."""
    # 1. Verificar se a UC existe e pertence ao professor
    stmt_cu = select(CourseUnit).where(
        CourseUnit.id == session_in.course_unit_id,
        CourseUnit.teacher_id == teacher.id
    )
    course_unit = db.scalars(stmt_cu).first()
    if not course_unit:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Unidade Curricular (disciplina) não encontrada."
        )

    # 2. Calcular a carga horária de sessões já dadas
    stmt_sum = select(func.sum(AttendanceSession.lessons_count)).where(
        AttendanceSession.course_unit_id == session_in.course_unit_id
    )
    total_hours_taught = db.execute(stmt_sum).scalar() or 0

    # 3. Validar se excede a carga horária (workload)
    workload = course_unit.workload or 0
    if workload > 0 and (total_hours_taught + session_in.lessons_count) > workload:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Carga horária limite da disciplina atingida. Não é possível iniciar nova chamada. "
                   f"Carga horária já ministrada: {total_hours_taught} de {workload} horas. "
                   f"Esta nova chamada adicionaria {session_in.lessons_count} horas."
        )

    # 4. Fechar automaticamente qualquer outra sessão ativa para essa UC
    stmt_close_prev = update(AttendanceSession).where(
        AttendanceSession.course_unit_id == session_in.course_unit_id,
        AttendanceSession.is_active == True
    ).values(is_active=False)
    db.execute(stmt_close_prev)

    # 5. Criar nova sessão
    db_session = AttendanceSession(
        course_unit_id=session_in.course_unit_id,
        date=datetime.utcnow().date(),
        lessons_count=session_in.lessons_count,
        pin=session_in.pin,
        is_active=True
    )
    db.add(db_session)
    db.commit()
    db.refresh(db_session)
    return db_session


@app.post(
    "/api/attendance/sessions/{session_id}/close",
    response_model=AttendanceSessionResponse,
    tags=["Sessões de Chamada"],
    dependencies=[Depends(verify_api_key)]
)
def close_attendance_session(
    session_id: int,
    close_in: AttendanceSessionClose,
    teacher: Teacher = Depends(get_current_teacher),
    db: Session = Depends(get_db)
):
    """Encerra a sessão de chamada ativa no quiosque se o PIN de segurança for válido."""
    stmt_session = select(AttendanceSession).join(CourseUnit).where(
        AttendanceSession.id == session_id,
        CourseUnit.teacher_id == teacher.id
    )
    db_session = db.scalars(stmt_session).first()
    if not db_session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Sessão de chamada não encontrada."
        )

    if db_session.pin != close_in.pin:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="PIN de segurança incorreto. Não foi possível encerrar a sessão."
        )

    db_session.is_active = False
    db.commit()
    db.refresh(db_session)
    return db_session


@app.get(
    "/api/attendance/sessions/active",
    response_model=Optional[AttendanceSessionResponse],
    tags=["Sessões de Chamada"],
    dependencies=[Depends(verify_api_key)]
)
def get_active_attendance_session(
    course_unit_id: int,
    teacher: Teacher = Depends(get_current_teacher),
    db: Session = Depends(get_db)
):
    """Busca a sessão de chamada ativa para uma UC específica do professor."""
    stmt = select(AttendanceSession).join(CourseUnit).where(
        AttendanceSession.course_unit_id == course_unit_id,
        CourseUnit.teacher_id == teacher.id,
        AttendanceSession.is_active == True
    ).order_by(AttendanceSession.id.desc())
    return db.scalars(stmt).first()

@app.get(
    "/api/attendance",
    response_model=List[AttendanceResponse],
    tags=["Chamada Facial"]
)
def list_attendances(
    teacher: Teacher = Depends(get_current_teacher),
    db: Session = Depends(get_db)
):
    """Lista todos os registros históricos de presença ordenados por data decrescente."""
    stmt = (
        select(Attendance)
        .join(CourseUnit, Attendance.course_unit_id == CourseUnit.id)
        .where(CourseUnit.teacher_id == teacher.id)
        .order_by(Attendance.timestamp.desc())
    )
    return db.scalars(stmt).all()

# ----------------- ROTAS DO PERFIL DO PROFESSOR (CRUD) -----------------

@app.get(
    "/api/teachers/me",
    response_model=TeacherResponse,
    tags=["Perfil do Professor"]
)
def get_teacher_profile(
    email: str = Depends(get_current_teacher_email),
    db: Session = Depends(get_db)
):
    """
    Retorna os dados cadastrais do professor ativo.
    Retorna HTTP 404 (registro pendente) caso o professor ainda não tenha se auto-cadastrado.
    """
    stmt = select(Teacher).where(Teacher.email == email)
    teacher = db.scalars(stmt).first()
    if not teacher:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Cadastro do professor pendente. Por favor, realize o auto-cadastro."
        )
    return teacher

@app.post(
    "/api/teachers/register",
    response_model=TeacherResponse,
    status_code=status.HTTP_201_CREATED,
    tags=["Perfil do Professor"]
)
def register_teacher(
    data: TeacherCreate,
    email: str = Depends(get_current_teacher_email),
    db: Session = Depends(get_db)
):
    """
    Realiza o auto-cadastro do professor conectado no primeiro acesso após a autenticação Google.
    """
    # Verificar se já existe cadastro
    stmt_exist = select(Teacher).where(Teacher.email == email)
    if db.scalars(stmt_exist).first():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Professor já cadastrado no sistema."
        )

    db_teacher = Teacher(
        name=data.name,
        email=email,
        phone=data.phone,
        department=data.department
    )
    db.add(db_teacher)
    db.commit()
    db.refresh(db_teacher)
    return db_teacher

@app.put(
    "/api/teachers/me",
    response_model=TeacherResponse,
    tags=["Perfil do Professor"]
)
def update_teacher(
    data: TeacherUpdate,
    email: str = Depends(get_current_teacher_email),
    db: Session = Depends(get_db)
):
    """
    Atualiza os contatos editáveis (telefone e departamento) do professor ativo.
    """
    stmt = select(Teacher).where(Teacher.email == email)
    teacher = db.scalars(stmt).first()
    if not teacher:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Professor não encontrado."
        )

    if data.phone is not None:
        teacher.phone = data.phone
    if data.department is not None:
        teacher.department = data.department

    db.commit()
    db.refresh(teacher)
    return teacher

@app.get(
    "/api/teachers/me/photo",
    tags=["Perfil do Professor"]
)
def get_teacher_photo(
    email: str = Depends(get_current_teacher_email),
    db: Session = Depends(get_db)
):
    """
    Retorna a foto de perfil do próprio professor autenticado.
    O arquivo não é exposto publicamente por URL estática.
    """
    stmt = select(Teacher).where(Teacher.email == email)
    teacher = db.scalars(stmt).first()
    if not teacher:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Professor não encontrado."
        )

    if not teacher.photo_storage_key:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Professor sem foto de perfil cadastrada."
        )

    filename = os.path.basename(teacher.photo_storage_key)
    filepath = os.path.join(TEACHER_UPLOAD_DIR, filename)
    if not os.path.exists(filepath):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Arquivo da foto de perfil não encontrado."
        )

    return FileResponse(
        path=filepath,
        filename=filename,
        headers={
            "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0",
            "Pragma": "no-cache",
            "Expires": "0",
        },
    )


@app.post(
    "/api/teachers/me/photo",
    response_model=TeacherResponse,
    tags=["Perfil do Professor"]
)
def upload_teacher_photo(
    file: UploadFile = File(..., description="Foto de perfil do professor"),
    email: str = Depends(get_current_teacher_email),
    db: Session = Depends(get_db)
):
    """
    Salva a foto de perfil do professor ativo no servidor local e atualiza seu identificador interno de foto.
    """
    stmt = select(Teacher).where(Teacher.email == email)
    teacher = db.scalars(stmt).first()
    if not teacher:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Professor não encontrado."
        )

    # Criar pasta local se não existir
    os.makedirs(TEACHER_UPLOAD_DIR, exist_ok=True)

    # Nome único da foto
    file_ext = os.path.splitext(file.filename)[1]
    if not file_ext:
        file_ext = ".jpg"
    filename = f"teacher_{teacher.id}_{int(datetime.utcnow().timestamp())}{file_ext}"
    filepath = os.path.join(TEACHER_UPLOAD_DIR, filename)

    old_filename = os.path.basename(teacher.photo_storage_key) if teacher.photo_storage_key else None
    old_filepath = os.path.join(TEACHER_UPLOAD_DIR, old_filename) if old_filename else None

    try:
        with open(filepath, "wb") as f:
            f.write(file.file.read())
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Erro ao salvar arquivo de foto: {str(e)}"
        )

    # Gravar apenas identificador interno (não público)
    teacher.photo_storage_key = filename
    db.commit()
    db.refresh(teacher)

    # Limpeza best-effort da foto anterior, se houver
    if old_filepath and os.path.exists(old_filepath) and old_filepath != filepath:
        try:
            os.remove(old_filepath)
        except OSError:
            pass

    return teacher
