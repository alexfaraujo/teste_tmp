
import sqlite3
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_NAME = os.path.join(BASE_DIR, "padlock.db")
    
def clear_db():
    print(f"Connecting to database: {DB_NAME}")
    if not os.path.exists(DB_NAME):
        print("Database file found.")
        return

    try:
        conn = sqlite3.connect(DB_NAME)
        cursor = conn.cursor()
        
        # 1. Clear requests table
        print("Clearing 'requests' table...")
        cursor.execute("DELETE FROM requests")
        print(f"Deleted {cursor.rowcount} rows from 'requests'.")
        
        # 2. Clear users table
        print("Clearing 'users' table...")
        cursor.execute("DELETE FROM users")
        print(f"Deleted {cursor.rowcount} rows from 'users'.")
        
        # 3. reset sqlite sequence for these tables (optional, resets ID counter)
        print("Resetting auto-increment counters...")
        cursor.execute("DELETE FROM sqlite_sequence WHERE name='requests'")
        cursor.execute("DELETE FROM sqlite_sequence WHERE name='users'")

        # 4. Verify external_devices
        print("Verifying 'external_devices'...")
        cursor.execute("SELECT count(*) FROM external_devices")
        count = cursor.fetchone()[0]
        print(f"Found {count} rows in 'external_devices'. (Should be > 0)")
        
        if count == 0:
            print("WARNING: external_devices is empty! Inserting default test device...")
            cursor.execute("INSERT INTO external_devices (nome, api_key) VALUES (?, ?)", ('Dispositivo de Teste', 'chave_teste_123'))

        conn.commit()
        conn.close()
        print("\nDatabase cleared successfully and ready for deployment!")
        
    except Exception as e:
        print(f"Error clearing database: {e}")

if __name__ == "__main__":
    confirm = input("Are you sure you want to clear all USER and REQUEST data? (yes/no): ")
    if confirm.lower() == 'yes':
        clear_db()
    else:
        print("Operation cancelled.")
