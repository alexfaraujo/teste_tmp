#!/bin/bash

# --- CONFIGURAÇÕES ---
PORT=2052
VENV_DIR="../.venv"

echo "=== INICIANDO IMPLANTAÇÃO REMOTA DO BACKEND (PORTA $PORT) ==="

# 1. Verificar instalação do Python 3
if ! command -v python3 &> /dev/null; then
    echo "Erro: python3 não está instalado no sistema."
    exit 1
fi

# 2. Criar ambiente virtual em ../.venv se não existir
if [ ! -d "$VENV_DIR" ]; then
    echo "Criando ambiente virtual Python em: $VENV_DIR..."
    python3 -m venv "$VENV_DIR"
    if [ $? -ne 0 ]; then
        echo "Erro ao criar ambiente virtual."
        exit 1
    fi
else
    echo "Ambiente virtual existente detectado em $VENV_DIR."
fi

# 3. Ativar o ambiente virtual
echo "Ativando ambiente virtual..."
source "$VENV_DIR/bin/activate"

# 4. Atualizar o pip e instalar dependências
echo "Atualizando o pip..."
pip install --upgrade pip

echo "Instalando dependências do requirements.txt..."
# O requirements.txt já usa opencv-python-headless para evitar instalar dependências de GUI do sistema
pip install -r requirements.txt
if [ $? -ne 0 ]; then
    echo "Erro ao instalar as dependências."
    exit 1
fi

# 5. Download automático dos modelos de IA (.onnx)
if [ -f "download_models.py" ]; then
    echo "Iniciando download automático dos modelos de IA..."
    python3 download_models.py
else
    echo "Aviso: download_models.py não encontrado. Certifique-se de que os modelos de IA estão na pasta 'models/'."
fi

# 6. Execução com suporte a HTTPS
echo "Verificando chaves de segurança SSL..."

# Tenta carregar variáveis do .env se existir
if [ -f ".env" ]; then
    export $(grep -v '^#' .env | xargs)
fi

# Verifica se os caminhos dos certificados foram especificados ou existem no diretório
if [ -n "$SSL_KEYFILE" ] && [ -n "$SSL_CERTFILE" ] && [ -f "$SSL_KEYFILE" ] && [ -f "$SSL_CERTFILE" ]; then
    echo "Certificados SSL fornecidos via ambiente/dotenv. Iniciando com HTTPS..."
    uvicorn app.main:app --host 0.0.0.0 --port $PORT --ssl-keyfile="$SSL_KEYFILE" --ssl-certfile="$SSL_CERTFILE"
elif [ -f "key.pem" ] && [ -f "cert.pem" ]; then
    echo "Certificados locais 'key.pem' e 'cert.pem' detectados. Iniciando com HTTPS..."
    uvicorn app.main:app --host 0.0.0.0 --port $PORT --ssl-keyfile=key.pem --ssl-certfile=cert.pem
else
    echo "------------------------------------------------------------------------"
    echo "AVISO: Nenhum certificado SSL válido ou arquivo 'key.pem' / 'cert.pem' foi detectado."
    echo "Para rodar em HTTPS direto no Uvicorn, você pode:"
    echo "  1. Colocar os arquivos 'key.pem' e 'cert.pem' na pasta backend/"
    echo "  2. Definir as variáveis SSL_KEYFILE e SSL_CERTFILE no seu arquivo .env"
    echo "------------------------------------------------------------------------"
    echo "Iniciando em modo HTTP convencional na porta $PORT..."
    echo "Recomendado usar um proxy reverso (Nginx/Caddy/Cloudflare) para terminar o SSL externo."
    uvicorn app.main:app --host 0.0.0.0 --port $PORT
fi
