import sys
from sqlalchemy import create_engine, text

# Ajusta path de forma absoluta
sys.path.append("/home/alex/Documentos/Chamada-Facial/backend")

from app.config import settings

def run_migration():
    print(f"Conectando ao banco em: {settings.DATABASE_URL}")
    engine = create_engine(settings.DATABASE_URL)
    
    queries = [
        """
        CREATE TABLE IF NOT EXISTS attendance_sessions (
            id SERIAL PRIMARY KEY,
            course_unit_id INT REFERENCES course_units(id) ON DELETE CASCADE,
            date DATE NOT NULL,
            lessons_count INT NOT NULL,
            pin VARCHAR(10) NOT NULL,
            is_active BOOLEAN NOT NULL DEFAULT TRUE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """,
        "ALTER TABLE attendance ADD COLUMN IF NOT EXISTS attendance_session_id INT REFERENCES attendance_sessions(id) ON DELETE CASCADE;",
        "CREATE INDEX IF NOT EXISTS idx_attendance_sessions_course ON attendance_sessions(course_unit_id);",
        "CREATE INDEX IF NOT EXISTS idx_attendance_session ON attendance(attendance_session_id);"
    ]
    
    with engine.connect() as conn:
        for query in queries:
            conn.execute(text(query))
            print(f"Executado com sucesso: {query.strip().splitlines()[0]}")
        conn.commit()
    print("Migração de Sessões (Opção B) concluída!")

if __name__ == "__main__":
    run_migration()
