#!/bin/bash

# --- CONFIGURAÇÕES ---
PORT=2053
ENV_FILE=".env.local"
BACKEND_URL="https://chamadaback.ifms.pro.br"

echo "=== INICIANDO IMPLANTAÇÃO AUTOMÁTICA DO FRONTEND (PORTA $PORT) ==="
echo "Configurando backend para: $BACKEND_URL"

# 1. Verificar instalação do Node.js/NPM
if ! command -v npm &> /dev/null; then
    echo "Erro: npm/node não está instalado no sistema."
    exit 1
fi

# 2. Instalar dependências npm
echo "Instalando dependências do projeto (npm install)..."
npm install
if [ $? -ne 0 ]; then
    echo "Erro ao instalar as dependências do frontend."
    exit 1
fi

# 3. Configurar variáveis de ambiente do backend
echo "Configurando as variáveis de ambiente em $ENV_FILE..."
# Garante que o arquivo existe
touch "$ENV_FILE"

# Limpa e define a URL do backend de forma não-interativa
sed -i '/NEXT_PUBLIC_API_URL=/d' "$ENV_FILE"
echo "NEXT_PUBLIC_API_URL=$BACKEND_URL" >> "$ENV_FILE"
echo "Variável NEXT_PUBLIC_API_URL configurada."

# 4. Compilar e inicializar Next.js em Modo Produção na porta 2053
# Como o servidor principal possui o certificado SSL e faz proxy reverso (chamada.ifms.pro.br -> localhost:2053),
# o Next.js DEVE rodar em HTTP comum. O proxy reverso fará a terminação SSL.
# Usamos o modo de Produção (npm run build && next start) para evitar logs de HMR (hot-reload)
# e resolver os avisos de erro de WebSocket (webpack-hmr 404) que ocorrem sob proxies.
echo "Compilando pacote de produção (npm run build)..."
npm run build
if [ $? -ne 0 ]; then
    echo "Erro ao realizar o build do Next.js."
    exit 1
fi

echo "Iniciando Next.js em Modo Produção na porta $PORT..."
echo "Acesse o subdomínio HTTPS configurado no seu proxy reverso."
npx next start --port $PORT --hostname 0.0.0.0
