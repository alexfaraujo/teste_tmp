"use client";

import { useState, useEffect, useRef } from "react";
import { useRouter } from "next/navigation";
import { 
  User, 
  Hash, 
  Search, 
  Camera, 
  RefreshCw, 
  XCircle, 
  CheckCircle2, 
  AlertTriangle, 
  ArrowLeft,
  BookOpen
} from "lucide-react";
import { onAuthStateChanged, User as FirebaseUser } from "firebase/auth";
import { auth } from "@/lib/firebase";

interface CourseUnit {
  id: number;
  name: string;
  code: string;
}

export default function RegisterStudentPage() {
  const router = useRouter();
  
  // Estados de Sessão do Firebase
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [checkingAuth, setCheckingAuth] = useState(true);

  // Estados do Formulário do Estudante
  const [name, setName] = useState("");
  const [matricula, setMatricula] = useState("");
  const [selectedUCs, setSelectedUCs] = useState<CourseUnit[]>([]);
  const [ucSearchQuery, setUcSearchQuery] = useState("");
  const [allUCs, setAllUCs] = useState<CourseUnit[]>([]);
  const [filteredUCs, setFilteredUCs] = useState<CourseUnit[]>([]);
  const [showDropdown, setShowDropdown] = useState(false);

  // Estados de Fluxo da Tela
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  // Estados da Webcam e Ring Light
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [cameraActive, setCameraActive] = useState(false);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [capturedPhoto, setCapturedPhoto] = useState<string | null>(null);
  const [ringLightActive, setRingLightActive] = useState(false);

  // Resolve dinamicamente a API URL baseada no hostname de acesso (preserva domínio configurado se não for IP local)
  const getApiUrl = () => {
    const envUrl = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
    if (envUrl && !envUrl.includes("localhost") && !envUrl.includes("127.0.0.1")) {
      return envUrl;
    }
    if (typeof window !== "undefined") {
      const hostname = window.location.hostname;
      if (hostname !== "localhost" && hostname !== "127.0.0.1" && /^[0-9.]+$/.test(hostname)) {
        return `http://${hostname}:8000`;
      }
    }
    return envUrl;
  };

  const getApiKey = () => {
    return process.env.NEXT_PUBLIC_API_KEY ?? "";
  };

  // Monitora a sessão do Firebase para proteger a rota
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      if (user) {
        setFirebaseUser(user);
      } else {
        router.push("/");
      }
      setCheckingAuth(false);
    });

    return () => {
      unsubscribe();
      stopCamera();
    };
  }, [router]);

  // Carrega as Unidades Curriculares cadastradas no backend
  useEffect(() => {
    if (!firebaseUser) return;

    const loadCourseUnits = async () => {
      try {
        const API_URL = getApiUrl();
        const apiKey = getApiKey();
        const userEmail = firebaseUser?.email || "";
        const response = await fetch(`${API_URL}/api/course_units`, {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            "x-api-key": apiKey,
            "X-User-Email": userEmail,
          },
        });

        if (response.ok) {
          const data = await response.json();
          setAllUCs(data);
        } else {
          console.error("Falha ao carregar as unidades curriculares do backend");
        }
      } catch (err) {
        console.error("Erro de conexão ao carregar disciplinas:", err);
      }
    };

    loadCourseUnits();
  }, [firebaseUser]);

  // Filtra as UCs com base na busca textual e remove as que já foram selecionadas
  useEffect(() => {
    const query = ucSearchQuery.trim().toLowerCase();
    if (!query) {
      setFilteredUCs([]);
      return;
    }

    const matches = allUCs.filter(
      (uc) =>
        (uc.name.toLowerCase().includes(query) || uc.code.toLowerCase().includes(query)) &&
        !selectedUCs.some((sel) => sel.id === uc.id)
    );

    setFilteredUCs(matches);
  }, [ucSearchQuery, allUCs, selectedUCs]);

  // Vincula o stream do vídeo ao elemento <video>
  useEffect(() => {
    if (videoRef.current && stream) {
      videoRef.current.srcObject = stream;
    }
  }, [stream, cameraActive]);

  // Inicia a transmissão da câmera
  const startCamera = async () => {
    setError(null);
    setCapturedPhoto(null);
    try {
      const constraints = {
        video: {
          width: { ideal: 640 },
          height: { ideal: 480 },
          facingMode: "user",
        },
        audio: false,
      };

      const mediaStream = await navigator.mediaDevices.getUserMedia(constraints);
      setStream(mediaStream);
      setCameraActive(true);
    } catch (err: any) {
      console.error("Erro ao acessar câmera:", err);
      setError(
        "Não foi possível acessar a câmera. Verifique se o seu dispositivo possui uma webcam conectada e se as permissões de acesso foram concedidas."
      );
    }
  };

  // Encerra a transmissão da câmera
  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach((track) => track.stop());
      setStream(null);
    }
    setCameraActive(false);
  };

  // Captura o frame atual do vídeo em formato canvas
  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      const ctx = canvas.getContext("2d");
      
      if (ctx) {
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        
        // Espelha a imagem para o canvas (câmera frontal simulada)
        ctx.translate(canvas.width, 0);
        ctx.scale(-1, 1);
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        
        const dataUrl = canvas.toDataURL("image/jpeg", 0.9);
        setCapturedPhoto(dataUrl);
        stopCamera();
      }
    }
  };

  const handleRecapture = () => {
    setCapturedPhoto(null);
    startCamera();
  };

  const handleDiscard = () => {
    setCapturedPhoto(null);
    stopCamera();
  };

  // Adiciona uma UC à lista de selecionadas
  const selectUC = (uc: CourseUnit) => {
    setSelectedUCs((prev) => [...prev, uc]);
    setUcSearchQuery("");
    setShowDropdown(false);
  };

  // Remove uma UC da lista de selecionadas
  const removeUC = (id: number) => {
    setSelectedUCs((prev) => prev.filter((uc) => uc.id !== id));
  };

  // Converte a string Base64 em Blob para envio multipart/form-data
  const dataURItoBlob = (dataURI: string) => {
    const byteString = atob(dataURI.split(",")[1]);
    const mimeString = dataURI.split(",")[0].split(":")[1].split(";")[0];
    const ab = new ArrayBuffer(byteString.length);
    const ia = new Uint8Array(ab);
    for (let i = 0; i < byteString.length; i++) {
      ia[i] = byteString.charCodeAt(i);
    }
    return new Blob([ab], { type: mimeString });
  };

  // Envia os dados de cadastro do estudante ao backend
  const handleSubmit = async () => {
    setError(null);
    setSuccess(null);

    // Validações locais
    if (!name.trim()) {
      setError("O nome completo do estudante é obrigatório.");
      return;
    }

    if (!matricula.trim()) {
      setError("O número de matrícula é obrigatório.");
      return;
    }

    if (selectedUCs.length === 0) {
      setError("O estudante deve estar vinculado a pelo menos uma Unidade Curricular.");
      return;
    }

    if (!capturedPhoto) {
      setError("É obrigatório capturar uma foto de rosto para cadastrar a biometria facial.");
      return;
    }

    setSubmitting(true);
    const API_URL = getApiUrl();
    const apiKey = getApiKey();
    const userEmail = firebaseUser?.email || "";

    try {
      const photoBlob = dataURItoBlob(capturedPhoto);
      const courseUnitIds = selectedUCs.map((uc) => uc.id).join(",");

      const formData = new FormData();
      formData.append("name", name.trim());
      formData.append("matricula", matricula.trim());
      formData.append("course_unit_ids", courseUnitIds);
      formData.append("photo", photoBlob, "student.jpg");

      const response = await fetch(`${API_URL}/api/students`, {
        method: "POST",
        headers: {
          "x-api-key": apiKey,
          "X-User-Email": userEmail,
        },
        body: formData,
      });

      const data = await response.json();

      if (response.ok) {
        setSuccess(`Estudante "${name}" cadastrado com sucesso!`);
        setTimeout(() => {
          router.push("/dashboard");
        }, 2000);
      } else {
        throw new Error(data.detail || "Erro ao realizar o cadastro do estudante.");
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Não foi possível conectar ao servidor backend (FastAPI).");
    } finally {
      setSubmitting(false);
    }
  };

  if (checkingAuth) {
    return (
      <div className="flex-1 w-full flex flex-col items-center justify-center bg-[#F1F5F9] py-20 gap-4">
        <RefreshCw className="w-8 h-8 text-primary animate-spin" />
        <span className="text-sm font-medium text-text-secondary">Verificando autenticação...</span>
      </div>
    );
  }

  return (
    <div className={`flex-1 w-full px-4 py-8 md:py-12 flex flex-col items-center transition-colors duration-300 ${
      ringLightActive ? "bg-white" : "bg-[#F1F5F9]"
    }`}>
      
      {/* Container Principal */}
      <div className={`w-full max-w-4xl rounded-2xl border p-6 md:p-8 transition-all duration-300 ${
        ringLightActive 
          ? "bg-white border-white shadow-none" 
          : "bg-white border-[#E2E8F0] shadow-md"
      }`}>
        
        {/* Cabeçalho da Seção com Voltar */}
        <div className="border-b border-[#E2E8F0] pb-6 mb-8 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div className="flex items-center gap-3">
            <button
              onClick={() => router.push("/dashboard")}
              className="p-2.5 rounded-xl border border-[#E2E8F0] hover:bg-[#F8FAFC] text-text-secondary hover:text-text-primary transition-all cursor-pointer"
              title="Voltar ao Dashboard"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <div>
              <h1 className="text-2xl font-bold text-text-primary">
                Cadastrar Novo Estudante
              </h1>
              <p className="text-sm text-text-secondary mt-1">
                Cadastre o rosto e matricule o estudante nas disciplinas (UCs) do semestre.
              </p>
            </div>
          </div>
        </div>

        {/* Mensagens de Sucesso / Erro */}
        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 rounded-xl p-4 flex items-start gap-2.5 text-sm mb-6 animate-in fade-in duration-200">
            <AlertTriangle className="w-5 h-5 shrink-0 text-red-500 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        {success && (
          <div className="bg-green-50 border border-green-200 text-green-700 rounded-xl p-4 flex items-start gap-2.5 text-sm mb-6 animate-in fade-in duration-200">
            <CheckCircle2 className="w-5 h-5 shrink-0 text-green-500 mt-0.5" />
            <span>{success}</span>
          </div>
        )}

        {/* Grid de Conteúdo */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
          
          {/* Lado Esquerdo - Dados do Formulário (Col 7) */}
          <div className="md:col-span-7 flex flex-col gap-5">
            <h2 className="text-lg font-semibold text-text-primary border-b border-[#F1F5F9] pb-2 mb-1">
              Dados Cadastrais
            </h2>

            {/* Input Nome */}
            <div className="flex flex-col gap-1.5">
              <label htmlFor="student-name" className="text-sm font-semibold text-text-primary flex items-center gap-1.5">
                <User className="w-4 h-4 text-text-secondary" />
                Nome Completo do Estudante
              </label>
              <input
                id="student-name"
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Ex: Carlos Souza Silva"
                className="w-full border border-[#CBD5E1] rounded-xl p-3 text-sm transition-all focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 bg-white text-text-primary"
              />
            </div>

            {/* Input Matrícula */}
            <div className="flex flex-col gap-1.5">
              <label htmlFor="student-matricula" className="text-sm font-semibold text-text-primary flex items-center gap-1.5">
                <Hash className="w-4 h-4 text-text-secondary" />
                Número de Matrícula Único
              </label>
              <input
                id="student-matricula"
                type="text"
                value={matricula}
                onChange={(e) => setMatricula(e.target.value)}
                placeholder="Ex: 2026100987"
                className="w-full border border-[#CBD5E1] rounded-xl p-3 text-sm transition-all focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 bg-white text-text-primary"
              />
            </div>

            {/* Autocomplete de Unidades Curriculares */}
            <div className="flex flex-col gap-1.5">
              <label htmlFor="uc-search-input" className="text-sm font-semibold text-text-primary flex items-center gap-1.5">
                <BookOpen className="w-4 h-4 text-text-secondary" />
                Vincular a Disciplinas (UCs)
              </label>
              
              <div className="relative">
                <div className="relative flex items-center">
                  <input
                    id="uc-search-input"
                    type="text"
                    value={ucSearchQuery}
                    onChange={(e) => {
                      setUcSearchQuery(e.target.value);
                      setShowDropdown(true);
                    }}
                    onFocus={() => setShowDropdown(true)}
                    placeholder="Digite para buscar disciplinas (ex: IA, SO, Cálculo)"
                    className="w-full border border-[#CBD5E1] rounded-xl pl-10 pr-4 p-3 text-sm transition-all focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 bg-white text-text-primary"
                  />
                  <Search className="w-4 h-4 text-text-secondary absolute left-3.5 pointer-events-none" />
                </div>

                {/* Dropdown de Sugestões */}
                {showDropdown && ucSearchQuery.trim() !== "" && (
                  <div className="absolute top-[105%] left-0 right-0 bg-white border border-[#E2E8F0] rounded-xl shadow-lg max-h-48 overflow-y-auto z-40 animate-in fade-in slide-in-from-top-1 duration-150">
                    {filteredUCs.length === 0 ? (
                      <div className="p-3 text-xs text-text-secondary text-center">
                        Nenhuma disciplina encontrada
                      </div>
                    ) : (
                      filteredUCs.map((uc) => (
                        <button
                          key={uc.id}
                          type="button"
                          onClick={() => selectUC(uc)}
                          className="w-full text-left p-3 hover:bg-[#F8FAFC] text-sm text-text-primary hover:text-primary transition-all border-b border-[#F1F5F9] last:border-0 flex justify-between items-center cursor-pointer"
                        >
                          <span className="font-medium">{uc.name}</span>
                          <span className="text-xs text-text-secondary bg-[#F1F5F9] px-2 py-0.5 rounded-md font-mono">{uc.code}</span>
                        </button>
                      ))
                    )}
                  </div>
                )}
              </div>

              {/* Tags de Disciplinas Selecionadas */}
              {selectedUCs.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-2">
                  {selectedUCs.map((uc) => (
                    <div
                      key={uc.id}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#E2E8F0] text-text-primary rounded-full text-xs font-semibold"
                    >
                      <span>{uc.name} ({uc.code})</span>
                      <button
                        type="button"
                        onClick={() => removeUC(uc.id)}
                        className="w-4 h-4 rounded-full bg-slate-300 hover:bg-red-200 hover:text-red-700 transition-all flex items-center justify-center text-[10px] font-bold cursor-pointer"
                        title="Remover"
                      >
                        ×
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Aviso de Regras de Negócio */}
            <div className="border-l-4 border-primary pl-4 py-1 text-xs text-text-secondary leading-normal flex flex-col gap-1">
              <strong>Validação de Duplicidade:</strong>
              <span>O número de matrícula é exclusivo. O sistema impede cadastros duplicados e valida a biometria facial do estudante contra spoofing usando detecção de vivacidade.</span>
            </div>

            {/* Botão de Envio Principal */}
            <button
              type="button"
              onClick={handleSubmit}
              disabled={submitting}
              className="w-full bg-gradient-to-r from-primary to-blue-600 hover:opacity-95 text-white font-semibold py-3.5 px-4 rounded-xl shadow-md flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-60 text-sm mt-4"
            >
              {submitting ? (
                <RefreshCw className="w-5 h-5 animate-spin" />
              ) : (
                <CheckCircle2 className="w-5 h-5" />
              )}
              <span>Salvar Cadastro de Estudante</span>
            </button>
          </div>

          {/* Lado Direito - Câmera e Ring Light (Col 5) */}
          <div className="md:col-span-5 flex flex-col items-center">
            <h2 className="w-full text-lg font-semibold text-text-primary border-b border-[#F1F5F9] pb-2 mb-6 text-center md:text-left">
              Biometria Facial
            </h2>

            {/* Painel da Câmera / Moldura Ring Light */}
            <div className={`relative w-full max-w-[280px] aspect-[4/3] bg-[#0F172A] rounded-2xl overflow-hidden flex items-center justify-center transition-all duration-300 ${
              ringLightActive 
                ? "border-8 border-white shadow-[0_0_30px_rgba(255,255,255,1)]" 
                : "border-2 border-[#CBD5E1] shadow-inner"
            }`}>
              
              {/* Elipse Guia do Rosto */}
              {cameraActive && !capturedPhoto && (
                <div className={`absolute w-[120px] h-[160px] border-dashed rounded-[50%] pointer-events-none z-30 transition-all duration-300 ${
                  ringLightActive 
                    ? "border-3 border-white shadow-[0_0_15px_rgba(255,255,255,0.8)] animate-none" 
                    : "border-2 border-white/60 animate-pulse"
                }`} />
              )}

              {/* Máscara de Foco / Ring Light (Capa inteira externa à elipse) */}
              {cameraActive && !capturedPhoto && (
                <div 
                  className="absolute inset-0 z-20 pointer-events-none transition-all duration-300"
                  style={{
                    background: ringLightActive
                      ? "radial-gradient(ellipse 60px 80px at center, transparent 99%, rgba(255, 255, 255, 1) 100%)"
                      : "radial-gradient(ellipse 60px 80px at center, transparent 99%, rgba(15, 23, 42, 0.6) 100%)",
                  }}
                />
              )}

              {/* Feed de Vídeo Ativo */}
              {cameraActive && !capturedPhoto && (
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  className="w-full h-full object-cover -scale-x-100 z-10"
                />
              )}

              {/* Exibição da Foto Capturada */}
              {capturedPhoto && (
                <div className="relative w-full h-full z-10">
                  <img
                    src={capturedPhoto}
                    alt="Foto Capturada"
                    className="w-full h-full object-cover"
                  />
                </div>
              )}

              {/* Placeholder quando a câmera está desligada e não há foto */}
              {!cameraActive && !capturedPhoto && (
                <div className="flex flex-col items-center text-center p-6 gap-2 text-white/50">
                  <Camera className="w-12 h-12 stroke-[1.5]" />
                  <span className="text-xs font-semibold">Simulador de Captura</span>
                  <span className="text-[10px] opacity-75">Posicione o rosto dentro da elipse guia</span>
                </div>
              )}
            </div>

            {/* Controles de Câmera */}
            <div className="w-full max-w-[280px] mt-4 flex flex-col gap-2">
              
              {/* Controles Câmera Ativa / Foto Tirada */}
              {!cameraActive && !capturedPhoto ? (
                <button
                  type="button"
                  onClick={startCamera}
                  className="w-full bg-[#F1F5F9] hover:bg-[#E2E8F0] border border-[#CBD5E1] text-text-primary font-semibold py-2 px-4 rounded-xl text-sm flex items-center justify-center gap-2 transition-all cursor-pointer"
                >
                  <Camera className="w-4 h-4" />
                  <span>Tirar Foto</span>
                </button>
              ) : cameraActive && !capturedPhoto ? (
                <div className="flex gap-2">
                  {/* Botão Ring Light */}
                  <button
                    type="button"
                    onClick={() => setRingLightActive(!ringLightActive)}
                    className={`flex-1 font-semibold py-2 px-3 rounded-xl text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer border ${
                      ringLightActive 
                        ? "bg-primary border-primary text-white shadow-md" 
                        : "bg-white border-[#CBD5E1] text-text-primary hover:bg-[#F8FAFC]"
                    }`}
                  >
                    <svg className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                      <circle cx="12" cy="12" r="10"></circle>
                      <circle cx="12" cy="12" r="6"></circle>
                    </svg>
                    <span>{ringLightActive ? "Desativar Luz" : "Ativar Ring Light"}</span>
                  </button>

                  {/* Botão Capturar */}
                  <button
                    type="button"
                    onClick={capturePhoto}
                    className="flex-1 bg-primary hover:bg-primary-hover text-white font-semibold py-2 px-3 rounded-xl text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-md"
                  >
                    <Camera className="w-3.5 h-3.5" />
                    <span>Capturar</span>
                  </button>
                </div>
              ) : (
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={handleRecapture}
                    className="flex-1 bg-[#F1F5F9] hover:bg-[#E2E8F0] border border-[#CBD5E1] text-text-primary font-semibold py-2 px-3 rounded-xl text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Refazer Foto</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleDiscard}
                    className="flex-1 bg-red-50 hover:bg-red-100 border border-red-200 text-red-700 font-semibold py-2 px-3 rounded-xl text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                  >
                    <XCircle className="w-3.5 h-3.5" />
                    <span>Descartar</span>
                  </button>
                </div>
              )}
            </div>
          </div>
          
        </div>

        {/* Elemento oculto para processar a captura do canvas */}
        <canvas ref={canvasRef} className="hidden" />

      </div>
      
      {/* Dropdown Backdrop para fechar dropdown ao clicar fora */}
      {showDropdown && (
        <div 
          className="fixed inset-0 z-30" 
          onClick={() => setShowDropdown(false)}
        />
      )}
    </div>
  );
}
