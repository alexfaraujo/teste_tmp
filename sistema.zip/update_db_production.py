import sqlite3

DATABASE = 'perfil.db'

def update_db_production():
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    
    print("Starting database update...")
    
    # 1. Create Tables (if they don't exist)
    # Note: We include the 'status' column in the CREATE statement for new installations
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS photos_event (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            evento_id INTEGER NOT NULL,
            pessoa_id INTEGER NOT NULL,
            caminho_arquivo TEXT NOT NULL,
            data_upload DATETIME DEFAULT CURRENT_TIMESTAMP,
            status TEXT DEFAULT 'ativo',
            FOREIGN KEY (evento_id) REFERENCES eventos (id),
            FOREIGN KEY (pessoa_id) REFERENCES pessoas (id)
        )
    ''')
    print("Checked/Created photos_event table.")
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS reports_event (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            evento_id INTEGER NOT NULL,
            pessoa_id INTEGER NOT NULL,
            caminho_arquivo TEXT NOT NULL,
            data_upload DATETIME DEFAULT CURRENT_TIMESTAMP,
            status TEXT DEFAULT 'ativo',
            FOREIGN KEY (evento_id) REFERENCES eventos (id),
            FOREIGN KEY (pessoa_id) REFERENCES pessoas (id)
        )
    ''')
    print("Checked/Created reports_event table.")
    
    # 2. Add 'status' column to existing tables (Migration for existing DBs)
    # This block handles cases where the table existed before the 'status' column was added
    
    tables = ['photos_event', 'reports_event']
    for table in tables:
        try:
            # Check if column exists to avoid error or just try-catch
            cursor.execute(f"ALTER TABLE {table} ADD COLUMN status TEXT DEFAULT 'ativo'")
            print(f"Added 'status' column to existing table: {table}")
        except sqlite3.OperationalError as e:
            if "duplicate column" in str(e).lower():
                print(f"Column 'status' already exists in {table}.")
            else:
                # In SQLite, adding a column that already exists throws an error.
                # We can safely ignore it if it's about the column existing.
                print(f"Note for {table}: {e}")

    conn.commit()
    conn.close()
    print("Database update completed successfully.")

if __name__ == '__main__':
    update_db_production()
