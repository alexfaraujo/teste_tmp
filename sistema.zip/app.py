from flask import Flask, render_template, request, redirect, url_for, session, flash, g, jsonify, send_file
import sqlite3
import os
import io

from datetime import datetime, timedelta
from PIL import Image, ImageFilter
from odf.opendocument import load
from odf.table import Table, TableRow, TableCell, TableColumn
from odf.text import P
from odf.draw import Frame, Image as OdfImage
from odf import teletype

app = Flask(__name__)
app.secret_key = 'supersecretkey'  # Change this in production!
DATABASE = 'perfil.db'

def format_datetime(value, format='%d/%m/%Y %H:%M'):
    if value is None:
        return ""
    
    # Try parsing as datetime with seconds
    try:
        dt = datetime.strptime(value, '%Y-%m-%d %H:%M:%S')
        return dt.strftime(format)
    except ValueError:
        pass
        
    # Try parsing as date only
    try:
        dt = datetime.strptime(value, '%Y-%m-%d')
        return dt.strftime('%d/%m/%Y')
    except ValueError:
        pass
        
    # Try parsing as time only (HH:MM) - though usually we want full date
    # If value is just a time string like "14:00", we might just want to return it or format it?
    # The user asked for Brazilian standard. 
    # If it's just a time, it's already HH:MM usually.
    
    return value

app.jinja_env.filters['format_datetime'] = format_datetime

def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row
    return db

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

@app.route('/', methods=['GET'])
def index():
    if 'user_id' in session:
        return redirect(url_for('perfil'))
    return render_template('login.html')

@app.route('/login', methods=['POST'])
def login():
    access_key = request.form['access_key']
    db = get_db()
    
    # Check if access key exists
    cursor = db.execute('SELECT * FROM codigos_acesso WHERE codigo = ?', (access_key,))
    access_code = cursor.fetchone()
    
    if access_code:
        session['user_id'] = access_code['pessoa_id']
        return redirect(url_for('perfil'))
    else:
        flash('Chave de acesso inválida. Tente novamente.', 'error')
        return redirect(url_for('index'))

@app.route('/perfil')
def perfil():
    if 'user_id' not in session:
        return redirect(url_for('index'))
    
    user_id = session['user_id']
    db = get_db()
    
    cursor = db.execute('SELECT * FROM pessoas WHERE id = ?', (user_id,))
    user = cursor.fetchone()
    
    if user is None:
        # Should not happen if referential integrity is maintained
        session.pop('user_id', None)
        return redirect(url_for('index'))
    
    # Get events for today where the user is responsible
    from datetime import date
    today = date.today().strftime('%Y-%m-%d')
    
    # Query events with attendance count
    cursor = db.execute('''
        SELECT e.*, 
        (SELECT COUNT(*) FROM presencas p WHERE p.evento_id = e.id) as qtd_presencas,
        (SELECT COUNT(*) FROM photos_event pe WHERE pe.evento_id = e.id AND pe.status = 'ativo') as qtd_fotos,
        (SELECT COUNT(*) FROM reports_event re WHERE re.evento_id = e.id AND re.status = 'ativo') as qtd_relatorios
        FROM eventos e 
        WHERE e.pessoa_id = ? AND e.data = ? AND e.deleted_at IS NULL
    ''', (user_id, today))
    meus_eventos = cursor.fetchall()
    
    # Get attendance registered for today
    cursor = db.execute('''
        SELECT e.id, e.nome, e.horario, e.local, p.registrado_em 
        FROM presencas p
        JOIN eventos e ON p.evento_id = e.id
        WHERE p.pessoa_id = ? AND date(p.registrado_em) = ?
    ''', (user_id, today))
    presencas_data = cursor.fetchall()
    
    # Process presences to add photo count and report count
    presencas_hoje = []
    for p in presencas_data:
        p_dict = dict(p)
        event_id = p_dict['id']
        
        # Count photos for this event from DB
        cursor = db.execute('SELECT COUNT(*) FROM photos_event WHERE evento_id = ? AND pessoa_id = ? AND status = "ativo"', (event_id, user_id))
        p_dict['photo_count'] = cursor.fetchone()[0]
        
        # Count reports for this event from DB
        cursor = db.execute('SELECT COUNT(*) FROM reports_event WHERE evento_id = ? AND pessoa_id = ? AND status = "ativo"', (event_id, user_id))
        p_dict['report_count'] = cursor.fetchone()[0]
        
        presencas_hoje.append(p_dict)
        
    # Check if user can create events
    ALLOWED_ROLES = [
        'preceptor', 'preceptora', 
        'orientador de serviço', 'orientadora de serviço', 
        'tutor', 'tutora'
    ]
    can_create_event = user['curso'] and user['curso'].lower() in ALLOWED_ROLES

    return render_template('perfil.html', user=user, meus_eventos=meus_eventos, presencas_hoje=presencas_hoje, can_create_event=can_create_event)

@app.route('/historico')
def historico():
    if 'user_id' not in session:
        return redirect(url_for('index'))
    
    user_id = session['user_id']
    db = get_db()
    
    # Get filter parameter
    filter_type = request.args.get('filter', 'all')
    
    # Fetch user details for the header
    cursor = db.execute('SELECT * FROM pessoas WHERE id = ?', (user_id,))
    user = cursor.fetchone()
    
    # Fetch all attended events
    # We need e.pessoa_id to check if user is the organizer
    cursor = db.execute('''
        SELECT e.id, e.nome, e.data, e.horario, e.local, e.pessoa_id as organizador_id, p.registrado_em,
        (SELECT COUNT(*) FROM photos_event pe WHERE pe.evento_id = e.id AND pe.status = 'ativo') as qtd_fotos,
        (SELECT COUNT(*) FROM reports_event re WHERE re.evento_id = e.id AND re.status = 'ativo') as qtd_relatorios
        FROM presencas p
        JOIN eventos e ON p.evento_id = e.id
        WHERE p.pessoa_id = ?
        ORDER BY p.registrado_em DESC
    ''', (user_id,))
    all_events = cursor.fetchall()
    
    historico_eventos = []
    
    if filter_type == 'responsible':
        # Show only events where user is the organizer
        historico_eventos = [e for e in all_events if e['organizador_id'] == user_id]
    elif filter_type == 'participant':
        # Show only events where user is NOT the organizer
        historico_eventos = [e for e in all_events if e['organizador_id'] != user_id]
    else:
        # Show all
        historico_eventos = all_events
    
    return render_template('historico.html', user=user, historico_eventos=historico_eventos, current_filter=filter_type)

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    return redirect(url_for('index'))

from werkzeug.utils import secure_filename

UPLOAD_FOLDER = 'static/uploads'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def process_image_for_gallery(image_path):
    """
    Process image to be square (1000x1000) with blurred background and a white frame.
    Returns the path to the processed image.
    """
    try:
        from PIL import ImageOps
        img = Image.open(image_path)
        
        # Target size for the final output
        final_size = (1000, 1000)
        
        # Size for the inner image (content) - leaving space for white border
        # Let's say 50px border on each side -> 900x900 content
        content_size = (900, 900)
        
        # Create content canvas (blurred bg + image)
        content_canvas = Image.new('RGB', content_size)
        
        # 1. Create blurred background for content
        aspect_ratio = img.width / img.height
        if aspect_ratio > 1: # Landscape
            bg_height = content_size[1]
            bg_width = int(content_size[1] * aspect_ratio)
        else: # Portrait
            bg_width = content_size[0]
            bg_height = int(content_size[0] / aspect_ratio)
            
        bg_img = img.resize((bg_width, bg_height), Image.Resampling.LANCZOS)
        
        # Center crop
        left = (bg_width - content_size[0]) / 2
        top = (bg_height - content_size[1]) / 2
        right = (bg_width + content_size[0]) / 2
        bottom = (bg_height + content_size[1]) / 2
        
        bg_img = bg_img.crop((left, top, right, bottom))
        bg_img = bg_img.filter(ImageFilter.GaussianBlur(radius=20))
        
        content_canvas.paste(bg_img, (0, 0))
        
        # 2. Paste original image (contained)
        img_contain = img.copy()
        img_contain.thumbnail(content_size, Image.Resampling.LANCZOS)
        
        pos_x = (content_size[0] - img_contain.width) // 2
        pos_y = (content_size[1] - img_contain.height) // 2
        
        content_canvas.paste(img_contain, (pos_x, pos_y))
        
        # 2.5 Add Watermark (Logo)
        try:
            logo_path = os.path.join(app.root_path, 'static', 'img', 'logo_transp.png')
            if os.path.exists(logo_path):
                logo = Image.open(logo_path)
                # Resize logo to be small (e.g., 15% of content width)
                logo_width = int(content_size[0] * 0.15)
                aspect = logo.width / logo.height
                logo_height = int(logo_width / aspect)
                logo = logo.resize((logo_width, logo_height), Image.Resampling.LANCZOS)
                
                # Position: Bottom Right of content canvas, with some padding
                padding = 20
                watermark_x = content_size[0] - logo_width - padding
                watermark_y = content_size[1] - logo_height - padding
                
                # Ensure it has alpha channel for transparency
                if logo.mode != 'RGBA':
                    logo = logo.convert('RGBA')
                
                # Apply 50% transparency
                # Get the alpha channel
                r, g, b, a = logo.split()
                # Reduce alpha by 50%
                a = a.point(lambda p: int(p * 0.5))
                # Merge back
                logo = Image.merge('RGBA', (r, g, b, a))
                
                # Paste with mask for transparency
                content_canvas.paste(logo, (watermark_x, watermark_y), logo)
        except Exception as e:
            print(f"Error adding watermark: {e}")

        # 3. Create final canvas with white background (Frame)
        final_canvas = Image.new('RGB', final_size, (255, 255, 255))
        
        # Paste content in center
        offset_x = (final_size[0] - content_size[0]) // 2
        offset_y = (final_size[1] - content_size[1]) // 2
        final_canvas.paste(content_canvas, (offset_x, offset_y))
        
        # 4. Add a thin gray border around the very edge for definition
        final_canvas = ImageOps.expand(final_canvas, border=2, fill='#e0e0e0')
        # Resize back to 1000x1000 if expand increased it (it did, to 1004x1004)
        final_canvas = final_canvas.resize(final_size, Image.Resampling.LANCZOS)
        
        # Save processed image to a 'processed' subdirectory
        directory = os.path.dirname(image_path)
        processed_dir = os.path.join(directory, 'processed')
        if not os.path.exists(processed_dir):
            os.makedirs(processed_dir)
            
        filename = os.path.basename(image_path)
        name, ext = os.path.splitext(filename)
        processed_filename = f"processed_{name}.jpg"
        processed_path = os.path.join(processed_dir, processed_filename)
        
        final_canvas.save(processed_path, quality=95)
        return processed_path
        
    except Exception as e:
        print(f"Error processing image {image_path}: {e}")
        return image_path # Fallback to original

@app.route('/frequencia', methods=['GET', 'POST'])
def frequencia():
    if 'user_id' not in session:
        return redirect(url_for('index'))
    
    if request.method == 'GET':
        session.pop('require_selfie', None)
        return render_template('frequencia.html', require_selfie=False)
    
    if request.method == 'POST':
        event_id = None
        origin_type = 'manual_input'
        
        # Check for manual code
        if 'event_code' in request.form and request.form['event_code']:
            try:
                event_id = int(request.form['event_code'])
            except ValueError:
                return jsonify({'success': False, 'message': 'Código do evento inválido.'})
        else:
             return jsonify({'success': False, 'message': 'Código do evento não fornecido.'})

        # Common Processing Logic
        if event_id:
            try:
                user_id = session['user_id']
                db = get_db()
                
                # 1. Fetch event details
                cursor = db.execute('SELECT * FROM eventos WHERE id = ? AND deleted_at IS NULL', (event_id,))
                event = cursor.fetchone()
                
                if not event:
                        return jsonify({'success': False, 'message': 'Evento não encontrado.'})
                
                # 2. Validate Date
                today_str = datetime.now().strftime('%Y-%m-%d')
                if event['data'] != today_str:
                    return jsonify({'success': False, 'message': f'Este evento não é hoje. Data do evento: {event["data"]}'})
                
                # 3. Validate Time Window
                now = datetime.now()
                event_start_str = f"{event['data']} {event['horario']}"
                event_start = datetime.strptime(event_start_str, '%Y-%m-%d %H:%M')
                
                # Calculate duration in minutes (assuming carga_horaria is in hours)
                duration_hours = float(event['carga_horaria'])
                event_end = event_start + timedelta(hours=duration_hours)
                
                if now < event_start:
                        return jsonify({'success': False, 'message': f'O evento ainda não começou. Início: {event["horario"]}'})
                
                if now > event_end:
                    return jsonify({'success': False, 'message': f'O evento já encerrou. Término: {event_end.strftime("%H:%M")}'})

                # Check for duplicate attendance
                cursor = db.execute('SELECT * FROM presencas WHERE pessoa_id = ? AND evento_id = ?', (user_id, event_id))
                existing_attendance = cursor.fetchone()
                
                if existing_attendance:
                    return jsonify({'success': False, 'message': 'Frequência já registrada para este evento.'})
                
                # Check if this is the first attendance for the event
                cursor = db.execute('SELECT COUNT(*) FROM presencas WHERE evento_id = ?', (event_id,))
                attendance_count = cursor.fetchone()[0]
                
                if attendance_count == 0:
                    # Auto-register the organizer
                    organizer_id = event['pessoa_id']
                    # Only auto-register if the current user is NOT the organizer (avoid double insert)
                    if organizer_id != user_id:
                        db.execute('INSERT INTO presencas (pessoa_id, evento_id, origem, registrado_em) VALUES (?, ?, ?, ?)', 
                                    (organizer_id, event_id, 'auto_organizer', now.strftime('%Y-%m-%d %H:%M:%S')))
                
                # Register attendance
                db.execute('INSERT INTO presencas (pessoa_id, evento_id, origem, registrado_em) VALUES (?, ?, ?, ?)', 
                            (user_id, event_id, origin_type, now.strftime('%Y-%m-%d %H:%M:%S')))
                db.commit()
                
                return jsonify({'success': True, 'message': 'Presença contabilizada com sucesso!', 'data': str(event_id)})
            except Exception as e:
                return jsonify({'success': False, 'message': f'Erro ao registrar frequência: {str(e)}'})
                
    return jsonify({'success': False, 'message': 'Método não permitido'})

@app.route('/upload_foto', methods=['POST'])
def upload_foto():
    if 'user_id' not in session:
        return redirect(url_for('index'))
    
    if 'foto' not in request.files:
        flash('Nenhuma imagem enviada', 'error')
        return redirect(url_for('perfil'))
    
    file = request.files['foto']
    if file.filename == '':
        flash('Nenhuma imagem selecionada', 'error')
        return redirect(url_for('perfil'))
        
    if file and allowed_file(file.filename):
        import time
        user_id = session['user_id']
        timestamp = int(time.time())
        # Create a unique filename: user_{id}_{timestamp}.ext
        ext = file.filename.rsplit('.', 1)[1].lower()
        new_filename = f"user_{user_id}_{timestamp}.{ext}"
        
        # Save to static/photo directory
        photo_dir = os.path.join('static', 'photo')
        if not os.path.exists(photo_dir):
            os.makedirs(photo_dir)
            
        filepath = os.path.join(photo_dir, new_filename)
        
        # Resize image if necessary
        try:
            img = Image.open(file)
            # Convert to RGB if necessary (e.g. for PNGs with transparency being saved as JPG, though we keep extension)
            # But here we keep original extension. If it's PNG, RGBA is fine.
            
            max_size = 512
            if img.width > max_size or img.height > max_size:
                img.thumbnail((max_size, max_size), Image.Resampling.LANCZOS)
            
            img.save(filepath)
        except Exception as e:
            print(f"Error resizing image: {e}")
            # Fallback to saving original if resizing fails
            file.seek(0)
            file.save(filepath)
        
        # Update database
        db = get_db()
        # Store relative path for template usage
        db_path = f"photo/{new_filename}"
        db.execute('UPDATE pessoas SET foto = ? WHERE id = ?', (db_path, user_id))
        db.commit()
        
        flash('Foto de perfil atualizada com sucesso!', 'success')
        return redirect(url_for('perfil'))
    
    flash('Tipo de arquivo não permitido', 'error')
    return redirect(url_for('perfil'))

@app.route('/upload_event_photo', methods=['POST'])
def upload_event_photo():
    if 'user_id' not in session:
        return redirect(url_for('index'))
    
    if 'event_photo' not in request.files:
        flash('Nenhuma imagem enviada', 'error')
        return redirect(url_for('perfil'))
        
    file = request.files['event_photo']
    if file.filename == '':
        flash('Nenhuma imagem selecionada', 'error')
        return redirect(url_for('perfil'))
        
    event_id = request.form.get('event_id')
    if not event_id:
        flash('Evento não identificado', 'error')
        return redirect(url_for('perfil'))

    if file and allowed_file(file.filename):
        import time
        import glob
        import uuid
        
        user_id = session['user_id']
        
        # Define folder
        EVENT_PHOTOS_FOLDER = os.path.join('static', 'event_photos')
        if not os.path.exists(EVENT_PHOTOS_FOLDER):
            os.makedirs(EVENT_PHOTOS_FOLDER)
            
        # Check limit (max 10 photos per user PER EVENT)
        db = get_db()
        cursor = db.execute('SELECT COUNT(*) FROM photos_event WHERE evento_id = ? AND pessoa_id = ?', (event_id, user_id))
        photo_count = cursor.fetchone()[0]
        
        if photo_count >= 10:
            flash('Limite de 10 fotografias atingido para este evento.', 'error')
            return redirect(url_for('perfil'))
            
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        unique_id = uuid.uuid4().hex[:8]
        ext = file.filename.rsplit('.', 1)[1].lower()
        # New format: picture_{user_id}_{event_id}_{timestamp}_{uuid}.{ext}
        filename = secure_filename(f"picture_{user_id}_{event_id}_{timestamp}_{unique_id}.{ext}")
        filepath = os.path.join(EVENT_PHOTOS_FOLDER, filename)
        
        # Save without resizing to keep original dimensions
        file.save(filepath)
        
        # Save to DB
        # Store relative path for template usage
        db_path = f"event_photos/{filename}"
        db.execute('INSERT INTO photos_event (evento_id, pessoa_id, caminho_arquivo) VALUES (?, ?, ?)', 
                   (event_id, user_id, db_path))
        db.commit()
        
        flash('Fotografia enviada com sucesso!', 'success')
        
        # Check for 'next' parameter to redirect back to details page if applicable
        next_url = request.form.get('next')
        if next_url:
            return redirect(next_url)
            
        return redirect(url_for('perfil'))
        
    flash('Tipo de arquivo não permitido', 'error')
    return redirect(url_for('perfil'))

@app.route('/historico/<int:event_id>')
def evento_detalhes(event_id):
    if 'user_id' not in session:
        return redirect(url_for('index'))
    
    user_id = session['user_id']
    db = get_db()
    
    # Fetch event details
    cursor = db.execute('SELECT * FROM eventos WHERE id = ?', (event_id,))
    evento = cursor.fetchone()
    
    if not evento:
        flash('Evento não encontrado.', 'error')
        return redirect(url_for('historico'))
        
    # Fetch attendance record
    cursor = db.execute('SELECT * FROM presencas WHERE pessoa_id = ? AND evento_id = ?', (user_id, event_id))
    presenca = cursor.fetchone()
    
    if not presenca:
        flash('Você não tem presença registrada neste evento.', 'error')
        return redirect(url_for('historico'))
        
    # Fetch photos from DB
    cursor = db.execute('SELECT id, caminho_arquivo, data_upload FROM photos_event WHERE evento_id = ? AND pessoa_id = ? AND status = "ativo"', (event_id, user_id))
    photos_data = cursor.fetchall()
    
    # Process photos to check if deletable
    photos = []
    now = datetime.now()
    for row in photos_data:
        p = dict(row)
        # Check if upload was less than 24 hours ago
        upload_time = datetime.strptime(p['data_upload'], '%Y-%m-%d %H:%M:%S')
        p['can_delete'] = (now - upload_time) < timedelta(hours=24)
        photos.append(p)
        
    # Check for report from DB
    cursor = db.execute('SELECT id, caminho_arquivo, data_upload FROM reports_event WHERE evento_id = ? AND pessoa_id = ? AND status = "ativo"', (event_id, user_id))
    report_row = cursor.fetchone()
    report_file = None
    if report_row:
        report_file = dict(report_row)
        upload_time = datetime.strptime(report_file['data_upload'], '%Y-%m-%d %H:%M:%S')
        report_file['can_delete'] = (now - upload_time) < timedelta(hours=24)
        
    return render_template('evento_detalhes.html', evento=evento, presenca=presenca, photos=photos, report_file=report_file)

@app.route('/painel/<int:event_id>')
def evento_painel(event_id):
    if 'user_id' not in session:
        return redirect(url_for('index'))
    
    user_id = session['user_id']
    db = get_db()
    
    # 1. Fetch event details
    cursor = db.execute('SELECT * FROM eventos WHERE id = ?', (event_id,))
    evento = cursor.fetchone()
    
    if not evento:
        flash('Evento não encontrado.', 'error')
        return redirect(url_for('historico'))
        
    # Check if user is the organizer
    if evento['pessoa_id'] != user_id:
        flash('Acesso negado. Você não é o organizador deste evento.', 'error')
        return redirect(url_for('historico'))
        
    # Check moderation time limit (72h after event start)
    event_start_str = f"{evento['data']} {evento['horario']}"
    try:
        event_start = datetime.strptime(event_start_str, '%Y-%m-%d %H:%M')
        can_moderate = (datetime.now() - event_start) < timedelta(hours=72)
    except ValueError:
        can_moderate = False
        
    # 2. Fetch all photos (with uploader info)
    cursor = db.execute('''
        SELECT pe.*, p.nome as uploader_nome 
        FROM photos_event pe
        JOIN pessoas p ON pe.pessoa_id = p.id
        WHERE pe.evento_id = ? AND pe.status = 'ativo'
        ORDER BY pe.data_upload DESC
    ''', (event_id,))
    all_photos = cursor.fetchall()
    
    # 3. Fetch all reports (with uploader info)
    cursor = db.execute('''
        SELECT re.*, p.nome as uploader_nome 
        FROM reports_event re
        JOIN pessoas p ON re.pessoa_id = p.id
        WHERE re.evento_id = ? AND re.status = 'ativo'
        ORDER BY re.data_upload DESC
    ''', (event_id,))
    all_reports = cursor.fetchall()
    
    # 4. Fetch all attendees
    cursor = db.execute('''
        SELECT p.nome, p.curso, pr.registrado_em
        FROM presencas pr
        JOIN pessoas p ON pr.pessoa_id = p.id
        WHERE pr.evento_id = ?
        ORDER BY p.nome ASC
    ''', (event_id,))
    attendees = cursor.fetchall()
    
    return render_template('evento_painel.html', evento=evento, all_photos=all_photos, all_reports=all_reports, attendees=attendees, can_moderate=can_moderate)

@app.route('/delete_photo/<int:photo_id>', methods=['POST'])
def delete_photo(photo_id):
    if 'user_id' not in session:
        return redirect(url_for('index'))
        
    user_id = session['user_id']
    db = get_db()
    
    # Fetch photo details first
    cursor = db.execute('SELECT * FROM photos_event WHERE id = ? AND status = "ativo"', (photo_id,))
    photo = cursor.fetchone()
    
    if not photo:
        flash('Foto não encontrada.', 'error')
        return redirect(url_for('historico'))
        
    # Fetch event details
    cursor = db.execute('SELECT * FROM eventos WHERE id = ?', (photo['evento_id'],))
    event = cursor.fetchone()
    
    if not event:
        flash('Evento associado não encontrado.', 'error')
        return redirect(url_for('historico'))

    # Permission Check
    is_owner = (photo['pessoa_id'] == user_id)
    is_organizer = (event['pessoa_id'] == user_id)
    
    allowed = False
    
    if is_owner:
        # Owner rule: < 24h from upload
        upload_time = datetime.strptime(photo['data_upload'], '%Y-%m-%d %H:%M:%S')
        if (datetime.now() - upload_time) < timedelta(hours=24):
            allowed = True
        elif not is_organizer:
             flash('O prazo de 24 horas para exclusão pelo autor expirou.', 'error')
             
    if is_organizer and not allowed:
        # Organizer rule: < 72h from event start
        event_start_str = f"{event['data']} {event['horario']}"
        try:
            event_start = datetime.strptime(event_start_str, '%Y-%m-%d %H:%M')
            if (datetime.now() - event_start) < timedelta(hours=72):
                allowed = True
            else:
                flash('O prazo de 72 horas para moderação expirou.', 'error')
        except ValueError:
            pass

    if not allowed:
        # Redirect back to where they came from (likely details or panel)
        # We can check referrer or just default to details
        if is_organizer:
             return redirect(url_for('evento_painel', event_id=photo['evento_id']))
        return redirect(url_for('evento_detalhes', event_id=photo['evento_id']))
        
    try:
        db.execute('UPDATE photos_event SET status = "inativo" WHERE id = ?', (photo_id,))
        db.commit()
        flash('Foto excluída com sucesso.', 'success')
    except Exception as e:
        flash(f'Erro ao excluir foto: {e}', 'error')
        
    if is_organizer:
         return redirect(url_for('evento_painel', event_id=photo['evento_id']))
    return redirect(url_for('evento_detalhes', event_id=photo['evento_id']))

@app.route('/delete_report/<int:report_id>', methods=['POST'])
def delete_report(report_id):
    if 'user_id' not in session:
        return redirect(url_for('index'))
        
    user_id = session['user_id']
    db = get_db()
    
    # Fetch report details
    cursor = db.execute('SELECT * FROM reports_event WHERE id = ? AND status = "ativo"', (report_id,))
    report = cursor.fetchone()
    
    if not report:
        flash('Relatório não encontrado.', 'error')
        return redirect(url_for('historico'))
        
    # Fetch event details
    cursor = db.execute('SELECT * FROM eventos WHERE id = ?', (report['evento_id'],))
    event = cursor.fetchone()
    
    if not event:
        flash('Evento associado não encontrado.', 'error')
        return redirect(url_for('historico'))

    # Permission Check
    is_owner = (report['pessoa_id'] == user_id)
    is_organizer = (event['pessoa_id'] == user_id)
    
    allowed = False
    
    if is_owner:
        # Owner rule: < 24h from upload
        upload_time = datetime.strptime(report['data_upload'], '%Y-%m-%d %H:%M:%S')
        if (datetime.now() - upload_time) < timedelta(hours=24):
            allowed = True
        elif not is_organizer:
             flash('O prazo de 24 horas para exclusão pelo autor expirou.', 'error')
             
    if is_organizer and not allowed:
        # Organizer rule: < 72h from event start
        event_start_str = f"{event['data']} {event['horario']}"
        try:
            event_start = datetime.strptime(event_start_str, '%Y-%m-%d %H:%M')
            if (datetime.now() - event_start) < timedelta(hours=72):
                allowed = True
            else:
                flash('O prazo de 72 horas para moderação expirou.', 'error')
        except ValueError:
            pass

    if not allowed:
        if is_organizer:
             return redirect(url_for('evento_painel', event_id=report['evento_id']))
        return redirect(url_for('evento_detalhes', event_id=report['evento_id']))
        
    try:
        db.execute('UPDATE reports_event SET status = "inativo" WHERE id = ?', (report_id,))
        db.commit()
        flash('Relatório excluído com sucesso.', 'success')
    except Exception as e:
        flash(f'Erro ao excluir relatório: {e}', 'error')
        
    if is_organizer:
         return redirect(url_for('evento_painel', event_id=report['evento_id']))
    return redirect(url_for('evento_detalhes', event_id=report['evento_id']))

@app.route('/upload_event_report', methods=['POST'])
def upload_event_report():
    if 'user_id' not in session:
        return redirect(url_for('index'))
    
    if 'event_report' not in request.files:
        flash('Nenhum arquivo enviado', 'error')
        return redirect(url_for('perfil'))
        
    file = request.files['event_report']
    if file.filename == '':
        flash('Nenhum arquivo selecionado', 'error')
        return redirect(url_for('perfil'))
        
    event_id = request.form.get('event_id')
    if not event_id:
        flash('Evento não identificado', 'error')
        return redirect(url_for('perfil'))

    # Validate PDF extension
    if file and '.' in file.filename and file.filename.rsplit('.', 1)[1].lower() == 'pdf':
        import time
        import glob
        
        user_id = session['user_id']
        
        # Define folder
        EVENT_REPORTS_FOLDER = os.path.join('static', 'event_reports')
        if not os.path.exists(EVENT_REPORTS_FOLDER):
            os.makedirs(EVENT_REPORTS_FOLDER)
            
        # Check limit (max 1 report per user PER EVENT)
        db = get_db()
        cursor = db.execute('SELECT COUNT(*) FROM reports_event WHERE evento_id = ? AND pessoa_id = ?', (event_id, user_id))
        report_count = cursor.fetchone()[0]
        
        if report_count >= 1:
            flash('Você já enviou um relatório para este evento.', 'error')
            return redirect(url_for('perfil'))
            
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        # Format: report_{user_id}_{event_id}_{timestamp}.pdf
        filename = secure_filename(f"report_{user_id}_{event_id}_{timestamp}.pdf")
        filepath = os.path.join(EVENT_REPORTS_FOLDER, filename)
        
        file.save(filepath)
        
        # Save to DB
        db_path = f"event_reports/{filename}"
        db.execute('INSERT INTO reports_event (evento_id, pessoa_id, caminho_arquivo) VALUES (?, ?, ?)', 
                   (event_id, user_id, db_path))
        db.commit()
        
        flash('Relatório enviado com sucesso!', 'success')
        
        # Check for 'next' parameter to redirect back to details page if applicable
        next_url = request.form.get('next')
        if next_url:
            return redirect(next_url)
            
        return redirect(url_for('perfil'))
        
    flash('Apenas arquivos PDF são permitidos.', 'error')
    return redirect(url_for('perfil'))

@app.route('/relatorio/<int:evento_id>')
def gerar_relatorio(evento_id):
    if 'user_id' not in session:
        return redirect(url_for('index'))
        
    db = get_db()
    
    # 1. Fetch event details
    cursor = db.execute('SELECT * FROM eventos WHERE id = ?', (evento_id,))
    evento = cursor.fetchone()
    
    if not evento:
        flash('Evento não encontrado.', 'error')
        return redirect(url_for('perfil'))
        
    # Check if user is owner
    if evento['pessoa_id'] != session['user_id']:
        flash('Você não tem permissão para gerar relatório deste evento.', 'error')
        return redirect(url_for('perfil'))

    # 2. Fetch attendance data
    cursor = db.execute('''
        SELECT p.id, p.nome, p.curso, pr.registrado_em
        FROM presencas pr
        JOIN pessoas p ON pr.pessoa_id = p.id
        WHERE pr.evento_id = ?
        ORDER BY p.nome ASC
    ''', (evento_id,))
    presencas = cursor.fetchall()
    
    # 3. Load Template
    from odf.opendocument import load
    from odf.table import Table, TableRow, TableCell
    from odf.text import P
    from odf import teletype
    
    template_path = os.path.join('static', 'template_relatorios', 'template_lista_frequencia.odt')
    if not os.path.exists(template_path):
        flash('Template de relatório não encontrado.', 'error')
        return redirect(url_for('perfil'))
        
    doc = load(template_path)
    
    # 4. Replace Placeholders (Simple Text)
    # We iterate over all paragraphs to replace event info
    for p in doc.getElementsByType(P):
        text = teletype.extractText(p)
        if '{{eventos.nome}}' in text:
            new_text = text.replace('{{eventos.nome}}', evento['nome'])
            # Clear children safely?
            # odfpy hack: direct list clear might work if we don't use removeChild
            p.childNodes = []
            teletype.addTextToElement(p, new_text)
            
        if '{{eventos.data}}' in text:
            # Format date
            data_fmt = datetime.strptime(evento['data'], '%Y-%m-%d').strftime('%d/%m/%Y')
            new_text = text.replace('{{eventos.data}}', data_fmt)
            p.childNodes = []
            teletype.addTextToElement(p, new_text)
            
        if '{{eventos.local}}' in text:
            new_text = text.replace('{{eventos.local}}', evento['local'])
            p.childNodes = []
            teletype.addTextToElement(p, new_text)
            
        if '{{eventos.horario}}' in text:
            new_text = text.replace('{{eventos.horario}}', evento['horario'])
            p.childNodes = []
            teletype.addTextToElement(p, new_text)

    # 5. Handle Table Rows
    # Find the table containing the markers
    tables = doc.getElementsByType(Table)
    for table in tables:
        rows = table.getElementsByType(TableRow)
        template_row = None
        
        # Find the row with markers
        for row in rows:
            cells = row.getElementsByType(TableCell)
            row_text = ""
            for cell in cells:
                row_text += teletype.extractText(cell)
            
            if '{{pessoas.nome}}' in row_text:
                template_row = row
                break
        
        if template_row:
            # Manual cloning function to avoid RecursionError with deepcopy
            from odf.element import Text, Element
            def clone_element(element):
                if isinstance(element, Text):
                    return Text(element.data)
                # Create new instance of the same class
                new_el = element.__class__(qname=element.qname, qattributes=element.attributes)
                for child in element.childNodes:
                    cloned_child = clone_element(child)
                    if isinstance(cloned_child, Text):
                        new_el.appendChild(cloned_child)
                    else:
                        new_el.addElement(cloned_child)
                return new_el

            for presenca in presencas:
                new_row = clone_element(template_row)
                
                # Fill data in new_row
                cells = new_row.getElementsByType(TableCell)
                for cell in cells:
                    # Iterate paragraphs in cell
                    for p in cell.getElementsByType(P):
                        text = teletype.extractText(p)
                        if '{{pessoas.nome}}' in text:
                            nome_exibicao = presenca['nome']
                            if presenca['id'] == evento['pessoa_id']:
                                nome_exibicao += " (responsável)"
                            new_text = text.replace('{{pessoas.nome}}', nome_exibicao)
                            p.childNodes = []
                            teletype.addTextToElement(p, new_text)
                        if '{{pessoas.curso}}' in text:
                            new_text = text.replace('{{pessoas.curso}}', presenca['curso'])
                            p.childNodes = []
                            teletype.addTextToElement(p, new_text)
                        if '{{presencas.registrado_em}}' in text:
                            # Format timestamp
                            reg_dt = datetime.strptime(presenca['registrado_em'], '%Y-%m-%d %H:%M:%S')
                            reg_fmt = reg_dt.strftime('%H:%M:%S')
                            new_text = text.replace('{{presencas.registrado_em}}', reg_fmt)
                            p.childNodes = []
                            teletype.addTextToElement(p, new_text)
                
                # Add new row to table
                table.insertBefore(new_row, template_row)
            
            # Remove the original template row
            table.removeChild(template_row)
            break # Assume only one table needs filling

    # 6. Save ODT
    reports_dir = os.path.join('static', 'reports')
    if not os.path.exists(reports_dir):
        os.makedirs(reports_dir)
        
    odt_filename = f"relatorio_evento_{evento_id}.odt"
    odt_path = os.path.join(reports_dir, odt_filename)
    doc.save(odt_path)
    
    # 7. Convert to PDF
    import subprocess
    try:
        # libreoffice --headless --convert-to pdf --outdir <dir> <file>
        cmd = ['libreoffice', '--headless', '--convert-to', 'pdf', '--outdir', reports_dir, odt_path]
        subprocess.run(cmd, check=True)
        
        pdf_filename = odt_filename.replace('.odt', '.pdf')
        # pdf_path = os.path.join(reports_dir, pdf_filename)
        
        return send_file(os.path.join(reports_dir, pdf_filename), as_attachment=True)
        
    except Exception as e:
        print(f"PDF conversion failed: {e}")
        flash('Erro ao gerar PDF. O arquivo ODT foi gerado.', 'error')
        # Fallback to ODT?
        return send_file(odt_path, as_attachment=True)




@app.route('/relatorio_galeria/<int:evento_id>')
def gerar_relatorio_galeria(evento_id):
    if 'user_id' not in session:
        return redirect(url_for('index'))
        
    db = get_db()
    
    # 1. Fetch event details
    cursor = db.execute('SELECT * FROM eventos WHERE id = ?', (evento_id,))
    evento = cursor.fetchone()
    
    if not evento:
        flash('Evento não encontrado.', 'error')
        return redirect(url_for('perfil'))
        
    # Check if user is owner
    if evento['pessoa_id'] != session['user_id']:
        flash('Você não tem permissão para gerar relatório deste evento.', 'error')
        return redirect(url_for('perfil'))

    # 2. Fetch attendance data
    cursor = db.execute('''
        SELECT p.id, p.nome, p.curso, pr.registrado_em
        FROM presencas pr
        JOIN pessoas p ON pr.pessoa_id = p.id
        WHERE pr.evento_id = ?
        ORDER BY p.nome ASC
    ''', (evento_id,))
    presencas = cursor.fetchall()
    
    # 3. Load Template
    from odf.opendocument import load
    from odf.table import Table, TableRow, TableCell
    from odf.text import P, PageNumber
    from odf import teletype
    from odf.style import Style, ParagraphProperties, TableColumnProperties, MasterPage, Footer
    
    template_path = os.path.join('static', 'template_relatorios', 'template_lista_frequencia.odt')
    if not os.path.exists(template_path):
        flash('Template de relatório não encontrado.', 'error')
        return redirect(url_for('perfil'))
        
    doc = load(template_path)
    
    # Add Page Numbering to Footer
    # Iterate over master styles to find the standard one or all of them
    for master in doc.masterstyles.getElementsByType(MasterPage):
        # Check if footer exists
        footer = None
        for child in master.childNodes:
            if isinstance(child, Footer):
                footer = child
                break
        
        if not footer:
            footer = Footer()
            master.addElement(footer)
            
        # Check if page number already exists in footer (to avoid duplication if template has it)
        has_page_number = False
        for element in footer.getElementsByType(P):
            for child in element.childNodes:
                if isinstance(child, PageNumber):
                    has_page_number = True
                    break
        
        if not has_page_number:
            # Create a paragraph for the page number
            # We can try to center it. We need a style for that.
            # For now, just adding it might be enough, usually defaults to left.
            # To center, we'd need to define a style.
            
            # Define a centered style
            centered_style = Style(name="FooterCentered", family="paragraph")
            centered_style.addElement(ParagraphProperties(textalign="center"))
            doc.automaticstyles.addElement(centered_style)
            
            p = P(stylename=centered_style)
            p.addElement(PageNumber(selectpage="current"))
            footer.addElement(p)
    
    # 4. Replace Placeholders (Simple Text)
    for p in doc.getElementsByType(P):
        text = teletype.extractText(p)
        if '{{eventos.nome}}' in text:
            new_text = text.replace('{{eventos.nome}}', evento['nome'])
            p.childNodes = []
            teletype.addTextToElement(p, new_text)
            
        if '{{eventos.data}}' in text:
            data_fmt = datetime.strptime(evento['data'], '%Y-%m-%d').strftime('%d/%m/%Y')
            new_text = text.replace('{{eventos.data}}', data_fmt)
            p.childNodes = []
            teletype.addTextToElement(p, new_text)
            
        if '{{eventos.local}}' in text:
            new_text = text.replace('{{eventos.local}}', evento['local'])
            p.childNodes = []
            teletype.addTextToElement(p, new_text)
            
        if '{{eventos.horario}}' in text:
            new_text = text.replace('{{eventos.horario}}', evento['horario'])
            p.childNodes = []
            teletype.addTextToElement(p, new_text)

    # 5. Handle Table Rows (Attendance)
    tables = doc.getElementsByType(Table)
    for table in tables:
        rows = table.getElementsByType(TableRow)
        template_row = None
        for row in rows:
            cells = row.getElementsByType(TableCell)
            row_text = ""
            for cell in cells:
                row_text += teletype.extractText(cell)
            if '{{pessoas.nome}}' in row_text:
                template_row = row
                break
        
        if template_row:
            from odf.element import Text, Element
            def clone_element(element):
                if isinstance(element, Text):
                    return Text(element.data)
                new_el = element.__class__(qname=element.qname, qattributes=element.attributes)
                for child in element.childNodes:
                    cloned_child = clone_element(child)
                    if isinstance(cloned_child, Text):
                        new_el.appendChild(cloned_child)
                    else:
                        new_el.addElement(cloned_child)
                return new_el

            for presenca in presencas:
                new_row = clone_element(template_row)
                cells = new_row.getElementsByType(TableCell)
                for cell in cells:
                    for p in cell.getElementsByType(P):
                        text = teletype.extractText(p)
                        if '{{pessoas.nome}}' in text:
                            nome_exibicao = presenca['nome']
                            if presenca['id'] == evento['pessoa_id']:
                                nome_exibicao += " (responsável)"
                            new_text = text.replace('{{pessoas.nome}}', nome_exibicao)
                            p.childNodes = []
                            teletype.addTextToElement(p, new_text)
                        if '{{pessoas.curso}}' in text:
                            new_text = text.replace('{{pessoas.curso}}', presenca['curso'])
                            p.childNodes = []
                            teletype.addTextToElement(p, new_text)
                        if '{{presencas.registrado_em}}' in text:
                            reg_dt = datetime.strptime(presenca['registrado_em'], '%Y-%m-%d %H:%M:%S')
                            reg_fmt = reg_dt.strftime('%H:%M:%S')
                            new_text = text.replace('{{presencas.registrado_em}}', reg_fmt)
                            p.childNodes = []
                            teletype.addTextToElement(p, new_text)
                table.insertBefore(new_row, template_row)
            table.removeChild(template_row)
            break

    # 6. Add Photo Gallery
    # Fetch photos
    cursor = db.execute('SELECT caminho_arquivo FROM photos_event WHERE evento_id = ? AND status = "ativo"', (evento_id,))
    photos = cursor.fetchall()
    
    if photos:
        # Create page break style
        page_break_style = Style(name="PageBreak", family="paragraph")
        page_break_style.addElement(ParagraphProperties(breakbefore="page"))
        doc.automaticstyles.addElement(page_break_style)
        
        # Add page break
        doc.text.addElement(P(stylename=page_break_style))
        
        # Add Title
        doc.text.addElement(P(text="Galeria de Fotos"))
        
        # Create Table for Gallery (2 columns)
        gallery_table = Table(name="GalleryTable")
        gallery_table.addElement(TableColumn(numbercolumnsrepeated=2))
        
        # Process photos in chunks of 2 (for 2 columns)
        # We want 3 rows per page, so 6 photos per page.
        # But we can just add rows and let the document flow handle pagination naturally, 
        # or force breaks. The prompt asks for "dividir a folha em duas colunas e 3 linhas".
        # If we just create a table with 2 columns, it should flow.
        # To strictly enforce 3 rows per page, we might need manual breaks, but ODT usually handles table flow.
        # However, to ensure images fit, we processed them to be square.
        
        current_row = None
        for i, photo in enumerate(photos):
            if i % 2 == 0:
                # Add spacer row before new row (except the first one)
                if i > 0:
                    spacer_row = TableRow()
                    # Add 2 empty cells for spacing
                    # We can add a paragraph with a specific style to control height if needed, 
                    # but standard line height might be enough separation.
                    # Let's add a bit of text/break to ensure it takes space? 
                    # Or just empty cells. Empty cells might collapse.
                    # Let's add a paragraph with non-breaking space or just empty.
                    c1 = TableCell()
                    c1.addElement(P(text=""))
                    spacer_row.addElement(c1)
                    
                    c2 = TableCell()
                    c2.addElement(P(text=""))
                    spacer_row.addElement(c2)
                    
                    gallery_table.addElement(spacer_row)

                current_row = TableRow()
                gallery_table.addElement(current_row)
            
            cell = TableCell()
            
            # Process image
            # photo['caminho_arquivo'] is relative to static/ e.g. "event_photos/..."
            # We need absolute path for processing
            abs_path = os.path.join(app.root_path, 'static', photo['caminho_arquivo'])
            
            if os.path.exists(abs_path):
                processed_path = process_image_for_gallery(abs_path)
                
                # Add to ODT
                # 1. Add picture to document manifest
                href = doc.addPicture(processed_path)
                
                # 2. Create Frame
                # 8.5cm width for larger images (2 rows per page)
                frame = Frame(width="8.5cm", height="8.5cm", anchortype="as-char")
                image_ref = OdfImage(href=href)
                frame.addElement(image_ref)
                
                # 3. Add to paragraph
                p = P()
                p.addElement(frame)
                cell.addElement(p)
                
                # Processed file is kept for history as per user request
            
            current_row.addElement(cell)
            
            # If we have an odd number of photos, the last row will have 1 cell, which is fine.
            
        doc.text.addElement(gallery_table)

    # 7. Save ODT
    reports_dir = os.path.join('static', 'reports')
    if not os.path.exists(reports_dir):
        os.makedirs(reports_dir)
        
    odt_filename = f"relatorio_galeria_evento_{evento_id}.odt"
    odt_path = os.path.join(reports_dir, odt_filename)
    doc.save(odt_path)
    
    # 8. Convert to PDF
    import subprocess
    try:
        cmd = ['libreoffice', '--headless', '--convert-to', 'pdf', '--outdir', reports_dir, odt_path]
        subprocess.run(cmd, check=True)
        
        pdf_filename = odt_filename.replace('.odt', '.pdf')
        return send_file(os.path.join(reports_dir, pdf_filename), as_attachment=True)
        
    except Exception as e:
        print(f"PDF conversion failed: {e}")
        flash('Erro ao gerar PDF. O arquivo ODT foi gerado.', 'error')
        return send_file(odt_path, as_attachment=True)

ALLOWED_ROLES = [
    'preceptor', 'preceptora', 
    'orientador de serviço', 'orientadora de serviço', 
    'tutor', 'tutora'
]

@app.route('/evento/novo', methods=['GET', 'POST'])
def novo_evento():
    if 'user_id' not in session:
        return redirect(url_for('index'))
        
    db = get_db()
    user_id = session['user_id']
    cursor = db.execute('SELECT * FROM pessoas WHERE id = ?', (user_id,))
    user = cursor.fetchone()
    
    if not user or user['curso'].lower() not in ALLOWED_ROLES:
        flash('Você não tem permissão para criar eventos.', 'error')
        return redirect(url_for('perfil'))
        
    if request.method == 'POST':
        nome = request.form['nome']
        data = request.form['data']
        horario = request.form['horario']
        local = request.form['local']
        carga_horaria = request.form['carga_horaria']
        
        try:
            db.execute('''
                INSERT INTO eventos (nome, data, horario, local, carga_horaria, pessoa_id)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (nome, data, horario, local, carga_horaria, user_id))
            db.commit()
            flash('Evento criado com sucesso!', 'success')
            return redirect(url_for('perfil'))
        except Exception as e:
            flash(f'Erro ao criar evento: {e}', 'error')
            
    return render_template('evento_form.html')

@app.route('/evento/editar/<int:id>', methods=['GET', 'POST'])
def editar_evento(id):
    if 'user_id' not in session:
        return redirect(url_for('index'))
        
    db = get_db()
    user_id = session['user_id']
    
    # Check ownership
    cursor = db.execute('SELECT * FROM eventos WHERE id = ?', (id,))
    evento = cursor.fetchone()
    
    if not evento:
        flash('Evento não encontrado.', 'error')
        return redirect(url_for('perfil'))
        
    if evento['pessoa_id'] != user_id:
        flash('Você não tem permissão para editar este evento.', 'error')
        return redirect(url_for('perfil'))
        
    if request.method == 'POST':
        nome = request.form['nome']
        data = request.form['data']
        horario = request.form['horario']
        local = request.form['local']
        carga_horaria = request.form['carga_horaria']
        
        try:
            db.execute('''
                UPDATE eventos 
                SET nome = ?, data = ?, horario = ?, local = ?, carga_horaria = ?
                WHERE id = ?
            ''', (nome, data, horario, local, carga_horaria, id))
            db.commit()
            flash('Evento atualizado com sucesso!', 'success')
            return redirect(url_for('perfil'))
        except Exception as e:
            flash(f'Erro ao atualizar evento: {e}', 'error')
            
    return render_template('evento_form.html', evento=evento)

@app.route('/evento/excluir/<int:id>', methods=['POST'])
def excluir_evento(id):
    if 'user_id' not in session:
        return redirect(url_for('index'))
        
    db = get_db()
    user_id = session['user_id']
    
    # Check ownership and if deleted
    cursor = db.execute('SELECT * FROM eventos WHERE id = ? AND deleted_at IS NULL', (id,))
    evento = cursor.fetchone()
    
    if not evento:
        flash('Evento não encontrado.', 'error')
        return redirect(url_for('perfil'))
        
    if evento['pessoa_id'] != user_id:
        flash('Você não tem permissão para excluir este evento.', 'error')
        return redirect(url_for('perfil'))
        
    # Check attendance
    cursor = db.execute('SELECT COUNT(*) FROM presencas WHERE evento_id = ?', (id,))
    attendance_count = cursor.fetchone()[0]
    
    if attendance_count > 0:
        flash('Não é possível excluir eventos que já possuem presença registrada.', 'error')
        return redirect(url_for('perfil'))
        
    try:
        db.execute('UPDATE eventos SET deleted_at = CURRENT_TIMESTAMP WHERE id = ?', (id,))
        db.commit()
        flash('Evento excluído com sucesso!', 'success')
    except Exception as e:
        flash(f'Erro ao excluir evento: {e}', 'error')
        
    return redirect(url_for('perfil'))

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
