import multiprocessing

# Bind to 0.0.0.0:5000
bind = "0.0.0.0:5000"

# Worker Configuration
# Recommended: (2 * cpu_cores) + 1
workers = multiprocessing.cpu_count() * 2 + 1
# Use 'gthread' for thread-based concurrency if needed, or 'sync' (default)
worker_class = 'sync'
# Threads per worker (only for gthread)
# threads = 2

# Timeout configuration
# Increase timeout to handle long report generation (e.g., 120 seconds)
timeout = 120

# Backlog - number of pending connections
backlog = 2048

# Logging
accesslog = "-"
errorlog = "-"
loglevel = "info"

# Process Name
proc_name = "registro_frequencia_app"
