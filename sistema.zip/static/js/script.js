// Manual Code Entry
document.getElementById('btn-manual').addEventListener('click', function () {
    const code = document.getElementById('manual-code').value;
    if (!code) {
        alert('Por favor, digite o código do evento.');
        return;
    }
    enviarCodigoManual(code);
});

function enviarCodigoManual(code) {
    const btn = document.getElementById('btn-manual');
    const originalContent = btn.innerHTML;

    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
    btn.disabled = true;

    const formData = new FormData();
    formData.append('event_code', code);

    fetch('/frequencia', {
        method: 'POST',
        body: formData
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('✅ ' + data.message);
                window.location.href = '/perfil';
            } else {
                alert('❌ ' + data.message);
            }
        })
        .catch(error => {
            console.error('Erro:', error);
            alert('Erro ao processar solicitação.');
        })
        .finally(() => {
            btn.innerHTML = originalContent;
            btn.disabled = false;
        });
}
