from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_login import LoginManager
from flask_wtf.csrf import CSRFProtect
from flask_admin import Admin
from flask_jwt_extended import JWTManager
from authlib.integrations.flask_client import OAuth
from flask_seeder import FlaskSeeder
from flask_babel import Babel

from app.admin_base import SecureAdminIndexView

db = SQLAlchemy()
migrate = Migrate()
login_manager = LoginManager()
csrf = CSRFProtect()
admin = Admin(name='Policia TL Admin', index_view=SecureAdminIndexView())
admin.base_template = 'admin/custom_base.html'
jwt = JWTManager()
oauth = OAuth()
seeder = FlaskSeeder()
babel = Babel()
