import socket
import urllib3.util.connection as urllib3_cn
def allowed_gai_family():
    return socket.AF_INET
urllib3_cn.allowed_gai_family = allowed_gai_family

from flask import Flask
from config import config
from app.extensions import db, migrate, login_manager, csrf, admin, jwt, oauth, seeder, babel

def create_app(config_name='default'):
    app = Flask(__name__)
    app.config.from_object(config[config_name])

    db.init_app(app)
    migrate.init_app(app, db)
    login_manager.init_app(app)
    csrf.init_app(app)
    admin.init_app(app)
    jwt.init_app(app)
    oauth.init_app(app)
    seeder.init_app(app, db)

    from app import models
    
    from app.services.audit_service import register_audit_events
    register_audit_events(app)

    oauth.register(
        name='google',
        client_id=app.config['GOOGLE_CLIENT_ID'],
        client_secret=app.config['GOOGLE_CLIENT_SECRET'],
        access_token_url='https://accounts.google.com/o/oauth2/token',
        access_token_params=None,
        authorize_url='https://accounts.google.com/o/oauth2/auth',
        authorize_params=None,
        api_base_url='https://www.googleapis.com/oauth2/v1/',
        client_kwargs={'scope': 'openid email profile'},
        jwks_uri='https://www.googleapis.com/oauth2/v3/certs',
        userinfo_endpoint='https://openidconnect.googleapis.com/v1/userinfo',
    )

    def get_locale():
        return 'pt_BR'

    babel.init_app(app, locale_selector=get_locale)

    from app.routes.auth import auth_bp
    app.register_blueprint(auth_bp, url_prefix='/auth')
    
    from app.routes.api import api_bp
    app.register_blueprint(api_bp, url_prefix='/api')

    from app.models import UsuarioSistema, MulherProtegida, LogAcesso, AuditoriaOperacao, AplicativoAutorizado
    from app.admin_views import SecureAdminIndexView, SecureModelView, MulherProtegidaView, UsuarioSistemaView, AplicativoAutorizadoView, AuditoriaView, LogAcessoView
    

    admin.add_view(UsuarioSistemaView(UsuarioSistema, db.session, name='Usuários'))
    admin.add_view(MulherProtegidaView(MulherProtegida, db.session, name='Mulheres Protegidas'))
    admin.add_view(LogAcessoView(LogAcesso, db.session, name='Logs de Acesso'))
    admin.add_view(AuditoriaView(AuditoriaOperacao, db.session, name='Auditoria'))
    admin.add_view(AplicativoAutorizadoView(AplicativoAutorizado, db.session, name='Apps Autorizados'))
    
    from flask_admin.menu import MenuLink
    admin.add_link(MenuLink(name='Sair', category='', url='/auth/logout'))

    @app.route('/')
    def index():
        from flask import redirect, url_for
        return redirect(url_for('auth.login'))

    return app
