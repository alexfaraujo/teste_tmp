import urllib.parse
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    environment: str
    secret_key: str
    db_user: str
    db_password: str
    db_host: str
    db_port: int
    db_name: str
    email_address: str
    pagination_limit: int
    max_image_pixels: int
    max_image_resize_width: int
    max_image_resize_height: int
    smtp_host: str
    smtp_port: int

    @property
    def database_url(self) -> str:
        encoded_password = urllib.parse.quote_plus(self.db_password)
        return f"postgresql://{self.db_user}:{encoded_password}@{self.db_host}:{self.db_port}/{self.db_name}"

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8")

settings = Settings()
