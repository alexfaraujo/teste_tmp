import os
import smtplib
from email.message import EmailMessage
from app.core.config import settings

class EmailService:
    @staticmethod
    def send_access_code(to_email: str, nome: str, codigo: str):
        try:
            msg = EmailMessage()
            msg.set_content(f"Olá {nome},\n\nSeu código de acesso ao sistema Falaqueufui é: {codigo}\n\nGuarde este código, pois ele é sua chave de acesso.")
            msg['Subject'] = "Seu Código de Acesso - Falaqueufui"
            msg['From'] = f"Falaqueufui Sistema <{settings.email_address}>"
            msg['To'] = f"{nome} <{to_email}>"

            with smtplib.SMTP(settings.smtp_host, settings.smtp_port) as server:
                server.send_message(msg)
            return True
        except Exception as e:
            print(f"Error sending email to {to_email}: {e}")
            return False
