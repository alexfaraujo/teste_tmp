#!/usr/bin/env bash
# Utilitário EasyEvent - Atalho para inicializar tabelas e administrador no PostgreSQL

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null 2>&1 && pwd)"
PROJECT_ROOT="$(cd "$DIR/.." >/dev/null 2>&1 && pwd)"
VENV_PYTHON="$PROJECT_ROOT/apps/backend/.venv/bin/python"

if [ -f "$VENV_PYTHON" ]; then
    exec "$VENV_PYTHON" "$DIR/init_db.py" "$@"
else
    python3 "$DIR/init_db.py" "$@"
fi
