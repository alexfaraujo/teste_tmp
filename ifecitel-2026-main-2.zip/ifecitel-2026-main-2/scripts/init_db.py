#!/usr/bin/env python3
"""
EasyEvent — Inicialização e Sincronização do Banco de Dados PostgreSQL (init_db.py)

Executa a criação de todas as tabelas, índices e restrições do sistema via SQLAlchemy
e provisiona o usuário Administrador Mestre inicial caso ainda não exista.
"""

import os
import sys

# Auto-detecção de ambiente virtual: se executado com python do sistema, invoca o venv do backend
script_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.abspath(os.path.join(script_dir, ".."))
backend_dir = os.path.join(project_root, "apps", "backend")
venv_python = os.path.join(backend_dir, ".venv", "bin", "python")

if sys.prefix == sys.base_prefix and os.path.exists(venv_python) and sys.executable != venv_python:
    os.execv(venv_python, [venv_python] + sys.argv)

sys.path.insert(0, backend_dir)

import asyncio
from sqlalchemy import select, text
from sqlalchemy.engine import make_url
from app.core.config import settings
from app.core.database import Base, engine
from app.core.security import get_password_hash
from app.models.enums import UserRole
from app.models.person import Person
# Import de todos os modelos para registro completo no Base.metadata
import app.models  # noqa: F401

# Cores ANSI
C_RESET = "\033[0m"
C_BOLD = "\033[1m"
C_GREEN = "\033[92m"
C_YELLOW = "\033[93m"
C_CYAN = "\033[96m"
C_RED = "\033[91m"


async def initialize_database():
    print(f"\n{C_CYAN}{C_BOLD}{'=' * 68}")
    print("   🚀 EASYEVENT — INICIALIZAÇÃO DE BANCO DE DADOS POSTGRESQL")
    print(f"{'=' * 68}{C_RESET}")
    parsed_db = make_url(settings.DATABASE_URL)
    print(f"Banco Conectado: {parsed_db.host}:{parsed_db.port or 5432}/{parsed_db.database}\n")

    try:
        print("📦 1. Conectando ao PostgreSQL e criando tabelas do sistema...")
        async with engine.begin() as conn:
            # 1. Cria todas as tabelas registradas no Base.metadata
            await conn.run_sync(Base.metadata.create_all)

            # 2. Executa patches incrementais idempotentes
            await conn.execute(text("""
                ALTER TABLE event_participants 
                ADD COLUMN IF NOT EXISTS evaluator_presence_confirmed BOOLEAN NOT NULL DEFAULT FALSE,
                ADD COLUMN IF NOT EXISTS evaluator_presence_confirmed_at TIMESTAMP WITH TIME ZONE;
            """))
            await conn.execute(text("""
                ALTER TABLE projects 
                ADD COLUMN IF NOT EXISTS needs_electricity BOOLEAN NOT NULL DEFAULT FALSE,
                ADD COLUMN IF NOT EXISTS needs_table BOOLEAN NOT NULL DEFAULT FALSE;
            """))
            await conn.execute(text("ALTER TABLE events ADD COLUMN IF NOT EXISTS owner_id INTEGER REFERENCES people(id) ON DELETE SET NULL;"))
            await conn.execute(text("CREATE INDEX IF NOT EXISTS ix_events_owner_id ON events(owner_id);"))
            await conn.execute(text("""
                CREATE TABLE IF NOT EXISTS registration_verifications (
                    id SERIAL PRIMARY KEY,
                    email VARCHAR(100) NOT NULL,
                    code_hash VARCHAR(255) NOT NULL,
                    attempts INTEGER NOT NULL DEFAULT 0,
                    verified BOOLEAN NOT NULL DEFAULT FALSE,
                    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
                    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
                    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
                    deleted_at TIMESTAMP WITH TIME ZONE DEFAULT NULL
                );
            """))
            await conn.execute(text("""
                CREATE INDEX IF NOT EXISTS ix_registration_verifications_email ON registration_verifications(email);
            """))

        print(f"{C_GREEN}✅ 1. Todas as tabelas e índices foram criados/verificados com sucesso!{C_RESET}")

        # 3. Verificação e Criação do Administrador Padrão
        print("\n👤 2. Verificando existência de usuário Administrador...")
        from sqlalchemy.ext.asyncio import AsyncSession
        async with AsyncSession(engine) as session:
            stmt = select(Person).where(Person.role == UserRole.ADMIN, Person.deleted_at.is_(None))
            res = await session.execute(stmt)
            existing_admin = res.scalars().first()

            if existing_admin:
                print(f"{C_YELLOW}ℹ️  Administrador já cadastrado no banco: {existing_admin.email}{C_RESET}")
            else:
                admin_email = "admin@fecitel.ifms.edu.br"
                admin_pass = "admin123"
                admin = Person(
                    name="Administrador FECITEL",
                    email=admin_email,
                    role=UserRole.ADMIN,
                    password_hash=get_password_hash(admin_pass),
                    barcode="BC-ADMIN-01",
                )
                session.add(admin)
                await session.commit()
                print(f"{C_GREEN}✅ Administrador padrão criado com sucesso!{C_RESET}")
                print(f"   • {C_BOLD}E-mail:{C_RESET} {C_CYAN}{admin_email}{C_RESET}")
                print(f"   • {C_BOLD}Senha:{C_RESET}  {C_CYAN}{admin_pass}{C_RESET}")

        print(f"\n{C_CYAN}{'=' * 68}")
        print(f"{C_GREEN}{C_BOLD}🎉 Banco de dados pronto para operação!{C_RESET}")
        print(f"{C_CYAN}{'=' * 68}\n")

    except Exception as e:
        print(f"\n{C_RED}❌ Erro durante a inicialização do banco de dados: {e}{C_RESET}")
        sys.exit(1)
    finally:
        await engine.dispose()


if __name__ == "__main__":
    asyncio.run(initialize_database())
