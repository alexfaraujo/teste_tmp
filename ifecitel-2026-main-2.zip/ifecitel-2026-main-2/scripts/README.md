# Utilitários de Manutenção e Testes — EasyEvent

Este diretório contém scripts auxiliares para facilitar os testes manuais e a homologação local do sistema **EasyEvent**.

## 🚀 Simulador e Teste de Stress de Feira Científica (`simular_evento.py`)

Utilitário de linha de comando de alta performance para simular o ciclo de vida completo de uma feira científica no EasyEvent, orquestrando:
- Criação e parametrização do evento (Áreas, Subáreas, Critérios de Avaliação, Premiações);
- Importação em lote de trabalhos e equipes com estandes e CPFs;
- Portaria: Check-in de estudantes e baixa de kits de estande;
- Sala de Avaliadores: Check-in, qualificação e alocação dinâmica balanceada com cumprimento da Golden Rule;
- Avaliações Mobile: Envio simultâneo de fichas com notas por critério e pareceres qualitativos;
- War Room & TV: Monitoramento de projetos críticos e ranking final.

### 🎮 Como Executar

Você pode executar de modo **interativo** (o script solicitará a quantidade de projetos, avaliadores por projeto e modo no terminal) ou via **flags**:

```bash
# Opção 1: Launcher direto na raiz do repositório (Modo interativo)
./simular_evento.sh

# Opção 2: Passando parâmetros diretamente via linha de comando
./simular_evento.sh --projects 20 --evaluators-per-project 3 --mode turbo

# Opção 3: Modo tempo real com pausas para acompanhar nas telas de TV
./simular_evento.sh --projects 10 --evaluators-per-project 2 --mode realtime

# Opção 4: Utilizando o Python do backend diretamente
./apps/backend/.venv/bin/python scripts/simular_evento.py --projects 15 --evaluators-per-project 3
```

### ⚙️ Opções e Parâmetros da Linha de Comando

| Parâmetro | Descrição | Padrão |
|---|---|---|
| `-p, --projects` | Quantidade de projetos científicos a simular | *Interativo* |
| `-e, --evaluators-per-project` | Quantidade de avaliadores por projeto | *Interativo* |
| `-m, --mode` | Modo de execução: `turbo` (stress test paralelo rápido) ou `realtime` (com delays para visualização no telão) | `turbo` |
| `-l, --levels` | Níveis de ensino a distribuir entre os projetos (ex: `MEDIO,FUNDAMENTAL`) | `MEDIO,FUNDAMENTAL` |
| `--event-id` | ID de um evento existente para simular (se omitido, cria um novo evento simulado) | *Novo evento* |
| `--api-url` | URL base da API FastAPI | `http://localhost:8000/api/v1` |
| `--admin-email` | E-mail do administrador | `admin@fecitel.ifms.edu.br` |
| `--admin-password` | Senha do administrador | `admin123` |

> **Nota sobre Múltiplos Níveis:** O simulador distribui alternadamente os projetos entre os níveis especificados (ex: `MEDIO` e `FUNDAMENTAL`), gerando templates e afiliações escolares compatíveis para cada nível. Na Etapa 7, o simulador apura e exibe o **Ranking 1 Oficial por Grande Área e Nível de Ensino** (Regra BR-12), as **Premiações Especiais / Menções Honrosas** (Regra BR-17) e o **Pódio Geral da Feira**.

---

## 🧹 Utilitário de Limpeza e Reset do Banco de Dados (`limpar_banco.py`)

Permite ao desenvolvedor ou administrador selecionar interativamente o que deseja limpar no banco de dados local (`fecitel_db`), com segurança, relatórios prévios de impacto e confirmações.

### 🚀 Como Executar

Você pode executar de qualquer uma das seguintes formas a partir da raiz do projeto:

```bash
# Opção 1: Via script shell direto (Recomendado)
./scripts/limpar_banco.sh

# Opção 2: Via Python do sistema (ele detecta o venv automaticamente)
python3 scripts/limpar_banco.py

# Opção 3: Usando o Python do ambiente virtual explicitamente
./apps/backend/.venv/bin/python scripts/limpar_banco.py
```

---

### 📋 Menu Interativo de Opções

| Opção | Descrição | O que é afetado |
|---|---|---|
| `[1]` | **📊 Ver Contadores / Estatísticas Atuais** | Exibe a contagem de registros em tempo real de todas as tabelas do sistema. |
| `[2]` | **🔬 Limpar Trabalhos Científicos / Projetos** | Remove trabalhos/projetos, seus membros vinculados (`project_members`), notas parciais (`evaluation_items`), avaliações (`evaluations`) e alocações de banca (`evaluator_allocations`). Mantém os participantes cadastrados no sistema. Pode ser executado para **Todos os Eventos** ou para um **Evento Específico**. |
| `[3]` | **👥 Limpar Participantes** | Remove participantes do evento (`event_participants`, `event_participant_roles`, subáreas e níveis vinculados) e pessoas órfãs. **Proteção:** Administradores globais (`role = 'ADMIN'`), donos de eventos (`owner_id`) e administradores de eventos (`event_administrators`) nunca são excluídos. |
| `[4]` | **📦 Limpeza Geral de Inscritos** | Executa a limpeza conjunta de Projetos + Participantes, zerando as inscrições de uma edição mas mantendo a estrutura do evento intacta (datas, regras, áreas e comissão). |
| `[5]` | **📝 Limpar Apenas Avaliações e Notas** | Zera notas (`evaluation_items`), avaliações concluídas/em andamento (`evaluations`) e alocações de banca (`evaluator_allocations`), retornando os projetos avaliados para o status `HOMOLOGATED`. Ideal para reiniciar a fase de avaliação do zero sem perder os projetos nem os avaliadores. |
| `[6]` | **🏷️ Limpar Áreas e Subáreas do Conhecimento** | Remove áreas (`knowledge_areas`) e subáreas (`subareas`) do evento selecionado. |
| `[7]` | **🏆 Limpar Critérios de Avaliação e Premiações** | Remove critérios de avaliação cadastrados (`evaluation_criteria`), premiações (`awards`) e critérios de prêmios (`award_criteria`). |
| `[8]` | **🧹 Limpar Eventos de Testes Automatizados** | Remove especificamente eventos criados por baterias de testes automatizados (contendo 'Test' no nome), limpando o lixo de dados gerado por testes de integração e pytest. |
| `[9]` | **💣 Reset Total de um Evento Específico** | Zera absolutamente todos os dados operacionais vinculados a um evento selecionado (projetos, participantes, avaliações, alocações, áreas e premiações), mantendo apenas as configurações básicas do evento e seus administradores. |
| `[10]` | **⚠️ Reset Geral do Banco de Dados** | Exclui todos os registros de todas as tabelas e recria o usuário administrador padrão: <br>• **E-mail:** `admin@fecitel.ifms.edu.br`<br>• **Senha:** `admin123` |
| `[0]` | **🚪 Sair** | Encerra o utilitário com segurança. |

---

### 🛡️ Mecanismos de Segurança
1. **Confirmação Explícita:** Nenhuma exclusão é realizada sem que o usuário digite `SIM` para confirmar.
2. **Contagem Prévia de Impacto:** O script avisa exatamente quantos registros de cada tabela serão excluídos antes de você autorizar.
3. **Transações Atômicas:** Todas as operações utilizam transações SQLAlchemy (`BEGIN ... COMMIT`). Em caso de erro, é executado `ROLLBACK` automático para não deixar o banco em estado inconsistente.
4. **Proteção de Administradores:** Contas administrativas são identificadas e protegidas contra exclusão acidental nas rotinas de participantes.

---

## 🛠️ Inicialização e Criação do Banco de Dados (`init_db.py` / `init_db.sh`)

Utilitário essencial para a **primeira execução** do sistema em um servidor novo ou ambiente de homologação limpo:
- Conecta ao PostgreSQL configurado no `.env`;
- Cria automaticamente todas as tabelas, índices e constraints do sistema via SQLAlchemy;
- Aplica patches incrementais idempotentes;
- Cria o usuário Administrador Geral inicial (`admin@fecitel.ifms.edu.br` / `admin123`) caso ainda não exista nenhum administrador no banco.

### 🎮 Como Executar

```bash
# Opção 1: Via launcher shell (Recomendado)
./scripts/init_db.sh

# Opção 2: Via Python do backend diretamente
./apps/backend/.venv/bin/python scripts/init_db.py
```

