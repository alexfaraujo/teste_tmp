#!/usr/bin/env bash
# Utilitário EasyEvent - Atalho para executar a limpeza e reset do banco de dados

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null 2>&1 && pwd)"
PROJECT_ROOT="$(cd "$DIR/.." >/dev/null 2>&1 && pwd)"
VENV_PYTHON="$PROJECT_ROOT/apps/backend/.venv/bin/python"

if [ -f "$VENV_PYTHON" ]; then
    exec "$VENV_PYTHON" "$DIR/limpar_banco.py" "$@"
else
    python3 "$DIR/limpar_banco.py" "$@"
fi
