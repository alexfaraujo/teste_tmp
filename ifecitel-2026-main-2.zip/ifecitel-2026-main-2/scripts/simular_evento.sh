#!/usr/bin/env bash
# EasyEvent - Launcher do Simulador de Ciclo de Vida e Teste de Stress

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null 2>&1 && pwd)"
PROJECT_ROOT="$(cd "$DIR/.." >/dev/null 2>&1 && pwd)"
VENV_PYTHON="$PROJECT_ROOT/apps/backend/.venv/bin/python"
SCRIPT="$DIR/simular_evento.py"

if [ -f "$VENV_PYTHON" ]; then
    exec "$VENV_PYTHON" "$SCRIPT" "$@"
else
    python3 "$SCRIPT" "$@"
fi
