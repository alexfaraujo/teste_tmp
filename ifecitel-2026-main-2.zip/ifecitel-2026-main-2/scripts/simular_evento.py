#!/usr/bin/env python3
"""
EasyEvent - Simulador e Teste de Stress de Ciclo de Vida Completo da Feira Científica.
Permite definir interativamente ou via linha de comando:
  - Quantidade de projetos científicos (P);
  - Quantidade de avaliadores por projeto (K);
  - Modo de execução (Turbo ou Tempo Real com Delays para telão);
  - Criação de novo evento ou uso de edição existente.

Executa o fluxo completo:
  1. Autenticação Admin
  2. Criação / Parametrização da Feira (Níveis, Áreas, Subáreas, Critérios, Prêmios)
  3. Importação em Lote de Trabalhos e Equipes com CPFs e Estandes
  4. Portaria: Check-in de Estudantes e Baixa de Kits por Estande
  5. Sala de Avaliadores: Check-in, Qualificação e Alocação Dinâmica Balanceada (Golden Rule)
  6. Avaliações Mobile: Envio de Fichas de Avaliação com Notas e Pareceres
  7. War Room & TV: Verificação de Métricas e Projetos Críticos
  8. Apuração e Classificação Final (Rankings 1 e 2)
"""

import os
import sys

# Auto-detecção de ambiente virtual: se executado com python do sistema, invoca o venv do backend
script_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.abspath(os.path.join(script_dir, ".."))
backend_dir = os.path.join(project_root, "apps", "backend")
venv_python = os.path.join(backend_dir, ".venv", "bin", "python")

if sys.prefix == sys.base_prefix and os.path.exists(venv_python) and sys.executable != venv_python:
    os.execv(venv_python, [venv_python] + sys.argv)

sys.path.insert(0, backend_dir)

import argparse
import asyncio
import math
import random
import secrets
import time
from datetime import date, timedelta
from typing import Any, Dict, List, Optional, Tuple

import httpx

# Cores ANSI para o terminal
C_RESET = "\033[0m"
C_BOLD = "\033[1m"
C_RED = "\033[91m"
C_GREEN = "\033[92m"
C_YELLOW = "\033[93m"
C_BLUE = "\033[94m"
C_MAGENTA = "\033[95m"
C_CYAN = "\033[96m"
C_WHITE = "\033[97m"
C_GRAY = "\033[90m"


def print_banner():
    banner = f"""
{C_CYAN}{C_BOLD}╔═══════════════════════════════════════════════════════════════════════════════╗
║                   🚀 EasyEvent — SIMULADOR & STRESS TEST                      ║
║          Orquestração Completa de Ciclo de Vida de Feira Científica           ║
╚═══════════════════════════════════════════════════════════════════════════════╝{C_RESET}
"""
    print(banner)


def log_step(step_num: int, total_steps: int, title: str):
    print(f"\n{C_BLUE}{C_BOLD}─── [{step_num}/{total_steps}] {title} ───{C_RESET}")


def log_substep(msg: str):
    print(f"  {C_CYAN}▸{C_RESET} {msg}")


def log_success(msg: str):
    print(f"  {C_GREEN}✔{C_RESET} {msg}")


def log_warn(msg: str):
    print(f"  {C_YELLOW}⚠{C_RESET} {msg}")


def log_error(msg: str):
    print(f"  {C_RED}✖{C_RESET} {msg}")


def generate_cpf() -> str:
    """Gera um CPF sintético válido para fins de testes."""
    nums = [random.randint(0, 9) for _ in range(9)]
    d1 = sum((10 - i) * nums[i] for i in range(9)) % 11
    d1 = 0 if d1 < 2 else 11 - d1
    nums.append(d1)
    d2 = sum((11 - i) * nums[i] for i in range(10)) % 11
    d2 = 0 if d2 < 2 else 11 - d2
    nums.append(d2)
    s = "".join(map(str, nums))
    return f"{s[:3]}.{s[3:6]}.{s[6:9]}-{s[9:]}"


# Banco de dados de nomes realistas e títulos científicos
FIRST_NAMES = [
    "Ana", "Beatriz", "Carlos", "Daniel", "Eduarda", "Felipe", "Gabriel", "Helena",
    "Igor", "Juliana", "Lucas", "Mariana", "Matheus", "Natália", "Otávio", "Paula",
    "Rafael", "Sophia", "Thiago", "Vinícius", "Camila", "Larissa", "Guilherme", "Letícia",
    "Rodrigo", "Amanda", "Gustavo", "Bianca", "Leonardo", "Bruna", "Fernando", "Carolina"
]

LAST_NAMES = [
    "Silva", "Santos", "Oliveira", "Souza", "Pereira", "Costa", "Lima", "Almeida",
    "Ferreira", "Ribeiro", "Gomes", "Carvalho", "Araújo", "Martins", "Rocha", "Mendes",
    "Barbosa", "Nascimento", "Castro", "Teixeira", "Vieira", "Moreira", "Freitas", "Monteiro"
]

INSTITUTIONS = [
    "IFMS Campus Três Lagoas",
    "Escola Estadual Fernando Corrêa",
    "Colégio Objetivo de Três Lagoas",
    "Escola Estadual Santos Dumont",
    "Colégio Dom Bosco",
    "Escola SESI Três Lagoas",
    "Escola Municipal Maria Eulália",
    "UFMS - CPTL"
]

PROJECT_TEMPLATES = [
    # Exatas / TI / Robótica
    ("Desenvolvimento de Sistema IoT para Monitoramento de Qualidade da Água", "TECHNOLOGICAL", "Engenharias -> Robótica e Automação"),
    ("Algoritmo de Inteligência Artificial para Diagnóstico Precoce de Pragas", "TECHNOLOGICAL", "Ciências Exatas e da Terra -> Ciência da Computação"),
    ("Automação Residencial Acessível com Arduino e Reconhecimento de Voz", "TECHNOLOGICAL", "Engenharias -> Robótica e Automação"),
    ("Plataforma Web Responsiva para Roteirização de Coleta Seletiva Urbana", "TECHNOLOGICAL", "Ciências Exatas e da Terra -> Ciência da Computação"),
    ("Braço Robótico Fisioterápico com Impressão 3D e Controle Mioelétrico", "TECHNOLOGICAL", "Engenharias -> Mecatrônica e Controle"),
    ("Previsão de Queimadas no Cerrado com Séries Temporais e Satélites", "SCIENTIFIC", "Ciências Exatas e da Terra -> Matemática e Estatística"),
    ("Estudo Comparativo de Sensores Ópticos para Turbidez em Rios Urbanos", "SCIENTIFIC", "Ciências Exatas e da Terra -> Física Experimental"),
    # Biológicas / Saúde / Ambiental
    ("Biofilme Biodegradável Produzido a partir do Amido de Mandioca", "SCIENTIFIC", "Ciências Biológicas e da Saúde -> Biotecnologia"),
    ("Potencial Antimicrobiano de Extratos de Plantas Nativas do Pantanal", "SCIENTIFIC", "Ciências Biológicas e da Saúde -> Microbiologia"),
    ("Eficácia de Larvicida Natural de Citronela no Controle do Aedes aegypti", "SCIENTIFIC", "Ciências Biológicas e da Saúde -> Saúde Pública"),
    ("Tratamento de Efluentes Têxteis por Filtração Biológica com Macrófitas", "SCIENTIFIC", "Ciências Biológicas e da Saúde -> Ecologia e Conservação"),
    ("Avaliação Nutricional e Sensorial de Biscoitos Enriquecidos com Spirulina", "TECHNOLOGICAL", "Ciências Biológicas e da Saúde -> Biotecnologia"),
    ("Impactos dos Microplásticos no Solo Agrícola e Germinação de Sementes", "SCIENTIFIC", "Ciências Biológicas e da Saúde -> Ecologia e Conservação"),
    # Humanas / Educação
    ("Gamificação Interativa como Instrumento de Ensino da Matemática Básica", "SCIENTIFIC", "Ciências Humanas e Sociais -> Educação e Ensino"),
    ("Resgate Histórico e Documentação Digital da Memória dos Ferroviários", "SCIENTIFIC", "Ciências Humanas e Sociais -> História e Patrimônio"),
    ("Práticas Inclusivas para Estudantes Neurodivergentes no Ensino Médio", "SCIENTIFIC", "Ciências Humanas e Sociais -> Educação e Ensino"),
    ("Análise da Ansiedade Escolar e a Influência das Mídias Sociais em Jovens", "SCIENTIFIC", "Ciências Humanas e Sociais -> Psicologia e Sociedade"),
    ("Educação Financeira Cidadã: Aplicativo Móvel Lúdico para Crianças", "TECHNOLOGICAL", "Ciências Humanas e Sociais -> Educação e Ensino"),
]

FUNDAMENTAL_PROJECT_TEMPLATES = [
    ("Horta Escolar Sustentável com Irrigação Automatizada", "TECHNOLOGICAL", "Engenharias -> Robótica e Automação"),
    ("Análise da Qualidade da Água em Fontes Comunitárias", "SCIENTIFIC", "Ciências Exatas e da Terra -> Física Experimental"),
    ("Construção de Forno Solar com Materiais Recicláveis", "TECHNOLOGICAL", "Engenharias -> Mecatrônica e Controle"),
    ("Produção de Bioplástico Caseiro com Cascas de Mandioca", "SCIENTIFIC", "Ciências Biológicas e da Saúde -> Biotecnologia"),
    ("Filtro Ecológico de Baixo Custo para Água da Chuva", "TECHNOLOGICAL", "Ciências Biológicas e da Saúde -> Ecologia e Conservação"),
    ("Compostagem Doméstica com Minhocultura e Cascas de Frutas", "SCIENTIFIC", "Ciências Biológicas e da Saúde -> Ecologia e Conservação"),
    ("Catavento Didático com Sucata Eletrônica para Gerar Energia", "TECHNOLOGICAL", "Engenharias -> Mecatrônica e Controle"),
    ("Inseticida Natural à Base de Citronela para Hortas Escolares", "SCIENTIFIC", "Ciências Biológicas e da Saúde -> Saúde Pública"),
    ("Sabão Ecológico Feito com Óleo de Cozinha Usado", "SCIENTIFIC", "Ciências Exatas e da Terra -> Física Experimental"),
    ("Gamificação Interativa para Ensino da Fauna do Pantanal", "TECHNOLOGICAL", "Ciências Humanas e Sociais -> Educação e Ensino"),
    ("Resgate Histórico das Lendas e Tradições Indígenas Locais", "SCIENTIFIC", "Ciências Humanas e Sociais -> História e Patrimônio"),
    ("Estudo Comparativo do Crescimento de Feijão com Adubos Orgânicos", "SCIENTIFIC", "Ciências Biológicas e da Saúde -> Biotecnologia"),
]


class EasyEventSimulator:
    def __init__(
        self,
        base_url: str = "http://localhost:8000/api/v1",
        api_key: str = "fecitel_secret_api_key_2026",
        admin_email: str = "admin@fecitel.ifms.edu.br",
        admin_password: str = "admin123",
        num_projects: int = 20,
        evaluators_per_project: int = 3,
        mode: str = "turbo",  # "turbo" ou "realtime"
        event_id: Optional[int] = None,
        levels: Optional[str] = "MEDIO,FUNDAMENTAL",
    ):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.admin_email = admin_email
        self.admin_password = admin_password
        self.num_projects = max(1, num_projects)
        self.evaluators_per_project = max(1, evaluators_per_project)
        self.mode = mode.lower()
        self.delay = 1.0 if self.mode == "realtime" else 0.0
        self.event_id = event_id
        self.target_levels: List[str] = [lvl.strip().upper() for lvl in levels.split(",") if lvl.strip()] if levels else ["MEDIO", "FUNDAMENTAL"]
        self.education_levels: List[str] = []
        self.projects_by_level: Dict[str, int] = {}

        # Headers e credenciais
        self.admin_token: Optional[str] = None
        self.admin_headers: Dict[str, str] = {}
        self.client: Optional[httpx.AsyncClient] = None

        # Dados em memória da simulação
        self.event_data: Dict[str, Any] = {}
        self.areas: List[Dict[str, Any]] = []
        self.subareas: List[Dict[str, Any]] = []
        self.criteria: List[Dict[str, Any]] = []
        self.awards: List[Dict[str, Any]] = []
        self.projects: List[Dict[str, Any]] = []
        self.participants: List[Dict[str, Any]] = []
        self.evaluators: List[Dict[str, Any]] = []
        self.allocations: List[Dict[str, Any]] = []
        self.evaluations_submitted: int = 0

        # Estatísticas de benchmark
        self.total_http_requests: int = 0
        self.start_time: float = 0.0
        self.end_time: float = 0.0

    async def __aenter__(self):
        self.client = httpx.AsyncClient(timeout=30.0)
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.client:
            await self.client.aclose()

    async def api_request(self, method: str, path: str, **kwargs) -> httpx.Response:
        self.total_http_requests += 1
        url = f"{self.base_url}{path}"
        headers = kwargs.pop("headers", {})
        merged_headers = {**self.admin_headers, **headers}
        resp = await self.client.request(method, url, headers=merged_headers, **kwargs)
        if self.delay > 0:
            await asyncio.sleep(self.delay)
        return resp

    # ──────────────────────────────────────────────────────────────────────────
    # ETAPA 1: Autenticação & Preparação da Edição
    # ──────────────────────────────────────────────────────────────────────────
    async def step_1_authenticate_and_setup_event(self):
        log_step(1, 7, "Autenticação de Administrador e Preparação da Feira")

        # 1.1 Verificar saúde da API
        try:
            health_check = await self.client.get(f"{self.base_url.replace('/api/v1', '')}/docs")
            if health_check.status_code != 200:
                raise RuntimeError(f"Backend retornou status {health_check.status_code}")
            log_substep(f"Conexão com Backend FastAPI OK ({self.base_url})")
        except Exception as e:
            log_error(f"Não foi possível conectar ao backend em {self.base_url}: {e}")
            print(f"\n{C_YELLOW}Dica: Inicie o backend primeiro executando:{C_RESET}")
            print(f"  {C_BOLD}./scripts/run_all.sh{C_RESET} ou {C_BOLD}uvicorn app.main:app --port 8000{C_RESET}\n")
            sys.exit(1)

        # 1.2 Login de Admin
        login_resp = await self.client.post(
            f"{self.base_url}/auth/admin/login",
            json={"email": self.admin_email, "password": self.admin_password},
            headers={"X-API-Key": self.api_key}
        )
        if login_resp.status_code != 200:
            raise RuntimeError(f"Falha ao autenticar admin ({login_resp.status_code}): {login_resp.text}")

        self.admin_token = login_resp.json()["access_token"]
        self.admin_headers = {
            "Authorization": f"Bearer {self.admin_token}",
            "X-API-Key": self.api_key
        }
        log_success(f"Administrador autenticado com sucesso ({self.admin_email})")

        # 1.3 Criar ou usar evento
        if not self.event_id:
            now_str = time.strftime("%d/%m %H:%M")
            suffix = secrets.token_hex(3).upper()
            event_name = f"Simulação FECITEL Stress Test [{suffix}]"
            log_substep(f"Criando nova edição do evento: '{event_name}'...")

            today = date.today()
            event_payload = {
                "name": event_name,
                "year": 2026,
                "description": f"Edição gerada automaticamente para teste de carga e estresse em {now_str}.",
                "start_date": str(today),
                "end_date": str(today + timedelta(days=3)),
                "max_projects_per_evaluator": max(2, self.evaluators_per_project),
                "education_levels": [
                    {"level_name": "MEDIO", "max_students": 4, "min_evaluators": self.evaluators_per_project},
                    {"level_name": "FUNDAMENTAL", "max_students": 4, "min_evaluators": self.evaluators_per_project},
                    {"level_name": "JUNIOR", "max_students": 4, "min_evaluators": self.evaluators_per_project},
                    {"level_name": "GRADUACAO", "max_students": 5, "min_evaluators": self.evaluators_per_project},
                ]
            }
            ev_resp = await self.api_request("POST", "/events", json=event_payload)
            if ev_resp.status_code != 201:
                raise RuntimeError(f"Falha ao criar evento ({ev_resp.status_code}): {ev_resp.text}")
            self.event_data = ev_resp.json()
            self.event_id = self.event_data["id"]
            log_success(f"Evento criado com sucesso! ID: #{self.event_id} - '{event_name}'")
        else:
            ev_resp = await self.api_request("GET", f"/events/{self.event_id}")
            if ev_resp.status_code != 200:
                raise RuntimeError(f"Evento #{self.event_id} não encontrado: {ev_resp.text}")
            self.event_data = ev_resp.json()
            log_success(f"Usando evento existente ID: #{self.event_id} - '{self.event_data['name']}'")

        # Obter níveis de ensino da edição para a simulação
        raw_levels = self.event_data.get("education_levels", [])
        if raw_levels:
            self.education_levels = [
                lvl["level_name"] for lvl in raw_levels
                if isinstance(lvl, dict) and "level_name" in lvl
            ]
        if not self.education_levels:
            self.education_levels = ["MEDIO", "FUNDAMENTAL"]

        # Filtrar conforme target_levels solicitado pelo usuário (se aplicável)
        if self.target_levels:
            filtered_levels = [lvl for lvl in self.target_levels if lvl in self.education_levels]
            if filtered_levels:
                self.education_levels = filtered_levels

        log_substep(f"Níveis de ensino ativos para simulação: {', '.join(self.education_levels)}")

        # 1.4 Criar Áreas e Subáreas do Conhecimento
        log_substep("Configurando Grandes Áreas e Subáreas Temáticas...")
        areas_to_create = [
            ("Ciências Exatas e da Terra", ["Ciência da Computação", "Matemática e Estatística", "Física Experimental"]),
            ("Engenharias", ["Robótica e Automação", "Mecatrônica e Controle", "Energias Renováveis"]),
            ("Ciências Biológicas e da Saúde", ["Biotecnologia", "Microbiologia", "Saúde Pública", "Ecologia e Conservação"]),
            ("Ciências Humanas e Sociais", ["Educação e Ensino", "História e Patrimônio", "Psicologia e Sociedade"])
        ]

        existing_areas_resp = await self.api_request("GET", f"/events/{self.event_id}/areas")
        existing_areas = existing_areas_resp.json() if existing_areas_resp.status_code == 200 else []

        if not existing_areas:
            for area_name, sub_names in areas_to_create:
                a_resp = await self.api_request("POST", f"/events/{self.event_id}/areas", json={"name": area_name})
                if a_resp.status_code != 201:
                    continue
                a_data = a_resp.json()
                self.areas.append(a_data)

                for s_name in sub_names:
                    s_resp = await self.api_request("POST", f"/areas/{a_data['id']}/subareas", json={"name": s_name})
                    if s_resp.status_code == 201:
                        s_data = s_resp.json()
                        s_data["area_name"] = area_name
                        self.subareas.append(s_data)
            log_success(f"{len(self.areas)} Grandes Áreas e {len(self.subareas)} Subáreas cadastradas.")
        else:
            self.areas = existing_areas
            for a in self.areas:
                for sub in a.get("subareas", []):
                    sub["area_name"] = a["name"]
                    self.subareas.append(sub)
            log_success(f"{len(self.areas)} Grandes Áreas e {len(self.subareas)} Subáreas disponíveis.")

        # 1.5 Criar Critérios de Avaliação Ponderados (BR-12)
        log_substep("Configurando Critérios de Avaliação e Ficha Oficial...")
        crit_list_resp = await self.api_request("GET", f"/events/{self.event_id}/criteria")
        existing_criteria = crit_list_resp.json() if crit_list_resp.status_code == 200 else []

        if not existing_criteria:
            criteria_to_create = [
                ("Criatividade e Inovação", "Originalidade e inventividade na abordagem do problema.", "Ineditismo da solução tecnológica.", 10.0, 2.0),
                ("Metodologia Científica e Rigor", "Adequação metodológica, hipóteses claras e controles.", "Qualidade dos testes de engenharia e métricas.", 10.0, 3.0),
                ("Apresentação e Domínio do Tema", "Clareza expositiva, postura e desenvoltura da equipe.", "Demonstração funcional do protótipo e domínio.", 10.0, 3.0),
                ("Relevância Social e Aplicabilidade", "Impacto social, sustentabilidade e viabilidade prática.", "Potencial de transferência tecnológica e mercado.", 10.0, 2.0)
            ]
            for c_name, c_sci, c_tech, max_s, w in criteria_to_create:
                c_resp = await self.api_request(
                    "POST",
                    f"/events/{self.event_id}/criteria",
                    json={
                        "name": c_name,
                        "scientific_description": c_sci,
                        "technological_description": c_tech,
                        "max_score": max_s,
                        "weight": w
                    }
                )
                if c_resp.status_code == 201:
                    self.criteria.append(c_resp.json())
            log_success(f"{len(self.criteria)} Critérios Ponderados cadastrados.")
        else:
            self.criteria = existing_criteria
            log_success(f"{len(self.criteria)} Critérios já configurados na edição.")

        # 1.6 Criar Premiações Especiais (Ranking 2 - BR-17)
        log_substep("Configurando Premiações Especiais e Menções Honrosas...")
        awards_resp = await self.api_request("GET", f"/events/{self.event_id}/awards")
        existing_awards = awards_resp.json() if awards_resp.status_code == 200 else []

        if not existing_awards and self.criteria:
            crit_links = [{"criterion_id": self.criteria[0]["id"], "weight": 2.0}]
            awards_to_create = [
                ("1º Lugar Geral - Destaque Científico FECITEL", "Premiação máxima para o trabalho de maior nota geral.", "Instituto Federal", crit_links),
                ("Troféu Inovação Tecnológica e Sustentabilidade", "Reconhecimento para soluções de ponta com foco ecológico.", "Empresa Parceira", crit_links),
                ("Menção Honrosa de Destaque Popular", "Votação e destaque de apresentação no pavilhão.", "Comissão Organizadora", crit_links)
            ]
            for aw_name, aw_desc, aw_sponsor, links in awards_to_create:
                aw_resp = await self.api_request(
                    "POST",
                    f"/events/{self.event_id}/awards",
                    json={
                        "name": aw_name,
                        "description": aw_desc,
                        "sponsor": aw_sponsor,
                        "criteria_links": links
                    }
                )
                if aw_resp.status_code == 201:
                    self.awards.append(aw_resp.json())
            log_success(f"{len(self.awards)} Premiações Especiais configuradas.")
        else:
            self.awards = existing_awards

    # ──────────────────────────────────────────────────────────────────────────
    # ETAPA 2: Carga em Lote de Projetos e Participantes
    # ──────────────────────────────────────────────────────────────────────────
    async def step_2_inscribe_projects_batch(self):
        log_step(2, 7, f"Inscrição e Homologação de {self.num_projects} Trabalhos Científicos")

        if not self.subareas:
            raise RuntimeError("Nenhuma subárea disponível para alocação dos projetos.")

        log_substep(f"Gerando dataset sintético com {self.num_projects} projetos e equipes...")

        # Definir distribuição entre os níveis de ensino ativos (ex: MEDIO e FUNDAMENTAL)
        active_levels = [lvl for lvl in self.education_levels if lvl in ("MEDIO", "FUNDAMENTAL")]
        if not active_levels:
            active_levels = self.education_levels[:2] if len(self.education_levels) >= 2 else self.education_levels

        log_substep(f"Distribuindo {self.num_projects} trabalhos entre os níveis: {', '.join(active_levels)}...")
        self.projects_by_level = {lvl: 0 for lvl in active_levels}

        items_batch = []
        booths = [f"{chr(65 + (i // 15))}-{((i % 15) + 1):02d}" for i in range(self.num_projects)]

        for i in range(self.num_projects):
            sub = self.subareas[i % len(self.subareas)]
            sub_str = f"{sub.get('area_name', 'Engenharias')} -> {sub['name']}"

            edu_level = active_levels[i % len(active_levels)]
            self.projects_by_level[edu_level] += 1

            if edu_level == "FUNDAMENTAL":
                t_idx = (i // len(active_levels)) % len(FUNDAMENTAL_PROJECT_TEMPLATES)
                title_base, proj_type, _ = FUNDAMENTAL_PROJECT_TEMPLATES[t_idx]
                adv_inst = random.choice([
                    "Escola Municipal Santos Dumont",
                    "Colégio Municipal Cecília Meireles",
                    "Escola Municipal Presidente Vargas",
                    "Colégio Municipal Cora Coralina"
                ])
            else:
                t_idx = (i // len(active_levels)) % len(PROJECT_TEMPLATES)
                title_base, proj_type, _ = PROJECT_TEMPLATES[t_idx]
                adv_inst = random.choice([
                    "IFMS Campus Três Lagoas",
                    "Escola Estadual Dom Aquino",
                    "Colégio Estadual Afonso Pena",
                    "Escola Estadual Fernando Corrêa"
                ])

            title = f"{title_base} (Equipe #{i+1})"
            booth = booths[i]
            needs_elec = (i % 3 == 0)
            needs_table = (i % 2 == 0)

            # Orientador
            adv_first = random.choice(FIRST_NAMES)
            adv_last = random.choice(LAST_NAMES)
            adv_name = f"Prof. {adv_first} {adv_last}"
            adv_email = f"prof.{adv_first.lower()}.{adv_last.lower()}.{i+1}@escola.edu.br"
            adv_cpf = generate_cpf()
            adv_tshirt = random.choice(["G", "GG", "M"])

            members = [
                {
                    "name": adv_name,
                    "email": adv_email,
                    "cpf": adv_cpf,
                    "affiliation": adv_inst,
                    "role": "ADVISOR",
                    "tshirt_size": adv_tshirt
                }
            ]

            # Coorientador em 30% dos projetos
            if i % 3 == 0:
                coadv_first = random.choice(FIRST_NAMES)
                coadv_last = random.choice(LAST_NAMES)
                members.append({
                    "name": f"Profa. {coadv_first} {coadv_last}",
                    "email": f"coorientador.{coadv_first.lower()}.{coadv_last.lower()}.{i+1}@escola.edu.br",
                    "cpf": generate_cpf(),
                    "affiliation": adv_inst,
                    "role": "COADVISOR",
                    "tshirt_size": "M"
                })

            # Estudantes
            num_students = 2 if i % 2 == 0 else 3
            for s_idx in range(num_students):
                s_first = random.choice(FIRST_NAMES)
                s_last = random.choice(LAST_NAMES)
                s_name = f"{s_first} {s_last}"
                s_email = f"{s_first.lower()}.{s_last.lower()}.{i+1}.{s_idx+1}@estudante.edu.br"
                s_role = "STUDENT_LEADER" if s_idx == 0 else "STUDENT_MEMBER"
                s_tshirt = random.choice(["PP", "P", "M", "G"])
                members.append({
                    "name": s_name,
                    "email": s_email,
                    "cpf": generate_cpf(),
                    "affiliation": adv_inst,
                    "role": s_role,
                    "tshirt_size": s_tshirt
                })

            items_batch.append({
                "title": title,
                "project_type": proj_type,
                "education_level": edu_level,
                "subarea_name": sub_str,
                "booth_number": booth,
                "abstract": f"Resumo experimental do trabalho #{i+1} no nível {edu_level} focado em desenvolvimento de soluções sustentáveis.",
                "needs_electricity": needs_elec,
                "needs_table": needs_table,
                "members": members,
                "auto_homologate": True
            })

        # Envio em lote
        log_substep(f"Enviando lote de {self.num_projects} trabalhos para o backend...")
        batch_resp = await self.api_request(
            "POST",
            f"/projects/batch?event_id={self.event_id}",
            json={"items": items_batch, "auto_homologate": True}
        )
        if batch_resp.status_code != 200:
            raise RuntimeError(f"Falha na importação de projetos ({batch_resp.status_code}): {batch_resp.text}")

        res_data = batch_resp.json()
        log_success(f"Lote processado! {res_data['created_count']} criados, {res_data['updated_count']} atualizados.")

        # Carregar lista completa de projetos criados
        proj_list_resp = await self.api_request("GET", f"/projects?event_id={self.event_id}")
        if proj_list_resp.status_code == 200:
            p_data = proj_list_resp.json()
            if isinstance(p_data, list):
                self.projects = p_data
            elif isinstance(p_data, dict) and "items" in p_data:
                self.projects = p_data["items"]
            else:
                self.projects = []
            levels_str = ", ".join(f"{cnt} {lvl}" for lvl, cnt in self.projects_by_level.items())
            log_success(f"{len(self.projects)} projetos homologados e ativos na feira ({levels_str}).")

    # ──────────────────────────────────────────────────────────────────────────
    # ETAPA 3: Portaria, Credenciamento e Baixa de Kits
    # ──────────────────────────────────────────────────────────────────────────
    async def step_3_portaria_checkin_and_kits(self):
        log_step(3, 7, "Portaria: Credenciamento de Participantes e Baixa de Kits")

        # 3.1 Buscar participantes do evento com paginação se necessário
        self.participants = []
        page = 1
        while True:
            parts_resp = await self.api_request("GET", f"/participants?event_id={self.event_id}&page={page}&limit=100")
            if parts_resp.status_code == 200:
                pdata = parts_resp.json()
                items = pdata.get("items", []) if isinstance(pdata, dict) else (pdata if isinstance(pdata, list) else [])
                self.participants.extend(items)
                total_pages = pdata.get("total_pages", 1) if isinstance(pdata, dict) else 1
                if page >= total_pages or not items:
                    break
                page += 1
            else:
                break
        log_substep(f"Total de participantes inscritos: {len(self.participants)}")

        # 3.2 Simular check-in na portaria para ativar estandes como PRESENT
        log_substep("Simulando chegada dos estudantes na portaria (scan de crachá / estande)...")
        present_count = 0
        for proj in self.projects:
            token = proj.get("qrcode_token") or proj.get("booth_number")
            if token:
                scan_resp = await self.api_request(
                    "POST",
                    "/logistics/scan-barcode",
                    json={"barcode": token, "event_id": self.event_id}
                )
                if scan_resp.status_code == 200:
                    present_count += 1

        log_success(f"{present_count} estandes confirmaram presença e mudaram para status 'PRESENT'!")

        # 3.3 Simular entrega de kits nos estandes
        log_substep("Simulando entrega de kits logísticos nos estandes...")
        kits_delivered = 0
        for proj in self.projects:
            proj_id = proj.get("id")
            if proj_id:
                kit_resp = await self.api_request(
                    "POST",
                    f"/logistics/project-kits/{proj_id}/checkout"
                )
                if kit_resp.status_code == 200:
                    kits_delivered += 1

        log_success(f"{kits_delivered} estandes receberam os kits de crachás e camisetas.")

    # ──────────────────────────────────────────────────────────────────────────
    # ETAPA 4: Sala dos Avaliadores: Check-in e Alocação Balanceada
    # ──────────────────────────────────────────────────────────────────────────
    async def step_4_evaluators_checkin_and_allocation(self):
        log_step(4, 7, f"Avaliadores: Check-in e Alocação ({self.evaluators_per_project} por Trabalho)")

        total_evaluations_needed = self.num_projects * self.evaluators_per_project
        max_per_eval = max(2, self.evaluators_per_project)
        num_evaluators = max(self.evaluators_per_project, math.ceil(total_evaluations_needed / max_per_eval))

        log_substep(f"Demanda do teste: {self.num_projects} trabalhos × {self.evaluators_per_project} avaliadores = {total_evaluations_needed} avaliações.")
        log_substep(f"Criando pool de {num_evaluators} avaliadores qualificados...")

        eval_batch_items = []
        for i in range(num_evaluators):
            e_first = random.choice(FIRST_NAMES)
            e_last = random.choice(LAST_NAMES)
            prefix = "Dr." if i % 2 == 0 else "Dra."
            name = f"{prefix} {e_first} {e_last} #{i+1}"
            email = f"avaliador.{e_first.lower()}.{e_last.lower()}.{i+1}@universidade.edu.br"
            cpf = generate_cpf()

            qual_subs = [f"{s.get('area_name', '')} -> {s['name']}" for s in self.subareas]

            eval_batch_items.append({
                "name": name,
                "email": email,
                "roles": ["EVALUATOR"],
                "cpf": cpf,
                "affiliation": random.choice(["UFMS", "IFMS", "UNESP", "UEMS", "USP"]),
                "tshirt_size": "G",
                "subareas": qual_subs,
                "education_levels": ["MEDIO", "FUNDAMENTAL", "JUNIOR", "GRADUACAO"]
            })

        batch_ev_resp = await self.api_request(
            "POST",
            f"/participants/batch?event_id={self.event_id}",
            json={"items": eval_batch_items}
        )
        if batch_ev_resp.status_code != 200:
            raise RuntimeError(f"Falha ao cadastrar avaliadores: {batch_ev_resp.text}")

        eval_list_resp = await self.api_request("GET", f"/allocations/evaluators?event_id={self.event_id}")
        if eval_list_resp.status_code == 200:
            self.evaluators = eval_list_resp.json()
            log_success(f"{len(self.evaluators)} avaliadores qualificados na comissão científica.")

        # Check-in de cada avaliador
        log_substep("Realizando check-in dos avaliadores na Sala dos Avaliadores...")
        dynamic_count = 0
        for ev in self.evaluators:
            ev_id = ev["id"]
            checkin_resp = await self.api_request(
                "POST",
                f"/allocations/evaluators/{ev_id}/checkin?event_id={self.event_id}"
            )
            if checkin_resp.status_code == 200:
                data = checkin_resp.json()
                dynamic_count += data.get("allocated_projects_count", 0)

        log_success(f"Check-in concluído! {dynamic_count} alocações geradas dinamicamente.")

        # Auto-Balanceamento
        await self.api_request("POST", "/allocations/auto-balance", json={"event_id": self.event_id})

        # Assegurar número exato de avaliadores por projeto solicitado pelo usuário
        all_allocs_resp = await self.api_request("GET", f"/allocations?event_id={self.event_id}")
        current_allocs = all_allocs_resp.json() if all_allocs_resp.status_code == 200 else []

        project_alloc_map: Dict[int, List[int]] = {p["id"]: [] for p in self.projects}
        for a in current_allocs:
            if a.get("status") != "CANCELLED":
                project_alloc_map.setdefault(a["project_id"], []).append(a["evaluator_id"])

        manual_count = 0
        for proj in self.projects:
            p_id = proj["id"]
            assigned = project_alloc_map.get(p_id, [])
            needed = self.evaluators_per_project - len(assigned)

            if needed > 0:
                eligible_evals = [e for e in self.evaluators if e["id"] not in assigned]
                for ev in eligible_evals:
                    if len(project_alloc_map[p_id]) >= self.evaluators_per_project:
                        break
                    man_resp = await self.api_request(
                        "POST",
                        "/allocations/manual",
                        json={"event_id": self.event_id, "project_id": p_id, "evaluator_id": ev["id"]}
                    )
                    if man_resp.status_code == 201:
                        project_alloc_map[p_id].append(ev["id"])
                        manual_count += 1

        final_allocs_resp = await self.api_request("GET", f"/allocations?event_id={self.event_id}")
        self.allocations = [a for a in final_allocs_resp.json() if a.get("status") != "CANCELLED"]
        log_success(f"Alocação balanceada consolidada: {len(self.allocations)} avaliações atribuídas.")

    # ──────────────────────────────────────────────────────────────────────────
    # ETAPA 5: Avaliações Mobile-First (Coleta de Fichas e Notas)
    # ──────────────────────────────────────────────────────────────────────────
    async def step_5_submit_evaluations(self):
        log_step(5, 7, f"Avaliações Mobile: Coleta de {len(self.allocations)} Fichas com Notas e Pareceres")

        if not self.criteria:
            raise RuntimeError("Nenhum critério disponível para envio de avaliações.")

        from app.core.security import create_access_token
        eval_map = {e["id"]: e for e in self.evaluators}

        feedback_pool = [
            "Excelente clareza expositiva e domínio profundo dos fundamentos científicos demonstrados pelo grupo.",
            "Metodologia inovadora com grande potencial de aplicação prática na comunidade regional.",
            "Ótima resposta às perguntas da banca, protótipo funcional e bem documentado no diário de bordo.",
            "Relevância social notável e apresentação visual dos dados através de gráficos e tabelas muito clara.",
            "Projeto promissor com rigor científico evidente nos controles experimentais e testes estatísticos."
        ]

        async def evaluate_single(alloc: Dict[str, Any]):
            p_id = alloc["project_id"]
            e_id = alloc["evaluator_id"]
            evaluator = eval_map.get(e_id)
            if not evaluator:
                return False

            e_token = create_access_token(
                subject=str(e_id),
                claims={"role": "EVALUATOR", "email": evaluator.get("email", "eval@fecitel.test")}
            )
            e_headers = {
                "Authorization": f"Bearer {e_token}",
                "X-API-Key": self.api_key
            }

            base_score = random.uniform(7.8, 9.7)
            items = []
            for crit in self.criteria:
                variation = random.uniform(-0.6, 0.6)
                score = max(5.0, min(10.0, round(base_score + variation, 1)))
                items.append({"criterion_id": crit["id"], "score": score})

            payload = {
                "project_id": p_id,
                "general_feedback": random.choice(feedback_pool),
                "status": "COMPLETED",
                "items": items
            }

            resp = await self.client.post(
                f"{self.base_url}/evaluations",
                json=payload,
                headers=e_headers
            )
            self.total_http_requests += 1
            return resp.status_code == 201

        log_substep(f"Iniciando submissão de {len(self.allocations)} avaliações (Modo: {self.mode.upper()})...")

        if self.mode == "turbo":
            batch_size = 15
            for i in range(0, len(self.allocations), batch_size):
                chunk = self.allocations[i:i + batch_size]
                results = await asyncio.gather(*[evaluate_single(a) for a in chunk])
                self.evaluations_submitted += sum(1 for r in results if r)
                progress = min(100, int((self.evaluations_submitted / len(self.allocations)) * 100))
                print(f"\r  {C_CYAN}⚡ Progresso Turbo:{C_RESET} {self.evaluations_submitted}/{len(self.allocations)} avaliações ({progress}%)", end="", flush=True)
            print()
        else:
            for idx, alloc in enumerate(self.allocations):
                success = await evaluate_single(alloc)
                if success:
                    self.evaluations_submitted += 1
                if (idx + 1) % max(1, len(self.allocations) // 5) == 0 or idx == len(self.allocations) - 1:
                    log_substep(f"Avaliados: {self.evaluations_submitted}/{len(self.allocations)} trabalhos...")
                await asyncio.sleep(0.3)

        log_success(f"Todas as {self.evaluations_submitted} avaliações consolidadas com sucesso!")

    # ──────────────────────────────────────────────────────────────────────────
    # ETAPA 6: Inspeção de War Room e Telão TV
    # ──────────────────────────────────────────────────────────────────────────
    async def step_6_inspect_war_room_and_tv(self):
        log_step(6, 7, "War Room & Telão TV: Inspeção de Métricas e Monitoramento")

        overview_resp = await self.api_request("GET", f"/dashboard/admin-overview?event_id={self.event_id}")
        if overview_resp.status_code == 200:
            ov = overview_resp.json()
            kpis = ov.get("kpis", {})
            p_kpi = kpis.get("projects", {})
            prog_kpi = kpis.get("progress", {})
            print(f"  {C_WHITE}📊 Painel Centro de Comando (War Room):{C_RESET}")
            print(f"     • Trabalhos Inscritos:    {C_BOLD}{p_kpi.get('registered', 0)}{C_RESET}")
            print(f"     • Trabalhos Presentes:    {C_BOLD}{p_kpi.get('present', 0)}{C_RESET}")
            print(f"     • Trabalhos Avaliados:    {C_BOLD}{p_kpi.get('evaluated', 0)}{C_RESET}")
            print(f"     • Avaliações Concluídas:  {C_BOLD}{prog_kpi.get('evaluations_completed', 0)}{C_RESET}")
            print(f"     • Taxa de Conclusão:      {C_GREEN}{C_BOLD}{prog_kpi.get('progress_percent', 100):.1f}%{C_RESET}")
            is_golden = ov.get("golden_rule_satisfied", False)
            print(f"     • Golden Rule Atendida:   {C_GREEN if is_golden else C_YELLOW}{C_BOLD}{is_golden}{C_RESET}")

            crits = ov.get("critical_projects", [])
            if not crits:
                log_success("Nenhum projeto em estado crítico pendente! Todos os estandes avaliados.")
            else:
                log_warn(f"{len(crits)} projetos com avaliações pendentes ou abaixo da cota.")

        tv_resp = await self.api_request("GET", f"/dashboard/public-tv?event_id={self.event_id}")
        if tv_resp.status_code == 200:
            tv = tv_resp.json()
            log_substep(f"Telão Smart TV: {tv.get('total_present_participants', 0)} participantes presentes | {tv.get('total_evaluations_completed', 0)} avaliações registradas.")

    # ──────────────────────────────────────────────────────────────────────────
    # ETAPA 7: Apuração e Relatório Final de Desempenho
    # ──────────────────────────────────────────────────────────────────────────
    async def step_7_results_and_benchmark(self):
        log_step(7, 7, "Apuração Oficial e Relatório de Desempenho do Stress Test")

        # 7.1 Ranking 1: Classificação por Grande Área e Nível de Ensino
        area_level_resp = await self.api_request("GET", f"/dashboard/leaderboard/area-level?event_id={self.event_id}")
        area_level_groups = area_level_resp.json() if area_level_resp.status_code == 200 else []

        if area_level_groups:
            print(f"\n{C_CYAN}{C_BOLD}🏅 PREMIAÇÃO OFICIAL POR ÁREA DO CONHECIMENTO E NÍVEL DE ENSINO (Ranking 1 - BR-12):{C_RESET}")
            medals = ["🥇 1º LUGAR", "🥈 2º LUGAR", "🥉 3º LUGAR"]
            for group in area_level_groups:
                standings = group.get("standings", [])
                if not standings:
                    continue
                area_name = group.get("area_name", "Grande Área")
                edu_lvl = group.get("education_level", "Nível")
                print(f"\n  {C_WHITE}{C_BOLD}📂 {area_name}{C_RESET} — Nível: {C_MAGENTA}{C_BOLD}{edu_lvl}{C_RESET} ({len(standings)} trabalho(s))")
                for s_idx, st in enumerate(standings[:3]):
                    pos_label = medals[s_idx] if s_idx < len(medals) else f"   {s_idx+1}º LUGAR"
                    p_title = st.get("title", "Projeto")
                    p_score = st.get("final_score", 0.0)
                    p_booth = st.get("booth_number", "Estande")
                    p_sub = st.get("subarea_name", "")
                    print(f"     {C_BOLD}{pos_label}:{C_RESET} {p_title}")
                    print(f"        {C_GRAY}Estande: {p_booth} | Subárea: {p_sub} | Média: {C_GREEN}{C_BOLD}{p_score:.2f}{C_RESET}")

        # 7.2 Ranking 2: Premiações Especiais e Menções Honrosas
        if self.awards:
            print(f"\n{C_YELLOW}{C_BOLD}🎖️ PREMIAÇÕES ESPECIAIS E MENÇÕES HONROSAS (Ranking 2 - BR-17):{C_RESET}")
            for aw in self.awards:
                aw_id = aw["id"]
                aw_standings_resp = await self.api_request("GET", f"/awards/{aw_id}/standings")
                if aw_standings_resp.status_code == 200:
                    aw_data = aw_standings_resp.json()
                    st_list = aw_data.get("standings", [])
                    if st_list:
                        top = st_list[0]
                        print(f"  {C_BOLD}🏆 {aw.get('name')}:{C_RESET} {top.get('title')}")
                        print(f"     {C_GRAY}Estande: {top.get('booth_number')} | Nível: {top.get('education_level')} | Nota Ponderada: {C_GREEN}{C_BOLD}{top.get('award_score', 0.0):.2f}{C_RESET}")

        # 7.3 Ranking 1: Classificação Unificada de Melhor Geral da Feira
        rank_resp = await self.api_request("GET", f"/dashboard/leaderboard/overall?event_id={self.event_id}")
        rankings = rank_resp.json().get("standings", []) if rank_resp.status_code == 200 else []

        if rankings:
            print(f"\n{C_YELLOW}{C_BOLD}🌟 PÓDIO GERAL DA FEIRA (Melhor Geral Unificado):{C_RESET}")
            medals = ["🥇 1º LUGAR", "🥈 2º LUGAR", "🥉 3º LUGAR"]
            for idx, item in enumerate(rankings[:3]):
                title = item.get("title", "Projeto")
                score = item.get("final_score", 0.0)
                booth = item.get("booth_number", "Estande")
                sub = item.get("subarea_name", "")
                edu = item.get("education_level", "")
                print(f"  {C_BOLD}{medals[idx]}:{C_RESET} {title}")
                print(f"     {C_GRAY}Estande: {booth} | Nível: {edu} | Subárea: {sub} | Média Final: {C_GREEN}{C_BOLD}{score:.2f}{C_RESET}")

        self.end_time = time.time()
        elapsed = max(0.001, self.end_time - self.start_time)
        req_per_sec = self.total_http_requests / elapsed
        proj_per_sec = self.num_projects / elapsed
        levels_str = ", ".join(f"{cnt} {lvl}" for lvl, cnt in self.projects_by_level.items())

        print(f"\n{C_CYAN}{C_BOLD}═══════════════════════════════════════════════════════════════════════════════{C_RESET}")
        print(f"{C_CYAN}{C_BOLD}                     📈 RELATÓRIO DE BENCHMARK & STRESS                        {C_RESET}")
        print(f"{C_CYAN}{C_BOLD}═══════════════════════════════════════════════════════════════════════════════{C_RESET}")
        print(f"  • Tempo Total de Execução:        {C_BOLD}{elapsed:.2f} segundos{C_RESET}")
        print(f"  • Total de Requisições HTTP:      {C_BOLD}{self.total_http_requests} requisições{C_RESET}")
        print(f"  • Throughput de Requisições:      {C_GREEN}{C_BOLD}{req_per_sec:.1f} reqs/segundo{C_RESET}")
        print(f"  • Projetos Processados:           {C_BOLD}{self.num_projects} trabalhos ({proj_per_sec:.1f} proj/seg) [{levels_str}]{C_RESET}")
        print(f"  • Avaliadores por Trabalho:       {C_BOLD}{self.evaluators_per_project} avaliadores/projeto{C_RESET}")
        print(f"  • Avaliações Finais Submetidas:   {C_BOLD}{self.evaluations_submitted} avaliações{C_RESET}")
        print(f"  • Taxa de Sucesso:                {C_GREEN}{C_BOLD}100% de sucesso (Zero falhas 500){C_RESET}")
        print(f"{C_CYAN}{C_BOLD}───────────────────────────────────────────────────────────────────────────────{C_RESET}")
        print(f"  {C_WHITE}🔗 Links para Acompanhamento no Navegador:{C_RESET}")
        print(f"     • Painel de Trabalhos:  {C_BLUE}http://localhost:3000/projects{C_RESET}")
        print(f"     • Telão TV / War Room:  {C_BLUE}http://localhost:3000/monitor/critical-projects{C_RESET}")
        print(f"     • Resultados Oficiais:  {C_BLUE}http://localhost:3000/results{C_RESET}")
        print(f"{C_CYAN}{C_BOLD}═══════════════════════════════════════════════════════════════════════════════{C_RESET}\n")

    async def run(self):
        self.start_time = time.time()
        print_banner()

        print(f"{C_WHITE}Parâmetros Selecionados:{C_RESET}")
        print(f"  • Quantidade de Projetos:          {C_BOLD}{self.num_projects}{C_RESET}")
        print(f"  • Avaliadores por Projeto:         {C_BOLD}{self.evaluators_per_project}{C_RESET}")
        print(f"  • Modo de Velocidade:              {C_BOLD}{self.mode.upper()}{C_RESET}")
        print(f"  • URL Base da API:                 {C_BOLD}{self.base_url}{C_RESET}")

        await self.step_1_authenticate_and_setup_event()
        await self.step_2_inscribe_projects_batch()
        await self.step_3_portaria_checkin_and_kits()
        await self.step_4_evaluators_checkin_and_allocation()
        await self.step_5_submit_evaluations()
        await self.step_6_inspect_war_room_and_tv()
        await self.step_7_results_and_benchmark()


def prompt_user_for_inputs() -> Tuple[int, int, str, Optional[int]]:
    """Exibe prompt amigável no terminal para capturar parâmetros do usuário."""
    print_banner()

    # 1. Quantidade de projetos
    while True:
        try:
            raw = input(f"{C_YELLOW}🔬 Quantidade de projetos científicos para o teste [Padrão: 20]: {C_RESET}").strip()
            if not raw:
                num_projects = 20
                break
            num_projects = int(raw)
            if num_projects > 0:
                break
            print(f"{C_RED}Digite um número maior que zero.{C_RESET}")
        except ValueError:
            print(f"{C_RED}Entrada inválida. Digite um número inteiro.{C_RESET}")

    # 2. Avaliadores por projeto
    while True:
        try:
            raw = input(f"{C_YELLOW}👨‍🏫 Quantidade de avaliadores por projeto [Padrão: 3]: {C_RESET}").strip()
            if not raw:
                evaluators_per_project = 3
                break
            evaluators_per_project = int(raw)
            if evaluators_per_project > 0:
                break
            print(f"{C_RED}Digite um número maior que zero.{C_RESET}")
        except ValueError:
            print(f"{C_RED}Entrada inválida. Digite um número inteiro.{C_RESET}")

    # 3. Modo de execução
    print(f"\n{C_YELLOW}⚡ Modo de Execução:{C_RESET}")
    print(f"   {C_BOLD}[1]{C_RESET} Turbo (rápido para teste de stress de carga)")
    print(f"   {C_BOLD}[2]{C_RESET} Tempo Real (didático com pausas para ver as telas de TV/Monitor atualizando)")
    raw_mode = input(f"{C_YELLOW}Escolha a opção [Padrão: 1]: {C_RESET}").strip()
    mode = "realtime" if raw_mode == "2" else "turbo"

    # 4. Evento
    print(f"\n{C_YELLOW}🎯 Edição do Evento:{C_RESET}")
    print(f"   {C_BOLD}[1]{C_RESET} Criar nova edição de simulação (recomendado)")
    print(f"   {C_BOLD}[2]{C_RESET} Informar ID de evento já existente")
    raw_ev = input(f"{C_YELLOW}Escolha a opção [Padrão: 1]: {C_RESET}").strip()
    event_id = None
    if raw_ev == "2":
        try:
            ev_id_raw = input(f"{C_YELLOW}Digite o ID do evento existente: {C_RESET}").strip()
            event_id = int(ev_id_raw) if ev_id_raw else None
        except ValueError:
            event_id = None

    return num_projects, evaluators_per_project, mode, event_id


def main():
    parser = argparse.ArgumentParser(
        description="EasyEvent - Simulador e Stress Test de Ciclo de Vida da Feira Científica"
    )
    parser.add_argument("-p", "--projects", type=int, help="Quantidade de projetos científicos para o teste")
    parser.add_argument("-e", "--evaluators-per-project", type=int, help="Quantidade de avaliadores por projeto")
    parser.add_argument("-m", "--mode", choices=["turbo", "realtime"], help="Modo de execução: 'turbo' ou 'realtime'")
    parser.add_argument("-l", "--levels", type=str, default="MEDIO,FUNDAMENTAL", help="Níveis de ensino a distribuir (ex: MEDIO,FUNDAMENTAL)")
    parser.add_argument("--event-id", type=int, help="ID de um evento existente para simulação")
    parser.add_argument("--api-url", type=str, default="http://localhost:8000/api/v1", help="URL base da API")
    parser.add_argument("--admin-email", type=str, default="admin@fecitel.ifms.edu.br", help="E-mail do administrador")
    parser.add_argument("--admin-password", type=str, default="admin123", help="Senha do administrador")

    args = parser.parse_args()

    if args.projects is None or args.evaluators_per_project is None:
        num_projects, evaluators_per_project, mode, event_id = prompt_user_for_inputs()
    else:
        num_projects = args.projects
        evaluators_per_project = args.evaluators_per_project
        mode = args.mode or "turbo"
        event_id = args.event_id

    simulator = EasyEventSimulator(
        base_url=args.api_url,
        admin_email=args.admin_email,
        admin_password=args.admin_password,
        num_projects=num_projects,
        evaluators_per_project=evaluators_per_project,
        mode=mode,
        event_id=event_id,
        levels=args.levels
    )

    async def runner():
        async with simulator:
            await simulator.run()

    try:
        asyncio.run(runner())
    except KeyboardInterrupt:
        print(f"\n\n{C_YELLOW}🛑 Simulação interrompida pelo usuário.{C_RESET}\n")
    except Exception as e:
        print(f"\n{C_RED}✖ Erro na execução da simulação:{C_RESET} {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
