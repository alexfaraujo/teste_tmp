#!/usr/bin/env bash
# ==============================================================================
# FECITEL — Script de Configuração de Ambiente Bare-Metal (setup_env.sh)
# ==============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"

echo "============================================================"
echo "🛠️  FECITEL — Verificação e Configuração do Ambiente Local"
echo "============================================================"

# Cores para saída
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# 1. Checagem do Python 3.11+
echo -e "\n🔍 1. Verificando ambiente Python..."
if command -v python3 &> /dev/null; then
    PY_VER=$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
    PY_MAJOR=$(python3 -c 'import sys; print(sys.version_info.major)')
    PY_MINOR=$(python3 -c 'import sys; print(sys.version_info.minor)')
    if [ "$PY_MAJOR" -ge 3 ] && [ "$PY_MINOR" -ge 11 ]; then
        echo -e "${GREEN}✅ Python ${PY_VER} detectado (atende ao requisito 3.11+)${NC}"
    else
        echo -e "${YELLOW}⚠️  Aviso: Python ${PY_VER} detectado. Recomendado Python 3.11 ou superior.${NC}"
    fi
else
    echo -e "${RED}❌ Erro: python3 não encontrado no sistema.${NC}"
    exit 1
fi

# Garantir caminhos padrão do Homebrew no PATH (macOS Apple Silicon e Intel)
for brew_bin in "/opt/homebrew/bin" "/usr/local/bin"; do
    if [ -d "$brew_bin" ] && [[ ":$PATH:" != *":$brew_bin:"* ]]; then
        export PATH="$brew_bin:$PATH"
    fi
done

# 2. Checagem e Instalação Automatizada do Node.js 18+
echo -e "\n🔍 2. Verificando ambiente Node.js..."
if ! command -v node &> /dev/null; then
    echo -e "${YELLOW}⚠️  Node.js não detectado no PATH. Tentando instalar automaticamente...${NC}"
    if [ -x "/opt/homebrew/bin/brew" ]; then
        echo -e "🍺 Instalando Node.js via Homebrew (/opt/homebrew/bin/brew)..."
        /opt/homebrew/bin/brew install node
        export PATH="/opt/homebrew/bin:$PATH"
    elif command -v brew &> /dev/null; then
        echo -e "🍺 Instalando Node.js via Homebrew (brew)..."
        brew install node
    elif command -v apt-get &> /dev/null; then
        echo -e "📦 Instalando Node.js via apt..."
        curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
        sudo apt-get install -y nodejs
    else
        echo -e "${RED}❌ Erro: Gerenciador de pacotes compatível não encontrado para instalação automática do Node.js.${NC}"
        echo -e "Por favor, instale o Node.js 18 ou 20 LTS manualmente."
        exit 1
    fi
fi

if command -v node &> /dev/null; then
    NODE_VER=$(node -v)
    echo -e "${GREEN}✅ Node.js ${NODE_VER} detectado e pronto.${NC}"
else
    echo -e "${RED}❌ Erro: Node.js não pôde ser instalado ou localizado no PATH.${NC}"
    exit 1
fi

if command -v npm &> /dev/null; then
    NPM_VER=$(npm -v)
    echo -e "${GREEN}✅ npm ${NPM_VER} detectado.${NC}"
else
    echo -e "${RED}❌ Erro: npm não encontrado no sistema.${NC}"
    exit 1
fi

# 3. Checagem do PostgreSQL Local (Porta 5432)
echo -e "\n🔍 3. Verificando conectividade com PostgreSQL local (porta 5432)..."
if nc -z 127.0.0.1 5432 2>/dev/null || nc -z localhost 5432 2>/dev/null; then
    echo -e "${GREEN}✅ PostgreSQL está ativo e respondendo na porta padrão 5432.${NC}"
else
    echo -e "${YELLOW}⚠️  Aviso: Não foi possível detectar o PostgreSQL escutando na porta 5432.${NC}"
    echo -e "   Certifique-se de que o serviço do PostgreSQL está iniciado na máquina local."
    echo -e "   Caso precise criar o usuário e o banco de dados 'fecitel_db', siga o README.md Seção 4."
fi

# 4. Preparação do Diretório de Armazenamento de Arquivos
echo -e "\n📁 4. Verificando diretório de uploads local..."
mkdir -p "${ROOT_DIR}/storage/uploads"
touch "${ROOT_DIR}/storage/uploads/.gitkeep"
echo -e "${GREEN}✅ Diretório de armazenamento configurado: ${ROOT_DIR}/storage/uploads${NC}"

# 5. Configuração do Backend (Python .venv e dependências)
echo -e "\n🐍 5. Configurando ambiente virtual do Backend (apps/backend)..."
cd "${ROOT_DIR}/apps/backend"

if [ ! -f ".env" ]; then
    echo "📄 Criando apps/backend/.env a partir do .env.example..."
    cp .env.example .env
fi

if [ ! -d ".venv" ]; then
    echo "📦 Criando ambiente virtual Python (.venv)..."
    python3 -m venv .venv
fi

# Ativação do venv e instalação
# shellcheck source=/dev/null
source .venv/bin/activate
echo "📥 Atualizando pip e instalando requirements.txt..."
pip install --upgrade pip --quiet
pip install -r requirements.txt --quiet
echo -e "${GREEN}✅ Dependências do Backend instaladas com sucesso no .venv.${NC}"

# 6. Configuração dos Frontends (Arquivos .env.local)
echo -e "\n🌐 6. Configurando variáveis de ambiente dos frontends..."

if [ ! -f "${ROOT_DIR}/apps/frontend-admin/.env.local" ]; then
    cp "${ROOT_DIR}/apps/frontend-admin/.env.example" "${ROOT_DIR}/apps/frontend-admin/.env.local"
    echo "✅ apps/frontend-admin/.env.local criado."
fi

if [ ! -f "${ROOT_DIR}/apps/frontend-evaluator/.env.local" ]; then
    cp "${ROOT_DIR}/apps/frontend-evaluator/.env.example" "${ROOT_DIR}/apps/frontend-evaluator/.env.local"
    echo "✅ apps/frontend-evaluator/.env.local criado."
fi

if [ ! -f "${ROOT_DIR}/apps/frontend-kiosk/.env.local" ]; then
    cp "${ROOT_DIR}/apps/frontend-kiosk/.env.example" "${ROOT_DIR}/apps/frontend-kiosk/.env.local"
    echo "✅ apps/frontend-kiosk/.env.local criado."
fi

# 7. Inicialização do Banco de Dados PostgreSQL (Criação de Tabelas e Admin Padrão)
echo -e "\n📦 7. Inicializando tabelas e administrador mestre no PostgreSQL..."
if [ -f "${ROOT_DIR}/scripts/init_db.sh" ]; then
    bash "${ROOT_DIR}/scripts/init_db.sh" || echo -e "${YELLOW}⚠️  Aviso: Não foi possível sincronizar o banco agora. Execute ./scripts/init_db.sh assim que o PostgreSQL estiver ativo.${NC}"
fi

echo -e "\n============================================================"
echo -e "${GREEN}🎉 Setup de Ambiente concluído com sucesso!${NC}"
echo -e "Para inicializar os 4 blocos locais simultaneamente:"
echo -e "   ${YELLOW}./scripts/run_all.sh${NC}"
echo -e "============================================================"
