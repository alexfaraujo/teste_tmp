#!/usr/bin/env bash
# ==============================================================================
# EasyEvent — Script de Execução Unificada dos 4 Blocos Locais (run_all.sh)
# ==============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"

# Cores do terminal
CYAN='\033[0;36m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${CYAN}============================================================${NC}"
echo -e "${CYAN}🚀 EasyEvent — Inicializando Monorepo (4 Blocos Locais)${NC}"
echo -e "${CYAN}============================================================${NC}"

# Garantir caminhos padrão do Homebrew no PATH (macOS Apple Silicon e Intel)
for brew_bin in "/opt/homebrew/bin" "/usr/local/bin"; do
    if [ -d "$brew_bin" ] && [[ ":$PATH:" != *":$brew_bin:"* ]]; then
        export PATH="$brew_bin:$PATH"
    fi
done

# Checagem e instalação do Node.js caso não exista
if ! command -v node &> /dev/null; then
    echo -e "${YELLOW}⚠️  Node.js não detectado no PATH. Tentando instalar via Homebrew...${NC}"
    if [ -x "/opt/homebrew/bin/brew" ]; then
        /opt/homebrew/bin/brew install node
        export PATH="/opt/homebrew/bin:$PATH"
    elif command -v brew &> /dev/null; then
        brew install node
    fi
fi

# Portas dos serviços (podem ser customizadas diretamente aqui ou via variáveis de ambiente)
BACKEND_PORT=${BACKEND_PORT:-8000}
FRONTEND_ADMIN_PORT=${FRONTEND_ADMIN_PORT:-3001}
FRONTEND_EVALUATOR_PORT=${FRONTEND_EVALUATOR_PORT:-3002}
FRONTEND_KIOSK_PORT=${FRONTEND_KIOSK_PORT:-3003}

# Array para registrar os PIDs dos processos filhos
PIDS=()

# Encerramento gracioso ao receber SIGINT ou SIGTERM (Ctrl+C)
cleanup() {
    echo -e "\n${YELLOW}🛑 Recebido comando de encerramento (Ctrl+C). Encerrando os serviços graciosamente...${NC}"
    for pid in "${PIDS[@]}"; do
        if kill -0 "$pid" 2>/dev/null; then
            kill -TERM "$pid" 2>/dev/null || true
        fi
    done
    wait 2>/dev/null || true
    echo -e "${GREEN}✅ Todos os 4 blocos da FECITEL foram encerrados com sucesso.${NC}"
    exit 0
}

trap cleanup SIGINT SIGTERM EXIT

# 1. Iniciar Bloco 1: Backend API (FastAPI) na porta BACKEND_PORT
echo -e "\n${BLUE}⚙️  [Bloco 1] Iniciando Backend API (Porta ${BACKEND_PORT})...${NC}"
(
    cd "${ROOT_DIR}/apps/backend"
    if [ -f "run.sh" ]; then
        PORT="${BACKEND_PORT}" exec ./run.sh
    fi
) &
PIDS+=($!)

# 2. Iniciar Bloco 2: Frontend Admin (Next.js) na porta FRONTEND_ADMIN_PORT
echo -e "${GREEN}⚙️  [Bloco 2] Iniciando Frontend Admin (Porta ${FRONTEND_ADMIN_PORT})...${NC}"
(
    cd "${ROOT_DIR}/apps/frontend-admin"
    if [ ! -d "node_modules" ]; then
        echo "📥 [Admin] Instalando dependências npm..."
        npm install --quiet
    fi
    exec npm run dev -- -p "${FRONTEND_ADMIN_PORT}"
) &
PIDS+=($!)

# 3. Iniciar Bloco 3: Frontend Evaluator (Next.js PWA) na porta FRONTEND_EVALUATOR_PORT
echo -e "${YELLOW}⚙️  [Bloco 3] Iniciando Frontend Evaluator (Porta ${FRONTEND_EVALUATOR_PORT})...${NC}"
(
    cd "${ROOT_DIR}/apps/frontend-evaluator"
    if [ ! -d "node_modules" ]; then
        echo "📥 [Evaluator] Instalando dependências npm..."
        npm install --quiet
    fi
    exec npm run dev -- -p "${FRONTEND_EVALUATOR_PORT}"
) &
PIDS+=($!)

# 4. Iniciar Bloco 4: Frontend TV Kiosk (Next.js) na porta FRONTEND_KIOSK_PORT
echo -e "${MAGENTA}⚙️  [Bloco 4] Iniciando Frontend TV Kiosk (Porta ${FRONTEND_KIOSK_PORT})...${NC}"
(
    cd "${ROOT_DIR}/apps/frontend-kiosk"
    if [ ! -d "node_modules" ]; then
        echo "📥 [Kiosk] Instalando dependências npm..."
        npm install --quiet
    fi
    exec npm run dev -- -p "${FRONTEND_KIOSK_PORT}"
) &
PIDS+=($!)

sleep 2

echo -e "\n${CYAN}============================================================${NC}"
echo -e "${GREEN}🌐 Todos os serviços foram disparados concorrentemente:${NC}"
echo -e "  * ${BLUE}Backend API:${NC}          http://localhost:${BACKEND_PORT} (Swagger: /docs)"
echo -e "  * ${GREEN}Painel Admin:${NC}         http://localhost:${FRONTEND_ADMIN_PORT}"
echo -e "  * ${YELLOW}Avaliador Mobile:${NC}     http://localhost:${FRONTEND_EVALUATOR_PORT}"
echo -e "  * ${MAGENTA}Telão TV Kiosk:${NC}       http://localhost:${FRONTEND_KIOSK_PORT}/tv"
echo -e "${CYAN}============================================================${NC}"
echo -e "${YELLOW}ℹ️  Pressione Ctrl+C a qualquer momento para encerrar todos os serviços simultaneamente.${NC}\n"

# Aguardar finalização dos processos filhos
wait
