#!/usr/bin/env python3
"""
FECITEL — Script de Migração de Banco: event_participant_roles
=============================================================
Cria a tabela associativa event_participant_roles e migra os papéis
dos participantes já existentes no banco de dados.
"""

import asyncio
import logging
import sys
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
BACKEND_DIR = BASE_DIR / "apps" / "backend"
if str(BACKEND_DIR) not in sys.path:
    sys.path.insert(0, str(BACKEND_DIR))

from sqlalchemy import text
from app.core.database import AsyncSessionLocal

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("fecitel.migrate_roles")

STATEMENTS = [
    """
    CREATE TABLE IF NOT EXISTS event_participant_roles (
        id SERIAL PRIMARY KEY,
        person_id INTEGER NOT NULL REFERENCES people(id) ON DELETE CASCADE,
        event_id INTEGER NOT NULL REFERENCES events(id) ON DELETE CASCADE,
        role VARCHAR(50) NOT NULL,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
        deleted_at TIMESTAMP WITH TIME ZONE NULL,
        CONSTRAINT uq_event_participant_role UNIQUE (person_id, event_id, role)
    );
    """,
    "CREATE INDEX IF NOT EXISTS idx_epr_person_event ON event_participant_roles(person_id, event_id) WHERE deleted_at IS NULL;",
    "CREATE INDEX IF NOT EXISTS idx_epr_event_role ON event_participant_roles(event_id, role) WHERE deleted_at IS NULL;",
    """
    INSERT INTO event_participant_roles (person_id, event_id, role)
    SELECT ep.person_id, ep.event_id, p.role::text
    FROM event_participants ep
    JOIN people p ON ep.person_id = p.id
    WHERE ep.deleted_at IS NULL
    ON CONFLICT (person_id, event_id, role) DO NOTHING;
    """,
    """
    INSERT INTO event_participant_roles (person_id, event_id, role)
    SELECT DISTINCT pm.person_id, pr.event_id, 
           CASE 
               WHEN pm.role = 'ADVISOR' THEN 'ADVISOR'
               WHEN pm.role = 'COADVISOR' THEN 'COADVISOR'
               ELSE 'STUDENT'
           END
    FROM project_members pm
    JOIN projects pr ON pm.project_id = pr.id
    WHERE pm.deleted_at IS NULL AND pr.deleted_at IS NULL
    ON CONFLICT (person_id, event_id, role) DO NOTHING;
    """
]

async def main():
    logger.info("Iniciando criação da tabela event_participant_roles e migração de papéis...")
    async with AsyncSessionLocal() as session:
        for idx, sql in enumerate(STATEMENTS, 1):
            logger.info(f"Executando etapa {idx}/{len(STATEMENTS)}...")
            await session.execute(text(sql))
        await session.commit()
        
        count_res = await session.execute(
            text("SELECT count(*), count(distinct person_id), count(distinct event_id) FROM event_participant_roles;")
        )
        total_roles, distinct_people, distinct_events = count_res.fetchone()
        logger.info(
            f"✅ Migração concluída com sucesso!\n"
            f"   - Total de registros em event_participant_roles: {total_roles}\n"
            f"   - Pessoas únicas com papéis: {distinct_people}\n"
            f"   - Eventos com papéis vinculados: {distinct_events}"
        )

if __name__ == "__main__":
    asyncio.run(main())
