#!/usr/bin/env python3
"""
FECITEL — Script de Importação do Dataset Real de Projetos para PostgreSQL
========================================================================
Lê o arquivo CSV da FECITEL (ex: dataset-fecitel.csv) e popula o banco de dados:
  1. Criação/Verificação das Grandes Áreas Temáticas e Subáreas padrão no Evento.
  2. Cadastro unificado e deduplicação de Pessoas (Orientadores, Coorientadores e Alunos).
  3. Inscrição dos Trabalhos (título, modalidade/nível de ensino, qrcode_token = ID Trabalho).
  4. Vínculo dos Membros do Projeto (STUDENT_LEADER, STUDENT_MEMBER, ADVISOR, COADVISOR).
  5. Registro dos participantes na edição do evento (EventParticipant).

Uso:
  # Execução em modo de simulação (valida e não altera o banco):
  python modelo_dataset_projetos/import_dataset.py --event-id 1 --dry-run

  # Execução com commit real no banco:
  python modelo_dataset_projetos/import_dataset.py --event-id 1 --apply
"""

import argparse
import asyncio
import csv
import logging
import os
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

# Adiciona o diretório do backend ao sys.path para carregar os modelos da aplicação
BASE_DIR = Path(__file__).resolve().parent.parent
BACKEND_DIR = BASE_DIR / "apps" / "backend"
if str(BACKEND_DIR) not in sys.path:
    sys.path.insert(0, str(BACKEND_DIR))

from sqlalchemy import select, text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import AsyncSessionLocal, engine
from app.models.enums import EducationLevelEnum, ProjectMemberRole, ProjectStatus, ProjectType, UserRole
from app.models.event import Event
from app.models.knowledge_area import KnowledgeArea, Subarea
from app.models.person import EventParticipant, Person
from app.models.project import Project, ProjectMember

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S"
)
logger = logging.getLogger("fecitel.importer")


def map_modalidade_to_level(modalidade_str: str) -> EducationLevelEnum:
    """Mapeia o texto de modalidade do CSV para o enum EducationLevelEnum."""
    mod = modalidade_str.strip().lower()
    if "fundamental" in mod:
        return EducationLevelEnum.FUNDAMENTAL
    elif "médio" in mod or "medio" in mod:
        return EducationLevelEnum.MEDIO
    return EducationLevelEnum.MEDIO


def clean_str(val: Optional[str]) -> str:
    """Limpa e normaliza espaços em strings."""
    return val.strip() if val else ""


def generate_placeholder_email(project_id: str, member_type: str, index: int, name: str) -> str:
    """Gera um e-mail temporário padronizado para pessoas sem e-mail informado no CSV."""
    clean_name = "".join(c for c in name.lower() if c.isalnum())[:12]
    return f"placeholder.{clean_name}.p{project_id}.{member_type}{index}@fecitel.local"


async def check_custom_columns(session: AsyncSession) -> Dict[str, bool]:
    """Verifica se a tabela people já possui as colunas 'cpf' e 'affiliation'."""
    result = await session.execute(text("""
        SELECT column_name 
        FROM information_schema.columns 
        WHERE table_name = 'people' AND column_name IN ('cpf', 'affiliation');
    """))
    found = {row[0] for row in result.fetchall()}
    return {
        "has_cpf": "cpf" in found,
        "has_affiliation": "affiliation" in found
    }


async def get_or_create_knowledge_area_and_subarea(
    session: AsyncSession,
    event_id: int,
    area_name: str,
    dry_run: bool
) -> Tuple[KnowledgeArea, Subarea]:
    """Busca ou cria a Grande Área e sua Subárea padrão vinculada."""
    area_name_clean = area_name.strip()
    
    # 1. Buscar Grande Área existente para o evento
    stmt = select(KnowledgeArea).where(
        KnowledgeArea.event_id == event_id,
        KnowledgeArea.name == area_name_clean,
        KnowledgeArea.deleted_at.is_(None)
    )
    res = await session.execute(stmt)
    area = res.scalar_one_or_none()
    
    if not area:
        area = KnowledgeArea(event_id=event_id, name=area_name_clean)
        session.add(area)
        await session.flush()
        logger.info(f"  [ÁREA CRIADA] '{area_name_clean}' (ID: {area.id})")

    # 2. Buscar ou criar Subárea padrão (com o mesmo nome ou 'Geral')
    subarea_name = "Geral"
    stmt_sub = select(Subarea).where(
        Subarea.area_id == area.id,
        Subarea.deleted_at.is_(None)
    )
    res_sub = await session.execute(stmt_sub)
    subarea = res_sub.scalars().first()
    
    if not subarea:
        subarea = Subarea(area_id=area.id, name=subarea_name)
        session.add(subarea)
        await session.flush()
        logger.info(f"    [SUBÁREA CRIADA] '{subarea_name}' vinculada à área '{area_name_clean}' (ID: {subarea.id})")
        
    return area, subarea


async def get_or_create_person(
    session: AsyncSession,
    name: str,
    email: str,
    cpf: Optional[str],
    role: UserRole,
    affiliation: Optional[str],
    custom_cols: Dict[str, bool],
    people_cache: Dict[str, Person]
) -> Person:
    """Busca ou cria uma pessoa no banco, deduplicando por e-mail."""
    email_key = email.strip().lower()
    
    # Cache local durante a execução da importação
    if email_key in people_cache:
        person = people_cache[email_key]
        return person

    stmt = select(Person).where(Person.email.ilike(email_key))
    res = await session.execute(stmt)
    person = res.scalar_one_or_none()

    if not person:
        person = Person(
            name=name.strip(),
            email=email_key,
            role=role,
            cpf=cpf.strip() if (custom_cols["has_cpf"] and cpf) else None,
            affiliation=affiliation.strip() if (custom_cols["has_affiliation"] and affiliation) else None
        )
        session.add(person)
        await session.flush()
    else:
        # Se a pessoa já existia e não tinha CPF ou afiliação preenchidos, complementa
        if custom_cols["has_cpf"] and cpf:
            await session.execute(
                text("UPDATE people SET cpf = COALESCE(cpf, :cpf) WHERE id = :pid"),
                {"cpf": cpf.strip(), "pid": person.id}
            )
        if custom_cols["has_affiliation"] and affiliation:
            await session.execute(
                text("UPDATE people SET affiliation = COALESCE(affiliation, :aff) WHERE id = :pid"),
                {"aff": affiliation.strip(), "pid": person.id}
            )

    people_cache[email_key] = person
    return person


async def ensure_event_participant(
    session: AsyncSession,
    event_id: int,
    person_id: int,
    participants_cache: set
) -> None:
    """Garante que a pessoa esteja registrada como participante da edição do evento."""
    key = (event_id, person_id)
    if key in participants_cache:
        return

    stmt = select(EventParticipant).where(
        EventParticipant.event_id == event_id,
        EventParticipant.person_id == person_id
    )
    res = await session.execute(stmt)
    part = res.scalar_one_or_none()
    if not part:
        part = EventParticipant(
            event_id=event_id,
            person_id=person_id,
            tshirt_size="M",
            kit_delivered=False,
            presence_confirmed=False
        )
        session.add(part)
        await session.flush()

    participants_cache.add(key)


async def run_import(csv_path: Path, event_id: int, dry_run: bool) -> None:
    """Executa a importação completa do arquivo CSV."""
    if not csv_path.exists():
        logger.error(f"Arquivo CSV não encontrado em: {csv_path}")
        sys.exit(1)

    with open(csv_path, mode="r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        all_rows = list(reader)

    # Filtrar apenas linhas com ID Trabalho numérico válido
    valid_rows = [r for r in all_rows if clean_str(r.get("ID Trabalho")).isdigit()]
    logger.info("============================================================")
    logger.info(f"📊 FECITEL DATASET IMPORTER — Arquivo: {csv_path.name}")
    logger.info(f"📌 Total de linhas no arquivo: {len(all_rows)}")
    logger.info(f"✅ Total de projetos válidos para importação: {len(valid_rows)}")
    logger.info(f"🎯 ID do Evento Alvo: {event_id}")
    logger.info(f"⚙️ Modo de execução: {'🔍 SIMULAÇÃO (DRY-RUN - sem alterações)' if dry_run else '🚀 APLICAÇÃO REAL (COMMIT)'}")
    logger.info("============================================================")

    async with AsyncSessionLocal() as session:
        # 1. Verificar se o evento existe
        event = await session.get(Event, event_id)
        if not event:
            logger.error(f"❌ Evento com ID {event_id} não encontrado no banco de dados!")
            sys.exit(1)
        logger.info(f"📅 Evento selecionado: '{event.name}' (Ano: {event.year}, Status: {event.status.value})")

        # 2. Verificar colunas customizadas em 'people'
        custom_cols = await check_custom_columns(session)
        if not custom_cols["has_cpf"]:
            logger.warning("⚠️  A tabela 'people' não possui coluna 'cpf'. Os CPFs do CSV não serão gravados até que a coluna seja adicionada.")
        if not custom_cols["has_affiliation"]:
            logger.warning("⚠️  A tabela 'people' não possui coluna 'affiliation'. O perfil dos alunos (interno/externo) não será gravado até que a coluna seja adicionada.")

        # Caches para acelerar importação e evitar queries repetidas
        people_cache: Dict[str, Person] = {}
        participants_cache: set = set()
        areas_subareas_cache: Dict[str, Tuple[KnowledgeArea, Subarea]] = {}

        created_projects_count = 0
        skipped_projects_count = 0
        created_members_count = 0

        for row_idx, row in enumerate(valid_rows, start=1):
            raw_id = clean_str(row.get("ID Trabalho"))
            title = clean_str(row.get("Título"))
            modalidade = clean_str(row.get("Modalidade"))
            area_tematica = clean_str(row.get("Área Temática"))

            if not title:
                logger.warning(f"Linha {row_idx} ignorada por não possuir título.")
                continue

            education_level = map_modalidade_to_level(modalidade)
            qrcode_token = raw_id  # Conforme regra do usuário: ID Trabalho é o valor do QRCode

            # 3. Área e Subárea
            if area_tematica not in areas_subareas_cache:
                area_obj, subarea_obj = await get_or_create_knowledge_area_and_subarea(
                    session, event_id, area_tematica, dry_run
                )
                areas_subareas_cache[area_tematica] = (area_obj, subarea_obj)
            else:
                area_obj, subarea_obj = areas_subareas_cache[area_tematica]

            # 4. Verificar se o projeto já existe
            stmt_proj = select(Project).where(
                Project.event_id == event_id,
                Project.qrcode_token == qrcode_token,
                Project.deleted_at.is_(None)
            )
            res_proj = await session.execute(stmt_proj)
            existing_proj = res_proj.scalar_one_or_none()

            if existing_proj:
                logger.info(f"  [PROJETO EXISTENTE] ID Trabalho {raw_id}: '{title[:45]}...' já cadastrado (ID DB: {existing_proj.id}). Ignorando duplicação.")
                skipped_projects_count += 1
                continue

            # 5. Criar o Projeto
            project = Project(
                event_id=event_id,
                subarea_id=subarea_obj.id,
                title=title[:255],
                project_type=ProjectType.SCIENTIFIC,
                education_level=education_level,
                abstract=None,
                qrcode_token=qrcode_token,
                status=ProjectStatus.HOMOLOGATED,  # Importados diretamente como homologados para a feira
                advisor_consent=True,
                advisor_consent_at=datetime.now(timezone.utc)
            )
            session.add(project)
            await session.flush()
            created_projects_count += 1

            # 6. Processar Integrantes do Projeto
            # 6.1. Orientador (Obrigatório)
            orientador_nome = clean_str(row.get("orientador"))
            orientador_email = clean_str(row.get("email_orientador"))
            orientador_cpf = clean_str(row.get("cpf_orientador"))

            if orientador_nome:
                if not orientador_email:
                    orientador_email = generate_placeholder_email(raw_id, "orientador", 0, orientador_nome)
                
                orientador_person = await get_or_create_person(
                    session=session,
                    name=orientador_nome,
                    email=orientador_email,
                    cpf=orientador_cpf,
                    role=UserRole.ADVISOR,
                    affiliation=None,
                    custom_cols=custom_cols,
                    people_cache=people_cache
                )
                await ensure_event_participant(session, event_id, orientador_person.id, participants_cache)

                session.add(ProjectMember(
                    project_id=project.id,
                    person_id=orientador_person.id,
                    role=ProjectMemberRole.ADVISOR
                ))
                created_members_count += 1

            # 6.2. Coorientador (Opcional)
            coorientador_nome = clean_str(row.get("coorientador"))
            coorientador_email = clean_str(row.get("email_coorientador"))
            coorientador_cpf = clean_str(row.get("cpf_coorientador"))

            if coorientador_nome:
                if not coorientador_email:
                    coorientador_email = generate_placeholder_email(raw_id, "coorientador", 0, coorientador_nome)

                coorientador_person = await get_or_create_person(
                    session=session,
                    name=coorientador_nome,
                    email=coorientador_email,
                    cpf=coorientador_cpf,
                    role=UserRole.COADVISOR,
                    affiliation=None,
                    custom_cols=custom_cols,
                    people_cache=people_cache
                )
                await ensure_event_participant(session, event_id, coorientador_person.id, participants_cache)

                session.add(ProjectMember(
                    project_id=project.id,
                    person_id=coorientador_person.id,
                    role=ProjectMemberRole.COADVISOR
                ))
                created_members_count += 1

            # 6.3. Alunos (1 a 5)
            for aluno_idx in range(1, 6):
                field_prefix = f"aluno{aluno_idx}"
                name_key = field_prefix if aluno_idx == 1 else f"{field_prefix}_nome"
                aluno_nome = clean_str(row.get(name_key))
                if not aluno_nome:
                    continue

                aluno_cpf = clean_str(row.get(f"{field_prefix}_cpf"))
                aluno_email = clean_str(row.get(f"{field_prefix}_email"))
                aluno_perfil = clean_str(row.get(f"{field_prefix}_perfil"))

                if not aluno_email:
                    aluno_email = generate_placeholder_email(raw_id, "aluno", aluno_idx, aluno_nome)

                aluno_role = ProjectMemberRole.STUDENT_LEADER if aluno_idx == 1 else ProjectMemberRole.STUDENT_MEMBER

                aluno_person = await get_or_create_person(
                    session=session,
                    name=aluno_nome,
                    email=aluno_email,
                    cpf=aluno_cpf,
                    role=UserRole.STUDENT,
                    affiliation=aluno_perfil,
                    custom_cols=custom_cols,
                    people_cache=people_cache
                )
                await ensure_event_participant(session, event_id, aluno_person.id, participants_cache)

                session.add(ProjectMember(
                    project_id=project.id,
                    person_id=aluno_person.id,
                    role=aluno_role
                ))
                created_members_count += 1

        # Finalização da Transação
        if dry_run:
            await session.rollback()
            logger.info("============================================================")
            logger.info("🔍 SIMULAÇÃO CONCLUÍDA COM SUCESSO (ROLLBACK EXECUTADO)!")
            logger.info(f"   • Projetos válidos analisados: {len(valid_rows)}")
            logger.info(f"   • Novos projetos a serem inseridos: {created_projects_count}")
            logger.info(f"   • Projetos já existentes (ignorados): {skipped_projects_count}")
            logger.info(f"   • Pessoas únicas mapeadas: {len(people_cache)}")
            logger.info(f"   • Vínculos de integrantes gerados: {created_members_count}")
            logger.info(f"   • Participações no evento geradas: {len(participants_cache)}")
            logger.info("ℹ️  Nenhuma alteração foi persistida no banco de dados.")
            logger.info("============================================================")
        else:
            await session.commit()
            logger.info("============================================================")
            logger.info("🚀 IMPORTAÇÃO REAL CONCLUÍDA E PERSISTIDA COM SUCESSO!")
            logger.info(f"   • Novos projetos inseridos: {created_projects_count}")
            logger.info(f"   • Projetos ignorados (já existiam): {skipped_projects_count}")
            logger.info(f"   • Pessoas cadastradas/reutilizadas: {len(people_cache)}")
            logger.info(f"   • Integrantes vinculados: {created_members_count}")
            logger.info(f"   • Participantes do evento: {len(participants_cache)}")
            logger.info("============================================================")


def main():
    parser = argparse.ArgumentParser(description="Importador de Projetos FECITEL via CSV para PostgreSQL")
    parser.add_argument(
        "--csv",
        type=str,
        default=str(BASE_DIR / "modelo_dataset_projetos" / "dataset-fecitel.csv"),
        help="Caminho para o arquivo CSV de projetos"
    )
    parser.add_argument(
        "--event-id",
        type=int,
        default=1,
        help="ID do evento para vincular os projetos (padrão: 1)"
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Executa validação completa em modo de simulação (rollback ao final)"
    )
    parser.add_argument(
        "--apply",
        action="store_true",
        help="Executa a importação real gravando as alterações no PostgreSQL"
    )

    args = parser.parse_args()

    if not args.dry_run and not args.apply:
        print("⚠️  Atenção: Você deve especificar --dry-run (para simular) ou --apply (para persistir no banco).")
        print("Exemplo de teste: python modelo_dataset_projetos/import_dataset.py --event-id 1 --dry-run")
        sys.exit(1)

    dry_run = args.dry_run and not args.apply
    asyncio.run(run_import(Path(args.csv), args.event_id, dry_run))


if __name__ == "__main__":
    main()
