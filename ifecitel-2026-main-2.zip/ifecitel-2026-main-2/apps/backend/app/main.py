"""EasyEvent API Central — FastAPI Main Application Entrypoint."""

from contextlib import asynccontextmanager
import logging
from fastapi import FastAPI, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.api.v1.router import api_router
from sqlalchemy import text
from app.core.config import settings
from app.core.database import Base, engine

# Configuração de logging estruturado
logging.basicConfig(
    level=logging.INFO if not settings.DEBUG else logging.DEBUG,
    format="%(asctime)s - %(levelname)s - %(name)s - %(message)s"
)
logger = logging.getLogger("easyevent.backend")


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Gerenciamento de ciclo de vida do FastAPI (inicialização e encerramento)."""
    logger.info("🚀 Inicializando aplicação EasyEvent Backend...")
    try:
        # Criação inicial automática das tabelas no PostgreSQL (garante idempotência em dev/testes)
        async with engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
            await conn.execute(text("""
                ALTER TABLE event_participants 
                ADD COLUMN IF NOT EXISTS evaluator_presence_confirmed BOOLEAN NOT NULL DEFAULT FALSE,
                ADD COLUMN IF NOT EXISTS evaluator_presence_confirmed_at TIMESTAMP WITH TIME ZONE;
            """))
            await conn.execute(text("""
                ALTER TABLE projects 
                ADD COLUMN IF NOT EXISTS needs_electricity BOOLEAN NOT NULL DEFAULT FALSE,
                ADD COLUMN IF NOT EXISTS needs_table BOOLEAN NOT NULL DEFAULT FALSE;
            """))
            await conn.execute(text("ALTER TABLE events ADD COLUMN IF NOT EXISTS owner_id INTEGER REFERENCES people(id) ON DELETE SET NULL;"))
            await conn.execute(text("CREATE INDEX IF NOT EXISTS ix_events_owner_id ON events(owner_id);"))
            await conn.execute(text("""
                UPDATE events 
                SET owner_id = 411 
                WHERE owner_id IS NULL AND EXISTS (SELECT 1 FROM people WHERE id = 411);
            """))
            await conn.execute(text("""
                INSERT INTO event_administrators (event_id, person_id, role, created_at, updated_at)
                SELECT e.id, e.owner_id, 'COORDINATOR', NOW(), NOW()
                FROM events e
                WHERE e.owner_id IS NOT NULL
                  AND NOT EXISTS (
                      SELECT 1 FROM event_administrators ea 
                      WHERE ea.event_id = e.id AND ea.person_id = e.owner_id
                  );
            """))
            await conn.execute(text("""
                CREATE TABLE IF NOT EXISTS registration_verifications (
                    id SERIAL PRIMARY KEY,
                    email VARCHAR(100) NOT NULL,
                    code_hash VARCHAR(255) NOT NULL,
                    attempts INTEGER NOT NULL DEFAULT 0,
                    verified BOOLEAN NOT NULL DEFAULT FALSE,
                    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
                    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
                    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
                    deleted_at TIMESTAMP WITH TIME ZONE DEFAULT NULL
                );
            """))
            await conn.execute(text("""
                CREATE INDEX IF NOT EXISTS ix_registration_verifications_email ON registration_verifications(email);
            """))
        logger.info("✅ Tabelas e esquemas verificados com sucesso no PostgreSQL.")
    except Exception as e:
        logger.error(f"❌ Falha ao conectar ou sincronizar tabelas no PostgreSQL: {e}")
        # Não trava se em ambiente de testes isolados, mas loga criticamente
    yield
    logger.info("🛑 Encerrando conexões com o PostgreSQL...")
    await engine.dispose()
    logger.info("✅ Conexões finalizadas graciosamente.")


app = FastAPI(
    title=settings.PROJECT_NAME,
    version=settings.VERSION,
    description=(
        "API Central do **EasyEvent (Sistema de Gestão e Avaliação de Feiras e Eventos)**. "
        "Desenvolvida em arquitetura assíncrona bare-metal de alto desempenho com PostgreSQL 15+."
    ),
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc"
)

# Configuração de CORS para permitir requisições dos 3 frontends locais
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get(
    "/health",
    status_code=status.HTTP_200_OK,
    tags=["Diagnóstico"],
    summary="Verificação de integridade da API"
)
async def health_check():
    """Endpoint de monitoramento de saúde do backend."""
    return JSONResponse(
        status_code=status.HTTP_200_OK,
        content={
            "status": "online",
            "service": settings.PROJECT_NAME,
            "version": settings.VERSION,
            "environment": settings.ENVIRONMENT
        }
    )


import os
from fastapi.staticfiles import StaticFiles

# Montagem de arquivos estáticos de uploads locais (logos, banners, relatórios)
os.makedirs(settings.UPLOAD_DIR, exist_ok=True)
os.makedirs(os.path.join(settings.UPLOAD_DIR, "logos"), exist_ok=True)
app.mount("/static/uploads", StaticFiles(directory=settings.UPLOAD_DIR), name="uploads")

# Inclusão do roteador de endpoints versão 1
app.include_router(api_router, prefix="/api/v1")
