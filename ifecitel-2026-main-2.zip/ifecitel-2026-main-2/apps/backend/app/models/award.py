"""Awards and award-to-criteria mapping models (Regra BR-17)."""

from typing import List, Optional
from sqlalchemy import ForeignKey, Numeric, String, Text, and_
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import BaseModel


class Award(BaseModel):
    """Premiações especiais, troféus de patrocinadores ou menções honrosas da feira."""

    __tablename__ = "awards"

    event_id: Mapped[int] = mapped_column(ForeignKey("events.id"), nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    sponsor: Mapped[Optional[str]] = mapped_column(String(200), nullable=True)

    # Relacionamentos
    event: Mapped["Event"] = relationship(back_populates="awards")
    criteria_links: Mapped[List["AwardCriterion"]] = relationship(
        back_populates="award",
        primaryjoin="and_(Award.id == AwardCriterion.award_id, AwardCriterion.deleted_at.is_(None))",
        cascade="all, delete-orphan",
        lazy="selectin"
    )


class AwardCriterion(BaseModel):
    """Vínculo associativo entre uma premiação e perguntas/critérios da ficha de avaliação."""

    __tablename__ = "award_criteria"

    award_id: Mapped[int] = mapped_column(ForeignKey("awards.id"), nullable=False, index=True)
    criterion_id: Mapped[int] = mapped_column(ForeignKey("evaluation_criteria.id"), nullable=False, index=True)
    weight: Mapped[float] = mapped_column(Numeric(4, 2), default=1.0, nullable=False)

    # Relacionamentos
    award: Mapped["Award"] = relationship(back_populates="criteria_links")
    criterion: Mapped["EvaluationCriterion"] = relationship(back_populates="award_links", lazy="joined")

    @property
    def criterion_name(self) -> Optional[str]:
        return self.criterion.name if self.criterion else None
