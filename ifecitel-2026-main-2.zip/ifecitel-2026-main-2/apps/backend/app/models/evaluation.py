from datetime import datetime, timezone
from typing import List, Optional
from sqlalchemy import DateTime, Enum, ForeignKey, Numeric, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import BaseModel
from app.models.enums import AllocationStatus, AllocationType, EvaluationStatus


class EvaluationCriterion(BaseModel):
    """Critério dinâmico da ficha de avaliação (científico e tecnológico)."""

    __tablename__ = "evaluation_criteria"

    event_id: Mapped[int] = mapped_column(ForeignKey("events.id"), nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    scientific_description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    technological_description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    max_score: Mapped[float] = mapped_column(Numeric(4, 2), default=10.0, nullable=False)
    weight: Mapped[float] = mapped_column(Numeric(4, 2), default=1.0, nullable=False)

    # Relacionamentos
    award_links: Mapped[List["AwardCriterion"]] = relationship(back_populates="criterion")
    items: Mapped[List["EvaluationItem"]] = relationship(back_populates="criterion")


class EvaluatorAllocation(BaseModel):
    """Alocação de trabalho para avaliador (Momento 1 automático ou Momento 2 manual) (Regra BR-10)."""

    __tablename__ = "evaluator_allocations"

    event_id: Mapped[int] = mapped_column(ForeignKey("events.id"), nullable=False, index=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id"), nullable=False, index=True)
    evaluator_id: Mapped[int] = mapped_column(ForeignKey("people.id"), nullable=False, index=True)

    allocation_type: Mapped[AllocationType] = mapped_column(
        Enum(AllocationType, native_enum=False),
        default=AllocationType.AUTOMATIC_CHECKIN,
        nullable=False
    )
    status: Mapped[AllocationStatus] = mapped_column(
        Enum(AllocationStatus, native_enum=False),
        default=AllocationStatus.PENDING,
        nullable=False
    )
    allocated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        nullable=False
    )

    # Relacionamentos
    event: Mapped["Event"] = relationship()
    project: Mapped["Project"] = relationship()
    evaluator: Mapped["Person"] = relationship()
    evaluation: Mapped[Optional["Evaluation"]] = relationship(back_populates="allocation", uselist=False)

    __table_args__ = (
        UniqueConstraint("project_id", "evaluator_id", name="uq_evaluator_allocations_project_evaluator"),
    )


class Evaluation(BaseModel):
    """Avaliação mestre de um projeto por um avaliador com parecer consolidado único (BR-11)."""

    __tablename__ = "evaluations"

    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id"), nullable=False, index=True)
    evaluator_id: Mapped[int] = mapped_column(ForeignKey("people.id"), nullable=False, index=True)
    allocation_id: Mapped[Optional[int]] = mapped_column(ForeignKey("evaluator_allocations.id"), nullable=True, index=True)
    
    status: Mapped[EvaluationStatus] = mapped_column(
        Enum(EvaluationStatus, native_enum=False),
        default=EvaluationStatus.DRAFT,
        nullable=False
    )
    
    # Parecer geral consolidado único (BR-11)
    general_feedback: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    evaluated_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)

    # Relacionamentos
    project: Mapped["Project"] = relationship(back_populates="evaluations")
    evaluator: Mapped["Person"] = relationship(back_populates="evaluations")
    allocation: Mapped[Optional["EvaluatorAllocation"]] = relationship(back_populates="evaluation")
    items: Mapped[List["EvaluationItem"]] = relationship(
        back_populates="evaluation",
        cascade="all, delete-orphan",
        lazy="selectin"
    )


class EvaluationItem(BaseModel):
    """Nota numérica atribuída a cada critério específico da ficha de avaliação."""

    __tablename__ = "evaluation_items"

    evaluation_id: Mapped[int] = mapped_column(ForeignKey("evaluations.id"), nullable=False, index=True)
    criterion_id: Mapped[int] = mapped_column(ForeignKey("evaluation_criteria.id"), nullable=False, index=True)
    score: Mapped[float] = mapped_column(Numeric(4, 2), nullable=False)

    # Relacionamentos
    evaluation: Mapped["Evaluation"] = relationship(back_populates="items")
    criterion: Mapped["EvaluationCriterion"] = relationship(back_populates="items", lazy="selectin")
