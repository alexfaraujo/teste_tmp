"""Person, roles and event participation models."""

from datetime import datetime
from typing import List, Optional
from sqlalchemy import Boolean, DateTime, Enum, ForeignKey, String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import BaseModel
from app.models.enums import UserRole, EducationLevelEnum


class Person(BaseModel):
    """Pessoa cadastrada no sistema (Administrador, Estudante, Orientador ou Avaliador)."""

    __tablename__ = "people"

    name: Mapped[str] = mapped_column(String(255), nullable=False)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True, nullable=False)
    cpf: Mapped[Optional[str]] = mapped_column(String(20), nullable=True, index=True)
    affiliation: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    
    # Credenciais de acesso: senha mestre para ADMIN; hash de OTP para demais perfis (SEC-01)
    password_hash: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    access_code_hash: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    
    # Código de barras pessoal para check-in e crachá individual (BR-08)
    barcode: Mapped[Optional[str]] = mapped_column(String(64), unique=True, nullable=True, index=True)
    
    # Papel principal ativo
    role: Mapped[UserRole] = mapped_column(
        Enum(UserRole, native_enum=False),
        default=UserRole.STUDENT,
        nullable=False
    )

    # Relacionamentos
    event_participations: Mapped[List["EventParticipant"]] = relationship(back_populates="person")
    event_roles: Mapped[List["EventParticipantRole"]] = relationship(back_populates="person", cascade="all, delete-orphan")
    project_memberships: Mapped[List["ProjectMember"]] = relationship(back_populates="person")
    evaluations: Mapped[List["Evaluation"]] = relationship(back_populates="evaluator")
    subarea_qualifications: Mapped[List["PersonSubarea"]] = relationship(back_populates="person", cascade="all, delete-orphan")
    education_level_qualifications: Mapped[List["PersonEducationLevel"]] = relationship(back_populates="person", cascade="all, delete-orphan")



class EventParticipant(BaseModel):
    """Participação de uma pessoa em uma edição específica da feira e logística de kit (BR-09)."""

    __tablename__ = "event_participants"

    event_id: Mapped[int] = mapped_column(ForeignKey("events.id"), nullable=False, index=True)
    person_id: Mapped[int] = mapped_column(ForeignKey("people.id"), nullable=False, index=True)
    tshirt_size: Mapped[str] = mapped_column(String(10), default="M", nullable=False)
    
    # Baixa de kits com lock atômico (BR-09)
    kit_delivered: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    kit_delivered_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    
    # Confirmação de presença geral no evento (Portaria / Credenciamento Geral)
    presence_confirmed: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    presence_confirmed_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)

    # Confirmação de presença específica na Sala dos Avaliadores (Comissão Científica)
    evaluator_presence_confirmed: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    evaluator_presence_confirmed_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)

    # Relacionamento
    person: Mapped["Person"] = relationship(back_populates="event_participations")


class PersonSubarea(BaseModel):
    """Vinculação de avaliador às suas subáreas de conhecimento (Regra BR-10)."""

    __tablename__ = "person_subareas"

    person_id: Mapped[int] = mapped_column(ForeignKey("people.id"), nullable=False, index=True)
    subarea_id: Mapped[int] = mapped_column(ForeignKey("subareas.id"), nullable=False, index=True)
    event_id: Mapped[int] = mapped_column(ForeignKey("events.id"), nullable=False, index=True)

    # Relacionamentos
    person: Mapped["Person"] = relationship(back_populates="subarea_qualifications")
    subarea: Mapped["Subarea"] = relationship()
    event: Mapped["Event"] = relationship()

    __table_args__ = (
        UniqueConstraint("person_id", "subarea_id", "event_id", name="uq_person_subareas_person_subarea_event"),
    )


class EventParticipantRole(BaseModel):
    """Papel atribuído a um participante em uma edição específica do evento (Opção 1)."""

    __tablename__ = "event_participant_roles"

    person_id: Mapped[int] = mapped_column(ForeignKey("people.id", ondelete="CASCADE"), nullable=False, index=True)
    event_id: Mapped[int] = mapped_column(ForeignKey("events.id", ondelete="CASCADE"), nullable=False, index=True)
    role: Mapped[UserRole] = mapped_column(
        Enum(UserRole, native_enum=False),
        nullable=False
    )

    # Relacionamentos
    person: Mapped["Person"] = relationship(back_populates="event_roles")
    event: Mapped["Event"] = relationship()

    __table_args__ = (
        UniqueConstraint("person_id", "event_id", "role", name="uq_event_participant_role"),
    )


class PersonEducationLevel(BaseModel):
    """Vinculação de avaliador aos níveis de ensino que está habilitado a avaliar na edição."""

    __tablename__ = "person_education_levels"

    person_id: Mapped[int] = mapped_column(ForeignKey("people.id", ondelete="CASCADE"), nullable=False, index=True)
    event_id: Mapped[int] = mapped_column(ForeignKey("events.id", ondelete="CASCADE"), nullable=False, index=True)
    education_level: Mapped[EducationLevelEnum] = mapped_column(
        Enum(EducationLevelEnum, native_enum=False),
        nullable=False
    )

    # Relacionamentos
    person: Mapped["Person"] = relationship(back_populates="education_level_qualifications")
    event: Mapped["Event"] = relationship()

    __table_args__ = (
        UniqueConstraint("person_id", "event_id", "education_level", name="uq_person_education_levels_person_event_level"),
    )


