"""Enumerations for the FECITEL domain."""

import enum


class UserRole(str, enum.Enum):
    """Papéis de usuários no sistema."""
    ADMIN = "ADMIN"
    STUDENT = "STUDENT"
    ADVISOR = "ADVISOR"
    COADVISOR = "COADVISOR"
    EVALUATOR = "EVALUATOR"


class EventStatus(str, enum.Enum):
    """Status da edição do evento."""
    DRAFT = "DRAFT"
    OPEN = "OPEN"
    IN_PROGRESS = "IN_PROGRESS"
    CLOSED = "CLOSED"


class EducationLevelEnum(str, enum.Enum):
    """Níveis de ensino atendidos."""
    MEDIO = "MEDIO"
    FUNDAMENTAL = "FUNDAMENTAL"
    JUNIOR = "JUNIOR"
    GRADUACAO = "GRADUACAO"
    POS_GRADUACAO = "POS_GRADUACAO"


class ProjectType(str, enum.Enum):
    """Tipo do projeto científico ou tecnológico."""
    SCIENTIFIC = "SCIENTIFIC"
    TECHNOLOGICAL = "TECHNOLOGICAL"


class ProjectStatus(str, enum.Enum):
    """Máquina de estados estrita do ciclo de vida do projeto (Regra BR-06)."""
    DRAFT = "DRAFT"
    SUBMITTED = "SUBMITTED"
    WAITING_CONSENT = "WAITING_CONSENT"
    HOMOLOGATED = "HOMOLOGATED"
    REJECTED = "REJECTED"
    PRESENT = "PRESENT"
    ABSENT = "ABSENT"
    UNDER_EVALUATION = "UNDER_EVALUATION"
    EVALUATED = "EVALUATED"


class ProjectMemberRole(str, enum.Enum):
    """Papel do integrante na equipe do projeto."""
    STUDENT_LEADER = "STUDENT_LEADER"
    STUDENT_MEMBER = "STUDENT_MEMBER"
    ADVISOR = "ADVISOR"
    COADVISOR = "COADVISOR"


class AllocationType(str, enum.Enum):
    """Momento da alocação do avaliador (Regra BR-10)."""
    AUTOMATIC_CHECKIN = "AUTOMATIC_CHECKIN"
    MANUAL_ADMIN = "MANUAL_ADMIN"


class AllocationStatus(str, enum.Enum):
    """Status da atribuição do avaliador."""
    PENDING = "PENDING"
    COMPLETED = "COMPLETED"
    CANCELLED = "CANCELLED"


class EvaluationStatus(str, enum.Enum):
    """Status da avaliação."""
    DRAFT = "DRAFT"
    COMPLETED = "COMPLETED"


class EventAdminRole(str, enum.Enum):
    """Níveis de governança administrativa por evento (Regra BR-23)."""
    COORDINATOR = "COORDINATOR"  # Coordenador Geral / Dono (Posse total, regras, equipe, exclusão)
    ORGANIZER = "ORGANIZER"      # Comissão Organizadora (Projetos, áreas, notas, alocação, apuração)
    OPERATOR = "OPERATOR"        # Apoio / Recepção (Credenciamento, Check-in, leitura da visão geral)

