"""Knowledge areas and subareas models (Regra BR-16)."""

from typing import List
from sqlalchemy import ForeignKey, String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import BaseModel


class KnowledgeArea(BaseModel):
    """Grande área do conhecimento científico/tecnológico vinculada ao evento."""

    __tablename__ = "knowledge_areas"

    event_id: Mapped[int] = mapped_column(ForeignKey("events.id"), nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(150), nullable=False)

    # Relacionamentos
    event: Mapped["Event"] = relationship(back_populates="knowledge_areas")
    subareas: Mapped[List["Subarea"]] = relationship(
        back_populates="knowledge_area",
        cascade="all, delete-orphan",
        lazy="selectin"
    )

    __table_args__ = (
        UniqueConstraint("event_id", "name", name="uq_knowledge_areas_event_name"),
    )


class Subarea(BaseModel):
    """Subárea científica vinculada a uma grande área mãe."""

    __tablename__ = "subareas"

    area_id: Mapped[int] = mapped_column(ForeignKey("knowledge_areas.id"), nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(150), nullable=False)

    # Relacionamentos
    knowledge_area: Mapped["KnowledgeArea"] = relationship(back_populates="subareas", lazy="selectin")
    projects: Mapped[List["Project"]] = relationship(back_populates="subarea")

    __table_args__ = (
        UniqueConstraint("area_id", "name", name="uq_subareas_area_name"),
    )

    @property
    def area_name(self) -> str:
        return self.knowledge_area.name if self.knowledge_area else ""
