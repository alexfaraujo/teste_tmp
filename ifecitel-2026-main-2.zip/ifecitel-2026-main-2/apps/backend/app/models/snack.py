"""Snack moments and snack delivery models (Rule BR-30)."""

from datetime import date as dt_date, datetime
from typing import List, Optional
from sqlalchemy import Boolean, Date, DateTime, ForeignKey, Integer, String, Text, UniqueConstraint, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import BaseModel


class SnackMoment(BaseModel):
    """Momento de fornecimento de lanche/coffee break em uma edição do evento (BR-30)."""

    __tablename__ = "snack_moments"

    event_id: Mapped[int] = mapped_column(ForeignKey("events.id", ondelete="CASCADE"), nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    date: Mapped[dt_date] = mapped_column(Date, nullable=False)
    start_time: Mapped[Optional[str]] = mapped_column(String(10), nullable=True)
    end_time: Mapped[Optional[str]] = mapped_column(String(10), nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    target_roles: Mapped[Optional[str]] = mapped_column(String(255), nullable=True, default="ALL")
    total_budgeted: Mapped[Optional[int]] = mapped_column(Integer, nullable=True, default=0)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # Relacionamentos
    event: Mapped["Event"] = relationship()
    deliveries: Mapped[List["SnackDelivery"]] = relationship(
        back_populates="snack_moment",
        cascade="all, delete-orphan"
    )

    __table_args__ = (
        UniqueConstraint("event_id", "name", name="uq_snack_moments_event_name"),
    )


class SnackDelivery(BaseModel):
    """Registro individual de entrega de lanche a participante com restrição estrita de unicidade (BR-30)."""

    __tablename__ = "snack_deliveries"

    snack_moment_id: Mapped[int] = mapped_column(ForeignKey("snack_moments.id", ondelete="CASCADE"), nullable=False, index=True)
    participant_id: Mapped[int] = mapped_column(ForeignKey("event_participants.id", ondelete="CASCADE"), nullable=False, index=True)
    delivered_by_user_id: Mapped[Optional[int]] = mapped_column(ForeignKey("people.id", ondelete="SET NULL"), nullable=True)
    delivered_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    notes: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)

    # Relacionamentos
    snack_moment: Mapped["SnackMoment"] = relationship(back_populates="deliveries")
    participant: Mapped["EventParticipant"] = relationship()
    delivered_by: Mapped[Optional["Person"]] = relationship()

    __table_args__ = (
        UniqueConstraint("snack_moment_id", "participant_id", name="uq_snack_deliveries_moment_participant"),
    )
