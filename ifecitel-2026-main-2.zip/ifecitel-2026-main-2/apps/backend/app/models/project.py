"""Project and project members models."""

from datetime import datetime
from typing import List, Optional
from sqlalchemy import Boolean, DateTime, Enum, ForeignKey, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import BaseModel
from app.models.enums import EducationLevelEnum, ProjectMemberRole, ProjectStatus, ProjectType


class Project(BaseModel):
    """Trabalho científico ou tecnológico inscrito na feira (Regras BR-04 a BR-08)."""

    __tablename__ = "projects"

    event_id: Mapped[int] = mapped_column(ForeignKey("events.id"), nullable=False, index=True)
    subarea_id: Mapped[int] = mapped_column(ForeignKey("subareas.id"), nullable=False, index=True)
    
    title: Mapped[str] = mapped_column(String(255), nullable=False)
    project_type: Mapped[ProjectType] = mapped_column(
        Enum(ProjectType, native_enum=False),
        default=ProjectType.SCIENTIFIC,
        nullable=False
    )
    education_level: Mapped[EducationLevelEnum] = mapped_column(
        Enum(EducationLevelEnum, native_enum=False),
        default=EducationLevelEnum.MEDIO,
        nullable=False,
        index=True
    )
    abstract: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    booth_number: Mapped[Optional[str]] = mapped_column(String(32), nullable=True, index=True)
    rejection_reason: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # Infraestrutura para apresentação / estande
    needs_electricity: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    needs_table: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)

    
    # Arquivos submetidos
    summary_file_url: Mapped[Optional[str]] = mapped_column(String(512), nullable=True)
    banner_file_url: Mapped[Optional[str]] = mapped_column(String(512), nullable=True)
    logbook_file_url: Mapped[Optional[str]] = mapped_column(String(512), nullable=True)
    
    # Token do QR Code de bancada para leitura com câmera de smartphone (BR-08)
    qrcode_token: Mapped[str] = mapped_column(String(64), unique=True, index=True, nullable=False)
    
    # Máquina de estados (BR-06)
    status: Mapped[ProjectStatus] = mapped_column(
        Enum(ProjectStatus, native_enum=False),
        default=ProjectStatus.DRAFT,
        nullable=False,
        index=True
    )
    
    # Anuência digital formal do orientador (BR-05)
    advisor_consent: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    advisor_consent_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)

    # Relacionamentos
    event: Mapped["Event"] = relationship(back_populates="projects")
    subarea: Mapped["Subarea"] = relationship(back_populates="projects", lazy="selectin")
    members: Mapped[List["ProjectMember"]] = relationship(
        back_populates="project",
        cascade="all, delete-orphan",
        lazy="selectin"
    )
    evaluations: Mapped[List["Evaluation"]] = relationship(back_populates="project")

    @property
    def subarea_name(self) -> Optional[str]:
        return self.subarea.name if self.subarea else None

    @property
    def area_name(self) -> Optional[str]:
        return self.subarea.knowledge_area.name if (self.subarea and self.subarea.knowledge_area) else None


class ProjectMember(BaseModel):
    """Integrantes vinculados ao projeto com definição estrita de papel (BR-04, BR-05)."""

    __tablename__ = "project_members"

    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id"), nullable=False, index=True)
    person_id: Mapped[int] = mapped_column(ForeignKey("people.id"), nullable=False, index=True)
    role: Mapped[ProjectMemberRole] = mapped_column(
        Enum(ProjectMemberRole, native_enum=False),
        nullable=False
    )

    # Relacionamentos
    project: Mapped["Project"] = relationship(back_populates="members", lazy="selectin")
    person: Mapped["Person"] = relationship(back_populates="project_memberships", lazy="selectin")

    @property
    def person_name(self) -> Optional[str]:
        return self.person.name if self.person else None

    @property
    def person_email(self) -> Optional[str]:
        return self.person.email if self.person else None

    @property
    def person_cpf(self) -> Optional[str]:
        return self.person.cpf if self.person else None

    @property
    def tshirt_size(self) -> Optional[str]:
        if "person" not in self.__dict__ or not self.person:
            return None
        person = self.person
        if "event_participations" not in person.__dict__:
            return None
        participations = person.event_participations or []
        event_id = None
        if "project" in self.__dict__ and self.project:
            event_id = self.project.event_id
        if event_id is not None:
            for ep in participations:
                if ep.event_id == event_id:
                    return ep.tshirt_size
        elif participations:
            return participations[-1].tshirt_size
        return None
