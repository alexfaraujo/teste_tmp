"""Registration verification model for OTP email validation (Rule BR-24)."""

from datetime import datetime
from sqlalchemy import Boolean, DateTime, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import BaseModel


class RegistrationVerification(BaseModel):
    """
    Registro de solicitação e validação de OTP para auto-cadastro
    ou primeiro acesso de organizadores de feiras (Regra BR-24).
    """
    __tablename__ = "registration_verifications"

    email: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    code_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    attempts: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    verified: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
