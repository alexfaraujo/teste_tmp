"""Event, stages and education levels models."""

from datetime import date
from typing import List, Optional
from sqlalchemy import Date, Enum, ForeignKey, Integer, String, Text, UniqueConstraint, and_
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import BaseModel
from app.models.enums import EducationLevelEnum, EventStatus, EventAdminRole


class Event(BaseModel):
    """Edição anual de uma feira de ciência e tecnologia (Regra BR-01)."""

    __tablename__ = "events"

    name: Mapped[str] = mapped_column(String(255), nullable=False)
    year: Mapped[int] = mapped_column(Integer, nullable=False, index=True)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    owner_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("people.id", ondelete="SET NULL"),
        nullable=True,
        index=True
    )
    max_projects: Mapped[int] = mapped_column(Integer, default=150, nullable=False)
    workload_hours: Mapped[int] = mapped_column(Integer, default=40, nullable=False)
    location: Mapped[str] = mapped_column(String(255), default="Campus do IFMS", nullable=False)
    start_date: Mapped[date] = mapped_column(Date, nullable=False)
    end_date: Mapped[date] = mapped_column(Date, nullable=False, index=True)  # Trava definitiva (BR-02)
    status: Mapped[EventStatus] = mapped_column(
        Enum(EventStatus, native_enum=False),
        default=EventStatus.OPEN,
        nullable=False
    )
    summary_extension: Mapped[str] = mapped_column(String(10), default="pdf", nullable=False)
    banner_extension: Mapped[str] = mapped_column(String(10), default="pdf", nullable=False)
    max_file_size_mb: Mapped[int] = mapped_column(Integer, default=20, nullable=False)
    max_projects_per_evaluator: Mapped[int] = mapped_column(Integer, default=4, nullable=False)
    organizing_institution: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    theme: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    contact_email: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    website_url: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    logo_url: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)

    # Relacionamentos
    owner: Mapped[Optional["Person"]] = relationship("Person", foreign_keys=[owner_id])
    administrators: Mapped[List["EventAdministrator"]] = relationship(
        "EventAdministrator",
        back_populates="event",
        primaryjoin="and_(Event.id == EventAdministrator.event_id, EventAdministrator.deleted_at.is_(None))",
        cascade="all, delete-orphan",
        lazy="selectin"
    )
    stages: Mapped[List["EventStage"]] = relationship(
        back_populates="event",
        cascade="all, delete-orphan",
        lazy="selectin"
    )
    education_levels: Mapped[List["EducationLevel"]] = relationship(
        back_populates="event",
        primaryjoin="and_(Event.id == EducationLevel.event_id, EducationLevel.deleted_at.is_(None))",
        cascade="all, delete-orphan",
        lazy="selectin"
    )
    knowledge_areas: Mapped[List["KnowledgeArea"]] = relationship(back_populates="event", cascade="all, delete-orphan")
    awards: Mapped[List["Award"]] = relationship(back_populates="event", cascade="all, delete-orphan")
    projects: Mapped[List["Project"]] = relationship(back_populates="event")


class EventStage(BaseModel):
    """Etapas temporais configuradas para a edição (submissão, anuência, etc.)."""

    __tablename__ = "event_stages"

    event_id: Mapped[int] = mapped_column(ForeignKey("events.id"), nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    start_date: Mapped[date] = mapped_column(Date, nullable=False)
    end_date: Mapped[date] = mapped_column(Date, nullable=False)

    event: Mapped["Event"] = relationship(back_populates="stages")


class EducationLevel(BaseModel):
    """Níveis de ensino configurados para o evento e cotas de alunos (Regra BR-04)."""

    __tablename__ = "education_levels"

    event_id: Mapped[int] = mapped_column(ForeignKey("events.id"), nullable=False, index=True)
    level_name: Mapped[EducationLevelEnum] = mapped_column(
        Enum(EducationLevelEnum, native_enum=False),
        nullable=False
    )
    max_students: Mapped[int] = mapped_column(Integer, default=4, nullable=False)
    min_evaluators: Mapped[int] = mapped_column(Integer, default=2, nullable=False)

    event: Mapped["Event"] = relationship(back_populates="education_levels")


class EventAdministrator(BaseModel):
    """Gestor administrativo associado a uma edição de evento (Regra BR-23)."""

    __tablename__ = "event_administrators"

    event_id: Mapped[int] = mapped_column(ForeignKey("events.id", ondelete="CASCADE"), nullable=False, index=True)
    person_id: Mapped[int] = mapped_column(ForeignKey("people.id", ondelete="CASCADE"), nullable=False, index=True)
    role: Mapped[EventAdminRole] = mapped_column(
        Enum(EventAdminRole, native_enum=False),
        default=EventAdminRole.ORGANIZER,
        nullable=False
    )

    event: Mapped["Event"] = relationship(back_populates="administrators")
    person: Mapped["Person"] = relationship("Person", lazy="joined")

    @property
    def name(self) -> str:
        return self.person.name if self.person else ""

    @property
    def email(self) -> str:
        return self.person.email if self.person else ""

    @property
    def is_owner(self) -> bool:
        return (self.event.owner_id == self.person_id) if self.event and self.event.owner_id else False

    __table_args__ = (
        UniqueConstraint("event_id", "person_id", name="uq_event_administrator"),
    )

