"""Models package aggregator."""

from app.models.base import BaseModel
from app.models.enums import (
    UserRole,
    EventStatus,
    EducationLevelEnum,
    ProjectType,
    ProjectStatus,
    ProjectMemberRole,
    AllocationType,
    AllocationStatus,
    EvaluationStatus,
    EventAdminRole
)
from app.models.event import Event, EventStage, EducationLevel, EventAdministrator
from app.models.knowledge_area import KnowledgeArea, Subarea
from app.models.person import Person, EventParticipant, PersonSubarea, EventParticipantRole, PersonEducationLevel
from app.models.project import Project, ProjectMember
from app.models.award import Award, AwardCriterion
from app.models.evaluation import EvaluationCriterion, Evaluation, EvaluationItem, EvaluatorAllocation
from app.models.registration_verification import RegistrationVerification
from app.models.snack import SnackMoment, SnackDelivery

__all__ = [
    "BaseModel",
    "UserRole",
    "EventStatus",
    "EducationLevelEnum",
    "ProjectType",
    "ProjectStatus",
    "ProjectMemberRole",
    "AllocationType",
    "AllocationStatus",
    "EvaluationStatus",
    "EventAdminRole",
    "Event",
    "EventStage",
    "EducationLevel",
    "EventAdministrator",
    "KnowledgeArea",
    "Subarea",
    "Person",
    "EventParticipant",
    "PersonSubarea",
    "EventParticipantRole",
    "PersonEducationLevel",
    "Project",
    "ProjectMember",
    "Award",
    "AwardCriterion",
    "EvaluationCriterion",
    "Evaluation",
    "EvaluationItem",
    "EvaluatorAllocation",
    "RegistrationVerification",
    "SnackMoment",
    "SnackDelivery",
]
