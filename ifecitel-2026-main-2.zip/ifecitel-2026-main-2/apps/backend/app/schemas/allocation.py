"""Schemas for evaluator allocations and qualifications (Regra BR-10)."""

from datetime import datetime
from typing import Dict, List, Optional
from pydantic import BaseModel, Field

from app.models.enums import AllocationStatus, AllocationType, EducationLevelEnum


class EvaluatorQualificationRequest(BaseModel):
    """Payload para vincular subáreas de conhecimento a um avaliador (BR-10)."""
    person_id: int = Field(..., description="ID do avaliador")
    event_id: int = Field(..., description="ID do evento")
    subarea_ids: List[int] = Field(..., min_length=1, description="Lista de IDs das subáreas de especialidade")


class EvaluatorQualificationResponse(BaseModel):
    """Resposta com subáreas vinculadas ao avaliador."""
    person_id: int
    person_name: str
    event_id: int
    subarea_ids: List[int]
    message: str


class AutoBalanceRequest(BaseModel):
    """Disparo do algoritmo de distribuição balanceada pós-checkin (Momento 1)."""
    event_id: int = Field(..., description="ID do evento ativo")


class AutoBalanceSummaryResponse(BaseModel):
    """Resultado estatístico do balanceamento com verificação da Regra de Ouro (delta <= 1)."""
    event_id: int
    present_projects_count: int
    evaluators_count: int
    total_allocations_created: int
    golden_rule_satisfied: bool
    allocations_per_subarea: Dict[str, int]
    message: str


class ManualAllocationRequest(BaseModel):
    """Alocação manual ou remanejamento pelo Administrador (Momento 2)."""
    event_id: int
    project_id: int
    evaluator_id: int
    override_conflict: bool = Field(False, description="Autorização excepcional da comissão para alocar mesmo com conflito de categoria (Grande Área + Nível)")
    override_reason: Optional[str] = Field(None, description="Justificativa administrativa para a alocação excepcional")


class AllocationResponse(BaseModel):
    """Detalhes da alocação de trabalho para avaliador."""
    id: int
    event_id: int
    project_id: int
    project_title: str
    booth_number: Optional[str] = None
    subarea_name: str
    area_name: Optional[str] = None
    evaluator_id: int
    evaluator_name: str
    allocation_type: AllocationType
    status: AllocationStatus
    allocated_at: datetime
    qrcode_token: Optional[str] = None

    class Config:
        from_attributes = True


class AllocatedProjectItem(BaseModel):
    """Resumo de um projeto alocado dinamicamente."""
    project_id: int
    project_title: str
    booth_number: Optional[str] = None
    subarea_name: str
    area_name: Optional[str] = None
    current_evaluators_count: int


class EvaluatorScanCheckinRequest(BaseModel):
    """Requisição para scan de código de barras / QR code / CPF na Sala dos Avaliadores."""
    barcode: str
    event_id: int


class EvaluatorCheckinAllocationResponse(BaseModel):
    """Resposta com dados da presença do avaliador e trabalhos alocados dinamicamente (BR-10)."""
    evaluator_id: int
    evaluator_name: str
    event_id: int
    presence_confirmed: bool
    evaluator_presence_confirmed: bool = True
    already_checked_in: bool = False
    kit_delivered: bool = False
    tshirt_size: Optional[str] = "M"
    allocated_projects_count: int
    allocated_projects: List[AllocatedProjectItem]
    message: str


class EvaluatorSubareaItem(BaseModel):
    """Subárea vinculada ao avaliador com sua grande área mãe."""
    subarea_id: int
    subarea_name: str
    area_id: int
    area_name: str


class EvaluatorListItem(BaseModel):
    """Item da listagem de avaliadores para alocação de projetos (BR-10)."""
    id: int
    name: str
    email: str
    cpf: Optional[str] = None
    barcode: Optional[str] = None
    presence_confirmed: bool = False
    evaluator_presence_confirmed: bool = False
    allocated_projects_count: int = 0
    education_levels: List[EducationLevelEnum] = []
    subareas: List[EvaluatorSubareaItem] = []

    class Config:
        from_attributes = True

