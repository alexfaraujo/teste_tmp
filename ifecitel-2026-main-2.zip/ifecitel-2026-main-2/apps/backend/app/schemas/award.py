"""Awards and criteria association schemas (Regra BR-17)."""

from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel, Field


class AwardCriterionLinkInput(BaseModel):
    criterion_id: int
    weight: float = Field(default=1.0, ge=0.1, le=10.0)


class AwardCriterionResponse(BaseModel):
    id: int
    award_id: int
    criterion_id: int
    criterion_name: Optional[str] = None
    weight: float
    created_at: datetime

    class Config:
        from_attributes = True


class AwardBase(BaseModel):
    name: str = Field(..., min_length=3, max_length=200)
    description: Optional[str] = None
    sponsor: Optional[str] = Field(None, max_length=200)


class AwardCreate(AwardBase):
    criteria_links: Optional[List[AwardCriterionLinkInput]] = None


class AwardUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=3, max_length=200)
    description: Optional[str] = None
    sponsor: Optional[str] = Field(None, max_length=200)
    criteria_links: Optional[List[AwardCriterionLinkInput]] = None


class AwardResponse(AwardBase):
    id: int
    event_id: int
    created_at: datetime
    updated_at: datetime
    criteria_links: Optional[List[AwardCriterionResponse]] = None

    class Config:
        from_attributes = True


class AwardStandingItemResponse(BaseModel):
    """Item classificado na premiação específica (Ranking 2 - BR-17)."""
    project_id: int
    title: str
    booth_number: str = ""
    subarea_name: str
    education_level: str
    evaluations_count: int
    award_score: float
    rank_position: int

    class Config:
        from_attributes = True


class AwardStandingsResponse(BaseModel):
    """Apuração oficial de um Prêmio Específico baseada estritamente nos itens indicados (Ranking 2)."""
    award_id: int
    award_name: str
    sponsor: Optional[str] = None
    criteria_considered: List[str]
    total_competing_projects: int
    standings: List[AwardStandingItemResponse]

