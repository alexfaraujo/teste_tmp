"""Authentication schemas for Admin and Participants."""

from typing import Optional
from pydantic import BaseModel, EmailStr, Field


class AdminLoginRequest(BaseModel):
    """Requisição de login para Administradores do Evento."""
    email: EmailStr
    password: str = Field(..., min_length=6, description="Senha mestre do administrador")


class OTPRequest(BaseModel):
    """Solicitação de geração e envio de código OTP de 8 caracteres por e-mail."""
    email: EmailStr


class OTPVerifyRequest(BaseModel):
    """Validação do código OTP de 8 caracteres em caixa alta (digitado mascarado)."""
    email: EmailStr
    access_code: str = Field(..., min_length=8, max_length=8, description="Código de 8 caracteres alfanuméricos")


class TokenResponse(BaseModel):
    """Resposta contendo o token JWT Bearer com validade de 12 horas."""
    access_token: str
    token_type: str = "bearer"
    expires_in_hours: int = 12
    id: int
    name: str
    email: str
    role: str
    barcode: Optional[str] = None


class UserProfileResponse(BaseModel):
    """Dados cadastrais do usuário autenticado."""
    id: int
    name: str
    email: str
    role: str
    barcode: Optional[str] = None


class RegisterRequestCodeRequest(BaseModel):
    """Solicitação de código OTP para auto-cadastro ou primeiro acesso de organizador (Regra BR-24)."""
    email: EmailStr
    name: Optional[str] = Field(None, min_length=2, description="Nome do organizador (opcional nesta etapa)")


class RegisterRequestCodeResponse(BaseModel):
    """Confirmação de envio do código OTP de verificação."""
    message: str
    email: str
    expires_in_seconds: int = 900
    dev_code: Optional[str] = None


class RegisterCompleteRequest(BaseModel):
    """Conclusão do cadastro do organizador com OTP, dados pessoais e definição de senha."""
    email: EmailStr
    code: str = Field(..., min_length=8, max_length=9, description="Código de 8 caracteres alfanuméricos")
    name: str = Field(..., min_length=2, max_length=150, description="Nome completo")
    password: str = Field(..., min_length=6, description="Senha de acesso pessoal")
    cpf: Optional[str] = Field(None, max_length=20, description="CPF do participante")
    affiliation: Optional[str] = Field(None, max_length=200, description="Instituição / Campus / Escola")

