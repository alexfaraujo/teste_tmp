"""Dashboard schemas for public TV kiosk (Regra BR-14)."""

from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel


class AreaEvaluationProgress(BaseModel):
    """Progresso percentual de avaliações por grande área do conhecimento."""
    area_id: int
    area_name: str
    total_projects: int
    present_projects: int = 0
    evaluations_completed: int
    expected_evaluations: int = 0
    progress_percent: float = 0.0


class PublicTvDashboardResponse(BaseModel):
    """Métricas puramente agregadas para o painel de Smart TVs e Telões (BR-14)."""
    event_id: int
    event_name: str
    total_registered_participants: int
    total_present_participants: int
    total_registered_students_advisors: int = 0
    total_present_students_advisors: int = 0
    total_registered_evaluators: int = 0
    total_present_evaluators: int = 0
    total_registered_projects: int
    total_present_projects: int
    total_evaluations_completed: int
    areas_progress: List[AreaEvaluationProgress]
    updated_at: datetime
    min_evaluators_default: int = 3
    total_expected_evaluations: int = 0
    evaluation_progress_percent: float = 0.0


class ProjectRankingItemResponse(BaseModel):
    """Item de projeto classificado no ranking oficial com nota calculada."""
    project_id: int
    title: str
    booth_number: str = ""
    subarea_name: str
    area_name: str
    education_level: str
    evaluations_count: int
    final_score: float
    rank_position: int

    class Config:
        from_attributes = True


class AreaLevelLeaderboardGroup(BaseModel):
    """Agrupamento do Ranking 1 por Área do Conhecimento e Nível de Ensino (BR-12)."""
    area_id: int
    area_name: str
    education_level: str
    total_projects: int
    standings: List[ProjectRankingItemResponse]


class LevelLeaderboardGroup(BaseModel):
    """Agrupamento do Ranking Geral por Nível de Ensino (BR-12)."""
    education_level: str
    education_level_label: str
    total_projects: int
    standings: List[ProjectRankingItemResponse]


class OverallLeaderboardResponse(BaseModel):
    """Ranking 1: Classificação unificada de Melhor Geral da Feira (BR-12)."""
    event_id: int
    event_name: str
    total_evaluated_projects: int
    standings: List[ProjectRankingItemResponse]
    by_education_level: Optional[List[LevelLeaderboardGroup]] = None


# ==============================================================================
# Centro de Comando do Administrador (War Room - BR-10, BR-14, BR-18)
# ==============================================================================

class AdminProjectsKpi(BaseModel):
    registered: int
    present: int
    present_percent: float
    in_evaluation: int
    evaluated: int
    absent: int
    zero_evaluators_count: int
    under_quota_count: int


class AdminParticipantsKpi(BaseModel):
    registered_students: int
    present_students: int
    students_presence_percent: float
    registered_advisors: int
    present_advisors: int
    advisors_presence_percent: float
    total_registered: int
    total_present: int
    overall_presence_percent: float
    kits_delivered: int
    kits_delivered_percent: float


class AdminEvaluatorsKpi(BaseModel):
    registered: int
    present: int
    present_percent: float
    evaluating_now: int
    available: int
    total_capacity: int
    expected_evaluations: int
    global_deficit_evaluations: int
    global_deficit_evaluators: int
    fundamental_evaluators_count: int
    medio_evaluators_count: int


class AdminProgressKpi(BaseModel):
    evaluations_completed: int
    evaluations_in_progress: int
    evaluations_pending: int
    progress_percent: float
    evaluations_per_hour: float
    estimated_completion_time: Optional[str] = None


class AdminKpiCollection(BaseModel):
    projects: AdminProjectsKpi
    participants: AdminParticipantsKpi
    evaluators: AdminEvaluatorsKpi
    progress: AdminProgressKpi


class AdminAreaDiagnostic(BaseModel):
    area_id: int
    area_name: str
    total_projects: int
    present_projects: int
    evaluations_completed: int
    expected_evaluations: int
    progress_percent: float
    registered_evaluators: int
    present_evaluators: int
    area_capacity: int
    deficit_evaluations: int
    deficit_evaluators_needed: int
    health_status: str  # "GREEN", "YELLOW", "RED"
    projects_at_risk_count: int


class AllocatedEvaluatorSimple(BaseModel):
    id: int
    name: str


class CriticalProjectItem(BaseModel):
    project_id: int
    title: str
    stand_number: Optional[str] = None
    area_id: int
    area_name: str
    education_level: str
    min_evaluators: int
    allocated_evaluators_count: int
    allocated_evaluators: List[AllocatedEvaluatorSimple] = []
    gap_status: str  # "ZERO_EVALUATORS" | "BELOW_QUOTA"


class AdminOverviewResponse(BaseModel):
    event_id: int
    event_name: str
    event_year: int
    event_status: str
    max_projects_per_evaluator: int
    updated_at: datetime
    kpis: AdminKpiCollection
    areas_diagnostic: List[AdminAreaDiagnostic]
    critical_projects: List[CriticalProjectItem]
    golden_rule_satisfied: bool
    total_active_allocations: int


