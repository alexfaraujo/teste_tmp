"""Event and stages schemas."""

from datetime import date, datetime
from typing import List, Optional
from pydantic import BaseModel, Field
from app.models.enums import EducationLevelEnum, EventStatus, EventAdminRole
from app.schemas.event_admin import EventAdminItem
from app.schemas.pagination import PaginatedResponse


class EducationLevelBase(BaseModel):
    level_name: EducationLevelEnum
    max_students: int = Field(default=4, ge=1, le=10)
    min_evaluators: int = Field(default=2, ge=1, le=5)


class EducationLevelCreate(EducationLevelBase):
    pass


class EducationLevelResponse(EducationLevelBase):
    id: int
    event_id: int
    created_at: datetime

    class Config:
        from_attributes = True


class EventStageBase(BaseModel):
    name: str
    start_date: date
    end_date: date


class EventStageCreate(EventStageBase):
    pass


class EventStageResponse(EventStageBase):
    id: int
    event_id: int
    created_at: datetime

    class Config:
        from_attributes = True


class EventAdminCreateInput(BaseModel):
    email: str = Field(..., min_length=3, max_length=255)
    role: EventAdminRole = Field(default=EventAdminRole.ORGANIZER)


class EventBase(BaseModel):
    name: str = Field(..., min_length=3, max_length=255)
    year: int = Field(..., ge=2020, le=2050)
    description: Optional[str] = None
    max_projects: int = Field(default=150, ge=1)
    workload_hours: int = Field(default=40, ge=1)
    location: str = "Campus do IFMS"
    start_date: date
    end_date: date
    summary_extension: str = "pdf"
    banner_extension: str = "pdf"
    max_file_size_mb: int = Field(default=20, ge=1, le=100)
    max_projects_per_evaluator: int = Field(default=4, ge=1, le=20)
    organizing_institution: Optional[str] = None
    theme: Optional[str] = None
    contact_email: Optional[str] = None
    website_url: Optional[str] = None
    logo_url: Optional[str] = None


class EventCreate(EventBase):
    stages: Optional[List[EventStageCreate]] = None
    education_levels: Optional[List[EducationLevelCreate]] = None
    administrators: Optional[List[EventAdminCreateInput]] = None


class EventUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    max_projects: Optional[int] = None
    workload_hours: Optional[int] = None
    location: Optional[str] = None
    start_date: Optional[date] = None
    end_date: Optional[date] = None
    status: Optional[EventStatus] = None
    summary_extension: Optional[str] = None
    banner_extension: Optional[str] = None
    max_file_size_mb: Optional[int] = None
    max_projects_per_evaluator: Optional[int] = None
    organizing_institution: Optional[str] = None
    theme: Optional[str] = None
    contact_email: Optional[str] = None
    website_url: Optional[str] = None
    logo_url: Optional[str] = None
    education_levels: Optional[List[EducationLevelCreate]] = None
    administrators: Optional[List[EventAdminCreateInput]] = None


class EventResponse(EventBase):
    id: int
    owner_id: Optional[int] = None
    owner_name: Optional[str] = None
    owner_email: Optional[str] = None
    status: EventStatus
    user_role: Optional[EventAdminRole] = None
    is_owner: Optional[bool] = None
    created_at: datetime
    updated_at: datetime
    education_levels: Optional[List[EducationLevelResponse]] = None
    administrators: Optional[List[EventAdminItem]] = None

    class Config:
        from_attributes = True


class PaginatedEventResponse(PaginatedResponse[EventResponse]):
    """Resposta paginada para listagem de edições de eventos (Regra BR-18)."""
    pass

