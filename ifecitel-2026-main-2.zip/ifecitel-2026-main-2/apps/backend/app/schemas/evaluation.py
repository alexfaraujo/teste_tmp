"""Schemas for evaluations, criteria and mobile sheet (Regras BR-11 e BR-12)."""

from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel, Field

from app.models.enums import EvaluationStatus, ProjectType


class EvaluationItemInput(BaseModel):
    """Nota numérica atribuída a cada critério da ficha."""
    criterion_id: int
    score: float = Field(..., ge=0.0, le=10.0, description="Nota de 0.0 a 10.0")


class EvaluationCriterionCreate(BaseModel):
    """Payload para cadastro de novo critério de avaliação vinculado ao evento."""
    name: str = Field(..., min_length=2, max_length=200, description="Nome identificador do critério / item da ficha")
    scientific_description: Optional[str] = Field(None, description="Pergunta / formulação exibida na ficha mobile quando o trabalho for Científico")
    technological_description: Optional[str] = Field(None, description="Pergunta / formulação exibida na ficha mobile quando o trabalho for Tecnológico")
    max_score: float = Field(default=10.0, ge=1.0, le=100.0, description="Pontuação máxima compartilhada para ambas as formulações")
    weight: float = Field(default=1.0, ge=0.1, le=10.0, description="Peso padrão compartilhado na ficha de avaliação")


class EvaluationCriterionUpdate(BaseModel):
    """Payload para atualização de critério de avaliação existente."""
    name: Optional[str] = Field(None, min_length=2, max_length=200, description="Nome identificador do critério / item da ficha")
    scientific_description: Optional[str] = Field(None, description="Pergunta / formulação exibida na ficha mobile quando o trabalho for Científico")
    technological_description: Optional[str] = Field(None, description="Pergunta / formulação exibida na ficha mobile quando o trabalho for Tecnológico")
    max_score: Optional[float] = Field(None, ge=1.0, le=100.0, description="Pontuação máxima compartilhada para ambas as formulações")
    weight: Optional[float] = Field(None, ge=0.1, le=10.0, description="Peso padrão compartilhado na ficha de avaliação")


class EvaluationCriterionResponse(BaseModel):
    """Critério de avaliação cadastrado para a edição do evento."""
    id: int
    event_id: int
    name: str
    scientific_description: Optional[str] = None
    technological_description: Optional[str] = None
    max_score: float
    weight: float

    class Config:
        from_attributes = True


class EvaluationCriterionBatchItem(BaseModel):
    """Item de critério de avaliação para importação em lote / CSV."""
    name: str = Field(..., min_length=2, max_length=200, description="Nome identificador do critério")
    pergunta_unica: Optional[str] = Field(None, description="Pergunta única opcional caso o evento não tenha distinção metodológica")
    scientific_description: Optional[str] = Field(None, description="Pergunta para trabalhos científicos")
    technological_description: Optional[str] = Field(None, description="Pergunta para trabalhos tecnológicos")
    max_score: float = Field(default=10.0, ge=1.0, le=100.0, description="Pontuação máxima")
    weight: float = Field(default=1.0, ge=0.1, le=10.0, description="Peso padrão na ficha")


class EvaluationCriterionBatchImport(BaseModel):
    """Payload para importação em lote de critérios de avaliação."""
    items: List[EvaluationCriterionBatchItem] = Field(..., min_length=1, description="Lista de critérios para importação / sincronização")


class EvaluationCriterionBatchResponse(BaseModel):
    """Resultado da importação em lote / upsert de critérios."""
    total: int = Field(..., description="Total de critérios processados")
    created_count: int = Field(..., description="Quantidade de novos critérios criados")
    updated_count: int = Field(..., description="Quantidade de critérios existentes atualizados")
    items: List[EvaluationCriterionResponse] = Field(..., description="Critérios resultantes após o upsert")


class EvaluationItemResponse(BaseModel):
    """Item de nota registrado."""
    id: int
    criterion_id: int
    criterion_name: str
    score: float

    class Config:
        from_attributes = True


class EvaluationCreate(BaseModel):
    """Submissão da avaliação com parecer consolidado único / observação opcional (BR-11)."""
    project_id: int
    general_feedback: Optional[str] = Field(None, description="Parecer geral / observação sobre o trabalho (opcional)")
    items: List[EvaluationItemInput] = Field(..., min_length=1, description="Notas por critério")
    status: EvaluationStatus = EvaluationStatus.COMPLETED


class EvaluationResponse(BaseModel):
    """Resposta com detalhes da avaliação e média calculada."""
    id: int
    project_id: int
    evaluator_id: int
    evaluator_name: str
    status: EvaluationStatus
    general_feedback: Optional[str] = None
    evaluated_at: Optional[datetime] = None
    items: List[EvaluationItemResponse]
    final_score: float

    class Config:
        from_attributes = True


class EvaluationCriterionSheetItem(BaseModel):
    """Critério dinâmico formatado para a tela do smartphone do avaliador."""
    criterion_id: int
    name: str
    description: str
    max_score: float
    weight: float
    current_score: Optional[float] = None


class EvaluationSheetResponse(BaseModel):
    """Ficha completa retornada após a leitura do QR Code de bancada (BR-08, BR-11)."""
    project_id: int
    title: str
    abstract: Optional[str] = None
    project_type: ProjectType
    booth_number: Optional[str] = None
    subarea_name: str
    area_name: Optional[str] = None
    education_level: Optional[str] = None
    school_name: Optional[str] = None
    authors: List[str] = []
    advisor_name: Optional[str] = None
    coadvisor_name: Optional[str] = None
    qrcode_token: Optional[str] = None
    criteria: List[EvaluationCriterionSheetItem]
    current_feedback: Optional[str] = None


class ProjectEvaluationSummaryResponse(BaseModel):
    """Totalização oficial das avaliações do projeto por média aritmética simples (BR-12)."""
    project_id: int
    title: str
    evaluations_count: int
    simple_arithmetic_mean: float
    feedbacks: List[str]
