"""Universal pagination schemas (Regra BR-18)."""

from typing import Generic, List, TypeVar
from pydantic import BaseModel, Field

T = TypeVar("T")


class PaginatedResponse(BaseModel, Generic[T]):
    """Modelo genérico para respostas paginadas (Regra BR-18: 15 itens por página)."""
    items: List[T]
    total: int = Field(..., description="Total de registros encontrados")
    page: int = Field(..., ge=1, description="Número da página corrente (1-indexed)")
    limit: int = Field(..., ge=1, description="Quantidade máxima de itens por página")
    total_pages: int = Field(..., ge=0, description="Total de páginas calculadas")
