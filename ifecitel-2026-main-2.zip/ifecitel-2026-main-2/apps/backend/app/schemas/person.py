"""Person schemas for user management."""

from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel, EmailStr, Field
from app.models.enums import UserRole, EducationLevelEnum


class PersonBase(BaseModel):
    name: str
    email: EmailStr
    cpf: Optional[str] = None
    affiliation: Optional[str] = None
    role: UserRole = UserRole.STUDENT


class PersonCreate(PersonBase):
    password: Optional[str] = None
    barcode: Optional[str] = None


class PersonResponse(PersonBase):
    id: int
    barcode: Optional[str] = None
    created_at: datetime

    class Config:
        from_attributes = True


class ParticipantProjectItem(BaseModel):
    project_id: int
    title: str
    member_role: str
    booth_number: Optional[str] = None


class ParticipantSubareaItem(BaseModel):
    subarea_id: int
    subarea_name: str
    area_name: str


class ParticipantItemResponse(BaseModel):
    participant_id: int
    person_id: int
    event_id: int
    name: str
    email: str
    cpf: Optional[str] = None
    affiliation: Optional[str] = None
    role: UserRole
    roles: List[UserRole] = []
    barcode: Optional[str] = None
    tshirt_size: str = "M"
    kit_delivered: bool = False
    kit_delivered_at: Optional[datetime] = None
    presence_confirmed: bool = False
    presence_confirmed_at: Optional[datetime] = None
    evaluator_presence_confirmed: bool = False
    evaluator_presence_confirmed_at: Optional[datetime] = None
    education_levels: List[EducationLevelEnum] = []
    projects_count: int = 0
    created_at: datetime

    class Config:
        from_attributes = True


class ParticipantDetailResponse(ParticipantItemResponse):
    projects: List[ParticipantProjectItem] = []
    subareas: List[ParticipantSubareaItem] = []


class ParticipantCreateRequest(BaseModel):
    name: str
    email: EmailStr
    cpf: Optional[str] = None
    affiliation: Optional[str] = None
    role: Optional[UserRole] = None
    roles: Optional[List[UserRole]] = None
    tshirt_size: str = "M"
    barcode: Optional[str] = None
    subarea_ids: Optional[List[int]] = None
    education_levels: Optional[List[EducationLevelEnum]] = None


class ParticipantUpdateRequest(BaseModel):
    name: Optional[str] = None
    email: Optional[EmailStr] = None
    cpf: Optional[str] = None
    affiliation: Optional[str] = None
    role: Optional[UserRole] = None
    roles: Optional[List[UserRole]] = None
    tshirt_size: Optional[str] = None
    barcode: Optional[str] = None
    kit_delivered: Optional[bool] = None
    presence_confirmed: Optional[bool] = None
    evaluator_presence_confirmed: Optional[bool] = None
    subarea_ids: Optional[List[int]] = None
    education_levels: Optional[List[EducationLevelEnum]] = None




class PaginatedParticipantsResponse(BaseModel):
    items: List[ParticipantItemResponse]
    total: int
    page: int
    limit: int
    total_pages: int


class ParticipantBatchItem(BaseModel):
    name: str = Field(..., min_length=2, max_length=255, description="Nome completo do participante")
    email: EmailStr = Field(..., description="E-mail único do participante")
    roles: List[UserRole] = Field(default_factory=lambda: [UserRole.STUDENT], description="Papéis exercidos no evento")
    cpf: Optional[str] = Field(None, max_length=20, description="CPF do participante")
    affiliation: Optional[str] = Field(None, max_length=255, description="Instituição ou afiliação")
    tshirt_size: Optional[str] = Field(default="M", max_length=10, description="Tamanho da camiseta")
    subareas: List[str] = Field(default_factory=list, description="Nomes das subáreas do avaliador")
    education_levels: List[EducationLevelEnum] = Field(default_factory=list, description="Níveis de ensino habilitados para o avaliador")
    barcode: Optional[str] = Field(None, max_length=64, description="Código de barras manual opcional")


class ParticipantBatchImport(BaseModel):
    items: List[ParticipantBatchItem] = Field(..., min_length=1, description="Lista de participantes para importação")


class ParticipantBatchResponse(BaseModel):
    total_processed: int = Field(..., description="Total de participantes processados")
    created_count: int = Field(..., description="Novos participantes cadastrados")
    updated_count: int = Field(..., description="Participantes existentes atualizados")
    roles_assigned_count: int = Field(..., description="Total de vínculos de papéis atribuídos")
    evaluators_count: int = Field(..., description="Total de avaliadores qualificados")
    items: List[ParticipantItemResponse] = Field(default_factory=list, description="Lista dos participantes processados")

