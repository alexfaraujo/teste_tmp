"""Event Administrator Schemas (Regra BR-23)."""

from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel, EmailStr, Field

from app.models.enums import EventAdminRole


class EventAdminItem(BaseModel):
    """Representação de um administrador vinculado ao evento."""
    id: int
    event_id: int
    person_id: int
    name: str
    email: str
    role: EventAdminRole
    is_owner: bool = False
    created_at: datetime

    class Config:
        from_attributes = True


class EventAdminCreate(BaseModel):
    """Payload para convidar/adicionar um novo administrador ao evento."""
    email: EmailStr
    role: EventAdminRole = EventAdminRole.ORGANIZER


class EventAdminUpdate(BaseModel):
    """Payload para alterar o nível administrativo de um gestor."""
    role: EventAdminRole


class EventAdminListResponse(BaseModel):
    """Lista de gestores administrativos de uma feira."""
    items: List[EventAdminItem]
    total: int
