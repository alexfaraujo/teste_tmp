"""Pydantic schemas for snack management and mobile distribution (Rule BR-30)."""

from datetime import date as dt_date, datetime
from typing import List, Optional
from pydantic import BaseModel, ConfigDict, Field


class SnackMomentBase(BaseModel):
    name: str = Field(..., min_length=2, max_length=100, description="Nome do momento de lanche")
    date: dt_date = Field(..., description="Data do momento de lanche")
    start_time: Optional[str] = Field(None, max_length=10, description="Horário de início (ex: 15:30)")
    end_time: Optional[str] = Field(None, max_length=10, description="Horário de término (ex: 17:00)")
    is_active: bool = Field(False, description="Momento ativo para distribuição na fila")
    target_roles: Optional[str] = Field("ALL", max_length=255, description="Papéis autorizados ('ALL' ou separados por vírgula)")
    total_budgeted: Optional[int] = Field(0, ge=0, description="Quantidade total estimada de lanches")
    notes: Optional[str] = Field(None, description="Observações logísticas")


class SnackMomentCreate(SnackMomentBase):
    pass


class SnackMomentUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=2, max_length=100)
    date: Optional[dt_date] = None
    start_time: Optional[str] = None
    end_time: Optional[str] = None
    is_active: Optional[bool] = None
    target_roles: Optional[str] = None
    total_budgeted: Optional[int] = Field(None, ge=0)
    notes: Optional[str] = None


class SnackMomentResponse(SnackMomentBase):
    id: int
    event_id: int
    created_at: datetime
    total_delivered: int = 0
    percentage_consumed: float = 0.0

    model_config = ConfigDict(from_attributes=True)


class SnackDeliverScanRequest(BaseModel):
    scan_query: str = Field(..., min_length=1, max_length=100, description="Código de barras, CPF ou ID do participante")
    notes: Optional[str] = Field(None, max_length=255, description="Observações da entrega")


class SnackDeliverScanResponse(BaseModel):
    status: str = Field(..., description="SUCCESS, ALREADY_DELIVERED, ROLE_NOT_ALLOWED, NOT_FOUND, MOMENT_INACTIVE")
    message: str
    moment_id: int
    moment_name: str
    participant_id: Optional[int] = None
    participant_name: Optional[str] = None
    participant_role: Optional[str] = None
    participant_barcode: Optional[str] = None
    affiliation: Optional[str] = None
    project_title: Optional[str] = None
    booth_number: Optional[str] = None
    delivered_at: Optional[datetime] = None
    delivered_by_name: Optional[str] = None
    total_delivered: int = 0
    total_budgeted: int = 0
    percentage_consumed: float = 0.0


class SnackDeliveryItemResponse(BaseModel):
    id: int
    participant_id: int
    participant_name: str
    participant_role: str
    participant_barcode: Optional[str] = None
    affiliation: Optional[str] = None
    project_title: Optional[str] = None
    booth_number: Optional[str] = None
    delivered_at: datetime
    delivered_by_name: Optional[str] = None
    notes: Optional[str] = None

    model_config = ConfigDict(from_attributes=True)


class SnackMomentReportResponse(BaseModel):
    moment: SnackMomentResponse
    delivered_count: int
    total_eligible: int
    deliveries: List[SnackDeliveryItemResponse]


class SnackEligibleCountResponse(BaseModel):
    count: int = Field(..., description="Quantidade de inscritos elegíveis para o público-alvo informado")

