"""Knowledge areas and subareas schemas (Regra BR-16)."""

from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel, Field


class SubareaBase(BaseModel):
    name: str = Field(..., min_length=2, max_length=150)


class SubareaCreate(SubareaBase):
    pass


class SubareaUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=2, max_length=150)


class SubareaResponse(SubareaBase):
    id: int
    area_id: int
    area_name: Optional[str] = None
    created_at: datetime
    updated_at: datetime
    deleted_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class KnowledgeAreaBase(BaseModel):
    name: str = Field(..., min_length=2, max_length=150)


class KnowledgeAreaCreate(KnowledgeAreaBase):
    pass


class KnowledgeAreaUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=2, max_length=150)


class KnowledgeAreaResponse(KnowledgeAreaBase):
    id: int
    event_id: int
    created_at: datetime
    updated_at: datetime
    subareas: Optional[List[SubareaResponse]] = None

    class Config:
        from_attributes = True


class KnowledgeAreaBatchItem(BaseModel):
    """Item para importação em lote (linha do CSV no formato area;subarea)."""
    area: str = Field(..., min_length=2, max_length=150, description="Nome da grande área do conhecimento")
    subarea: Optional[str] = Field(None, max_length=150, description="Nome da subárea especializada (opcional)")


class KnowledgeAreaBatchImport(BaseModel):
    """Payload para importação em lote de grandes áreas e subáreas."""
    items: List[KnowledgeAreaBatchItem] = Field(..., min_length=1, description="Lista de registros a serem processados")


class KnowledgeAreaBatchResponse(BaseModel):
    """Resultado consolidado da importação em lote de áreas e subáreas."""
    total_rows_processed: int = Field(..., description="Total de linhas enviadas no lote")
    total_areas_processed: int = Field(..., description="Total de grandes áreas distintas identificadas")
    total_subareas_processed: int = Field(..., description="Total de subáreas processadas")
    created_areas_count: int = Field(..., description="Novas grandes áreas criadas (ou reativadas)")
    created_subareas_count: int = Field(..., description="Novas subáreas criadas (ou reativadas)")
    reused_areas_count: int = Field(..., description="Grandes áreas que já existiam ativas e foram preservadas")
    reused_subareas_count: int = Field(..., description="Subáreas que já existiam ativas e foram preservadas")
    items: List[KnowledgeAreaResponse] = Field(..., description="Lista de grandes áreas ativas da edição com subáreas")

