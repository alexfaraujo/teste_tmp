"""Logistics, barcode check-in and kit delivery schemas (Regras BR-08 e BR-09)."""

from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel, Field


class BarcodeScanRequest(BaseModel):
    """Payload recebido no leitor de código de barras durante o credenciamento."""
    barcode: str = Field(..., min_length=3, max_length=64, description="Código de barras do crachá")
    event_id: int = Field(..., description="ID da edição do evento ativo")


class ScanProjectItem(BaseModel):
    """Dados de um trabalho científico vinculado para conferência na portaria e entrega de kits."""
    id: int
    title: str
    booth_number: Optional[str] = None
    status: str
    subarea_name: Optional[str] = None
    area_name: Optional[str] = None
    role_in_project: Optional[str] = None
    all_kits_delivered: bool = False


class BarcodeScanResponse(BaseModel):
    """Resposta com dados cadastrais e gatilho de presença coletiva (BR-08) ou scan de estande."""
    person_id: Optional[int] = None
    person_name: Optional[str] = None
    person_role: Optional[str] = None
    barcode: str
    presence_confirmed: bool = False
    presence_confirmed_at: Optional[datetime] = None
    tshirt_size: Optional[str] = None
    kit_delivered: bool = False
    project_id: Optional[int] = None
    project_title: Optional[str] = None
    booth_number: Optional[str] = None
    project_status: Optional[str] = None
    collective_presence_triggered: bool = False
    allocated_projects_count: Optional[int] = None
    is_project_scan: bool = False
    projects: List[ScanProjectItem] = Field(default_factory=list)
    message: str


class KitCheckoutRequest(BaseModel):
    """Payload para baixa de camiseta/kit no guichê."""
    barcode: str = Field(..., min_length=3, max_length=64)
    event_id: int


class KitCheckoutResponse(BaseModel):
    """Confirmação da entrega de kit com tamanho de camiseta (BR-09)."""
    person_id: int
    person_name: str
    tshirt_size: str
    kit_delivered: bool
    kit_delivered_at: datetime
    message: str


class ProjectKitMemberStatus(BaseModel):
    """Status individual de cada membro da equipe para triagem no guichê."""
    person_id: int
    name: str
    role: str
    tshirt_size: str
    presence_confirmed: bool
    kit_delivered: bool
    kit_delivered_at: Optional[datetime] = None


class ProjectKitsSummaryResponse(BaseModel):
    """Visão agregada dos kits e presenças de um trabalho científico."""
    project_id: int
    title: str
    booth_number: Optional[str] = None
    members: List[ProjectKitMemberStatus]
