"""Project submission, members and advisor consent schemas."""

from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel, Field
from app.models.enums import EducationLevelEnum, ProjectMemberRole, ProjectStatus, ProjectType
from app.schemas.pagination import PaginatedResponse


class ProjectMemberInput(BaseModel):
    person_id: int
    role: ProjectMemberRole


class ProjectMemberResponse(BaseModel):
    id: int
    person_id: int
    role: ProjectMemberRole
    created_at: datetime
    person_name: Optional[str] = None
    person_email: Optional[str] = None
    person_cpf: Optional[str] = None
    tshirt_size: Optional[str] = None

    class Config:
        from_attributes = True


class ProjectCreate(BaseModel):
    event_id: int
    subarea_id: int
    education_level: EducationLevelEnum = Field(..., description="Nível de ensino para validação de cotas (BR-04)")
    title: str = Field(..., min_length=5, max_length=255)
    project_type: ProjectType = ProjectType.SCIENTIFIC
    abstract: Optional[str] = None
    needs_electricity: bool = Field(default=False, description="Necessita de ponto de energia elétrica")
    needs_table: bool = Field(default=False, description="Necessita de mesa/bancada para protótipo")
    booth_number: Optional[str] = Field(default=None, description="Número da bancada (opcional na criação)")
    auto_homologate: bool = Field(default=False, description="Se deve auto-homologar o projeto na criação")
    members: List[ProjectMemberInput] = Field(..., min_length=2, description="Equipe com alunos e orientador")


class ProjectUpdate(BaseModel):
    title: Optional[str] = Field(None, min_length=3, max_length=255)
    project_type: Optional[ProjectType] = None
    education_level: Optional[EducationLevelEnum] = None
    abstract: Optional[str] = None
    subarea_id: Optional[int] = None
    booth_number: Optional[str] = None
    needs_electricity: Optional[bool] = None
    needs_table: Optional[bool] = None
    members: Optional[List[ProjectMemberInput]] = Field(None, min_length=2, description="Atualização completa da equipe")


class ProjectResponse(BaseModel):
    id: int
    event_id: int
    subarea_id: int
    subarea_name: Optional[str] = None
    area_name: Optional[str] = None
    title: str
    project_type: ProjectType
    education_level: EducationLevelEnum
    abstract: Optional[str] = None
    summary_file_url: Optional[str] = None
    banner_file_url: Optional[str] = None
    logbook_file_url: Optional[str] = None
    booth_number: Optional[str] = None
    rejection_reason: Optional[str] = None
    qrcode_token: str
    status: ProjectStatus
    advisor_consent: bool
    advisor_consent_at: Optional[datetime] = None
    needs_electricity: bool = False
    needs_table: bool = False
    created_at: datetime
    updated_at: datetime
    members: Optional[List[ProjectMemberResponse]] = None

    class Config:
        from_attributes = True


class PaginatedProjectResponse(PaginatedResponse[ProjectResponse]):
    """Resposta paginada para listagem de projetos (Regra BR-18)."""
    pass


class AdvisorConsentResponse(BaseModel):
    project_id: int
    advisor_id: int
    advisor_name: str
    advisor_consent: bool
    advisor_consent_at: datetime
    new_status: ProjectStatus
    message: str


class ProjectHomologateRequest(BaseModel):
    """Payload para homologação da coordenação (BR-06)."""
    homologated: bool = Field(..., description="True para homologar, False para reprovar/indeferir")
    booth_number: Optional[str] = Field(None, max_length=32, description="Número de estande alocado")
    rejection_reason: Optional[str] = Field(None, description="Justificativa caso reprovado")


class ProjectBoothAssignmentRequest(BaseModel):
    """Payload para alocação direta de estande de apresentação."""
    booth_number: str = Field(..., min_length=1, max_length=32, description="Código do estande (ex: A-12)")


class ProjectBatchMemberInput(BaseModel):
    """Integrante informado no lote CSV para o projeto."""
    name: str = Field(..., min_length=2, max_length=255, description="Nome completo do integrante")
    email: str = Field(..., min_length=5, max_length=255, description="E-mail do integrante")
    role: ProjectMemberRole = Field(..., description="Papel do integrante (STUDENT_LEADER, STUDENT_MEMBER, ADVISOR, COADVISOR)")
    cpf: Optional[str] = Field(default=None, max_length=20, description="CPF do integrante (com ou sem pontuação)")
    affiliation: Optional[str] = Field(default=None, max_length=100, description="Instituição ou afiliação escolar do integrante")
    tshirt_size: Optional[str] = Field(default="M", max_length=10, description="Tamanho de camiseta do participante (PP, P, M, G, GG, XG)")


class ProjectBatchItem(BaseModel):
    """Item de projeto a ser importado / sincronizado em lote."""
    title: str = Field(..., min_length=3, max_length=255, description="Título do trabalho")
    project_type: ProjectType = Field(default=ProjectType.SCIENTIFIC, description="Tipo do projeto (SCIENTIFIC ou TECHNOLOGICAL)")
    education_level: EducationLevelEnum = Field(default=EducationLevelEnum.MEDIO, description="Nível de ensino")
    subarea_name: str = Field(..., min_length=2, max_length=150, description="Nome da subárea temática")
    booth_number: Optional[str] = Field(None, max_length=32, description="Número/código do estande")
    abstract: Optional[str] = Field(None, description="Resumo do trabalho")
    needs_electricity: bool = Field(default=False, description="Necessita de ponto de energia")
    needs_table: bool = Field(default=False, description="Necessita de mesa para protótipo")
    members: List[ProjectBatchMemberInput] = Field(default_factory=list, description="Lista de integrantes (orientador e estudantes)")
    auto_homologate: Optional[bool] = Field(None, description="Se deve ser importado já homologado")


class ProjectBatchImport(BaseModel):
    """Payload de importação em lote de trabalhos científicos."""
    items: List[ProjectBatchItem] = Field(..., min_length=1, description="Lista de trabalhos para importação")
    auto_homologate: bool = Field(default=True, description="Homologar trabalhos e aprovar anuência automaticamente")


class ProjectBatchResponse(BaseModel):
    """Resultado da importação em lote de projetos."""
    total: int = Field(..., description="Total de trabalhos processados")
    created_count: int = Field(..., description="Trabalhos novos cadastrados")
    updated_count: int = Field(..., description="Trabalhos existentes atualizados")
    participants_created_count: int = Field(..., description="Novos participantes (estudantes/orientadores) criados no sistema")
    items: List[ProjectResponse] = Field(..., description="Lista de projetos resultantes")


