"""Schemas package aggregator."""

from app.schemas.auth import (
    AdminLoginRequest,
    OTPRequest,
    OTPVerifyRequest,
    TokenResponse,
    UserProfileResponse,
    RegisterRequestCodeRequest,
    RegisterRequestCodeResponse,
    RegisterCompleteRequest
)
from app.schemas.person import (
    PersonCreate,
    PersonResponse,
    ParticipantItemResponse,
    ParticipantDetailResponse,
    ParticipantCreateRequest,
    ParticipantUpdateRequest,
    PaginatedParticipantsResponse
)
from app.schemas.event import (
    EventCreate,
    EventUpdate,
    EventResponse,
    EventStageCreate,
    EventStageResponse,
    EducationLevelCreate,
    EducationLevelResponse
)
from app.schemas.event_admin import (
    EventAdminItem,
    EventAdminCreate,
    EventAdminUpdate,
    EventAdminListResponse
)
from app.schemas.knowledge_area import (
    KnowledgeAreaCreate,
    KnowledgeAreaUpdate,
    KnowledgeAreaResponse,
    SubareaCreate,
    SubareaUpdate,
    SubareaResponse
)
from app.schemas.award import (
    AwardCreate,
    AwardUpdate,
    AwardResponse,
    AwardCriterionLinkInput,
    AwardCriterionResponse,
    AwardStandingItemResponse,
    AwardStandingsResponse
)
from app.schemas.project import (
    ProjectCreate,
    ProjectUpdate,
    ProjectResponse,
    ProjectMemberInput,
    ProjectMemberResponse,
    AdvisorConsentResponse,
    ProjectHomologateRequest,
    ProjectBoothAssignmentRequest
)
from app.schemas.logistics import (
    BarcodeScanRequest,
    BarcodeScanResponse,
    KitCheckoutRequest,
    KitCheckoutResponse,
    ProjectKitMemberStatus,
    ProjectKitsSummaryResponse,
    ScanProjectItem
)
from app.schemas.dashboard import (
    AreaEvaluationProgress,
    PublicTvDashboardResponse,
    ProjectRankingItemResponse,
    AreaLevelLeaderboardGroup,
    LevelLeaderboardGroup,
    OverallLeaderboardResponse
)
from app.schemas.allocation import (
    EvaluatorQualificationRequest,
    EvaluatorQualificationResponse,
    AutoBalanceRequest,
    AutoBalanceSummaryResponse,
    ManualAllocationRequest,
    AllocationResponse
)
from app.schemas.evaluation import (
    EvaluationItemInput,
    EvaluationItemResponse,
    EvaluationCreate,
    EvaluationResponse,
    EvaluationCriterionSheetItem,
    EvaluationSheetResponse,
    ProjectEvaluationSummaryResponse
)
from app.schemas.snack import (
    SnackMomentCreate,
    SnackMomentUpdate,
    SnackMomentResponse,
    SnackDeliverScanRequest,
    SnackDeliverScanResponse,
    SnackDeliveryItemResponse,
    SnackMomentReportResponse
)

__all__ = [
    "AdminLoginRequest",
    "OTPRequest",
    "OTPVerifyRequest",
    "TokenResponse",
    "UserProfileResponse",
    "RegisterRequestCodeRequest",
    "RegisterRequestCodeResponse",
    "RegisterCompleteRequest",
    "PersonCreate",
    "PersonResponse",
    "EventCreate",
    "EventUpdate",
    "EventResponse",
    "EventStageCreate",
    "EventStageResponse",
    "EducationLevelCreate",
    "EducationLevelResponse",
    "EventAdminItem",
    "EventAdminCreate",
    "EventAdminUpdate",
    "EventAdminListResponse",
    "KnowledgeAreaCreate",
    "KnowledgeAreaUpdate",
    "KnowledgeAreaResponse",
    "SubareaCreate",
    "SubareaUpdate",
    "SubareaResponse",
    "AwardCreate",
    "AwardUpdate",
    "AwardResponse",
    "AwardCriterionLinkInput",
    "AwardCriterionResponse",
    "AwardStandingItemResponse",
    "AwardStandingsResponse",
    "ProjectCreate",
    "ProjectUpdate",
    "ProjectResponse",
    "ProjectMemberInput",
    "ProjectMemberResponse",
    "AdvisorConsentResponse",
    "ProjectHomologateRequest",
    "ProjectBoothAssignmentRequest",
    "BarcodeScanRequest",
    "BarcodeScanResponse",
    "KitCheckoutRequest",
    "KitCheckoutResponse",
    "ProjectKitMemberStatus",
    "ProjectKitsSummaryResponse",
    "ScanProjectItem",
    "AreaEvaluationProgress",
    "PublicTvDashboardResponse",
    "ProjectRankingItemResponse",
    "AreaLevelLeaderboardGroup",
    "LevelLeaderboardGroup",
    "OverallLeaderboardResponse",
    "EvaluatorQualificationRequest",
    "EvaluatorQualificationResponse",
    "AutoBalanceRequest",
    "AutoBalanceSummaryResponse",
    "ManualAllocationRequest",
    "AllocationResponse",
    "EvaluationItemInput",
    "EvaluationItemResponse",
    "EvaluationCreate",
    "EvaluationResponse",
    "EvaluationCriterionSheetItem",
    "EvaluationSheetResponse",
    "ProjectEvaluationSummaryResponse",
    "SnackMomentCreate",
    "SnackMomentUpdate",
    "SnackMomentResponse",
    "SnackDeliverScanRequest",
    "SnackDeliverScanResponse",
    "SnackDeliveryItemResponse",
    "SnackMomentReportResponse",
]


