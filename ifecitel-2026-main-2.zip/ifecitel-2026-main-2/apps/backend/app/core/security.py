"""Security utilities: password hashing, 8-character OTP generator, and JWT tokens."""

import random
import string
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Optional
import jwt
from passlib.context import CryptContext

from app.core.config import settings

# Contexto de criptografia de senhas mestres com bcrypt (salt rounds = 12)
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verifica se a senha em texto puro coincide com o hash bcrypt armazenado."""
    return pwd_context.verify(plain_password, hashed_password)


def get_password_hash(password: str) -> str:
    """Gera um hash bcrypt de alta entropia para a senha mestre."""
    return pwd_context.hash(password)


def generate_access_code(year: Optional[int] = None) -> str:
    """
    Gera o código de acesso OTP exclusivo de 8 caracteres em caixa alta (Regra SEC-01):
    - 2 primeiros caracteres: Últimos 2 dígitos do ano (ex: '26' para 2026).
    - Demais 6 caracteres: Exatamente 4 letras maiúsculas e 2 dígitos numéricos aleatórios.
    """
    if year is None:
        year = datetime.now(timezone.utc).year

    year_prefix = str(year)[-2:]

    # Selecionar exatamente 4 letras maiúsculas (excluindo caracteres ambíguos se desejado, mas A-Z completo é padrão)
    # Evitando letras que possam gerar confusão visual extrema se necessário, mas mantendo regras estritas
    letters = random.choices(string.ascii_uppercase, k=4)
    digits = random.choices(string.digits, k=2)

    # Combinar e embaralhar os 6 caracteres restantes
    suffix_chars = letters + digits
    random.shuffle(suffix_chars)

    code = f"{year_prefix}{''.join(suffix_chars)}"
    return code.upper()


def hash_access_code(code: str) -> str:
    """Gera hash seguro para o código OTP de acesso antes de gravar no banco."""
    return pwd_context.hash(code.upper().strip())


def verify_access_code(plain_code: str, hashed_code: str) -> bool:
    """Valida se o código de acesso digitado pelo participante confere com o hash."""
    return pwd_context.verify(plain_code.upper().strip(), hashed_code)


def create_access_token(
    subject: str,
    claims: Optional[Dict[str, Any]] = None,
    expires_delta: Optional[timedelta] = None
) -> str:
    """Emite um token JWT assinado com validade padrão de 12 horas (Regra SEC-02)."""
    now = datetime.now(timezone.utc)
    if expires_delta:
        expire = now + expires_delta
    else:
        expire = now + timedelta(hours=settings.ACCESS_TOKEN_EXPIRE_HOURS)

    to_encode: Dict[str, Any] = {
        "sub": str(subject),
        "iat": int(now.timestamp()),
        "exp": int(expire.timestamp())
    }

    if claims:
        to_encode.update(claims)

    encoded_jwt = jwt.encode(
        to_encode,
        settings.JWT_SECRET_KEY,
        algorithm=settings.JWT_ALGORITHM
    )
    return encoded_jwt


def decode_access_token(token: str) -> Optional[Dict[str, Any]]:
    """Decodifica e valida o token JWT recebido no cabeçalho Authorization: Bearer."""
    try:
        payload = jwt.decode(
            token,
            settings.JWT_SECRET_KEY,
            algorithms=[settings.JWT_ALGORITHM]
        )
        return payload
    except (jwt.PyJWTError, ValueError):
        return None
