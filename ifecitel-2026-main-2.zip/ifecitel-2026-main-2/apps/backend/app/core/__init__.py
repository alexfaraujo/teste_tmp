"""Core module: configurations, database and security."""
