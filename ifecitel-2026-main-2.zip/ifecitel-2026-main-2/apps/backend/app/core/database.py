"""Asynchronous database engine, session factory and base model."""

from collections.abc import AsyncGenerator
from sqlalchemy.ext.asyncio import (
    AsyncSession,
    async_sessionmaker,
    create_async_engine
)
from sqlalchemy.orm import DeclarativeBase
from app.core.config import settings

# Engine assíncrona para PostgreSQL bare-metal com asyncpg
engine = create_async_engine(
    settings.DATABASE_URL,
    echo=settings.DEBUG,
    future=True,
    pool_pre_ping=True,
    pool_recycle=1800,
    pool_timeout=30,
    pool_size=20,
    max_overflow=30
)

# Fábrica de sessões assíncronas
AsyncSessionLocal = async_sessionmaker(
    bind=engine,
    class_=AsyncSession,
    autoflush=False,
    expire_on_commit=False
)


class Base(DeclarativeBase):
    """Classe base declarativa do SQLAlchemy 2.0 para todos os modelos."""
    pass


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """Injeção de dependência assíncrona do FastAPI para fornecer a sessão de banco de dados."""
    async with AsyncSessionLocal() as session:
        try:
            yield session
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()
