import os
import re
import urllib.parse
from pathlib import Path
from typing import List, Optional
from pydantic import model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict
from sqlalchemy.engine import URL, make_url

_BACKEND_DIR = Path(__file__).resolve().parents[2]
_BACKEND_ENV = _BACKEND_DIR / ".env"
_REPO_ROOT = Path(__file__).resolve().parents[4]
_ROOT_ENV = _REPO_ROOT / ".env"
_DEFAULT_UPLOAD_DIR = str(_REPO_ROOT / "storage" / "uploads")


def _build_safe_database_url(
    raw_url: str,
    db_user: Optional[str] = None,
    db_password: Optional[str] = None,
    db_host: Optional[str] = None,
    db_port: Optional[int] = None,
    db_name: Optional[str] = None,
    db_driver: str = "postgresql+asyncpg",
) -> str:
    """
    Constrói ou higieniza a URL do banco de dados, tratando com segurança
    caracteres especiais na senha (@, #, $, %, :, /, etc.).
    """
    # 1. Se variáveis discretas foram informadas no .env, constrói URL com escape seguro via URL.create
    if db_user and db_password is not None:
        host = db_host or "127.0.0.1"
        port = db_port or 5432
        database = db_name or "fecitel_db"
        driver = db_driver or "postgresql+asyncpg"
        return URL.create(
            drivername=driver,
            username=db_user,
            password=db_password,
            host=host,
            port=port,
            database=database,
        ).render_as_string(hide_password=False)

    if not raw_url:
        return raw_url

    # 2. Se a URL já for limpa e o make_url parsear sem ambiguidade
    try:
        scheme_rest = raw_url.split("://", 1)
        if len(scheme_rest) == 2:
            _, rest = scheme_rest
            if "@" in rest:
                userinfo, _ = rest.rsplit("@", 1)
                # Se não tem múltiplos @ e não tem # literal no userinfo:
                if "@" not in userinfo and "#" not in userinfo:
                    parsed = make_url(raw_url)
                    if parsed.host and not any(ch in parsed.host for ch in ("@", "#", ":", "/")):
                        return raw_url
    except Exception:
        pass

    # 3. Caso a senha contenha caracteres especiais não escapados (@, #, $, %, etc.)
    pattern = r"^(?P<driver>[a-zA-Z0-9_+]+)://(?P<user>[^:/]+):(?P<password>.+)@(?P<host>[^:/@]+)(?::(?P<port>\d+))?/(?P<db>[^?]+)(?:\?(?P<query>.*))?$"
    match = re.match(pattern, raw_url)
    if not match:
        return raw_url

    d = match.groupdict()
    query_args = {}
    if d.get("query"):
        query_args = dict(urllib.parse.parse_qsl(d["query"]))

    safe_url = URL.create(
        drivername=d["driver"],
        username=urllib.parse.unquote(d["user"]),
        password=d["password"],  # senha bruta com caracteres especiais escapada nativamente
        host=d["host"],
        port=int(d["port"]) if d.get("port") else None,
        database=d["db"],
        query=query_args
    )
    return safe_url.render_as_string(hide_password=False)


class Settings(BaseSettings):
    """Configurações centrais da aplicação carregadas do arquivo .env."""

    # Aplicação
    PROJECT_NAME: str = "EasyEvent API"
    VERSION: str = "1.0.0"
    ENVIRONMENT: str = "development"
    DEBUG: bool = True
    HOST: str = "127.0.0.1"
    PORT: int = 8000

    # CORS
    CORS_ORIGINS: List[str] = [
        "http://localhost:3000",
        "http://localhost:3001",
        "http://localhost:3002",
        "http://localhost:3003",
        "http://127.0.0.1:3000",
        "http://127.0.0.1:3001",
        "http://127.0.0.1:3002",
        "http://127.0.0.1:3003",
    ]

    # Banco de Dados PostgreSQL (asyncpg nativo)
    # Variáveis opcionais para configuração granular (trata senhas com caracteres especiais sem necessidade de URL encoding)
    DB_USER: Optional[str] = None
    DB_PASSWORD: Optional[str] = None
    DB_HOST: Optional[str] = None
    DB_PORT: Optional[int] = None
    DB_NAME: Optional[str] = None
    DB_DRIVER: str = "postgresql+asyncpg"

    DATABASE_URL: str = "postgresql+asyncpg://fecitel_user:fecitel_secret_2026@127.0.0.1:5432/fecitel_db"

    @model_validator(mode="after")
    def validate_database_url(self) -> "Settings":
        """Garante que a DATABASE_URL esteja adequadamente formatada e com caracteres especiais escapados."""
        self.DATABASE_URL = _build_safe_database_url(
            raw_url=self.DATABASE_URL,
            db_user=self.DB_USER,
            db_password=self.DB_PASSWORD,
            db_host=self.DB_HOST,
            db_port=self.DB_PORT,
            db_name=self.DB_NAME,
            db_driver=self.DB_DRIVER,
        )
        return self

    # Segurança e Criptografia
    JWT_SECRET_KEY: str = "sua_chave_secreta_super_segura_de_no_minimo_32_caracteres_fecitel"
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_HOURS: int = 12
    API_KEY: str = "fecitel_secret_api_key_2026"
    API_KEY_NAME: str = "X-API-Key"

    # Servidor SMTP de Notificações por E-mail
    SMTP_HOST: str = "localhost"
    SMTP_PORT: int = 25
    SMTP_USER: str = "notificacoes@fecitel.ifms.edu.br"
    SMTP_PASSWORD: str = ""
    SMTP_FROM: str = "nao-responda@fecitel.ifms.edu.br"

    @property
    def smtp_host(self) -> str:
        return self.SMTP_HOST

    @property
    def smtp_port(self) -> int:
        return self.SMTP_PORT

    @property
    def email_address(self) -> str:
        return self.SMTP_FROM

    # Uploads e Arquivos
    UPLOAD_DIR: str = _DEFAULT_UPLOAD_DIR
    MAX_FILE_SIZE_MB: int = 20

    model_config = SettingsConfigDict(
        env_file=(_BACKEND_ENV, _ROOT_ENV, ".env"),
        env_file_encoding="utf-8",
        extra="ignore"
    )


settings = Settings()
