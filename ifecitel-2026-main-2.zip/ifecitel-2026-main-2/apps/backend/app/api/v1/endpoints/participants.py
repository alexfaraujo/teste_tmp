"""Endpoints for participant management in the active event (Regra BR-18 e BR-19)."""

from typing import Optional
from fastapi import APIRouter, Depends, Query, Response, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_admin, get_event_admin_access
from app.core.database import get_db
from app.models.enums import UserRole, EventAdminRole
from app.models.person import Person
from app.schemas.person import (
    PaginatedParticipantsResponse,
    ParticipantBatchImport,
    ParticipantBatchResponse,
    ParticipantCreateRequest,
    ParticipantDetailResponse,
    ParticipantItemResponse,
    ParticipantUpdateRequest,
)
from app.services import participant_service

router = APIRouter(prefix="/participants", tags=["Gestão de Participantes"])


@router.get(
    "",
    response_model=PaginatedParticipantsResponse,
    status_code=status.HTTP_200_OK,
    summary="Listar participantes da edição com paginação real e filtros (BR-18)"
)
async def list_participants(
    event_id: int = Query(..., description="ID da edição do evento ativo"),
    page: int = Query(1, ge=1, description="Número da página (1-indexed)"),
    limit: int = Query(15, ge=1, le=1000, description="Itens por página (padrão 15, máx 1000)"),
    search: Optional[str] = Query(None, description="Busca textual por nome, e-mail, CPF ou código de barras"),
    role: Optional[UserRole] = Query(None, description="Filtrar por papel (STUDENT, ADVISOR, EVALUATOR, etc.)"),
    presence: Optional[bool] = Query(None, description="Filtrar por presença física confirmada"),
    kit_delivered: Optional[bool] = Query(None, description="Filtrar por entrega de kit de camiseta"),
    db: AsyncSession = Depends(get_db),
    admin: Person = Depends(get_current_admin)
):
    """Retorna listagem paginada de participantes vinculados à edição ativa."""
    await get_event_admin_access(event_id, min_role=EventAdminRole.ORGANIZER, db=db, admin=admin)
    return await participant_service.list_participants(
        db=db,
        event_id=event_id,
        page=page,
        limit=limit,
        search=search,
        role=role,
        presence=presence,
        kit_delivered=kit_delivered,
    )


@router.get(
    "/{person_id}",
    response_model=ParticipantDetailResponse,
    status_code=status.HTTP_200_OK,
    summary="Consultar detalhes de um participante específico no evento"
)
async def get_participant(
    person_id: int,
    event_id: int = Query(..., description="ID da edição do evento ativo"),
    db: AsyncSession = Depends(get_db),
    admin: Person = Depends(get_current_admin)
):
    """Retorna dados cadastrais e os papéis que o participante desempenha no evento."""
    await get_event_admin_access(event_id, min_role=EventAdminRole.ORGANIZER, db=db, admin=admin)
    return await participant_service.get_participant(
        db=db,
        event_id=event_id,
        person_id=person_id,
    )


@router.post(
    "",
    response_model=ParticipantItemResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Cadastrar ou vincular participante avulso à edição ativa"
)
async def register_participant(
    payload: ParticipantCreateRequest,
    event_id: int = Query(..., description="ID da edição do evento ativo"),
    db: AsyncSession = Depends(get_db),
    admin: Person = Depends(get_current_admin)
):
    """Cadastra um participante avulso ou vincula pessoa existente ao evento ativo."""
    await get_event_admin_access(event_id, min_role=EventAdminRole.ORGANIZER, db=db, admin=admin)
    return await participant_service.create_participant(
        db=db,
        event_id=event_id,
        payload=payload,
    )


@router.post(
    "/batch",
    response_model=ParticipantBatchResponse,
    status_code=status.HTTP_200_OK,
    summary="Importar / sincronizar em lote participantes do evento via CSV/JSON (BR-26)"
)
async def import_participants_batch(
    payload: ParticipantBatchImport,
    event_id: int = Query(..., description="ID da edição do evento ativo"),
    db: AsyncSession = Depends(get_db),
    admin: Person = Depends(get_current_admin)
):
    """
    Importa em lote participantes atribuindo múltiplos papéis, subáreas e níveis de ensino com idempotência.
    """
    await get_event_admin_access(event_id, min_role=EventAdminRole.ORGANIZER, db=db, admin=admin)
    return await participant_service.import_participants_batch(
        db=db,
        event_id=event_id,
        payload=payload,
    )


@router.patch(
    "/{person_id}",
    response_model=ParticipantItemResponse,
    status_code=status.HTTP_200_OK,
    summary="Atualizar dados cadastrais e de logística de um participante"
)
async def update_participant(
    person_id: int,
    payload: ParticipantUpdateRequest,
    event_id: int = Query(..., description="ID da edição do evento ativo"),
    db: AsyncSession = Depends(get_db),
    admin: Person = Depends(get_current_admin)
):
    """Permite corrigir erros de importação (nome, CPF, afiliação) ou reatribuir papel."""
    await get_event_admin_access(event_id, min_role=EventAdminRole.ORGANIZER, db=db, admin=admin)
    return await participant_service.update_participant(
        db=db,
        event_id=event_id,
        person_id=person_id,
        payload=payload,
    )


@router.delete(
    "/{person_id}",
    status_code=status.HTTP_200_OK,
    summary="Desvincular participante do evento ativo (com trava de integridade)"
)
async def delete_participant(
    person_id: int,
    event_id: int = Query(..., description="ID da edição do evento ativo"),
    db: AsyncSession = Depends(get_db),
    admin: Person = Depends(get_current_admin)
):
    """Desvincula o participante do evento caso não seja membro ativo de nenhum projeto na feira."""
    await get_event_admin_access(event_id, min_role=EventAdminRole.ORGANIZER, db=db, admin=admin)
    return await participant_service.delete_participant(
        db=db,
        event_id=event_id,
        person_id=person_id,
    )


@router.get(
    "/{participant_id}/badge/pdf",
    summary="Exportar crachá individual do participante em formato PDF",
)
async def export_participant_badge_pdf(
    participant_id: int,
    event_id: int = Query(..., description="ID da edição do evento ativo"),
    db: AsyncSession = Depends(get_db),
    admin: Person = Depends(get_current_admin),
):
    """Gera o PDF com o crachá avulso do participante para impressão imediata."""
    await get_event_admin_access(event_id, min_role=EventAdminRole.OPERATOR, db=db, admin=admin)
    from app.services.badge_service import generate_participant_badge_pdf

    pdf_bytes = await generate_participant_badge_pdf(db, event_id, participant_id)
    filename = f"cracha_participante_{participant_id}.pdf"

    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
            "Cache-Control": "no-cache",
        },
    )
