"""Awards and criteria association endpoints (Regra BR-17)."""

from typing import List
from fastapi import APIRouter, Depends, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_admin, get_event_admin_access
from app.core.database import get_db
from app.models.enums import EventAdminRole
from app.models.person import Person
from app.schemas.award import (
    AwardCreate,
    AwardCriterionLinkInput,
    AwardResponse,
    AwardStandingsResponse,
    AwardUpdate
)
from app.services import award_service


router = APIRouter(tags=["Premiações"])


@router.post(
    "/events/{event_id}/awards",
    response_model=AwardResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Cadastrar premiação especial no painel do evento (BR-17)"
)
async def create_award(
    event_id: int,
    payload: AwardCreate,
    db: AsyncSession = Depends(get_db),
    admin: Person = Depends(get_current_admin)
):
    """Cadastra um novo prêmio ou menção honrosa vinculado à edição do evento."""
    await get_event_admin_access(event_id, min_role=EventAdminRole.ORGANIZER, db=db, admin=admin)
    return await award_service.create_award(db, event_id, payload)


@router.get(
    "/events/{event_id}/awards",
    response_model=List[AwardResponse],
    status_code=status.HTTP_200_OK,
    summary="Listar premiações de uma edição do evento"
)
async def list_awards(
    event_id: int,
    db: AsyncSession = Depends(get_db)
):
    """Lista todas as premiações cadastradas e os critérios de avaliação associados."""
    return await award_service.list_awards(db, event_id)


@router.post(
    "/awards/{award_id}/criteria",
    response_model=AwardResponse,
    status_code=status.HTTP_200_OK,
    summary="Vincular perguntas/critérios da avaliação à premiação (BR-17)"
)
async def link_criteria_to_award(
    award_id: int,
    payload: List[AwardCriterionLinkInput],
    db: AsyncSession = Depends(get_db),
    admin: Person = Depends(get_current_admin)
):
    """Associa as perguntas da ficha de avaliação que compõem a nota da premiação."""
    return await award_service.link_criteria_to_award(db, award_id, payload)


@router.put(
    "/awards/{award_id}",
    response_model=AwardResponse,
    status_code=status.HTTP_200_OK,
    summary="Atualizar dados cadastrais ou critérios de uma premiação"
)
async def update_award(
    award_id: int,
    payload: AwardUpdate,
    db: AsyncSession = Depends(get_db),
    admin: Person = Depends(get_current_admin)
):
    """Atualiza o nome, patrocinador, descrição e opcionalmente os critérios vinculados."""
    return await award_service.update_award(db, award_id, payload)


@router.delete(
    "/awards/{award_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Desativar (soft-delete) uma premiação"
)
async def delete_award(
    award_id: int,
    db: AsyncSession = Depends(get_db),
    admin: Person = Depends(get_current_admin)
):
    """Desativa logicamente uma premiação e seus vínculos com critérios."""
    await award_service.delete_award(db, award_id)


@router.get(
    "/awards/{award_id}/standings",
    response_model=AwardStandingsResponse,
    status_code=status.HTTP_200_OK,
    summary="Ranking 2: Classificação oficial de Prêmio Específico (BR-17)"
)
async def get_award_standings(
    award_id: int,
    db: AsyncSession = Depends(get_db),
    admin: Person = Depends(get_current_admin)
):
    """
    Apuração do Ranking 2 baseada exclusivamente nas notas dos critérios indicados
    para a premiação específica e seus respectivos pesos ponderados.
    Acesso restrito à coordenação do evento para sigilo até a cerimônia oficial.
    """
    return await award_service.get_award_standings(db, award_id)

