"""Endpoints for evaluator allocations and qualifications (Regra BR-10)."""

from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_admin, get_current_evaluator, get_current_user, get_event_admin_access
from app.core.database import get_db
from app.models.enums import EventAdminRole
from app.models.evaluation import EvaluatorAllocation
from app.models.person import Person
from app.schemas.allocation import (
    AllocationResponse,
    AutoBalanceRequest,
    AutoBalanceSummaryResponse,
    EvaluatorCheckinAllocationResponse,
    EvaluatorListItem,
    EvaluatorQualificationRequest,
    EvaluatorQualificationResponse,
    EvaluatorScanCheckinRequest,
    ManualAllocationRequest
)
from app.services import allocation_service, evaluation_service

router = APIRouter(prefix="/allocations", tags=["Alocação de Avaliadores"])


@router.get(
    "/evaluators",
    response_model=List[EvaluatorListItem],
    status_code=status.HTTP_200_OK,
    summary="Listar avaliadores do evento com subáreas qualificadas e presença (BR-10)"
)
async def list_evaluators(
    event_id: int = Query(..., description="ID da edição do evento ativo"),
    db: AsyncSession = Depends(get_db),
    admin: Person = Depends(get_current_admin)
):
    """
    Retorna todos os avaliadores cadastrados no evento, incluindo suas subáreas de conhecimento
    e grandes áreas vinculadas, presença física e contagem de alocações ativas.
    """
    await get_event_admin_access(event_id, min_role=EventAdminRole.OPERATOR, db=db, admin=admin)
    return await allocation_service.list_event_evaluators(db, event_id)


@router.post(
    "/qualify",
    response_model=EvaluatorQualificationResponse,
    status_code=status.HTTP_200_OK,
    summary="Vincular subáreas de conhecimento ao avaliador (BR-10)"
)
async def qualify_evaluator(
    payload: EvaluatorQualificationRequest,
    db: AsyncSession = Depends(get_db),
    admin: Person = Depends(get_current_admin)
):
    """Permite ao Administrador vincular as subáreas de especialidade de um avaliador."""
    await get_event_admin_access(payload.event_id, min_role=EventAdminRole.ORGANIZER, db=db, admin=admin)
    return await allocation_service.qualify_evaluator_subareas(db, payload)


@router.post(
    "/evaluators/scan-checkin",
    response_model=EvaluatorCheckinAllocationResponse,
    status_code=status.HTTP_200_OK,
    summary="Check-in por leitura de código de barras / QR Code / CPF na Sala dos Avaliadores (BR-10)"
)
async def scan_evaluator_checkin(
    payload: EvaluatorScanCheckinRequest,
    db: AsyncSession = Depends(get_db),
    admin: Person = Depends(get_current_admin)
):
    """
    Realiza o check-in presencial do avaliador na Sala dos Avaliadores via bipagem de crachá,
    QR code ou CPF, confirmando sua presença na comissão e disparando a alocação dinâmica imediata.
    """
    return await allocation_service.scan_evaluator_checkin(db, payload)


@router.post(
    "/evaluators/{evaluator_id}/checkin",
    response_model=EvaluatorCheckinAllocationResponse,
    status_code=status.HTTP_200_OK,
    summary="Check-in presencial do avaliador com alocação dinâmica automática (Momento 1) (BR-10)"
)
async def checkin_evaluator_and_allocate(
    evaluator_id: int,
    event_id: int = Query(..., description="ID da edição do evento ativo"),
    db: AsyncSession = Depends(get_db),
    admin: Person = Depends(get_current_admin)
):
    """
    Confirma a presença física do avaliador no evento e dispara a alocação dinâmica automática.
    Seleciona projetos da mesma subárea que já estejam PRESENTES na feira, priorizando os que
    possuem menor número de avaliadores atribuídos (Regra de Ouro delta <= 1).
    """
    return await allocation_service.allocate_evaluator_on_checkin(db, event_id, evaluator_id)


@router.post(
    "/auto-balance",
    response_model=AutoBalanceSummaryResponse,
    status_code=status.HTTP_200_OK,
    summary="Disparar algoritmo de distribuição balanceada pós-checkin (Momento 1) (BR-10)"
)
async def auto_balance_allocations(
    payload: AutoBalanceRequest,
    db: AsyncSession = Depends(get_db),
    admin: Person = Depends(get_current_admin)
):
    """
    Executa o algoritmo guloso balanceado de alocação de avaliadores pós-checkin.
    Distribui exclusivamente para projetos PRESENT, respeita subáreas, teto de carga,
    evita conflitos e garante a Regra de Ouro (delta <= 1 entre projetos da mesma subárea).
    """
    await get_event_admin_access(payload.event_id, min_role=EventAdminRole.ORGANIZER, db=db, admin=admin)
    return await allocation_service.run_auto_balance_allocation(db, payload)


@router.post(
    "/manual",
    response_model=AllocationResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Alocação manual ou remanejamento pelo Administrador (Momento 2) (BR-10)"
)
async def manual_allocation(
    payload: ManualAllocationRequest,
    db: AsyncSession = Depends(get_db),
    admin: Person = Depends(get_current_admin)
):
    """Permite ao Administrador vincular ou remanejar manualmente um avaliador para um projeto."""
    await get_event_admin_access(payload.event_id, min_role=EventAdminRole.ORGANIZER, db=db, admin=admin)
    return await allocation_service.manual_allocate(db, payload)


@router.delete(
    "/{allocation_id}",
    response_model=AllocationResponse,
    status_code=status.HTTP_200_OK,
    summary="Cancelar alocação de avaliador"
)
async def cancel_allocation(
    allocation_id: int,
    db: AsyncSession = Depends(get_db),
    admin: Person = Depends(get_current_admin)
):
    """Cancela uma alocação ativa (desde que a avaliação ainda não tenha sido concluída)."""
    alloc = await db.get(EvaluatorAllocation, allocation_id)
    if not alloc or alloc.deleted_at is not None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Alocação não encontrada."
        )
    await get_event_admin_access(alloc.event_id, min_role=EventAdminRole.ORGANIZER, db=db, admin=admin)
    return await allocation_service.cancel_allocation(db, allocation_id)


@router.get(
    "/my",
    response_model=List[AllocationResponse],
    status_code=status.HTTP_200_OK,
    summary="Listar projetos alocados para o avaliador autenticado"
)
async def get_my_allocations(
    event_id: Optional[int] = Query(None, description="ID da edição do evento (opcional)"),
    db: AsyncSession = Depends(get_db),
    evaluator: Person = Depends(get_current_evaluator)
):
    """Retorna os trabalhos que foram atribuídos ao avaliador conectado."""
    return await evaluation_service.get_my_allocations(db, event_id, evaluator)


@router.get(
    "",
    response_model=List[AllocationResponse],
    status_code=status.HTTP_200_OK,
    summary="Listar alocações do evento (com filtros opcionais)"
)
async def list_allocations(
    event_id: int = Query(..., description="ID da edição do evento"),
    project_id: Optional[int] = Query(None, description="Filtrar por ID do projeto"),
    evaluator_id: Optional[int] = Query(None, description="Filtrar por ID do avaliador"),
    status: Optional[str] = Query(None, description="Filtrar por status da alocação (PENDING, COMPLETED, CANCELLED)"),
    db: AsyncSession = Depends(get_db),
    current_user: Person = Depends(get_current_user)
):
    """Lista as alocações da feira com suporte a filtros."""
    if current_user.role.value == "ADMIN":
        await get_event_admin_access(event_id, min_role=EventAdminRole.OPERATOR, db=db, admin=current_user)
    return await allocation_service.list_allocations(db, event_id, project_id, evaluator_id, status)

