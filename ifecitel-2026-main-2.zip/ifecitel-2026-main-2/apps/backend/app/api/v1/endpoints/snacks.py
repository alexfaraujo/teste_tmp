"""Endpoints for snack management and mobile distribution (Rule BR-30)."""

from typing import List, Optional
from fastapi import APIRouter, Body, Depends, Query, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.schemas.snack import (
    SnackDeliverScanRequest,
    SnackDeliverScanResponse,
    SnackEligibleCountResponse,
    SnackMomentCreate,
    SnackMomentReportResponse,
    SnackMomentResponse,
    SnackMomentUpdate,
)
from app.services import snack_service

router = APIRouter(prefix="/snacks", tags=["Lanches e Coffee Break"])


@router.get(
    "/events/{event_id}/eligible-count",
    response_model=SnackEligibleCountResponse,
    status_code=status.HTTP_200_OK,
    summary="Contar participantes elegíveis por público-alvo"
)
async def get_eligible_count(
    event_id: int,
    target_roles: Optional[str] = Query("ALL", description="Público-alvo ('ALL' ou separados por vírgula)"),
    db: AsyncSession = Depends(get_db),
):
    count = await snack_service.get_eligible_participants_count(db, event_id, target_roles)
    return SnackEligibleCountResponse(count=count)



@router.get(
    "/events/{event_id}/moments",
    response_model=List[SnackMomentResponse],
    status_code=status.HTTP_200_OK,
    summary="Listar momentos de lanche cadastrados para a edição do evento"
)
async def list_moments(
    event_id: int,
    db: AsyncSession = Depends(get_db),
):
    return await snack_service.list_snack_moments(db, event_id)


@router.post(
    "/events/{event_id}/moments",
    response_model=SnackMomentResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Criar novo momento de lanche para a edição"
)
async def create_moment(
    event_id: int,
    payload: SnackMomentCreate,
    db: AsyncSession = Depends(get_db),
):
    return await snack_service.create_snack_moment(db, event_id, payload)


@router.get(
    "/moments/{moment_id}",
    response_model=SnackMomentResponse,
    status_code=status.HTTP_200_OK,
    summary="Recuperar dados e estatísticas de um momento de lanche"
)
async def get_moment(
    moment_id: int,
    db: AsyncSession = Depends(get_db),
):
    report = await snack_service.get_snack_moment_report(db, moment_id)
    return report.moment


@router.put(
    "/moments/{moment_id}",
    response_model=SnackMomentResponse,
    status_code=status.HTTP_200_OK,
    summary="Atualizar dados de um momento de lanche"
)
async def update_moment(
    moment_id: int,
    payload: SnackMomentUpdate,
    db: AsyncSession = Depends(get_db),
):
    return await snack_service.update_snack_moment(db, moment_id, payload)


@router.patch(
    "/moments/{moment_id}/toggle",
    response_model=SnackMomentResponse,
    status_code=status.HTTP_200_OK,
    summary="Abrir ou fechar a fila de distribuição de um momento de lanche"
)
async def toggle_moment_active(
    moment_id: int,
    is_active: bool = Query(..., description="Novo estado ativo da distribuição"),
    db: AsyncSession = Depends(get_db),
):
    return await snack_service.toggle_snack_moment_active(db, moment_id, is_active)


@router.delete(
    "/moments/{moment_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Excluir (soft-delete) um momento de lanche"
)
async def delete_moment(
    moment_id: int,
    db: AsyncSession = Depends(get_db),
):
    await snack_service.delete_snack_moment(db, moment_id)
    return None


@router.post(
    "/moments/{moment_id}/deliver",
    response_model=SnackDeliverScanResponse,
    status_code=status.HTTP_200_OK,
    summary="Registrar entrega de lanche via código de barras, CPF ou ID (Regra BR-30)"
)
async def deliver_snack(
    moment_id: int,
    payload: SnackDeliverScanRequest,
    operator_id: Optional[int] = Query(None, description="ID do operador que bipou"),
    db: AsyncSession = Depends(get_db),
):
    return await snack_service.deliver_snack(
        db=db,
        moment_id=moment_id,
        payload=payload,
        operator_user_id=operator_id,
    )


@router.get(
    "/moments/{moment_id}/report",
    response_model=SnackMomentReportResponse,
    status_code=status.HTTP_200_OK,
    summary="Relatório de auditoria e lista de entregas do momento"
)
async def get_moment_report(
    moment_id: int,
    db: AsyncSession = Depends(get_db),
):
    return await snack_service.get_snack_moment_report(db, moment_id)
