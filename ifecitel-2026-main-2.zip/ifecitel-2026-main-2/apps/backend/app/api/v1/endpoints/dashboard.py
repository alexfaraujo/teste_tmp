from typing import List, Optional
from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_admin, get_event_admin_access
from app.core.database import get_db
from app.models.enums import EventAdminRole
from app.models.person import Person
from app.schemas.dashboard import (
    AdminOverviewResponse,
    AreaLevelLeaderboardGroup,
    OverallLeaderboardResponse,
    PublicTvDashboardResponse
)
from app.services import dashboard_service

router = APIRouter(prefix="/dashboard", tags=["Dashboards e Telão"])


@router.get(
    "/public-tv",
    response_model=PublicTvDashboardResponse,
    status_code=status.HTTP_200_OK,
    summary="Métricas agregadas para telões e Smart TVs do pavilhão (BR-14)"
)
async def get_public_tv_dashboard(
    event_id: int = Query(..., description="ID da edição do evento"),
    db: AsyncSession = Depends(get_db)
):
    """
    Retorna métricas puramente agregadas para exibição no modo quiosque em Smart TVs (1080p e 4K).
    Garantia estrita de Sigilo e Fair Play: Não expõe notas individuais, pareceres ou ranqueamentos.
    """
    return await dashboard_service.get_public_tv_metrics(db, event_id)


@router.get(
    "/admin-overview",
    response_model=AdminOverviewResponse,
    status_code=status.HTTP_200_OK,
    summary="Diagnóstico executivo unificado para o Centro de Comando do Administrador (BR-10, BR-14, BR-18)"
)
async def get_admin_overview_dashboard(
    event_id: int = Query(..., description="ID da edição do evento ativo"),
    db: AsyncSession = Depends(get_db),
    admin: Person = Depends(get_current_admin)
):
    """
    Retorna em requisição única otimizada todas as métricas consolidadas, microdetalhes operacionais,
    termômetro de risco por área, trabalhos críticos desassistidos e status de balanceamento.
    Valida se o usuário pertence à equipe da respectiva feira (Regra BR-23).
    """
    await get_event_admin_access(event_id, min_role=EventAdminRole.OPERATOR, db=db, admin=admin)
    return await dashboard_service.get_admin_overview_metrics(db, event_id)


@router.get(
    "/leaderboard/area-level",
    response_model=List[AreaLevelLeaderboardGroup],
    status_code=status.HTTP_200_OK,
    summary="Ranking 1: Classificação por Grande Área e Nível de Ensino (BR-12)"
)
async def get_area_level_leaderboard(
    event_id: int = Query(..., description="ID da edição do evento"),
    area_id: Optional[int] = Query(None, description="Filtrar por Grande Área específica"),
    education_level: Optional[str] = Query(None, description="Filtrar por Nível de Ensino (MEDIO, FUNDAMENTAL, JUNIOR)"),
    db: AsyncSession = Depends(get_db),
    admin: Person = Depends(get_current_admin)
):
    """
    Apuração do Ranking 1 agrupado por Área do Conhecimento e Nível de Ensino dos cursos do trabalho.
    Calcula a média simples de todas as avaliações concluídas considerando TODOS os itens da ficha.
    Acesso restrito à coordenação do evento para sigilo até a cerimônia de premiação.
    """
    await get_event_admin_access(event_id, min_role=EventAdminRole.ORGANIZER, db=db, admin=admin)
    return await dashboard_service.get_area_level_leaderboard(db, event_id, area_id, education_level)


@router.get(
    "/leaderboard/overall",
    response_model=OverallLeaderboardResponse,
    status_code=status.HTTP_200_OK,
    summary="Ranking 1: Classificação Melhor Geral da Feira (BR-12)"
)
async def get_overall_leaderboard(
    event_id: int = Query(..., description="ID da edição do evento"),
    db: AsyncSession = Depends(get_db),
    admin: Person = Depends(get_current_admin)
):
    """
    Apuração do Ranking 1 com a classificação unificada dos melhores trabalhos de toda a feira.
    Calcula a nota com base em TODOS os itens da ficha de avaliação.
    Acesso restrito à coordenação do evento.
    """
    await get_event_admin_access(event_id, min_role=EventAdminRole.ORGANIZER, db=db, admin=admin)
    return await dashboard_service.get_overall_leaderboard(db, event_id)


