"""Logistics, barcode check-in and kit delivery endpoints (Regras BR-08 e BR-09)."""

from fastapi import APIRouter, Depends, Query, Response, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.schemas.logistics import (
    BarcodeScanRequest,
    BarcodeScanResponse,
    KitCheckoutRequest,
    KitCheckoutResponse,
    ProjectKitsSummaryResponse
)
from app.services import logistics_service

router = APIRouter(prefix="/logistics", tags=["Logística e Credenciamento"])


@router.post(
    "/scan-barcode",
    response_model=BarcodeScanResponse,
    status_code=status.HTTP_200_OK,
    summary="Bipar código de barras do crachá para credenciamento (BR-08)"
)
async def scan_barcode(
    payload: BarcodeScanRequest,
    db: AsyncSession = Depends(get_db)
):
    """
    Registra a presença física individual do participante pelo código de barras.
    Se o participante for membro de um trabalho homologado, dispara o Gatilho de
    Presença Coletiva (Regra BR-08), promovendo o projeto automaticamente para PRESENT.
    """
    return await logistics_service.scan_barcode(db, payload)


@router.post(
    "/checkout-kit",
    response_model=KitCheckoutResponse,
    status_code=status.HTTP_200_OK,
    summary="Baixa de entrega de kit/camiseta com lock atômico (BR-09)"
)
async def checkout_kit(
    payload: KitCheckoutRequest,
    db: AsyncSession = Depends(get_db)
):
    """
    Registra a baixa de entrega do kit do participante com lock atômico condicional.
    Rejeita com HTTP 409 Conflict tentativas de retiradas duplicadas em guichês simultâneos.
    """
    return await logistics_service.checkout_kit(db, payload)


@router.get(
    "/project-kits/{project_id}",
    response_model=ProjectKitsSummaryResponse,
    status_code=status.HTTP_200_OK,
    summary="Consultar kits e tamanhos de camiseta da equipe do projeto"
)
async def get_project_kits(
    project_id: int,
    db: AsyncSession = Depends(get_db)
):
    """Retorna os integrantes do projeto com status de presença, kit e tamanho de camiseta."""
    return await logistics_service.get_project_kits(db, project_id)


@router.post(
    "/project-kits/{project_id}/checkout",
    response_model=ProjectKitsSummaryResponse,
    status_code=status.HTTP_200_OK,
    summary="Baixa coletiva de todos os kits da equipe do projeto na entrega do pacote"
)
async def checkout_project_kits(
    project_id: int,
    db: AsyncSession = Depends(get_db)
):
    """
    Registra a entrega do pacote de kits do projeto.
    Qualquer integrante do grupo pode retirar o kit do projeto.
    Atualiza todos os integrantes do projeto para kit_delivered=True e presence_confirmed=True.
    """
    return await logistics_service.checkout_project_kits(db, project_id)


@router.get(
    "/events/{event_id}/kit-cards/pdf",
    summary="Exportar cards de kits do evento em lote em formato PDF (via Logistics)",
)
async def export_logistics_kit_cards_pdf(
    event_id: int,
    format: str = Query("project", regex="^(project|individual)$"),
    include_tshirt_students: bool = Query(True),
    include_tshirt_advisors: bool = Query(False),
    include_tshirt_coadvisors: bool = Query(False),
    include_tshirt_evaluators: bool = Query(False),
    sort_by: str = Query("booth", regex="^(booth|school|title|name)$"),
    status_filter: str = Query("homologated", regex="^(homologated|all)$"),
    db: AsyncSession = Depends(get_db),
):
    """Gera o PDF consolidado de cards de kits pronto para impressão em folha A4."""
    from app.services.kit_card_service import generate_event_kit_cards_pdf

    pdf_bytes = await generate_event_kit_cards_pdf(
        db=db,
        event_id=event_id,
        card_format=format,
        include_tshirt_students=include_tshirt_students,
        include_tshirt_advisors=include_tshirt_advisors,
        include_tshirt_coadvisors=include_tshirt_coadvisors,
        include_tshirt_evaluators=include_tshirt_evaluators,
        sort_by=sort_by,
        status_filter=status_filter,
    )
    filename = f"cards_kits_evento_{event_id}_{format}.pdf"

    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
            "Cache-Control": "no-cache",
        },
    )

