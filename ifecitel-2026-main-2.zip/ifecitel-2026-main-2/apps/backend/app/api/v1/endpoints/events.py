"""Event management endpoints (BR-01, BR-02, BR-23)."""

import csv
import io
import os
from typing import List, Optional, Tuple, Union
import uuid
from fastapi import APIRouter, Depends, File, HTTPException, Query, Response, UploadFile, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import (
    get_current_admin,
    get_event_admin_access,
    get_optional_admin,
    require_event_role,
)
from app.core.config import settings
from app.core.database import get_db
from app.models.enums import EventAdminRole
from app.models.evaluation import EvaluationCriterion
from app.models.event import Event
from app.models.person import Person
from app.schemas.evaluation import (
    EvaluationCriterionBatchImport,
    EvaluationCriterionBatchItem,
    EvaluationCriterionBatchResponse,
    EvaluationCriterionCreate,
    EvaluationCriterionResponse,
    EvaluationCriterionUpdate,
)
from app.schemas.event import (
    EventCreate,
    EventResponse,
    EventUpdate,
    PaginatedEventResponse,
)
from app.schemas.event_admin import (
    EventAdminCreate,
    EventAdminItem,
    EventAdminListResponse,
    EventAdminUpdate,
)
from app.services import event_service

router = APIRouter(prefix="/events", tags=["Eventos"])


@router.post(
    "",
    response_model=EventResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Cadastrar nova edição do evento (Multi-Evento BR-01, Posse Soberana BR-23)"
)
async def create_event(
    payload: EventCreate,
    db: AsyncSession = Depends(get_db),
    admin: Person = Depends(get_current_admin)
):
    """Cria uma nova edição da feira vinculando o criador como Coordenador Geral soberano."""
    return await event_service.create_event(db, payload, creator_id=admin.id)


@router.get(
    "",
    response_model=Union[PaginatedEventResponse, List[EventResponse]],
    status_code=status.HTTP_200_OK,
    summary="Listar edições de eventos com suporte a busca, paginação (BR-18) e isolamento estrito (BR-23)"
)
async def list_events(
    page: Optional[int] = Query(None, ge=1, description="Número da página (1-indexed) para paginação real"),
    limit: int = Query(15, ge=1, le=100, description="Itens por página (padrão: 15)"),
    search: Optional[str] = Query(None, description="Termo para busca textual por nome da edição"),
    db: AsyncSession = Depends(get_db),
    admin: Optional[Person] = Depends(get_optional_admin)
):
    """
    Lista edições cadastradas no sistema.
    Se autenticado como administrador, lista estritamente as feiras em que possui posse ou vínculo.
    """
    admin_id = admin.id if admin else None
    if page is not None:
        return await event_service.list_events_paginated(db, admin_id=admin_id, page=page, limit=limit, search=search)
    return await event_service.list_events(db, admin_id=admin_id, search=search)


@router.get(
    "/{event_id}",
    response_model=EventResponse,
    status_code=status.HTTP_200_OK,
    summary="Consultar detalhes de uma edição com blindagem de autorização (BR-23)"
)
async def get_event(
    event_id: int,
    db: AsyncSession = Depends(get_db),
    admin: Optional[Person] = Depends(get_optional_admin)
):
    """Recupera detalhes da edição. Se admin autenticado, valida se pertence à equipe da feira."""
    if admin:
        await get_event_admin_access(event_id, min_role=EventAdminRole.OPERATOR, db=db, admin=admin)
        return await event_service.get_event_by_id(db, event_id, admin_id=admin.id)
    return await event_service.get_event_by_id(db, event_id)


@router.put(
    "/{event_id}",
    response_model=EventResponse,
    status_code=status.HTTP_200_OK,
    summary="Atualizar parâmetros do evento (Exclusivo COORDINATOR BR-23)"
)
async def update_event(
    event_id: int,
    payload: EventUpdate,
    db: AsyncSession = Depends(get_db),
    auth_context: Tuple[Event, EventAdminRole] = Depends(require_event_role(EventAdminRole.COORDINATOR))
):
    """Atualiza configurações da edição, restrito ao Coordenador Geral da feira."""
    return await event_service.update_event(db, event_id, payload)


@router.delete(
    "/{event_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Desativar (soft-delete) uma edição de evento (Exclusivo COORDINATOR BR-23)"
)
async def delete_event(
    event_id: int,
    db: AsyncSession = Depends(get_db),
    auth_context: Tuple[Event, EventAdminRole] = Depends(require_event_role(EventAdminRole.COORDINATOR))
):
    """Desativa logicamente uma edição de evento, restrito ao Coordenador Geral da feira."""
    await event_service.delete_event(db, event_id)


# ==============================================================================
# Gestão de Equipe e Administradores da Feira (Regra BR-23)
# ==============================================================================

@router.get(
    "/{event_id}/admins",
    response_model=EventAdminListResponse,
    status_code=status.HTTP_200_OK,
    summary="Listar administradores vinculados à feira (Regra BR-23)"
)
async def list_event_admins(
    event_id: int,
    db: AsyncSession = Depends(get_db),
    auth_context: Tuple[Event, EventAdminRole] = Depends(require_event_role(EventAdminRole.ORGANIZER))
):
    """Lista todos os gestores administrativos com seus papéis na feira."""
    return await event_service.list_event_admins(db, event_id)


@router.post(
    "/{event_id}/admins",
    response_model=EventAdminItem,
    status_code=status.HTTP_201_CREATED,
    summary="Convidar/Adicionar administrador para a feira (Exclusivo COORDINATOR BR-23)"
)
async def add_event_admin(
    event_id: int,
    payload: EventAdminCreate,
    db: AsyncSession = Depends(get_db),
    admin: Person = Depends(get_current_admin),
    auth_context: Tuple[Event, EventAdminRole] = Depends(require_event_role(EventAdminRole.COORDINATOR))
):
    """Adiciona um membro à equipe administrativa da feira pelo e-mail com o papel designado."""
    return await event_service.add_event_admin(db, event_id, payload, current_admin_id=admin.id)


@router.put(
    "/{event_id}/admins/{person_id}",
    response_model=EventAdminItem,
    status_code=status.HTTP_200_OK,
    summary="Alterar papel de um administrador na feira (Exclusivo COORDINATOR BR-23)"
)
async def update_event_admin_role(
    event_id: int,
    person_id: int,
    payload: EventAdminUpdate,
    db: AsyncSession = Depends(get_db),
    admin: Person = Depends(get_current_admin),
    auth_context: Tuple[Event, EventAdminRole] = Depends(require_event_role(EventAdminRole.COORDINATOR))
):
    """Altera o papel hierárquico de um administrador na equipe do evento."""
    return await event_service.update_event_admin_role(
        db, event_id, person_id, payload.role, current_admin_id=admin.id
    )


@router.delete(
    "/{event_id}/admins/{person_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Revogar acesso de um administrador à feira (Exclusivo COORDINATOR BR-23)"
)
async def remove_event_admin(
    event_id: int,
    person_id: int,
    db: AsyncSession = Depends(get_db),
    admin: Person = Depends(get_current_admin),
    auth_context: Tuple[Event, EventAdminRole] = Depends(require_event_role(EventAdminRole.COORDINATOR))
):
    """Revoga o vínculo de um administrador com a feira (bloqueado para o dono soberano)."""
    await event_service.remove_event_admin(db, event_id, person_id, current_admin_id=admin.id)



@router.get(
    "/{event_id}/criteria",
    response_model=List[EvaluationCriterionResponse],
    status_code=status.HTTP_200_OK,
    summary="Listar critérios de avaliação cadastrados para a edição do evento"
)
async def list_event_criteria(
    event_id: int,
    db: AsyncSession = Depends(get_db)
):
    """Lista as perguntas/critérios da ficha de avaliação vinculados à edição do evento."""
    stmt = (
        select(EvaluationCriterion)
        .where(
            EvaluationCriterion.event_id == event_id,
            EvaluationCriterion.deleted_at.is_(None)
        )
        .order_by(EvaluationCriterion.id.asc())
    )
    result = await db.execute(stmt)
    return result.scalars().all()


@router.post(
    "/{event_id}/criteria",
    response_model=EvaluationCriterionResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Cadastrar critério de avaliação para a edição do evento"
)
async def create_event_criterion(
    event_id: int,
    payload: EvaluationCriterionCreate,
    db: AsyncSession = Depends(get_db),
    auth_context: Tuple[Event, EventAdminRole] = Depends(require_event_role(EventAdminRole.ORGANIZER))
):
    """Cadastra uma nova pergunta/critério na ficha de avaliação da edição."""
    event, _ = auth_context
    event_service.verify_event_temporal_lock(event)

    criterion = EvaluationCriterion(
        event_id=event_id,
        name=payload.name.strip(),
        scientific_description=payload.scientific_description,
        technological_description=payload.technological_description,
        max_score=payload.max_score,
        weight=payload.weight
    )
    db.add(criterion)
    await db.commit()
    await db.refresh(criterion)
    return criterion


@router.get(
    "/{event_id}/criteria/template-csv",
    summary="Baixar modelo esqueleto oficial de CSV para critérios de avaliação"
)
async def download_criteria_csv_template(
    event_id: int,
    db: AsyncSession = Depends(get_db),
    auth_context: Tuple[Event, EventAdminRole] = Depends(require_event_role(EventAdminRole.ORGANIZER))
):
    """
    Retorna o esqueleto de CSV estruturado em UTF-8 com BOM e exemplos didáticos
    para preenchimento no Excel e importação em lote.
    """
    event, _ = auth_context
    csv_content = (
        "\uFEFF"  # UTF-8 BOM para compatibilidade com Microsoft Excel no Brasil
        "nome;pergunta_unica;descricao_cientifica;descricao_tecnologica;nota_maxima;peso\r\n"
        "Critério 1: Rigor Metodológico e Condução da Pesquisa;;Como a equipe formulou a hipótese científica, conduziu os testes experimentais e controlou variáveis?;Como a equipe definiu a demanda técnica, concebeu a arquitetura do protótipo e testou o funcionamento?;10,0;1,5\r\n"
        "Critério 2: Relevância, Criatividade e Impacto Social;;Qual o grau de originalidade, impacto social e aplicabilidade prática da pesquisa desenvolvida?;Qual o grau de inovação da tecnologia proposta e seu potencial de solução do problema real?;10,0;1,0\r\n"
        "Critério 3: Postura, Clareza e Domínio na Apresentação;Como os estudantes apresentaram o trabalho no estande, demonstrando clareza, articulação técnica e domínio do assunto?;;;10,0;1,0\r\n"
    )
    filename = f"modelo_criterios_easyevent_evento_{event_id}.csv"
    return Response(
        content=csv_content.encode("utf-8"),
        media_type="text/csv; charset=utf-8",
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"'
        }
    )


@router.post(
    "/{event_id}/criteria/batch",
    response_model=EvaluationCriterionBatchResponse,
    status_code=status.HTTP_200_OK,
    summary="Importar / Sincronizar em lote critérios de avaliação da edição (Upsert)"
)
async def import_batch_event_criteria(
    event_id: int,
    payload: EvaluationCriterionBatchImport,
    db: AsyncSession = Depends(get_db),
    auth_context: Tuple[Event, EventAdminRole] = Depends(require_event_role(EventAdminRole.ORGANIZER))
):
    """
    Sincroniza múltiplos critérios de avaliação de uma só vez (Upsert Atômico).
    - Se o critério existir pelo nome (case-insensitive), atualiza formulações, nota máxima e peso.
    - Se for novo, cadastra.
    - Se estava desativado (deleted_at), reativa.
    - Critérios existentes não listados no lote são preservados intactos.
    """
    event, _ = auth_context
    event_service.verify_event_temporal_lock(event)

    # 1. Carregar todos os critérios do evento (inclusive deletados para permitir reativação)
    stmt = select(EvaluationCriterion).where(EvaluationCriterion.event_id == event_id)
    res = await db.execute(stmt)
    existing_criteria = res.scalars().all()
    existing_map = {c.name.strip().lower(): c for c in existing_criteria}

    created_count = 0
    updated_count = 0
    affected_criteria: List[EvaluationCriterion] = []

    for item in payload.items:
        clean_name = item.name.strip()
        if not clean_name:
            continue

        # Normalizar formulações: se pergunta_unica fornecida, usar para ambas
        sci_desc = (item.scientific_description.strip() if item.scientific_description else None)
        tech_desc = (item.technological_description.strip() if item.technological_description else None)
        if item.pergunta_unica and item.pergunta_unica.strip():
            u_text = item.pergunta_unica.strip()
            sci_desc = sci_desc or u_text
            tech_desc = tech_desc or u_text
        elif sci_desc and not tech_desc:
            tech_desc = sci_desc
        elif tech_desc and not sci_desc:
            sci_desc = tech_desc

        key = clean_name.lower()
        if key in existing_map:
            criterion = existing_map[key]
            criterion.name = clean_name
            criterion.scientific_description = sci_desc
            criterion.technological_description = tech_desc
            criterion.max_score = item.max_score
            criterion.weight = item.weight
            criterion.deleted_at = None  # Reativar se estava deletado
            updated_count += 1
            affected_criteria.append(criterion)
        else:
            criterion = EvaluationCriterion(
                event_id=event_id,
                name=clean_name,
                scientific_description=sci_desc,
                technological_description=tech_desc,
                max_score=item.max_score,
                weight=item.weight
            )
            db.add(criterion)
            existing_map[key] = criterion
            created_count += 1
            affected_criteria.append(criterion)

    await db.commit()
    for c in affected_criteria:
        await db.refresh(c)

    return EvaluationCriterionBatchResponse(
        total=len(affected_criteria),
        created_count=created_count,
        updated_count=updated_count,
        items=affected_criteria
    )


@router.post(
    "/{event_id}/criteria/upload-csv",
    response_model=EvaluationCriterionBatchResponse,
    status_code=status.HTTP_200_OK,
    summary="Upload e importação de arquivo CSV de critérios de avaliação"
)
async def upload_criteria_csv(
    event_id: int,
    file: UploadFile = File(...),
    db: AsyncSession = Depends(get_db),
    auth_context: Tuple[Event, EventAdminRole] = Depends(require_event_role(EventAdminRole.ORGANIZER))
):
    """
    Recebe um arquivo CSV com os critérios de avaliação e executa a importação em lote.
    Suporta codificação UTF-8, UTF-8-sig (BOM) e Latin-1/ISO-8859-1.
    """
    event, _ = auth_context
    event_service.verify_event_temporal_lock(event)

    contents = await file.read()
    if not contents:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Arquivo CSV vazio."
        )

    text = None
    for enc in ("utf-8-sig", "utf-8", "latin-1", "iso-8859-1"):
        try:
            text = contents.decode(enc)
            break
        except UnicodeDecodeError:
            continue

    if text is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Não foi possível decodificar o arquivo CSV. Por favor, salve o arquivo em codificação UTF-8."
        )

    sample = text[:2048]
    delimiter = ";"
    if ";" in sample:
        delimiter = ";"
    elif "\t" in sample:
        delimiter = "\t"
    elif "," in sample:
        delimiter = ","

    reader = csv.DictReader(io.StringIO(text), delimiter=delimiter)
    if not reader.fieldnames:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="O arquivo CSV não possui cabeçalho válido."
        )

    normalized_fields = {k: k.strip().lower().replace(" ", "_") for k in reader.fieldnames if k}

    items_to_import: List[EvaluationCriterionBatchItem] = []
    for row in reader:
        clean_row = {}
        for orig_key, val in row.items():
            if orig_key and orig_key in normalized_fields:
                norm_key = normalized_fields[orig_key]
                clean_row[norm_key] = val.strip() if val else ""

        name = (
            clean_row.get("nome")
            or clean_row.get("name")
            or clean_row.get("criterio")
            or clean_row.get("titulo")
            or ""
        )
        if not name:
            continue

        pergunta_unica = clean_row.get("pergunta_unica") or clean_row.get("pergunta") or ""
        sci_desc = clean_row.get("descricao_cientifica") or clean_row.get("cientifico") or clean_row.get("scientific_description") or ""
        tech_desc = clean_row.get("descricao_tecnologica") or clean_row.get("tecnologico") or clean_row.get("technological_description") or ""

        raw_max = clean_row.get("nota_maxima") or clean_row.get("nota_max") or clean_row.get("max_score") or clean_row.get("nota") or "10.0"
        try:
            max_score = float(raw_max.replace(",", "."))
        except ValueError:
            max_score = 10.0

        raw_weight = clean_row.get("peso") or clean_row.get("weight") or "1.0"
        try:
            weight = float(raw_weight.replace(",", "."))
        except ValueError:
            weight = 1.0

        items_to_import.append(
            EvaluationCriterionBatchItem(
                name=name,
                pergunta_unica=pergunta_unica or None,
                scientific_description=sci_desc or None,
                technological_description=tech_desc or None,
                max_score=max(1.0, min(100.0, max_score)),
                weight=max(0.1, min(10.0, weight))
            )
        )

    if not items_to_import:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Nenhum critério válido encontrado no arquivo CSV."
        )

    batch_payload = EvaluationCriterionBatchImport(items=items_to_import)
    return await import_batch_event_criteria(event_id, batch_payload, db, auth_context)


@router.put(
    "/{event_id}/criteria/{criterion_id}",
    response_model=EvaluationCriterionResponse,
    status_code=status.HTTP_200_OK,
    summary="Atualizar critério de avaliação da edição do evento"
)
async def update_event_criterion(
    event_id: int,
    criterion_id: int,
    payload: EvaluationCriterionUpdate,
    db: AsyncSession = Depends(get_db),
    auth_context: Tuple[Event, EventAdminRole] = Depends(require_event_role(EventAdminRole.ORGANIZER))
):
    """Atualiza os dados cadastrais, descrições, peso ou pontuação máxima de um critério."""
    event, _ = auth_context
    event_service.verify_event_temporal_lock(event)

    stmt = select(EvaluationCriterion).where(
        EvaluationCriterion.id == criterion_id,
        EvaluationCriterion.event_id == event_id,
        EvaluationCriterion.deleted_at.is_(None)
    )
    res = await db.execute(stmt)
    criterion = res.scalar_one_or_none()
    if not criterion:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Critério de avaliação não encontrado."
        )

    if payload.name is not None:
        criterion.name = payload.name.strip()
    if payload.scientific_description is not None:
        criterion.scientific_description = payload.scientific_description
    if payload.technological_description is not None:
        criterion.technological_description = payload.technological_description
    if payload.max_score is not None:
        criterion.max_score = payload.max_score
    if payload.weight is not None:
        criterion.weight = payload.weight

    await db.commit()
    await db.refresh(criterion)
    return criterion


@router.delete(
    "/{event_id}/criteria/{criterion_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Desativar (soft-delete) critério de avaliação da edição"
)
async def delete_event_criterion(
    event_id: int,
    criterion_id: int,
    db: AsyncSession = Depends(get_db),
    auth_context: Tuple[Event, EventAdminRole] = Depends(require_event_role(EventAdminRole.ORGANIZER))
):
    """Desativa um critério de avaliação caso ainda não possua notas registradas."""
    from app.models.award import AwardCriterion
    from app.models.evaluation import EvaluationItem

    event, _ = auth_context
    event_service.verify_event_temporal_lock(event)

    stmt = select(EvaluationCriterion).where(
        EvaluationCriterion.id == criterion_id,
        EvaluationCriterion.event_id == event_id,
        EvaluationCriterion.deleted_at.is_(None)
    )
    res = await db.execute(stmt)
    criterion = res.scalar_one_or_none()
    if not criterion:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Critério de avaliação não encontrado."
        )

    # Trava de integridade: checar se já há notas atribuídas para este critério
    eval_items_stmt = select(EvaluationItem).where(
        EvaluationItem.criterion_id == criterion_id,
        EvaluationItem.deleted_at.is_(None)
    )
    eval_res = await db.execute(eval_items_stmt)
    if eval_res.scalars().first():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Não é possível excluir este critério pois ele já possui notas registradas em avaliações de projetos."
        )

    # Desativar vínculos em premiações se houver
    award_links_stmt = select(AwardCriterion).where(
        AwardCriterion.criterion_id == criterion_id,
        AwardCriterion.deleted_at.is_(None)
    )
    links_res = await db.execute(award_links_stmt)
    for link in links_res.scalars().all():
        link.soft_delete()

    criterion.soft_delete()
    await db.commit()


@router.post(
    "/upload-logo",
    summary="Upload avulso de logotipo do evento (PNG ou JPG/JPEG) retornando URL estática",
)
async def upload_event_logo_temp(
    file: UploadFile = File(...),
):
    """Permite o upload de arquivos PNG ou JPG/JPEG de até 5MB para o logotipo do evento."""
    if not file.filename:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Arquivo não fornecido.",
        )

    ext = os.path.splitext(file.filename)[1].lower()
    if ext not in [".png", ".jpg", ".jpeg"]:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Formato de imagem inválido. Aceitos somente PNG ou JPG/JPEG.",
        )

    contents = await file.read()
    if len(contents) > 5 * 1024 * 1024:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="O arquivo da imagem excede o tamanho máximo de 5MB.",
        )

    logos_dir = os.path.join(settings.UPLOAD_DIR, "logos")
    os.makedirs(logos_dir, exist_ok=True)
    filename = f"logo_{uuid.uuid4().hex[:12]}{ext}"
    dest_path = os.path.join(logos_dir, filename)

    with open(dest_path, "wb") as f:
        f.write(contents)

    logo_url = f"/static/uploads/logos/{filename}"
    return {"logo_url": logo_url}


@router.post(
    "/{event_id}/logo",
    summary="Upload e atualização do logotipo do evento existente (PNG ou JPG/JPEG)",
)
async def upload_event_logo(
    event_id: int,
    file: UploadFile = File(...),
    db: AsyncSession = Depends(get_db),
    auth_context: Tuple[Event, EventAdminRole] = Depends(require_event_role(EventAdminRole.ORGANIZER)),
):
    """Recebe e atualiza o logotipo de uma edição existente com arquivo PNG ou JPG/JPEG."""
    event, _ = auth_context
    event_service.verify_event_temporal_lock(event)

    ext = os.path.splitext(file.filename or "")[1].lower()
    if ext not in [".png", ".jpg", ".jpeg"]:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Formato de imagem inválido. Aceitos somente PNG ou JPG/JPEG.",
        )

    contents = await file.read()
    if len(contents) > 5 * 1024 * 1024:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="O arquivo da imagem excede o tamanho máximo de 5MB.",
        )

    logos_dir = os.path.join(settings.UPLOAD_DIR, "logos")
    os.makedirs(logos_dir, exist_ok=True)
    filename = f"event_{event_id}_logo_{uuid.uuid4().hex[:8]}{ext}"
    dest_path = os.path.join(logos_dir, filename)

    with open(dest_path, "wb") as f:
        f.write(contents)

    logo_url = f"/static/uploads/logos/{filename}"
    event.logo_url = logo_url
    await db.commit()
    await db.refresh(event)

    return {"logo_url": logo_url, "message": "Logotipo do evento atualizado com sucesso."}


@router.get(
    "/{event_id}/badges/pdf",
    summary="Exportar crachás do evento em lote em formato PDF (A4 4 por folha)",
)
async def export_event_badges_pdf(
    event_id: int,
    filter: str = Query("all", regex="^(all|projects|evaluators|staff)$"),
    db: AsyncSession = Depends(get_db),
    auth_context: Tuple[Event, EventAdminRole] = Depends(require_event_role(EventAdminRole.ORGANIZER)),
):
    """
    Gera o PDF consolidado de crachás em lote agrupados por equipes de trabalho, organizadores e avaliadores.
    """
    from app.services.badge_service import generate_event_badges_batch_pdf

    pdf_bytes = await generate_event_badges_batch_pdf(db, event_id, filter_type=filter)
    filename = f"crachas_evento_{event_id}_{filter}.pdf"

    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
            "Cache-Control": "no-cache",
        },
    )


@router.get(
    "/{event_id}/kit-cards/pdf",
    summary="Exportar cards de kits do evento em lote em formato PDF (individual ou por projeto)",
)
async def export_event_kit_cards_pdf(
    event_id: int,
    format: str = Query("project", regex="^(project|individual)$"),
    include_tshirt_students: bool = Query(True),
    include_tshirt_advisors: bool = Query(False),
    include_tshirt_coadvisors: bool = Query(False),
    include_tshirt_evaluators: bool = Query(False),
    sort_by: str = Query("booth", regex="^(booth|school|title|name)$"),
    status_filter: str = Query("homologated", regex="^(homologated|all)$"),
    db: AsyncSession = Depends(get_db),
    auth_context: Tuple[Event, EventAdminRole] = Depends(require_event_role(EventAdminRole.ORGANIZER)),
):
    """
    Gera o PDF consolidado de cards de kits pronto para impressão em folha A4.
    Formatos suportados:
    - project: 2 cards por folha A4 com Packing List e checklist de conferência do estande.
    - individual: 6 cards por folha A4 com etiqueta de participante e código de barras.
    Permite filtrar a concessão de camisetas por papel (estudantes, orientadores, coorientadores, avaliadores).
    """
    from app.services.kit_card_service import generate_event_kit_cards_pdf

    pdf_bytes = await generate_event_kit_cards_pdf(
        db=db,
        event_id=event_id,
        card_format=format,
        include_tshirt_students=include_tshirt_students,
        include_tshirt_advisors=include_tshirt_advisors,
        include_tshirt_coadvisors=include_tshirt_coadvisors,
        include_tshirt_evaluators=include_tshirt_evaluators,
        sort_by=sort_by,
        status_filter=status_filter,
    )
    filename = f"cards_kits_evento_{event_id}_{format}.pdf"

    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
            "Cache-Control": "no-cache",
        },
    )


@router.get(
    "/{event_id}/booth-stickers/pdf",
    summary="Exportar adesivos/placas com QR Code de bancada em PDF",
)
async def export_event_booth_stickers_pdf(
    event_id: int,
    status_filter: str = Query("homologated", regex="^(homologated|all)$"),
    area_id: Optional[int] = Query(None),
    sort_by: str = Query("id", regex="^(id|booth|area|title)$"),
    layout: str = Query("a5_double", regex="^(a5_double|a6_quad)$"),
    db: AsyncSession = Depends(get_db),
    auth_context: Tuple[Event, EventAdminRole] = Depends(require_event_role(EventAdminRole.ORGANIZER)),
):
    """
    Gera o PDF consolidado de adesivos com QR Code para bancadas físicas dos projetos.
    Modelos suportados:
    - a5_double: 2 adesivos por folha A4 (1x2 retrato, QR Code gigante).
    - a6_quad: 4 adesivos por folha A4 (2x2 paisagem, alta densidade).
    """
    from app.services.booth_sticker_service import generate_event_booth_stickers_pdf

    pdf_bytes = await generate_event_booth_stickers_pdf(
        db=db,
        event_id=event_id,
        status_filter=status_filter,
        area_id=area_id,
        sort_by=sort_by,
        layout=layout,
    )
    filename = f"adesivos_bancada_evento_{event_id}_{layout}.pdf"

    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
            "Cache-Control": "no-cache",
        },
    )

