"""Knowledge areas and subareas endpoints (Regra BR-16)."""

from typing import List
from fastapi import APIRouter, Depends, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_admin
from app.core.database import get_db
from app.models.person import Person
from app.schemas.knowledge_area import (
    KnowledgeAreaCreate,
    KnowledgeAreaResponse,
    KnowledgeAreaBatchImport,
    KnowledgeAreaBatchResponse,
    SubareaCreate,
    SubareaResponse
)
from app.services import knowledge_area_service

router = APIRouter(tags=["Áreas e Subáreas do Conhecimento"])


@router.post(
    "/events/{event_id}/areas/batch",
    response_model=KnowledgeAreaBatchResponse,
    status_code=status.HTTP_200_OK,
    summary="Importar / Sincronizar em lote grandes áreas e subáreas do conhecimento (BR-16)"
)
async def import_batch_areas(
    event_id: int,
    payload: KnowledgeAreaBatchImport,
    db: AsyncSession = Depends(get_db),
    admin: Person = Depends(get_current_admin)
):
    """
    Importa em lote áreas e subáreas para a edição ativa a partir de dados estruturados/CSV.
    - Cria novas áreas e subáreas.
    - Reativa itens desativados anteriormente.
    - Preserva registros ativos existentes sem duplicá-los (Idempotente).
    """
    return await knowledge_area_service.import_knowledge_areas_batch(db, event_id, payload)



@router.post(
    "/events/{event_id}/areas",
    response_model=KnowledgeAreaResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Cadastrar grande área do conhecimento vinculada ao evento (BR-16)"
)
async def create_area(
    event_id: int,
    payload: KnowledgeAreaCreate,
    db: AsyncSession = Depends(get_db),
    admin: Person = Depends(get_current_admin)
):
    """Cria uma nova área científica no painel de administração da feira."""
    return await knowledge_area_service.create_knowledge_area(db, event_id, payload)


@router.get(
    "/events/{event_id}/areas",
    response_model=List[KnowledgeAreaResponse],
    status_code=status.HTTP_200_OK,
    summary="Listar áreas e subáreas de uma edição do evento"
)
async def list_areas(
    event_id: int,
    db: AsyncSession = Depends(get_db)
):
    """Retorna todas as grandes áreas e respectivas subáreas ativas da edição."""
    return await knowledge_area_service.list_knowledge_areas(db, event_id)


@router.delete(
    "/areas/{area_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Desativar (soft-delete) grande área com trava de integridade"
)
async def delete_area(
    area_id: int,
    db: AsyncSession = Depends(get_db),
    admin: Person = Depends(get_current_admin)
):
    """Desativa uma área do conhecimento, bloqueando se houver subáreas ativas associadas (BR-16)."""
    await knowledge_area_service.delete_knowledge_area(db, area_id)


@router.post(
    "/areas/{area_id}/subareas",
    response_model=SubareaResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Cadastrar subárea vinculada à área mãe (BR-16)"
)
async def create_subarea(
    area_id: int,
    payload: SubareaCreate,
    db: AsyncSession = Depends(get_db),
    admin: Person = Depends(get_current_admin)
):
    """Adiciona uma subárea especializada dentro de uma grande área."""
    return await knowledge_area_service.create_subarea(db, area_id, payload)


@router.delete(
    "/subareas/{subarea_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Desativar (soft-delete) subárea com trava de integridade"
)
async def delete_subarea(
    subarea_id: int,
    db: AsyncSession = Depends(get_db),
    admin: Person = Depends(get_current_admin)
):
    """Desativa uma subárea, bloqueando se houver projetos ativos associados a ela (BR-16)."""
    await knowledge_area_service.delete_subarea(db, subarea_id)
