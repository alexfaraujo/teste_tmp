"""Endpoints for evaluations and mobile evaluation sheet (Regras BR-11 e BR-12)."""

from typing import List
from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_evaluator, get_current_user
from app.core.database import get_db
from app.models.person import Person
from app.schemas.evaluation import (
    EvaluationCreate,
    EvaluationResponse,
    EvaluationSheetResponse,
    ProjectEvaluationSummaryResponse
)
from app.services import evaluation_service

router = APIRouter(prefix="/evaluations", tags=["Avaliações e Ficha Mobile"])


@router.get(
    "/sheet",
    response_model=EvaluationSheetResponse,
    status_code=status.HTTP_200_OK,
    summary="Carregar ficha de avaliação via QR Code de bancada (BR-08, BR-11)"
)
async def get_evaluation_sheet(
    qrcode: str = Query(..., description="Token do QR Code afixado no estande/bancada"),
    db: AsyncSession = Depends(get_db),
    evaluator: Person = Depends(get_current_evaluator)
):
    """
    Leitura da ficha de notas adaptada ao tipo de trabalho (Científico vs Tecnológico)
    a partir do token lido pela câmera do smartphone do avaliador.
    """
    return await evaluation_service.get_evaluation_sheet_by_qrcode(db, qrcode, evaluator)


@router.get(
    "/project/{project_id}/my-sheet",
    response_model=EvaluationSheetResponse,
    status_code=status.HTTP_200_OK,
    summary="Carregar ficha de avaliação do avaliador autenticado para o projeto alocado"
)
async def get_my_project_evaluation_sheet(
    project_id: int,
    db: AsyncSession = Depends(get_db),
    evaluator: Person = Depends(get_current_evaluator)
):
    """
    Retorna a ficha de avaliação (com notas e parecer já salvos, se houver) para o avaliador
    autenticado, sem exigir a leitura física do QR code de bancada.
    """
    return await evaluation_service.get_evaluation_sheet_by_project_id(db, project_id, evaluator)


@router.post(
    "",
    response_model=EvaluationResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Submeter avaliação com parecer consolidado único (BR-11, BR-12)"
)
async def submit_evaluation(
    payload: EvaluationCreate,
    db: AsyncSession = Depends(get_db),
    evaluator: Person = Depends(get_current_evaluator)
):
    """
    Registra ou atualiza as notas da ficha de avaliação e o parecer geral consolidado único.
    Promove o trabalho para UNDER_EVALUATION e, ao completar todas as avaliações, para EVALUATED.
    """
    return await evaluation_service.submit_evaluation(db, payload, evaluator)


@router.get(
    "/project/{project_id}/summary",
    response_model=ProjectEvaluationSummaryResponse,
    status_code=status.HTTP_200_OK,
    summary="Obter resumo e nota final por média aritmética simples (BR-12)"
)
async def get_project_evaluation_summary(
    project_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: Person = Depends(get_current_user)
):
    """
    Retorna a nota final oficial do projeto calculada por média aritmética simples
    sem descarte de notas (Regra BR-12) e a lista de pareceres consolidados.
    """
    return await evaluation_service.get_project_evaluation_summary(db, project_id)


@router.get(
    "/project/{project_id}",
    response_model=List[EvaluationResponse],
    status_code=status.HTTP_200_OK,
    summary="Listar todas as avaliações individuais de um projeto"
)
async def list_project_evaluations(
    project_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: Person = Depends(get_current_user)
):
    """Lista as avaliações individuais submetidas pelos avaliadores para o trabalho."""
    return await evaluation_service.list_project_evaluations(db, project_id)
