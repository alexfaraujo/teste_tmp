"""Project submission and formal advisor consent endpoints (BR-03, BR-04, BR-05, BR-06)."""

import csv
import io
from typing import List, Optional, Union
from fastapi import APIRouter, Depends, File, HTTPException, Query, Response, UploadFile, status
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_admin, get_current_user, get_optional_admin, get_event_admin_access
from app.core.database import get_db
from app.models.enums import EducationLevelEnum, ProjectStatus, EventAdminRole, ProjectType, ProjectMemberRole
from app.models.event import EducationLevel
from app.models.knowledge_area import KnowledgeArea, Subarea
from app.models.person import Person
from app.schemas.project import (
    AdvisorConsentResponse,
    PaginatedProjectResponse,
    ProjectBatchImport,
    ProjectBatchItem,
    ProjectBatchMemberInput,
    ProjectBatchResponse,
    ProjectBoothAssignmentRequest,
    ProjectCreate,
    ProjectHomologateRequest,
    ProjectResponse,
    ProjectUpdate,
)
from app.services import project_service

router = APIRouter(prefix="/projects", tags=["Projetos"])


@router.get(
    "",
    response_model=Union[PaginatedProjectResponse, List[ProjectResponse]],
    status_code=status.HTTP_200_OK,
    summary="Listar projetos de um evento com filtros e paginação real (BR-01, BR-18)"
)
async def list_projects(
    event_id: int = Query(..., description="ID do evento obrigatório (Multi-Evento BR-01)"),
    page: Optional[int] = Query(None, ge=1, description="Número da página (1-indexed) para paginação real"),
    limit: int = Query(15, ge=1, le=100, description="Itens por página (padrão: 15)"),
    status: Optional[ProjectStatus] = Query(None, description="Filtrar por status do projeto"),
    education_level: Optional[EducationLevelEnum] = Query(None, description="Filtrar por nível de ensino"),
    subarea_id: Optional[int] = Query(None, description="Filtrar por subárea"),
    search: Optional[str] = Query(None, description="Busca textual por título, token QR ou bancada"),
    db: AsyncSession = Depends(get_db),
    admin: Optional[Person] = Depends(get_optional_admin)
):
    """Lista projetos cadastrados para o evento, com isolamento multi-evento e paginação real (BR-18)."""
    if admin:
        await get_event_admin_access(event_id, min_role=EventAdminRole.OPERATOR, db=db, admin=admin)

    if page is not None:
        return await project_service.list_projects_paginated(
            db=db,
            event_id=event_id,
            page=page,
            limit=limit,
            status=status,
            education_level=education_level,
            subarea_id=subarea_id,
            search=search
        )
    return await project_service.list_projects(
        db=db,
        event_id=event_id,
        status=status,
        education_level=education_level,
        subarea_id=subarea_id,
        search=search
    )


@router.post(
    "",
    response_model=ProjectResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Submeter trabalho científico com validação de cotas (BR-04, BR-05)"
)
async def submit_project(
    payload: ProjectCreate,
    db: AsyncSession = Depends(get_db),
    current_user: Person = Depends(get_current_user)
):
    """
    Submete um novo trabalho para a feira.
    Valida cotas de alunos por nível (Médio: 4, Fundamental: 5), exige 1 orientador
    e inicia no status WAITING_CONSENT até que o orientador conceda a anuência digital.
    """
    return await project_service.submit_project(db, payload)


@router.get(
    "/template-csv",
    summary="Baixar modelo esqueleto oficial de CSV para trabalhos científicos"
)
async def download_projects_csv_template(
    event_id: int = Query(..., description="ID da edição do evento ativo"),
    db: AsyncSession = Depends(get_db),
    admin: Person = Depends(get_current_admin)
):
    """
    Retorna o esqueleto de CSV em UTF-8 com BOM e exemplos com as subáreas reais cadastradas na feira.
    """
    await get_event_admin_access(event_id, min_role=EventAdminRole.ORGANIZER, db=db, admin=admin)

    # Obter subáreas da feira com suas respectivas Grandes Áreas para colocar nos exemplos
    subareas_stmt = (
        select(Subarea, KnowledgeArea.name.label("area_name"))
        .join(KnowledgeArea, Subarea.area_id == KnowledgeArea.id)
        .where(
            KnowledgeArea.event_id == event_id,
            KnowledgeArea.deleted_at.is_(None),
            Subarea.deleted_at.is_(None)
        )
    )
    subareas_res = await db.execute(subareas_stmt)
    subareas_rows = subareas_res.all()

    def format_sub_example(row_item, fallback_text: str) -> str:
        if row_item:
            sub_obj, area_name = row_item
            return f"{area_name} -> {sub_obj.name}" if area_name else sub_obj.name
        return fallback_text

    sub1 = format_sub_example(subareas_rows[0] if len(subareas_rows) > 0 else None, "Engenharias -> Robótica e Automação")
    sub2 = format_sub_example(subareas_rows[1] if len(subareas_rows) > 1 else None, "Ciências da Natureza -> Biologia")
    sub3 = format_sub_example(subareas_rows[2] if len(subareas_rows) > 2 else None, "Ciências Humanas -> Educação e Sociedade")

    # Determinar a cota máxima de estudantes configurada no evento ativo
    stmt_max = (
        select(func.max(EducationLevel.max_students))
        .where(
            EducationLevel.event_id == event_id,
            EducationLevel.deleted_at.is_(None)
        )
    )
    max_students_res = await db.execute(stmt_max)
    max_students = max_students_res.scalar()
    if not max_students or max_students < 1:
        max_students = 5

    # Cabeçalho oficial com area_subarea no formato 'Área -> Subárea', ponto_energia, mesa_prototipo, camisetas, CPFs, instituições e autores dinâmicos 1..N
    header_cols = [
        "titulo", "tipo", "nivel", "area_subarea", "estande",
        "ponto_energia", "mesa_prototipo", "resumo",
        "orientador_nome", "orientador_email", "orientador_cpf", "orientador_instituicao", "orientador_camiseta",
        "coorientador_nome", "coorientador_email", "coorientador_cpf", "coorientador_instituicao", "coorientador_camiseta"
    ]
    for i in range(1, max_students + 1):
        header_cols.extend([
            f"autor{i}_nome", f"autor{i}_email", f"autor{i}_cpf", f"autor{i}_instituicao", f"autor{i}_camiseta"
        ])

    header = ";".join(header_cols) + "\r\n"

    # Linhas de exemplo
    row1_cols = [
        "Desenvolvimento de Braço Robótico Sustentável", "Tecnológico", "Médio", sub1, "A-01",
        "Sim", "Sim", "Protótipo robótico de baixo custo utilizando materiais recicláveis",
        "Prof. Carlos Silva", "carlos.silva@escola.edu.br", "999.888.777-66", "IFMS Campus Três Lagoas", "G",
        "Profa. Mariana Costa", "mariana.costa@escola.edu.br", "888.777.666-55", "IFMS Campus Três Lagoas", "M",
        "Lucas Almeida", "lucas.almeida@aluno.edu.br", "111.222.333-01", "IFMS Campus Três Lagoas", "M",
        "Beatriz Santos", "beatriz.santos@aluno.edu.br", "222.333.444-02", "IFMS Campus Três Lagoas", "P"
    ]
    while len(row1_cols) < len(header_cols):
        row1_cols.append("")
    row1 = ";".join(row1_cols) + "\r\n"

    row2_cols = [
        "Análise da Qualidade da Água de Nascentes Urbanas", "Científico", "Médio", sub2, "A-02",
        "Não", "Não", "Investigação físico-química e microbiológica de nascentes locais",
        "Profa. Ana Paula Mendes", "ana.mendes@escola.edu.br", "777.666.555-44", "Escola Estadual Santos Dumont", "M",
        "", "", "", "", "",
        "Gabriel Rocha", "gabriel.rocha@aluno.edu.br", "333.444.555-03", "Escola Estadual Santos Dumont", "G",
        "Juliana Lima", "juliana.lima@aluno.edu.br", "444.555.666-04", "Escola Estadual Santos Dumont", "P",
        "Matheus Pereira", "matheus.pereira@aluno.edu.br", "555.666.777-05", "Escola Estadual Santos Dumont", "GG"
    ]
    while len(row2_cols) < len(header_cols):
        row2_cols.append("")
    row2 = ";".join(row2_cols) + "\r\n"

    row3_cols = [
        "Jogos Educativos no Ensino Fundamental", "Científico", "Fundamental", sub3, "B-01",
        "Não", "Sim", "Uso de gamificação lúdica para ensino de matemática básica",
        "Prof. Roberto Souza", "roberto.souza@escola.edu.br", "666.555.444-33", "Colégio Objetivo", "GG",
        "", "", "", "", "",
        "Sophia Martins", "sophia.martins@aluno.edu.br", "666.777.888-06", "Colégio Objetivo", "PP"
    ]
    while len(row3_cols) < len(header_cols):
        row3_cols.append("")
    row3 = ";".join(row3_cols) + "\r\n"

    csv_content = "\uFEFF" + header + row1 + row2 + row3
    filename = f"modelo_trabalhos_easyevent_evento_{event_id}.csv"
    return Response(
        content=csv_content.encode("utf-8"),
        media_type="text/csv; charset=utf-8",
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"'
        }
    )


@router.post(
    "/batch",
    response_model=ProjectBatchResponse,
    status_code=status.HTTP_200_OK,
    summary="Importar / Sincronizar em lote trabalhos científicos (Upsert Atômico)"
)
async def import_projects_batch(
    payload: ProjectBatchImport,
    event_id: int = Query(..., description="ID da edição ativa do evento"),
    db: AsyncSession = Depends(get_db),
    admin: Person = Depends(get_current_admin)
):
    """
    Cadastra e atualiza em lote múltiplos trabalhos científicos com criação automática de participantes.
    """
    await get_event_admin_access(event_id, min_role=EventAdminRole.ORGANIZER, db=db, admin=admin)
    return await project_service.import_projects_batch(db, event_id, payload)


@router.post(
    "/upload-csv",
    response_model=ProjectBatchResponse,
    status_code=status.HTTP_200_OK,
    summary="Upload e importação direta de arquivo CSV de trabalhos científicos"
)
async def upload_projects_csv(
    event_id: int = Query(..., description="ID da edição ativa do evento"),
    file: UploadFile = File(...),
    auto_homologate: bool = Query(True, description="Homologar trabalhos e aprovar anuência automaticamente"),
    db: AsyncSession = Depends(get_db),
    admin: Person = Depends(get_current_admin)
):
    """
    Recebe um arquivo CSV de trabalhos e processa a importação em lote com suporte a múltiplos autores.
    """
    await get_event_admin_access(event_id, min_role=EventAdminRole.ORGANIZER, db=db, admin=admin)

    contents = await file.read()
    if not contents:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Arquivo CSV vazio."
        )

    text = None
    for enc in ("utf-8-sig", "utf-8", "latin-1", "iso-8859-1"):
        try:
            text = contents.decode(enc)
            break
        except UnicodeDecodeError:
            continue

    if text is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Não foi possível decodificar o arquivo CSV. Salve o arquivo em UTF-8."
        )

    sample = text[:2048]
    delimiter = ";" if ";" in sample else ("\t" if "\t" in sample else ",")
    reader = csv.DictReader(io.StringIO(text), delimiter=delimiter)
    if not reader.fieldnames:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="O arquivo CSV não possui cabeçalho válido."
        )

    normalized_fields = {k: k.strip().lower().replace(" ", "_").replace("/", "_").replace("-", "_") for k in reader.fieldnames if k}

    items_to_import: List[ProjectBatchItem] = []
    for row in reader:
        clean_row = {}
        for orig_key, val in row.items():
            if orig_key and orig_key in normalized_fields:
                norm_key = normalized_fields[orig_key]
                clean_row[norm_key] = val.strip() if val else ""

        title = (
            clean_row.get("titulo")
            or clean_row.get("title")
            or clean_row.get("nome_do_trabalho")
            or clean_row.get("trabalho")
            or ""
        )
        if not title:
            continue

        raw_type = (clean_row.get("tipo") or clean_row.get("project_type") or "cientifico").lower()
        project_type = ProjectType.TECHNOLOGICAL if "tec" in raw_type else ProjectType.SCIENTIFIC

        raw_level = (clean_row.get("nivel") or clean_row.get("education_level") or "medio").lower()
        if "gradua" in raw_level or "superior" in raw_level:
            education_level = EducationLevelEnum.GRADUACAO
        elif "pos" in raw_level or "pós" in raw_level:
            education_level = EducationLevelEnum.POS_GRADUACAO
        elif "jun" in raw_level or "fund 1" in raw_level or "fundamental 1" in raw_level or "fundamental i" in raw_level:
            education_level = EducationLevelEnum.JUNIOR
        elif "fund" in raw_level or "fund 2" in raw_level or "fundamental 2" in raw_level or "fundamental ii" in raw_level:
            education_level = EducationLevelEnum.FUNDAMENTAL
        else:
            education_level = EducationLevelEnum.MEDIO

        subarea_name = (
            clean_row.get("area_subarea")
            or clean_row.get("area_e_subarea")
            or clean_row.get("subarea")
            or clean_row.get("sub_area")
            or clean_row.get("area")
            or clean_row.get("subarea_name")
            or clean_row.get("area_tematica")
            or ""
        )
        booth = clean_row.get("estande") or clean_row.get("bancada") or clean_row.get("booth_number") or ""
        abstract = clean_row.get("resumo") or clean_row.get("abstract") or ""

        # Infraestrutura para o estande
        raw_elec = (clean_row.get("ponto_energia") or clean_row.get("energia") or clean_row.get("needs_electricity") or clean_row.get("tomada") or "").lower()
        needs_electricity = raw_elec in ("sim", "s", "true", "1", "yes", "y")

        raw_table = (clean_row.get("mesa_prototipo") or clean_row.get("mesa") or clean_row.get("needs_table") or clean_row.get("bancada") or "").lower()
        needs_table = raw_table in ("sim", "s", "true", "1", "yes", "y")

        # Membros
        members: List[ProjectBatchMemberInput] = []

        # Orientador
        adv_name = (clean_row.get("orientador_nome") or clean_row.get("orientador") or clean_row.get("advisor_name") or "").strip()
        adv_email = (clean_row.get("orientador_email") or clean_row.get("email_orientador") or clean_row.get("advisor_email") or "").strip()
        adv_cpf = (clean_row.get("orientador_cpf") or clean_row.get("cpf_orientador") or clean_row.get("advisor_cpf") or "").strip()
        adv_inst = (
            clean_row.get("orientador_instituicao")
            or clean_row.get("orientador_afiliacao")
            or clean_row.get("instituicao_orientador")
            or clean_row.get("afiliacao_orientador")
            or clean_row.get("advisor_affiliation")
            or ""
        ).strip()
        adv_tshirt = clean_row.get("orientador_camiseta") or clean_row.get("camiseta_orientador") or clean_row.get("tshirt_orientador") or clean_row.get("tamanho_orientador") or "M"
        if adv_name:
            if not adv_email:
                slug = "".join(filter(str.isalnum, adv_name.lower()))
                adv_email = f"{slug}@easyevent.local"
            members.append(
                ProjectBatchMemberInput(
                    name=adv_name,
                    email=adv_email,
                    cpf=adv_cpf or None,
                    affiliation=adv_inst or None,
                    role=ProjectMemberRole.ADVISOR,
                    tshirt_size=adv_tshirt
                )
            )

        # Coorientador
        coadv_name = (clean_row.get("coorientador_nome") or clean_row.get("coorientador") or clean_row.get("coadvisor_name") or "").strip()
        coadv_email = (clean_row.get("coorientador_email") or clean_row.get("email_coorientador") or clean_row.get("coadvisor_email") or "").strip()
        coadv_cpf = (clean_row.get("coorientador_cpf") or clean_row.get("cpf_coorientador") or clean_row.get("coadvisor_cpf") or "").strip()
        coadv_inst = (
            clean_row.get("coorientador_instituicao")
            or clean_row.get("coorientador_afiliacao")
            or clean_row.get("instituicao_coorientador")
            or clean_row.get("afiliacao_coorientador")
            or clean_row.get("coadvisor_affiliation")
            or ""
        ).strip()
        coadv_tshirt = clean_row.get("coorientador_camiseta") or clean_row.get("camiseta_coorientador") or clean_row.get("tshirt_coorientador") or clean_row.get("tamanho_coorientador") or "M"
        if coadv_name:
            if not coadv_email:
                slug = "".join(filter(str.isalnum, coadv_name.lower()))
                coadv_email = f"{slug}@easyevent.local"
            members.append(
                ProjectBatchMemberInput(
                    name=coadv_name,
                    email=coadv_email,
                    cpf=coadv_cpf or None,
                    affiliation=coadv_inst or None,
                    role=ProjectMemberRole.COADVISOR,
                    tshirt_size=coadv_tshirt
                )
            )

        # Autores dinâmicos (1..20)
        student_idx = 0
        for i in range(1, 21):
            s_name = (
                clean_row.get(f"autor{i}_nome")
                or clean_row.get(f"aluno{i}_nome")
                or clean_row.get(f"estudante{i}_nome")
                or clean_row.get(f"autor_{i}_nome")
                or clean_row.get(f"autor{i}")
                or ""
            ).strip()
            if not s_name:
                continue

            s_email = (
                clean_row.get(f"autor{i}_email")
                or clean_row.get(f"aluno{i}_email")
                or clean_row.get(f"estudante{i}_email")
                or clean_row.get(f"autor_{i}_email")
                or clean_row.get(f"email_autor{i}")
                or ""
            ).strip()
            if not s_email:
                slug = "".join(filter(str.isalnum, s_name.lower()))
                s_email = f"{slug}@aluno.easyevent.local"

            s_cpf = (
                clean_row.get(f"autor{i}_cpf")
                or clean_row.get(f"aluno{i}_cpf")
                or clean_row.get(f"estudante{i}_cpf")
                or clean_row.get(f"autor_{i}_cpf")
                or clean_row.get(f"cpf_autor{i}")
                or clean_row.get(f"cpf_aluno{i}")
                or ""
            ).strip()

            s_inst = (
                clean_row.get(f"autor{i}_instituicao")
                or clean_row.get(f"aluno{i}_instituicao")
                or clean_row.get(f"estudante{i}_instituicao")
                or clean_row.get(f"autor_{i}_instituicao")
                or clean_row.get(f"instituicao_autor{i}")
                or clean_row.get(f"instituicao_aluno{i}")
                or clean_row.get(f"autor{i}_afiliacao")
                or clean_row.get(f"aluno{i}_afiliacao")
                or clean_row.get(f"autor{i}_perfil")
                or clean_row.get(f"aluno{i}_perfil")
                or ""
            ).strip()

            s_tshirt = (
                clean_row.get(f"autor{i}_camiseta")
                or clean_row.get(f"aluno{i}_camiseta")
                or clean_row.get(f"estudante{i}_camiseta")
                or clean_row.get(f"autor_{i}_camiseta")
                or clean_row.get(f"camiseta_autor{i}")
                or clean_row.get(f"camiseta_aluno{i}")
                or clean_row.get(f"tamanho_autor{i}")
                or "M"
            ).strip()

            role = ProjectMemberRole.STUDENT_LEADER if student_idx == 0 else ProjectMemberRole.STUDENT_MEMBER
            members.append(
                ProjectBatchMemberInput(
                    name=s_name,
                    email=s_email,
                    cpf=s_cpf or None,
                    affiliation=s_inst or None,
                    role=role,
                    tshirt_size=s_tshirt
                )
            )
            student_idx += 1

        items_to_import.append(
            ProjectBatchItem(
                title=title,
                project_type=project_type,
                education_level=education_level,
                subarea_name=subarea_name,
                booth_number=booth or None,
                abstract=abstract or None,
                needs_electricity=needs_electricity,
                needs_table=needs_table,
                members=members,
                auto_homologate=auto_homologate
            )
        )

    if not items_to_import:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Nenhum trabalho válido encontrado no arquivo CSV."
        )

    batch_payload = ProjectBatchImport(items=items_to_import, auto_homologate=auto_homologate)
    return await project_service.import_projects_batch(db, event_id, batch_payload)


@router.get(
    "/{project_id}",
    response_model=ProjectResponse,
    status_code=status.HTTP_200_OK,
    summary="Consultar dados do projeto"
)
async def get_project(
    project_id: int,
    db: AsyncSession = Depends(get_db)
):
    """Retorna detalhes do projeto, status atual no ciclo de vida e integrantes."""
    return await project_service.get_project_by_id(db, project_id)


@router.post(
    "/{project_id}/consent",
    response_model=AdvisorConsentResponse,
    status_code=status.HTTP_200_OK,
    summary="Conceder anuência digital formal do orientador (BR-05)"
)
async def grant_advisor_consent(
    project_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: Person = Depends(get_current_user)
):
    """
    Registra a anuência formal do Orientador.
    Apenas o orientador titular formalmente indicado na submissão pode conceder esta anuência.
    Promove o trabalho de WAITING_CONSENT para SUBMITTED (liberado para homologação).
    """
    return await project_service.grant_advisor_consent(
        db=db,
        project_id=project_id,
        advisor=current_user
    )


@router.patch(
    "/{project_id}/homologate",
    response_model=ProjectResponse,
    status_code=status.HTTP_200_OK,
    summary="Homologar ou reprovar projeto submetido (Coordenação)"
)
async def homologate_project(
    project_id: int,
    payload: ProjectHomologateRequest,
    db: AsyncSession = Depends(get_db),
    admin: Person = Depends(get_current_admin)
):
    """Homologa a submissão para a feira presencial (exige prévia anuência do orientador)."""
    return await project_service.homologate_project(
        db=db,
        project_id=project_id,
        homologated=payload.homologated,
        booth_number=payload.booth_number,
        rejection_reason=payload.rejection_reason
    )


@router.patch(
    "/{project_id}/booth",
    response_model=ProjectResponse,
    status_code=status.HTTP_200_OK,
    summary="Alocar ou alterar número de bancada/estande do projeto"
)
async def assign_booth(
    project_id: int,
    payload: ProjectBoothAssignmentRequest,
    db: AsyncSession = Depends(get_db),
    admin: Person = Depends(get_current_admin)
):
    """Aloca o número de estande/bancada para o projeto homologado."""
    return await project_service.assign_booth_number(
        db=db,
        project_id=project_id,
        booth_number=payload.booth_number
    )


@router.put(
    "/{project_id}",
    response_model=ProjectResponse,
    status_code=status.HTTP_200_OK,
    summary="Atualizar dados cadastrais do projeto (Coordenação / Organizador)"
)
async def update_project(
    project_id: int,
    payload: ProjectUpdate,
    db: AsyncSession = Depends(get_db),
    admin: Person = Depends(get_current_admin)
):
    """Atualiza título, subárea, nível, tipo, estande, resumo e infraestrutura do projeto."""
    project = await project_service.get_project_by_id(db, project_id)
    await get_event_admin_access(project.event_id, min_role=EventAdminRole.ORGANIZER, db=db, admin=admin)
    return await project_service.update_project(db=db, project_id=project_id, payload=payload)


@router.get(
    "/{project_id}/booth-sticker/pdf",
    summary="Exportar adesivo individual com QR Code de bancada do projeto em PDF",
)
async def export_project_booth_sticker_pdf(
    project_id: int,
    layout: str = Query("a5_double", regex="^(a5_double|a6_quad)$"),
    db: AsyncSession = Depends(get_db),
    admin: Person = Depends(get_current_admin),
):
    """
    Gera o PDF com o adesivo de bancada para um trabalho específico.
    """
    from app.services.booth_sticker_service import generate_event_booth_stickers_pdf

    project = await project_service.get_project_by_id(db, project_id)
    await get_event_admin_access(project.event_id, min_role=EventAdminRole.ORGANIZER, db=db, admin=admin)

    pdf_bytes = await generate_event_booth_stickers_pdf(
        db=db,
        event_id=project.event_id,
        project_id=project.id,
        layout=layout,
    )
    filename = f"adesivo_bancada_projeto_{project.id}_{layout}.pdf"

    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
            "Cache-Control": "no-cache",
        },
    )

