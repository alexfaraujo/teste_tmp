"""Authentication endpoints (Admin login, OTP generation and verification)."""

from fastapi import APIRouter, Depends, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_user
from app.core.database import get_db
from app.models.person import Person
from app.schemas.auth import (
    AdminLoginRequest,
    OTPRequest,
    OTPVerifyRequest,
    TokenResponse,
    UserProfileResponse,
    RegisterRequestCodeRequest,
    RegisterRequestCodeResponse,
    RegisterCompleteRequest
)
from app.services.auth_service import (
    authenticate_admin,
    generate_and_send_otp,
    verify_otp_and_login,
    request_registration_otp,
    verify_registration_and_complete
)

router = APIRouter(prefix="/auth", tags=["Autenticação"])


@router.post(
    "/admin/login",
    response_model=TokenResponse,
    status_code=status.HTTP_200_OK,
    summary="Login de Administrador com e-mail e senha mestre"
)
async def login_admin(
    payload: AdminLoginRequest,
    db: AsyncSession = Depends(get_db)
):
    """Autentica o administrador do evento e emite um token JWT Bearer com validade de 12 horas."""
    return await authenticate_admin(
        db=db,
        email=payload.email,
        password=payload.password
    )


@router.post(
    "/request-code",
    status_code=status.HTTP_200_OK,
    summary="Solicitar código OTP de 8 caracteres por e-mail"
)
async def request_otp_code(
    payload: OTPRequest,
    db: AsyncSession = Depends(get_db)
):
    """Gera um código aleatório exclusivo de 8 caracteres em caixa alta e envia ao e-mail cadastrado."""
    return await generate_and_send_otp(
        db=db,
        email=payload.email
    )


@router.post(
    "/verify-code",
    response_model=TokenResponse,
    status_code=status.HTTP_200_OK,
    summary="Validar código OTP de 8 caracteres e entrar no sistema"
)
async def verify_otp(
    payload: OTPVerifyRequest,
    db: AsyncSession = Depends(get_db)
):
    """Valida o código digitado em campo mascarado pelo participante e emite o token JWT Bearer."""
    return await verify_otp_and_login(
        db=db,
        email=payload.email,
        access_code=payload.access_code
    )


@router.post(
    "/register/request-code",
    response_model=RegisterRequestCodeResponse,
    status_code=status.HTTP_200_OK,
    summary="Solicitar código OTP para auto-cadastro de organizador de feiras (Regra BR-24)"
)
async def register_request_code(
    payload: RegisterRequestCodeRequest,
    db: AsyncSession = Depends(get_db)
):
    """
    Gera código OTP de 8 caracteres alfanuméricos com expiração de 15 minutos
    para verificação prévia da caixa postal do organizador de feiras.
    """
    return await request_registration_otp(
        db=db,
        email=payload.email,
        name=payload.name
    )


@router.post(
    "/register/verify-and-complete",
    response_model=TokenResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Validar código OTP, definir senha e concluir auto-cadastro (Regra BR-24)"
)
async def register_verify_and_complete(
    payload: RegisterCompleteRequest,
    db: AsyncSession = Depends(get_db)
):
    """
    Comprova o e-mail via OTP, define a senha mestre pessoal, cadastra o organizador
    e emite o token JWT Bearer para acesso imediato e autônomo ao painel de feiras.
    """
    return await verify_registration_and_complete(
        db=db,
        payload=payload
    )


@router.get(
    "/me",
    response_model=UserProfileResponse,
    status_code=status.HTTP_200_OK,
    summary="Consultar dados do usuário autenticado atual"
)
async def get_me(
    current_user: Person = Depends(get_current_user)
):
    """Retorna os dados cadastrais e o papel ativo da pessoa autenticada via token Bearer."""
    return UserProfileResponse(
        id=current_user.id,
        name=current_user.name,
        email=current_user.email,
        role=current_user.role.value,
        barcode=current_user.barcode
    )
