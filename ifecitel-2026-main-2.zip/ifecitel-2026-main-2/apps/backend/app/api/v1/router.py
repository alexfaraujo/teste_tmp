"""API v1 Central Router."""

from fastapi import APIRouter, Depends
from app.api.deps import verify_api_key
from app.api.v1.endpoints import (
    allocations,
    auth,
    awards,
    dashboard,
    evaluations,
    events,
    knowledge_areas,
    logistics,
    participants,
    projects,
    snacks
)

api_router = APIRouter(dependencies=[Depends(verify_api_key)])
api_router.include_router(auth.router)
api_router.include_router(events.router)
api_router.include_router(knowledge_areas.router)
api_router.include_router(awards.router)
api_router.include_router(projects.router)
api_router.include_router(participants.router)
api_router.include_router(logistics.router)
api_router.include_router(allocations.router)
api_router.include_router(evaluations.router)
api_router.include_router(dashboard.router)
api_router.include_router(snacks.router)

