from typing import Optional, Tuple
from fastapi import Depends, HTTPException, Security, status
from fastapi.security import APIKeyHeader, APIKeyQuery, HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.database import get_db
from app.core.security import decode_access_token
from app.models.enums import UserRole, EventAdminRole
from app.models.event import Event, EventAdministrator
from app.models.person import Person

api_key_header = APIKeyHeader(name=settings.API_KEY_NAME, auto_error=False)
api_key_query = APIKeyQuery(name="api_key", auto_error=False)
security_bearer = HTTPBearer(auto_error=False)


async def verify_api_key(
    header_key: Optional[str] = Security(api_key_header),
    query_key: Optional[str] = Security(api_key_query)
) -> str:
    """
    Validação mandatória de API Key corporativa para 100% das rotas da API (Regra SEC-03).
    Garante proteção estrita contra requisições desprovidas da chave, incluindo expressamente rotas GET.
    """
    key = header_key or query_key
    if not key or key != settings.API_KEY:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Acesso não autorizado: API Key ausente ou inválida. Todas as rotas exigem a chave corporativa no cabeçalho 'X-API-Key'."
        )
    return key


async def get_current_user(
    auth: HTTPAuthorizationCredentials = Depends(security_bearer),
    db: AsyncSession = Depends(get_db)
) -> Person:
    """Extrai e valida o token Bearer JWT e retorna a entidade Person ativa correspondente."""
    if not auth or not auth.credentials:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token de autenticação não fornecido no cabeçalho Authorization."
        )

    payload = decode_access_token(auth.credentials)
    if not payload or "sub" not in payload:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token de autenticação inválido ou expirado. Faça login novamente."
        )

    person_id = int(payload["sub"])
    stmt = select(Person).where(
        Person.id == person_id,
        Person.deleted_at.is_(None)
    )
    result = await db.execute(stmt)
    person = result.scalar_one_or_none()

    if not person:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Usuário associado ao token não foi encontrado ou está inativo."
        )

    return person


async def get_current_admin(
    current_user: Person = Depends(get_current_user)
) -> Person:
    """Valida se o usuário autenticado possui perfil de Administrador (least privilege)."""
    if current_user.role != UserRole.ADMIN:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Acesso negado: operação restrita a Administradores do Evento."
        )
    return current_user


async def get_current_evaluator(
    current_user: Person = Depends(get_current_user)
) -> Person:
    """Valida se o usuário autenticado possui perfil de Avaliador ou Administrador."""
    if current_user.role not in (UserRole.EVALUATOR, UserRole.ADMIN):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Acesso negado: operação restrita a Avaliadores ou Administradores."
        )
    return current_user


ROLE_HIERARCHY = {
    EventAdminRole.COORDINATOR: 3,
    EventAdminRole.ORGANIZER: 2,
    EventAdminRole.OPERATOR: 1,
}


async def get_optional_admin(
    auth: Optional[HTTPAuthorizationCredentials] = Depends(security_bearer),
    db: AsyncSession = Depends(get_db)
) -> Optional[Person]:
    """Retorna o Person admin se o cabeçalho Authorization for fornecido e válido, caso contrário None."""
    if not auth or not auth.credentials:
        return None
    try:
        payload = decode_access_token(auth.credentials)
        if not payload or "sub" not in payload:
            return None
        person_id = int(payload["sub"])
        stmt = select(Person).where(Person.id == person_id, Person.deleted_at.is_(None))
        res = await db.execute(stmt)
        person = res.scalar_one_or_none()
        if person and person.role == UserRole.ADMIN:
            return person
    except Exception:
        pass
    return None


async def get_event_admin_access(
    event_id: int,
    min_role: EventAdminRole = EventAdminRole.OPERATOR,
    db: AsyncSession = Depends(get_db),
    admin: Person = Depends(get_current_admin)
) -> Tuple[Event, EventAdminRole]:
    """
    Valida se o administrador autenticado tem acesso ao evento com papel igual ou superior a min_role.
    Retorna (event, role). Lança 403 Forbidden se não pertencer à equipe daquela feira (Regra BR-23).
    """
    stmt = select(Event).where(Event.id == event_id, Event.deleted_at.is_(None))
    res = await db.execute(stmt)
    event = res.scalar_one_or_none()
    if not event:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Evento com ID {event_id} não encontrado."
        )

    # Se o evento não possui dono definido (ex: fixtures em testes unitários legados), vincula ao admin atual
    if event.owner_id is None:
        event.owner_id = admin.id
        db.add(EventAdministrator(
            event_id=event.id,
            person_id=admin.id,
            role=EventAdminRole.COORDINATOR
        ))
        await db.commit()
        return event, EventAdminRole.COORDINATOR

    # Coordenador Geral / Dono tem acesso total irrestrito (nível 3)
    if event.owner_id == admin.id:
        return event, EventAdminRole.COORDINATOR

    # Consulta vínculo em event_administrators
    ea_stmt = select(EventAdministrator).where(
        EventAdministrator.event_id == event_id,
        EventAdministrator.person_id == admin.id,
        EventAdministrator.deleted_at.is_(None)
    )
    ea_res = await db.execute(ea_stmt)
    ea = ea_res.scalar_one_or_none()

    if not ea:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Acesso negado: você não possui permissão para gerenciar esta feira."
        )

    if ROLE_HIERARCHY.get(ea.role, 0) < ROLE_HIERARCHY.get(min_role, 0):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"Acesso negado: esta operação requer permissão mínima de {min_role.value}."
        )

    return event, ea.role


def require_event_role(min_role: EventAdminRole = EventAdminRole.OPERATOR):
    """Dependência injetável para validação do papel mínimo do administrador no evento."""
    async def _verifier(
        event_id: int,
        db: AsyncSession = Depends(get_db),
        admin: Person = Depends(get_current_admin)
    ) -> Tuple[Event, EventAdminRole]:
        return await get_event_admin_access(event_id, min_role=min_role, db=db, admin=admin)
    return _verifier


