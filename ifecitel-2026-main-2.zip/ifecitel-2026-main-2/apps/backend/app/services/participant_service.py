"""Service for managing participants in an event (CRUD de Participantes)."""

from datetime import datetime, timezone
import random
import string
from typing import Dict, List, Optional, Tuple
import unicodedata
from fastapi import HTTPException, status
from sqlalchemy import func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.enums import UserRole, EducationLevelEnum
from app.models.event import Event
from app.models.knowledge_area import KnowledgeArea, Subarea
from app.models.person import EventParticipant, Person, PersonSubarea, EventParticipantRole, PersonEducationLevel
from app.models.project import Project, ProjectMember
from app.schemas.person import (
    PaginatedParticipantsResponse,
    ParticipantBatchImport,
    ParticipantBatchItem,
    ParticipantBatchResponse,
    ParticipantCreateRequest,
    ParticipantDetailResponse,
    ParticipantItemResponse,
    ParticipantProjectItem,
    ParticipantSubareaItem,
    ParticipantUpdateRequest,
)


def generate_barcode() -> str:
    """Gera um código de barras único no formato BC-XXXXX."""
    suffix = "".join(random.choices(string.ascii_uppercase + string.digits, k=5))
    return f"BC-{suffix}"


def _normalize_name(text: str) -> str:
    """Normaliza texto removendo acentos, pontuação desnecessária e espaços, convertendo para minúsculas."""
    if not text:
        return ""
    nfd = unicodedata.normalize("NFD", text.strip().lower())
    return "".join(c for c in nfd if unicodedata.category(c) != "Mn")


def _parse_subarea_entry(entry: str) -> Tuple[Optional[str], str]:
    """Separa uma entrada de subárea em (area_nome, subarea_nome) caso use separadores como '->', '>', ':'."""
    for sep in ["->", ">", ":"]:
        if sep in entry:
            parts = entry.split(sep, 1)
            return parts[0].strip(), parts[1].strip()
    return None, entry.strip()


async def _sync_participant_roles(
    db: AsyncSession,
    person_id: int,
    event_id: int,
    target_roles: List[UserRole],
) -> None:
    """Sincroniza os múltiplos papéis do participante na edição do evento (Opção 1)."""
    stmt = select(EventParticipantRole).where(
        EventParticipantRole.person_id == person_id,
        EventParticipantRole.event_id == event_id,
    )
    res = await db.execute(stmt)
    existing_roles = res.scalars().all()
    existing_map = {er.role: er for er in existing_roles}

    # 1. Soft-delete papéis removidos
    for role, er in existing_map.items():
        if role not in target_roles and er.deleted_at is None:
            er.deleted_at = datetime.now(timezone.utc)

    # 2. Adicionar ou reativar papéis solicitados
    for role in target_roles:
        if role in existing_map:
            er = existing_map[role]
            if er.deleted_at is not None:
                er.deleted_at = None
        else:
            db.add(
                EventParticipantRole(
                    person_id=person_id,
                    event_id=event_id,
                    role=role,
                )
            )
    await db.flush()


async def _sync_evaluator_education_levels(
    db: AsyncSession,
    person_id: int,
    event_id: int,
    target_levels: Optional[List[EducationLevelEnum]],
) -> None:
    """Sincroniza os níveis de ensino que o avaliador está habilitado a avaliar na edição."""
    stmt = select(PersonEducationLevel).where(
        PersonEducationLevel.person_id == person_id,
        PersonEducationLevel.event_id == event_id,
    )
    res = await db.execute(stmt)
    existing_records = res.scalars().all()
    existing_map = {rec.education_level: rec for rec in existing_records}

    clean_target = set(target_levels) if target_levels is not None else set()

    # 1. Soft-delete níveis removidos
    for lvl, rec in existing_map.items():
        if lvl not in clean_target and rec.deleted_at is None:
            rec.deleted_at = datetime.now(timezone.utc)

    # 2. Adicionar ou reativar níveis solicitados
    for lvl in clean_target:
        if lvl in existing_map:
            rec = existing_map[lvl]
            if rec.deleted_at is not None:
                rec.deleted_at = None
        else:
            db.add(
                PersonEducationLevel(
                    person_id=person_id,
                    event_id=event_id,
                    education_level=lvl,
                )
            )
    await db.flush()


async def _sync_evaluator_subareas(
    db: AsyncSession,
    person_id: int,
    event_id: int,
    target_subarea_ids: Optional[List[int]],
) -> None:
    """Sincroniza as subáreas de conhecimento do avaliador na edição com soft-delete/reativação."""
    stmt = select(PersonSubarea).where(
        PersonSubarea.person_id == person_id,
        PersonSubarea.event_id == event_id,
    )
    res = await db.execute(stmt)
    existing_records = res.scalars().all()
    existing_map = {rec.subarea_id: rec for rec in existing_records}

    clean_target = set(target_subarea_ids) if target_subarea_ids is not None else set()

    # 1. Soft-delete subáreas removidas
    for sid, rec in existing_map.items():
        if sid not in clean_target and rec.deleted_at is None:
            rec.deleted_at = datetime.now(timezone.utc)

    # 2. Adicionar ou reativar subáreas solicitadas
    for sid in clean_target:
        if sid in existing_map:
            rec = existing_map[sid]
            if rec.deleted_at is not None:
                rec.deleted_at = None
        else:
            db.add(
                PersonSubarea(
                    person_id=person_id,
                    subarea_id=sid,
                    event_id=event_id,
                )
            )
    await db.flush()




async def list_participants(
    db: AsyncSession,
    event_id: int,
    page: int = 1,
    limit: int = 15,
    search: Optional[str] = None,
    role: Optional[UserRole] = None,
    presence: Optional[bool] = None,
    kit_delivered: Optional[bool] = None,
) -> PaginatedParticipantsResponse:
    """Lista participantes vinculados a uma edição de evento com paginação real e filtros (BR-18)."""
    # 1. Base Query
    base_conditions = [
        EventParticipant.event_id == event_id,
        EventParticipant.deleted_at.is_(None),
        Person.deleted_at.is_(None),
    ]

    if role:
        role_subquery = (
            select(EventParticipantRole.person_id)
            .where(
                EventParticipantRole.event_id == event_id,
                EventParticipantRole.role == role,
                EventParticipantRole.deleted_at.is_(None),
            )
        )
        base_conditions.append(
            or_(
                EventParticipant.person_id.in_(role_subquery),
                Person.role == role,
            )
        )

    if presence is not None:
        base_conditions.append(EventParticipant.presence_confirmed == presence)

    if kit_delivered is not None:
        base_conditions.append(EventParticipant.kit_delivered == kit_delivered)

    if search and search.strip():
        s = f"%{search.strip()}%"
        digits_only = "".join(filter(str.isdigit, search.strip()))
        search_clauses = [
            Person.name.ilike(s),
            Person.email.ilike(s),
            Person.cpf.ilike(s),
            Person.barcode.ilike(s),
            Person.affiliation.ilike(s),
        ]
        if digits_only and len(digits_only) >= 3:
            cleaned_cpf = func.replace(func.replace(Person.cpf, '.', ''), '-', '')
            search_clauses.append(cleaned_cpf.ilike(f"%{digits_only}%"))
            if len(digits_only) == 11:
                formatted_cpf = f"{digits_only[:3]}.{digits_only[3:6]}.{digits_only[6:9]}-{digits_only[9:]}"
                search_clauses.append(Person.cpf == formatted_cpf)

        base_conditions.append(or_(*search_clauses))

    # 2. Contagem total
    count_stmt = (
        select(func.count(EventParticipant.id))
        .join(Person, EventParticipant.person_id == Person.id)
        .where(*base_conditions)
    )
    res_count = await db.execute(count_stmt)
    total = res_count.scalar() or 0

    total_pages = max(1, (total + limit - 1) // limit) if total > 0 else 1
    offset_val = (page - 1) * limit

    # 3. Consulta de Dados
    stmt = (
        select(
            EventParticipant.id.label("participant_id"),
            Person.id.label("person_id"),
            EventParticipant.event_id,
            Person.name,
            Person.email,
            Person.cpf,
            Person.affiliation,
            Person.role,
            Person.barcode,
            EventParticipant.tshirt_size,
            EventParticipant.kit_delivered,
            EventParticipant.kit_delivered_at,
            EventParticipant.presence_confirmed,
            EventParticipant.presence_confirmed_at,
            EventParticipant.evaluator_presence_confirmed,
            EventParticipant.evaluator_presence_confirmed_at,
            Person.created_at,
        )
        .join(Person, EventParticipant.person_id == Person.id)
        .where(*base_conditions)
        .order_by(Person.name.asc())
        .offset(offset_val)
        .limit(limit)
    )

    result = await db.execute(stmt)
    rows = result.all()

    person_ids = [r.person_id for r in rows]

    # 4. Obter múltiplos papéis de cada participante neste evento
    person_roles_map = {}
    if person_ids:
        roles_stmt = (
            select(
                EventParticipantRole.person_id,
                EventParticipantRole.role,
            )
            .where(
                EventParticipantRole.person_id.in_(person_ids),
                EventParticipantRole.event_id == event_id,
                EventParticipantRole.deleted_at.is_(None),
            )
        )
        roles_res = await db.execute(roles_stmt)
        for pid, r_role in roles_res.all():
            if pid not in person_roles_map:
                person_roles_map[pid] = []
            if r_role not in person_roles_map[pid]:
                person_roles_map[pid].append(r_role)

    # 5. Obter contagem de projetos para cada participante neste evento
    project_counts = {}
    if person_ids:
        proj_count_stmt = (
            select(
                ProjectMember.person_id,
                func.count(Project.id).label("p_count")
            )
            .join(Project, ProjectMember.project_id == Project.id)
            .where(
                ProjectMember.person_id.in_(person_ids),
                Project.event_id == event_id,
                ProjectMember.deleted_at.is_(None),
                Project.deleted_at.is_(None),
            )
            .group_by(ProjectMember.person_id)
        )
        proj_res = await db.execute(proj_count_stmt)
        for pid, pcount in proj_res.all():
            project_counts[pid] = pcount

    # 6. Obter níveis de ensino habilitados para avaliadores neste evento
    person_education_levels_map = {}
    if person_ids:
        levels_stmt = (
            select(
                PersonEducationLevel.person_id,
                PersonEducationLevel.education_level,
            )
            .where(
                PersonEducationLevel.person_id.in_(person_ids),
                PersonEducationLevel.event_id == event_id,
                PersonEducationLevel.deleted_at.is_(None),
            )
        )
        levels_res = await db.execute(levels_stmt)
        for pid, elevel in levels_res.all():
            if pid not in person_education_levels_map:
                person_education_levels_map[pid] = []
            if elevel not in person_education_levels_map[pid]:
                person_education_levels_map[pid].append(elevel)

    items = []
    for r in rows:
        p_roles = person_roles_map.get(r.person_id, [])
        if not p_roles and r.role:
            p_roles = [r.role]
        primary_role = p_roles[0] if p_roles else r.role

        items.append(
            ParticipantItemResponse(
                participant_id=r.participant_id,
                person_id=r.person_id,
                event_id=r.event_id,
                name=r.name,
                email=r.email,
                cpf=r.cpf,
                affiliation=r.affiliation,
                role=primary_role,
                roles=p_roles,
                barcode=r.barcode,
                tshirt_size=r.tshirt_size,
                kit_delivered=r.kit_delivered,
                kit_delivered_at=r.kit_delivered_at,
                presence_confirmed=r.presence_confirmed,
                presence_confirmed_at=r.presence_confirmed_at,
                evaluator_presence_confirmed=r.evaluator_presence_confirmed,
                evaluator_presence_confirmed_at=r.evaluator_presence_confirmed_at,
                education_levels=person_education_levels_map.get(r.person_id, []),
                projects_count=project_counts.get(r.person_id, 0),
                created_at=r.created_at,
            )
        )


    return PaginatedParticipantsResponse(
        items=items,
        total=total,
        page=page,
        limit=limit,
        total_pages=total_pages,
    )


async def get_participant(
    db: AsyncSession,
    event_id: int,
    person_id: int,
) -> ParticipantDetailResponse:
    """Retorna detalhes completos do participante no evento com projetos e subáreas."""
    stmt = (
        select(
            EventParticipant.id.label("participant_id"),
            Person.id.label("person_id"),
            EventParticipant.event_id,
            Person.name,
            Person.email,
            Person.cpf,
            Person.affiliation,
            Person.role,
            Person.barcode,
            EventParticipant.tshirt_size,
            EventParticipant.kit_delivered,
            EventParticipant.kit_delivered_at,
            EventParticipant.presence_confirmed,
            EventParticipant.presence_confirmed_at,
            EventParticipant.evaluator_presence_confirmed,
            EventParticipant.evaluator_presence_confirmed_at,
            Person.created_at,
        )
        .join(Person, EventParticipant.person_id == Person.id)
        .where(
            EventParticipant.event_id == event_id,
            EventParticipant.person_id == person_id,
            EventParticipant.deleted_at.is_(None),
            Person.deleted_at.is_(None),
        )
    )
    result = await db.execute(stmt)
    r = result.one_or_none()
    if not r:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Participante não encontrado nesta edição do evento.",
        )

    # Buscar projetos do participante
    proj_stmt = (
        select(
            Project.id.label("project_id"),
            Project.title,
            ProjectMember.role.label("member_role"),
            Project.booth_number,
        )
        .join(ProjectMember, Project.id == ProjectMember.project_id)
        .where(
            ProjectMember.person_id == person_id,
            Project.event_id == event_id,
            ProjectMember.deleted_at.is_(None),
            Project.deleted_at.is_(None),
        )
    )
    proj_res = await db.execute(proj_stmt)
    projects = [
        ParticipantProjectItem(
            project_id=p.project_id,
            title=p.title,
            member_role=p.member_role.value if hasattr(p.member_role, "value") else str(p.member_role),
            booth_number=p.booth_number,
        )
        for p in proj_res.all()
    ]

    # Buscar papéis na edição do evento
    epr_stmt = (
        select(EventParticipantRole.role)
        .where(
            EventParticipantRole.person_id == person_id,
            EventParticipantRole.event_id == event_id,
            EventParticipantRole.deleted_at.is_(None),
        )
    )
    epr_res = await db.execute(epr_stmt)
    roles = [row[0] for row in epr_res.all()]
    if not roles and r.role:
        roles = [r.role]
    primary_role = roles[0] if roles else r.role

    # Buscar subáreas se for avaliador
    subareas = []
    if UserRole.EVALUATOR in roles or r.role == UserRole.EVALUATOR:
        sub_stmt = (
            select(
                Subarea.id.label("subarea_id"),
                Subarea.name.label("subarea_name"),
                KnowledgeArea.name.label("area_name"),
            )
            .join(PersonSubarea, Subarea.id == PersonSubarea.subarea_id)
            .join(KnowledgeArea, Subarea.area_id == KnowledgeArea.id)
            .where(
                PersonSubarea.person_id == person_id,
                PersonSubarea.event_id == event_id,
                PersonSubarea.deleted_at.is_(None),
            )
        )
        sub_res = await db.execute(sub_stmt)
        subareas = [
            ParticipantSubareaItem(
                subarea_id=s.subarea_id,
                subarea_name=s.subarea_name,
                area_name=s.area_name,
            )
            for s in sub_res.all()
        ]

    # Buscar níveis de ensino se for avaliador
    education_levels = []
    if UserRole.EVALUATOR in roles or r.role == UserRole.EVALUATOR:
        el_stmt = (
            select(PersonEducationLevel.education_level)
            .where(
                PersonEducationLevel.person_id == person_id,
                PersonEducationLevel.event_id == event_id,
                PersonEducationLevel.deleted_at.is_(None),
            )
        )
        el_res = await db.execute(el_stmt)
        education_levels = [row[0] for row in el_res.all()]

    return ParticipantDetailResponse(
        participant_id=r.participant_id,
        person_id=r.person_id,
        event_id=r.event_id,
        name=r.name,
        email=r.email,
        cpf=r.cpf,
        affiliation=r.affiliation,
        role=primary_role,
        roles=roles,
        barcode=r.barcode,
        tshirt_size=r.tshirt_size,
        kit_delivered=r.kit_delivered,
        kit_delivered_at=r.kit_delivered_at,
        presence_confirmed=r.presence_confirmed,
        presence_confirmed_at=r.presence_confirmed_at,
        evaluator_presence_confirmed=r.evaluator_presence_confirmed,
        evaluator_presence_confirmed_at=r.evaluator_presence_confirmed_at,
        education_levels=education_levels,
        projects_count=len(projects),
        created_at=r.created_at,
        projects=projects,
        subareas=subareas,
    )


async def create_participant(
    db: AsyncSession,
    event_id: int,
    payload: ParticipantCreateRequest,
) -> ParticipantItemResponse:
    """Cria um novo participante e o vincula à edição ativa do evento com múltiplos papéis (Opção 1)."""
    # 1. Verificar se evento existe
    event = await db.get(Event, event_id)
    if not event or event.deleted_at is not None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Edição do evento não encontrada.",
        )

    # 2. Determinar papéis solicitados
    if payload.roles:
        target_roles = list(dict.fromkeys(payload.roles))
    elif payload.role:
        target_roles = [payload.role]
    else:
        target_roles = [UserRole.STUDENT]

    if UserRole.ADMIN in target_roles:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="O papel Administrador não pode ser atribuído a participantes. A gestão da equipe administrativa do evento deve ser realizada exclusivamente na tela de Equipe da Feira.",
        )

    primary_role = target_roles[0]

    # 3. Localizar ou criar Person por e-mail
    stmt_person = select(Person).where(Person.email == payload.email)
    res_person = await db.execute(stmt_person)
    person = res_person.scalar_one_or_none()

    if person:
        # Atualiza dados se a pessoa já existia
        person.name = payload.name.strip()
        if payload.cpf:
            person.cpf = payload.cpf.strip()
        if payload.affiliation:
            person.affiliation = payload.affiliation.strip()
        person.role = primary_role
        if person.deleted_at is not None:
            person.deleted_at = None
    else:
        barcode = payload.barcode.strip() if payload.barcode else generate_barcode()
        person = Person(
            name=payload.name.strip(),
            email=payload.email.strip().lower(),
            cpf=payload.cpf.strip() if payload.cpf else None,
            affiliation=payload.affiliation.strip() if payload.affiliation else None,
            role=primary_role,
            barcode=barcode,
        )
        db.add(person)
        await db.flush()

    # 4. Vincular ao evento via EventParticipant
    stmt_part = select(EventParticipant).where(
        EventParticipant.event_id == event_id,
        EventParticipant.person_id == person.id,
    )
    res_part = await db.execute(stmt_part)
    participant = res_part.scalar_one_or_none()

    if participant:
        participant.tshirt_size = payload.tshirt_size or "M"
        if participant.deleted_at is not None:
            participant.deleted_at = None
    else:
        participant = EventParticipant(
            event_id=event_id,
            person_id=person.id,
            tshirt_size=payload.tshirt_size or "M",
            kit_delivered=False,
            presence_confirmed=False,
        )
        db.add(participant)
        await db.flush()

    # 5. Sincronizar papéis múltiplos em event_participant_roles
    await _sync_participant_roles(db, person.id, event_id, target_roles)

    # 6. Vincular subáreas se for avaliador
    if UserRole.EVALUATOR in target_roles and payload.subarea_ids:
        del_stmt = select(PersonSubarea).where(
            PersonSubarea.person_id == person.id,
            PersonSubarea.event_id == event_id,
        )
        del_res = await db.execute(del_stmt)
        for ps in del_res.scalars().all():
            await db.delete(ps)

        for sid in set(payload.subarea_ids):
            db.add(
                PersonSubarea(
                    person_id=person.id,
                    subarea_id=sid,
                    event_id=event_id,
                )
            )

    # 7. Vincular níveis de ensino se for avaliador
    if UserRole.EVALUATOR in target_roles and payload.education_levels is not None:
        await _sync_evaluator_education_levels(db, person.id, event_id, payload.education_levels)

    await db.commit()

    return ParticipantItemResponse(
        participant_id=participant.id,
        person_id=person.id,
        event_id=event_id,
        name=person.name,
        email=person.email,
        cpf=person.cpf,
        affiliation=person.affiliation,
        role=primary_role,
        roles=target_roles,
        barcode=person.barcode,
        tshirt_size=participant.tshirt_size,
        kit_delivered=participant.kit_delivered,
        kit_delivered_at=participant.kit_delivered_at,
        presence_confirmed=participant.presence_confirmed,
        presence_confirmed_at=participant.presence_confirmed_at,
        evaluator_presence_confirmed=participant.evaluator_presence_confirmed,
        evaluator_presence_confirmed_at=participant.evaluator_presence_confirmed_at,
        education_levels=payload.education_levels or [] if UserRole.EVALUATOR in target_roles else [],
        projects_count=0,
        created_at=person.created_at or datetime.now(timezone.utc),
    )



async def update_participant(
    db: AsyncSession,
    event_id: int,
    person_id: int,
    payload: ParticipantUpdateRequest,
) -> ParticipantItemResponse:
    """Atualiza dados cadastrais e de logística de um participante."""
    stmt = select(EventParticipant).where(
        EventParticipant.event_id == event_id,
        EventParticipant.person_id == person_id,
        EventParticipant.deleted_at.is_(None),
    )
    res = await db.execute(stmt)
    participant = res.scalar_one_or_none()
    if not participant:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Participante não encontrado nesta edição do evento.",
        )

    person = await db.get(Person, person_id)
    if not person or person.deleted_at is not None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Pessoa não encontrada no sistema.",
        )

    # 1. Atualizar campos da Person
    if payload.name is not None:
        person.name = payload.name.strip()

    if payload.email is not None:
        new_email = payload.email.strip().lower()
        if new_email != person.email:
            # Verificar se já existe outra pessoa com esse e-mail
            check_email = await db.execute(
                select(Person).where(Person.email == new_email, Person.id != person_id)
            )
            if check_email.scalar_one_or_none():
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Já existe outra pessoa cadastrada com este e-mail.",
                )
            person.email = new_email

    if payload.cpf is not None:
        person.cpf = payload.cpf.strip() if payload.cpf else None

    if payload.affiliation is not None:
        person.affiliation = payload.affiliation.strip() if payload.affiliation else None

    # Determinar e sincronizar papéis
    target_roles = None
    if payload.roles is not None:
        target_roles = list(dict.fromkeys(payload.roles))
    elif payload.role is not None:
        target_roles = [payload.role]

    if target_roles is not None:
        if not target_roles:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="O participante deve possuir pelo menos um papel atribuído no evento.",
            )
        if UserRole.ADMIN in target_roles:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="O papel Administrador não pode ser atribuído a participantes. A gestão da equipe administrativa do evento deve ser realizada exclusivamente na tela de Equipe da Feira.",
            )
        person.role = target_roles[0]
        await _sync_participant_roles(db, person_id, event_id, target_roles)
        active_roles = target_roles
    else:
        roles_stmt = select(EventParticipantRole.role).where(
            EventParticipantRole.person_id == person_id,
            EventParticipantRole.event_id == event_id,
            EventParticipantRole.deleted_at.is_(None),
        )
        roles_res = await db.execute(roles_stmt)
        active_roles = [row[0] for row in roles_res.all()]
        if not active_roles:
            active_roles = [person.role]

    if payload.barcode is not None:
        person.barcode = payload.barcode.strip() if payload.barcode else None

    # 2. Atualizar campos do EventParticipant
    if payload.tshirt_size is not None:
        participant.tshirt_size = payload.tshirt_size

    now = datetime.now(timezone.utc)
    if payload.kit_delivered is not None:
        if payload.kit_delivered and not participant.kit_delivered:
            participant.kit_delivered = True
            participant.kit_delivered_at = now
        elif not payload.kit_delivered and participant.kit_delivered:
            participant.kit_delivered = False
            participant.kit_delivered_at = None

    if payload.presence_confirmed is not None:
        if payload.presence_confirmed and not participant.presence_confirmed:
            participant.presence_confirmed = True
            participant.presence_confirmed_at = now
        elif not payload.presence_confirmed and participant.presence_confirmed:
            participant.presence_confirmed = False
            participant.presence_confirmed_at = None

    if payload.evaluator_presence_confirmed is not None:
        if payload.evaluator_presence_confirmed and not participant.evaluator_presence_confirmed:
            participant.evaluator_presence_confirmed = True
            participant.evaluator_presence_confirmed_at = now
            if not participant.presence_confirmed:
                participant.presence_confirmed = True
                participant.presence_confirmed_at = now
        elif not payload.evaluator_presence_confirmed and participant.evaluator_presence_confirmed:
            participant.evaluator_presence_confirmed = False
            participant.evaluator_presence_confirmed_at = None

    # 3. Atualizar subáreas se for avaliador
    if UserRole.EVALUATOR in active_roles:
        if payload.subarea_ids is not None:
            del_stmt = select(PersonSubarea).where(
                PersonSubarea.person_id == person_id,
                PersonSubarea.event_id == event_id,
            )
            del_res = await db.execute(del_stmt)
            for ps in del_res.scalars().all():
                await db.delete(ps)

            for sid in set(payload.subarea_ids):
                db.add(
                    PersonSubarea(
                        person_id=person_id,
                        subarea_id=sid,
                        event_id=event_id,
                    )
                )
    else:
        # Se deixou de ser avaliador, limpar vinculação de subáreas
        del_stmt = select(PersonSubarea).where(
            PersonSubarea.person_id == person_id,
            PersonSubarea.event_id == event_id,
        )
        del_res = await db.execute(del_stmt)
        for ps in del_res.scalars().all():
            await db.delete(ps)

    # 4. Atualizar níveis de ensino se for avaliador
    if UserRole.EVALUATOR in active_roles:
        if payload.education_levels is not None:
            await _sync_evaluator_education_levels(db, person_id, event_id, payload.education_levels)
    else:
        # Se deixou de ser avaliador, limpar vinculação de níveis de ensino
        await _sync_evaluator_education_levels(db, person_id, event_id, [])

    await db.commit()

    # Contagem de projetos
    proj_count_stmt = (
        select(func.count(Project.id))
        .join(ProjectMember, Project.id == ProjectMember.project_id)
        .where(
            ProjectMember.person_id == person_id,
            Project.event_id == event_id,
            ProjectMember.deleted_at.is_(None),
            Project.deleted_at.is_(None),
        )
    )
    p_count_res = await db.execute(proj_count_stmt)
    projects_count = p_count_res.scalar() or 0

    curr_levels = []
    if UserRole.EVALUATOR in active_roles:
        el_stmt = select(PersonEducationLevel.education_level).where(
            PersonEducationLevel.person_id == person_id,
            PersonEducationLevel.event_id == event_id,
            PersonEducationLevel.deleted_at.is_(None),
        )
        el_res = await db.execute(el_stmt)
        curr_levels = [row[0] for row in el_res.all()]

    return ParticipantItemResponse(
        participant_id=participant.id,
        person_id=person.id,
        event_id=event_id,
        name=person.name,
        email=person.email,
        cpf=person.cpf,
        affiliation=person.affiliation,
        role=active_roles[0] if active_roles else person.role,
        roles=active_roles,
        barcode=person.barcode,
        tshirt_size=participant.tshirt_size,
        kit_delivered=participant.kit_delivered,
        kit_delivered_at=participant.kit_delivered_at,
        presence_confirmed=participant.presence_confirmed,
        presence_confirmed_at=participant.presence_confirmed_at,
        evaluator_presence_confirmed=participant.evaluator_presence_confirmed,
        evaluator_presence_confirmed_at=participant.evaluator_presence_confirmed_at,
        education_levels=curr_levels,
        projects_count=projects_count,
        created_at=person.created_at,
    )


async def delete_participant(
    db: AsyncSession,
    event_id: int,
    person_id: int,
) -> dict:
    """
    Remove/desvincula o participante do evento.
    Aplica verificação rigorosa de integridade referencial (Regra BR-16).
    """
    stmt = select(EventParticipant).where(
        EventParticipant.event_id == event_id,
        EventParticipant.person_id == person_id,
        EventParticipant.deleted_at.is_(None),
    )
    res = await db.execute(stmt)
    participant = res.scalar_one_or_none()
    if not participant:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Participante não encontrado nesta edição do evento.",
        )

    # 1. Checar se a pessoa faz parte de equipes de projetos no evento
    proj_stmt = (
        select(Project.title)
        .join(ProjectMember, Project.id == ProjectMember.project_id)
        .where(
            ProjectMember.person_id == person_id,
            Project.event_id == event_id,
            ProjectMember.deleted_at.is_(None),
            Project.deleted_at.is_(None),
        )
    )
    proj_res = await db.execute(proj_stmt)
    project_titles = proj_res.scalars().all()

    if project_titles:
        titles_str = ", ".join(f'"{t}"' for t in project_titles[:3])
        if len(project_titles) > 3:
            titles_str += f" e mais {len(project_titles) - 3} trabalho(s)"
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=(
                f"Não é possível desvincular o participante pois ele integra a equipe do(s) projeto(s): {titles_str}. "
                "Substitua ou remova o participante da equipe do projeto antes de desvinculá-lo do evento."
            ),
        )

    # 2. Soft-delete do EventParticipant
    participant.deleted_at = datetime.now(timezone.utc)

    # 3. Soft-delete das subáreas se houver
    sub_stmt = select(PersonSubarea).where(
        PersonSubarea.person_id == person_id,
        PersonSubarea.event_id == event_id,
        PersonSubarea.deleted_at.is_(None),
    )
    sub_res = await db.execute(sub_stmt)
    for ps in sub_res.scalars().all():
        ps.deleted_at = datetime.now(timezone.utc)

    # 4. Soft-delete de event_participant_roles
    epr_stmt = select(EventParticipantRole).where(
        EventParticipantRole.person_id == person_id,
        EventParticipantRole.event_id == event_id,
        EventParticipantRole.deleted_at.is_(None),
    )
    epr_res = await db.execute(epr_stmt)
    for epr in epr_res.scalars().all():
        epr.deleted_at = datetime.now(timezone.utc)

    # 5. Soft-delete de person_education_levels se houver
    el_stmt = select(PersonEducationLevel).where(
        PersonEducationLevel.person_id == person_id,
        PersonEducationLevel.event_id == event_id,
        PersonEducationLevel.deleted_at.is_(None),
    )
    el_res = await db.execute(el_stmt)
    for pel in el_res.scalars().all():
        pel.deleted_at = datetime.now(timezone.utc)

    await db.commit()

    return {"message": "Participante desvinculado do evento com sucesso."}


async def import_participants_batch(
    db: AsyncSession,
    event_id: int,
    payload: ParticipantBatchImport,
) -> ParticipantBatchResponse:
    """Importa e sincroniza em lote participantes vinculados à edição ativa do evento (Regra BR-26)."""
    # 1. Verificar se a edição do evento existe
    event = await db.get(Event, event_id)
    if not event or event.deleted_at is not None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Edição do evento não encontrada.",
        )

    # 2. Carregar mapa de subáreas ativas do evento para resolução composta (Área -> Subárea) ou simples
    stmt_subareas = (
        select(Subarea, KnowledgeArea.name.label("area_name"))
        .join(KnowledgeArea, Subarea.area_id == KnowledgeArea.id)
        .where(
            KnowledgeArea.event_id == event_id,
            Subarea.deleted_at.is_(None),
            KnowledgeArea.deleted_at.is_(None),
        )
    )
    res_sub = await db.execute(stmt_subareas)
    subareas_rows = res_sub.all()

    # Mapa composto: (norm(area_name), norm(subarea_name)) -> subarea_id
    composite_subarea_map: Dict[Tuple[str, str], int] = {}
    # Mapa simples com rastreamento de ocorrências: norm(subarea_name) -> list of (subarea_id, real_area_name)
    simple_subarea_map: Dict[str, List[Tuple[int, str]]] = {}

    for sub_obj, area_name in subareas_rows:
        area_norm = _normalize_name(area_name)
        sub_norm = _normalize_name(sub_obj.name)
        composite_subarea_map[(area_norm, sub_norm)] = sub_obj.id
        if sub_norm not in simple_subarea_map:
            simple_subarea_map[sub_norm] = []
        simple_subarea_map[sub_norm].append((sub_obj.id, area_name))

    # 2.1 Pré-carregamento em lote de pessoas e participantes (Eliminação N+1)
    all_emails = {
        item.email.strip().lower()
        for item in payload.items
        if item.email and item.email.strip()
    }
    all_cpfs = {
        item.cpf.strip()
        for item in payload.items
        if item.cpf and item.cpf.strip()
    }

    person_by_email: Dict[str, Person] = {}
    person_by_cpf: Dict[str, Person] = {}

    conditions = []
    if all_emails:
        conditions.append(Person.email.in_(list(all_emails)))
    if all_cpfs:
        conditions.append(Person.cpf.in_(list(all_cpfs)))

    if conditions:
        p_batch_stmt = select(Person).where(or_(*conditions))
        p_batch_res = await db.execute(p_batch_stmt)
        for p in p_batch_res.scalars().all():
            if p.email:
                person_by_email[p.email.lower()] = p
            if p.cpf:
                person_by_cpf[p.cpf] = p

    loaded_person_ids = {p.id for p in person_by_email.values()} | {p.id for p in person_by_cpf.values()}
    ep_by_person_id: Dict[int, EventParticipant] = {}
    if loaded_person_ids:
        ep_batch_stmt = select(EventParticipant).where(
            EventParticipant.event_id == event_id,
            EventParticipant.person_id.in_(list(loaded_person_ids))
        )
        ep_batch_res = await db.execute(ep_batch_stmt)
        for ep in ep_batch_res.scalars().all():
            ep_by_person_id[ep.person_id] = ep

    total_processed = len(payload.items)
    created_count = 0
    updated_count = 0
    roles_assigned_count = 0
    evaluators_count = 0
    result_items: List[ParticipantItemResponse] = []

    for item in payload.items:
        # Filtrar e normalizar papéis
        raw_roles = [r for r in item.roles if r != UserRole.ADMIN] if item.roles else [UserRole.STUDENT]
        target_roles = list(dict.fromkeys(raw_roles))
        if not target_roles:
            target_roles = [UserRole.STUDENT]
        primary_role = target_roles[0]

        clean_email = item.email.strip().lower()
        clean_cpf = item.cpf.strip() if item.cpf else None

        # 3. Localizar ou criar Person via mapa em memória
        person = None
        if clean_cpf and clean_cpf in person_by_cpf:
            person = person_by_cpf[clean_cpf]
        if not person and clean_email in person_by_email:
            person = person_by_email[clean_email]

        if person:
            person.name = item.name.strip()
            if clean_cpf:
                person.cpf = clean_cpf
                person_by_cpf[clean_cpf] = person
            if item.affiliation:
                person.affiliation = item.affiliation.strip()
            if item.barcode and not person.barcode:
                person.barcode = item.barcode.strip()
            person.role = primary_role
            if person.deleted_at is not None:
                person.deleted_at = None
        else:
            barcode = item.barcode.strip() if item.barcode else generate_barcode()
            person = Person(
                name=item.name.strip(),
                email=clean_email,
                cpf=clean_cpf,
                affiliation=item.affiliation.strip() if item.affiliation else None,
                role=primary_role,
                barcode=barcode,
            )
            db.add(person)
            await db.flush()
            person_by_email[clean_email] = person
            if clean_cpf:
                person_by_cpf[clean_cpf] = person

        # 4. Vincular a EventParticipant via mapa em memória
        participant = ep_by_person_id.get(person.id)

        if participant:
            if item.tshirt_size:
                participant.tshirt_size = item.tshirt_size.strip()
            if participant.deleted_at is not None:
                participant.deleted_at = None
            updated_count += 1
        else:
            participant = EventParticipant(
                event_id=event_id,
                person_id=person.id,
                tshirt_size=item.tshirt_size.strip() if item.tshirt_size else "M",
                kit_delivered=False,
                presence_confirmed=False,
            )
            db.add(participant)
            await db.flush()
            ep_by_person_id[person.id] = participant
            created_count += 1

        # 5. Sincronizar múltiplos papéis
        await _sync_participant_roles(db, person.id, event_id, target_roles)
        roles_assigned_count += len(target_roles)

        # 6. Para avaliadores, sincronizar subáreas e níveis de ensino
        is_evaluator = UserRole.EVALUATOR in target_roles
        applied_levels: List[EducationLevelEnum] = []
        if is_evaluator:
            evaluators_count += 1

            # Subáreas
            if item.subareas is not None:
                matched_subarea_ids = []
                for s_entry in item.subareas:
                    if not s_entry or not s_entry.strip():
                        continue
                    area_part, sub_part = _parse_subarea_entry(s_entry)
                    sub_norm = _normalize_name(sub_part)

                    if area_part:
                        area_norm = _normalize_name(area_part)
                        comp_key = (area_norm, sub_norm)
                        if comp_key in composite_subarea_map:
                            matched_subarea_ids.append(composite_subarea_map[comp_key])
                        else:
                            # Tenta busca parcial de área se o nome não for idêntico
                            matched_partial = False
                            for (a_n, s_n), sid in composite_subarea_map.items():
                                if (area_norm in a_n or a_n in area_norm) and (sub_norm == s_n):
                                    matched_subarea_ids.append(sid)
                                    matched_partial = True
                                    break
                            if not matched_partial:
                                pass  # Subárea não encontrada na área informada, ignora silenciosamente ou não vincula
                    else:
                        # Busca simples por nome de subárea
                        if sub_norm in simple_subarea_map:
                            candidates = simple_subarea_map[sub_norm]
                            if len(candidates) == 1:
                                matched_subarea_ids.append(candidates[0][0])
                            else:
                                areas_str = ", ".join(f"'{c[1]}'" for c in candidates)
                                raise HTTPException(
                                    status_code=status.HTTP_400_BAD_REQUEST,
                                    detail=(
                                        f"A subárea '{s_entry}' informada para o participante '{item.name}' é ambígua, "
                                        f"pois pertence a mais de uma grande área: {areas_str}. "
                                        f"Por favor, especifique no formato 'Área -> Subárea'."
                                    ),
                                )
                await _sync_evaluator_subareas(db, person.id, event_id, matched_subarea_ids)


            # Níveis de ensino
            if item.education_levels is not None:
                applied_levels = item.education_levels
                await _sync_evaluator_education_levels(db, person.id, event_id, item.education_levels)

        result_items.append(
            ParticipantItemResponse(
                participant_id=participant.id,
                person_id=person.id,
                event_id=event_id,
                name=person.name,
                email=person.email,
                cpf=person.cpf,
                affiliation=person.affiliation,
                role=primary_role,
                roles=target_roles,
                barcode=person.barcode,
                tshirt_size=participant.tshirt_size,
                kit_delivered=participant.kit_delivered,
                kit_delivered_at=participant.kit_delivered_at,
                presence_confirmed=participant.presence_confirmed,
                presence_confirmed_at=participant.presence_confirmed_at,
                evaluator_presence_confirmed=participant.evaluator_presence_confirmed,
                evaluator_presence_confirmed_at=participant.evaluator_presence_confirmed_at,
                education_levels=applied_levels if is_evaluator else [],
                projects_count=0,
                created_at=person.created_at or datetime.now(timezone.utc),
            )
        )

    await db.commit()

    return ParticipantBatchResponse(
        total_processed=total_processed,
        created_count=created_count,
        updated_count=updated_count,
        roles_assigned_count=roles_assigned_count,
        evaluators_count=evaluators_count,
        items=result_items,
    )


