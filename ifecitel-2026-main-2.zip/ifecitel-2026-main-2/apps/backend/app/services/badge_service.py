"""Service para geração de crachás em formato PDF com ReportLab e Code128 (Regra BR-07 e BR-09)."""

import io
import os
import textwrap
from typing import Any, Dict, List, Optional
from fastapi import HTTPException, status
from reportlab.graphics.barcode import code128
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from sqlalchemy import select, or_
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.core.config import settings
from app.models.enums import UserRole, EducationLevelEnum
from app.models.event import Event, EventAdministrator, EventAdminRole
from app.models.knowledge_area import KnowledgeArea, Subarea
from app.models.person import EventParticipant, EventParticipantRole, Person, PersonEducationLevel, PersonSubarea
from app.models.project import Project, ProjectMember, ProjectMemberRole


def _resolve_local_logo_path(logo_url: Optional[str]) -> Optional[str]:
    """Tenta localizar o arquivo de logotipo no disco local."""
    if not logo_url:
        return None

    # 1. Se for uma URL relativa do static uploads (/static/uploads/logos/...)
    if "/static/uploads/" in logo_url:
        rel = logo_url.split("/static/uploads/")[-1].lstrip("/")
        candidate = os.path.join(settings.UPLOAD_DIR, rel)
        if os.path.isfile(candidate):
            return candidate

    # 2. Se for um caminho absoluto existente no disco
    if os.path.isfile(logo_url):
        return logo_url

    # 3. Busca direta na pasta de logos
    basename = os.path.basename(logo_url)
    candidate_logo_dir = os.path.join(settings.UPLOAD_DIR, "logos", basename)
    if os.path.isfile(candidate_logo_dir):
        return candidate_logo_dir

    return None


def _build_event_data(event: Event) -> Dict[str, Any]:
    """Constrói metadados do evento para renderização de crachás com ImageReader em cache."""
    logo_path = _resolve_local_logo_path(event.logo_url)
    logo_ir = None
    orig_w, orig_h = 0, 0
    if logo_path and os.path.isfile(logo_path):
        try:
            from reportlab.lib.utils import ImageReader
            logo_ir = ImageReader(logo_path)
            orig_w, orig_h = logo_ir.getSize()
        except Exception:
            logo_ir = None

    return {
        "name": event.name,
        "year": event.year,
        "institution": event.organizing_institution,
        "location": event.location,
        "logo_path": logo_path,
        "logo_image_reader": logo_ir,
        "logo_dimensions": (orig_w, orig_h),
    }


def _format_education_level_label(level: Optional[str]) -> str:
    """Retorna o rótulo legível do nível de ensino."""
    mapping = {
        "JUNIOR": "Ensino Fundamental I",
        "FUNDAMENTAL": "Ensino Fundamental II",
        "MEDIO": "Ensino Médio / Técnico",
        "GRADUACAO": "Graduação / Superior",
        "POS_GRADUACAO": "Pós-Graduação",
    }
    return mapping.get(str(level), str(level or ""))


def _wrap_name_lines(c: canvas.Canvas, name_str: str, max_w: float) -> tuple:
    """Quebra o nome do participante em 1 ou 2 linhas (sempre UPPERCASE), retornando (linhas, font_size)."""
    raw_name = " ".join(name_str.strip().upper().split())
    if not raw_name:
        return [""], 16.0

    # 1. Se couber em 1 linha com tamanho destacado (16pt a 19pt)
    for fs in [19.0, 18.0, 17.0, 16.0]:
        if c.stringWidth(raw_name, "Helvetica-Bold", fs) <= max_w:
            return [raw_name], fs

    # 2. Se for longo, divide em 2 linhas equilibradas com tamanho generoso (13.5pt a 16.5pt)
    words = raw_name.split()
    if len(words) >= 2:
        for fs in [16.5, 15.5, 14.5, 13.5]:
            candidates = []
            for i in range(1, len(words)):
                l1 = " ".join(words[:i])
                l2 = " ".join(words[i:])
                w1 = c.stringWidth(l1, "Helvetica-Bold", fs)
                w2 = c.stringWidth(l2, "Helvetica-Bold", fs)
                if w1 <= max_w and w2 <= max_w:
                    penalty = 0
                    # Evita deixar preposição isolada no fim da linha 1
                    if words[i - 1].upper() in ("DE", "DA", "DO", "DOS", "DAS", "E"):
                        penalty += 15
                    score = abs(w1 - w2) + penalty
                    candidates.append((score, l1, l2))
            if candidates:
                candidates.sort(key=lambda item: item[0])
                return [candidates[0][1], candidates[0][2]], fs

    # 3. Fallback se não couber em 2 linhas com as fontes acima
    for fs in [14.0, 13.0, 12.0, 11.0]:
        if c.stringWidth(raw_name, "Helvetica-Bold", fs) <= max_w:
            return [raw_name], fs

    return [raw_name[:24], raw_name[24:]], 12.0


def _draw_badge_card(
    c: canvas.Canvas,
    x: float,
    y: float,
    w: float,
    h: float,
    event_data: Dict[str, Any],
    badge_data: Dict[str, Any],
) -> None:
    """Desenha um crachá individual em coordenadas específicas da folha A4."""
    # 1. Moldura externa com cantos arredondados
    c.setStrokeColor(colors.HexColor("#94A3B8"))
    c.setLineWidth(1)
    c.roundRect(x, y, w, h, 8, stroke=1, fill=0)

    # 2. Cabeçalho do Evento (Logotipo 100% largura OU Nome + Local de Realização)
    logo_path = event_data.get("logo_path")
    logo_ir = event_data.get("logo_image_reader")
    has_logo = bool(logo_ir or (logo_path and os.path.isfile(logo_path)))

    if has_logo:
        # Quando há logotipo cadastrado:
        # NÃO inserir nome do evento nem local de realização.
        # O logotipo ocupa toda a parte superior do crachá (100% da largura do crachá).
        orig_w, orig_h = event_data.get("logo_dimensions", (0, 0))
        if orig_w <= 0 or orig_h <= 0:
            try:
                from reportlab.lib.utils import ImageReader
                if not logo_ir and logo_path:
                    logo_ir = ImageReader(logo_path)
                if logo_ir:
                    orig_w, orig_h = logo_ir.getSize()
            except Exception:
                pass

        aspect = (orig_w / orig_h) if (orig_w > 0 and orig_h > 0) else 2.8
        calc_h = w / aspect
        banner_h = max(55.0, min(calc_h, 88.0))

        c.saveState()
        # Clip nos cantos superiores arredondados do crachá (raio 8)
        clip_p = c.beginPath()
        clip_p.roundRect(x, y, w, h, 8)
        c.clipPath(clip_p, stroke=0, fill=0)

        c.setFillColor(colors.HexColor("#FFFFFF"))
        c.rect(x, y + h - banner_h, w, banner_h, fill=1, stroke=0)
        c.drawImage(
            logo_ir if logo_ir is not None else logo_path,
            x,
            y + h - banner_h,
            width=w,
            height=banner_h,
            preserveAspectRatio=True,
            anchor="c",
            mask="auto",
        )
        c.restoreState()

        # Linha divisória sutil abaixo do banner
        c.setStrokeColor(colors.HexColor("#CBD5E1"))
        c.setLineWidth(0.8)
        c.line(x, y + h - banner_h, x + w, y + h - banner_h)

        header_bottom_y = y + h - banner_h
    else:
        # Quando NÃO há logotipo cadastrado:
        # Exibir o Nome do Evento e o Local de Realização
        banner_h = 62.0
        header_bottom_y = y + h - banner_h

        event_name = (event_data.get("name") or "EasyEvent").strip().upper()
        event_loc = (event_data.get("location") or event_data.get("institution") or "").strip()

        # Nome do Evento
        c.setFillColor(colors.HexColor("#0F172A"))
        ev_fs = 13.5
        while ev_fs > 9.5 and c.stringWidth(event_name, "Helvetica-Bold", ev_fs) > (w - 24):
            ev_fs -= 1.0
        c.setFont("Helvetica-Bold", ev_fs)
        c.drawCentredString(x + w / 2, y + h - 35, event_name)

        # Local de Realização
        if event_loc:
            c.setFillColor(colors.HexColor("#475569"))
            loc_fs = 9.0
            while loc_fs > 7.0 and c.stringWidth(event_loc, "Helvetica", loc_fs) > (w - 24):
                loc_fs -= 0.5
            c.setFont("Helvetica", loc_fs)
            c.drawCentredString(x + w / 2, y + h - 50, event_loc)

        # Divisória do cabeçalho
        c.setStrokeColor(colors.HexColor("#CBD5E1"))
        c.setLineWidth(0.8)
        c.line(x + 10, header_bottom_y, x + w - 10, header_bottom_y)

    # Marcação de furo para presilha/cordão (topo centro)
    c.setStrokeColor(colors.HexColor("#475569"))
    c.setLineWidth(0.8)
    c.setDash(2, 2)
    c.circle(x + w / 2, y + h - 13, 4.5, stroke=1, fill=0)
    c.setDash()

    # Redesenha a borda externa para acabamento perfeito
    c.setStrokeColor(colors.HexColor("#94A3B8"))
    c.setLineWidth(1)
    c.roundRect(x, y, w, h, 8, stroke=1, fill=0)

    # 3. Tarja do Papel Principal (altura ampliada para 28pt; fonte 13pt bold)
    role_color_map = {
        "ESTUDANTE": ("#1E40AF", "#DBEAFE"),       # Azul
        "ORIENTADOR": ("#065F46", "#D1FAE5"),      # Verde
        "COORIENTADOR": ("#0E7490", "#CFFAFE"),    # Ciano
        "AVALIADOR": ("#581C87", "#F3E8FF"),       # Roxo
        "COORDENAÇÃO GERAL": ("#9A3412", "#FFEDD5"), # Laranja/Terracota
        "COMISSÃO ORGANIZADORA": ("#9A3412", "#FFEDD5"),
        "APOIO & CREDENCIAMENTO": ("#9A3412", "#FFEDD5"),
    }
    role_label = badge_data.get("role_label", "PARTICIPANTE").upper()
    fg_col, bg_col = role_color_map.get(role_label, ("#1E293B", "#F1F5F9"))

    pill_h = 28
    pill_y = header_bottom_y - 10 - pill_h
    c.setFillColor(colors.HexColor(bg_col))
    c.roundRect(x + 12, pill_y, w - 24, pill_h, 5, stroke=0, fill=1)
    c.setFillColor(colors.HexColor(fg_col))
    role_font_size = 11.5 if len(role_label) > 18 else 13
    c.setFont("Helvetica-Bold", role_font_size)
    c.drawCentredString(x + w / 2, pill_y + 8.5, role_label)

    # 5. Nome do Participante (sempre em UPPERCASE, com quebra dinâmica de linha se necessário)
    max_name_w = w - 28
    raw_name = (badge_data.get("name") or "").strip()
    name_lines, name_font_size = _wrap_name_lines(c, raw_name, max_name_w)

    raw_affiliation = (badge_data.get("affiliation") or "").strip()
    affiliation = raw_affiliation or (event_data.get("institution") or "").strip()

    c.setFillColor(colors.HexColor("#0F172A"))
    c.setFont("Helvetica-Bold", name_font_size)

    line_spacing = name_font_size + 2.5
    if len(name_lines) == 1:
        first_line_y = pill_y - 23
        c.drawCentredString(x + w / 2, first_line_y, name_lines[0])
        extra_name_height = 0.0
    else:
        first_line_y = pill_y - 20
        c.drawCentredString(x + w / 2, first_line_y, name_lines[0])
        c.drawCentredString(x + w / 2, first_line_y - line_spacing, name_lines[1])
        extra_name_height = line_spacing

    # 6. Afiliação / Instituição de Ensino
    aff_y = first_line_y - (line_spacing if len(name_lines) > 1 else 0) - 17
    if affiliation:
        c.setFillColor(colors.HexColor("#475569"))
        c.setFont("Helvetica-Bold", 10.0)
        if len(affiliation) > 36:
            affiliation = affiliation[:34] + "..."
        c.drawCentredString(x + w / 2, aff_y, affiliation)

    # 7. Bloco de Contexto Específico (Trabalho / Avaliador / Organização)
    # Reduz a altura do box proporcionalmente caso o nome ocupe mais de uma linha
    box_y = y + 72
    base_box_top = pill_y - 54 if affiliation else pill_y - 42
    box_top = base_box_top - extra_name_height
    box_h = box_top - box_y

    c.setFillColor(colors.HexColor("#F8FAFC"))
    c.setStrokeColor(colors.HexColor("#CBD5E1"))
    c.roundRect(x + 12, box_y, w - 24, box_h, 6, stroke=1, fill=1)

    project_title = badge_data.get("project_title")
    booth_number = badge_data.get("booth_number")
    subarea_name = badge_data.get("subarea_name")
    education_levels_str = badge_data.get("education_levels_str")
    staff_role_desc = badge_data.get("staff_role_desc")

    if project_title:
        # Participante vinculado a projeto
        cur_y = box_y + box_h - 17
        if booth_number:
            c.setFillColor(colors.HexColor("#0F172A"))
            c.setFont("Helvetica-Bold", 13)
            c.drawString(x + 18, cur_y, f"ESTANDE: {booth_number}")
            cur_y -= 16

        if subarea_name:
            c.setFillColor(colors.HexColor("#0D9488"))
            c.setFont("Helvetica-Bold", 10)
            sub_display = subarea_name if len(subarea_name) <= 35 else subarea_name[:33] + "..."
            c.drawString(x + 18, cur_y, sub_display)
            cur_y -= 15

        # Linha sutil separadora antes do título
        c.setStrokeColor(colors.HexColor("#E2E8F0"))
        c.setLineWidth(0.6)
        c.line(x + 18, cur_y + 2, x + w - 18, cur_y + 2)
        cur_y -= 11

        c.setFillColor(colors.HexColor("#1E293B"))
        c.setFont("Helvetica", 9.5)
        max_title_lines = 3 if extra_name_height > 0 else 4
        lines = textwrap.wrap(project_title.strip(), width=36)
        for line in lines[:max_title_lines]:
            c.drawString(x + 18, cur_y, line)
            cur_y -= 13

    elif role_label == "AVALIADOR":
        # Avaliador Científico
        cur_y = box_y + box_h - 17
        c.setFillColor(colors.HexColor("#581C87"))
        c.setFont("Helvetica-Bold", 10.5)
        c.drawString(x + 18, cur_y, "Áreas e Subáreas de Avaliação:")
        cur_y -= 16

        # Linha sutil separadora
        c.setStrokeColor(colors.HexColor("#E2E8F0"))
        c.setLineWidth(0.6)
        c.line(x + 18, cur_y + 3, x + w - 18, cur_y + 3)
        cur_y -= 10

        c.setFillColor(colors.HexColor("#334155"))
        c.setFont("Helvetica", 9)
        if subarea_name:
            subs = [s.strip() for s in subarea_name.split(",")]
            max_subs = 2 if extra_name_height > 0 else 3
            for s in subs[:max_subs]:
                c.drawString(x + 22, cur_y, f"• {s[:33]}")
                cur_y -= 13
            if len(subs) > max_subs:
                c.drawString(x + 22, cur_y, f"• + {len(subs) - max_subs} outra(s) subárea(s)")
                cur_y -= 13
        else:
            c.drawString(x + 22, cur_y, "• Todas as áreas temáticas (Geral)")
            cur_y -= 13

        if education_levels_str:
            cur_y -= 3
            c.setFillColor(colors.HexColor("#64748B"))
            c.setFont("Helvetica-Bold", 9)
            c.drawString(x + 18, cur_y, f"Níveis: {education_levels_str}")

    else:
        # Equipe Organizadora ou Geral
        cur_y = box_y + box_h - 22
        c.setFillColor(colors.HexColor("#9A3412"))
        c.setFont("Helvetica-Bold", 13.5)
        c.drawString(x + 18, cur_y, staff_role_desc or "Equipe de Gestão e Operação")
        cur_y -= 18

        c.setStrokeColor(colors.HexColor("#E2E8F0"))
        c.setLineWidth(0.6)
        c.line(x + 18, cur_y + 3, x + w - 18, cur_y + 3)
        cur_y -= 12

        c.setFillColor(colors.HexColor("#475569"))
        c.setFont("Helvetica", 10)
        c.drawString(x + 18, cur_y, "Acesso aos pavilhões e salas técnicas")
        cur_y -= 16
        c.drawString(x + 18, cur_y, f"Edição Oficial • {event_data.get('year', '2026')}")

    # 8. Rodapé: Código de Barras Code128 Vetorial (altura ampliada para 36pt, legenda 10.5pt)
    barcode_val = badge_data.get("barcode", "BC-00000")
    try:
        bc = code128.Code128(barcode_val, barWidth=1.1, barHeight=36)
        bc_x = x + (w - bc.width) / 2
        bc.drawOn(c, bc_x, y + 26)
    except Exception:
        pass

    c.setFillColor(colors.HexColor("#334155"))
    c.setFont("Courier-Bold", 10.5)
    c.drawCentredString(x + w / 2, y + 11, barcode_val)


async def generate_participant_badge_pdf(
    db: AsyncSession,
    event_id: int,
    participant_id: int,
) -> bytes:
    """Gera um PDF contendo o crachá avulso de um participante específico."""
    # 1. Obter Evento
    event = await db.get(Event, event_id)
    if not event or event.deleted_at is not None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Edição do evento não encontrada.",
        )

    # 2. Obter Participante (suporta tanto EventParticipant.id quanto Person.id)
    stmt_part = (
        select(EventParticipant)
        .options(selectinload(EventParticipant.person))
        .where(
            or_(
                EventParticipant.id == participant_id,
                EventParticipant.person_id == participant_id,
            ),
            EventParticipant.event_id == event_id,
            EventParticipant.deleted_at.is_(None),
        )
    )
    res_part = await db.execute(stmt_part)
    participant = res_part.scalar_one_or_none()

    if participant and participant.person:
        person = participant.person
    else:
        # Se não houver registro em EventParticipant, tenta buscar diretamente em Person
        res_person = await db.execute(
            select(Person).where(Person.id == participant_id, Person.deleted_at.is_(None))
        )
        person = res_person.scalar_one_or_none()
        if not person:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Participante não encontrado no evento.",
            )

    # 3. Identificar Papéis
    roles_stmt = select(EventParticipantRole.role).where(
        EventParticipantRole.person_id == person.id,
        EventParticipantRole.event_id == event_id,
        EventParticipantRole.deleted_at.is_(None),
    )
    roles_res = await db.execute(roles_stmt)
    roles = roles_res.scalars().all() or [person.role]

    # Verificar se faz parte da equipe organizadora (EventAdministrator)
    admin_stmt = select(EventAdministrator.role).where(
        EventAdministrator.person_id == person.id,
        EventAdministrator.event_id == event_id,
        EventAdministrator.deleted_at.is_(None),
    )
    admin_res = await db.execute(admin_stmt)
    admin_role = admin_res.scalar_one_or_none()

    staff_desc = None
    if admin_role == EventAdminRole.COORDINATOR:
        primary_role = "COORDENADOR GERAL"
        staff_desc = "Coordenador Geral da Feira"
    elif admin_role == EventAdminRole.ORGANIZER:
        primary_role = "COMISSÃO ORGANIZADORA"
        staff_desc = "Comissão Organizadora da Feira"
    elif admin_role == EventAdminRole.OPERATOR:
        primary_role = "EQUIPE DE APOIO"
        staff_desc = "Equipe de Apoio e Credenciamento"
    elif UserRole.ADVISOR in roles:
        primary_role = "ORIENTADOR"
    elif UserRole.COADVISOR in roles:
        primary_role = "COORIENTADOR"
    elif UserRole.EVALUATOR in roles:
        primary_role = "AVALIADOR"
    elif UserRole.ADMIN in roles:
        primary_role = "COMISSÃO ORGANIZADORA"
        staff_desc = "Comissão Organizadora da Feira"
    else:
        primary_role = "ESTUDANTE"

    # 4. Dados de projeto se houver
    proj_stmt = (
        select(Project)
        .join(ProjectMember, Project.id == ProjectMember.project_id)
        .options(
            selectinload(Project.subarea).selectinload(Subarea.knowledge_area),
        )
        .where(
            ProjectMember.person_id == person.id,
            Project.event_id == event_id,
            ProjectMember.deleted_at.is_(None),
            Project.deleted_at.is_(None),
        )
    )
    proj_res = await db.execute(proj_stmt)
    project = proj_res.scalars().first()

    # 5. Dados de avaliador se houver
    subareas_str = ""
    levels_str = ""
    if UserRole.EVALUATOR in roles:
        sub_stmt = (
            select(Subarea, KnowledgeArea.name.label("area_name"))
            .join(PersonSubarea, Subarea.id == PersonSubarea.subarea_id)
            .join(KnowledgeArea, Subarea.area_id == KnowledgeArea.id)
            .where(
                PersonSubarea.person_id == person.id,
                PersonSubarea.event_id == event_id,
                PersonSubarea.deleted_at.is_(None),
            )
        )
        sub_res = await db.execute(sub_stmt)
        subs = [f"{row[1]} > {row[0].name}" for row in sub_res.all()]
        subareas_str = ", ".join(subs)

        lvl_stmt = select(PersonEducationLevel.education_level).where(
            PersonEducationLevel.person_id == person.id,
            PersonEducationLevel.event_id == event_id,
            PersonEducationLevel.deleted_at.is_(None),
        )
        lvl_res = await db.execute(lvl_stmt)
        lvls = [_format_education_level_label(l) for l in lvl_res.scalars().all()]
        levels_str = ", ".join(lvls) if lvls else "Todos os Níveis"

    # Montar PDF
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)

    event_data = _build_event_data(event)

    badge_data = {
        "name": person.name,
        "affiliation": person.affiliation,
        "role_label": primary_role,
        "barcode": person.barcode or f"BC-{person.id:05d}",
        "project_title": project.title if project else None,
        "booth_number": project.booth_number if project else None,
        "subarea_name": f"{project.subarea.area_name} > {project.subarea.name}" if project and project.subarea else subareas_str,
        "education_levels_str": levels_str,
        "staff_role_desc": staff_desc,
    }

    # Posiciona no primeiro quadrante (Top-Left) da folha A4 com guias de corte (como se existissem os 4 crachás)
    page_w, page_h = A4
    badge_w = 260
    badge_h = 375
    margin_x = (page_w - (badge_w * 2)) / 3
    margin_y = (page_h - (badge_h * 2)) / 3

    # Quadrante 1 (Top-Left): mesmo slot 0 da grade 2x2
    x = margin_x
    y = margin_y + badge_h + margin_y

    _draw_badge_card(c, x, y, badge_w, badge_h, event_data, badge_data)

    # Linhas de corte pontilhadas da folha A4
    c.setStrokeColor(colors.HexColor("#CBD5E1"))
    c.setLineWidth(0.5)
    c.setDash(3, 4)
    # Linha vertical central de corte
    c.line(page_w / 2, 0, page_w / 2, page_h)
    # Linha horizontal central de corte
    c.line(0, page_h / 2, page_w, page_h / 2)
    c.setDash()

    c.showPage()
    c.save()
    return buf.getvalue()


async def generate_event_badges_batch_pdf(
    db: AsyncSession,
    event_id: int,
    filter_type: str = "all",
) -> bytes:
    """Gera o PDF consolidado de crachás em lote agrupados por equipes de trabalho, organizadores e avaliadores."""
    # 1. Obter Evento
    event = await db.get(Event, event_id)
    if not event or event.deleted_at is not None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Edição do evento não encontrada.",
        )

    event_data = _build_event_data(event)

    badges_queue: List[Dict[str, Any]] = []

    # =========================================================================
    # SEÇÃO 1: Trabalhos Científicos e Equipes (Orientador -> Coorientador -> Estudantes)
    # =========================================================================
    if filter_type in ("all", "projects"):
        proj_stmt = (
            select(Project)
            .options(
                selectinload(Project.members).selectinload(ProjectMember.person),
                selectinload(Project.subarea).selectinload(Subarea.knowledge_area),
            )
            .where(
                Project.event_id == event_id,
                Project.deleted_at.is_(None),
            )
            .order_by(Project.booth_number.nullslast(), Project.title)
        )
        proj_res = await db.execute(proj_stmt)
        projects = proj_res.scalars().all()

        for p in projects:
            subarea_label = f"{p.subarea.area_name} > {p.subarea.name}" if p.subarea else ""
            # Ordenar membros: ADVISOR primeiro, depois COADVISOR, depois STUDENT
            def _member_sort_key(m: ProjectMember):
                if m.role == ProjectMemberRole.ADVISOR:
                    return 0
                if m.role == ProjectMemberRole.COADVISOR:
                    return 1
                return 2

            sorted_members = sorted(p.members, key=_member_sort_key)
            for m in sorted_members:
                if not m.person or m.deleted_at is not None:
                    continue

                if m.role == ProjectMemberRole.ADVISOR:
                    r_label = "ORIENTADOR"
                elif m.role == ProjectMemberRole.COADVISOR:
                    r_label = "COORIENTADOR"
                else:
                    r_label = "ESTUDANTE"

                badges_queue.append({
                    "name": m.person.name,
                    "affiliation": m.person.affiliation,
                    "role_label": r_label,
                    "barcode": m.person.barcode or f"BC-{m.person.id:05d}",
                    "project_title": p.title,
                    "booth_number": p.booth_number,
                    "subarea_name": subarea_label,
                })

    # =========================================================================
    # SEÇÃO 2: Equipe Organizadora e Apoio
    # =========================================================================
    if filter_type in ("all", "staff"):
        admin_stmt = (
            select(EventAdministrator, Person)
            .join(Person, EventAdministrator.person_id == Person.id)
            .where(
                EventAdministrator.event_id == event_id,
                EventAdministrator.deleted_at.is_(None),
                Person.deleted_at.is_(None),
            )
            .order_by(EventAdministrator.role, Person.name)
        )
        admin_res = await db.execute(admin_stmt)
        for ea, person in admin_res.all():
            if ea.role == EventAdminRole.COORDINATOR:
                role_label = "COORDENAÇÃO GERAL"
                role_desc = "Coordenador Geral / Dono do Evento"
            elif ea.role == EventAdminRole.ORGANIZER:
                role_label = "COMISSÃO ORGANIZADORA"
                role_desc = "Comissão Organizadora / Co-Administrador"
            else:
                role_label = "APOIO & CREDENCIAMENTO"
                role_desc = "Equipe de Apoio e Credenciamento"

            badges_queue.append({
                "name": person.name,
                "affiliation": person.affiliation or event.organizing_institution,
                "role_label": role_label,
                "barcode": person.barcode or f"BC-{person.id:05d}",
                "staff_role_desc": role_desc,
            })

    # =========================================================================
    # SEÇÃO 3: Comissão Avaliadora
    # =========================================================================
    if filter_type in ("all", "evaluators"):
        eval_stmt = (
            select(Person)
            .join(EventParticipantRole, Person.id == EventParticipantRole.person_id)
            .where(
                EventParticipantRole.event_id == event_id,
                EventParticipantRole.role == UserRole.EVALUATOR,
                EventParticipantRole.deleted_at.is_(None),
                Person.deleted_at.is_(None),
            )
            .distinct()
            .order_by(Person.name)
        )
        eval_res = await db.execute(eval_stmt)
        evaluators = eval_res.scalars().all()

        for ev in evaluators:
            # Subáreas vinculadas
            sub_stmt = (
                select(Subarea, KnowledgeArea.name.label("area_name"))
                .join(PersonSubarea, Subarea.id == PersonSubarea.subarea_id)
                .join(KnowledgeArea, Subarea.area_id == KnowledgeArea.id)
                .where(
                    PersonSubarea.person_id == ev.id,
                    PersonSubarea.event_id == event_id,
                    PersonSubarea.deleted_at.is_(None),
                )
            )
            sub_res = await db.execute(sub_stmt)
            subs = [f"{row[1]} > {row[0].name}" for row in sub_res.all()]
            sub_str = ", ".join(subs)

            # Níveis vinculados
            lvl_stmt = select(PersonEducationLevel.education_level).where(
                PersonEducationLevel.person_id == ev.id,
                PersonEducationLevel.event_id == event_id,
                PersonEducationLevel.deleted_at.is_(None),
            )
            lvl_res = await db.execute(lvl_stmt)
            lvls = [_format_education_level_label(l) for l in lvl_res.scalars().all()]
            lvl_str = ", ".join(lvls) if lvls else "Todos os Níveis"

            badges_queue.append({
                "name": ev.name,
                "affiliation": ev.affiliation or "Comissão Avaliadora",
                "role_label": "AVALIADOR",
                "barcode": ev.barcode or f"BC-{ev.id:05d}",
                "subarea_name": sub_str,
                "education_levels_str": lvl_str,
            })

    if not badges_queue:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Nenhum crachá encontrado para os filtros selecionados.",
        )

    # =========================================================================
    # Montagem do PDF A4 (4 crachás por folha, grid 2x2 com linhas de corte)
    # =========================================================================
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)

    page_w, page_h = A4
    badge_w = 260
    badge_h = 375
    margin_x = (page_w - (badge_w * 2)) / 3
    margin_y = (page_h - (badge_h * 2)) / 3

    # Grade 2x2:
    # Coluna 0: x = margin_x
    # Coluna 1: x = margin_x + badge_w + margin_x
    # Linha 1 (topo): y = margin_y + badge_h + margin_y
    # Linha 0 (baixo): y = margin_y
    positions = [
        (margin_x, margin_y + badge_h + margin_y),                     # Top-Left (0)
        (margin_x + badge_w + margin_x, margin_y + badge_h + margin_y), # Top-Right (1)
        (margin_x, margin_y),                                          # Bottom-Left (2)
        (margin_x + badge_w + margin_x, margin_y),                     # Bottom-Right (3)
    ]

    for idx, badge_info in enumerate(badges_queue):
        slot = idx % 4
        x, y = positions[slot]

        # Desenhar crachá
        _draw_badge_card(c, x, y, badge_w, badge_h, event_data, badge_info)

        # Se for o último slot da folha ou o último crachá da fila:
        if slot == 3 or idx == len(badges_queue) - 1:
            # Linhas de corte pontilhadas entre colunas e linhas
            c.setStrokeColor(colors.HexColor("#CBD5E1"))
            c.setLineWidth(0.5)
            c.setDash(3, 4)
            # Linha vertical central de corte
            c.line(page_w / 2, 0, page_w / 2, page_h)
            # Linha horizontal central de corte
            c.line(0, page_h / 2, page_w, page_h / 2)
            c.setDash()

            c.showPage()

    c.save()
    return buf.getvalue()
