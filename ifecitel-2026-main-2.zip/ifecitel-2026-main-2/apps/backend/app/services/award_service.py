"""Awards and criteria association service (Regra BR-17)."""

from typing import List
from fastapi import HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.models.award import Award, AwardCriterion
from app.schemas.award import (
    AwardCreate,
    AwardCriterionLinkInput,
    AwardStandingItemResponse,
    AwardStandingsResponse,
    AwardUpdate
)
from app.services.event_service import get_event_by_id, verify_event_temporal_lock



async def create_award(
    db: AsyncSession,
    event_id: int,
    payload: AwardCreate
) -> Award:
    """Cadastra uma premiação especial e opcionalmente associa perguntas da avaliação (BR-17)."""
    event = await get_event_by_id(db, event_id)
    verify_event_temporal_lock(event)

    award = Award(
        event_id=event_id,
        name=payload.name.strip(),
        description=payload.description,
        sponsor=payload.sponsor
    )
    db.add(award)
    await db.flush()

    if payload.criteria_links:
        for link in payload.criteria_links:
            crit_link = AwardCriterion(
                award_id=award.id,
                criterion_id=link.criterion_id,
                weight=link.weight
            )
            db.add(crit_link)

    await db.commit()
    await db.refresh(award)
    return award


async def list_awards(db: AsyncSession, event_id: int) -> List[Award]:
    """Lista todas as premiações cadastradas em uma edição do evento com seus critérios associados."""
    stmt = (
        select(Award)
        .where(Award.event_id == event_id, Award.deleted_at.is_(None))
        .options(selectinload(Award.criteria_links))
        .order_by(Award.name.asc())
    )
    res = await db.execute(stmt)
    return list(res.scalars().all())


async def link_criteria_to_award(
    db: AsyncSession,
    award_id: int,
    criteria_links: List[AwardCriterionLinkInput]
) -> Award:
    """Vincula perguntas/itens da ficha de avaliação a uma premiação para apuração automática (BR-17)."""
    stmt = (
        select(Award)
        .where(Award.id == award_id, Award.deleted_at.is_(None))
        .options(selectinload(Award.criteria_links))
    )
    res = await db.execute(stmt)
    award = res.scalar_one_or_none()
    if not award:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Premiação não encontrada.")

    # Remover vínculos anteriores ativos
    for existing in award.criteria_links:
        existing.soft_delete()

    # Adicionar novos vínculos
    for link in criteria_links:
        new_link = AwardCriterion(
            award_id=award.id,
            criterion_id=link.criterion_id,
            weight=link.weight
        )
        db.add(new_link)

    await db.commit()
    await db.refresh(award)
    return award


async def update_award(
    db: AsyncSession,
    award_id: int,
    payload: AwardUpdate
) -> Award:
    """Atualiza os dados cadastrais e os critérios associados a uma premiação."""
    stmt = (
        select(Award)
        .where(Award.id == award_id, Award.deleted_at.is_(None))
        .options(selectinload(Award.criteria_links))
    )
    res = await db.execute(stmt)
    award = res.scalar_one_or_none()
    if not award:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Premiação não encontrada.")

    event = await get_event_by_id(db, award.event_id)
    verify_event_temporal_lock(event)

    if payload.name is not None:
        award.name = payload.name.strip()
    if payload.description is not None:
        award.description = payload.description
    if payload.sponsor is not None:
        award.sponsor = payload.sponsor

    if payload.criteria_links is not None:
        for existing in award.criteria_links:
            existing.soft_delete()
        for link in payload.criteria_links:
            new_link = AwardCriterion(
                award_id=award.id,
                criterion_id=link.criterion_id,
                weight=link.weight
            )
            db.add(new_link)

    await db.commit()
    await db.refresh(award)
    return award


async def delete_award(db: AsyncSession, award_id: int) -> None:
    """Aplica soft-delete na premiação."""
    stmt = select(Award).where(Award.id == award_id, Award.deleted_at.is_(None))
    res = await db.execute(stmt)
    award = res.scalar_one_or_none()
    if not award:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Premiação não encontrada.")

    award.soft_delete()
    await db.commit()


async def get_award_standings(
    db: AsyncSession,
    award_id: int
) -> AwardStandingsResponse:
    """
    Apuração oficial do Ranking 2: Premiações Específicas / Temáticas (Regra BR-17).
    Calcula a classificação dos projetos concorrentes considerando exclusivamente
    as notas dos critérios (itens) indicados no cadastro do prêmio e seus pesos.
    """
    from app.models.enums import EvaluationStatus
    from app.models.evaluation import Evaluation, EvaluationItem
    from app.models.project import Project
    from app.schemas.award import AwardStandingItemResponse, AwardStandingsResponse

    # 1. Carregar premiação com critérios vinculados
    stmt_award = (
        select(Award)
        .options(
            selectinload(Award.criteria_links).selectinload(AwardCriterion.criterion)
        )
        .where(Award.id == award_id, Award.deleted_at.is_(None))
    )
    res_award = await db.execute(stmt_award)
    award = res_award.scalar_one_or_none()
    if not award:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Premiação não encontrada.")

    active_links = [l for l in award.criteria_links if l.deleted_at is None]
    if not active_links:
        return AwardStandingsResponse(
            award_id=award.id,
            award_name=award.name,
            sponsor=award.sponsor,
            criteria_considered=[],
            total_competing_projects=0,
            standings=[]
        )

    criteria_dict = {
        l.criterion_id: (l.criterion.name, float(l.weight))
        for l in active_links
        if l.criterion
    }
    criteria_considered = [l.criterion.name for l in active_links if l.criterion]

    # 2. Carregar projetos do evento com subárea e avaliações concluídas
    stmt_projects = (
        select(Project)
        .options(
            selectinload(Project.subarea),
            selectinload(Project.evaluations).selectinload(Evaluation.items).selectinload(EvaluationItem.criterion)
        )
        .where(Project.event_id == award.event_id, Project.deleted_at.is_(None))
    )
    res_projects = await db.execute(stmt_projects)
    projects = res_projects.scalars().all()

    candidates = []
    for proj in projects:
        comp_evals = [
            ev for ev in proj.evaluations
            if ev.status == EvaluationStatus.COMPLETED and ev.deleted_at is None
        ]
        if not comp_evals:
            continue

        eval_scores = []
        for ev in comp_evals:
            matching_items = [it for it in ev.items if it.criterion_id in criteria_dict]
            if not matching_items:
                continue

            total_weight = sum(criteria_dict[it.criterion_id][1] for it in matching_items)
            if total_weight > 0:
                weighted_sum = sum(float(it.score) * criteria_dict[it.criterion_id][1] for it in matching_items)
                eval_scores.append(round(weighted_sum / total_weight, 2))
            else:
                eval_scores.append(round(sum(float(it.score) for it in matching_items) / len(matching_items), 2))

        if eval_scores:
            project_award_score = round(sum(eval_scores) / len(eval_scores), 2)
            candidates.append({
                "project_id": proj.id,
                "title": proj.title,
                "booth_number": proj.booth_number or "",
                "subarea_name": proj.subarea.name if proj.subarea else "Geral",
                "education_level": proj.education_level.value if hasattr(proj, "education_level") and proj.education_level else "MEDIO",
                "evaluations_count": len(eval_scores),
                "award_score": project_award_score
            })

    # 3. Ordenar: maior nota primeiro, desempate por contagem de avaliações e ID
    candidates.sort(key=lambda c: (-c["award_score"], -c["evaluations_count"], c["project_id"]))

    standings: List[AwardStandingItemResponse] = []
    for idx, c in enumerate(candidates, start=1):
        standings.append(
            AwardStandingItemResponse(
                project_id=c["project_id"],
                title=c["title"],
                booth_number=c["booth_number"],
                subarea_name=c["subarea_name"],
                education_level=c["education_level"],
                evaluations_count=c["evaluations_count"],
                award_score=c["award_score"],
                rank_position=idx
            )
        )

    return AwardStandingsResponse(
        award_id=award.id,
        award_name=award.name,
        sponsor=award.sponsor,
        criteria_considered=criteria_considered,
        total_competing_projects=len(standings),
        standings=standings
    )

