"""Logistics, barcode check-in and kit delivery service (Regras BR-08 e BR-09)."""

from datetime import datetime, timezone
from typing import List, Optional
from fastapi import HTTPException, status
from sqlalchemy import or_, select, update
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.models.enums import ProjectStatus, UserRole
from app.models.knowledge_area import Subarea
from app.models.person import EventParticipant, EventParticipantRole, Person
from app.models.project import Project, ProjectMember
from app.schemas.logistics import (
    BarcodeScanRequest,
    BarcodeScanResponse,
    KitCheckoutRequest,
    KitCheckoutResponse,
    ProjectKitMemberStatus,
    ProjectKitsSummaryResponse,
    ScanProjectItem
)


def _get_person_lookup_condition(term: str):
    """Cria predicado flexível para busca por código de barras, CPF (com/sem pontuação) ou e-mail."""
    term_clean = term.strip()
    digits = "".join(c for c in term_clean if c.isdigit())
    conds = [
        Person.barcode == term_clean,
        Person.email.ilike(term_clean)
    ]
    if hasattr(Person, "cpf"):
        conds.append(Person.cpf == term_clean)
        if digits and len(digits) == 11:
            formatted = f"{digits[:3]}.{digits[3:6]}.{digits[6:9]}-{digits[9:]}"
            conds.append(Person.cpf == formatted)
    return or_(*conds)


async def scan_barcode(
    db: AsyncSession,
    payload: BarcodeScanRequest
) -> BarcodeScanResponse:
    """
    Bipagem do código de barras individual do crachá na recepção (Regra BR-08).
    - Confirma a presença individual do participante no evento.
    - Gatilho de Presença Coletiva (BR-08): se o participante for integrante de um
      projeto homologado, promove automaticamente o status do trabalho para 'PRESENT'.
    """
    # 1. Localizar participante pelo código de barras, CPF ou e-mail
    stmt_person = select(Person).where(
        _get_person_lookup_condition(payload.barcode),
        Person.deleted_at.is_(None)
    )
    res_person = await db.execute(stmt_person)
    person = res_person.scalar_one_or_none()

    if not person:
        # 1.1 Verificar se o código bipado é o código do estande/pacote do projeto (qrcode_token, booth_number ou PRJ-{id})
        term_clean = payload.barcode.strip()
        proj_id_candidate = -1
        if term_clean.upper().startswith("PRJ-") and term_clean[4:].isdigit():
            proj_id_candidate = int(term_clean[4:])

        stmt_proj_scan = (
            select(Project)
            .options(selectinload(Project.members).selectinload(ProjectMember.person))
            .where(
                Project.event_id == payload.event_id,
                Project.deleted_at.is_(None),
                or_(
                    Project.qrcode_token == term_clean,
                    Project.booth_number.ilike(term_clean),
                    Project.id == proj_id_candidate
                )
            )
        )
        res_proj_scan = await db.execute(stmt_proj_scan)
        scanned_project = res_proj_scan.scalar_one_or_none()

        if not scanned_project:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Código de barras, QR Code ou CPF não encontrado ou inativo."
            )

        # Promove projetos HOMOLOGATED ou SUBMITTED para PRESENT na leitura do estande
        if scanned_project.status in (ProjectStatus.HOMOLOGATED, ProjectStatus.SUBMITTED):
            scanned_project.status = ProjectStatus.PRESENT

        await db.commit()
        await db.refresh(scanned_project)

        # Checar se todos os kits dos membros do estande já foram entregues
        scanned_member_ids = [m.person_id for m in (scanned_project.members or [])]
        parts_map = {}
        if scanned_member_ids:
            stmt_sp = select(EventParticipant).where(
                EventParticipant.event_id == payload.event_id,
                EventParticipant.person_id.in_(scanned_member_ids),
                EventParticipant.deleted_at.is_(None)
            )
            res_sp = await db.execute(stmt_sp)
            parts_map = {ep.person_id: ep for ep in res_sp.scalars().all()}

        all_delivered = bool(scanned_project.members) and all(
            parts_map.get(m.person_id) is not None and parts_map[m.person_id].kit_delivered
            for m in (scanned_project.members or [])
        )

        project_item = ScanProjectItem(
            id=scanned_project.id,
            title=scanned_project.title,
            booth_number=scanned_project.booth_number,
            status=scanned_project.status.value if hasattr(scanned_project.status, "value") else str(scanned_project.status),
            subarea_name=scanned_project.subarea_name,
            area_name=scanned_project.area_name,
            role_in_project=None,
            all_kits_delivered=all_delivered
        )

        booth_str = f"Estande {scanned_project.booth_number}: " if scanned_project.booth_number else ""
        return BarcodeScanResponse(
            barcode=payload.barcode,
            project_id=scanned_project.id,
            project_title=scanned_project.title,
            booth_number=scanned_project.booth_number,
            project_status=scanned_project.status.value if hasattr(scanned_project.status, "value") else str(scanned_project.status),
            collective_presence_triggered=True,
            is_project_scan=True,
            projects=[project_item],
            message=f"{booth_str}{scanned_project.title} identificado. Pacote do projeto liberado para entrega por qualquer integrante."
        )

    now = datetime.now(timezone.utc)

    # 2. Localizar ou inicializar a participação do evento (event_participants)
    stmt_part = select(EventParticipant).where(
        EventParticipant.event_id == payload.event_id,
        EventParticipant.person_id == person.id,
        EventParticipant.deleted_at.is_(None)
    )
    res_part = await db.execute(stmt_part)
    participant = res_part.scalar_one_or_none()

    if not participant:
        participant = EventParticipant(
            event_id=payload.event_id,
            person_id=person.id,
            tshirt_size="M",
            presence_confirmed=True,
            presence_confirmed_at=now
        )
        db.add(participant)
    else:
        participant.presence_confirmed = True
        participant.presence_confirmed_at = now

    await db.flush()

    # 3. Gatilho de Presença Coletiva (BR-08)
    # Busca todos os projetos ativos do evento onde a pessoa é membro
    stmt_proj = (
        select(Project, ProjectMember.role)
        .join(ProjectMember, ProjectMember.project_id == Project.id)
        .options(
            selectinload(Project.subarea).selectinload(Subarea.knowledge_area),
            selectinload(Project.members)
        )
        .where(
            Project.event_id == payload.event_id,
            ProjectMember.person_id == person.id,
            Project.deleted_at.is_(None)
        )
        .order_by(Project.booth_number.nulls_last(), Project.id)
    )
    res_proj = await db.execute(stmt_proj)
    project_tuples = res_proj.all()

    unique_projects: List[Project] = []
    project_roles: dict[int, str] = {}
    for proj, role in project_tuples:
        if proj.id not in project_roles:
            unique_projects.append(proj)
            project_roles[proj.id] = role.value if hasattr(role, "value") else str(role)

    collective_triggered = False
    promoted_projects: List[Project] = []

    for proj in unique_projects:
        # Promove projetos HOMOLOGATED ou SUBMITTED para PRESENT no primeiro membro que chega
        if proj.status in (ProjectStatus.HOMOLOGATED, ProjectStatus.SUBMITTED):
            proj.status = ProjectStatus.PRESENT
            promoted_projects.append(proj)
            collective_triggered = True

    await db.commit()
    await db.refresh(participant)

    # Buscar status de entrega dos kits de todos os integrantes de cada projeto vinculado
    all_member_ids = set()
    for proj in unique_projects:
        for m in (proj.members or []):
            all_member_ids.add(m.person_id)

    parts_map = {}
    if all_member_ids:
        stmt_members_parts = select(EventParticipant).where(
            EventParticipant.event_id == payload.event_id,
            EventParticipant.person_id.in_(all_member_ids),
            EventParticipant.deleted_at.is_(None)
        )
        res_mp = await db.execute(stmt_members_parts)
        parts_map = {ep.person_id: ep for ep in res_mp.scalars().all()}

    project_items: List[ScanProjectItem] = []
    for proj in unique_projects:
        all_delivered = bool(proj.members) and all(
            parts_map.get(m.person_id) is not None and parts_map[m.person_id].kit_delivered
            for m in (proj.members or [])
        )
        project_items.append(
            ScanProjectItem(
                id=proj.id,
                title=proj.title,
                booth_number=proj.booth_number,
                status=proj.status.value if hasattr(proj.status, "value") else str(proj.status),
                subarea_name=proj.subarea_name,
                area_name=proj.area_name,
                role_in_project=project_roles.get(proj.id),
                all_kits_delivered=all_delivered
            )
        )

    # Verificar se a pessoa também possui papel de avaliador nesta edição do evento
    stmt_eval_role = select(EventParticipantRole).where(
        EventParticipantRole.event_id == payload.event_id,
        EventParticipantRole.person_id == person.id,
        EventParticipantRole.role == UserRole.EVALUATOR,
        EventParticipantRole.deleted_at.is_(None)
    )
    res_eval_role = await db.execute(stmt_eval_role)
    is_evaluator = (res_eval_role.scalar_one_or_none() is not None) or (person.role == UserRole.EVALUATOR)

    allocated_count: Optional[int] = None

    # Mensagem informativa detalhada
    if len(project_items) > 1:
        message = f"Presença de {person.name} confirmada com sucesso ({len(project_items)} trabalhos vinculados)."
    else:
        message = f"Presença de {person.name} confirmada com sucesso."

    if promoted_projects:
        if len(promoted_projects) == 1:
            p = promoted_projects[0]
            booth_info = f" (Estande {p.booth_number})" if p.booth_number else ""
            message += f" Trabalho '{p.title}'{booth_info} promovido para PRESENT (Presença confirmada no estande)."
        else:
            promoted_info = ", ".join(
                [f"'{p.title}'" + (f" (Estande {p.booth_number})" if p.booth_number else "") for p in promoted_projects]
            )
            message += f" {len(promoted_projects)} trabalhos promovidos para PRESENT: {promoted_info}."

    if is_evaluator:
        message += f" Aviso: {person.name} possui papel de Avaliador. O check-in e a atribuição de trabalhos devem ser realizados na Sala dos Avaliadores."

    primary_project = unique_projects[0] if unique_projects else None

    return BarcodeScanResponse(
        person_id=person.id,
        person_name=person.name,
        person_role=person.role.value if hasattr(person.role, "value") else str(person.role),
        barcode=payload.barcode,
        presence_confirmed=participant.presence_confirmed,
        presence_confirmed_at=participant.presence_confirmed_at or now,
        tshirt_size=participant.tshirt_size,
        kit_delivered=participant.kit_delivered,
        project_id=primary_project.id if primary_project else None,
        project_title=primary_project.title if primary_project else None,
        booth_number=primary_project.booth_number if primary_project else None,
        project_status=primary_project.status.value if primary_project and hasattr(primary_project.status, "value") else (str(primary_project.status) if primary_project else None),
        collective_presence_triggered=collective_triggered,
        allocated_projects_count=allocated_count,
        is_project_scan=False,
        projects=project_items,
        message=message
    )


async def checkout_kit(
    db: AsyncSession,
    payload: KitCheckoutRequest
) -> KitCheckoutResponse:
    """
    Baixa atômica de entrega de camiseta/kit (Regra BR-09).
    Utiliza SQL UPDATE atômico condicional com WHERE kit_delivered = FALSE,
    garantindo proteção contra retiradas duplicadas em guichês simultâneos.
    """
    # 1. Localizar participante
    stmt_person = select(Person).where(
        _get_person_lookup_condition(payload.barcode),
        Person.deleted_at.is_(None)
    )
    res_person = await db.execute(stmt_person)
    person = res_person.scalar_one_or_none()

    if not person:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Participante não encontrado pelo código de barras ou CPF informado."
        )

    now = datetime.now(timezone.utc)

    # 2. Executar UPDATE atômico condicional contra concorrência
    stmt_update = (
        update(EventParticipant)
        .where(
            EventParticipant.event_id == payload.event_id,
            EventParticipant.person_id == person.id,
            EventParticipant.kit_delivered.is_(False),
            EventParticipant.deleted_at.is_(None)
        )
        .values(
            kit_delivered=True,
            kit_delivered_at=now,
            presence_confirmed=True,
            presence_confirmed_at=now
        )
        .returning(EventParticipant.tshirt_size, EventParticipant.kit_delivered_at)
    )

    result = await db.execute(stmt_update)
    row = result.fetchone()

    if row:
        await db.commit()
        tshirt_size, kit_delivered_at = row
        return KitCheckoutResponse(
            person_id=person.id,
            person_name=person.name,
            tshirt_size=tshirt_size,
            kit_delivered=True,
            kit_delivered_at=kit_delivered_at,
            message=f"Kit entregue com sucesso! Tamanho de camiseta: {tshirt_size}."
        )

    # 3. Se nenhuma linha foi atualizada, verificar se já foi entregue ou se não existe inscrição
    stmt_check = select(EventParticipant).where(
        EventParticipant.event_id == payload.event_id,
        EventParticipant.person_id == person.id,
        EventParticipant.deleted_at.is_(None)
    )
    res_check = await db.execute(stmt_check)
    existing = res_check.scalar_one_or_none()

    if existing and existing.kit_delivered:
        delivered_str = (
            existing.kit_delivered_at.strftime("%d/%m/%Y às %H:%M")
            if existing.kit_delivered_at
            else "horário anterior"
        )
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Bloqueio atômico de duplicidade: o kit de {person.name} já foi retirado em {delivered_str}."
        )

    # Se a participação ainda não existe, cria como entregue
    new_participant = EventParticipant(
        event_id=payload.event_id,
        person_id=person.id,
        tshirt_size="M",
        presence_confirmed=True,
        presence_confirmed_at=now,
        kit_delivered=True,
        kit_delivered_at=now
    )
    db.add(new_participant)
    await db.commit()

    return KitCheckoutResponse(
        person_id=person.id,
        person_name=person.name,
        tshirt_size="M",
        kit_delivered=True,
        kit_delivered_at=now,
        message=f"Inscrição registrada e kit entregue com sucesso! Tamanho: M."
    )


async def get_project_kits(
    db: AsyncSession,
    project_id: int
) -> ProjectKitsSummaryResponse:
    """
    Retorna o status de kits e tamanhos de camiseta de todos os membros de um projeto
    para triagem ágil na mesa de recepção.
    """
    stmt_proj = (
        select(Project)
        .options(selectinload(Project.members).selectinload(ProjectMember.person))
        .where(Project.id == project_id, Project.deleted_at.is_(None))
    )
    res_proj = await db.execute(stmt_proj)
    project = res_proj.scalar_one_or_none()

    if not project:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Projeto não encontrado."
        )

    # Obter os IDs de todas as pessoas da equipe
    person_ids = [m.person_id for m in project.members]

    stmt_parts = select(EventParticipant).where(
        EventParticipant.event_id == project.event_id,
        EventParticipant.person_id.in_(person_ids),
        EventParticipant.deleted_at.is_(None)
    )
    res_parts = await db.execute(stmt_parts)
    parts_map = {p.person_id: p for p in res_parts.scalars().all()}

    members_status: List[ProjectKitMemberStatus] = []
    for m in project.members:
        part = parts_map.get(m.person_id)
        members_status.append(
            ProjectKitMemberStatus(
                person_id=m.person_id,
                name=m.person.name if m.person else f"Pessoa #{m.person_id}",
                role=m.role.value if hasattr(m.role, "value") else str(m.role),
                tshirt_size=part.tshirt_size if part else "M",
                presence_confirmed=part.presence_confirmed if part else False,
                kit_delivered=part.kit_delivered if part else False,
                kit_delivered_at=part.kit_delivered_at if part else None
            )
        )

    return ProjectKitsSummaryResponse(
        project_id=project.id,
        title=project.title,
        booth_number=project.booth_number,
        members=members_status
    )


async def checkout_project_kits(
    db: AsyncSession,
    project_id: int
) -> ProjectKitsSummaryResponse:
    """
    Baixa coletiva de todos os kits da equipe do projeto na entrega do pacote do estande.
    Qualquer integrante do grupo pode retirar o kit do projeto.
    Atualiza todos os integrantes do projeto para kit_delivered=True e presence_confirmed=True.
    """
    stmt_proj = (
        select(Project)
        .options(selectinload(Project.members).selectinload(ProjectMember.person))
        .where(Project.id == project_id, Project.deleted_at.is_(None))
    )
    res_proj = await db.execute(stmt_proj)
    project = res_proj.scalar_one_or_none()

    if not project:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Projeto não encontrado."
        )

    now = datetime.now(timezone.utc)

    # 1. Promover status do projeto para PRESENT se ainda não estiver
    if project.status in (ProjectStatus.HOMOLOGATED, ProjectStatus.SUBMITTED):
        project.status = ProjectStatus.PRESENT

    # 2. Obter participantes existentes do evento
    person_ids = [m.person_id for m in project.members if m.deleted_at is None]

    stmt_parts = select(EventParticipant).where(
        EventParticipant.event_id == project.event_id,
        EventParticipant.person_id.in_(person_ids),
        EventParticipant.deleted_at.is_(None)
    )
    res_parts = await db.execute(stmt_parts)
    existing_parts = {p.person_id: p for p in res_parts.scalars().all()}

    # 3. Atualizar ou criar participação para cada membro, marcando kit como entregue e presença confirmada
    for pid in person_ids:
        part = existing_parts.get(pid)
        if part:
            part.kit_delivered = True
            if not part.kit_delivered_at:
                part.kit_delivered_at = now
            part.presence_confirmed = True
            if not part.presence_confirmed_at:
                part.presence_confirmed_at = now
        else:
            new_part = EventParticipant(
                event_id=project.event_id,
                person_id=pid,
                tshirt_size="M",
                presence_confirmed=True,
                presence_confirmed_at=now,
                kit_delivered=True,
                kit_delivered_at=now
            )
            db.add(new_part)
            existing_parts[pid] = new_part

    await db.commit()
    await db.refresh(project)

    # 4. Retornar resumo completo atualizado
    return await get_project_kits(db, project_id)
