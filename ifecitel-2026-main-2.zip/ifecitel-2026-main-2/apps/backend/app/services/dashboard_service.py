"""Dashboard service for public TV kiosk (Regra BR-14) and Admin War Room (BR-10, BR-18)."""

import math
import time
from collections import defaultdict
from datetime import datetime, timezone, timedelta
from typing import Dict, List, Optional, Set, Tuple

from fastapi import HTTPException, status
from sqlalchemy import exists, func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.enums import AllocationStatus, EvaluationStatus, ProjectStatus, UserRole
from app.models.evaluation import Evaluation, EvaluatorAllocation
from app.models.event import Event, EducationLevel
from app.models.knowledge_area import KnowledgeArea, Subarea
from app.models.person import EventParticipant, EventParticipantRole, Person, PersonSubarea
from app.models.project import Project
from app.schemas.dashboard import (
    AdminAreaDiagnostic,
    AdminEvaluatorsKpi,
    AdminKpiCollection,
    AdminOverviewResponse,
    AdminParticipantsKpi,
    AdminProgressKpi,
    AdminProjectsKpi,
    AllocatedEvaluatorSimple,
    AreaEvaluationProgress,
    AreaLevelLeaderboardGroup,
    CriticalProjectItem,
    LevelLeaderboardGroup,
    OverallLeaderboardResponse,
    ProjectRankingItemResponse,
    PublicTvDashboardResponse
)

# Cache em memória de curta duração para métricas de TV e Admin War Room (TTL = 8 segundos)
_DASHBOARD_CACHE_TTL = 8.0
_public_tv_cache: Dict[int, Tuple[float, PublicTvDashboardResponse]] = {}
_admin_overview_cache: Dict[int, Tuple[float, AdminOverviewResponse]] = {}


def invalidate_dashboard_cache(event_id: Optional[int] = None) -> None:
    """Invalida o cache em memória das métricas analíticas de dashboard."""
    if event_id is not None:
        _public_tv_cache.pop(event_id, None)
        _admin_overview_cache.pop(event_id, None)
    else:
        _public_tv_cache.clear()
        _admin_overview_cache.clear()


async def get_public_tv_metrics(
    db: AsyncSession,
    event_id: int
) -> PublicTvDashboardResponse:
    """
    Retorna métricas puramente agregadas para exibição nos telões da feira (Regra BR-14).
    Sigilo Absoluto: Não expõe notas individuais, pareceres, ranqueamentos ou nomes de avaliadores.
    Calcula metas e progresso baseando-se na cota de min_evaluators configurada para cada nível de ensino
    ou cota de avaliadores do evento configurada no banco de dados.
    """
    # 0. Verificação de Cache em Memória (TTL 8s)
    now_ts = time.monotonic()
    if event_id in _public_tv_cache:
        cached_ts, cached_resp = _public_tv_cache[event_id]
        if now_ts - cached_ts < _DASHBOARD_CACHE_TTL:
            return cached_resp

    # 1. Verificar se o evento existe
    stmt_ev = select(Event).where(Event.id == event_id, Event.deleted_at.is_(None))
    res_ev = await db.execute(stmt_ev)
    event = res_ev.scalar_one_or_none()

    if not event:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Edição do evento não encontrada."
        )

    # 2. Contagem agregada e segmentada de participantes (alunos/orientadores e avaliadores)
    # Suporte a múltiplos papéis por edição (Doc 024 e Regra BR-14):
    # Um participante pode ter cadastro base como orientador/coorientador, mas ter o papel
    # de EVALUATOR na edição em event_participant_roles ou possuir credenciamento de avaliador.
    evaluator_role_exists = exists().where(
        EventParticipantRole.person_id == EventParticipant.person_id,
        EventParticipantRole.event_id == event_id,
        EventParticipantRole.role == UserRole.EVALUATOR,
        EventParticipantRole.deleted_at.is_(None)
    )
    is_evaluator_expr = or_(
        Person.role == UserRole.EVALUATOR,
        evaluator_role_exists,
        EventParticipant.evaluator_presence_confirmed.is_(True)
    )

    student_advisor_role_exists = exists().where(
        EventParticipantRole.person_id == EventParticipant.person_id,
        EventParticipantRole.event_id == event_id,
        EventParticipantRole.role.in_([UserRole.STUDENT, UserRole.ADVISOR, UserRole.COADVISOR]),
        EventParticipantRole.deleted_at.is_(None)
    )
    is_student_advisor_expr = or_(
        Person.role.in_([UserRole.STUDENT, UserRole.ADVISOR, UserRole.COADVISOR]),
        student_advisor_role_exists
    )

    stmt_part_agg = (
        select(
            func.count(EventParticipant.id).label("total_registered_all"),
            func.count(func.nullif(EventParticipant.presence_confirmed.is_(True), False)).label("total_present_all"),
            func.count(
                func.nullif(
                    is_student_advisor_expr,
                    False
                )
            ).label("registered_students_advisors"),
            func.count(
                func.nullif(
                    is_student_advisor_expr & (EventParticipant.presence_confirmed.is_(True)),
                    False
                )
            ).label("present_students_advisors"),
            func.count(
                func.nullif(
                    is_evaluator_expr,
                    False
                )
            ).label("registered_evaluators"),
            func.count(
                func.nullif(
                    EventParticipant.evaluator_presence_confirmed.is_(True),
                    False
                )
            ).label("present_evaluators"),
        )
        .join(Person, Person.id == EventParticipant.person_id)
        .where(
            EventParticipant.event_id == event_id,
            EventParticipant.deleted_at.is_(None)
        )
    )
    res_part_agg = await db.execute(stmt_part_agg)
    part_row = res_part_agg.one()

    # Contagem de papéis de avaliador registrados diretamente em event_participant_roles
    stmt_eval_roles = (
        select(func.count(func.distinct(EventParticipantRole.person_id)))
        .where(
            EventParticipantRole.event_id == event_id,
            EventParticipantRole.role == UserRole.EVALUATOR,
            EventParticipantRole.deleted_at.is_(None)
        )
    )
    res_eval_roles = await db.execute(stmt_eval_roles)
    eval_roles_total = res_eval_roles.scalar_one() or 0

    total_registered_participants = part_row.total_registered_all or 0
    total_present_participants = part_row.total_present_all or 0
    total_registered_students_advisors = part_row.registered_students_advisors or 0
    total_present_students_advisors = part_row.present_students_advisors or 0
    total_present_evaluators = part_row.present_evaluators or 0
    total_registered_evaluators = max(part_row.registered_evaluators or 0, eval_roles_total, total_present_evaluators)

    # Fallback caso os papéis não estejam configurados como STUDENT/ADVISOR
    if total_registered_students_advisors == 0 and total_registered_participants > 0:
        total_registered_students_advisors = max(0, total_registered_participants - total_registered_evaluators)
        total_present_students_advisors = max(0, total_present_participants - total_present_evaluators)

    # 3. Contagem de projetos inscritos vs presentes nos estandes
    stmt_proj_total = select(func.count(Project.id)).where(
        Project.event_id == event_id,
        Project.deleted_at.is_(None)
    )
    res_proj_total = await db.execute(stmt_proj_total)
    total_registered_projects = res_proj_total.scalar_one() or 0

    stmt_proj_pres = select(func.count(Project.id)).where(
        Project.event_id == event_id,
        Project.status.in_([
            ProjectStatus.PRESENT,
            ProjectStatus.UNDER_EVALUATION,
            ProjectStatus.EVALUATED
        ]),
        Project.deleted_at.is_(None)
    )
    res_proj_pres = await db.execute(stmt_proj_pres)
    total_present_projects = res_proj_pres.scalar_one() or 0

    # 4. Contagem total de avaliações concluídas
    stmt_eval_total = (
        select(func.count(Evaluation.id))
        .join(Project, Project.id == Evaluation.project_id)
        .where(
            Project.event_id == event_id,
            Evaluation.status == EvaluationStatus.COMPLETED,
            Evaluation.deleted_at.is_(None)
        )
    )
    res_eval_total = await db.execute(stmt_eval_total)
    total_evaluations_completed = res_eval_total.scalar_one() or 0

    # 5. Configuração de cota de avaliadores por Nível de Ensino puxada do banco de dados (Regra BR-21)
    stmt_levels = select(EducationLevel).where(
        EducationLevel.event_id == event_id,
        EducationLevel.deleted_at.is_(None)
    )
    res_levels = await db.execute(stmt_levels)
    levels = list(res_levels.scalars().all())

    level_min_evaluators_map = {}
    for lvl in levels:
        lvl_key = lvl.level_name.value if hasattr(lvl.level_name, "value") else str(lvl.level_name)
        level_min_evaluators_map[lvl_key] = lvl.min_evaluators

    # Puxa dinamicamente a cota do evento cadastrada no banco de dados (ex: 3 avaliadores para a edição)
    event_eval_quota = getattr(event, "max_projects_per_evaluator", None) or 3
    default_min_eval = levels[0].min_evaluators if levels else event_eval_quota

    def get_project_min_evals(proj_edu_level) -> int:
        key = proj_edu_level.value if hasattr(proj_edu_level, "value") else str(proj_edu_level)
        return level_min_evaluators_map.get(key, default_min_eval)

    is_present_status = lambda st: st in (
        ProjectStatus.PRESENT,
        ProjectStatus.UNDER_EVALUATION,
        ProjectStatus.EVALUATED
    )

    # 6. Mapeamento de subáreas para grandes áreas
    stmt_subareas = (
        select(Subarea.id, Subarea.area_id)
        .join(KnowledgeArea, KnowledgeArea.id == Subarea.area_id)
        .where(
            KnowledgeArea.event_id == event_id,
            KnowledgeArea.deleted_at.is_(None),
            Subarea.deleted_at.is_(None)
        )
    )
    res_subareas = await db.execute(stmt_subareas)
    subarea_to_area = {row.id: row.area_id for row in res_subareas.all()}

    # 7. Consulta de todos os projetos do evento
    stmt_all_projects = (
        select(Project.id, Project.subarea_id, Project.education_level, Project.status)
        .where(Project.event_id == event_id, Project.deleted_at.is_(None))
    )
    res_all_projects = await db.execute(stmt_all_projects)
    all_projects = res_all_projects.all()

    # Considera projetos presentes; se ainda não houver presença no credenciamento, usa os inscritos
    target_projects = [p for p in all_projects if is_present_status(p.status)]
    if not target_projects:
        target_projects = list(all_projects)

    total_expected_evaluations = sum(get_project_min_evals(p.education_level) for p in target_projects)
    if total_expected_evaluations > 0:
        evaluation_progress_percent = min(
            100.0,
            round((total_evaluations_completed / total_expected_evaluations) * 100, 1)
        )
    else:
        evaluation_progress_percent = 0.0

    # 8. Contagem agregada única de avaliações concluídas por grande área (elimina N+1 queries)
    stmt_area_evals = (
        select(Subarea.area_id, func.count(Evaluation.id).label("completed_count"))
        .join(Project, Project.id == Evaluation.project_id)
        .join(Subarea, Subarea.id == Project.subarea_id)
        .where(
            Project.event_id == event_id,
            Evaluation.status == EvaluationStatus.COMPLETED,
            Evaluation.deleted_at.is_(None)
        )
        .group_by(Subarea.area_id)
    )
    res_area_evals = await db.execute(stmt_area_evals)
    eval_counts_by_area = {row.area_id: row.completed_count for row in res_area_evals.all()}

    # 9. Progresso de avaliações estruturado por Grande Área do Conhecimento
    stmt_areas = (
        select(KnowledgeArea)
        .where(KnowledgeArea.event_id == event_id, KnowledgeArea.deleted_at.is_(None))
        .order_by(KnowledgeArea.name)
    )
    res_areas = await db.execute(stmt_areas)
    areas = res_areas.scalars().all()

    areas_progress: List[AreaEvaluationProgress] = []
    for area in areas:
        area_projects = [p for p in all_projects if subarea_to_area.get(p.subarea_id) == area.id]
        area_total_projects = len(area_projects)
        area_present_projects = sum(1 for p in area_projects if is_present_status(p.status))

        area_target_projects = [
            p for p in area_projects
            if (is_present_status(p.status) if total_present_projects > 0 else True)
        ]
        area_expected_evals = sum(get_project_min_evals(p.education_level) for p in area_target_projects)
        area_eval_completed = eval_counts_by_area.get(area.id, 0)

        area_progress_percent = (
            min(100.0, round((area_eval_completed / area_expected_evals) * 100, 1))
            if area_expected_evals > 0
            else 0.0
        )

        areas_progress.append(
            AreaEvaluationProgress(
                area_id=area.id,
                area_name=area.name,
                total_projects=area_total_projects,
                present_projects=area_present_projects,
                evaluations_completed=area_eval_completed,
                expected_evaluations=area_expected_evals,
                progress_percent=area_progress_percent
            )
        )

    response = PublicTvDashboardResponse(
        event_id=event.id,
        event_name=event.name,
        total_registered_participants=total_registered_participants,
        total_present_participants=total_present_participants,
        total_registered_students_advisors=total_registered_students_advisors,
        total_present_students_advisors=total_present_students_advisors,
        total_registered_evaluators=total_registered_evaluators,
        total_present_evaluators=total_present_evaluators,
        total_registered_projects=total_registered_projects,
        total_present_projects=total_present_projects,
        total_evaluations_completed=total_evaluations_completed,
        areas_progress=areas_progress,
        updated_at=datetime.now(timezone.utc),
        min_evaluators_default=default_min_eval,
        total_expected_evaluations=total_expected_evaluations,
        evaluation_progress_percent=evaluation_progress_percent
    )
    _public_tv_cache[event_id] = (time.monotonic(), response)
    return response


async def get_admin_overview_metrics(
    db: AsyncSession,
    event_id: int
) -> AdminOverviewResponse:
    """
    Retorna diagnóstico executivo unificado para o Centro de Comando do Administrador (BR-10, BR-14, BR-18).
    Agrupa em uma única chamada de alta performance (sem N+1):
    - 4 KPIs principais com microdetalhes operacionais (2A.3, 2B.1+2B.2, 2C.3+2C.1, 2D.1+2D.2)
    - Diagnóstico de saúde e déficit de avaliadores por Grande Área (Termômetro de Risco 3A)
    - Listagem de trabalhos críticos com 0 ou abaixo da cota (4A)
    - Conformidade com a Regra de Ouro (delta <= 1)
    """
    # 0. Verificação de Cache em Memória (TTL 8s)
    now_ts = time.monotonic()
    if event_id in _admin_overview_cache:
        cached_ts, cached_resp = _admin_overview_cache[event_id]
        if now_ts - cached_ts < _DASHBOARD_CACHE_TTL:
            return cached_resp

    # 1. Verificar evento
    stmt_ev = select(Event).where(Event.id == event_id, Event.deleted_at.is_(None))
    res_ev = await db.execute(stmt_ev)
    event = res_ev.scalar_one_or_none()
    if not event:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Edição do evento não encontrada."
        )

    # 2. Configurações de cota e níveis de ensino
    stmt_levels = select(EducationLevel).where(
        EducationLevel.event_id == event_id,
        EducationLevel.deleted_at.is_(None)
    )
    res_levels = await db.execute(stmt_levels)
    levels = list(res_levels.scalars().all())
    level_min_evaluators_map = {
        (lvl.level_name.value if hasattr(lvl.level_name, "value") else str(lvl.level_name)): lvl.min_evaluators
        for lvl in levels
    }
    event_eval_quota = getattr(event, "max_projects_per_evaluator", None) or 3
    default_min_eval = levels[0].min_evaluators if levels else event_eval_quota

    def get_project_min_evals(proj_edu_level) -> int:
        key = proj_edu_level.value if hasattr(proj_edu_level, "value") else str(proj_edu_level)
        return level_min_evaluators_map.get(key, default_min_eval)

    # 3. Subáreas e Grandes Áreas
    stmt_subareas = (
        select(Subarea.id, Subarea.area_id, Subarea.name)
        .join(KnowledgeArea, KnowledgeArea.id == Subarea.area_id)
        .where(
            KnowledgeArea.event_id == event_id,
            KnowledgeArea.deleted_at.is_(None),
            Subarea.deleted_at.is_(None)
        )
    )
    res_subareas = await db.execute(stmt_subareas)
    subareas_rows = res_subareas.all()
    subarea_to_area = {row.id: row.area_id for row in subareas_rows}

    stmt_areas = (
        select(KnowledgeArea)
        .where(KnowledgeArea.event_id == event_id, KnowledgeArea.deleted_at.is_(None))
        .order_by(KnowledgeArea.name)
    )
    res_areas = await db.execute(stmt_areas)
    areas = res_areas.scalars().all()
    area_name_map = {a.id: a.name for a in areas}

    # 4. Agregação de Participantes (Alunos, Orientadores, Avaliadores, Kits)
    evaluator_role_exists = exists().where(
        EventParticipantRole.person_id == EventParticipant.person_id,
        EventParticipantRole.event_id == event_id,
        EventParticipantRole.role == UserRole.EVALUATOR,
        EventParticipantRole.deleted_at.is_(None)
    )
    is_evaluator_expr = or_(
        Person.role == UserRole.EVALUATOR,
        evaluator_role_exists,
        EventParticipant.evaluator_presence_confirmed.is_(True)
    )

    student_role_exists = exists().where(
        EventParticipantRole.person_id == EventParticipant.person_id,
        EventParticipantRole.event_id == event_id,
        EventParticipantRole.role == UserRole.STUDENT,
        EventParticipantRole.deleted_at.is_(None)
    )
    is_student_expr = or_(
        Person.role == UserRole.STUDENT,
        student_role_exists
    )

    advisor_role_exists = exists().where(
        EventParticipantRole.person_id == EventParticipant.person_id,
        EventParticipantRole.event_id == event_id,
        EventParticipantRole.role.in_([UserRole.ADVISOR, UserRole.COADVISOR]),
        EventParticipantRole.deleted_at.is_(None)
    )
    is_advisor_expr = or_(
        Person.role.in_([UserRole.ADVISOR, UserRole.COADVISOR]),
        advisor_role_exists
    )

    stmt_part_agg = (
        select(
            func.count(EventParticipant.id).label("total_registered_all"),
            func.count(func.nullif(EventParticipant.presence_confirmed.is_(True), False)).label("total_present_all"),
            func.count(func.nullif(EventParticipant.kit_delivered.is_(True), False)).label("kits_delivered"),
            func.count(func.nullif(is_student_expr, False)).label("registered_students"),
            func.count(func.nullif(is_student_expr & (EventParticipant.presence_confirmed.is_(True)), False)).label("present_students"),
            func.count(func.nullif(is_advisor_expr, False)).label("registered_advisors"),
            func.count(func.nullif(is_advisor_expr & (EventParticipant.presence_confirmed.is_(True)), False)).label("present_advisors"),
            func.count(func.nullif(is_evaluator_expr, False)).label("registered_evaluators"),
            func.count(func.nullif(EventParticipant.evaluator_presence_confirmed.is_(True), False)).label("present_evaluators"),
        )
        .join(Person, Person.id == EventParticipant.person_id)
        .where(
            EventParticipant.event_id == event_id,
            EventParticipant.deleted_at.is_(None)
        )
    )
    res_part_agg = await db.execute(stmt_part_agg)
    part_row = res_part_agg.one()

    # Contagem distinta de papéis de avaliador na edição
    stmt_eval_roles = (
        select(func.count(func.distinct(EventParticipantRole.person_id)))
        .where(
            EventParticipantRole.event_id == event_id,
            EventParticipantRole.role == UserRole.EVALUATOR,
            EventParticipantRole.deleted_at.is_(None)
        )
    )
    res_eval_roles = await db.execute(stmt_eval_roles)
    eval_roles_total = res_eval_roles.scalar_one() or 0

    total_registered_all = part_row.total_registered_all or 0
    total_present_all = part_row.total_present_all or 0
    kits_delivered = part_row.kits_delivered or 0
    registered_students = part_row.registered_students or 0
    present_students = part_row.present_students or 0
    registered_advisors = part_row.registered_advisors or 0
    present_advisors = part_row.present_advisors or 0
    present_evaluators = part_row.present_evaluators or 0
    registered_evaluators = max(part_row.registered_evaluators or 0, eval_roles_total, present_evaluators)

    # Fallback caso participantes não estejam tipados como student/advisor
    if registered_students == 0 and total_registered_all > 0:
        registered_students = max(0, total_registered_all - registered_evaluators - registered_advisors)
        present_students = max(0, total_present_all - present_evaluators - present_advisors)

    students_pct = round((present_students / registered_students * 100), 1) if registered_students > 0 else 0.0
    advisors_pct = round((present_advisors / registered_advisors * 100), 1) if registered_advisors > 0 else 0.0
    overall_presence_pct = round((total_present_all / total_registered_all * 100), 1) if total_registered_all > 0 else 0.0
    kits_pct = round((kits_delivered / total_registered_all * 100), 1) if total_registered_all > 0 else 0.0

    # 5. Avaliadores qualificados por subárea/área e presenças de avaliadores
    stmt_person_subareas = (
        select(PersonSubarea.person_id, Subarea.area_id)
        .join(Subarea, Subarea.id == PersonSubarea.subarea_id)
        .where(PersonSubarea.event_id == event_id, PersonSubarea.deleted_at.is_(None))
    )
    res_ps = await db.execute(stmt_person_subareas)
    area_qualified_persons: Dict[int, Set[int]] = defaultdict(set)
    for p_id, a_id in res_ps.all():
        area_qualified_persons[a_id].add(p_id)

    stmt_present_eval_ids = (
        select(EventParticipant.person_id)
        .where(
            EventParticipant.event_id == event_id,
            EventParticipant.evaluator_presence_confirmed.is_(True),
            EventParticipant.deleted_at.is_(None)
        )
    )
    res_present_eval_ids = await db.execute(stmt_present_eval_ids)
    present_evaluator_ids = set(res_present_eval_ids.scalars().all())

    # 6. Consulta e segmentação de projetos
    stmt_projects = (
        select(
            Project.id,
            Project.title,
            Project.booth_number,
            Project.subarea_id,
            Project.education_level,
            Project.status
        )
        .where(Project.event_id == event_id, Project.deleted_at.is_(None))
    )
    res_projects = await db.execute(stmt_projects)
    all_projects = res_projects.all()

    is_present_status = lambda st: st in (
        ProjectStatus.PRESENT,
        ProjectStatus.UNDER_EVALUATION,
        ProjectStatus.EVALUATED
    )

    present_projects = [p for p in all_projects if is_present_status(p.status)]
    in_eval_count = sum(1 for p in all_projects if p.status == ProjectStatus.UNDER_EVALUATION)
    evaluated_count = sum(1 for p in all_projects if p.status == ProjectStatus.EVALUATED)
    absent_count = len(all_projects) - len(present_projects)

    target_projects = present_projects if present_projects else list(all_projects)
    total_expected_evaluations = sum(get_project_min_evals(p.education_level) for p in target_projects)

    # 7. Alocações ativas e identificação de trabalhos críticos
    stmt_allocs = (
        select(
            EvaluatorAllocation.id,
            EvaluatorAllocation.project_id,
            EvaluatorAllocation.evaluator_id,
            EvaluatorAllocation.status,
            Person.name.label("evaluator_name"),
            Project.education_level
        )
        .join(Person, Person.id == EvaluatorAllocation.evaluator_id)
        .join(Project, Project.id == EvaluatorAllocation.project_id)
        .where(
            EvaluatorAllocation.event_id == event_id,
            EvaluatorAllocation.status != AllocationStatus.CANCELLED,
            EvaluatorAllocation.deleted_at.is_(None)
        )
    )
    res_allocs = await db.execute(stmt_allocs)
    all_allocs = res_allocs.all()

    allocations_by_project: Dict[int, List[AllocatedEvaluatorSimple]] = defaultdict(list)
    allocations_by_evaluator: Dict[int, List[int]] = defaultdict(list)
    fundamental_evals_set: Set[int] = set()
    medio_evals_set: Set[int] = set()

    for row in all_allocs:
        allocations_by_project[row.project_id].append(
            AllocatedEvaluatorSimple(id=row.evaluator_id, name=row.evaluator_name)
        )
        allocations_by_evaluator[row.evaluator_id].append(row.project_id)
        lvl_str = str(row.education_level).upper()
        if "FUNDAMENTAL" in lvl_str:
            fundamental_evals_set.add(row.evaluator_id)
        else:
            medio_evals_set.add(row.evaluator_id)

    critical_projects: List[CriticalProjectItem] = []
    zero_evals_count = 0
    under_quota_count = 0

    for proj in present_projects:
        allocs_for_proj = allocations_by_project.get(proj.id, [])
        alloc_count = len(allocs_for_proj)
        min_required = get_project_min_evals(proj.education_level)
        area_id = subarea_to_area.get(proj.subarea_id, 0)
        area_name = area_name_map.get(area_id, "Não informada")
        edu_lvl_str = proj.education_level.value if hasattr(proj.education_level, "value") else str(proj.education_level)

        if alloc_count == 0:
            zero_evals_count += 1
            critical_projects.append(
                CriticalProjectItem(
                    project_id=proj.id,
                    title=proj.title,
                    stand_number=proj.booth_number or f"ESTANDE #{proj.id}",
                    area_id=area_id,
                    area_name=area_name,
                    education_level=edu_lvl_str,
                    min_evaluators=min_required,
                    allocated_evaluators_count=0,
                    allocated_evaluators=[],
                    gap_status="ZERO_EVALUATORS"
                )
            )
        elif alloc_count < min_required:
            under_quota_count += 1
            critical_projects.append(
                CriticalProjectItem(
                    project_id=proj.id,
                    title=proj.title,
                    stand_number=proj.booth_number or f"ESTANDE #{proj.id}",
                    area_id=area_id,
                    area_name=area_name,
                    education_level=edu_lvl_str,
                    min_evaluators=min_required,
                    allocated_evaluators_count=alloc_count,
                    allocated_evaluators=allocs_for_proj,
                    gap_status="BELOW_QUOTA"
                )
            )

    critical_projects.sort(key=lambda x: (0 if x.gap_status == "ZERO_EVALUATORS" else 1, x.stand_number or ""))

    # Regra de Ouro (delta <= 1 entre projetos presentes)
    if present_projects:
        counts = [len(allocations_by_project.get(p.id, [])) for p in present_projects]
        golden_rule_satisfied = (max(counts) - min(counts)) <= 1
    else:
        golden_rule_satisfied = True

    # 8. Avaliações concluídas e ritmo
    stmt_evals = (
        select(
            Evaluation.id,
            Evaluation.status,
            Evaluation.evaluated_at,
            Evaluation.created_at,
            Subarea.area_id
        )
        .join(Project, Project.id == Evaluation.project_id)
        .join(Subarea, Subarea.id == Project.subarea_id)
        .where(
            Project.event_id == event_id,
            Evaluation.deleted_at.is_(None)
        )
    )
    res_evals = await db.execute(stmt_evals)
    all_evals = res_evals.all()

    completed_evals = [e for e in all_evals if e.status == EvaluationStatus.COMPLETED]
    in_prog_evals = [e for e in all_evals if e.status == EvaluationStatus.DRAFT]
    total_evals_completed = len(completed_evals)
    total_evals_in_progress = len(in_prog_evals)
    evals_pending = max(0, total_expected_evaluations - total_evals_completed)

    progress_percent = (
        min(100.0, round((total_evals_completed / total_expected_evaluations) * 100, 1))
        if total_expected_evaluations > 0
        else 0.0
    )

    now = datetime.now(timezone.utc)
    two_hours_ago = now - timedelta(hours=2)
    recent_completed = [
        e for e in completed_evals
        if e.evaluated_at and (e.evaluated_at if e.evaluated_at.tzinfo else e.evaluated_at.replace(tzinfo=timezone.utc)) >= two_hours_ago
    ]
    evals_per_hour = round(len(recent_completed) / 2.0, 1) if recent_completed else 0.0
    est_completion_time: Optional[str] = None
    if evals_per_hour > 0 and evals_pending > 0:
        hours_to_finish = evals_pending / evals_per_hour
        est_completion_time = (now + timedelta(hours=hours_to_finish)).strftime("%H:%M")

    completed_by_area: Dict[int, int] = defaultdict(int)
    for e in completed_evals:
        completed_by_area[e.area_id] += 1

    # 9. Diagnóstico por Grande Área (Termômetro de Risco)
    areas_diagnostic: List[AdminAreaDiagnostic] = []
    for area in areas:
        area_projs = [p for p in all_projects if subarea_to_area.get(p.subarea_id) == area.id]
        area_pres_projs = [p for p in area_projs if is_present_status(p.status)]
        target_area_projs = area_pres_projs if len(present_projects) > 0 else area_projs
        area_expected = sum(get_project_min_evals(p.education_level) for p in target_area_projs)
        area_completed = completed_by_area.get(area.id, 0)
        area_prog_pct = (
            min(100.0, round((area_completed / area_expected) * 100, 1))
            if area_expected > 0
            else 0.0
        )

        qualified_pids = area_qualified_persons.get(area.id, set())
        reg_evals = len(qualified_pids)
        pres_evals = len(qualified_pids.intersection(present_evaluator_ids))
        area_cap = pres_evals * event_eval_quota
        deficit_evals = max(0, area_expected - area_cap)
        needed_evals = math.ceil(deficit_evals / event_eval_quota) if event_eval_quota > 0 else 0

        if area_expected == 0 or area_cap >= area_expected:
            health = "GREEN"
        elif area_cap >= (area_expected * 0.5):
            health = "YELLOW"
        else:
            health = "RED"

        area_risk_projs = sum(
            1 for p in area_pres_projs
            if len(allocations_by_project.get(p.id, [])) < get_project_min_evals(p.education_level)
        )

        areas_diagnostic.append(
            AdminAreaDiagnostic(
                area_id=area.id,
                area_name=area.name,
                total_projects=len(area_projs),
                present_projects=len(area_pres_projs),
                evaluations_completed=area_completed,
                expected_evaluations=area_expected,
                progress_percent=area_prog_pct,
                registered_evaluators=reg_evals,
                present_evaluators=pres_evals,
                area_capacity=area_cap,
                deficit_evaluations=deficit_evals,
                deficit_evaluators_needed=needed_evals,
                health_status=health,
                projects_at_risk_count=area_risk_projs
            )
        )

    # 10. Balanço Global de Capacidade de Avaliadores
    total_cap = present_evaluators * event_eval_quota
    global_def_evals = max(0, total_expected_evaluations - total_cap)
    global_def_evaluators = math.ceil(global_def_evals / event_eval_quota) if event_eval_quota > 0 else 0

    evaluating_now_count = len([e_id for e_id in present_evaluator_ids if len(allocations_by_evaluator.get(e_id, [])) > 0])
    available_evaluators_count = max(0, present_evaluators - evaluating_now_count)
    evaluators_pres_pct = round((present_evaluators / registered_evaluators * 100), 1) if registered_evaluators > 0 else 0.0

    projects_pres_pct = round((len(present_projects) / len(all_projects) * 100), 1) if len(all_projects) > 0 else 0.0

    kpis = AdminKpiCollection(
        projects=AdminProjectsKpi(
            registered=len(all_projects),
            present=len(present_projects),
            present_percent=projects_pres_pct,
            in_evaluation=in_eval_count,
            evaluated=evaluated_count,
            absent=absent_count,
            zero_evaluators_count=zero_evals_count,
            under_quota_count=under_quota_count
        ),
        participants=AdminParticipantsKpi(
            registered_students=registered_students,
            present_students=present_students,
            students_presence_percent=students_pct,
            registered_advisors=registered_advisors,
            present_advisors=present_advisors,
            advisors_presence_percent=advisors_pct,
            total_registered=total_registered_all,
            total_present=total_present_all,
            overall_presence_percent=overall_presence_pct,
            kits_delivered=kits_delivered,
            kits_delivered_percent=kits_pct
        ),
        evaluators=AdminEvaluatorsKpi(
            registered=registered_evaluators,
            present=present_evaluators,
            present_percent=evaluators_pres_pct,
            evaluating_now=evaluating_now_count,
            available=available_evaluators_count,
            total_capacity=total_cap,
            expected_evaluations=total_expected_evaluations,
            global_deficit_evaluations=global_def_evals,
            global_deficit_evaluators=global_def_evaluators,
            fundamental_evaluators_count=len(fundamental_evals_set),
            medio_evaluators_count=len(medio_evals_set)
        ),
        progress=AdminProgressKpi(
            evaluations_completed=total_evals_completed,
            evaluations_in_progress=total_evals_in_progress,
            evaluations_pending=evals_pending,
            progress_percent=progress_percent,
            evaluations_per_hour=evals_per_hour,
            estimated_completion_time=est_completion_time
        )
    )

    ev_status_str = event.status.value if hasattr(event.status, "value") else str(event.status)

    response = AdminOverviewResponse(
        event_id=event.id,
        event_name=event.name,
        event_year=event.year,
        event_status=ev_status_str,
        max_projects_per_evaluator=event_eval_quota,
        updated_at=now,
        kpis=kpis,
        areas_diagnostic=areas_diagnostic,
        critical_projects=critical_projects,
        golden_rule_satisfied=golden_rule_satisfied,
        total_active_allocations=len(all_allocs)
    )
    _admin_overview_cache[event_id] = (time.monotonic(), response)
    return response


async def get_area_level_leaderboard(
    db: AsyncSession,
    event_id: int,
    area_id: Optional[int] = None,
    education_level: Optional[str] = None
) -> List[AreaLevelLeaderboardGroup]:
    """
    Ranking 1: Classificação por Grande Área do Conhecimento e Nível de Ensino (Regra BR-12).
    Calcula a média simples de todas as avaliações concluídas considerando TODOS os itens de notas da ficha.
    """
    from collections import defaultdict
    from sqlalchemy.orm import selectinload
    from app.models.evaluation import EvaluationItem
    from app.services.evaluation_service import compute_single_evaluation_score
    from app.schemas.dashboard import AreaLevelLeaderboardGroup, ProjectRankingItemResponse

    # 1. Verificar evento
    stmt_ev = select(Event).where(Event.id == event_id, Event.deleted_at.is_(None))
    res_ev = await db.execute(stmt_ev)
    event = res_ev.scalar_one_or_none()
    if not event:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Edição do evento não encontrada.")

    # 2. Carregar projetos com área, subárea e avaliações concluídas
    stmt_proj = (
        select(Project)
        .join(Subarea, Subarea.id == Project.subarea_id)
        .join(KnowledgeArea, KnowledgeArea.id == Subarea.area_id)
        .options(
            selectinload(Project.subarea).selectinload(Subarea.knowledge_area),
            selectinload(Project.evaluations).selectinload(Evaluation.items).selectinload(EvaluationItem.criterion)
        )
        .where(Project.event_id == event_id, Project.deleted_at.is_(None))
    )

    if area_id:
        stmt_proj = stmt_proj.where(Subarea.area_id == area_id)
    if education_level:
        stmt_proj = stmt_proj.where(Project.education_level == education_level)

    res_proj = await db.execute(stmt_proj)
    projects = res_proj.scalars().all()

    # 3. Agrupar projetos por (area_id, area_name, education_level)
    groups_dict = defaultdict(list)

    for proj in projects:
        comp_evals = [
            ev for ev in proj.evaluations
            if ev.status == EvaluationStatus.COMPLETED and ev.deleted_at is None
        ]
        if not comp_evals:
            continue

        eval_scores = [compute_single_evaluation_score(ev.items) for ev in comp_evals]
        final_score = round(sum(eval_scores) / len(eval_scores), 2) if eval_scores else 0.0

        area_obj = proj.subarea.knowledge_area if proj.subarea else None
        a_id = area_obj.id if area_obj else 0
        a_name = area_obj.name if area_obj else "Sem Área"
        ed_level = proj.education_level.value if hasattr(proj, "education_level") and proj.education_level else "MEDIO"

        key = (a_id, a_name, ed_level)
        groups_dict[key].append({
            "project_id": proj.id,
            "title": proj.title,
            "booth_number": proj.booth_number or "",
            "subarea_name": proj.subarea.name if proj.subarea else "Geral",
            "area_name": a_name,
            "education_level": ed_level,
            "evaluations_count": len(eval_scores),
            "final_score": final_score
        })

    # 4. Ordenar projetos de cada grupo e atribuir rank_position
    result_groups: List[AreaLevelLeaderboardGroup] = []

    # Ordenar grupos por nome da área e nível de ensino
    sorted_keys = sorted(groups_dict.keys(), key=lambda k: (k[1], k[2]))

    for (a_id, a_name, ed_level) in sorted_keys:
        projs = groups_dict[(a_id, a_name, ed_level)]
        # Maior nota primeiro, desempate por contagem de avaliações e ID do projeto
        projs.sort(key=lambda p: (-p["final_score"], -p["evaluations_count"], p["project_id"]))

        standings = [
            ProjectRankingItemResponse(
                project_id=p["project_id"],
                title=p["title"],
                booth_number=p["booth_number"],
                subarea_name=p["subarea_name"],
                area_name=p["area_name"],
                education_level=p["education_level"],
                evaluations_count=p["evaluations_count"],
                final_score=p["final_score"],
                rank_position=idx
            )
            for idx, p in enumerate(projs, start=1)
        ]

        result_groups.append(
            AreaLevelLeaderboardGroup(
                area_id=a_id,
                area_name=a_name,
                education_level=ed_level,
                total_projects=len(standings),
                standings=standings
            )
        )

    return result_groups


async def get_overall_leaderboard(
    db: AsyncSession,
    event_id: int
) -> OverallLeaderboardResponse:
    """
    Ranking 1: Classificação unificada de Melhor Geral da Feira (Regra BR-12).
    Classifica todos os projetos avaliados do evento pela média simples de TODOS os itens de notas.
    """
    from sqlalchemy.orm import selectinload
    from app.models.evaluation import EvaluationItem
    from app.services.evaluation_service import compute_single_evaluation_score
    from app.schemas.dashboard import (
        LevelLeaderboardGroup,
        OverallLeaderboardResponse,
        ProjectRankingItemResponse
    )

    # 1. Verificar evento
    stmt_ev = select(Event).where(Event.id == event_id, Event.deleted_at.is_(None))
    res_ev = await db.execute(stmt_ev)
    event = res_ev.scalar_one_or_none()
    if not event:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Edição do evento não encontrada.")

    # 2. Carregar todos os projetos com avaliações concluídas
    stmt_proj = (
        select(Project)
        .options(
            selectinload(Project.subarea).selectinload(Subarea.knowledge_area),
            selectinload(Project.evaluations).selectinload(Evaluation.items).selectinload(EvaluationItem.criterion)
        )
        .where(Project.event_id == event_id, Project.deleted_at.is_(None))
    )
    res_proj = await db.execute(stmt_proj)
    projects = res_proj.scalars().all()

    candidates = []
    for proj in projects:
        comp_evals = [
            ev for ev in proj.evaluations
            if ev.status == EvaluationStatus.COMPLETED and ev.deleted_at is None
        ]
        if not comp_evals:
            continue

        eval_scores = [compute_single_evaluation_score(ev.items) for ev in comp_evals]
        final_score = round(sum(eval_scores) / len(eval_scores), 2) if eval_scores else 0.0

        area_obj = proj.subarea.knowledge_area if proj.subarea else None
        a_name = area_obj.name if area_obj else "Geral"
        ed_level = proj.education_level.value if hasattr(proj, "education_level") and proj.education_level else "MEDIO"

        candidates.append({
            "project_id": proj.id,
            "title": proj.title,
            "booth_number": proj.booth_number or "",
            "subarea_name": proj.subarea.name if proj.subarea else "Geral",
            "area_name": a_name,
            "education_level": ed_level,
            "evaluations_count": len(eval_scores),
            "final_score": final_score
        })

    # Ordenar: maior nota primeiro
    candidates.sort(key=lambda p: (-p["final_score"], -p["evaluations_count"], p["project_id"]))

    standings = [
        ProjectRankingItemResponse(
            project_id=p["project_id"],
            title=p["title"],
            booth_number=p["booth_number"],
            subarea_name=p["subarea_name"],
            area_name=p["area_name"],
            education_level=p["education_level"],
            evaluations_count=p["evaluations_count"],
            final_score=p["final_score"],
            rank_position=idx
        )
        for idx, p in enumerate(candidates, start=1)
    ]

    # 3. Carregar níveis de ensino configurados para o evento e montar ranking por nível
    stmt_levels = (
        select(EducationLevel)
        .where(EducationLevel.event_id == event_id)
        .order_by(EducationLevel.id)
    )
    res_levels = await db.execute(stmt_levels)
    event_education_levels = res_levels.scalars().all()

    STANDARD_LEVEL_ORDER = ["JUNIOR", "FUNDAMENTAL", "MEDIO", "GRADUACAO", "POS_GRADUACAO"]
    LEVEL_LABELS = {
        "JUNIOR": "Ensino Fundamental I",
        "FUNDAMENTAL": "Ensino Fundamental II",
        "MEDIO": "Ensino Médio",
        "GRADUACAO": "Graduação",
        "POS_GRADUACAO": "Pós-Graduação"
    }

    if event_education_levels:
        configured_level_keys = [
            el.level_name.value if hasattr(el.level_name, "value") else str(el.level_name)
            for el in event_education_levels
        ]
    else:
        present_levels = {c["education_level"] for c in candidates}
        configured_level_keys = [lvl for lvl in STANDARD_LEVEL_ORDER if lvl in present_levels]
        if not configured_level_keys:
            configured_level_keys = list(STANDARD_LEVEL_ORDER)

    for c in candidates:
        if c["education_level"] not in configured_level_keys:
            configured_level_keys.append(c["education_level"])

    by_education_level: List[LevelLeaderboardGroup] = []
    for lvl in configured_level_keys:
        lvl_candidates = [c for c in candidates if c["education_level"] == lvl]
        lvl_candidates.sort(key=lambda p: (-p["final_score"], -p["evaluations_count"], p["project_id"]))
        lvl_standings = [
            ProjectRankingItemResponse(
                project_id=p["project_id"],
                title=p["title"],
                booth_number=p["booth_number"],
                subarea_name=p["subarea_name"],
                area_name=p["area_name"],
                education_level=p["education_level"],
                evaluations_count=p["evaluations_count"],
                final_score=p["final_score"],
                rank_position=pos
            )
            for pos, p in enumerate(lvl_candidates, start=1)
        ]
        by_education_level.append(
            LevelLeaderboardGroup(
                education_level=lvl,
                education_level_label=LEVEL_LABELS.get(lvl, lvl),
                total_projects=len(lvl_standings),
                standings=lvl_standings
            )
        )

    return OverallLeaderboardResponse(
        event_id=event.id,
        event_name=event.name,
        total_evaluated_projects=len(standings),
        standings=standings,
        by_education_level=by_education_level
    )

