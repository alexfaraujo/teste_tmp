"""Project submission, quota enforcement and formal advisor consent service (BR-04, BR-05, BR-06)."""

import math
import random
import re
import secrets
import string
import unicodedata
from datetime import datetime, timezone
from typing import Dict, List, Optional, Tuple
from fastapi import HTTPException, status
from sqlalchemy import delete, func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.models.enums import (
    EducationLevelEnum,
    ProjectMemberRole,
    ProjectStatus,
    ProjectType,
    UserRole,
)
from app.models.knowledge_area import KnowledgeArea, Subarea
from app.models.person import EventParticipant, Person
from app.models.project import Project, ProjectMember
from app.schemas.project import (
    AdvisorConsentResponse,
    ProjectBatchImport,
    ProjectBatchResponse,
    ProjectCreate,
    ProjectResponse,
    ProjectUpdate,
)
from app.services.event_service import get_event_by_id, verify_event_temporal_lock


def _normalize_name(name: str) -> str:
    """Normaliza texto para comparações insensíveis a maiúsculas, espaços e acentuação."""
    if not name:
        return ""
    nfkd = unicodedata.normalize("NFKD", name)
    no_accent = "".join([c for c in nfkd if not unicodedata.combining(c)])
    return re.sub(r"[^a-zA-Z0-9]", "", no_accent).lower()


def _parse_subarea_entry(entry: str) -> Tuple[Optional[str], str]:
    """Separa a entrada em (area_name, subarea_name) caso utilize notação hierárquica ('->', '>', ':')."""
    for sep in ("->", ">", ":"):
        if sep in entry:
            parts = entry.split(sep, 1)
            return parts[0].strip(), parts[1].strip()
    return None, entry.strip()


def validate_quotas_and_advisors(
    level: EducationLevelEnum,
    members: List[ProjectMember]
) -> None:
    """Valida as cotas máximas de estudantes e exigência estrita de orientação (BR-04, BR-05)."""
    student_roles = [ProjectMemberRole.STUDENT_LEADER, ProjectMemberRole.STUDENT_MEMBER]
    student_count = sum(1 for m in members if m.role in student_roles)
    advisor_count = sum(1 for m in members if m.role == ProjectMemberRole.ADVISOR)
    coadvisor_count = sum(1 for m in members if m.role == ProjectMemberRole.COADVISOR)

    # 1. Validação de Cotas de Estudantes (Regra BR-04)
    if student_count == 0:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="O projeto deve possuir pelo menos um estudante cadastrado."
        )

    if level == EducationLevelEnum.MEDIO and student_count > 4:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Cota excedida: Projetos do Ensino Médio permitem no máximo 4 estudantes (enviados: {student_count})."
        )
    elif level == EducationLevelEnum.FUNDAMENTAL and student_count > 5:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Cota excedida: Projetos do Ensino Fundamental II permitem no máximo 5 estudantes (enviados: {student_count})."
        )
    elif level == EducationLevelEnum.JUNIOR and student_count > 5:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Cota excedida: Projetos do Ensino Fundamental I permitem no máximo 5 estudantes (enviados: {student_count})."
        )
    elif level == EducationLevelEnum.GRADUACAO and student_count > 5:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Cota excedida: Projetos de Graduação permitem no máximo 5 estudantes (enviados: {student_count})."
        )
    elif level == EducationLevelEnum.POS_GRADUACAO and student_count > 4:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Cota excedida: Projetos de Pós-Graduação permitem no máximo 4 estudantes (enviados: {student_count})."
        )

    # 2. Validação da Equipe de Orientação (Regra BR-05)
    if advisor_count != 1:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Exigência de orientação: O projeto deve conter exatamente 1 Orientador (encontrados: {advisor_count})."
        )
    if coadvisor_count > 1:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Exigência de orientação: O projeto pode conter no máximo 1 Coorientador (encontrados: {coadvisor_count})."
        )


async def submit_project(
    db: AsyncSession,
    payload: ProjectCreate
) -> Project:
    """Submete um novo projeto científico, gerando token QR e iniciando em WAITING_CONSENT (BR-05, BR-06)."""
    event = await get_event_by_id(db, payload.event_id)
    verify_event_temporal_lock(event)

    # 1. Validar duplicidade de participantes
    person_ids = [m.person_id for m in payload.members]
    if len(person_ids) != len(set(person_ids)):
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="Um mesmo participante não pode ser selecionado em mais de um papel no mesmo projeto."
        )

    # 2. Validar existência das pessoas
    p_stmt = select(Person.id).where(Person.id.in_(person_ids), Person.deleted_at.is_(None))
    p_res = await db.execute(p_stmt)
    found_ids = set(p_res.scalars().all())
    missing_ids = set(person_ids) - found_ids
    if missing_ids:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Participante(s) com ID {list(missing_ids)} não encontrado(s)."
        )

    # 3. Converter membros para validação de cotas (BR-04, BR-05)
    temp_members = [ProjectMember(person_id=m.person_id, role=m.role) for m in payload.members]
    validate_quotas_and_advisors(payload.education_level, temp_members)

    # 4. Assegurar vínculo em EventParticipant para a edição do evento
    for pid in person_ids:
        ep_stmt = select(EventParticipant).where(
            EventParticipant.event_id == payload.event_id,
            EventParticipant.person_id == pid,
            EventParticipant.deleted_at.is_(None)
        )
        ep_res = await db.execute(ep_stmt)
        if not ep_res.scalar_one_or_none():
            db.add(EventParticipant(event_id=payload.event_id, person_id=pid))

    # Gerar token único de bancada para QR Code (BR-08)
    qrcode_token = f"FECITEL-{event.year}-{secrets.token_hex(8).upper()}"

    proj_status = ProjectStatus.HOMOLOGATED if payload.auto_homologate else ProjectStatus.WAITING_CONSENT
    advisor_consent = True if payload.auto_homologate else False
    advisor_consent_at = datetime.now(timezone.utc) if payload.auto_homologate else None

    project = Project(
        event_id=payload.event_id,
        subarea_id=payload.subarea_id,
        title=payload.title.strip(),
        project_type=payload.project_type,
        education_level=payload.education_level,
        abstract=payload.abstract.strip() if payload.abstract and payload.abstract.strip() else None,
        needs_electricity=payload.needs_electricity,
        needs_table=payload.needs_table,
        booth_number=payload.booth_number.strip() if payload.booth_number and payload.booth_number.strip() else None,
        qrcode_token=qrcode_token,
        status=proj_status,
        advisor_consent=advisor_consent,
        advisor_consent_at=advisor_consent_at
    )
    db.add(project)
    await db.flush()

    # Adicionar os membros ao projeto
    for member_input in payload.members:
        member = ProjectMember(
            project_id=project.id,
            person_id=member_input.person_id,
            role=member_input.role
        )
        db.add(member)

    await db.commit()
    return await get_project_by_id(db, project.id)


async def get_project_by_id(db: AsyncSession, project_id: int) -> Project:
    """Recupera dados completos do projeto com membros associados."""
    stmt = (
        select(Project)
        .where(Project.id == project_id, Project.deleted_at.is_(None))
        .options(
            selectinload(Project.subarea).selectinload(Subarea.knowledge_area),
            selectinload(Project.members).selectinload(ProjectMember.person).selectinload(Person.event_participations)
        )
    )
    res = await db.execute(stmt)
    project = res.scalar_one_or_none()
    if not project:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Projeto não encontrado.")
    return project


async def grant_advisor_consent(
    db: AsyncSession,
    project_id: int,
    advisor: Person
) -> AdvisorConsentResponse:
    """
    Concede a anuência digital formal do orientador (Regra BR-05).
    Apenas o orientador formalmente vinculado ao trabalho pode conceder esta autorização.
    """
    project = await get_project_by_id(db, project_id)

    # Verificar se o orientador pertence ao projeto no papel de ADVISOR
    is_designated_advisor = any(
        m.person_id == advisor.id and m.role == ProjectMemberRole.ADVISOR
        for m in project.members
    )

    if not is_designated_advisor:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Acesso negado: apenas o Orientador titular deste projeto pode conceder a anuência formal."
        )

    now = datetime.now(timezone.utc)
    project.advisor_consent = True
    project.advisor_consent_at = now
    # Após anuência, avança para SUBMITTED e fica pronto para homologação da comissão
    project.status = ProjectStatus.SUBMITTED

    await db.commit()
    await db.refresh(project)

    return AdvisorConsentResponse(
        project_id=project.id,
        advisor_id=advisor.id,
        advisor_name=advisor.name,
        advisor_consent=True,
        advisor_consent_at=now,
        new_status=project.status,
        message="Anuência digital formal concedida com sucesso. O projeto está liberado para homologação."
    )


async def homologate_project(
    db: AsyncSession,
    project_id: int,
    homologated: bool,
    booth_number: Optional[str] = None,
    rejection_reason: Optional[str] = None
) -> Project:
    """
    Homologa ou rejeita o projeto (Regra BR-06).
    Exige que o projeto tenha obtido a anuência digital formal do orientador (advisor_consent == True).
    """
    project = await get_project_by_id(db, project_id)

    if not project.advisor_consent:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Projeto não pode ser homologado sem a anuência digital formal do orientador."
        )

    if homologated:
        project.status = ProjectStatus.HOMOLOGATED
        project.rejection_reason = None
        if booth_number:
            project.booth_number = booth_number.strip()
    else:
        project.status = ProjectStatus.REJECTED
        if rejection_reason:
            project.rejection_reason = rejection_reason.strip()

    await db.commit()
    return await get_project_by_id(db, project.id)


async def assign_booth_number(
    db: AsyncSession,
    project_id: int,
    booth_number: str
) -> Project:
    """Atribui ou altera o número de estande/bancada de apresentação do trabalho."""
    project = await get_project_by_id(db, project_id)
    project.booth_number = booth_number.strip()
    await db.commit()
    return await get_project_by_id(db, project.id)


async def update_project(
    db: AsyncSession,
    project_id: int,
    payload: ProjectUpdate
) -> Project:
    """Atualiza dados cadastrais e equipe de um projeto existente."""
    project = await get_project_by_id(db, project_id)

    if payload.title is not None and payload.title.strip():
        project.title = payload.title.strip()
    if payload.project_type is not None:
        project.project_type = payload.project_type
    if payload.education_level is not None:
        project.education_level = payload.education_level
    if payload.abstract is not None:
        project.abstract = payload.abstract.strip() if payload.abstract.strip() else None
    if payload.subarea_id is not None:
        sub_stmt = select(Subarea).where(Subarea.id == payload.subarea_id, Subarea.deleted_at.is_(None))
        sub_res = await db.execute(sub_stmt)
        if not sub_res.scalar_one_or_none():
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Subárea temática não encontrada.")
        project.subarea_id = payload.subarea_id
    if payload.booth_number is not None:
        project.booth_number = payload.booth_number.strip() if payload.booth_number.strip() else None
    if payload.needs_electricity is not None:
        project.needs_electricity = payload.needs_electricity
    if payload.needs_table is not None:
        project.needs_table = payload.needs_table

    if payload.members is not None:
        member_person_ids = [m.person_id for m in payload.members]
        if len(member_person_ids) != len(set(member_person_ids)):
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail="Um mesmo participante não pode ser selecionado em mais de um papel no mesmo projeto."
            )

        p_stmt = select(Person.id).where(Person.id.in_(member_person_ids), Person.deleted_at.is_(None))
        p_res = await db.execute(p_stmt)
        found_ids = set(p_res.scalars().all())
        missing_ids = set(member_person_ids) - found_ids
        if missing_ids:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Participante(s) com ID {list(missing_ids)} não encontrado(s)."
            )

        target_level = payload.education_level or project.education_level
        temp_members = [ProjectMember(person_id=m.person_id, role=m.role) for m in payload.members]
        validate_quotas_and_advisors(target_level, temp_members)

        for pid in member_person_ids:
            ep_stmt = select(EventParticipant).where(
                EventParticipant.event_id == project.event_id,
                EventParticipant.person_id == pid,
                EventParticipant.deleted_at.is_(None)
            )
            ep_res = await db.execute(ep_stmt)
            if not ep_res.scalar_one_or_none():
                db.add(EventParticipant(event_id=project.event_id, person_id=pid))

        # Atualizar membros via relacionamento com cascade="all, delete-orphan"
        project.members.clear()
        for m_input in payload.members:
            project.members.append(
                ProjectMember(
                    person_id=m_input.person_id,
                    role=m_input.role
                )
            )

    await db.commit()
    return await get_project_by_id(db, project_id)


async def list_projects(
    db: AsyncSession,
    event_id: int,
    status: Optional[ProjectStatus] = None,
    education_level: Optional[EducationLevelEnum] = None,
    subarea_id: Optional[int] = None,
    search: Optional[str] = None
) -> List[Project]:
    """Lista todos os projetos ativos de um evento com suporte a filtros e busca (Multi-Evento BR-01)."""
    stmt = (
        select(Project)
        .where(Project.event_id == event_id, Project.deleted_at.is_(None))
        .options(
            selectinload(Project.subarea).selectinload(Subarea.knowledge_area),
            selectinload(Project.members).selectinload(ProjectMember.person).selectinload(Person.event_participations)
        )
    )
    if status:
        stmt = stmt.where(Project.status == status)
    if education_level:
        stmt = stmt.where(Project.education_level == education_level)
    if subarea_id:
        stmt = stmt.where(Project.subarea_id == subarea_id)
    if search and search.strip():
        term = f"%{search.strip()}%"
        stmt = stmt.where(
            or_(
                Project.title.ilike(term),
                Project.qrcode_token.ilike(term),
                Project.booth_number.ilike(term)
            )
        )
    stmt = stmt.order_by(Project.id.desc())
    res = await db.execute(stmt)
    return list(res.scalars().all())


async def list_projects_paginated(
    db: AsyncSession,
    event_id: int,
    page: int = 1,
    limit: int = 15,
    status: Optional[ProjectStatus] = None,
    education_level: Optional[EducationLevelEnum] = None,
    subarea_id: Optional[int] = None,
    search: Optional[str] = None
) -> dict:
    """Lista projetos de um evento com paginação real no banco (Regra BR-18: 15 itens por página)."""
    base_filter = [Project.event_id == event_id, Project.deleted_at.is_(None)]
    if status:
        base_filter.append(Project.status == status)
    if education_level:
        base_filter.append(Project.education_level == education_level)
    if subarea_id:
        base_filter.append(Project.subarea_id == subarea_id)
    if search and search.strip():
        term = f"%{search.strip()}%"
        base_filter.append(
            or_(
                Project.title.ilike(term),
                Project.qrcode_token.ilike(term),
                Project.booth_number.ilike(term)
            )
        )

    # 1. Total de registros filtrados
    count_stmt = select(func.count(Project.id)).where(*base_filter)
    total_res = await db.execute(count_stmt)
    total = total_res.scalar_one()

    # 2. Registros da página
    offset = (page - 1) * limit
    stmt = (
        select(Project)
        .where(*base_filter)
        .options(
            selectinload(Project.subarea).selectinload(Subarea.knowledge_area),
            selectinload(Project.members).selectinload(ProjectMember.person)
        )
        .order_by(Project.id.desc())
        .offset(offset)
        .limit(limit)
    )
    res = await db.execute(stmt)
    items = list(res.scalars().all())

    total_pages = math.ceil(total / limit) if total > 0 else 1

    return {
        "items": items,
        "total": total,
        "page": page,
        "limit": limit,
        "total_pages": total_pages
    }


async def import_projects_batch(
    db: AsyncSession,
    event_id: int,
    payload: ProjectBatchImport
) -> ProjectBatchResponse:
    """
    Sincroniza / cadastra trabalhos científicos em lote no evento (Upsert Atômico).
    - Localiza ou cadastra participantes (estudantes e orientadores) em people e event_participants.
    - Resolve subáreas da edição ativa do evento.
    - Se o trabalho já existir pelo título (case-insensitive), atualiza dados e integrantes.
    - Se for novo, gera QR Code de bancada e insere.
    - Homologa e concede anuência formal se solicitado (auto_homologate).
    """
    event = await get_event_by_id(db, event_id)
    verify_event_temporal_lock(event)

    # 1. Carregar subáreas do evento juntamente com o nome da Grande Área mãe
    subareas_stmt = (
        select(Subarea, KnowledgeArea.name.label("area_name"))
        .join(KnowledgeArea, Subarea.area_id == KnowledgeArea.id)
        .where(
            KnowledgeArea.event_id == event_id,
            KnowledgeArea.deleted_at.is_(None),
            Subarea.deleted_at.is_(None)
        )
    )
    subareas_res = await db.execute(subareas_stmt)
    subareas_rows = subareas_res.all()
    if not subareas_rows:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="A edição ativa do evento ainda não possui Grandes Áreas e Subáreas cadastradas. Configure as áreas temáticas antes de importar os trabalhos."
        )

    # Mapa composto: (norm(area_name), norm(subarea_name)) -> Subarea
    composite_subarea_map: Dict[Tuple[str, str], Subarea] = {}
    # Mapa simples: norm(subarea_name) -> list of (Subarea, real_area_name)
    simple_subarea_map: Dict[str, List[Tuple[Subarea, str]]] = {}

    for sub_obj, area_name in subareas_rows:
        area_norm = _normalize_name(area_name)
        sub_norm = _normalize_name(sub_obj.name)
        composite_subarea_map[(area_norm, sub_norm)] = sub_obj
        if sub_norm not in simple_subarea_map:
            simple_subarea_map[sub_norm] = []
        simple_subarea_map[sub_norm].append((sub_obj, area_name))

    # 2. Carregar projetos já existentes no evento (para suporte a Upsert)
    existing_stmt = (
        select(Project)
        .where(Project.event_id == event_id, Project.deleted_at.is_(None))
        .options(
            selectinload(Project.subarea).selectinload(Subarea.knowledge_area),
            selectinload(Project.members).selectinload(ProjectMember.person)
        )
    )
    existing_res = await db.execute(existing_stmt)
    existing_projects = existing_res.scalars().all()
    existing_map = {p.title.strip().lower(): p for p in existing_projects}

    # 2.1 Pré-carregamento em Lote: buscar pessoas e participantes existentes do lote (Eliminação N+1)
    all_emails = {
        m.email.strip().lower()
        for item in payload.items
        for m in item.members
        if m.email and m.email.strip()
    }
    all_cpfs = {
        m.cpf.strip()
        for item in payload.items
        for m in item.members
        if m.cpf and m.cpf.strip()
    }

    person_by_email: Dict[str, Person] = {}
    person_by_cpf: Dict[str, Person] = {}

    conditions = []
    if all_emails:
        conditions.append(Person.email.in_(list(all_emails)))
    if all_cpfs:
        conditions.append(Person.cpf.in_(list(all_cpfs)))

    if conditions:
        p_batch_stmt = select(Person).where(or_(*conditions), Person.deleted_at.is_(None))
        p_batch_res = await db.execute(p_batch_stmt)
        for p in p_batch_res.scalars().all():
            if p.email:
                person_by_email[p.email.lower()] = p
            if p.cpf:
                person_by_cpf[p.cpf] = p

    # Carregar em lote os EventParticipant já existentes para essas pessoas no evento
    loaded_person_ids = {p.id for p in person_by_email.values()} | {p.id for p in person_by_cpf.values()}
    ep_by_person_id: Dict[int, EventParticipant] = {}
    if loaded_person_ids:
        ep_batch_stmt = select(EventParticipant).where(
            EventParticipant.event_id == event_id,
            EventParticipant.person_id.in_(list(loaded_person_ids)),
            EventParticipant.deleted_at.is_(None)
        )
        ep_batch_res = await db.execute(ep_batch_stmt)
        for ep in ep_batch_res.scalars().all():
            ep_by_person_id[ep.person_id] = ep

    created_projects = 0
    updated_projects = 0
    participants_created = 0
    affected_projects: List[Project] = []
    now = datetime.now(timezone.utc)

    for item in payload.items:
        title_clean = item.title.strip()
        if not title_clean:
            continue

        # Resolução de subárea com suporte a notação hierárquica 'Área -> Subárea' e desambiguação
        area_part, sub_part = _parse_subarea_entry(item.subarea_name)
        sub_norm = _normalize_name(sub_part)
        matched_subarea: Optional[Subarea] = None

        if area_part:
            area_norm = _normalize_name(area_part)
            comp_key = (area_norm, sub_norm)
            if comp_key in composite_subarea_map:
                matched_subarea = composite_subarea_map[comp_key]
            else:
                # Busca parcial de área caso haja ligeira variação no nome da área informada
                for (a_n, s_n), s_obj in composite_subarea_map.items():
                    if (area_norm in a_n or a_n in area_norm) and (sub_norm == s_n):
                        matched_subarea = s_obj
                        break
        else:
            # Busca simples por nome de subárea
            if sub_norm in simple_subarea_map:
                candidates = simple_subarea_map[sub_norm]
                if len(candidates) == 1:
                    matched_subarea = candidates[0][0]
                elif len(candidates) > 1:
                    areas_str = ", ".join(f"'{c[1]}'" for c in candidates)
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail=(
                            f"A subárea '{item.subarea_name}' informada para o trabalho '{title_clean}' é ambígua, "
                            f"pois pertence a mais de uma grande área: {areas_str}. "
                            f"Por favor, especifique no formato 'Área -> Subárea'."
                        ),
                    )
            else:
                # Tentativa de busca parcial caso seja única
                candidates_partial = [
                    s_obj for (a_n, s_n), s_obj in composite_subarea_map.items()
                    if sub_norm in s_n or s_norm in sub_norm
                ]
                if len(candidates_partial) == 1:
                    matched_subarea = candidates_partial[0]

        if not matched_subarea:
            if not item.subarea_name.strip() and subareas_rows:
                matched_subarea = subareas_rows[0][0]
            else:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"A subárea '{item.subarea_name}' informada para o trabalho '{title_clean}' não foi encontrada na feira ativa."
                )

        subarea = matched_subarea

        # Determinar status e anuência
        is_homologated = item.auto_homologate if item.auto_homologate is not None else payload.auto_homologate
        initial_status = ProjectStatus.HOMOLOGATED if is_homologated else ProjectStatus.WAITING_CONSENT
        has_consent = True if is_homologated else False
        consent_time = now if is_homologated else None

        key = title_clean.lower()
        if key in existing_map:
            project = existing_map[key]
            project.title = title_clean
            project.subarea_id = subarea.id
            project.project_type = item.project_type
            project.education_level = item.education_level
            project.needs_electricity = item.needs_electricity
            project.needs_table = item.needs_table
            if item.abstract is not None:
                project.abstract = item.abstract
            if item.booth_number is not None:
                project.booth_number = item.booth_number.strip()
            if is_homologated and project.status in (ProjectStatus.DRAFT, ProjectStatus.WAITING_CONSENT, ProjectStatus.SUBMITTED):
                project.status = ProjectStatus.HOMOLOGATED
                project.advisor_consent = True
                project.advisor_consent_at = now
            updated_projects += 1
        else:
            qrcode_token = f"EASYEVENT-{event.year}-{secrets.token_hex(8).upper()}"
            project = Project(
                event_id=event_id,
                subarea_id=subarea.id,
                title=title_clean,
                project_type=item.project_type,
                education_level=item.education_level,
                abstract=item.abstract,
                booth_number=item.booth_number.strip() if item.booth_number else None,
                needs_electricity=item.needs_electricity,
                needs_table=item.needs_table,
                qrcode_token=qrcode_token,
                status=initial_status,
                advisor_consent=has_consent,
                advisor_consent_at=consent_time
            )
            db.add(project)
            await db.flush()
            existing_map[key] = project
            created_projects += 1

        # Sincronizar membros: se o projeto já existia, remover vínculos anteriores diretamente
        await db.execute(
            delete(ProjectMember).where(ProjectMember.project_id == project.id)
        )
        await db.flush()

        for m_input in item.members:
            m_email = m_input.email.strip().lower()
            m_name = m_input.name.strip()
            m_cpf = m_input.cpf.strip() if m_input.cpf else None
            if not m_email or not m_name:
                continue

            m_affiliation = m_input.affiliation.strip() if m_input.affiliation else None

            # Localizar Person nos mapas em memória (prioritariamente por CPF, depois por e-mail)
            person = None
            if m_cpf and m_cpf in person_by_cpf:
                person = person_by_cpf[m_cpf]
            if not person and m_email in person_by_email:
                person = person_by_email[m_email]

            if not person:
                barcode = f"BC-{''.join(random.choices(string.ascii_uppercase + string.digits, k=5))}"
                user_role = (
                    UserRole.ADVISOR
                    if m_input.role in (ProjectMemberRole.ADVISOR, ProjectMemberRole.COADVISOR)
                    else UserRole.STUDENT
                )
                person = Person(
                    name=m_name,
                    email=m_email,
                    cpf=m_cpf,
                    affiliation=m_affiliation,
                    role=user_role,
                    barcode=barcode
                )
                db.add(person)
                await db.flush()
                participants_created += 1
                person_by_email[m_email] = person
                if m_cpf:
                    person_by_cpf[m_cpf] = person
            else:
                updated_person = False
                if m_cpf and person.cpf != m_cpf:
                    person.cpf = m_cpf
                    person_by_cpf[m_cpf] = person
                    updated_person = True
                if m_affiliation and person.affiliation != m_affiliation:
                    person.affiliation = m_affiliation
                    updated_person = True
                if updated_person:
                    db.add(person)
                    await db.flush()

            # Normalização e validação de tamanho de camiseta
            VALID_SIZES = {"PP", "P", "M", "G", "GG", "XG"}
            raw_size = (m_input.tshirt_size or "").strip().upper()
            tshirt_size = raw_size if raw_size in VALID_SIZES else "M"

            # Assegurar participação da pessoa na feira (EventParticipant) via mapa em memória
            ep = ep_by_person_id.get(person.id)
            if not ep:
                ep = EventParticipant(
                    event_id=event_id,
                    person_id=person.id,
                    tshirt_size=tshirt_size
                )
                db.add(ep)
                await db.flush()
                ep_by_person_id[person.id] = ep
            else:
                if raw_size in VALID_SIZES:
                    ep.tshirt_size = tshirt_size
                    db.add(ep)
                    await db.flush()

            # Adicionar integrante no projeto
            pm = ProjectMember(
                project_id=project.id,
                person_id=person.id,
                role=m_input.role
            )
            db.add(pm)

        affected_projects.append(project)

    await db.commit()

    # Recarregar projetos em uma única consulta consolidada com relacionamentos (Fim do N+1)
    result_items: List[Project] = []
    if affected_projects:
        affected_ids = [p.id for p in affected_projects]
        stmt_reload = (
            select(Project)
            .where(Project.id.in_(affected_ids), Project.deleted_at.is_(None))
            .options(
                selectinload(Project.subarea).selectinload(Subarea.knowledge_area),
                selectinload(Project.members).selectinload(ProjectMember.person).selectinload(Person.event_participations)
            )
        )
        res_reload = await db.execute(stmt_reload)
        reloaded_map = {p.id: p for p in res_reload.scalars().all()}
        result_items = [reloaded_map[pid] for pid in affected_ids if pid in reloaded_map]

    return ProjectBatchResponse(
        total=len(result_items),
        created_count=created_projects,
        updated_count=updated_projects,
        participants_created_count=participants_created,
        items=result_items
    )


