"""Service para geração de Adesivos/Placas com QR Code para Bancadas de Projetos (PDF).

Permite a impressão em alta resolução (ReportLab) com guias de corte:
- Modelo A5 (2 por folha A4): Grade 1x2 em folha A4 retrato, QR Code gigante (~180pt).
- Modelo A6 (4 por folha A4): Grade 2x2 em folha A4 paisagem, QR Code amplo (~140pt).

Regras de Negócio:
- Sem número de estande (apenas ID do Trabalho em destaque para maximizar o QR Code).
- Sem informações redundantes do banner (título, autores, escola, nível de ensino omitidos).
- Badges de Tipo de Trabalho (Científico/Tecnológico) e Infraestrutura (Tomada e Mesa).
- QR Code 2D ampliado com código textual do token e instrução de avaliação.
"""

import io
import os
from typing import Any, Dict, List, Optional, Tuple

from fastapi import HTTPException, status
from reportlab.graphics import renderPDF
from reportlab.graphics.barcode.qr import QrCodeWidget
from reportlab.graphics.shapes import Drawing
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, landscape
from reportlab.pdfgen import canvas
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.core.config import settings
from app.models.enums import ProjectStatus, ProjectType
from app.models.event import Event
from app.models.knowledge_area import KnowledgeArea, Subarea
from app.models.project import Project


def _resolve_local_logo_path(logo_url: Optional[str]) -> Optional[str]:
    """Tenta localizar o logotipo do evento no disco local."""
    if not logo_url:
        return None
    if "/static/uploads/" in logo_url:
        rel = logo_url.split("/static/uploads/")[-1].lstrip("/")
        candidate = os.path.join(settings.UPLOAD_DIR, rel)
        if os.path.isfile(candidate):
            return candidate
    if os.path.isfile(logo_url):
        return logo_url
    basename = os.path.basename(logo_url)
    candidate_logo_dir = os.path.join(settings.UPLOAD_DIR, "logos", basename)
    if os.path.isfile(candidate_logo_dir):
        return candidate_logo_dir
    return None


def _wrap_text_lines(
    c: canvas.Canvas,
    text_str: str,
    max_w: float,
    font_name: str,
    font_size: float,
    max_lines: int = 2,
) -> List[str]:
    """Quebra texto em linhas respeitando a largura máxima."""
    words = text_str.strip().split()
    if not words:
        return [""]

    lines: List[str] = []
    curr = words[0]
    for w in words[1:]:
        test = f"{curr} {w}"
        if c.stringWidth(test, font_name, font_size) <= max_w:
            curr = test
        else:
            lines.append(curr)
            curr = w
            if len(lines) >= max_lines:
                break
    if len(lines) < max_lines:
        lines.append(curr)

    # Se a última linha ainda passar da largura, trunca com reticências
    if lines:
        last = lines[-1]
        while c.stringWidth(last + "...", font_name, font_size) > max_w and len(last) > 3:
            last = last[:-1].strip()
        if last != lines[-1]:
            lines[-1] = last + "..."

    return lines


def _draw_badge_pill(
    c: canvas.Canvas,
    x: float,
    y: float,
    label: str,
    bg_color: colors.Color,
    border_color: colors.Color,
    text_color: colors.Color,
    font_size: float = 8.0,
    padding_x: float = 6.0,
    height: float = 18.0,
) -> float:
    """Desenha uma pill/badge arredondada e retorna a largura total ocupada."""
    c.setFont("Helvetica-Bold", font_size)
    text_w = c.stringWidth(label, "Helvetica-Bold", font_size)
    total_w = text_w + (padding_x * 2)

    c.saveState()
    c.setFillColor(bg_color)
    c.setStrokeColor(border_color)
    c.setLineWidth(0.8)
    c.roundRect(x, y, total_w, height, height / 2.0, fill=1, stroke=1)

    c.setFillColor(text_color)
    # Alinhamento vertical centralizado
    text_y = y + (height - font_size) / 2.0 + 0.5
    c.drawString(x + padding_x, text_y, label)
    c.restoreState()

    return total_w


def _draw_qrcode(
    c: canvas.Canvas,
    token: str,
    x: float,
    y: float,
    size: float,
) -> None:
    """Renderiza o QR Code vetorial com ReportLab na posição (x, y)."""
    try:
        qr = QrCodeWidget(token)
        b = qr.getBounds()
        w = b[2] - b[0]
        h = b[3] - b[1]
        if w <= 0 or h <= 0:
            w, h = 1, 1
        d = Drawing(size, size, transform=[size / w, 0, 0, size / h, 0, 0])
        d.add(qr)
        renderPDF.draw(d, c, x, y)
    except Exception as exc:
        # Fallback de erro se falhar
        c.saveState()
        c.setStrokeColor(colors.HexColor("#EF4444"))
        c.rect(x, y, size, size, fill=0, stroke=1)
        c.setFont("Helvetica", 8)
        c.setFillColor(colors.HexColor("#EF4444"))
        c.drawCentredString(x + size / 2, y + size / 2, "Erro QR Code")
        c.restoreState()


def _format_booth_display(project_data: Dict[str, Any]) -> Tuple[str, str]:
    """Retorna (rótulo, valor_destaque) para a caixa de identificação do estande/trabalho."""
    booth = str(project_data.get("booth_number") or "").strip()
    if booth:
        b_upper = booth.upper()
        if any(b_upper.startswith(p) for p in ["ESTANDE", "BANCADA", "EST."]):
            return "NÚMERO / CÓDIGO DO ESTANDE", b_upper
        return "NÚMERO / CÓDIGO DO ESTANDE", f"ESTANDE {b_upper}"

    pid = project_data.get("id")
    if pid:
        return "IDENTIFICADOR DO TRABALHO", f"TRABALHO #{pid}"
    return "NÚMERO / CÓDIGO DO ESTANDE", "ESTANDE PENDENTE"


def _draw_booth_sticker_a5(
    c: canvas.Canvas,
    x: float,
    y: float,
    w: float,
    h: float,
    project_data: Dict[str, Any],
    event_info: Dict[str, Any],
) -> None:
    """Desenha 1 adesivo de bancada no formato A5 (metade de folha A4).

    Dimensões aproximadas: w ~ 555pt, h ~ 392pt.
    """
    c.saveState()

    # 1. Cartão externo com cantos arredondados e sombra sutil
    c.setFillColor(colors.HexColor("#FFFFFF"))
    c.setStrokeColor(colors.HexColor("#CBD5E1"))
    c.setLineWidth(1.2)
    c.roundRect(x, y, w, h, 10, fill=1, stroke=1)

    # 2. Barra de destaque no topo (accent bar)
    c.setFillColor(colors.HexColor("#2563EB"))  # Azul vibrante
    c.roundRect(x + 1, y + h - 8, w - 2, 7, 3, fill=1, stroke=0)

    pad = 20.0
    inner_w = w - (pad * 2)
    inner_h = h - (pad * 2)

    # 3. Cabeçalho do Card
    head_y = y + h - 28.0
    evt_name = (event_info.get("name") or "FECITEL").upper()
    evt_year = str(event_info.get("year") or "")
    if evt_year and evt_year in evt_name:
        header_title = f"{evt_name} • IDENTIFICAÇÃO DE BANCADA"
    else:
        header_title = f"{evt_name} {evt_year} • IDENTIFICAÇÃO DE BANCADA".strip()

    c.setFont("Helvetica-Bold", 10)
    c.setFillColor(colors.HexColor("#475569"))
    c.drawString(x + pad, head_y, header_title)

    # Linha divisória sutil abaixo do cabeçalho
    c.setStrokeColor(colors.HexColor("#E2E8F0"))
    c.setLineWidth(0.8)
    c.line(x + pad, head_y - 10, x + w - pad, head_y - 10)

    # Divisão em duas colunas:
    # Coluna Esquerda: Informações do Trabalho (w ~ 290pt)
    # Coluna Direita: QR Code Gigante (w ~ 225pt)
    left_x = x + pad
    left_w = inner_w - 235.0
    right_x = x + w - pad - 215.0

    content_top_y = head_y - 24.0

    # 4. DESTAQUE DO ESTANDE / TRABALHO
    id_box_h = 60.0
    c.setFillColor(colors.HexColor("#F8FAFC"))
    c.setStrokeColor(colors.HexColor("#E2E8F0"))
    c.roundRect(left_x, content_top_y - id_box_h, left_w, id_box_h, 8, fill=1, stroke=1)

    booth_label, booth_display = _format_booth_display(project_data)
    c.setFont("Helvetica-Bold", 9)
    c.setFillColor(colors.HexColor("#64748B"))
    c.drawString(left_x + 14, content_top_y - 18, booth_label)

    font_size_a5 = 26.0
    while font_size_a5 > 14.0 and c.stringWidth(booth_display, "Helvetica-Bold", font_size_a5) > (left_w - 28.0):
        font_size_a5 -= 2.0
    c.setFont("Helvetica-Bold", font_size_a5)
    c.setFillColor(colors.HexColor("#1E3A8A"))  # Azul marinho elegante
    c.drawString(left_x + 14, content_top_y - 48, booth_display)

    # 5. Área e Subárea do Conhecimento
    area_top_y = content_top_y - id_box_h - 22.0
    c.setFont("Helvetica-Bold", 8)
    c.setFillColor(colors.HexColor("#94A3B8"))
    c.drawString(left_x, area_top_y, "GRANDE ÁREA DO CONHECIMENTO")

    area_name = (project_data.get("area_name") or "ÁREA NÃO DEFINIDA").upper()
    c.setFont("Helvetica-Bold", 14)
    c.setFillColor(colors.HexColor("#0F172A"))
    area_lines = _wrap_text_lines(c, area_name, left_w, "Helvetica-Bold", 14, max_lines=2)
    curr_area_y = area_top_y - 16.0
    for l in area_lines:
        c.drawString(left_x, curr_area_y, l)
        curr_area_y -= 18.0

    # Subárea
    subarea_name = project_data.get("subarea_name")
    if subarea_name:
        curr_area_y -= 4.0
        c.setFont("Helvetica-Bold", 8)
        c.setFillColor(colors.HexColor("#94A3B8"))
        c.drawString(left_x, curr_area_y, "SUBÁREA CIENTÍFICA / TEMÁTICA")
        curr_area_y -= 14.0

        c.setFont("Helvetica", 11)
        c.setFillColor(colors.HexColor("#334155"))
        sub_lines = _wrap_text_lines(c, subarea_name, left_w, "Helvetica", 11, max_lines=2)
        for l in sub_lines:
            c.drawString(left_x, curr_area_y, l)
            curr_area_y -= 14.0

    # 6. Badges de Tipo e Infraestrutura
    badges_y = y + pad + 24.0
    curr_bx = left_x

    # Badge de Tipo
    ptype = project_data.get("project_type")
    ptype_label = "TECNOLÓGICO" if ptype == ProjectType.TECHNOLOGICAL else "CIENTÍFICO"
    bw1 = _draw_badge_pill(
        c,
        curr_bx,
        badges_y,
        f"TIPO: {ptype_label}",
        bg_color=colors.HexColor("#EFF6FF"),
        border_color=colors.HexColor("#BFDBFE"),
        text_color=colors.HexColor("#1D4ED8"),
        font_size=8.5,
        height=20.0,
    )
    curr_bx += bw1 + 8.0

    # Badge de Tomada
    needs_elec = bool(project_data.get("needs_electricity"))
    elec_label = "TOMADA: SIM" if needs_elec else "TOMADA: NÃO"
    elec_bg = colors.HexColor("#FEF3C7") if needs_elec else colors.HexColor("#F1F5F9")
    elec_border = colors.HexColor("#FDE68A") if needs_elec else colors.HexColor("#E2E8F0")
    elec_text = colors.HexColor("#B45309") if needs_elec else colors.HexColor("#64748B")
    bw2 = _draw_badge_pill(
        c,
        curr_bx,
        badges_y,
        elec_label,
        bg_color=elec_bg,
        border_color=elec_border,
        text_color=elec_text,
        font_size=8.5,
        height=20.0,
    )
    curr_bx += bw2 + 8.0

    # Badge de Mesa
    needs_tab = bool(project_data.get("needs_table"))
    tab_label = "MESA: SIM" if needs_tab else "MESA: NÃO"
    tab_bg = colors.HexColor("#EEF2FF") if needs_tab else colors.HexColor("#F1F5F9")
    tab_border = colors.HexColor("#C7D2FE") if needs_tab else colors.HexColor("#E2E8F0")
    tab_text = colors.HexColor("#4338CA") if needs_tab else colors.HexColor("#64748B")
    _draw_badge_pill(
        c,
        curr_bx,
        badges_y,
        tab_label,
        bg_color=tab_bg,
        border_color=tab_border,
        text_color=tab_text,
        font_size=8.5,
        height=20.0,
    )

    # Rodapé sutil da coluna esquerda
    c.setFont("Helvetica", 7.5)
    c.setFillColor(colors.HexColor("#94A3B8"))
    c.drawString(left_x, y + pad + 6.0, "Mantenha este adesivo visível e afixado na bancada durante todo o evento.")

    # 7. COLUNA DIREITA: CONTAINER DO QR CODE GIGANTE
    qr_container_w = 215.0
    qr_container_h = inner_h - 10.0
    qr_container_y = y + pad + 6.0

    # Moldura do QR Code
    c.setFillColor(colors.HexColor("#F8FAFC"))
    c.setStrokeColor(colors.HexColor("#E2E8F0"))
    c.setLineWidth(1.0)
    c.roundRect(right_x, qr_container_y, qr_container_w, qr_container_h, 10, fill=1, stroke=1)

    # Topo do container do QR Code
    c.setFont("Helvetica-Bold", 10)
    c.setFillColor(colors.HexColor("#1E293B"))
    c.drawCentredString(right_x + (qr_container_w / 2.0), qr_container_y + qr_container_h - 22.0, "AVALIAÇÃO DO TRABALHO")

    c.setFont("Helvetica", 8)
    c.setFillColor(colors.HexColor("#64748B"))
    c.drawCentredString(right_x + (qr_container_w / 2.0), qr_container_y + qr_container_h - 35.0, "Aponte a câmera do celular")

    # QR Code Gigante (~180pt)
    qr_size = 180.0
    qr_x = right_x + (qr_container_w - qr_size) / 2.0
    qr_y = qr_container_y + 48.0

    # Fundo branco puro atrás do QR Code para leitura óptica perfeita
    c.setFillColor(colors.HexColor("#FFFFFF"))
    c.setStrokeColor(colors.HexColor("#CBD5E1"))
    c.setLineWidth(0.6)
    c.roundRect(qr_x - 6, qr_y - 6, qr_size + 12, qr_size + 12, 6, fill=1, stroke=1)

    token = project_data.get("qrcode_token") or f"PRJ-{project_data.get('id', 0):05d}"
    _draw_qrcode(c, token, qr_x, qr_y, qr_size)

    # Código Textual do Token abaixo do QR
    c.setFont("Helvetica-Bold", 9)
    c.setFillColor(colors.HexColor("#0F172A"))
    c.drawCentredString(right_x + (qr_container_w / 2.0), qr_container_y + 26.0, f"CÓDIGO: {token}")

    c.setFont("Helvetica", 7.5)
    c.setFillColor(colors.HexColor("#94A3B8"))
    c.drawCentredString(right_x + (qr_container_w / 2.0), qr_container_y + 12.0, "Exclusivo para avaliadores cadastrados")

    c.restoreState()


def _draw_booth_sticker_a6(
    c: canvas.Canvas,
    x: float,
    y: float,
    w: float,
    h: float,
    project_data: Dict[str, Any],
    event_info: Dict[str, Any],
) -> None:
    """Desenha 1 adesivo de bancada no formato A6 (1/4 de folha A4 paisagem).

    Dimensões aproximadas: w ~ 394pt, h ~ 271pt.
    """
    c.saveState()

    # 1. Cartão com cantos arredondados
    c.setFillColor(colors.HexColor("#FFFFFF"))
    c.setStrokeColor(colors.HexColor("#CBD5E1"))
    c.setLineWidth(1.0)
    c.roundRect(x, y, w, h, 8, fill=1, stroke=1)

    # 2. Barra de destaque no topo
    c.setFillColor(colors.HexColor("#2563EB"))
    c.roundRect(x + 1, y + h - 6, w - 2, 5, 2, fill=1, stroke=0)

    pad = 12.0
    inner_w = w - (pad * 2)
    inner_h = h - (pad * 2)

    # 3. Cabeçalho Compacto
    head_y = y + h - 20.0
    evt_name = (event_info.get("name") or "FECITEL").upper()
    evt_year = str(event_info.get("year") or "")
    if evt_year and evt_year in evt_name:
        header_title = f"{evt_name} • BANCADA"
    else:
        header_title = f"{evt_name} {evt_year} • BANCADA".strip()
    c.setFont("Helvetica-Bold", 8.5)
    c.setFillColor(colors.HexColor("#475569"))
    c.drawString(x + pad, head_y, header_title)

    # Linha divisória
    c.setStrokeColor(colors.HexColor("#E2E8F0"))
    c.setLineWidth(0.6)
    c.line(x + pad, head_y - 6, x + w - pad, head_y - 6)

    # Divisão em duas colunas:
    # Coluna Esquerda: Dados do trabalho (w ~ 210pt)
    # Coluna Direita: QR Code Amplo (w ~ 150pt)
    left_x = x + pad
    left_w = inner_w - 156.0
    right_x = x + w - pad - 146.0

    content_top_y = head_y - 16.0

    # 4. DESTAQUE DO ESTANDE / TRABALHO
    id_box_h = 44.0
    c.setFillColor(colors.HexColor("#F8FAFC"))
    c.setStrokeColor(colors.HexColor("#E2E8F0"))
    c.roundRect(left_x, content_top_y - id_box_h, left_w, id_box_h, 6, fill=1, stroke=1)

    booth_label, booth_display = _format_booth_display(project_data)
    c.setFont("Helvetica-Bold", 7.5)
    c.setFillColor(colors.HexColor("#64748B"))
    c.drawString(left_x + 10, content_top_y - 13, booth_label)

    font_size_a6 = 18.0
    while font_size_a6 > 11.0 and c.stringWidth(booth_display, "Helvetica-Bold", font_size_a6) > (left_w - 20.0):
        font_size_a6 -= 1.5
    c.setFont("Helvetica-Bold", font_size_a6)
    c.setFillColor(colors.HexColor("#1E3A8A"))
    c.drawString(left_x + 10, content_top_y - 35, booth_display)

    # 5. Área e Subárea
    area_top_y = content_top_y - id_box_h - 14.0
    c.setFont("Helvetica-Bold", 7)
    c.setFillColor(colors.HexColor("#94A3B8"))
    c.drawString(left_x, area_top_y, "GRANDE ÁREA")

    area_name = (project_data.get("area_name") or "ÁREA NÃO DEFINIDA").upper()
    c.setFont("Helvetica-Bold", 10.5)
    c.setFillColor(colors.HexColor("#0F172A"))
    area_lines = _wrap_text_lines(c, area_name, left_w, "Helvetica-Bold", 10.5, max_lines=2)
    curr_area_y = area_top_y - 12.0
    for l in area_lines:
        c.drawString(left_x, curr_area_y, l)
        curr_area_y -= 13.0

    subarea_name = project_data.get("subarea_name")
    if subarea_name:
        curr_area_y -= 2.0
        c.setFont("Helvetica-Bold", 7)
        c.setFillColor(colors.HexColor("#94A3B8"))
        c.drawString(left_x, curr_area_y, "SUBÁREA")
        curr_area_y -= 10.0

        c.setFont("Helvetica", 8.5)
        c.setFillColor(colors.HexColor("#334155"))
        sub_lines = _wrap_text_lines(c, subarea_name, left_w, "Helvetica", 8.5, max_lines=2)
        for l in sub_lines:
            c.drawString(left_x, curr_area_y, l)
            curr_area_y -= 11.0

    # Token do Trabalho posicionado abaixo da Subárea (espaço horizontal amplo)
    token = project_data.get("qrcode_token") or f"PRJ-{project_data.get('id', 0):05d}"
    curr_area_y -= 3.0
    c.setFont("Helvetica-Bold", 7)
    c.setFillColor(colors.HexColor("#64748B"))
    c.drawString(left_x, curr_area_y, "CÓDIGO / TOKEN:")
    curr_area_y -= 9.5

    c.setFont("Courier-Bold", 8)
    c.setFillColor(colors.HexColor("#0F172A"))
    c.drawString(left_x, curr_area_y, token)

    # 6. Badges compactos na base
    badges_y = y + pad + 18.0
    curr_bx = left_x

    ptype = project_data.get("project_type")
    ptype_label = "TECNOLÓGICO" if ptype == ProjectType.TECHNOLOGICAL else "CIENTÍFICO"
    bw1 = _draw_badge_pill(
        c,
        curr_bx,
        badges_y,
        ptype_label,
        bg_color=colors.HexColor("#EFF6FF"),
        border_color=colors.HexColor("#BFDBFE"),
        text_color=colors.HexColor("#1D4ED8"),
        font_size=7.5,
        height=16.0,
    )
    curr_bx += bw1 + 5.0

    needs_elec = bool(project_data.get("needs_electricity"))
    elec_label = "TOMADA: SIM" if needs_elec else "TOMADA: NÃO"
    elec_bg = colors.HexColor("#FEF3C7") if needs_elec else colors.HexColor("#F1F5F9")
    elec_border = colors.HexColor("#FDE68A") if needs_elec else colors.HexColor("#E2E8F0")
    elec_text = colors.HexColor("#B45309") if needs_elec else colors.HexColor("#64748B")
    bw2 = _draw_badge_pill(
        c,
        curr_bx,
        badges_y,
        elec_label,
        bg_color=elec_bg,
        border_color=elec_border,
        text_color=elec_text,
        font_size=7.5,
        height=16.0,
    )
    curr_bx += bw2 + 5.0

    needs_tab = bool(project_data.get("needs_table"))
    tab_label = "MESA: SIM" if needs_tab else "MESA: NÃO"
    tab_bg = colors.HexColor("#EEF2FF") if needs_tab else colors.HexColor("#F1F5F9")
    tab_border = colors.HexColor("#C7D2FE") if needs_tab else colors.HexColor("#E2E8F0")
    tab_text = colors.HexColor("#4338CA") if needs_tab else colors.HexColor("#64748B")
    _draw_badge_pill(
        c,
        curr_bx,
        badges_y,
        tab_label,
        bg_color=tab_bg,
        border_color=tab_border,
        text_color=tab_text,
        font_size=7.5,
        height=16.0,
    )

    # Mensagem de rodapé
    c.setFont("Helvetica", 6.5)
    c.setFillColor(colors.HexColor("#94A3B8"))
    c.drawString(left_x, y + pad + 4.0, "Identificação e avaliação oficial de bancada.")

    # 7. COLUNA DIREITA: QR CODE AMPLO (~135pt)
    qr_container_w = 146.0
    qr_container_h = inner_h - 4.0
    qr_container_y = y + pad + 2.0

    c.setFillColor(colors.HexColor("#F8FAFC"))
    c.setStrokeColor(colors.HexColor("#E2E8F0"))
    c.setLineWidth(0.8)
    c.roundRect(right_x, qr_container_y, qr_container_w, qr_container_h, 8, fill=1, stroke=1)

    c.setFont("Helvetica-Bold", 8)
    c.setFillColor(colors.HexColor("#1E293B"))
    c.drawCentredString(right_x + (qr_container_w / 2.0), qr_container_y + qr_container_h - 16.0, "AVALIAÇÃO")

    c.setFont("Helvetica", 6.5)
    c.setFillColor(colors.HexColor("#64748B"))
    c.drawCentredString(right_x + (qr_container_w / 2.0), qr_container_y + qr_container_h - 26.0, "Aponte a câmera para avaliar")

    # QR Code no centro com margem e proporção ideal
    qr_size = 135.0
    qr_x = right_x + (qr_container_w - qr_size) / 2.0
    qr_y = qr_container_y + 20.0

    c.setFillColor(colors.HexColor("#FFFFFF"))
    c.setStrokeColor(colors.HexColor("#CBD5E1"))
    c.setLineWidth(0.5)
    c.roundRect(qr_x - 4, qr_y - 4, qr_size + 8, qr_size + 8, 4, fill=1, stroke=1)

    _draw_qrcode(c, token, qr_x, qr_y, qr_size)

    c.setFont("Helvetica", 6)
    c.setFillColor(colors.HexColor("#94A3B8"))
    c.drawCentredString(right_x + (qr_container_w / 2.0), qr_container_y + 8.0, "Apenas avaliadores cadastrados")

    c.restoreState()


def _draw_crop_lines_a5(c: canvas.Canvas, page_w: float, page_h: float) -> None:
    """Desenha guias de corte discretas no meio da folha A4 retrato."""
    c.saveState()
    c.setStrokeColor(colors.HexColor("#CBD5E1"))
    c.setLineWidth(0.5)
    c.setDash([4, 4])
    mid_y = page_h / 2.0
    # Linha de corte horizontal
    c.line(10, mid_y, page_w - 10, mid_y)
    c.restoreState()


def _draw_crop_lines_a6(c: canvas.Canvas, page_w: float, page_h: float) -> None:
    """Desenha guias de corte discretas em cruz na folha A4 paisagem."""
    c.saveState()
    c.setStrokeColor(colors.HexColor("#CBD5E1"))
    c.setLineWidth(0.5)
    c.setDash([4, 4])
    mid_x = page_w / 2.0
    mid_y = page_h / 2.0
    # Linha de corte vertical
    c.line(mid_x, 10, mid_x, page_h - 10)
    # Linha de corte horizontal
    c.line(10, mid_y, page_w - 10, mid_y)
    c.restoreState()


async def generate_event_booth_stickers_pdf(
    db: AsyncSession,
    event_id: int,
    project_id: Optional[int] = None,
    status_filter: str = "homologated",
    area_id: Optional[int] = None,
    sort_by: str = "id",
    layout: str = "a5_double",
) -> bytes:
    """Gera o documento PDF consolidado de adesivos de bancada para impressão.

    Args:
        db: Sessão assíncrona do SQLAlchemy.
        event_id: ID do evento.
        project_id: Opcional. ID de um trabalho específico para emissão individual.
        status_filter: homologated ou all.
        area_id: Opcional. Filtro por Grande Área do Conhecimento.
        sort_by: id, area, ou title.
        layout: a5_double (2 por folha A4) ou a6_quad (4 por folha A4).

    Returns:
        Bytes do documento PDF gerado.
    """
    # 1. Carregar Evento
    event = await db.get(Event, event_id)
    if not event or event.deleted_at is not None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Edição do evento não encontrada.",
        )

    event_info = {
        "id": event.id,
        "name": event.name,
        "year": event.year,
        "institution": event.organizing_institution,
        "logo_path": _resolve_local_logo_path(event.logo_url),
    }

    # 2. Query de Projetos
    stmt = (
        select(Project)
        .options(
            selectinload(Project.subarea).selectinload(Subarea.knowledge_area),
        )
        .where(
            Project.event_id == event_id,
            Project.deleted_at.is_(None),
        )
    )

    if project_id:
        stmt = stmt.where(Project.id == project_id)
    else:
        if status_filter == "homologated":
            stmt = stmt.where(
                Project.status.in_([ProjectStatus.HOMOLOGATED, ProjectStatus.PRESENT, ProjectStatus.EVALUATED])
            )
        if area_id:
            stmt = stmt.join(Project.subarea).where(Subarea.area_id == area_id)

    res = await db.execute(stmt)
    projects = list(res.scalars().all())

    if not projects:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Nenhum trabalho encontrado para os filtros selecionados.",
        )

    # 3. Ordenação
    if sort_by == "booth":
        projects.sort(key=lambda p: (p.booth_number or "ZZZZ", p.id))
    elif sort_by == "area":
        projects.sort(key=lambda p: (p.area_name or "", p.subarea_name or "", p.id))
    elif sort_by == "title":
        projects.sort(key=lambda p: (p.title.lower() if p.title else "", p.id))
    else:  # "id"
        projects.sort(key=lambda p: p.id)

    # Estruturar dados dos projetos
    projects_data: List[Dict[str, Any]] = []
    for p in projects:
        projects_data.append({
            "id": p.id,
            "title": p.title,
            "booth_number": p.booth_number,
            "project_type": p.project_type,
            "area_name": p.area_name or "ÁREA NÃO DEFINIDA",
            "subarea_name": p.subarea_name or "",
            "needs_electricity": p.needs_electricity,
            "needs_table": p.needs_table,
            "qrcode_token": p.qrcode_token,
        })

    # 4. Construção do PDF
    buffer = io.BytesIO()

    if layout == "a6_quad":
        # Folha A4 Paisagem (841.89 x 595.28 pt)
        page_size = landscape(A4)
        page_w, page_h = page_size
        c = canvas.Canvas(buffer, pagesize=page_size)

        margin_x = 18.0
        margin_y = 18.0
        gap_x = 16.0
        gap_y = 16.0
        slot_w = (page_w - (margin_x * 2) - gap_x) / 2.0
        slot_h = (page_h - (margin_y * 2) - gap_y) / 2.0

        # Quadrantes: Top-Left, Top-Right, Bottom-Left, Bottom-Right
        slots = [
            (margin_x, margin_y + slot_h + gap_y),                  # Top-Left
            (margin_x + slot_w + gap_x, margin_y + slot_h + gap_y), # Top-Right
            (margin_x, margin_y),                                   # Bottom-Left
            (margin_x + slot_w + gap_x, margin_y),                  # Bottom-Right
        ]

        per_page = 4
        for idx, p_data in enumerate(projects_data):
            slot_idx = idx % per_page
            sx, sy = slots[slot_idx]
            _draw_booth_sticker_a6(c, sx, sy, slot_w, slot_h, p_data, event_info)

            # Se completou a página ou é o último item
            if slot_idx == per_page - 1 or idx == len(projects_data) - 1:
                _draw_crop_lines_a6(c, page_w, page_h)
                c.showPage()

    else:
        # Padrão: Modelo A5 (2 por folha A4 Retrato: 595.28 x 841.89 pt)
        page_size = A4
        page_w, page_h = page_size
        c = canvas.Canvas(buffer, pagesize=page_size)

        margin_x = 20.0
        margin_y = 20.0
        gap_y = 16.0
        slot_w = page_w - (margin_x * 2)
        slot_h = (page_h - (margin_y * 2) - gap_y) / 2.0

        slots = [
            (margin_x, margin_y + slot_h + gap_y), # Topo
            (margin_x, margin_y),                  # Base
        ]

        per_page = 2
        for idx, p_data in enumerate(projects_data):
            slot_idx = idx % per_page
            sx, sy = slots[slot_idx]
            _draw_booth_sticker_a5(c, sx, sy, slot_w, slot_h, p_data, event_info)

            if slot_idx == per_page - 1 or idx == len(projects_data) - 1:
                _draw_crop_lines_a5(c, page_w, page_h)
                c.showPage()

    c.save()
    pdf_bytes = buffer.getvalue()
    buffer.close()
    return pdf_bytes
