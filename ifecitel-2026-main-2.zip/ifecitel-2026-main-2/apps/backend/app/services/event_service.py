"""Event service containing business logic, temporal locking, and multi-tenant isolation (BR-01, BR-02, BR-23)."""

from datetime import date
import math
from typing import List, Optional
from fastapi import HTTPException, status
from sqlalchemy import func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.models.enums import EducationLevelEnum, EventAdminRole, EventStatus, UserRole
from app.models.event import EducationLevel, Event, EventAdministrator, EventStage
from app.models.person import Person
from app.schemas.event import EventCreate, EventUpdate
from app.schemas.event_admin import EventAdminCreate, EventAdminItem


def verify_event_temporal_lock(event: Event) -> None:
    """Verifica se o evento atingiu a data de encerramento (Trava Temporal BR-02)."""
    if date.today() > event.end_date or event.status == EventStatus.CLOSED:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Operação bloqueada: o evento já foi encerrado e encontra-se em modo somente-leitura."
        )


async def _decorate_event_roles(db: AsyncSession, events: List[Event], admin_id: Optional[int]) -> None:
    """Decora transitoriamente os eventos com o papel e propriedade do administrador consultante e dados do proprietário."""
    if not events:
        return

    ea_map = {}
    if admin_id:
        event_ids = [e.id for e in events]
        ea_stmt = select(EventAdministrator).where(
            EventAdministrator.event_id.in_(event_ids),
            EventAdministrator.person_id == admin_id,
            EventAdministrator.deleted_at.is_(None)
        )
        ea_res = await db.execute(ea_stmt)
        ea_map = {ea.event_id: ea.role for ea in ea_res.scalars().all()}

    owner_ids = list({e.owner_id for e in events if e.owner_id})
    owner_map = {}
    if owner_ids:
        p_stmt = select(Person).where(Person.id.in_(owner_ids))
        p_res = await db.execute(p_stmt)
        owner_map = {p.id: p for p in p_res.scalars().all()}

    for e in events:
        if admin_id and e.owner_id == admin_id:
            e.user_role = EventAdminRole.COORDINATOR
            e.is_owner = True
        elif admin_id and e.id in ea_map:
            e.user_role = ea_map[e.id]
            e.is_owner = False
        else:
            e.user_role = None
            e.is_owner = False

        if e.owner_id and e.owner_id in owner_map:
            owner_person = owner_map[e.owner_id]
            e.owner_name = owner_person.name
            e.owner_email = owner_person.email
        else:
            e.owner_name = None
            e.owner_email = None


async def create_event(db: AsyncSession, payload: EventCreate, creator_id: Optional[int] = None) -> Event:
    """Cria uma nova edição anual da feira com posse soberana do criador (Regra BR-01 e BR-23)."""
    if payload.end_date < payload.start_date:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="A data de encerramento (end_date) não pode ser anterior à data de início."
        )

    event = Event(
        name=payload.name,
        year=payload.year,
        description=payload.description,
        owner_id=creator_id,
        max_projects=payload.max_projects,
        workload_hours=payload.workload_hours,
        location=payload.location,
        start_date=payload.start_date,
        end_date=payload.end_date,
        status=EventStatus.OPEN,
        summary_extension=payload.summary_extension,
        banner_extension=payload.banner_extension,
        max_file_size_mb=payload.max_file_size_mb,
        max_projects_per_evaluator=payload.max_projects_per_evaluator,
        organizing_institution=payload.organizing_institution,
        theme=payload.theme,
        contact_email=payload.contact_email,
        website_url=payload.website_url,
        logo_url=payload.logo_url
    )
    db.add(event)
    await db.flush()

    # Se informado o criador, cadastra-o automaticamente como Coordenador Geral soberano
    if creator_id:
        ea = EventAdministrator(
            event_id=event.id,
            person_id=creator_id,
            role=EventAdminRole.COORDINATOR
        )
        db.add(ea)

    # Adicionar estágios se fornecidos
    if payload.stages:
        for stage_data in payload.stages:
            stage = EventStage(
                event_id=event.id,
                name=stage_data.name,
                start_date=stage_data.start_date,
                end_date=stage_data.end_date
            )
            db.add(stage)

    # Adicionar níveis de ensino configurados
    if payload.education_levels:
        for level_data in payload.education_levels:
            level = EducationLevel(
                event_id=event.id,
                level_name=level_data.level_name,
                max_students=level_data.max_students,
                min_evaluators=level_data.min_evaluators
            )
            db.add(level)

    # Adicionar equipe gestora configurada (opcional)
    if payload.administrators:
        for admin_input in payload.administrators:
            email_clean = str(admin_input.email).strip().lower()
            if not email_clean:
                continue
            person_stmt = select(Person).where(func.lower(Person.email) == email_clean, Person.deleted_at.is_(None))
            person_res = await db.execute(person_stmt)
            person = person_res.scalar_one_or_none()
            if not person:
                person = Person(
                    name=email_clean.split("@")[0].replace(".", " ").title(),
                    email=email_clean,
                    role=UserRole.ADMIN
                )
                db.add(person)
                await db.flush()
            elif person.role != UserRole.ADMIN:
                person.role = UserRole.ADMIN

            # Não adiciona o criador duas vezes
            if creator_id and person.id == creator_id:
                continue

            ea = EventAdministrator(
                event_id=event.id,
                person_id=person.id,
                role=admin_input.role
            )
            db.add(ea)

    await db.commit()
    db.expire(event, ["education_levels", "administrators", "stages"])
    return await get_event_by_id(db, event.id, creator_id)


async def get_event_by_id(db: AsyncSession, event_id: int, admin_id: Optional[int] = None) -> Event:
    """Recupera os dados de uma edição ativa com verificação de soft-delete e decora papéis."""
    stmt = (
        select(Event)
        .where(Event.id == event_id, Event.deleted_at.is_(None))
        .options(
            selectinload(Event.stages),
            selectinload(Event.education_levels),
            selectinload(Event.administrators).selectinload(EventAdministrator.person)
        )
        .execution_options(populate_existing=True)
    )
    res = await db.execute(stmt)
    event = res.scalar_one_or_none()
    if not event:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Evento com ID {event_id} não encontrado."
        )

    await _decorate_event_roles(db, [event], admin_id)
    return event


async def list_events(db: AsyncSession, admin_id: Optional[int] = None, search: Optional[str] = None) -> List[Event]:
    """
    Lista edições de eventos ativas no sistema.
    Se admin_id for informado, filtra estritamente por posse ou equipe (Regra BR-23).
    """
    base_filter = [Event.deleted_at.is_(None)]

    if admin_id:
        base_filter.append(
            or_(
                Event.owner_id == admin_id,
                Event.id.in_(
                    select(EventAdministrator.event_id).where(
                        EventAdministrator.person_id == admin_id,
                        EventAdministrator.deleted_at.is_(None)
                    )
                )
            )
        )

    if search and search.strip():
        base_filter.append(Event.name.ilike(f"%{search.strip()}%"))

    stmt = (
        select(Event)
        .where(*base_filter)
        .options(
            selectinload(Event.education_levels),
            selectinload(Event.administrators).selectinload(EventAdministrator.person)
        )
        .order_by(Event.year.desc())
    )
    res = await db.execute(stmt)
    items = list(res.scalars().all())

    await _decorate_event_roles(db, items, admin_id)
    return items


async def list_events_paginated(
    db: AsyncSession,
    admin_id: Optional[int] = None,
    page: int = 1,
    limit: int = 15,
    search: Optional[str] = None
) -> dict:
    """
    Lista edições com paginação real no banco de dados (Regra BR-18) e isolamento estrito (Regra BR-23).
    """
    base_filter = [Event.deleted_at.is_(None)]

    if admin_id:
        base_filter.append(
            or_(
                Event.owner_id == admin_id,
                Event.id.in_(
                    select(EventAdministrator.event_id).where(
                        EventAdministrator.person_id == admin_id,
                        EventAdministrator.deleted_at.is_(None)
                    )
                )
            )
        )

    if search and search.strip():
        base_filter.append(Event.name.ilike(f"%{search.strip()}%"))

    # 1. Total de registros ativos filtrados
    count_stmt = select(func.count(Event.id)).where(*base_filter)
    total_res = await db.execute(count_stmt)
    total = total_res.scalar_one()

    # 2. Registros da página solicitada
    offset = (page - 1) * limit
    stmt = (
        select(Event)
        .where(*base_filter)
        .options(
            selectinload(Event.education_levels),
            selectinload(Event.administrators).selectinload(EventAdministrator.person)
        )
        .order_by(Event.year.desc(), Event.id.desc())
        .offset(offset)
        .limit(limit)
    )
    res = await db.execute(stmt)
    items = list(res.scalars().all())

    await _decorate_event_roles(db, items, admin_id)

    total_pages = math.ceil(total / limit) if total > 0 else 1

    return {
        "items": items,
        "total": total,
        "page": page,
        "limit": limit,
        "total_pages": total_pages
    }


async def update_event(db: AsyncSession, event_id: int, payload: EventUpdate) -> Event:
    """Atualiza configurações de uma edição, respeitando a trava temporal."""
    event = await get_event_by_id(db, event_id)
    verify_event_temporal_lock(event)

    update_data = payload.model_dump(exclude_unset=True)
    education_levels_data = update_data.pop("education_levels", None)
    administrators_data = update_data.pop("administrators", None)

    for field, value in update_data.items():
        setattr(event, field, value)

    # Sincronização de níveis de ensino se fornecido
    if education_levels_data is not None:
        el_stmt = select(EducationLevel).where(
            EducationLevel.event_id == event_id
        )
        el_res = await db.execute(el_stmt)
        all_levels = list(el_res.scalars().all())

        def _to_key(val):
            return val.value if hasattr(val, "value") else str(val)

        existing_map = {_to_key(el.level_name): el for el in all_levels}
        incoming_keys = set()

        for item_data in education_levels_data:
            key = _to_key(item_data["level_name"])
            incoming_keys.add(key)
            lvl_enum = item_data["level_name"] if isinstance(item_data["level_name"], EducationLevelEnum) else EducationLevelEnum(item_data["level_name"])

            if key in existing_map:
                existing = existing_map[key]
                existing.deleted_at = None
                existing.max_students = item_data["max_students"]
                existing.min_evaluators = item_data["min_evaluators"]
            else:
                new_lvl = EducationLevel(
                    event_id=event.id,
                    level_name=lvl_enum,
                    max_students=item_data["max_students"],
                    min_evaluators=item_data["min_evaluators"]
                )
                db.add(new_lvl)

        for key, existing in existing_map.items():
            if key not in incoming_keys and existing.deleted_at is None:
                existing.soft_delete()

    # Sincronização de administradores se fornecido
    if administrators_data is not None:
        ea_stmt = select(EventAdministrator).where(
            EventAdministrator.event_id == event_id,
            EventAdministrator.deleted_at.is_(None)
        ).options(selectinload(EventAdministrator.person))
        ea_res = await db.execute(ea_stmt)
        existing_admins = list(ea_res.scalars().all())
        existing_admin_by_email = {}
        for ea in existing_admins:
            if ea.person and ea.person.email:
                existing_admin_by_email[ea.person.email.lower()] = ea

        incoming_admin_emails = set()
        for admin_item in administrators_data:
            email_clean = str(admin_item["email"]).strip().lower()
            if not email_clean:
                continue
            incoming_admin_emails.add(email_clean)
            role = admin_item.get("role", EventAdminRole.ORGANIZER)

            if email_clean in existing_admin_by_email:
                ea = existing_admin_by_email[email_clean]
                if event.owner_id != ea.person_id:
                    ea.role = role
            else:
                person_stmt = select(Person).where(func.lower(Person.email) == email_clean, Person.deleted_at.is_(None))
                person_res = await db.execute(person_stmt)
                person = person_res.scalar_one_or_none()
                if not person:
                    person = Person(
                        name=email_clean.split("@")[0].replace(".", " ").title(),
                        email=email_clean,
                        role=UserRole.ADMIN
                    )
                    db.add(person)
                    await db.flush()
                elif person.role != UserRole.ADMIN:
                    person.role = UserRole.ADMIN

                old_ea_stmt = select(EventAdministrator).where(
                    EventAdministrator.event_id == event_id,
                    EventAdministrator.person_id == person.id
                )
                old_ea_res = await db.execute(old_ea_stmt)
                old_ea = old_ea_res.scalar_one_or_none()
                if old_ea:
                    old_ea.deleted_at = None
                    if event.owner_id != person.id:
                        old_ea.role = role
                else:
                    new_ea = EventAdministrator(
                        event_id=event.id,
                        person_id=person.id,
                        role=role if event.owner_id != person.id else EventAdminRole.COORDINATOR
                    )
                    db.add(new_ea)

        for ea in existing_admins:
            if ea.person and ea.person.email:
                if ea.person.email.lower() not in incoming_admin_emails:
                    if event.owner_id != ea.person_id:
                        ea.soft_delete()

    await db.commit()
    db.expire(event, ["education_levels", "administrators", "stages"])
    return await get_event_by_id(db, event_id)


async def delete_event(db: AsyncSession, event_id: int) -> None:
    """Aplica soft-delete na edição do evento."""
    event = await get_event_by_id(db, event_id)
    event.soft_delete()
    await db.commit()


# ==============================================================================
# Gestão de Equipe e Administradores da Feira (Regra BR-23)
# ==============================================================================

async def list_event_admins(db: AsyncSession, event_id: int) -> dict:
    """Lista todos os gestores administrativos com seus respectivos níveis na feira."""
    event = await get_event_by_id(db, event_id)

    stmt = (
        select(EventAdministrator)
        .where(EventAdministrator.event_id == event_id, EventAdministrator.deleted_at.is_(None))
        .options(selectinload(EventAdministrator.person))
        .order_by(EventAdministrator.created_at.asc())
    )
    res = await db.execute(stmt)
    admins = list(res.scalars().all())

    items: List[EventAdminItem] = []
    seen_person_ids = set()

    # Se o evento possui owner_id e não estiver explicitamente na tabela, inclui como Dono
    for a in admins:
        is_owner = (a.person_id == event.owner_id)
        seen_person_ids.add(a.person_id)
        items.append(
            EventAdminItem(
                id=a.id,
                event_id=a.event_id,
                person_id=a.person_id,
                name=a.person.name if a.person else "Administrador",
                email=a.person.email if a.person else "",
                role=EventAdminRole.COORDINATOR if is_owner else a.role,
                is_owner=is_owner,
                created_at=a.created_at
            )
        )

    if event.owner_id and event.owner_id not in seen_person_ids:
        owner_stmt = select(Person).where(Person.id == event.owner_id)
        owner_res = await db.execute(owner_stmt)
        owner = owner_res.scalar_one_or_none()
        if owner:
            items.insert(
                0,
                EventAdminItem(
                    id=0,
                    event_id=event.id,
                    person_id=owner.id,
                    name=owner.name,
                    email=owner.email,
                    role=EventAdminRole.COORDINATOR,
                    is_owner=True,
                    created_at=event.created_at
                )
            )

    return {
        "items": items,
        "total": len(items)
    }


async def add_event_admin(
    db: AsyncSession,
    event_id: int,
    payload: EventAdminCreate,
    current_admin_id: int
) -> EventAdminItem:
    """Convida e adiciona um novo administrador à feira pelo e-mail."""
    event = await get_event_by_id(db, event_id)
    email_clean = str(payload.email).strip().lower()

    # Busca a pessoa no cadastro unificado
    person_stmt = select(Person).where(func.lower(Person.email) == email_clean, Person.deleted_at.is_(None))
    person_res = await db.execute(person_stmt)
    person = person_res.scalar_one_or_none()

    if not person:
        # Se ainda não existe, cria conta administrativa pré-cadastrada
        person = Person(
            name=email_clean.split("@")[0].replace(".", " ").title(),
            email=email_clean,
            role=UserRole.ADMIN
        )
        db.add(person)
        await db.flush()
    elif person.role != UserRole.ADMIN:
        person.role = UserRole.ADMIN

    # Dono não pode ser adicionado novamente
    if event.owner_id == person.id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Este usuário já é o Coordenador Geral soberano da feira."
        )

    # Verifica vínculo em event_administrators
    ea_stmt = select(EventAdministrator).where(
        EventAdministrator.event_id == event_id,
        EventAdministrator.person_id == person.id
    )
    ea_res = await db.execute(ea_stmt)
    ea = ea_res.scalar_one_or_none()

    if ea:
        if ea.deleted_at is None:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Este usuário já faz parte da equipe administrativa da feira."
            )
        ea.deleted_at = None
        ea.role = payload.role
    else:
        ea = EventAdministrator(
            event_id=event_id,
            person_id=person.id,
            role=payload.role
        )
        db.add(ea)

    await db.commit()
    await db.refresh(ea)

    return EventAdminItem(
        id=ea.id,
        event_id=event_id,
        person_id=person.id,
        name=person.name,
        email=person.email,
        role=ea.role,
        is_owner=False,
        created_at=ea.created_at
    )


async def update_event_admin_role(
    db: AsyncSession,
    event_id: int,
    target_person_id: int,
    new_role: EventAdminRole,
    current_admin_id: int
) -> EventAdminItem:
    """Atualiza o papel hierárquico de um administrador do evento."""
    event = await get_event_by_id(db, event_id)
    if target_person_id == event.owner_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Não é permitido alterar o papel do Coordenador Geral soberano da feira."
        )

    stmt = (
        select(EventAdministrator)
        .where(
            EventAdministrator.event_id == event_id,
            EventAdministrator.person_id == target_person_id,
            EventAdministrator.deleted_at.is_(None)
        )
        .options(selectinload(EventAdministrator.person))
    )
    res = await db.execute(stmt)
    ea = res.scalar_one_or_none()
    if not ea:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Administrador não encontrado na equipe desta feira."
        )

    ea.role = new_role
    await db.commit()
    await db.refresh(ea)

    return EventAdminItem(
        id=ea.id,
        event_id=ea.event_id,
        person_id=ea.person_id,
        name=ea.person.name if ea.person else "Administrador",
        email=ea.person.email if ea.person else "",
        role=ea.role,
        is_owner=False,
        created_at=ea.created_at
    )


async def remove_event_admin(
    db: AsyncSession,
    event_id: int,
    target_person_id: int,
    current_admin_id: int
) -> None:
    """Revoga o acesso de um administrador à feira."""
    event = await get_event_by_id(db, event_id)
    if target_person_id == event.owner_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Não é permitido revogar o acesso do Coordenador Geral soberano da feira."
        )

    stmt = select(EventAdministrator).where(
        EventAdministrator.event_id == event_id,
        EventAdministrator.person_id == target_person_id,
        EventAdministrator.deleted_at.is_(None)
    )
    res = await db.execute(stmt)
    ea = res.scalar_one_or_none()
    if not ea:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Administrador não encontrado na equipe desta feira."
        )

    ea.soft_delete()
    await db.commit()
