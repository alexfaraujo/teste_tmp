"""Service for snack moments management and distribution (Rule BR-30)."""

from datetime import datetime, timezone
from typing import List, Optional, Tuple
from fastapi import HTTPException, status
from sqlalchemy import distinct, exists, func, or_, select, update
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.models.enums import UserRole
from app.models.event import EventAdministrator
from app.models.person import EventParticipant, EventParticipantRole, Person
from app.models.project import Project, ProjectMember
from app.models.snack import SnackDelivery, SnackMoment
from app.schemas.snack import (
    SnackDeliverScanRequest,
    SnackDeliverScanResponse,
    SnackDeliveryItemResponse,
    SnackMomentCreate,
    SnackMomentReportResponse,
    SnackMomentResponse,
    SnackMomentUpdate,
)


def _get_person_lookup_condition(term: str):
    """Cria predicado flexível para busca por código de barras, CPF (com/sem pontuação), ID ou e-mail."""
    term_clean = term.strip()
    digits = "".join(c for c in term_clean if c.isdigit())
    conds = [
        Person.barcode == term_clean,
        Person.email.ilike(term_clean),
    ]
    if hasattr(Person, "cpf"):
        conds.append(Person.cpf == term_clean)
        if digits and len(digits) == 11:
            formatted = f"{digits[:3]}.{digits[3:6]}.{digits[6:9]}-{digits[9:]}"
            conds.append(Person.cpf == formatted)
    if digits and len(digits) <= 8:
        try:
            conds.append(Person.id == int(digits))
        except ValueError:
            pass
    return or_(*conds)


async def list_snack_moments(
    db: AsyncSession,
    event_id: int,
) -> List[SnackMomentResponse]:
    """Lista todos os momentos de lanche cadastrados para uma edição do evento."""
    stmt = (
        select(
            SnackMoment,
            func.count(SnackDelivery.id).label("total_delivered"),
        )
        .outerjoin(
            SnackDelivery,
            (SnackDelivery.snack_moment_id == SnackMoment.id)
            & (SnackDelivery.deleted_at.is_(None)),
        )
        .where(
            SnackMoment.event_id == event_id,
            SnackMoment.deleted_at.is_(None),
        )
        .group_by(SnackMoment.id)
        .order_by(SnackMoment.date.asc(), SnackMoment.start_time.asc().nulls_last())
    )
    result = await db.execute(stmt)
    rows = result.all()

    response: List[SnackMomentResponse] = []
    for moment, delivered_count in rows:
        budgeted = moment.total_budgeted or 0
        pct = (delivered_count / budgeted * 100.0) if budgeted > 0 else 0.0
        response.append(
            SnackMomentResponse(
                id=moment.id,
                event_id=moment.event_id,
                name=moment.name,
                date=moment.date,
                start_time=moment.start_time,
                end_time=moment.end_time,
                is_active=moment.is_active,
                target_roles=moment.target_roles or "ALL",
                total_budgeted=budgeted,
                notes=moment.notes,
                created_at=moment.created_at,
                total_delivered=delivered_count,
                percentage_consumed=round(pct, 1),
            )
        )
    return response


async def get_snack_moment_or_404(
    db: AsyncSession,
    moment_id: int,
) -> SnackMoment:
    """Recupera um momento de lanche ativo por ID."""
    stmt = select(SnackMoment).where(
        SnackMoment.id == moment_id,
        SnackMoment.deleted_at.is_(None),
    )
    res = await db.execute(stmt)
    moment = res.scalar_one_or_none()
    if not moment:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Momento de lanche não encontrado.",
        )
    return moment


async def create_snack_moment(
    db: AsyncSession,
    event_id: int,
    data: SnackMomentCreate,
) -> SnackMomentResponse:
    """Cria um novo momento de lanche para a edição."""
    # Verificar unicidade de nome para a mesma edição
    stmt_check = select(SnackMoment).where(
        SnackMoment.event_id == event_id,
        SnackMoment.name.ilike(data.name.strip()),
        SnackMoment.deleted_at.is_(None),
    )
    res_check = await db.execute(stmt_check)
    if res_check.scalar_one_or_none():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Já existe um momento de lanche cadastrado com o nome '{data.name.strip()}'.",
        )

    moment = SnackMoment(
        event_id=event_id,
        name=data.name.strip(),
        date=data.date,
        start_time=data.start_time.strip() if data.start_time else None,
        end_time=data.end_time.strip() if data.end_time else None,
        is_active=data.is_active,
        target_roles=(data.target_roles or "ALL").strip().upper(),
        total_budgeted=data.total_budgeted or 0,
        notes=data.notes.strip() if data.notes else None,
    )
    db.add(moment)
    await db.commit()
    await db.refresh(moment)

    return SnackMomentResponse(
        id=moment.id,
        event_id=moment.event_id,
        name=moment.name,
        date=moment.date,
        start_time=moment.start_time,
        end_time=moment.end_time,
        is_active=moment.is_active,
        target_roles=moment.target_roles or "ALL",
        total_budgeted=moment.total_budgeted or 0,
        notes=moment.notes,
        created_at=moment.created_at,
        total_delivered=0,
        percentage_consumed=0.0,
    )


async def update_snack_moment(
    db: AsyncSession,
    moment_id: int,
    data: SnackMomentUpdate,
) -> SnackMomentResponse:
    """Atualiza dados de um momento de lanche."""
    moment = await get_snack_moment_or_404(db, moment_id)

    if data.name is not None and data.name.strip() != moment.name:
        # Verificar duplicidade
        stmt_check = select(SnackMoment).where(
            SnackMoment.event_id == moment.event_id,
            SnackMoment.name.ilike(data.name.strip()),
            SnackMoment.id != moment_id,
            SnackMoment.deleted_at.is_(None),
        )
        res_check = await db.execute(stmt_check)
        if res_check.scalar_one_or_none():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Já existe um momento de lanche cadastrado com o nome '{data.name.strip()}'.",
            )
        moment.name = data.name.strip()

    if data.date is not None:
        moment.date = data.date
    if data.start_time is not None:
        moment.start_time = data.start_time.strip() if data.start_time else None
    if data.end_time is not None:
        moment.end_time = data.end_time.strip() if data.end_time else None
    if data.is_active is not None:
        moment.is_active = data.is_active
    if data.target_roles is not None:
        moment.target_roles = data.target_roles.strip().upper()
    if data.total_budgeted is not None:
        moment.total_budgeted = data.total_budgeted
    if data.notes is not None:
        moment.notes = data.notes.strip() if data.notes else None

    await db.commit()
    await db.refresh(moment)

    # Buscar total entregue
    stmt_count = select(func.count(SnackDelivery.id)).where(
        SnackDelivery.snack_moment_id == moment.id,
        SnackDelivery.deleted_at.is_(None),
    )
    res_count = await db.execute(stmt_count)
    delivered = res_count.scalar_one() or 0
    budgeted = moment.total_budgeted or 0
    pct = (delivered / budgeted * 100.0) if budgeted > 0 else 0.0

    return SnackMomentResponse(
        id=moment.id,
        event_id=moment.event_id,
        name=moment.name,
        date=moment.date,
        start_time=moment.start_time,
        end_time=moment.end_time,
        is_active=moment.is_active,
        target_roles=moment.target_roles or "ALL",
        total_budgeted=budgeted,
        notes=moment.notes,
        created_at=moment.created_at,
        total_delivered=delivered,
        percentage_consumed=round(pct, 1),
    )


async def toggle_snack_moment_active(
    db: AsyncSession,
    moment_id: int,
    is_active: bool,
) -> SnackMomentResponse:
    """Alterna rapidamente o status ativo de distribuição do momento."""
    moment = await get_snack_moment_or_404(db, moment_id)
    moment.is_active = is_active
    await db.commit()
    await db.refresh(moment)

    stmt_count = select(func.count(SnackDelivery.id)).where(
        SnackDelivery.snack_moment_id == moment.id,
        SnackDelivery.deleted_at.is_(None),
    )
    res_count = await db.execute(stmt_count)
    delivered = res_count.scalar_one() or 0
    budgeted = moment.total_budgeted or 0
    pct = (delivered / budgeted * 100.0) if budgeted > 0 else 0.0

    return SnackMomentResponse(
        id=moment.id,
        event_id=moment.event_id,
        name=moment.name,
        date=moment.date,
        start_time=moment.start_time,
        end_time=moment.end_time,
        is_active=moment.is_active,
        target_roles=moment.target_roles or "ALL",
        total_budgeted=budgeted,
        notes=moment.notes,
        created_at=moment.created_at,
        total_delivered=delivered,
        percentage_consumed=round(pct, 1),
    )


async def delete_snack_moment(
    db: AsyncSession,
    moment_id: int,
) -> None:
    """Realiza soft-delete do momento de lanche."""
    moment = await get_snack_moment_or_404(db, moment_id)
    moment.soft_delete()
    await db.commit()


async def deliver_snack(
    db: AsyncSession,
    moment_id: int,
    payload: SnackDeliverScanRequest,
    operator_user_id: Optional[int] = None,
) -> SnackDeliverScanResponse:
    """
    Registra a entrega de lanche para um participante com validações estritas (Regra BR-30):
    1. Momento precisa existir e estar ativo (is_active == True).
    2. Identifica o participante pelo código de barras, CPF, e-mail ou ID.
    3. Confirma inscrição do participante no evento daquele momento.
    4. Valida se o papel do participante é compatível com o público-alvo (target_roles).
    5. Trava antifraude: rejeita com ALREADY_DELIVERED se já retirou neste momento.
    6. Se tudo válido, insere a entrega atômica e retorna sucesso com contadores atualizados.
    """
    moment = await get_snack_moment_or_404(db, moment_id)

    # 1. Checar se o momento está ativo
    if not moment.is_active:
        return SnackDeliverScanResponse(
            status="MOMENT_INACTIVE",
            message=f"A entrega para '{moment.name}' está pausada no momento. Por favor, aguarde a abertura pela organização.",
            moment_id=moment.id,
            moment_name=moment.name,
            total_delivered=0,
            total_budgeted=moment.total_budgeted or 0,
            percentage_consumed=0.0,
        )

    # 2. Localizar a pessoa física
    stmt_person = select(Person).where(
        _get_person_lookup_condition(payload.scan_query),
        Person.deleted_at.is_(None),
    )
    res_person = await db.execute(stmt_person)
    person = res_person.scalar_one_or_none()

    if not person:
        return SnackDeliverScanResponse(
            status="NOT_FOUND",
            message=f"Não localizamos nenhum participante com a identificação '{payload.scan_query}'. Por favor, confira o crachá ou consulte a portaria.",
            moment_id=moment.id,
            moment_name=moment.name,
            total_delivered=0,
            total_budgeted=moment.total_budgeted or 0,
            percentage_consumed=0.0,
        )

    # 3. Localizar vínculo do participante com o evento
    stmt_part = select(EventParticipant).where(
        EventParticipant.person_id == person.id,
        EventParticipant.event_id == moment.event_id,
        EventParticipant.deleted_at.is_(None),
    )
    res_part = await db.execute(stmt_part)
    participant = res_part.scalar_one_or_none()

    if not participant:
        return SnackDeliverScanResponse(
            status="NOT_FOUND",
            message=f"O(a) participante {person.name} foi localizado(a), mas não possui inscrição ativa nesta edição do evento.",
            moment_id=moment.id,
            moment_name=moment.name,
            participant_name=person.name,
            participant_barcode=person.barcode,
            affiliation=person.affiliation,
            total_delivered=0,
            total_budgeted=moment.total_budgeted or 0,
            percentage_consumed=0.0,
        )

    # 4. Obter projeto vinculado (se houver)
    stmt_proj = (
        select(Project)
        .join(ProjectMember, ProjectMember.project_id == Project.id)
        .where(
            ProjectMember.person_id == person.id,
            Project.event_id == moment.event_id,
            Project.deleted_at.is_(None),
            ProjectMember.deleted_at.is_(None),
        )
    )
    res_proj = await db.execute(stmt_proj)
    project = res_proj.scalars().first()

    # 5. Obter papéis do participante na edição
    stmt_roles = select(EventParticipantRole.role).where(
        EventParticipantRole.person_id == person.id,
        EventParticipantRole.event_id == moment.event_id,
        EventParticipantRole.deleted_at.is_(None),
    )
    res_roles = await db.execute(stmt_roles)
    event_roles = [r.value if hasattr(r, "value") else str(r) for r in res_roles.scalars().all()]

    stmt_admin = select(EventAdministrator.role).where(
        EventAdministrator.person_id == person.id,
        EventAdministrator.event_id == moment.event_id,
        EventAdministrator.deleted_at.is_(None),
    )
    res_admin = await db.execute(stmt_admin)
    for adm_r in res_admin.scalars().all():
        adm_val = adm_r.value if hasattr(adm_r, "value") else str(adm_r)
        if adm_val not in event_roles:
            event_roles.append(adm_val)

    if person.role:
        role_val = person.role.value if hasattr(person.role, "value") else str(person.role)
        if role_val not in event_roles:
            event_roles.append(role_val)

    primary_role = event_roles[0] if event_roles else (person.role.value if hasattr(person.role, "value") else "PARTICIPANT")

    # Mapeamento para rótulo amigável
    role_labels = {
        "STUDENT": "Estudante",
        "ADVISOR": "Orientador",
        "COADVISOR": "Coorientador",
        "EVALUATOR": "Avaliador",
        "ORGANIZER": "Comissão Organizadora",
        "VOLUNTEER": "Voluntário",
        "ADMIN": "Administrador",
    }
    role_display = " / ".join([role_labels.get(r, r) for r in event_roles])

    # 6. Validar público-alvo (target_roles)
    target = (moment.target_roles or "ALL").strip().upper()
    if target != "ALL":
        allowed_roles = [r.strip() for r in target.split(",") if r.strip()]
        has_permission = any(r in allowed_roles for r in event_roles)
        if not has_permission:
            # Buscar total entregue
            stmt_cnt = select(func.count(SnackDelivery.id)).where(
                SnackDelivery.snack_moment_id == moment.id,
                SnackDelivery.deleted_at.is_(None),
            )
            res_cnt = await db.execute(stmt_cnt)
            deliv_count = res_cnt.scalar_one() or 0
            budgeted = moment.total_budgeted or 0
            pct = (deliv_count / budgeted * 100.0) if budgeted > 0 else 0.0

            target_friendly = ", ".join([role_labels.get(r, r) for r in allowed_roles])
            return SnackDeliverScanResponse(
                status="ROLE_NOT_ALLOWED",
                message=f"Este lanche é reservado para {target_friendly}. O perfil de {person.name} ({role_display}) não possui autorização para este momento.",
                moment_id=moment.id,
                moment_name=moment.name,
                participant_id=participant.id,
                participant_name=person.name,
                participant_role=role_display,
                participant_barcode=person.barcode,
                affiliation=person.affiliation,
                project_title=project.title if project else None,
                booth_number=project.booth_number if project else None,
                total_delivered=deliv_count,
                total_budgeted=budgeted,
                percentage_consumed=round(pct, 1),
            )

    # 7. Checar se já retirou (Trava Antifraude de Unicidade)
    stmt_existing = (
        select(SnackDelivery)
        .options(selectinload(SnackDelivery.delivered_by))
        .where(
            SnackDelivery.snack_moment_id == moment.id,
            SnackDelivery.participant_id == participant.id,
            SnackDelivery.deleted_at.is_(None),
        )
    )
    res_existing = await db.execute(stmt_existing)
    existing = res_existing.scalar_one_or_none()

    # Contar entregas atuais
    stmt_cnt = select(func.count(SnackDelivery.id)).where(
        SnackDelivery.snack_moment_id == moment.id,
        SnackDelivery.deleted_at.is_(None),
    )
    res_cnt = await db.execute(stmt_cnt)
    deliv_count = res_cnt.scalar_one() or 0
    budgeted = moment.total_budgeted or 0

    if existing:
        deliv_time = existing.delivered_at.strftime("%H:%M:%S") if existing.delivered_at else "horário anterior"
        operator_name = existing.delivered_by.name if existing.delivered_by else "um operador"
        pct = (deliv_count / budgeted * 100.0) if budgeted > 0 else 0.0

        return SnackDeliverScanResponse(
            status="ALREADY_DELIVERED",
            message=f"O lanche de {person.name} já foi retirado hoje às {deliv_time} (atendido por {operator_name}). Para que todos possam ser atendidos, cada participante tem direito a 1 lanche por momento.",
            moment_id=moment.id,
            moment_name=moment.name,
            participant_id=participant.id,
            participant_name=person.name,
            participant_role=role_display,
            participant_barcode=person.barcode,
            affiliation=person.affiliation,
            project_title=project.title if project else None,
            booth_number=project.booth_number if project else None,
            delivered_at=existing.delivered_at,
            delivered_by_name=operator_name,
            total_delivered=deliv_count,
            total_budgeted=budgeted,
            percentage_consumed=round(pct, 1),
        )

    # 8. Efetuar a entrega
    delivery = SnackDelivery(
        snack_moment_id=moment.id,
        participant_id=participant.id,
        delivered_by_user_id=operator_user_id,
        delivered_at=datetime.now(timezone.utc),
        notes=payload.notes.strip() if payload.notes else None,
    )
    db.add(delivery)
    await db.commit()
    await db.refresh(delivery)

    # Recalcular totais com a nova entrega
    deliv_count += 1
    pct = (deliv_count / budgeted * 100.0) if budgeted > 0 else 0.0

    # Buscar nome do operador que entregou
    operator_name = None
    if operator_user_id:
        stmt_op = select(Person.name).where(Person.id == operator_user_id)
        res_op = await db.execute(stmt_op)
        operator_name = res_op.scalar_one_or_none()

    return SnackDeliverScanResponse(
        status="SUCCESS",
        message=f"Lanche entregue com sucesso para {person.name}!",
        moment_id=moment.id,
        moment_name=moment.name,
        participant_id=participant.id,
        participant_name=person.name,
        participant_role=role_display,
        participant_barcode=person.barcode,
        affiliation=person.affiliation,
        project_title=project.title if project else None,
        booth_number=project.booth_number if project else None,
        delivered_at=delivery.delivered_at,
        delivered_by_name=operator_name,
        total_delivered=deliv_count,
        total_budgeted=budgeted,
        percentage_consumed=round(pct, 1),
    )


async def get_snack_moment_report(
    db: AsyncSession,
    moment_id: int,
) -> SnackMomentReportResponse:
    """Gera relatório consolidado das entregas de um momento de lanche."""
    moment = await get_snack_moment_or_404(db, moment_id)

    # Buscar histórico de entregas
    stmt = (
        select(
            SnackDelivery,
            Person.name.label("person_name"),
            Person.role.label("person_role"),
            Person.barcode.label("person_barcode"),
            Person.affiliation.label("person_affiliation"),
            Person.id.label("person_id"),
        )
        .join(EventParticipant, EventParticipant.id == SnackDelivery.participant_id)
        .join(Person, Person.id == EventParticipant.person_id)
        .options(selectinload(SnackDelivery.delivered_by))
        .where(
            SnackDelivery.snack_moment_id == moment.id,
            SnackDelivery.deleted_at.is_(None),
        )
        .order_by(SnackDelivery.delivered_at.desc())
    )
    result = await db.execute(stmt)
    rows = result.all()

    deliveries_items: List[SnackDeliveryItemResponse] = []
    for delivery, p_name, p_role, p_barcode, p_affil, p_id in rows:
        # Projeto vinculado
        stmt_proj = (
            select(Project.title, Project.booth_number)
            .join(ProjectMember, ProjectMember.project_id == Project.id)
            .where(
                ProjectMember.person_id == p_id,
                Project.event_id == moment.event_id,
                Project.deleted_at.is_(None),
                ProjectMember.deleted_at.is_(None),
            )
        )
        res_proj = await db.execute(stmt_proj)
        proj_row = res_proj.first()

        deliveries_items.append(
            SnackDeliveryItemResponse(
                id=delivery.id,
                participant_id=delivery.participant_id,
                participant_name=p_name,
                participant_role=p_role.value if hasattr(p_role, "value") else str(p_role),
                participant_barcode=p_barcode,
                affiliation=p_affil,
                project_title=proj_row[0] if proj_row else None,
                booth_number=proj_row[1] if proj_row else None,
                delivered_at=delivery.delivered_at,
                delivered_by_name=delivery.delivered_by.name if delivery.delivered_by else None,
                notes=delivery.notes,
            )
        )

    # Contagem de elegíveis no evento de acordo com o público-alvo
    total_eligible = await get_eligible_participants_count(db, moment.event_id, moment.target_roles)

    budgeted = moment.total_budgeted or 0
    delivered_count = len(deliveries_items)
    pct = (delivered_count / budgeted * 100.0) if budgeted > 0 else 0.0

    moment_resp = SnackMomentResponse(
        id=moment.id,
        event_id=moment.event_id,
        name=moment.name,
        date=moment.date,
        start_time=moment.start_time,
        end_time=moment.end_time,
        is_active=moment.is_active,
        target_roles=moment.target_roles or "ALL",
        total_budgeted=budgeted,
        notes=moment.notes,
        created_at=moment.created_at,
        total_delivered=delivered_count,
        percentage_consumed=round(pct, 1),
    )

    return SnackMomentReportResponse(
        moment=moment_resp,
        delivered_count=delivered_count,
        total_eligible=total_eligible,
        deliveries=deliveries_items,
    )


async def get_eligible_participants_count(
    db: AsyncSession,
    event_id: int,
    target_roles: Optional[str] = "ALL",
) -> int:
    """Calcula a quantidade de participantes elegíveis no evento conforme o público-alvo selecionado."""
    target = (target_roles or "ALL").strip().upper()
    if target == "ALL":
        stmt = select(func.count(distinct(EventParticipant.id))).where(
            EventParticipant.event_id == event_id,
            EventParticipant.deleted_at.is_(None),
        )
        res = await db.execute(stmt)
        return res.scalar_one() or 0

    allowed_roles = [r.strip().upper() for r in target.split(",") if r.strip()]
    if not allowed_roles:
        return 0

    # 1. Possui o papel em EventParticipantRole para este evento
    has_event_role = exists(
        select(1).where(
            EventParticipantRole.person_id == EventParticipant.person_id,
            EventParticipantRole.event_id == event_id,
            EventParticipantRole.role.in_(allowed_roles),
            EventParticipantRole.deleted_at.is_(None),
        )
    )

    # 2. Possui o papel direto na pessoa (Person.role)
    has_person_role = exists(
        select(1).where(
            Person.id == EventParticipant.person_id,
            Person.role.in_(allowed_roles),
            Person.deleted_at.is_(None),
        )
    )

    # 3. Possui o papel na gestão do evento (EventAdministrator.role)
    has_admin_role = exists(
        select(1).where(
            EventAdministrator.person_id == EventParticipant.person_id,
            EventAdministrator.event_id == event_id,
            EventAdministrator.role.in_(allowed_roles),
            EventAdministrator.deleted_at.is_(None),
        )
    )

    stmt = select(func.count(distinct(EventParticipant.id))).where(
        EventParticipant.event_id == event_id,
        EventParticipant.deleted_at.is_(None),
        or_(has_event_role, has_person_role, has_admin_role),
    )
    res = await db.execute(stmt)
    return res.scalar_one() or 0

