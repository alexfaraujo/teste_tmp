"""Evaluator allocation and qualification service (Regra BR-10)."""

from collections import defaultdict
from datetime import datetime, timezone
from typing import Dict, List, Optional, Set, Tuple
from fastapi import HTTPException, status
from sqlalchemy import and_, func, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.models.enums import AllocationStatus, AllocationType, EducationLevelEnum, EvaluationStatus, ProjectMemberRole, ProjectStatus, UserRole
from app.models.event import Event
from app.models.knowledge_area import KnowledgeArea, Subarea
from app.models.person import EventParticipant, EventParticipantRole, Person, PersonSubarea, PersonEducationLevel
from app.models.project import Project, ProjectMember
from app.models.evaluation import Evaluation, EvaluatorAllocation
from app.schemas.allocation import (
    AllocatedProjectItem,
    AllocationResponse,
    AutoBalanceRequest,
    AutoBalanceSummaryResponse,
    EvaluatorCheckinAllocationResponse,
    EvaluatorListItem,
    EvaluatorQualificationRequest,
    EvaluatorQualificationResponse,
    EvaluatorScanCheckinRequest,
    EvaluatorSubareaItem,
    ManualAllocationRequest
)


async def qualify_evaluator_subareas(
    db: AsyncSession,
    payload: EvaluatorQualificationRequest
) -> EvaluatorQualificationResponse:
    """
    Cadastra ou atualiza as subáreas temáticas de especialidade de um avaliador para o evento (Regra BR-10).
    """
    # 1. Verificar avaliador
    stmt_person = select(Person).where(
        Person.id == payload.person_id,
        Person.deleted_at.is_(None)
    )
    res_person = await db.execute(stmt_person)
    person = res_person.scalar_one_or_none()
    if not person:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Avaliador não encontrado ou inativo."
        )

    # 2. Verificar evento
    stmt_event = select(Event).where(
        Event.id == payload.event_id,
        Event.deleted_at.is_(None)
    )
    res_event = await db.execute(stmt_event)
    event = res_event.scalar_one_or_none()
    if not event:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Edição do evento não encontrada."
        )

    # 3. Validar todas as subáreas
    stmt_subareas = select(Subarea).where(
        Subarea.id.in_(payload.subarea_ids),
        Subarea.deleted_at.is_(None)
    )
    res_subareas = await db.execute(stmt_subareas)
    found_subareas = res_subareas.scalars().all()
    if len(found_subareas) != len(set(payload.subarea_ids)):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Uma ou mais subáreas informadas são inválidas ou inexistentes."
        )

    # 4. Remover qualificações anteriores deste avaliador no evento
    stmt_existing = select(PersonSubarea).where(
        PersonSubarea.person_id == payload.person_id,
        PersonSubarea.event_id == payload.event_id
    )
    res_existing = await db.execute(stmt_existing)
    for old_qual in res_existing.scalars().all():
        await db.delete(old_qual)
    await db.flush()

    # 5. Inserir novas qualificações
    for subarea_id in set(payload.subarea_ids):
        new_qual = PersonSubarea(
            person_id=payload.person_id,
            subarea_id=subarea_id,
            event_id=payload.event_id
        )
        db.add(new_qual)

    await db.commit()

    return EvaluatorQualificationResponse(
        person_id=person.id,
        person_name=person.name,
        event_id=event.id,
        subarea_ids=payload.subarea_ids,
        message="Subáreas vinculadas ao avaliador com sucesso."
    )


async def allocate_evaluator_on_checkin(
    db: AsyncSession,
    event_id: int,
    evaluator_id: int
) -> EvaluatorCheckinAllocationResponse:
    """
    Alocação dinâmica e balanceada disparada no momento do check-in do avaliador (Regra BR-10).
    - Confirma a presença do avaliador no evento (EventParticipant).
    - Identifica as subáreas temáticas de especialidade do avaliador (PersonSubarea).
    - Busca os trabalhos daquela subárea que JÁ ESTÃO PRESENTES no evento (status == 'PRESENT').
    - Filtra impedimentos e conflitos de interesse (orientador/coorientador/membro da equipe).
    - Filtra trabalhos onde o avaliador já está alocado.
    - Ordena os trabalhos de forma ascendente pela quantidade atual de avaliadores atribuídos
      (prioriza trabalhos com menor número de avaliadores para manter a Regra de Ouro delta <= 1).
    - Cria as alocações até a capacidade restante do avaliador (event.max_projects_per_evaluator).
    """
    now = datetime.now(timezone.utc)

    # 1. Carregar evento
    stmt_event = select(Event).where(Event.id == event_id, Event.deleted_at.is_(None))
    res_event = await db.execute(stmt_event)
    event = res_event.scalar_one_or_none()
    if not event:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Edição do evento não encontrada."
        )

    # 2. Carregar avaliador
    stmt_person = select(Person).where(Person.id == evaluator_id, Person.deleted_at.is_(None))
    res_person = await db.execute(stmt_person)
    person = res_person.scalar_one_or_none()
    if not person:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Avaliador não encontrado ou inativo."
        )

    # 3. Registrar / Confirmar presença do avaliador (EventParticipant)
    stmt_part = select(EventParticipant).where(
        EventParticipant.event_id == event_id,
        EventParticipant.person_id == evaluator_id,
        EventParticipant.deleted_at.is_(None)
    )
    res_part = await db.execute(stmt_part)
    participant = res_part.scalar_one_or_none()

    was_already_checked_in = bool(participant and participant.evaluator_presence_confirmed)

    if not participant:
        participant = EventParticipant(
            event_id=event_id,
            person_id=evaluator_id,
            tshirt_size="M",
            presence_confirmed=False,
            presence_confirmed_at=None,
            evaluator_presence_confirmed=True,
            evaluator_presence_confirmed_at=now
        )
        db.add(participant)
    else:
        # Confirma estritamente a presença na Sala dos Avaliadores (Comissão Científica).
        # O credenciamento geral como participante (presence_confirmed) e entrega de kit
        # são controlados exclusivamente pela equipe de recepção/logística.
        participant.evaluator_presence_confirmed = True
        if not participant.evaluator_presence_confirmed_at:
            participant.evaluator_presence_confirmed_at = now

    await db.flush()

    # 4. Obter subáreas e níveis de ensino do avaliador
    stmt_quals = select(PersonSubarea).where(
        PersonSubarea.event_id == event_id,
        PersonSubarea.person_id == evaluator_id,
        PersonSubarea.deleted_at.is_(None)
    )
    res_quals = await db.execute(stmt_quals)
    qualifications = res_quals.scalars().all()
    subarea_ids = [q.subarea_id for q in qualifications]

    stmt_levels = select(PersonEducationLevel.education_level).where(
        PersonEducationLevel.event_id == event_id,
        PersonEducationLevel.person_id == evaluator_id,
        PersonEducationLevel.deleted_at.is_(None)
    )
    res_levels = await db.execute(stmt_levels)
    evaluator_levels = set(res_levels.scalars().all())

    # 5. Obter alocações já existentes do avaliador no evento (com dados dos projetos)
    stmt_my_allocs = select(EvaluatorAllocation).options(
        selectinload(EvaluatorAllocation.project).selectinload(Project.subarea).selectinload(Subarea.knowledge_area)
    ).where(
        EvaluatorAllocation.event_id == event_id,
        EvaluatorAllocation.evaluator_id == evaluator_id,
        EvaluatorAllocation.deleted_at.is_(None)
    )
    res_my_allocs = await db.execute(stmt_my_allocs)
    all_my_allocs = res_my_allocs.scalars().all()
    my_allocs = [a for a in all_my_allocs if a.status != AllocationStatus.CANCELLED]
    already_allocated_project_ids = {a.project_id for a in all_my_allocs}
    active_allocated_project_ids = {a.project_id for a in my_allocs}

    existing_items: List[AllocatedProjectItem] = []
    if active_allocated_project_ids:
        stmt_counts = select(
            EvaluatorAllocation.project_id,
            func.count(EvaluatorAllocation.id)
        ).where(
            EvaluatorAllocation.event_id == event_id,
            EvaluatorAllocation.project_id.in_(active_allocated_project_ids),
            EvaluatorAllocation.status != AllocationStatus.CANCELLED,
            EvaluatorAllocation.deleted_at.is_(None)
        ).group_by(EvaluatorAllocation.project_id)
        res_counts = await db.execute(stmt_counts)
        existing_proj_counts = dict(res_counts.all())

        for a in my_allocs:
            p = a.project
            if p:
                existing_items.append(
                    AllocatedProjectItem(
                        project_id=p.id,
                        project_title=p.title,
                        booth_number=p.booth_number,
                        subarea_name=p.subarea.name if p.subarea else "Geral",
                        area_name=p.subarea.knowledge_area.name if (p.subarea and p.subarea.knowledge_area) else None,
                        current_evaluators_count=existing_proj_counts.get(p.id, 1)
                    )
                )

    if not subarea_ids:
        await db.commit()
        msg = (
            f"O avaliador {person.name} já havia realizado check-in, mas não possui subáreas vinculadas."
            if was_already_checked_in
            else f"Presença de {person.name} confirmada, mas o avaliador não possui subáreas vinculadas."
        )
        return EvaluatorCheckinAllocationResponse(
            evaluator_id=person.id,
            evaluator_name=person.name,
            event_id=event.id,
            presence_confirmed=participant.presence_confirmed,
            evaluator_presence_confirmed=True,
            already_checked_in=was_already_checked_in,
            kit_delivered=participant.kit_delivered,
            tshirt_size=participant.tshirt_size,
            allocated_projects_count=len(existing_items),
            allocated_projects=existing_items,
            message=msg
        )

    capacity = event.max_projects_per_evaluator - len(my_allocs)
    if capacity <= 0:
        await db.commit()
        msg = (
            f"Check-in de avaliador já realizado anteriormente para {person.name}. "
            f"Atualmente possui {len(existing_items)} trabalho(s) alocado(s) (limite de {event.max_projects_per_evaluator})."
            if was_already_checked_in
            else f"Presença de {person.name} confirmada. Avaliador já atingiu o limite de {event.max_projects_per_evaluator} trabalhos."
        )
        return EvaluatorCheckinAllocationResponse(
            evaluator_id=person.id,
            evaluator_name=person.name,
            event_id=event.id,
            presence_confirmed=participant.presence_confirmed,
            evaluator_presence_confirmed=True,
            already_checked_in=was_already_checked_in,
            kit_delivered=participant.kit_delivered,
            tshirt_size=participant.tshirt_size,
            allocated_projects_count=len(existing_items),
            allocated_projects=existing_items,
            message=msg
        )

    # 6. Carregar projetos PRESENTES nas subáreas do avaliador (respeitando níveis de ensino habilitados)
    stmt_projects = select(Project).options(
        selectinload(Project.members),
        selectinload(Project.subarea).selectinload(Subarea.knowledge_area)
    ).where(
        Project.event_id == event.id,
        Project.status == ProjectStatus.PRESENT,
        Project.subarea_id.in_(subarea_ids),
        Project.deleted_at.is_(None)
    )
    if evaluator_levels:
        stmt_projects = stmt_projects.where(Project.education_level.in_(evaluator_levels))
    res_projects = await db.execute(stmt_projects)
    present_projects = res_projects.scalars().all()

    # 6.1 Mapear conflitos de categoria (Grande Área + Nível) caso o avaliador oriente projetos no evento
    stmt_adv = (
        select(Project)
        .join(ProjectMember, ProjectMember.project_id == Project.id)
        .options(selectinload(Project.subarea))
        .where(
            Project.event_id == event.id,
            Project.deleted_at.is_(None),
            ProjectMember.person_id == evaluator_id,
            ProjectMember.role.in_([ProjectMemberRole.ADVISOR, ProjectMemberRole.COADVISOR]),
            ProjectMember.deleted_at.is_(None)
        )
    )
    res_adv = await db.execute(stmt_adv)
    advisor_conflict_categories: Set[Tuple[int, EducationLevelEnum]] = set()
    for adv_p in res_adv.scalars().all():
        if adv_p.subarea and adv_p.subarea.area_id:
            advisor_conflict_categories.add((adv_p.subarea.area_id, adv_p.education_level))

    # 7. Filtrar impedimentos e conflitos de interesse
    eligible_projects: List[Project] = []
    for proj in present_projects:
        if proj.id in already_allocated_project_ids:
            continue
        # Conflito Direto: membro da equipe do projeto
        is_direct_conflict = any(member.person_id == evaluator_id for member in proj.members)
        if is_direct_conflict:
            continue
        # Conflito de Categoria: mesma Grande Área e Nível de projeto orientado
        proj_area_id = proj.subarea.area_id if proj.subarea else None
        if proj_area_id and (proj_area_id, proj.education_level) in advisor_conflict_categories:
            continue
        eligible_projects.append(proj)

    if not eligible_projects:
        await db.commit()
        if was_already_checked_in:
            if existing_items:
                msg = (
                    f"Check-in já realizado anteriormente para {person.name}. "
                    f"Atualmente possui {len(existing_items)} trabalho(s) alocado(s). Nenhum novo trabalho compatível no momento."
                )
            else:
                msg = (
                    f"Check-in já realizado anteriormente para {person.name}. "
                    f"Nenhum trabalho compatível presente para alocação no momento."
                )
        else:
            msg = f"Presença de {person.name} confirmada. Nenhum trabalho presente disponível para alocação no momento."

        return EvaluatorCheckinAllocationResponse(
            evaluator_id=person.id,
            evaluator_name=person.name,
            event_id=event.id,
            presence_confirmed=participant.presence_confirmed,
            evaluator_presence_confirmed=True,
            already_checked_in=was_already_checked_in,
            kit_delivered=participant.kit_delivered,
            tshirt_size=participant.tshirt_size,
            allocated_projects_count=len(existing_items),
            allocated_projects=existing_items,
            message=msg
        )

    # 8. Calcular contagem atual de avaliadores por projeto para manter a Regra de Ouro (delta <= 1)
    eligible_ids = [p.id for p in eligible_projects]
    stmt_alloc_counts = select(
        EvaluatorAllocation.project_id
    ).where(
        EvaluatorAllocation.event_id == event.id,
        EvaluatorAllocation.project_id.in_(eligible_ids),
        EvaluatorAllocation.status != AllocationStatus.CANCELLED,
        EvaluatorAllocation.deleted_at.is_(None)
    )
    res_alloc_counts = await db.execute(stmt_alloc_counts)
    current_counts: Dict[int, int] = defaultdict(int)
    for row in res_alloc_counts.scalars().all():
        current_counts[row] += 1

    # 9. Ordenar candidatos: menor número de avaliadores atribuídos primeiro, depois id
    eligible_projects.sort(key=lambda p: (current_counts[p.id], p.id))

    # 10. Alocar até a capacidade restante
    to_allocate = eligible_projects[:capacity]
    new_items: List[AllocatedProjectItem] = []

    for proj in to_allocate:
        alloc = EvaluatorAllocation(
            event_id=event.id,
            project_id=proj.id,
            evaluator_id=evaluator_id,
            allocation_type=AllocationType.AUTOMATIC_CHECKIN,
            status=AllocationStatus.PENDING,
            allocated_at=now
        )
        db.add(alloc)
        new_items.append(
            AllocatedProjectItem(
                project_id=proj.id,
                project_title=proj.title,
                booth_number=proj.booth_number,
                subarea_name=proj.subarea.name if proj.subarea else "Geral",
                area_name=proj.subarea.knowledge_area.name if (proj.subarea and proj.subarea.knowledge_area) else None,
                current_evaluators_count=current_counts[proj.id] + 1
            )
        )

    all_items = existing_items + new_items
    await db.commit()

    if was_already_checked_in:
        msg = (
            f"Check-in já realizado anteriormente para {person.name}. "
            f"{len(new_items)} novo(s) trabalho(s) atribuído(s). Total: {len(all_items)} trabalho(s) alocado(s)."
        )
    else:
        msg = f"Presença de {person.name} na Sala dos Avaliadores confirmada com sucesso! {len(all_items)} trabalho(s) alocado(s) dinamicamente."

    return EvaluatorCheckinAllocationResponse(
        evaluator_id=person.id,
        evaluator_name=person.name,
        event_id=event.id,
        presence_confirmed=participant.presence_confirmed,
        evaluator_presence_confirmed=True,
        already_checked_in=was_already_checked_in,
        kit_delivered=participant.kit_delivered,
        tshirt_size=participant.tshirt_size,
        allocated_projects_count=len(all_items),
        allocated_projects=all_items,
        message=msg
    )


async def scan_evaluator_checkin(
    db: AsyncSession,
    payload: EvaluatorScanCheckinRequest
) -> EvaluatorCheckinAllocationResponse:
    """
    Check-in presencial do avaliador na Sala dos Avaliadores via código de barras, QR code ou CPF (Regra BR-10).
    - Localiza a pessoa.
    - Valida se possui papel de EVALUATOR nesta edição do evento.
    - Confirma presença física e presença de avaliador.
    - Executa alocação dinâmica imediata de projetos.
    """
    from app.services.logistics_service import _get_person_lookup_condition

    # 1. Localizar Person
    stmt_person = select(Person).where(
        _get_person_lookup_condition(payload.barcode),
        Person.deleted_at.is_(None)
    )
    res_person = await db.execute(stmt_person)
    person = res_person.scalar_one_or_none()
    if not person:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Código de barras, QR code ou CPF não encontrado no sistema."
        )

    # 2. Verificar se a pessoa possui o papel de avaliador nesta edição do evento
    stmt_eval_role = select(EventParticipantRole).where(
        EventParticipantRole.event_id == payload.event_id,
        EventParticipantRole.person_id == person.id,
        EventParticipantRole.role == UserRole.EVALUATOR,
        EventParticipantRole.deleted_at.is_(None)
    )
    res_eval_role = await db.execute(stmt_eval_role)
    has_eval_role = (res_eval_role.scalar_one_or_none() is not None) or (person.role == UserRole.EVALUATOR)

    if not has_eval_role:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"{person.name} não possui cadastro com papel de Avaliador nesta edição do evento."
        )

    # 3. Executar o check-in na Sala dos Avaliadores e a alocação dinâmica
    return await allocate_evaluator_on_checkin(db, payload.event_id, person.id)


async def run_auto_balance_allocation(
    db: AsyncSession,
    payload: AutoBalanceRequest
) -> AutoBalanceSummaryResponse:
    """
    Algoritmo de Alocação Balanceada de Avaliadores (Momento 1 - Pós-Checkin Automatizado) (Regra BR-10).
    - Distribui avaliadores exclusivamente para projetos com presença confirmada (status = 'PRESENT').
    - Considera APENAS avaliadores com presença confirmada na Sala dos Avaliadores (evaluator_presence_confirmed = True).
    - Emparelha subáreas temáticas (projects.subarea_id == evaluators.subarea_id).
    - Respeita o teto de trabalhos por avaliador (event.max_projects_per_evaluator).
    - Bloqueia conflitos de interesse (orientador/coorientador/membro não pode avaliar trabalho próprio).
    - Regra de Ouro: a diferença de avaliadores entre quaisquer dois trabalhos da mesma subárea
      não pode exceder 1 (delta <= 1).
    """
    # 1. Carregar evento
    stmt_event = select(Event).where(
        Event.id == payload.event_id,
        Event.deleted_at.is_(None)
    )
    res_event = await db.execute(stmt_event)
    event = res_event.scalar_one_or_none()
    if not event:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Edição do evento não encontrada."
        )

    # 2. Carregar projetos PRESENTES com seus integrantes e subárea
    stmt_projects = select(Project).options(
        selectinload(Project.members),
        selectinload(Project.subarea)
    ).where(
        Project.event_id == event.id,
        Project.status == ProjectStatus.PRESENT,
        Project.deleted_at.is_(None)
    ).order_by(Project.id)
    res_projects = await db.execute(stmt_projects)
    present_projects = res_projects.scalars().all()

    if not present_projects:
        return AutoBalanceSummaryResponse(
            event_id=event.id,
            present_projects_count=0,
            evaluators_count=0,
            total_allocations_created=0,
            golden_rule_satisfied=True,
            allocations_per_subarea={},
            message="Nenhum projeto com presença confirmada (PRESENT) encontrado para alocação."
        )

    # 3. Mapa de conflitos de interesse por projeto (conflito direto)
    conflict_evaluators_by_project: Dict[int, Set[int]] = defaultdict(set)
    for proj in present_projects:
        for member in proj.members:
            conflict_evaluators_by_project[proj.id].add(member.person_id)

    # 3.1 Mapa de conflitos de categoria (Grande Área + Nível de Ensino) para orientadores/coorientadores
    stmt_advisor_members = (
        select(ProjectMember.person_id, Project)
        .join(Project, Project.id == ProjectMember.project_id)
        .options(selectinload(Project.subarea))
        .where(
            Project.event_id == event.id,
            Project.deleted_at.is_(None),
            ProjectMember.role.in_([ProjectMemberRole.ADVISOR, ProjectMemberRole.COADVISOR]),
            ProjectMember.deleted_at.is_(None)
        )
    )
    res_adv_members = await db.execute(stmt_advisor_members)
    advisor_conflicts_by_person: Dict[int, Set[Tuple[int, EducationLevelEnum]]] = defaultdict(set)
    for person_id, adv_proj in res_adv_members.all():
        if adv_proj.subarea and adv_proj.subarea.area_id:
            advisor_conflicts_by_person[person_id].add((adv_proj.subarea.area_id, adv_proj.education_level))

    # 4. Carregar avaliadores qualificados por subárea QUE JÁ CONFIRMARAM PRESENÇA NA SALA DOS AVALIADORES
    stmt_quals = (
        select(PersonSubarea)
        .join(
            EventParticipant,
            and_(
                EventParticipant.event_id == event.id,
                EventParticipant.person_id == PersonSubarea.person_id,
                EventParticipant.evaluator_presence_confirmed.is_(True),
                EventParticipant.deleted_at.is_(None)
            )
        )
        .where(
            PersonSubarea.event_id == event.id,
            PersonSubarea.deleted_at.is_(None)
        )
    )
    res_quals = await db.execute(stmt_quals)
    qualifications = res_quals.scalars().all()

    evaluators_by_subarea: Dict[int, List[int]] = defaultdict(list)
    all_evaluators: Set[int] = set()
    for q in qualifications:
        evaluators_by_subarea[q.subarea_id].append(q.person_id)
        all_evaluators.add(q.person_id)

    # Carregar níveis de ensino habilitados por avaliador
    stmt_levels = select(PersonEducationLevel).where(
        PersonEducationLevel.event_id == event.id,
        PersonEducationLevel.deleted_at.is_(None)
    )
    res_levels = await db.execute(stmt_levels)
    evaluator_levels_map: Dict[int, Set[EducationLevelEnum]] = defaultdict(set)
    for l in res_levels.scalars().all():
        evaluator_levels_map[l.person_id].add(l.education_level)

    if not all_evaluators:
        return AutoBalanceSummaryResponse(
            event_id=event.id,
            present_projects_count=len(present_projects),
            evaluators_count=0,
            total_allocations_created=0,
            golden_rule_satisfied=True,
            allocations_per_subarea={},
            message="Nenhum avaliador com presença confirmada na Sala dos Avaliadores encontrado para rebalanceamento."
        )

    # 5. Carregar alocações já existentes no evento (ativas e canceladas)
    stmt_allocs = select(EvaluatorAllocation).where(
        EvaluatorAllocation.event_id == event.id,
        EvaluatorAllocation.deleted_at.is_(None)
    )
    res_allocs = await db.execute(stmt_allocs)
    existing_allocs = res_allocs.scalars().all()

    evaluator_load: Dict[int, int] = defaultdict(int)
    project_allocations: Dict[int, Set[int]] = defaultdict(set)
    project_all_evaluators: Dict[int, Set[int]] = defaultdict(set)
    for alloc in existing_allocs:
        project_all_evaluators[alloc.project_id].add(alloc.evaluator_id)
        if alloc.status != AllocationStatus.CANCELLED:
            evaluator_load[alloc.evaluator_id] += 1
            project_allocations[alloc.project_id].add(alloc.evaluator_id)

    # 6. Agrupar projetos presentes por subárea
    projects_by_subarea: Dict[int, List[Project]] = defaultdict(list)
    for proj in present_projects:
        projects_by_subarea[proj.subarea_id].append(proj)

    total_created = 0
    golden_rule_satisfied = True
    allocations_per_subarea: Dict[str, int] = {}

    # 7. Executar alocação balanceada por subárea com garantia da Regra de Ouro
    for subarea_id, sub_projects in projects_by_subarea.items():
        subarea_name = sub_projects[0].subarea.name if sub_projects[0].subarea else f"Subarea #{subarea_id}"
        candidates = evaluators_by_subarea.get(subarea_id, [])

        while True:
            # Calcular contagem atual de alocações por projeto na subárea
            counts = [len(project_allocations[p.id]) for p in sub_projects]
            min_count = min(counts)
            
            # Identificar projetos que ainda estão no piso mínimo
            eligible_projects = [p for p in sub_projects if len(project_allocations[p.id]) == min_count]
            
            round_allocated = 0
            cannot_allocate_for_some = False

            for p in eligible_projects:
                p_area_id = p.subarea.area_id if p.subarea else None
                # Filtrar avaliadores disponíveis sem conflito direto ou de categoria, sem alocação prévia, com carga disponível e nível de ensino compatível
                available = [
                    e for e in candidates
                    if e not in project_all_evaluators[p.id]
                    and e not in conflict_evaluators_by_project[p.id]
                    and not (p_area_id and (p_area_id, p.education_level) in advisor_conflicts_by_person[e])
                    and evaluator_load[e] < event.max_projects_per_evaluator
                    and (not evaluator_levels_map[e] or p.education_level in evaluator_levels_map[e])
                ]
                if available:
                    # Escolher o avaliador com a menor carga atual para máxima equidade
                    available.sort(key=lambda e: (evaluator_load[e], e))
                    chosen_evaluator_id = available[0]

                    new_alloc = EvaluatorAllocation(
                        event_id=event.id,
                        project_id=p.id,
                        evaluator_id=chosen_evaluator_id,
                        allocation_type=AllocationType.AUTOMATIC_CHECKIN,
                        status=AllocationStatus.PENDING,
                        allocated_at=datetime.now(timezone.utc)
                    )
                    db.add(new_alloc)
                    project_allocations[p.id].add(chosen_evaluator_id)
                    project_all_evaluators[p.id].add(chosen_evaluator_id)
                    evaluator_load[chosen_evaluator_id] += 1
                    round_allocated += 1
                    total_created += 1
                else:
                    cannot_allocate_for_some = True

            # Se ninguém conseguiu alocar nesta rodada, encerramos a subárea
            if round_allocated == 0:
                break

            # Se algum projeto não pôde receber avaliador enquanto outros receberam,
            # os outros foram para min_count + 1. Não podemos iniciar outra rodada que
            # levaria projetos a min_count + 2 enquanto este ficou em min_count (violaria delta <= 1).
            if cannot_allocate_for_some:
                break

        # Verificação final da Regra de Ouro para a subárea
        final_counts = [len(project_allocations[p.id]) for p in sub_projects]
        if final_counts and (max(final_counts) - min(final_counts) > 1):
            golden_rule_satisfied = False

        allocations_per_subarea[subarea_name] = sum(len(project_allocations[p.id]) for p in sub_projects)

    await db.commit()

    return AutoBalanceSummaryResponse(
        event_id=event.id,
        present_projects_count=len(present_projects),
        evaluators_count=len(all_evaluators),
        total_allocations_created=total_created,
        golden_rule_satisfied=golden_rule_satisfied,
        allocations_per_subarea=allocations_per_subarea,
        message=(
            f"Alocação balanceada concluída com sucesso. {total_created} novas atribuições criadas. "
            f"Regra de Ouro (delta <= 1) {'cumprida rigorosamente' if golden_rule_satisfied else 'não atendida'}."
        )
    )


async def manual_allocate(
    db: AsyncSession,
    payload: ManualAllocationRequest
) -> AllocationResponse:
    """
    Alocação manual ou remanejamento pontual de avaliador pelo Administrador (Momento 2) (Regra BR-10).
    Valida:
    - Existência do projeto e pertencimento ao evento;
    - Existência do avaliador e papel EVALUATOR;
    - Existência de subáreas cadastradas para o avaliador (PersonSubarea);
    - Compatibilidade estrita de subárea: project.subarea_id deve pertencer às subáreas do avaliador;
    - Inexistência de conflito de interesses (orientador/coorientador/membro da equipe);
    - Inexistência de alocação ativa duplicada.
    """
    # 1. Carregar projeto com integrantes e subárea (com grande área)
    stmt_proj = select(Project).options(
        selectinload(Project.members),
        selectinload(Project.subarea).selectinload(Subarea.knowledge_area)
    ).where(
        Project.id == payload.project_id,
        Project.event_id == payload.event_id,
        Project.deleted_at.is_(None)
    )
    res_proj = await db.execute(stmt_proj)
    project = res_proj.scalar_one_or_none()
    if not project:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Projeto não encontrado ou não pertence a esta edição do evento."
        )

    # 2. Carregar avaliador
    stmt_eval = select(Person).where(
        Person.id == payload.evaluator_id,
        Person.deleted_at.is_(None)
    )
    res_eval = await db.execute(stmt_eval)
    evaluator = res_eval.scalar_one_or_none()
    if not evaluator:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Avaliador não encontrado ou inativo."
        )

    # 3. Bloquear conflito de interesses direto (orientador/coorientador/membro da equipe do próprio projeto)
    for member in project.members:
        if member.person_id == evaluator.id:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Conflito de interesses: o avaliador é orientador ou membro da equipe deste projeto."
            )

    # 3.1 Validar conflito de interesses por categoria (mesma Grande Área + mesmo Nível de Ensino)
    proj_area_id = project.subarea.area_id if project.subarea else None
    if proj_area_id:
        stmt_conflicting_advisor = (
            select(Project)
            .join(ProjectMember, ProjectMember.project_id == Project.id)
            .options(selectinload(Project.subarea))
            .where(
                Project.event_id == payload.event_id,
                Project.deleted_at.is_(None),
                ProjectMember.person_id == evaluator.id,
                ProjectMember.role.in_([ProjectMemberRole.ADVISOR, ProjectMemberRole.COADVISOR]),
                ProjectMember.deleted_at.is_(None),
                Project.education_level == project.education_level
            )
        )
        res_conflicting = await db.execute(stmt_conflicting_advisor)
        conflicting_projects = [
            p for p in res_conflicting.scalars().all()
            if p.subarea and p.subarea.area_id == proj_area_id
        ]
        if conflicting_projects:
            first_conflicting = conflicting_projects[0]
            area_name = project.area_name or (project.subarea.knowledge_area.name if project.subarea and project.subarea.knowledge_area else "Grande Área")
            edu_name = project.education_level.value if hasattr(project.education_level, "value") else str(project.education_level)
            if not payload.override_conflict:
                raise HTTPException(
                    status_code=status.HTTP_409_CONFLICT,
                    detail=(
                        f"Conflito de interesses por categoria: O avaliador '{evaluator.name}' é orientador/coorientador "
                        f"do trabalho '{first_conflicting.title}' na mesma Grande Área ({area_name}) e Nível ({edu_name}). "
                        f"Para autorizar esta alocação excepcional, confirme a autorização de override."
                    )
                )

    # 4. Validar se possui papel de avaliador (no evento ou perfil global)
    stmt_role = select(EventParticipantRole).where(
        EventParticipantRole.event_id == payload.event_id,
        EventParticipantRole.person_id == evaluator.id,
        EventParticipantRole.role == UserRole.EVALUATOR,
        EventParticipantRole.deleted_at.is_(None)
    )
    has_eval_role = (await db.execute(stmt_role)).scalar_one_or_none()
    if not has_eval_role and evaluator.role != UserRole.EVALUATOR:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"A pessoa '{evaluator.name}' não possui o papel de Avaliador atribuído neste evento."
        )

    # 5. Validar subáreas de qualificação do avaliador (Regra estrita BR-10)
    stmt_quals = select(PersonSubarea).where(
        PersonSubarea.event_id == payload.event_id,
        PersonSubarea.person_id == evaluator.id,
        PersonSubarea.deleted_at.is_(None)
    )
    res_quals = await db.execute(stmt_quals)
    qualifications = res_quals.scalars().all()
    evaluator_subarea_ids = {q.subarea_id for q in qualifications}

    if not evaluator_subarea_ids:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"O avaliador '{evaluator.name}' não possui nenhuma subárea de avaliação cadastrada neste evento. Vincule ao menos uma subárea antes de realizar alocações."
        )

    if project.subarea_id not in evaluator_subarea_ids:
        sub_name = project.subarea.name if project.subarea else f"ID {project.subarea_id}"
        area_name = project.subarea.knowledge_area.name if (project.subarea and project.subarea.knowledge_area) else ""
        area_info = f" (Área: {area_name})" if area_name else ""
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Incompatibilidade de especialidade: o trabalho #{project.id} pertence à subárea '{sub_name}'{area_info}, mas o avaliador '{evaluator.name}' não possui qualificação nesta subárea."
        )

    # 5.1 Validar nível de ensino do trabalho e qualificação do avaliador
    stmt_levels = select(PersonEducationLevel.education_level).where(
        PersonEducationLevel.event_id == payload.event_id,
        PersonEducationLevel.person_id == evaluator.id,
        PersonEducationLevel.deleted_at.is_(None)
    )
    res_levels = await db.execute(stmt_levels)
    evaluator_levels = set(res_levels.scalars().all())

    if evaluator_levels and project.education_level not in evaluator_levels:
        lvl_name = project.education_level.value if hasattr(project.education_level, "value") else str(project.education_level)
        allowed_str = ", ".join(l.value if hasattr(l, "value") else str(l) for l in sorted(evaluator_levels, key=lambda x: str(x)))
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=(
                f"Incompatibilidade de nível de ensino: o trabalho #{project.id} pertence ao nível '{lvl_name}', "
                f"mas o avaliador '{evaluator.name}' está habilitado apenas para o(s) nível(is): {allowed_str}."
            )
        )

    # 6. Verificar se já existe alocação ativa ou prévia
    stmt_existing = select(EvaluatorAllocation).options(
        selectinload(EvaluatorAllocation.project).selectinload(Project.subarea).selectinload(Subarea.knowledge_area),
        selectinload(EvaluatorAllocation.evaluator)
    ).where(
        EvaluatorAllocation.project_id == project.id,
        EvaluatorAllocation.evaluator_id == evaluator.id,
        EvaluatorAllocation.deleted_at.is_(None)
    )
    res_existing = await db.execute(stmt_existing)
    existing = res_existing.scalar_one_or_none()
    if existing:
        if existing.status == AllocationStatus.COMPLETED:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Este avaliador já concluiu a avaliação deste trabalho."
            )
        elif existing.status != AllocationStatus.CANCELLED:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Avaliador já está alocado para este projeto."
            )
        else:
            # Reativar alocação que havia sido cancelada anteriormente
            existing.status = AllocationStatus.PENDING
            existing.allocation_type = AllocationType.MANUAL_ADMIN
            existing.allocated_at = datetime.now(timezone.utc)
            await db.commit()
            await db.refresh(existing)
            allocation = existing
    else:
        # 7. Criar alocação manual
        allocation = EvaluatorAllocation(
            event_id=payload.event_id,
            project_id=project.id,
            evaluator_id=evaluator.id,
            allocation_type=AllocationType.MANUAL_ADMIN,
            status=AllocationStatus.PENDING,
            allocated_at=datetime.now(timezone.utc)
        )
        db.add(allocation)
        await db.commit()
        await db.refresh(allocation)

    return AllocationResponse(
        id=allocation.id,
        event_id=allocation.event_id,
        project_id=project.id,
        project_title=project.title,
        booth_number=project.booth_number,
        subarea_name=project.subarea.name if project.subarea else "Geral",
        area_name=project.subarea.knowledge_area.name if (project.subarea and project.subarea.knowledge_area) else None,
        evaluator_id=evaluator.id,
        evaluator_name=evaluator.name,
        allocation_type=allocation.allocation_type,
        status=allocation.status,
        allocated_at=allocation.allocated_at
    )


async def cancel_allocation(
    db: AsyncSession,
    allocation_id: int
) -> AllocationResponse:
    """
    Cancela uma alocação de avaliador (se a avaliação ainda não tiver sido concluída).
    """
    stmt = select(EvaluatorAllocation).options(
        selectinload(EvaluatorAllocation.project).selectinload(Project.subarea).selectinload(Subarea.knowledge_area),
        selectinload(EvaluatorAllocation.evaluator),
        selectinload(EvaluatorAllocation.evaluation)
    ).where(
        EvaluatorAllocation.id == allocation_id,
        EvaluatorAllocation.deleted_at.is_(None)
    )
    res = await db.execute(stmt)
    alloc = res.scalar_one_or_none()
    if not alloc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Alocação não encontrada."
        )

    if alloc.status == AllocationStatus.COMPLETED:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Não é possível cancelar uma alocação cuja avaliação já foi concluída."
        )
    if alloc.status == AllocationStatus.CANCELLED:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Esta alocação já se encontra cancelada."
        )

    # Verificar se existe uma avaliação associada diretamente à alocação
    if alloc.evaluation and (
        alloc.evaluation.status == EvaluationStatus.COMPLETED
        or alloc.evaluation.evaluated_at is not None
    ):
        alloc.status = AllocationStatus.COMPLETED
        await db.commit()
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Não é possível cancelar uma alocação cuja avaliação já foi realizada."
        )

    # Verificação adicional por (project_id, evaluator_id) caso a avaliação não tenha allocation_id preenchido
    stmt_eval = select(Evaluation).where(
        Evaluation.project_id == alloc.project_id,
        Evaluation.evaluator_id == alloc.evaluator_id,
        Evaluation.deleted_at.is_(None)
    )
    res_eval = await db.execute(stmt_eval)
    existing_eval = res_eval.scalar_one_or_none()
    if existing_eval and (
        existing_eval.status == EvaluationStatus.COMPLETED
        or existing_eval.evaluated_at is not None
    ):
        alloc.status = AllocationStatus.COMPLETED
        await db.commit()
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Não é possível cancelar uma alocação cuja avaliação já foi realizada."
        )

    alloc.status = AllocationStatus.CANCELLED
    await db.commit()
    await db.refresh(alloc)

    return AllocationResponse(
        id=alloc.id,
        event_id=alloc.event_id,
        project_id=alloc.project.id,
        project_title=alloc.project.title,
        booth_number=alloc.project.booth_number,
        subarea_name=alloc.project.subarea.name if alloc.project.subarea else "Geral",
        area_name=alloc.project.subarea.knowledge_area.name if (alloc.project.subarea and alloc.project.subarea.knowledge_area) else None,
        evaluator_id=alloc.evaluator.id,
        evaluator_name=alloc.evaluator.name,
        allocation_type=alloc.allocation_type,
        status=alloc.status,
        allocated_at=alloc.allocated_at
    )


async def list_allocations(
    db: AsyncSession,
    event_id: int,
    project_id: Optional[int] = None,
    evaluator_id: Optional[int] = None,
    status: Optional[str] = None
) -> List[AllocationResponse]:
    """
    Lista alocações com filtros opcionais por projeto, avaliador ou status.
    """
    stmt = select(EvaluatorAllocation).options(
        selectinload(EvaluatorAllocation.project).selectinload(Project.subarea).selectinload(Subarea.knowledge_area),
        selectinload(EvaluatorAllocation.evaluator)
    ).where(
        EvaluatorAllocation.event_id == event_id,
        EvaluatorAllocation.deleted_at.is_(None)
    ).order_by(EvaluatorAllocation.id)

    if project_id:
        stmt = stmt.where(EvaluatorAllocation.project_id == project_id)
    if evaluator_id:
        stmt = stmt.where(EvaluatorAllocation.evaluator_id == evaluator_id)
    if status:
        stmt = stmt.where(EvaluatorAllocation.status == status)

    res = await db.execute(stmt)
    allocations = res.scalars().all()

    return [
        AllocationResponse(
            id=a.id,
            event_id=a.event_id,
            project_id=a.project.id,
            project_title=a.project.title,
            booth_number=a.project.booth_number,
            subarea_name=a.project.subarea.name if a.project.subarea else "Geral",
            area_name=a.project.subarea.knowledge_area.name if (a.project.subarea and a.project.subarea.knowledge_area) else None,
            evaluator_id=a.evaluator.id,
            evaluator_name=a.evaluator.name,
            allocation_type=a.allocation_type,
            status=a.status,
            allocated_at=a.allocated_at
        )
        for a in allocations
    ]


async def list_event_evaluators(
    db: AsyncSession,
    event_id: int
) -> List[EvaluatorListItem]:
    """
    Lista todos os avaliadores cadastrados na edição com suas subáreas, presença e contagem de alocações ativas (BR-10).
    """
    # 1. Identificar IDs de pessoas vinculadas como avaliadores neste evento
    stmt_roles = select(EventParticipantRole.person_id).where(
        EventParticipantRole.event_id == event_id,
        EventParticipantRole.role == UserRole.EVALUATOR,
        EventParticipantRole.deleted_at.is_(None)
    )
    res_roles = await db.execute(stmt_roles)
    role_person_ids = set(res_roles.scalars().all())

    stmt_people_role = select(EventParticipant.person_id).join(
        Person, EventParticipant.person_id == Person.id
    ).where(
        EventParticipant.event_id == event_id,
        Person.role == UserRole.EVALUATOR,
        EventParticipant.deleted_at.is_(None),
        Person.deleted_at.is_(None)
    )
    res_people_role = await db.execute(stmt_people_role)
    people_role_ids = set(res_people_role.scalars().all())

    stmt_quals = select(PersonSubarea.person_id).where(
        PersonSubarea.event_id == event_id,
        PersonSubarea.deleted_at.is_(None)
    )
    res_quals = await db.execute(stmt_quals)
    qual_person_ids = set(res_quals.scalars().all())

    evaluator_ids = role_person_ids | people_role_ids | qual_person_ids
    if not evaluator_ids:
        return []

    # 2. Carregar dados das pessoas e dados de participante
    stmt_persons = select(Person, EventParticipant).join(
        EventParticipant,
        (Person.id == EventParticipant.person_id) & (EventParticipant.event_id == event_id) & (EventParticipant.deleted_at.is_(None)),
        isouter=True
    ).where(
        Person.id.in_(evaluator_ids),
        Person.deleted_at.is_(None)
    ).order_by(Person.name)
    res_persons = await db.execute(stmt_persons)
    person_rows = res_persons.all()

    # 3. Carregar subáreas dos avaliadores
    stmt_subs = select(
        PersonSubarea.person_id,
        Subarea.id.label("subarea_id"),
        Subarea.name.label("subarea_name"),
        KnowledgeArea.id.label("area_id"),
        KnowledgeArea.name.label("area_name")
    ).join(
        Subarea, PersonSubarea.subarea_id == Subarea.id
    ).join(
        KnowledgeArea, Subarea.area_id == KnowledgeArea.id
    ).where(
        PersonSubarea.event_id == event_id,
        PersonSubarea.person_id.in_(evaluator_ids),
        PersonSubarea.deleted_at.is_(None)
    ).order_by(KnowledgeArea.name, Subarea.name)
    res_subs = await db.execute(stmt_subs)
    sub_rows = res_subs.all()

    subareas_by_person: Dict[int, List[EvaluatorSubareaItem]] = {}
    for r in sub_rows:
        subareas_by_person.setdefault(r.person_id, []).append(
            EvaluatorSubareaItem(
                subarea_id=r.subarea_id,
                subarea_name=r.subarea_name,
                area_id=r.area_id,
                area_name=r.area_name
            )
        )

    # 4. Carregar níveis de ensino dos avaliadores
    stmt_levels = select(
        PersonEducationLevel.person_id,
        PersonEducationLevel.education_level
    ).where(
        PersonEducationLevel.event_id == event_id,
        PersonEducationLevel.person_id.in_(evaluator_ids),
        PersonEducationLevel.deleted_at.is_(None)
    )
    res_levels = await db.execute(stmt_levels)
    levels_by_person: Dict[int, List[EducationLevelEnum]] = defaultdict(list)
    for pid, lvl in res_levels.all():
        levels_by_person[pid].append(lvl)

    # 5. Contagem de alocações ativas
    stmt_alloc_count = select(
        EvaluatorAllocation.evaluator_id,
        func.count(EvaluatorAllocation.id)
    ).where(
        EvaluatorAllocation.event_id == event_id,
        EvaluatorAllocation.evaluator_id.in_(evaluator_ids),
        EvaluatorAllocation.status != AllocationStatus.CANCELLED,
        EvaluatorAllocation.deleted_at.is_(None)
    ).group_by(EvaluatorAllocation.evaluator_id)
    res_alloc_count = await db.execute(stmt_alloc_count)
    alloc_counts = dict(res_alloc_count.all())

    # 6. Montar lista de saída
    items: List[EvaluatorListItem] = []
    for person, part in person_rows:
        items.append(
            EvaluatorListItem(
                id=person.id,
                name=person.name,
                email=person.email,
                cpf=person.cpf,
                barcode=person.barcode,
                presence_confirmed=part.presence_confirmed if part else False,
                evaluator_presence_confirmed=part.evaluator_presence_confirmed if part else False,
                allocated_projects_count=alloc_counts.get(person.id, 0),
                education_levels=levels_by_person.get(person.id, []),
                subareas=subareas_by_person.get(person.id, [])
            )
        )

    return items
