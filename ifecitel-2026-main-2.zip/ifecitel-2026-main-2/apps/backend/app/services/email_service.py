"""Email service for sending access codes and system notifications via SMTP."""

import logging
import smtplib
from email.message import EmailMessage
from typing import Optional

from app.core.config import settings

logger = logging.getLogger(__name__)


class EmailService:
    """Serviço modular para envio de e-mails do sistema via SMTP."""

    @staticmethod
    def send_access_code(
        to_email: str,
        nome: str,
        codigo: str,
        system_name: str = "EasyEvent"
    ) -> bool:
        """
        Envia o código de acesso (OTP) por e-mail para o usuário.
        """
        try:
            msg = EmailMessage()
            msg.set_content(
                f"Olá {nome},\n\n"
                f"Seu código de acesso ao sistema {system_name} é: {codigo}\n\n"
                f"Guarde este código, pois ele é sua chave de acesso."
            )
            msg["Subject"] = f"Seu Código de Acesso - {system_name}"
            msg["From"] = f"{system_name} Sistema <{settings.email_address}>"
            msg["To"] = f"{nome} <{to_email}>"

            with smtplib.SMTP(settings.smtp_host, settings.smtp_port, timeout=10) as server:
                server.send_message(msg)
            logger.info(f"E-mail com código de acesso enviado com sucesso para {to_email}")
            return True
        except Exception as e:
            print(f"Error sending email to {to_email}: {e}")
            logger.error(f"Error sending email to {to_email}: {e}")
            return False

    @staticmethod
    def send_email(
        to_email: str,
        subject: str,
        body: str,
        to_name: Optional[str] = None,
        from_name: Optional[str] = None
    ) -> bool:
        """
        Envia e-mail genérico formatado via SMTP.
        """
        try:
            msg = EmailMessage()
            msg.set_content(body)
            msg["Subject"] = subject
            sender_name = from_name or "EasyEvent Sistema"
            msg["From"] = f"{sender_name} <{settings.email_address}>"
            msg["To"] = f"{to_name} <{to_email}>" if to_name else to_email

            with smtplib.SMTP(settings.smtp_host, settings.smtp_port, timeout=10) as server:
                server.send_message(msg)
            logger.info(f"E-mail '{subject}' enviado com sucesso para {to_email}")
            return True
        except Exception as e:
            print(f"Error sending email to {to_email}: {e}")
            logger.error(f"Error sending email to {to_email}: {e}")
            return False
