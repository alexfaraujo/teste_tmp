"""Services package."""

from app.services.auth_service import (
    authenticate_admin,
    generate_and_send_otp,
    verify_otp_and_login
)
from app.services.email_service import EmailService

__all__ = [
    "authenticate_admin",
    "generate_and_send_otp",
    "verify_otp_and_login",
    "EmailService",
]
