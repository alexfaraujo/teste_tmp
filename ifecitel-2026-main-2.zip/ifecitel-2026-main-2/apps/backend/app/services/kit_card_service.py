"""Service para geração de Cards de Kits em formato PDF (Individual e por Projeto).

Permite a impressão em alta resolução (ReportLab) com guias de corte:
- Individual por Participante: 6 cards por folha A4 (grade 2x3).
- Coletivo por Projeto / Estande: 2 cards por folha A4 (grade 1x2) com Packing List e Checklist de entrega.
Suporta controle de concessão de camisetas por categoria de participante (Estudantes, Orientadores, Coorientadores, Avaliadores).
"""

import io
import os
from collections import Counter
from typing import Any, Dict, List, Optional, Tuple

from fastapi import HTTPException, status
from reportlab.graphics.barcode import code128
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from sqlalchemy import or_, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.core.config import settings
from app.models.enums import EducationLevelEnum, ProjectMemberRole, ProjectStatus, UserRole
from app.models.event import Event
from app.models.knowledge_area import KnowledgeArea, Subarea
from app.models.person import EventParticipant, EventParticipantRole, Person
from app.models.project import Project, ProjectMember


def _resolve_local_logo_path(logo_url: Optional[str]) -> Optional[str]:
    """Tenta localizar o logotipo do evento no disco local."""
    if not logo_url:
        return None
    if "/static/uploads/" in logo_url:
        rel = logo_url.split("/static/uploads/")[-1].lstrip("/")
        candidate = os.path.join(settings.UPLOAD_DIR, rel)
        if os.path.isfile(candidate):
            return candidate
    if os.path.isfile(logo_url):
        return logo_url
    basename = os.path.basename(logo_url)
    candidate_logo_dir = os.path.join(settings.UPLOAD_DIR, "logos", basename)
    if os.path.isfile(candidate_logo_dir):
        return candidate_logo_dir
    return None


def _format_education_level_label(level: Optional[Any]) -> str:
    """Retorna o rótulo legível do nível de ensino."""
    mapping = {
        "JUNIOR": "Ensino Fundamental I",
        "FUNDAMENTAL": "Ensino Fundamental II",
        "MEDIO": "Ensino Médio / Técnico",
        "GRADUACAO": "Graduação / Superior",
        "POS_GRADUACAO": "Pós-Graduação",
    }
    raw = level.value if hasattr(level, "value") else str(level or "")
    return mapping.get(raw, raw)


def _wrap_text_lines(c: canvas.Canvas, text_str: str, max_w: float, font_name: str, font_size: float, max_lines: int = 2) -> List[str]:
    """Quebra texto em linhas que caibam na largura máxima."""
    words = text_str.strip().split()
    if not words:
        return [""]

    lines: List[str] = []
    curr = words[0]
    for w in words[1:]:
        test_line = curr + " " + w
        if c.stringWidth(test_line, font_name, font_size) <= max_w:
            curr = test_line
        else:
            lines.append(curr)
            curr = w
            if len(lines) >= max_lines - 1:
                break

    if curr:
        lines.append(curr)

    # Se a última linha ainda exceder, trunca com reticências
    if lines:
        last = lines[-1]
        while c.stringWidth(last + "...", font_name, font_size) > max_w and len(last) > 3:
            last = last[:-1]
        if last != lines[-1]:
            lines[-1] = last + "..."

    return lines[:max_lines]


# =============================================================================
# DESENHO DE CARD INDIVIDUAL (6 POR FOLHA A4 - GRADE 2x3)
# =============================================================================

def _draw_individual_kit_card(
    c: canvas.Canvas,
    x: float,
    y: float,
    w: float,
    h: float,
    event_info: Dict[str, Any],
    card_data: Dict[str, Any],
) -> None:
    """Renderiza uma etiqueta individual de kit de participante."""
    c.saveState()

    # 1. Borda externa arredondada
    c.setStrokeColor(colors.HexColor("#CBD5E1"))
    c.setFillColor(colors.HexColor("#FFFFFF"))
    c.setLineWidth(1)
    c.roundRect(x, y, w, h, 6, stroke=1, fill=1)

    # 2. Cabeçalho com faixa colorida superior
    header_h = 24
    c.setFillColor(colors.HexColor("#F1F5F9"))
    c.roundRect(x, y + h - header_h, w, header_h, 6, stroke=0, fill=1)
    # Cobre os cantos inferiores arredondados da faixa
    c.rect(x, y + h - header_h, w, 8, stroke=0, fill=1)
    c.setStrokeColor(colors.HexColor("#E2E8F0"))
    c.setLineWidth(0.8)
    c.line(x, y + h - header_h, x + w, y + h - header_h)

    # Badge de Papel (Estudante, Orientador, etc.) no topo direito
    role_label = card_data.get("role_label", "PARTICIPANTE").upper()
    role_bg = colors.HexColor("#0D9488")
    if "ORIENTADOR" in role_label:
        role_bg = colors.HexColor("#2563EB")
    elif "COORIENTADOR" in role_label:
        role_bg = colors.HexColor("#4F46E5")
    elif "AVALIADOR" in role_label:
        role_bg = colors.HexColor("#D97706")

    badge_w = c.stringWidth(role_label, "Helvetica-Bold", 6.5) + 10
    c.setFillColor(role_bg)
    c.roundRect(x + w - badge_w - 6, y + h - 18, badge_w, 12, 3, stroke=0, fill=1)
    c.setFillColor(colors.white)
    c.setFont("Helvetica-Bold", 6.5)
    c.drawCentredString(x + w - 6 - (badge_w / 2), y + h - 14.5, role_label)

    # Área disponível no topo à esquerda do badge
    avail_x = x + 8
    avail_w = w - badge_w - 20
    avail_h = header_h - 6

    logo_path = event_info.get("logo_path")
    logo_ir = event_info.get("logo_image_reader")
    if logo_ir or (logo_path and os.path.isfile(logo_path)):
        # Se tiver logotipo: NÃO inserir nome nem local, usar logotipo na área disponível
        try:
            c.drawImage(
                logo_ir if logo_ir is not None else logo_path,
                avail_x,
                y + h - header_h + 3,
                width=avail_w,
                height=avail_h,
                preserveAspectRatio=True,
                anchor="w",
                mask="auto",
            )
        except Exception:
            pass
    else:
        # Se NÃO tiver logotipo: inserir nome do evento e local de realização
        c.setFillColor(colors.HexColor("#0F766E"))
        c.setFont("Helvetica-Bold", 7.5)
        loc = event_info.get("location") or str(event_info.get("year", ""))
        evt_title = f"{event_info['name']} • {loc}".upper()
        if c.stringWidth(evt_title, "Helvetica-Bold", 7.5) > avail_w:
            evt_title = evt_title[:28] + "..."
        c.drawString(avail_x, y + h - 15, evt_title)

    # 3. Nome do Participante (Destaque em CAIXA ALTA)
    name_str = card_data.get("name", "").strip().upper()
    c.setFillColor(colors.HexColor("#0F172A"))
    name_lines = _wrap_text_lines(c, name_str, w - 16, "Helvetica-Bold", 11.5, max_lines=2)
    name_y = y + h - 38
    for line in name_lines:
        c.setFont("Helvetica-Bold", 11.5)
        c.drawString(x + 8, name_y, line)
        name_y -= 13

    # Afiliação / Escola
    affil_str = card_data.get("affiliation") or event_info.get("institution") or ""
    if affil_str:
        c.setFillColor(colors.HexColor("#64748B"))
        c.setFont("Helvetica", 7)
        affil_lines = _wrap_text_lines(c, affil_str, w - 16, "Helvetica", 7, max_lines=1)
        if affil_lines:
            c.drawString(x + 8, name_y, affil_lines[0])
            name_y -= 10

    # 4. Box de Informações do Trabalho / Estande
    box_w = w - 16
    box_h = 42
    box_x = x + 8
    box_y = name_y - box_h + 4

    c.setStrokeColor(colors.HexColor("#E2E8F0"))
    c.setFillColor(colors.HexColor("#F8FAFC"))
    c.setLineWidth(0.6)
    c.roundRect(box_x, box_y, box_w, box_h, 4, stroke=1, fill=1)

    # Linha 1 do Box: Número do Estande
    booth = card_data.get("booth_number")
    c.setFont("Helvetica-Bold", 8.5)
    if booth:
        c.setFillColor(colors.HexColor("#1D4ED8"))
        c.drawString(box_x + 6, box_y + box_h - 13, f"ESTANDE: {booth.upper()}")
    else:
        c.setFillColor(colors.HexColor("#94A3B8"))
        c.drawString(box_x + 6, box_y + box_h - 13, "ESTANDE: A DEFINIR")

    # Linha 2 e 3 do Box: Título do Trabalho
    proj_title = card_data.get("project_title", "")
    if proj_title:
        c.setFillColor(colors.HexColor("#334155"))
        p_lines = _wrap_text_lines(c, proj_title, box_w - 12, "Helvetica", 7, max_lines=2)
        p_y = box_y + box_h - 24
        for pl in p_lines:
            c.setFont("Helvetica", 7)
            c.drawString(box_x + 6, p_y, pl)
            p_y -= 8.5

    # 5. Box de Concessão de Camiseta / Kit
    shirt_allowed = card_data.get("shirt_allowed", False)
    tshirt_size = card_data.get("tshirt_size", "M").upper()

    shirt_box_y = box_y - 34
    shirt_box_h = 30
    if shirt_allowed:
        # Destaque Azul / Concedido
        c.setStrokeColor(colors.HexColor("#93C5FD"))
        c.setFillColor(colors.HexColor("#EFF6FF"))
        c.setLineWidth(1)
        c.roundRect(box_x, shirt_box_y, box_w, shirt_box_h, 4, stroke=1, fill=1)

        c.setFillColor(colors.HexColor("#1E40AF"))
        c.setFont("Helvetica-Bold", 8)
        c.drawString(box_x + 8, shirt_box_y + 17, "CAMISETA NO KIT:")

        # Letra grande com o tamanho
        c.setFillColor(colors.HexColor("#1D4ED8"))
        c.setFont("Helvetica-Bold", 14)
        c.drawString(box_x + 105, shirt_box_y + 14, f"[  {tshirt_size}  ]")

        c.setFillColor(colors.HexColor("#3B82F6"))
        c.setFont("Helvetica", 6.5)
        c.drawString(box_x + 8, shirt_box_y + 6, "Verifique o tamanho indicado antes da entrega ao participante.")
    else:
        # Básico / Sem Camiseta
        c.setStrokeColor(colors.HexColor("#CBD5E1"))
        c.setFillColor(colors.HexColor("#F8FAFC"))
        c.setLineWidth(0.8)
        c.roundRect(box_x, shirt_box_y, box_w, shirt_box_h, 4, stroke=1, fill=1)

        c.setFillColor(colors.HexColor("#64748B"))
        c.setFont("Helvetica-Bold", 8)
        c.drawString(box_x + 8, shirt_box_y + 17, "KIT BÁSICO (SEM CAMISETA)")

        c.setFillColor(colors.HexColor("#94A3B8"))
        c.setFont("Helvetica", 6.5)
        c.drawString(box_x + 8, shirt_box_y + 6, "Categoria sem concessão de camiseta nesta edição da feira.")

    # 6. Código de Barras Code128 para Leitura Óptica
    bc_text = card_data.get("barcode") or f"BC-{card_data.get('person_id', 0):05d}"
    try:
        bc_obj = code128.Code128(
            bc_text,
            barWidth=0.85,
            barHeight=16,
            humanReadable=False,
        )
        bc_w = bc_obj.width
        bc_x = x + (w - bc_w) / 2
        bc_y = y + 14
        bc_obj.drawOn(c, bc_x, bc_y)

        c.setFillColor(colors.HexColor("#64748B"))
        c.setFont("Helvetica", 6.5)
        c.drawCentredString(x + w / 2, y + 5, bc_text)
    except Exception:
        c.setFillColor(colors.HexColor("#64748B"))
        c.setFont("Helvetica-Bold", 7.5)
        c.drawCentredString(x + w / 2, y + 10, f"CÓDIGO: {bc_text}")

    c.restoreState()


# =============================================================================
# DESENHO DE CARD COLETIVO POR PROJETO / ESTANDE (2 POR FOLHA A4 - GRADE 1x2)
# =============================================================================

def _draw_project_kit_card(
    c: canvas.Canvas,
    x: float,
    y: float,
    w: float,
    h: float,
    event_info: Dict[str, Any],
    project_data: Dict[str, Any],
) -> None:
    """Renderiza um card coletivo de projeto com Packing List e checklist da equipe."""
    c.saveState()

    # 1. Borda externa com cantos arredondados
    c.setStrokeColor(colors.HexColor("#94A3B8"))
    c.setFillColor(colors.HexColor("#FFFFFF"))
    c.setLineWidth(1)
    c.roundRect(x, y, w, h, 8, stroke=1, fill=1)

    # 2. Cabeçalho Superior
    header_h = 56
    header_y = y + h - header_h

    # Faixa superior de identificação
    c.setFillColor(colors.HexColor("#F8FAFC"))
    c.roundRect(x, header_y, w, header_h, 8, stroke=0, fill=1)
    c.rect(x, header_y, w, 10, stroke=0, fill=1)
    c.setStrokeColor(colors.HexColor("#CBD5E1"))
    c.setLineWidth(1)
    c.line(x, header_y, x + w, header_y)

    # BADGE GIGANTE DO ESTANDE (Topo Direito)
    booth_num = project_data.get("booth_number") or "S/N"
    booth_badge_w = 175
    booth_badge_h = 44
    booth_badge_x = x + w - booth_badge_w - 12
    booth_badge_y = y + h - booth_badge_h - 6

    c.setFillColor(colors.HexColor("#0F172A"))
    c.roundRect(booth_badge_x, booth_badge_y, booth_badge_w, booth_badge_h, 6, stroke=0, fill=1)

    c.setFillColor(colors.HexColor("#94A3B8"))
    c.setFont("Helvetica-Bold", 7.5)
    c.drawCentredString(booth_badge_x + booth_badge_w / 2, booth_badge_y + booth_badge_h - 11, "LOCALIZAÇÃO NO PAVILHÃO")

    c.setFillColor(colors.HexColor("#38BDF8"))
    c.setFont("Helvetica-Bold", 16)
    c.drawCentredString(booth_badge_x + booth_badge_w / 2, booth_badge_y + 8, f"ESTANDE: {booth_num.upper()}")

    # Espaço disponível no topo à esquerda do badge do estande
    avail_x = x + 14
    avail_w = booth_badge_x - avail_x - 14
    avail_h = header_h - 14

    logo_path = event_info.get("logo_path")
    logo_ir = event_info.get("logo_image_reader")
    if logo_ir or (logo_path and os.path.isfile(logo_path)):
        # Se tiver logotipo cadastrado: NÃO inserir nome do evento nem local de realização.
        # Usar o logotipo ocupando a parte superior do card que estiver disponível.
        try:
            c.drawImage(
                logo_ir if logo_ir is not None else logo_path,
                avail_x,
                header_y + 7,
                width=avail_w,
                height=avail_h,
                preserveAspectRatio=True,
                anchor="w",
                mask="auto",
            )
        except Exception:
            pass
    else:
        # Se NÃO tiver logotipo cadastrado: inserir nome do evento e local de realização.
        evt_text = f"{event_info['name']} ({event_info['year']})"
        c.setFillColor(colors.HexColor("#0F172A"))
        c.setFont("Helvetica-Bold", 12.5)
        if c.stringWidth(evt_text, "Helvetica-Bold", 12.5) > avail_w:
            evt_text = evt_text[:34] + "..."
        c.drawString(avail_x, header_y + 31, evt_text)

        loc_text = event_info.get("location") or event_info.get("institution") or "Campus do IFMS"
        c.setFillColor(colors.HexColor("#475569"))
        c.setFont("Helvetica", 9)
        if c.stringWidth(loc_text, "Helvetica", 9) > avail_w:
            loc_text = loc_text[:45] + "..."
        c.drawString(avail_x, header_y + 15, loc_text)

    # 3. Informações do Trabalho Científico
    info_y = header_y - 14
    c.setFillColor(colors.HexColor("#0F172A"))
    c.setFont("Helvetica-Bold", 11)
    p_title = project_data.get("title", "").upper()
    t_lines = _wrap_text_lines(c, p_title, w - 28, "Helvetica-Bold", 11, max_lines=2)
    for tl in t_lines:
        c.drawString(x + 14, info_y, tl)
        info_y -= 13

    # Metadados: Área/Subárea, Escola e Nível
    subarea = project_data.get("subarea_label", "")
    school = project_data.get("school_or_affiliation", "")
    level_label = _format_education_level_label(project_data.get("education_level"))

    c.setFillColor(colors.HexColor("#475569"))
    c.setFont("Helvetica", 7.5)
    meta_line = f"Área: {subarea}   •   Nível: {level_label}"
    if school:
        meta_line += f"   •   Escola: {school}"
    meta_lines = _wrap_text_lines(c, meta_line, w - 160, "Helvetica", 7.5, max_lines=1)
    if meta_lines:
        c.drawString(x + 14, info_y, meta_lines[0])

    # Badges de Infraestrutura (Energia e Mesa)
    needs_elec = project_data.get("needs_electricity", False)
    needs_tab = project_data.get("needs_table", False)

    badge_right_x = x + w - 14
    if needs_tab:
        tab_w = 68
        badge_right_x -= tab_w
        c.setFillColor(colors.HexColor("#EEF2FF"))
        c.setStrokeColor(colors.HexColor("#C7D2FE"))
        c.roundRect(badge_right_x, info_y - 3, tab_w, 13, 3, stroke=1, fill=1)
        c.setFillColor(colors.HexColor("#4338CA"))
        c.setFont("Helvetica-Bold", 6.5)
        c.drawString(badge_right_x + 5, info_y + 1, "MESA: SIM")
        badge_right_x -= 6

    if needs_elec:
        elec_w = 74
        badge_right_x -= elec_w
        c.setFillColor(colors.HexColor("#FEF3C7"))
        c.setStrokeColor(colors.HexColor("#FDE68A"))
        c.roundRect(badge_right_x, info_y - 3, elec_w, 13, 3, stroke=1, fill=1)
        c.setFillColor(colors.HexColor("#B45309"))
        c.setFont("Helvetica-Bold", 6.5)
        c.drawString(badge_right_x + 5, info_y + 1, "ENERGIA: SIM")

    # 4. Box de Packing List (Resumo de Montagem da Sacola)
    box_w = w - 28
    box_h = 42
    box_x = x + 14
    box_y = info_y - box_h - 8

    c.setFillColor(colors.HexColor("#F0FDF4"))
    c.setStrokeColor(colors.HexColor("#86EFAC"))
    c.setLineWidth(1)
    c.roundRect(box_x, box_y, box_w, box_h, 5, stroke=1, fill=1)

    c.setFillColor(colors.HexColor("#065F46"))
    c.setFont("Helvetica-Bold", 8)
    c.drawString(box_x + 10, box_y + box_h - 12, "📦 RESUMO DE CONTEÚDO DO PACOTE")

    # Contagem de camisetas e discriminativo
    members = project_data.get("members", [])
    total_kits = len(members)
    eligible_shirts = [m.get("tshirt_size", "M").upper() for m in members if m.get("shirt_allowed", False)]
    total_shirts = len(eligible_shirts)

    c.setFillColor(colors.HexColor("#14532D"))
    c.setFont("Helvetica-Bold", 9)
    summary_txt = f"TOTAL DE KITS: {total_kits}   •   TOTAL DE CAMISETAS NO PACOTE: {total_shirts}"
    c.drawString(box_x + 10, box_y + box_h - 24, summary_txt)

    if eligible_shirts:
        counts = Counter(eligible_shirts)
        desc_parts = [f"{qty}x {sz}" for sz, qty in sorted(counts.items())]
        desc_str = "Camisetas a incluir na sacola: " + ", ".join(desc_parts)
    else:
        desc_str = "Nenhuma camiseta a incluir neste pacote (Categorias desmarcadas na configuração)."

    c.setFillColor(colors.HexColor("#15803D"))
    c.setFont("Helvetica", 7.5)
    c.drawString(box_x + 10, box_y + 6, desc_str)

    # 5. Tabela / Checklist Nominal dos Integrantes
    tbl_y = box_y - 14
    c.setFillColor(colors.HexColor("#0F172A"))
    c.setFont("Helvetica-Bold", 8.5)
    c.drawString(x + 14, tbl_y, "INTEGRANTES DA EQUIPE / CHECKLIST DE CONFERÊNCIA")

    # Cabeçalho da tabela
    tbl_head_y = tbl_y - 14
    c.setFillColor(colors.HexColor("#F1F5F9"))
    c.rect(x + 14, tbl_head_y, w - 28, 12, stroke=0, fill=1)

    c.setFillColor(colors.HexColor("#475569"))
    c.setFont("Helvetica-Bold", 7)
    c.drawString(x + 20, tbl_head_y + 3, "[ ] CONF.")
    c.drawString(x + 65, tbl_head_y + 3, "NOME DO INTEGRANTE")
    c.drawString(x + 270, tbl_head_y + 3, "PAPEL NO PROJETO")
    c.drawString(x + 380, tbl_head_y + 3, "CAMISETA CONCEDIDA")

    row_y = tbl_head_y - 14
    for m in members[:6]:  # Limite seguro de 6 linhas
        # Quadrado para checklist manual
        c.setStrokeColor(colors.HexColor("#94A3B8"))
        c.setLineWidth(0.8)
        c.rect(x + 22, row_y + 1, 9, 9, stroke=1, fill=0)

        # Nome
        c.setFillColor(colors.HexColor("#0F172A"))
        c.setFont("Helvetica-Bold", 7.5)
        m_name = m.get("name", "").upper()
        if c.stringWidth(m_name, "Helvetica-Bold", 7.5) > 195:
            m_name = m_name[:32] + "..."
        c.drawString(x + 65, row_y + 2, m_name)

        # Papel
        r_label = m.get("role_label", "ESTUDANTE")
        c.setFillColor(colors.HexColor("#475569"))
        c.setFont("Helvetica", 7.5)
        c.drawString(x + 270, row_y + 2, r_label)

        # Camiseta
        if m.get("shirt_allowed", False):
            sz = m.get("tshirt_size", "M").upper()
            c.setFillColor(colors.HexColor("#1D4ED8"))
            c.setFont("Helvetica-Bold", 8)
            c.drawString(x + 380, row_y + 2, f"TAMANHO: {sz}")
        else:
            c.setFillColor(colors.HexColor("#94A3B8"))
            c.setFont("Helvetica", 7)
            c.drawString(x + 380, row_y + 2, "Sem camiseta")

        c.setStrokeColor(colors.HexColor("#F1F5F9"))
        c.setLineWidth(0.5)
        c.line(x + 14, row_y - 2, x + w - 14, row_y - 2)

        row_y -= 14

    # 6. Rodapé com Código do Estande (Padronizado para retirada do pacote por qualquer integrante)
    foot_y = y + 10
    bc_text = project_data.get("barcode") or project_data.get("qrcode_token") or f"PRJ-{project_data.get('id', 0):05d}"
    try:
        bc_obj = code128.Code128(
            bc_text,
            barWidth=0.85,
            barHeight=16,
            humanReadable=False,
        )
        bc_obj.drawOn(c, x + 14, foot_y + 6)
        c.setFillColor(colors.HexColor("#64748B"))
        c.setFont("Helvetica-Bold", 6.5)
        c.drawString(x + 14, foot_y - 1, f"CÓDIGO DO ESTANDE: {bc_text}")
    except Exception:
        pass

    c.restoreState()


# =============================================================================
# ORQUESTRADOR PRINCIPAL DO PDF
# =============================================================================

async def generate_event_kit_cards_pdf(
    db: AsyncSession,
    event_id: int,
    card_format: str = "project",  # "project" ou "individual"
    include_tshirt_students: bool = True,
    include_tshirt_advisors: bool = False,
    include_tshirt_coadvisors: bool = False,
    include_tshirt_evaluators: bool = False,
    sort_by: str = "booth",  # "booth", "school", "title"
    status_filter: str = "homologated",  # "homologated" ou "all"
) -> bytes:
    """Gera o documento PDF consolidado de cards de kits pronto para impressão."""
    # 1. Carregar Evento
    event = await db.get(Event, event_id)
    if not event or event.deleted_at is not None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Edição do evento não encontrada.",
        )

    logo_path = _resolve_local_logo_path(event.logo_url)
    logo_ir = None
    if logo_path and os.path.isfile(logo_path):
        try:
            from reportlab.lib.utils import ImageReader
            logo_ir = ImageReader(logo_path)
        except Exception:
            logo_ir = None

    event_info = {
        "id": event.id,
        "name": event.name,
        "year": event.year,
        "institution": event.organizing_institution,
        "location": event.location,
        "logo_path": logo_path,
        "logo_image_reader": logo_ir,
    }

    # 2. Construir Query de Projetos
    proj_stmt = (
        select(Project)
        .options(
            selectinload(Project.members).selectinload(ProjectMember.person),
            selectinload(Project.subarea).selectinload(Subarea.knowledge_area),
        )
        .where(
            Project.event_id == event_id,
            Project.deleted_at.is_(None),
        )
    )

    if status_filter == "homologated":
        proj_stmt = proj_stmt.where(
            Project.status.in_([ProjectStatus.HOMOLOGATED, ProjectStatus.PRESENT, ProjectStatus.EVALUATED])
        )

    proj_res = await db.execute(proj_stmt)
    projects = proj_res.scalars().all()

    if not projects:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Nenhum trabalho encontrado para os filtros selecionados.",
        )

    # 3. Carregar tamanhos de camisetas de event_participants para os membros
    all_person_ids = set()
    for p in projects:
        for m in p.members:
            if m.person and m.deleted_at is None:
                all_person_ids.add(m.person_id)

    part_stmt = select(EventParticipant).where(
        EventParticipant.event_id == event_id,
        EventParticipant.person_id.in_(list(all_person_ids)),
        EventParticipant.deleted_at.is_(None),
    )
    part_res = await db.execute(part_stmt)
    participants_map: Dict[int, EventParticipant] = {
        ep.person_id: ep for ep in part_res.scalars().all()
    }

    # Função auxiliar para verificar concessão de camiseta
    def _is_shirt_allowed(role: ProjectMemberRole) -> bool:
        if role in (ProjectMemberRole.STUDENT_LEADER, ProjectMemberRole.STUDENT_MEMBER):
            return include_tshirt_students
        if role == ProjectMemberRole.ADVISOR:
            return include_tshirt_advisors
        if role == ProjectMemberRole.COADVISOR:
            return include_tshirt_coadvisors
        return False

    # 4. Processar dados estruturados de projetos
    projects_data: List[Dict[str, Any]] = []

    for p in projects:
        sub_label = f"{p.subarea.area_name} > {p.subarea.name}" if p.subarea else "Área Geral"

        # Ordenar membros: ADVISOR -> COADVISOR -> STUDENT_LEADER -> STUDENT_MEMBER
        def _m_sort(m: ProjectMember):
            if m.role == ProjectMemberRole.ADVISOR:
                return 0
            if m.role == ProjectMemberRole.COADVISOR:
                return 1
            if m.role == ProjectMemberRole.STUDENT_LEADER:
                return 2
            return 3

        sorted_m = sorted(p.members, key=_m_sort)
        members_data = []
        school_str = ""

        for m in sorted_m:
            if not m.person or m.deleted_at is not None:
                continue

            ep = participants_map.get(m.person_id)
            sz = ep.tshirt_size if ep and ep.tshirt_size else "M"
            allowed = _is_shirt_allowed(m.role)

            if m.role == ProjectMemberRole.ADVISOR:
                r_lbl = "ORIENTADOR"
            elif m.role == ProjectMemberRole.COADVISOR:
                r_lbl = "COORIENTADOR"
            elif m.role in (ProjectMemberRole.STUDENT_LEADER, ProjectMemberRole.STUDENT_MEMBER):
                r_lbl = "ESTUDANTE"

            if not school_str and m.person.affiliation:
                school_str = m.person.affiliation

            members_data.append({
                "person_id": m.person_id,
                "name": m.person.name,
                "affiliation": m.person.affiliation,
                "role": m.role.value if hasattr(m.role, "value") else str(m.role),
                "role_label": r_lbl,
                "tshirt_size": sz,
                "shirt_allowed": allowed,
                "barcode": m.person.barcode or f"BC-{m.person_id:05d}",
            })

        # Código do pacote: Padronizado para ser o mesmo código do estande (p.qrcode_token)
        # Qualquer integrante do grupo pode retirar o kit do projeto
        stand_barcode = p.qrcode_token or f"PRJ-{p.id:05d}"

        projects_data.append({
            "id": p.id,
            "title": p.title,
            "booth_number": p.booth_number or "",
            "education_level": p.education_level,
            "needs_electricity": p.needs_electricity,
            "needs_table": p.needs_table,
            "subarea_label": sub_label,
            "school_or_affiliation": school_str,
            "barcode": stand_barcode,
            "qrcode_token": p.qrcode_token,
            "members": members_data,
        })

    # 5. Ordenação dos dados
    def _sort_key(item: Dict[str, Any]):
        if sort_by == "school":
            return (item.get("school_or_affiliation", "").lower(), item.get("booth_number", ""), item.get("title", "").lower())
        elif sort_by == "title":
            return (item.get("title", "").lower(), item.get("booth_number", ""))
        else:  # "booth" (padrão)
            # Ordena por número de estande (se vazio, vai para o final)
            booth = item.get("booth_number", "")
            return (0 if booth else 1, booth.lower(), item.get("title", "").lower())

    projects_data.sort(key=_sort_key)

    # 6. Renderização no Canvas ReportLab
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    page_w, page_h = A4

    # =========================================================================
    # RAMO A: CARD COLETIVO POR PROJETO (2 por folha A4 - Grade 1x2)
    # =========================================================================
    if card_format == "project":
        card_w = 545
        card_h = 385
        margin_x = (page_w - card_w) / 2
        margin_y = (page_h - (card_h * 2)) / 3

        # Posições: 0 = Top, 1 = Bottom
        positions = [
            (margin_x, margin_y + card_h + margin_y),  # Top
            (margin_x, margin_y),                      # Bottom
        ]

        for idx, p_info in enumerate(projects_data):
            slot = idx % 2
            x, y = positions[slot]

            _draw_project_kit_card(c, x, y, card_w, card_h, event_info, p_info)

            # Se for o último slot da folha ou o último projeto:
            if slot == 1 or idx == len(projects_data) - 1:
                # Guia de corte horizontal central pontilhada
                c.setStrokeColor(colors.HexColor("#CBD5E1"))
                c.setLineWidth(0.5)
                c.setDash(3, 4)
                c.line(0, page_h / 2, page_w, page_h / 2)
                c.setDash()

                c.showPage()

    # =========================================================================
    # RAMO B: CARD INDIVIDUAL POR PARTICIPANTE (6 por folha A4 - Grade 2x3)
    # =========================================================================
    else:
        # Extrair fila de participantes individuais
        individual_queue: List[Dict[str, Any]] = []
        for p_info in projects_data:
            for m in p_info["members"]:
                individual_queue.append({
                    "person_id": m["person_id"],
                    "name": m["name"],
                    "affiliation": m["affiliation"] or p_info["school_or_affiliation"],
                    "role_label": m["role_label"],
                    "booth_number": p_info["booth_number"],
                    "project_title": p_info["title"],
                    "tshirt_size": m["tshirt_size"],
                    "shirt_allowed": m["shirt_allowed"],
                    "barcode": m["barcode"],
                })

        # Se avaliadores devem ser incluídos e tiverem camiseta configurada
        if include_tshirt_evaluators:
            eval_stmt = (
                select(Person, EventParticipant)
                .join(EventParticipantRole, Person.id == EventParticipantRole.person_id)
                .outerjoin(
                    EventParticipant,
                    (EventParticipant.person_id == Person.id) & (EventParticipant.event_id == event_id)
                )
                .where(
                    EventParticipantRole.event_id == event_id,
                    EventParticipantRole.role == UserRole.EVALUATOR,
                    EventParticipantRole.deleted_at.is_(None),
                    Person.deleted_at.is_(None),
                )
                .distinct()
                .order_by(Person.name)
            )
            eval_res = await db.execute(eval_stmt)
            for ev_person, ev_part in eval_res.all():
                sz = ev_part.tshirt_size if ev_part and ev_part.tshirt_size else "M"
                individual_queue.append({
                    "person_id": ev_person.id,
                    "name": ev_person.name,
                    "affiliation": ev_person.affiliation or "Comissão Avaliadora",
                    "role_label": "AVALIADOR",
                    "booth_number": "SALA AVALIADORES",
                    "project_title": "Comissão de Avaliação Científica",
                    "tshirt_size": sz,
                    "shirt_allowed": True,
                    "barcode": ev_person.barcode or f"BC-{ev_person.id:05d}",
                })

        card_w = 265
        card_h = 245
        margin_x = (page_w - (card_w * 2)) / 3
        margin_y = (page_h - (card_h * 3)) / 4

        # Posições para os 6 slots
        # Linhas de cima para baixo:
        # Row 2 (topo): y = margin_y + 2*card_h + 2*margin_y = 3*margin_y + 2*card_h
        # Row 1 (meio): y = margin_y + card_h + margin_y = 2*margin_y + card_h
        # Row 0 (baixo): y = margin_y
        positions = [
            (margin_x, 3 * margin_y + 2 * card_h),              # Top-Left (0)
            (2 * margin_x + card_w, 3 * margin_y + 2 * card_h),  # Top-Right (1)
            (margin_x, 2 * margin_y + card_h),                  # Mid-Left (2)
            (2 * margin_x + card_w, 2 * margin_y + card_h),      # Mid-Right (3)
            (margin_x, margin_y),                               # Bottom-Left (4)
            (2 * margin_x + card_w, margin_y),                   # Bottom-Right (5)
        ]

        for idx, card_info in enumerate(individual_queue):
            slot = idx % 6
            x, y = positions[slot]

            _draw_individual_kit_card(c, x, y, card_w, card_h, event_info, card_info)

            # Se for o último slot da folha ou o último card da fila:
            if slot == 5 or idx == len(individual_queue) - 1:
                # Linhas pontilhadas de corte
                c.setStrokeColor(colors.HexColor("#CBD5E1"))
                c.setLineWidth(0.5)
                c.setDash(3, 4)

                # Linha vertical central
                c.line(page_w / 2, 0, page_w / 2, page_h)

                # Linhas horizontais separando as 3 linhas de cards
                h_cut_1 = margin_y + card_h + (margin_y / 2)
                h_cut_2 = 2 * margin_y + 2 * card_h + (margin_y / 2)
                c.line(0, h_cut_1, page_w, h_cut_1)
                c.line(0, h_cut_2, page_w, h_cut_2)

                c.setDash()
                c.showPage()

    c.save()
    return buf.getvalue()
