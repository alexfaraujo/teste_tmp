from datetime import datetime, timezone
from typing import List
from fastapi import HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload, with_loader_criteria

from app.models.knowledge_area import KnowledgeArea, Subarea
from app.models.person import PersonSubarea
from app.models.project import Project
from app.schemas.knowledge_area import (
    KnowledgeAreaCreate,
    KnowledgeAreaUpdate,
    KnowledgeAreaBatchImport,
    KnowledgeAreaBatchResponse,
    SubareaCreate,
    SubareaUpdate
)
from app.services.event_service import get_event_by_id, verify_event_temporal_lock


async def create_knowledge_area(
    db: AsyncSession,
    event_id: int,
    payload: KnowledgeAreaCreate
) -> KnowledgeArea:
    """Cadastra uma nova grande área do conhecimento vinculada ao evento ativo."""
    event = await get_event_by_id(db, event_id)
    verify_event_temporal_lock(event)

    # 1. Validar se já existe área ativa com mesmo nome neste evento
    stmt = select(KnowledgeArea).where(
        KnowledgeArea.event_id == event_id,
        KnowledgeArea.name.ilike(payload.name.strip()),
        KnowledgeArea.deleted_at.is_(None)
    )
    res = await db.execute(stmt)
    if res.scalars().first():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Já existe uma área do conhecimento com o nome '{payload.name}' nesta edição."
        )

    # 2. Se já existe uma área com este nome que foi desativada, reativá-la
    stmt_del = select(KnowledgeArea).where(
        KnowledgeArea.event_id == event_id,
        KnowledgeArea.name.ilike(payload.name.strip()),
        KnowledgeArea.deleted_at.is_not(None)
    )
    res_del = await db.execute(stmt_del)
    deleted_area = res_del.scalars().first()
    if deleted_area:
        deleted_area.name = payload.name.strip()
        deleted_area.deleted_at = None
        deleted_area.updated_at = datetime.now(timezone.utc)
        await db.commit()
        await db.refresh(deleted_area)
        return deleted_area

    # 3. Caso contrário, criar nova área
    area = KnowledgeArea(event_id=event_id, name=payload.name.strip())
    db.add(area)
    await db.commit()
    await db.refresh(area)
    return area


async def list_knowledge_areas(db: AsyncSession, event_id: int) -> List[KnowledgeArea]:
    """Lista todas as áreas ativas de um evento com suas respectivas subáreas ativas (Regra BR-16)."""
    stmt = (
        select(KnowledgeArea)
        .where(KnowledgeArea.event_id == event_id, KnowledgeArea.deleted_at.is_(None))
        .options(
            selectinload(KnowledgeArea.subareas),
            with_loader_criteria(Subarea, Subarea.deleted_at.is_(None))
        )
        .execution_options(populate_existing=True)
        .order_by(KnowledgeArea.name.asc())
    )
    res = await db.execute(stmt)
    return list(res.scalars().all())


async def delete_knowledge_area(db: AsyncSession, area_id: int) -> None:
    """
    Desativa (soft-delete) uma grande área, impedindo a exclusão se houver subáreas ativas (BR-16).
    """
    stmt = (
        select(KnowledgeArea)
        .where(KnowledgeArea.id == area_id, KnowledgeArea.deleted_at.is_(None))
        .options(selectinload(KnowledgeArea.subareas))
    )
    res = await db.execute(stmt)
    area = res.scalar_one_or_none()
    if not area:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Área do conhecimento não encontrada.")

    # Regra BR-16: Não pode desativar área com subáreas ativas
    active_subareas = [s for s in area.subareas if s.deleted_at is None]
    if active_subareas:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=(
                f"Não é possível desativar a área '{area.name}' pois existem {len(active_subareas)} "
                "subárea(s) ativa(s) vinculada(s). Desative as subáreas primeiro."
            )
        )

    area.soft_delete()
    await db.commit()


async def create_subarea(
    db: AsyncSession,
    area_id: int,
    payload: SubareaCreate
) -> Subarea:
    """Cadastra uma nova subárea vinculada à área mãe."""
    stmt = select(KnowledgeArea).where(KnowledgeArea.id == area_id, KnowledgeArea.deleted_at.is_(None))
    res = await db.execute(stmt)
    area = res.scalar_one_or_none()
    if not area:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Área do conhecimento mãe não encontrada.")

    # 1. Validar se já existe subárea ativa com mesmo nome
    stmt_sub = select(Subarea).where(
        Subarea.area_id == area_id,
        Subarea.name.ilike(payload.name.strip()),
        Subarea.deleted_at.is_(None)
    )
    res_sub = await db.execute(stmt_sub)
    if res_sub.scalars().first():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"A subárea '{payload.name}' já está cadastrada nesta área do conhecimento."
        )

    # 2. Se já existe uma subárea com este nome que foi desativada, reativá-la
    stmt_del = select(Subarea).where(
        Subarea.area_id == area_id,
        Subarea.name.ilike(payload.name.strip()),
        Subarea.deleted_at.is_not(None)
    )
    res_del = await db.execute(stmt_del)
    deleted_subarea = res_del.scalars().first()
    if deleted_subarea:
        deleted_subarea.name = payload.name.strip()
        deleted_subarea.deleted_at = None
        deleted_subarea.updated_at = datetime.now(timezone.utc)
        await db.commit()
        await db.refresh(deleted_subarea)
        return deleted_subarea

    # 3. Caso contrário, criar nova subárea
    subarea = Subarea(area_id=area_id, name=payload.name.strip())
    db.add(subarea)
    await db.commit()
    await db.refresh(subarea)
    return subarea


async def delete_subarea(db: AsyncSession, subarea_id: int) -> None:
    """
    Desativa (soft-delete) uma subárea, impedindo a exclusão se houver projetos ou avaliadores ativos vinculados (BR-16).
    """
    stmt = select(Subarea).where(Subarea.id == subarea_id, Subarea.deleted_at.is_(None))
    res = await db.execute(stmt)
    subarea = res.scalar_one_or_none()
    if not subarea:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Subárea não encontrada.")

    # Regra BR-16: Bloqueio impeditivo caso exista projeto ativo usando esta subárea
    stmt_proj = select(Project).where(
        Project.subarea_id == subarea_id,
        Project.deleted_at.is_(None)
    )
    res_proj = await db.execute(stmt_proj)
    linked_project = res_proj.scalars().first()
    if linked_project:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=(
                f"Bloqueio de integridade: a subárea '{subarea.name}' não pode ser desativada "
                f"pois está associada ao projeto ativo '{linked_project.title}' (ID: {linked_project.id})."
            )
        )

    # Regra BR-16: Bloqueio impeditivo caso exista avaliador vinculado a esta subárea
    stmt_eval = select(PersonSubarea).where(
        PersonSubarea.subarea_id == subarea_id,
        PersonSubarea.deleted_at.is_(None)
    )
    res_eval = await db.execute(stmt_eval)
    if res_eval.scalars().first():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=(
                f"Bloqueio de integridade: a subárea '{subarea.name}' não pode ser desativada "
                "pois possui avaliadores vinculados a ela."
            )
        )

    subarea.soft_delete()
    await db.commit()


async def import_knowledge_areas_batch(
    db: AsyncSession,
    event_id: int,
    payload: KnowledgeAreaBatchImport
) -> KnowledgeAreaBatchResponse:
    """
    Importa em lote Grandes Áreas e Subáreas para uma edição (Regra BR-16).
    - Agrupa linhas pelo nome da área mãe (case-insensitive).
    - Idempotência:
      * Se a Grande Área já existe ativa, reaproveita.
      * Se estava desativada (soft-deleted), reativa.
      * Se não existe, cria nova.
    - Para cada Subárea:
      * Se já existe ativa sob a área mãe, reaproveita.
      * Se estava desativada (soft-deleted), reativa.
      * Se não existe e tem nome válido, cria nova.
    - Preserva projetos e avaliadores existentes.
    """
    event = await get_event_by_id(db, event_id)
    verify_event_temporal_lock(event)

    total_rows = len(payload.items)

    # 1. Agrupar em memória: area_name_lower -> { "name": str, "subareas": dict(subarea_lower: original_subarea_name) }
    grouped_areas: dict = {}
    for item in payload.items:
        clean_area = item.area.strip()
        if not clean_area:
            continue
        area_key = clean_area.lower()
        if area_key not in grouped_areas:
            grouped_areas[area_key] = {
                "name": clean_area,
                "subareas": {}
            }

        if item.subarea and item.subarea.strip():
            clean_sub = item.subarea.strip()
            sub_key = clean_sub.lower()
            if sub_key not in grouped_areas[area_key]["subareas"]:
                grouped_areas[area_key]["subareas"][sub_key] = clean_sub

    # 2. Carregar todas as áreas existentes no evento (incluindo deletadas para possibilitar reativação)
    stmt_areas = (
        select(KnowledgeArea)
        .where(KnowledgeArea.event_id == event_id)
        .options(selectinload(KnowledgeArea.subareas))
    )
    res_areas = await db.execute(stmt_areas)
    existing_areas = res_areas.scalars().all()
    existing_areas_map = {a.name.strip().lower(): a for a in existing_areas}

    created_areas_count = 0
    reused_areas_count = 0
    created_subareas_count = 0
    reused_subareas_count = 0
    total_subareas_processed = 0

    now_utc = datetime.now(timezone.utc)

    for area_key, area_data in grouped_areas.items():
        area_name = area_data["name"]
        subareas_dict = area_data["subareas"]
        total_subareas_processed += len(subareas_dict)

        # Tratar Grande Área
        if area_key in existing_areas_map:
            area_obj = existing_areas_map[area_key]
            if area_obj.deleted_at is not None:
                area_obj.deleted_at = None
                area_obj.updated_at = now_utc
                created_areas_count += 1
            else:
                reused_areas_count += 1
        else:
            area_obj = KnowledgeArea(event_id=event_id, name=area_name)
            db.add(area_obj)
            await db.flush()
            existing_areas_map[area_key] = area_obj
            created_areas_count += 1

        # Carregar todas as subáreas existentes dessa área mãe (inclusive deletadas)
        stmt_subs = select(Subarea).where(Subarea.area_id == area_obj.id)
        res_subs = await db.execute(stmt_subs)
        existing_subs_map = {s.name.strip().lower(): s for s in res_subs.scalars().all()}

        for sub_key, sub_name in subareas_dict.items():
            if sub_key in existing_subs_map:
                sub_obj = existing_subs_map[sub_key]
                if sub_obj.deleted_at is not None:
                    sub_obj.deleted_at = None
                    sub_obj.updated_at = now_utc
                    created_subareas_count += 1
                else:
                    reused_subareas_count += 1
            else:
                new_sub = Subarea(area_id=area_obj.id, name=sub_name)
                db.add(new_sub)
                existing_subs_map[sub_key] = new_sub
                created_subareas_count += 1

    await db.commit()

    # Retorna lista fresca de áreas ativas do evento
    refreshed_areas = await list_knowledge_areas(db, event_id)

    return KnowledgeAreaBatchResponse(
        total_rows_processed=total_rows,
        total_areas_processed=len(grouped_areas),
        total_subareas_processed=total_subareas_processed,
        created_areas_count=created_areas_count,
        created_subareas_count=created_subareas_count,
        reused_areas_count=reused_areas_count,
        reused_subareas_count=reused_subareas_count,
        items=refreshed_areas
    )

