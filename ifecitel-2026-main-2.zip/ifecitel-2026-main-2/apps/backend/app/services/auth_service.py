"""Authentication service containing business logic for login and OTP generation."""

import logging
from datetime import datetime, timedelta, timezone
from typing import Optional
from fastapi import HTTPException, status
from sqlalchemy import select, func, desc
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.security import (
    create_access_token,
    generate_access_code,
    get_password_hash,
    hash_access_code,
    verify_access_code,
    verify_password
)
from app.models.enums import UserRole
from app.models.person import Person
from app.models.registration_verification import RegistrationVerification
from app.schemas.auth import TokenResponse, RegisterCompleteRequest, RegisterRequestCodeResponse
from app.services.email_service import EmailService

logger = logging.getLogger(__name__)


async def authenticate_admin(
    db: AsyncSession,
    email: str,
    password: str
) -> TokenResponse:
    """Autentica o administrador por email e senha criptografada (bcrypt)."""
    stmt = select(Person).where(
        Person.email == email.lower().strip(),
        Person.deleted_at.is_(None)
    )
    result = await db.execute(stmt)
    person = result.scalar_one_or_none()

    if not person:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Credenciais inválidas. Verifique seu e-mail e senha."
        )

    if person.role != UserRole.ADMIN:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Acesso restrito. Este usuário não possui privilégios de Administrador."
        )

    if not person.password_hash or not verify_password(password, person.password_hash):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Credenciais inválidas. Verifique seu e-mail e senha."
        )

    # Emissão do token JWT Bearer (12h de validade)
    token = create_access_token(
        subject=str(person.id),
        claims={
            "email": person.email,
            "role": person.role.value,
            "name": person.name
        }
    )

    return TokenResponse(
        access_token=token,
        token_type="bearer",
        expires_in_hours=settings.ACCESS_TOKEN_EXPIRE_HOURS,
        id=person.id,
        name=person.name,
        email=person.email,
        role=person.role.value,
        barcode=person.barcode
    )


async def generate_and_send_otp(
    db: AsyncSession,
    email: str
) -> dict:
    """
    Gera um código OTP de 8 caracteres em caixa alta (YY + 4 letras + 2 dígitos)
    e grava seu hash na tabela people (Regra SEC-01).
    """
    stmt = select(Person).where(
        Person.email == email.lower().strip(),
        Person.deleted_at.is_(None)
    )
    result = await db.execute(stmt)
    person = result.scalar_one_or_none()

    if not person:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="E-mail não encontrado no sistema. Entre em contato com a organização da feira."
        )

    # Gerar código de 8 caracteres alfanuméricos em caixa alta
    code = generate_access_code()
    person.access_code_hash = hash_access_code(code)
    await db.commit()

    logger.info(f"🔑 Código OTP gerado para {person.email}: {code}")

    # Envio do código de acesso via SMTP usando EmailService
    EmailService.send_access_code(
        to_email=person.email,
        nome=person.name or "Participante",
        codigo=code
    )

    # Em desenvolvimento, expor o dev_code para facilitar testes
    response_payload = {
        "message": "Código de acesso de 8 caracteres enviado com sucesso para seu e-mail.",
        "email": person.email
    }
    if settings.DEBUG:
        response_payload["dev_code"] = code

    return response_payload


async def verify_otp_and_login(
    db: AsyncSession,
    email: str,
    access_code: str
) -> TokenResponse:
    """Valida o código OTP mascarado fornecido pelo participante e emite o token JWT."""
    stmt = select(Person).where(
        Person.email == email.lower().strip(),
        Person.deleted_at.is_(None)
    )
    result = await db.execute(stmt)
    person = result.scalar_one_or_none()

    if not person:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="E-mail não encontrado no sistema."
        )

    if not person.access_code_hash:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Nenhum código foi solicitado previamente para este e-mail. Solicite um novo código."
        )

    # Validar conferência do hash
    if not verify_access_code(access_code, person.access_code_hash):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Código de acesso inválido ou incorreto. Certifique-se de digitar exatamente os 8 caracteres."
        )

    # Limpar o hash após login bem-sucedido se for one-time ou mantê-lo ativo durante o dia
    token = create_access_token(
        subject=str(person.id),
        claims={
            "email": person.email,
            "role": person.role.value,
            "name": person.name
        }
    )

    return TokenResponse(
        access_token=token,
        token_type="bearer",
        expires_in_hours=settings.ACCESS_TOKEN_EXPIRE_HOURS,
        id=person.id,
        name=person.name,
        email=person.email,
        role=person.role.value,
        barcode=person.barcode
    )


async def request_registration_otp(
    db: AsyncSession,
    email: str,
    name: Optional[str] = None
) -> RegisterRequestCodeResponse:
    """
    Gera código OTP de 8 caracteres alfanuméricos para auto-cadastro
    ou primeiro acesso de organizadores e administradores de feiras (Regra BR-24).
    """
    email_clean = email.strip().lower()

    # Verifica se já possui conta ativa com senha mestre cadastrada
    person_stmt = select(Person).where(
        func.lower(Person.email) == email_clean,
        Person.deleted_at.is_(None)
    )
    person_res = await db.execute(person_stmt)
    person = person_res.scalar_one_or_none()

    if person and person.password_hash:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Este e-mail já possui conta ativa com senha no sistema. Efetue login diretamente."
        )

    # Verificação anti-flood: não permitir nova solicitação em menos de 60 segundos
    now = datetime.now(timezone.utc)
    recent_stmt = select(RegistrationVerification).where(
        RegistrationVerification.email == email_clean,
        RegistrationVerification.verified.is_(False),
        RegistrationVerification.created_at >= now - timedelta(seconds=60)
    ).order_by(desc(RegistrationVerification.id))
    recent_res = await db.execute(recent_stmt)
    if recent_res.scalar_one_or_none():
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail="Um código já foi enviado recentemente para este e-mail. Aguarde 60 segundos antes de solicitar um novo."
        )

    # Gera código OTP de 8 caracteres alfanuméricos (Regra SEC-01)
    code = generate_access_code()
    code_hash = hash_access_code(code)
    expires_at = now + timedelta(minutes=15)

    verification = RegistrationVerification(
        email=email_clean,
        code_hash=code_hash,
        expires_at=expires_at,
        attempts=0,
        verified=False
    )
    db.add(verification)
    await db.commit()

    logger.info(f"🔑 [AUTO-CADASTRO OTP] Código gerado para {email_clean}: {code}")

    # Envio do código de acesso via SMTP usando EmailService
    EmailService.send_access_code(
        to_email=email_clean,
        nome=name or "Organizador",
        codigo=code
    )

    response = RegisterRequestCodeResponse(
        message="Código de verificação enviado com sucesso para o e-mail informado.",
        email=email_clean,
        expires_in_seconds=900,
        dev_code=code if settings.DEBUG else None
    )
    return response


async def verify_registration_and_complete(
    db: AsyncSession,
    payload: RegisterCompleteRequest
) -> TokenResponse:
    """
    Valida o código OTP digitado, cadastra/ativa a pessoa e define sua senha pessoal (Regra BR-24).
    Retorna o token JWT Bearer imediatamente para acesso autônomo.
    """
    email_clean = payload.email.strip().lower()
    clean_code = payload.code.strip().upper()

    # Busca a verificação pendente mais recente
    verif_stmt = select(RegistrationVerification).where(
        RegistrationVerification.email == email_clean,
        RegistrationVerification.verified.is_(False)
    ).order_by(desc(RegistrationVerification.id))
    verif_res = await db.execute(verif_stmt)
    verification = verif_res.scalar_one_or_none()

    if not verification:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Nenhuma solicitação de verificação ativa foi encontrada para este e-mail. Solicite um novo código."
        )

    now = datetime.now(timezone.utc)
    if verification.expires_at < now:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="O código de verificação expirou. Solicite um novo código."
        )

    if verification.attempts >= 5:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Limite de tentativas excedido (5 tentativas). Solicite um novo código de verificação."
        )

    if not verify_access_code(clean_code, verification.code_hash):
        verification.attempts += 1
        await db.commit()
        remaining = 5 - verification.attempts
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Código de verificação incorreto. Tentativas restantes: {remaining}."
        )

    # Código válido! Marca como confirmado
    verification.verified = True

    # Busca ou cria a pessoa
    person_stmt = select(Person).where(
        func.lower(Person.email) == email_clean,
        Person.deleted_at.is_(None)
    )
    person_res = await db.execute(person_stmt)
    person = person_res.scalar_one_or_none()

    new_password_hash = get_password_hash(payload.password)

    if not person:
        person = Person(
            name=payload.name.strip(),
            email=email_clean,
            cpf=payload.cpf.strip() if payload.cpf else None,
            affiliation=payload.affiliation.strip() if payload.affiliation else None,
            role=UserRole.ADMIN,
            password_hash=new_password_hash
        )
        db.add(person)
    else:
        # Atualiza cadastro existente (ex: pessoa pré-convidada para uma feira sem senha)
        person.name = payload.name.strip()
        if payload.cpf:
            person.cpf = payload.cpf.strip()
        if payload.affiliation:
            person.affiliation = payload.affiliation.strip()
        person.password_hash = new_password_hash
        if person.role != UserRole.ADMIN:
            person.role = UserRole.ADMIN

    await db.commit()
    await db.refresh(person)

    logger.info(f"✅ Organizador ativado com sucesso: ID={person.id}, Email={person.email}")

    # Emite token JWT Bearer imediatamente
    token = create_access_token(
        subject=str(person.id),
        claims={
            "email": person.email,
            "role": person.role.value,
            "name": person.name
        }
    )

    return TokenResponse(
        access_token=token,
        token_type="bearer",
        expires_in_hours=settings.ACCESS_TOKEN_EXPIRE_HOURS,
        id=person.id,
        name=person.name,
        email=person.email,
        role=person.role.value,
        barcode=person.barcode
    )

