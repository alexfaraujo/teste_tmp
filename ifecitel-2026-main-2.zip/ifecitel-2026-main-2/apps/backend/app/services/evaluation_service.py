"""Evaluations and mobile sheet service (Regras BR-11 e BR-12)."""

from datetime import datetime, timezone
from typing import List, Optional
from fastapi import HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.models.enums import AllocationStatus, EvaluationStatus, ProjectMemberRole, ProjectStatus, ProjectType, UserRole
from app.models.evaluation import Evaluation, EvaluationCriterion, EvaluationItem, EvaluatorAllocation
from app.models.knowledge_area import Subarea
from app.models.person import Person
from app.models.project import Project, ProjectMember
from app.schemas.allocation import AllocationResponse
from app.schemas.evaluation import (
    EvaluationCreate,
    EvaluationCriterionSheetItem,
    EvaluationItemResponse,
    EvaluationResponse,
    EvaluationSheetResponse,
    ProjectEvaluationSummaryResponse
)


def compute_single_evaluation_score(items: List[EvaluationItem]) -> float:
    """Calcula a nota de uma única avaliação aplicando pesos dos critérios."""
    if not items:
        return 0.0
    total_weight = sum(float(item.criterion.weight) for item in items if item.criterion)
    if total_weight > 0:
        total_score = sum(float(item.score) * float(item.criterion.weight) for item in items if item.criterion)
        return round(total_score / total_weight, 2)
    return round(sum(float(item.score) for item in items) / len(items), 2)


_compute_single_evaluation_score = compute_single_evaluation_score



async def get_my_allocations(
    db: AsyncSession,
    event_id: Optional[int],
    evaluator: Person
) -> List[AllocationResponse]:
    """
    Retorna a lista de projetos alocados para o avaliador autenticado na edição do evento.
    Se event_id não for informado, busca as alocações ativas do avaliador.
    """
    conditions = [
        EvaluatorAllocation.evaluator_id == evaluator.id,
        EvaluatorAllocation.status != AllocationStatus.CANCELLED,
        EvaluatorAllocation.deleted_at.is_(None)
    ]
    if event_id is not None:
        conditions.append(EvaluatorAllocation.event_id == event_id)

    stmt = select(EvaluatorAllocation).options(
        selectinload(EvaluatorAllocation.project).selectinload(Project.subarea).selectinload(Subarea.knowledge_area),
        selectinload(EvaluatorAllocation.evaluator)
    ).where(
        *conditions
    ).order_by(EvaluatorAllocation.id)

    res = await db.execute(stmt)
    allocations = res.scalars().all()

    return [
        AllocationResponse(
            id=a.id,
            event_id=a.event_id,
            project_id=a.project.id,
            project_title=a.project.title,
            booth_number=a.project.booth_number,
            subarea_name=a.project.subarea.name if a.project.subarea else "Geral",
            area_name=a.project.subarea.knowledge_area.name if (a.project.subarea and a.project.subarea.knowledge_area) else None,
            evaluator_id=a.evaluator.id,
            evaluator_name=a.evaluator.name,
            allocation_type=a.allocation_type,
            status=a.status,
            allocated_at=a.allocated_at,
            qrcode_token=a.project.qrcode_token
        )
        for a in allocations
    ]


async def get_evaluation_sheet_by_qrcode(
    db: AsyncSession,
    qrcode_token: str,
    evaluator: Person
) -> EvaluationSheetResponse:
    """
    Carrega a ficha de avaliação presencial Mobile-First a partir do QR Code de bancada (Regras BR-08 e BR-11).
    Adapta os critérios de acordo com o tipo de projeto (SCIENTIFIC vs TECHNOLOGICAL).
    Inclui os dados completos de conferência visual do banner (título, autores, orientadores, escola, resumo).
    """
    # 1. Localizar projeto pelo token do QR Code de bancada
    stmt_project = select(Project).options(
        selectinload(Project.subarea).selectinload(Subarea.knowledge_area),
        selectinload(Project.members).selectinload(ProjectMember.person)
    ).where(
        Project.qrcode_token == qrcode_token.strip(),
        Project.deleted_at.is_(None)
    )
    res_project = await db.execute(stmt_project)
    project = res_project.scalar_one_or_none()

    if not project:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="QR Code de estande inválido ou projeto não encontrado."
        )

    # 2. Verificar se o projeto está presente para avaliação
    valid_statuses = (ProjectStatus.PRESENT, ProjectStatus.UNDER_EVALUATION, ProjectStatus.EVALUATED)
    if project.status not in valid_statuses:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Projeto com status '{project.status.value}' não está apto para avaliação presencial (exige presença confirmada)."
        )

    # 3. Bloquear conflito de interesse
    for member in project.members:
        if member.person_id == evaluator.id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Conflito de interesses: você é orientador ou integrante da equipe deste projeto."
            )

    # 4. Validar se o avaliador possui alocação para este projeto (exceto se for ADMIN)
    if evaluator.role != UserRole.ADMIN:
        stmt_alloc = select(EvaluatorAllocation).where(
            EvaluatorAllocation.project_id == project.id,
            EvaluatorAllocation.evaluator_id == evaluator.id,
            EvaluatorAllocation.status != AllocationStatus.CANCELLED,
            EvaluatorAllocation.deleted_at.is_(None)
        )
        res_alloc = await db.execute(stmt_alloc)
        alloc = res_alloc.scalar_one_or_none()
        if not alloc:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Avaliador não está alocado para este projeto nesta edição."
            )

    # 5. Construir e retornar a ficha de avaliação
    return await _build_sheet_response_for_project(db, project, evaluator)


async def get_evaluation_sheet_by_project_id(
    db: AsyncSession,
    project_id: int,
    evaluator: Person
) -> EvaluationSheetResponse:
    """
    Carrega a ficha de avaliação diretamente pelo ID do projeto (sem exigir leitura física de QR Code).
    Permite aos avaliadores consultarem seus trabalhos já avaliados em modo somente-leitura.
    """
    stmt_project = select(Project).options(
        selectinload(Project.subarea).selectinload(Subarea.knowledge_area),
        selectinload(Project.members).selectinload(ProjectMember.person)
    ).where(
        Project.id == project_id,
        Project.deleted_at.is_(None)
    )
    res_project = await db.execute(stmt_project)
    project = res_project.scalar_one_or_none()

    if not project:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Projeto não encontrado."
        )

    # Validar se o avaliador possui alocação para este projeto (exceto se for ADMIN)
    if evaluator.role != UserRole.ADMIN:
        stmt_alloc = select(EvaluatorAllocation).where(
            EvaluatorAllocation.project_id == project.id,
            EvaluatorAllocation.evaluator_id == evaluator.id,
            EvaluatorAllocation.status != AllocationStatus.CANCELLED,
            EvaluatorAllocation.deleted_at.is_(None)
        )
        res_alloc = await db.execute(stmt_alloc)
        alloc = res_alloc.scalar_one_or_none()
        if not alloc:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Avaliador não está alocado para este projeto nesta edição."
            )

    return await _build_sheet_response_for_project(db, project, evaluator)


async def _build_sheet_response_for_project(
    db: AsyncSession,
    project: Project,
    evaluator: Person
) -> EvaluationSheetResponse:
    """Helper unificado para montar a ficha de avaliação com critérios e banner."""
    # Carregar critérios do evento
    stmt_criteria = select(EvaluationCriterion).where(
        EvaluationCriterion.event_id == project.event_id,
        EvaluationCriterion.deleted_at.is_(None)
    ).order_by(EvaluationCriterion.id)
    res_criteria = await db.execute(stmt_criteria)
    criteria = res_criteria.scalars().all()

    # Carregar avaliação anterior deste avaliador se houver (rascunho ou preenchida)
    stmt_eval = select(Evaluation).options(
        selectinload(Evaluation.items)
    ).where(
        Evaluation.project_id == project.id,
        Evaluation.evaluator_id == evaluator.id,
        Evaluation.deleted_at.is_(None)
    )
    res_eval = await db.execute(stmt_eval)
    existing_eval = res_eval.scalar_one_or_none()

    existing_scores = {}
    if existing_eval:
        for it in existing_eval.items:
            existing_scores[it.criterion_id] = float(it.score)

    sheet_criteria: List[EvaluationCriterionSheetItem] = []
    for c in criteria:
        # Descrição/pergunta adaptada dinamicamente ao tipo de projeto (científico vs tecnológico)
        desc = (
            (c.scientific_description or c.technological_description)
            if project.project_type == ProjectType.SCIENTIFIC
            else (c.technological_description or c.scientific_description)
        ) or ""

        sheet_criteria.append(
            EvaluationCriterionSheetItem(
                criterion_id=c.id,
                name=c.name,
                description=desc,
                max_score=float(c.max_score),
                weight=float(c.weight),
                current_score=existing_scores.get(c.id)
            )
        )

    # Dados completos para conferência visual do Banner físico
    authors = [
        m.person.name for m in project.members
        if m.role in (ProjectMemberRole.STUDENT_LEADER, ProjectMemberRole.STUDENT_MEMBER) and m.person
    ]
    advisor_name = next(
        (m.person.name for m in project.members if m.role == ProjectMemberRole.ADVISOR and m.person),
        None
    )
    coadvisor_name = next(
        (m.person.name for m in project.members if m.role == ProjectMemberRole.COADVISOR and m.person),
        None
    )
    school_name = next(
        (m.person.affiliation for m in project.members if m.person and m.person.affiliation),
        None
    )

    return EvaluationSheetResponse(
        project_id=project.id,
        title=project.title,
        abstract=project.abstract,
        project_type=project.project_type,
        booth_number=project.booth_number,
        subarea_name=project.subarea.name if project.subarea else "Geral",
        area_name=project.subarea.knowledge_area.name if (project.subarea and project.subarea.knowledge_area) else None,
        education_level=project.education_level.value if project.education_level else None,
        school_name=school_name,
        authors=authors,
        advisor_name=advisor_name,
        coadvisor_name=coadvisor_name,
        qrcode_token=project.qrcode_token,
        criteria=sheet_criteria,
        current_feedback=existing_eval.general_feedback if existing_eval else None
    )


async def submit_evaluation(
    db: AsyncSession,
    payload: EvaluationCreate,
    evaluator: Person
) -> EvaluationResponse:
    """
    Submete a avaliação presencial Mobile-First com parecer geral consolidado único (Regra BR-11).
    Atualiza a máquina de estados do projeto (UNDER_EVALUATION e EVALUATED) e calcula notas (Regra BR-12).
    """
    # 1. Carregar projeto com seus integrantes e evento
    stmt_project = select(Project).options(
        selectinload(Project.members),
        selectinload(Project.event)
    ).where(
        Project.id == payload.project_id,
        Project.deleted_at.is_(None)
    )
    res_project = await db.execute(stmt_project)
    project = res_project.scalar_one_or_none()
    if not project:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Projeto não encontrado."
        )

    # 2. Bloquear conflito de interesse
    for member in project.members:
        if member.person_id == evaluator.id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Conflito de interesses: você é orientador ou membro deste projeto."
            )

    # 3. Localizar alocação ativa do avaliador para o projeto
    stmt_alloc = select(EvaluatorAllocation).where(
        EvaluatorAllocation.project_id == project.id,
        EvaluatorAllocation.evaluator_id == evaluator.id,
        EvaluatorAllocation.status != AllocationStatus.CANCELLED,
        EvaluatorAllocation.deleted_at.is_(None)
    )
    res_alloc = await db.execute(stmt_alloc)
    allocation = res_alloc.scalar_one_or_none()

    if not allocation and evaluator.role != UserRole.ADMIN:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Avaliador não possui alocação ativa para este projeto."
        )

    # 4. Validar critérios informados contra os critérios do evento
    stmt_criteria = select(EvaluationCriterion).where(
        EvaluationCriterion.event_id == project.event_id,
        EvaluationCriterion.deleted_at.is_(None)
    )
    res_criteria = await db.execute(stmt_criteria)
    event_criteria = {c.id: c for c in res_criteria.scalars().all()}

    submitted_criterion_ids = {it.criterion_id for it in payload.items}
    if not submitted_criterion_ids.issubset(event_criteria.keys()):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Um ou mais critérios informados não pertencem a esta edição do evento."
        )

    for item in payload.items:
        crit = event_criteria[item.criterion_id]
        if item.score < 0.0 or item.score > float(crit.max_score):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"A nota do critério '{crit.name}' ({item.score}) deve estar entre 0.0 e {crit.max_score}."
            )

    # 5. Localizar ou criar a entidade de avaliação (Evaluation)
    stmt_eval = select(Evaluation).options(
        selectinload(Evaluation.items)
    ).where(
        Evaluation.project_id == project.id,
        Evaluation.evaluator_id == evaluator.id,
        Evaluation.deleted_at.is_(None)
    )
    res_eval = await db.execute(stmt_eval)
    evaluation = res_eval.scalar_one_or_none()

    now = datetime.now(timezone.utc)

    feedback_text = payload.general_feedback.strip() if payload.general_feedback and payload.general_feedback.strip() else None

    if evaluation:
        evaluation.general_feedback = feedback_text
        evaluation.status = payload.status
        evaluation.evaluated_at = now
        # Deletar itens antigos e substituir pelos novos
        for old_item in list(evaluation.items):
            await db.delete(old_item)
        await db.flush()
    else:
        evaluation = Evaluation(
            project_id=project.id,
            evaluator_id=evaluator.id,
            allocation_id=allocation.id if allocation else None,
            status=payload.status,
            general_feedback=feedback_text,
            evaluated_at=now
        )
        db.add(evaluation)
        await db.flush()

    # 6. Gravar itens da avaliação
    for it in payload.items:
        new_item = EvaluationItem(
            evaluation_id=evaluation.id,
            criterion_id=it.criterion_id,
            score=it.score
        )
        db.add(new_item)

    # 7. Atualizar status da alocação se avaliação concluída
    if allocation and payload.status == EvaluationStatus.COMPLETED:
        allocation.status = AllocationStatus.COMPLETED

    # 8. Transição da Máquina de Estados do Projeto (Regra BR-06)
    # Transição para UNDER_EVALUATION no primeiro preenchimento
    if project.status == ProjectStatus.PRESENT:
        project.status = ProjectStatus.UNDER_EVALUATION

    # Verificar se todas as alocações ativas do projeto foram concluídas
    stmt_all_allocs = select(EvaluatorAllocation).where(
        EvaluatorAllocation.project_id == project.id,
        EvaluatorAllocation.status != AllocationStatus.CANCELLED,
        EvaluatorAllocation.deleted_at.is_(None)
    )
    res_all_allocs = await db.execute(stmt_all_allocs)
    all_allocs = res_all_allocs.scalars().all()

    if all_allocs and all(a.status == AllocationStatus.COMPLETED for a in all_allocs):
        project.status = ProjectStatus.EVALUATED

    await db.commit()

    # 9. Recarregar avaliação persistida para montagem da resposta
    stmt_reload = select(Evaluation).options(
        selectinload(Evaluation.items).selectinload(EvaluationItem.criterion),
        selectinload(Evaluation.evaluator)
    ).where(Evaluation.id == evaluation.id)
    res_reload = await db.execute(stmt_reload)
    saved_eval = res_reload.scalar_one()

    single_score = _compute_single_evaluation_score(saved_eval.items)

    return EvaluationResponse(
        id=saved_eval.id,
        project_id=saved_eval.project_id,
        evaluator_id=saved_eval.evaluator_id,
        evaluator_name=saved_eval.evaluator.name,
        status=saved_eval.status,
        general_feedback=saved_eval.general_feedback,
        evaluated_at=saved_eval.evaluated_at,
        final_score=single_score,
        items=[
            EvaluationItemResponse(
                id=it.id,
                criterion_id=it.criterion_id,
                criterion_name=it.criterion.name if it.criterion else f"Critério #{it.criterion_id}",
                score=float(it.score)
            )
            for it in saved_eval.items
        ]
    )


async def get_project_evaluation_summary(
    db: AsyncSession,
    project_id: int
) -> ProjectEvaluationSummaryResponse:
    """
    Totalização das avaliações do projeto calculada por média aritmética simples sem descarte (Regra BR-12).
    """
    stmt_proj = select(Project).where(
        Project.id == project_id,
        Project.deleted_at.is_(None)
    )
    res_proj = await db.execute(stmt_proj)
    project = res_proj.scalar_one_or_none()
    if not project:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Projeto não encontrado."
        )

    # Carregar avaliações concluídas com seus itens e critérios
    stmt_evals = select(Evaluation).options(
        selectinload(Evaluation.items).selectinload(EvaluationItem.criterion)
    ).where(
        Evaluation.project_id == project.id,
        Evaluation.status == EvaluationStatus.COMPLETED,
        Evaluation.deleted_at.is_(None)
    )
    res_evals = await db.execute(stmt_evals)
    completed_evals = res_evals.scalars().all()

    scores = []
    feedbacks = []
    for ev in completed_evals:
        score = _compute_single_evaluation_score(ev.items)
        scores.append(score)
        if ev.general_feedback:
            feedbacks.append(ev.general_feedback)

    # Média aritmética simples sem descarte de notas extremas (BR-12)
    arithmetic_mean = round(sum(scores) / len(scores), 2) if scores else 0.0

    return ProjectEvaluationSummaryResponse(
        project_id=project.id,
        title=project.title,
        evaluations_count=len(scores),
        simple_arithmetic_mean=arithmetic_mean,
        feedbacks=feedbacks
    )


async def list_project_evaluations(
    db: AsyncSession,
    project_id: int
) -> List[EvaluationResponse]:
    """
    Lista todas as avaliações de um projeto com detalhes.
    """
    stmt = select(Evaluation).options(
        selectinload(Evaluation.items).selectinload(EvaluationItem.criterion),
        selectinload(Evaluation.evaluator)
    ).where(
        Evaluation.project_id == project_id,
        Evaluation.deleted_at.is_(None)
    ).order_by(Evaluation.id)

    res = await db.execute(stmt)
    evals = res.scalars().all()

    return [
        EvaluationResponse(
            id=ev.id,
            project_id=ev.project_id,
            evaluator_id=ev.evaluator_id,
            evaluator_name=ev.evaluator.name,
            status=ev.status,
            general_feedback=ev.general_feedback,
            evaluated_at=ev.evaluated_at,
            final_score=_compute_single_evaluation_score(ev.items),
            items=[
                EvaluationItemResponse(
                    id=it.id,
                    criterion_id=it.criterion_id,
                    criterion_name=it.criterion.name if it.criterion else f"Critério #{it.criterion_id}",
                    score=float(it.score)
                )
                for it in ev.items
            ]
        )
        for ev in evals
    ]
