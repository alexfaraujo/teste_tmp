"""Automated test suite for Rule BR-24: Self-registration with 2-step OTP verification."""

import pytest
from httpx import AsyncClient
from sqlalchemy import delete, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.person import EventParticipant, EventParticipantRole, Person
from app.models.event import EventAdministrator
from app.models.registration_verification import RegistrationVerification
from app.core.security import get_password_hash


@pytest.mark.asyncio
async def test_register_flow_new_organizer(client: AsyncClient, db_session: AsyncSession):
    """Test full self-registration flow for a new organizer."""
    test_email = "novo.organizador.teste@ifms.edu.br"

    # Clean up any previous test records
    p = (await db_session.execute(select(Person).where(Person.email == test_email))).scalar_one_or_none()
    if p:
        await db_session.execute(delete(EventParticipantRole).where(EventParticipantRole.person_id == p.id))
        await db_session.execute(delete(EventParticipant).where(EventParticipant.person_id == p.id))
        await db_session.execute(delete(EventAdministrator).where(EventAdministrator.person_id == p.id))
        await db_session.delete(p)
    verifs = (await db_session.execute(select(RegistrationVerification).where(RegistrationVerification.email == test_email))).scalars().all()
    for v in verifs:
        await db_session.delete(v)
    await db_session.commit()

    # Step 1: Request code
    req_resp = await client.post(
        "/api/v1/auth/register/request-code",
        json={"email": test_email, "name": "Prof. Novo Organizador"}
    )
    assert req_resp.status_code == 200, req_resp.text
    data = req_resp.json()
    assert data["email"] == test_email
    assert "dev_code" in data
    dev_code = data["dev_code"]
    assert len(dev_code) == 8

    # Verify record in DB
    verif_stmt = select(RegistrationVerification).where(
        RegistrationVerification.email == test_email,
        RegistrationVerification.verified.is_(False)
    )
    verif_res = await db_session.execute(verif_stmt)
    verification = verif_res.scalar_one_or_none()
    assert verification is not None
    assert verification.attempts == 0

    # Step 1.1: Anti-flood test (requesting immediately again)
    flood_resp = await client.post(
        "/api/v1/auth/register/request-code",
        json={"email": test_email}
    )
    assert flood_resp.status_code == 429

    # Step 2: Try invalid OTP
    bad_resp = await client.post(
        "/api/v1/auth/register/verify-and-complete",
        json={
            "email": test_email,
            "code": "INVALIDO",
            "name": "Prof. Novo Organizador",
            "password": "MinhaSenhaForte123!",
            "affiliation": "IFMS Campus Ponta Porã"
        }
    )
    assert bad_resp.status_code == 400
    assert "Código de verificação incorreto" in bad_resp.text

    # Step 3: Complete with valid OTP
    complete_resp = await client.post(
        "/api/v1/auth/register/verify-and-complete",
        json={
            "email": test_email,
            "code": dev_code,
            "name": "Prof. Novo Organizador",
            "password": "MinhaSenhaForte123!",
            "cpf": "111.222.333-44",
            "affiliation": "IFMS Campus Ponta Porã"
        }
    )
    assert complete_resp.status_code == 201, complete_resp.text
    login_data = complete_resp.json()
    assert "access_token" in login_data
    assert login_data["email"] == test_email
    assert login_data["role"] == "ADMIN"

    # Verify Person in DB
    p_stmt = select(Person).where(Person.email == test_email)
    p_res = await db_session.execute(p_stmt)
    person = p_res.scalar_one_or_none()
    assert person is not None
    assert person.password_hash is not None
    assert person.affiliation == "IFMS Campus Ponta Porã"

    # Step 4: Login with newly created password
    login_resp = await client.post(
        "/api/v1/auth/admin/login",
        json={
            "email": test_email,
            "password": "MinhaSenhaForte123!"
        }
    )
    assert login_resp.status_code == 200, login_resp.text
    assert login_resp.json()["access_token"] is not None

    # Step 5: Try requesting registration code again for already active user -> 400
    duplicate_req = await client.post(
        "/api/v1/auth/register/request-code",
        json={"email": test_email}
    )
    assert duplicate_req.status_code == 400
    assert "já possui conta ativa com senha" in duplicate_req.text


@pytest.mark.asyncio
async def test_first_access_for_pre_invited_admin(client: AsyncClient, db_session: AsyncSession):
    """Test first access / password activation for an admin invited by email without password."""
    invited_email = "convidado.equipe.teste@ifms.edu.br"

    # Pre-create person without password (simulating add_event_admin)
    existing_p = (await db_session.execute(
        select(Person).where(Person.email == invited_email)
    )).scalar_one_or_none()

    if not existing_p:
        existing_p = Person(
            name="Membro Convidado",
            email=invited_email,
            role="ADMIN",
            password_hash=None
        )
        db_session.add(existing_p)
        await db_session.commit()
    else:
        existing_p.password_hash = None
        await db_session.commit()

    # User requests OTP
    req_resp = await client.post(
        "/api/v1/auth/register/request-code",
        json={"email": invited_email}
    )
    assert req_resp.status_code == 200, req_resp.text
    dev_code = req_resp.json()["dev_code"]

    # User completes first access with their custom password
    complete_resp = await client.post(
        "/api/v1/auth/register/verify-and-complete",
        json={
            "email": invited_email,
            "code": dev_code,
            "name": "Membro Convidado Atualizado",
            "password": "SenhaConvidado2026!",
            "affiliation": "IFMS Campus Três Lagoas"
        }
    )
    assert complete_resp.status_code == 201, complete_resp.text
    assert complete_resp.json()["email"] == invited_email

    # Verify user can now login with password
    login_resp = await client.post(
        "/api/v1/auth/admin/login",
        json={
            "email": invited_email,
            "password": "SenhaConvidado2026!"
        }
    )
    assert login_resp.status_code == 200, login_resp.text
