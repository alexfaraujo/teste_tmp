"""Automated tests for Phase 2: Events, Knowledge Areas, Awards, Project Quotas and Advisor Consent."""

from datetime import date, timedelta
import uuid
import pytest
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.security import create_access_token, get_password_hash
from app.models.enums import (
    EducationLevelEnum,
    EventStatus,
    ProjectMemberRole,
    ProjectStatus,
    ProjectType,
    UserRole
)
from app.models.evaluation import EvaluationCriterion
from app.models.event import Event
from app.models.knowledge_area import KnowledgeArea, Subarea
from app.models.person import Person
from app.models.project import Project, ProjectMember


@pytest.fixture
def admin_headers(seed_admin: Person) -> dict:
    """Gera cabeçalho de autenticação Bearer e API Key para o Administrador."""
    token = create_access_token(
        subject=str(seed_admin.id),
        claims={"role": "ADMIN", "email": seed_admin.email}
    )
    return {"Authorization": f"Bearer {token}", "X-API-Key": settings.API_KEY}


@pytest.fixture
def advisor_headers(seed_advisor: Person) -> dict:
    """Gera cabeçalho de autenticação Bearer e API Key para o Orientador."""
    token = create_access_token(
        subject=str(seed_advisor.id),
        claims={"role": "ADVISOR", "email": seed_advisor.email}
    )
    return {"Authorization": f"Bearer {token}", "X-API-Key": settings.API_KEY}


@pytest.fixture
def student_headers(seed_student: Person) -> dict:
    """Gera cabeçalho de autenticação Bearer e API Key para um Estudante."""
    token = create_access_token(
        subject=str(seed_student.id),
        claims={"role": "STUDENT", "email": seed_student.email}
    )
    return {"Authorization": f"Bearer {token}", "X-API-Key": settings.API_KEY}


@pytest.fixture
async def seed_advisor(db_session: AsyncSession) -> Person:
    """Cria ou recupera orientador de teste no banco real."""
    from sqlalchemy import select
    stmt = select(Person).where(Person.email == "orientador.teste@fecitel.ifms.edu.br")
    res = await db_session.execute(stmt)
    advisor = res.scalar_one_or_none()
    if not advisor:
        advisor = Person(
            name="Prof. Dr. Orientador Silva",
            email="orientador.teste@fecitel.ifms.edu.br",
            role=UserRole.ADVISOR,
            barcode="BC-ADV-0001"
        )
        db_session.add(advisor)
        await db_session.commit()
        await db_session.refresh(advisor)
    return advisor


@pytest.fixture
async def seed_student(db_session: AsyncSession) -> Person:
    """Cria ou recupera estudante líder de teste no banco real."""
    from sqlalchemy import select
    stmt = select(Person).where(Person.email == "aluno.lider@fecitel.ifms.edu.br")
    res = await db_session.execute(stmt)
    student = res.scalar_one_or_none()
    if not student:
        student = Person(
            name="Aluno Líder Científico",
            email="aluno.lider@fecitel.ifms.edu.br",
            role=UserRole.STUDENT,
            barcode="BC-STU-0001"
        )
        db_session.add(student)
        await db_session.commit()
        await db_session.refresh(student)
    return student


@pytest.mark.asyncio
async def test_create_and_list_events_with_temporal_lock(
    client: AsyncClient,
    admin_headers: dict,
    db_session: AsyncSession,
    seed_admin: Person
):
    """Testa cadastro de multi-eventos e valida a trava temporal (BR-01, BR-02)."""
    today = date.today()

    # 1. Cadastrar evento ativo com data futura
    create_resp = await client.post(
        "/api/v1/events",
        headers=admin_headers,
        json={
            "name": "FECITEL 2026 — Edição Principal",
            "year": 2026,
            "description": "Feira Científica Oficial",
            "max_projects": 120,
            "workload_hours": 40,
            "location": "Ginásio Poliesportivo do IFMS",
            "start_date": str(today),
            "end_date": str(today + timedelta(days=5)),
            "summary_extension": "pdf",
            "banner_extension": "pdf",
            "max_file_size_mb": 20
        }
    )
    assert create_resp.status_code == 201, create_resp.text
    event_data = create_resp.json()
    event_id = event_data["id"]
    assert event_data["name"] == "FECITEL 2026 — Edição Principal"

    # 2. Listar eventos
    list_resp = await client.get("/api/v1/events")
    assert list_resp.status_code == 200
    assert any(e["id"] == event_id for e in list_resp.json())

    # 2.1 Testar paginação real BR-18 (page=1, limit=15)
    pag_resp = await client.get("/api/v1/events?page=1&limit=15&search=Principal", headers=admin_headers)
    assert pag_resp.status_code == 200
    pag_data = pag_resp.json()
    assert "items" in pag_data
    assert "total" in pag_data
    assert pag_data["page"] == 1
    assert pag_data["limit"] == 15
    assert pag_data["total"] >= 1
    assert any(e["id"] == event_id for e in pag_data["items"])

    # 2.2 Testar busca por nome do evento
    search_resp = await client.get(f"/api/v1/events?page=1&limit=15&search=2026")
    assert search_resp.status_code == 200
    search_data = search_resp.json()
    assert any(e["id"] == event_id for e in search_data["items"])

    search_empty_resp = await client.get("/api/v1/events?page=1&limit=15&search=NomeInexistenteXYZ123")
    assert search_empty_resp.status_code == 200
    assert search_empty_resp.json()["total"] == 0
    assert len(search_empty_resp.json()["items"]) == 0

    # 3. Testar trava temporal com evento expirado no passado
    past_event = Event(
        name="FECITEL 2020 (Histórica)",
        year=2020,
        owner_id=seed_admin.id,
        start_date=today - timedelta(days=100),
        end_date=today - timedelta(days=95),  # Encerrado no passado
        status=EventStatus.CLOSED
    )
    db_session.add(past_event)
    await db_session.commit()
    await db_session.refresh(past_event)

    # Tentativa de atualizar evento expirado deve ser bloqueada (BR-02)
    update_resp = await client.put(
        f"/api/v1/events/{past_event.id}",
        headers=admin_headers,
        json={"name": "Tentativa de Alterar Evento Encerrado"}
    )
    assert update_resp.status_code == 403
    assert "modo somente-leitura" in update_resp.json()["detail"]


@pytest.mark.asyncio
async def test_knowledge_areas_crud_and_integrity_lock(
    client: AsyncClient,
    admin_headers: dict,
    db_session: AsyncSession
):
    """Testa o CRUD de Áreas e Subáreas e a trava impeditiva de desativação (BR-16)."""
    today = date.today()
    event = Event(
        name="FECITEL Áreas Test",
        year=2026,
        start_date=today,
        end_date=today + timedelta(days=10)
    )
    db_session.add(event)
    await db_session.commit()
    await db_session.refresh(event)

    # 1. Cadastrar grande área
    area_resp = await client.post(
        f"/api/v1/events/{event.id}/areas",
        headers=admin_headers,
        json={"name": "Ciências Exatas e da Terra"}
    )
    assert area_resp.status_code == 201
    area_id = area_resp.json()["id"]

    # 2. Cadastrar subárea vinculada
    subarea_resp = await client.post(
        f"/api/v1/areas/{area_id}/subareas",
        headers=admin_headers,
        json={"name": "Ciência da Computação"}
    )
    assert subarea_resp.status_code == 201
    subarea_id = subarea_resp.json()["id"]

    # 3. Tentativa de excluir a grande área com subárea ativa deve falhar (BR-16)
    del_area_fail = await client.delete(
        f"/api/v1/areas/{area_id}",
        headers=admin_headers
    )
    assert del_area_fail.status_code == 400
    assert "subárea(s) ativa(s)" in del_area_fail.json()["detail"]

    # 4. Desativar a subárea primeiro
    del_sub_ok = await client.delete(
        f"/api/v1/subareas/{subarea_id}",
        headers=admin_headers
    )
    assert del_sub_ok.status_code == 204

    # 4.1 Garantir que a listagem de áreas não exibe subáreas soft-deletadas (BR-16)
    list_after_del = await client.get(
        f"/api/v1/events/{event.id}/areas",
        headers=admin_headers
    )
    assert list_after_del.status_code == 200
    target_area = next((a for a in list_after_del.json() if a["id"] == area_id), None)
    assert target_area is not None
    assert len(target_area["subareas"]) == 0

    # 4.2 Recadastrar a mesma subárea excluída anteriormente deve ter sucesso (reativação)
    recreate_sub = await client.post(
        f"/api/v1/areas/{area_id}/subareas",
        headers=admin_headers,
        json={"name": "Ciência da Computação"}
    )
    assert recreate_sub.status_code == 201
    assert recreate_sub.json()["id"] == subarea_id

    # 4.3 Tentar cadastrar novamente enquanto ativa deve falhar com 400
    dup_sub = await client.post(
        f"/api/v1/areas/{area_id}/subareas",
        headers=admin_headers,
        json={"name": "Ciência da Computação"}
    )
    assert dup_sub.status_code == 400

    # Desativar novamente para permitir excluir a área
    await client.delete(f"/api/v1/subareas/{subarea_id}", headers=admin_headers)

    # 5. Agora a área pode ser desativada com sucesso
    del_area_ok = await client.delete(
        f"/api/v1/areas/{area_id}",
        headers=admin_headers
    )
    assert del_area_ok.status_code == 204

    # 5.1 Recadastrar a mesma grande área excluída anteriormente deve ter sucesso (reativação)
    recreate_area = await client.post(
        f"/api/v1/events/{event.id}/areas",
        headers=admin_headers,
        json={"name": "Ciências Exatas e da Terra"}
    )
    assert recreate_area.status_code == 201
    assert recreate_area.json()["id"] == area_id


@pytest.mark.asyncio
async def test_awards_crud_and_criteria_linking(
    client: AsyncClient,
    admin_headers: dict,
    db_session: AsyncSession
):
    """Testa CRUD de Premiações e amarração com perguntas da ficha de avaliação (BR-17)."""
    today = date.today()
    event = Event(
        name="FECITEL Prêmios Test",
        year=2026,
        start_date=today,
        end_date=today + timedelta(days=10)
    )
    db_session.add(event)
    await db_session.flush()

    # Criar um critério de avaliação para associar
    criterion = EvaluationCriterion(
        event_id=event.id,
        name="Inovação e Relevância Social",
        scientific_description="Grau de novidade metodológica",
        technological_description="Potencial aplicativo e benefício comunitário",
        max_score=10.0,
        weight=2.0
    )
    db_session.add(criterion)
    await db_session.commit()
    await db_session.refresh(event)
    await db_session.refresh(criterion)

    # 1. Cadastrar premiação
    award_resp = await client.post(
        f"/api/v1/events/{event.id}/awards",
        headers=admin_headers,
        json={
            "name": "Prêmio Inovação Tecnológica 2026",
            "description": "Destaque em solução prática para a sociedade",
            "sponsor": "Empresa Parceira de Tecnologia"
        }
    )
    assert award_resp.status_code == 201
    award_id = award_resp.json()["id"]

    # 2. Vincular critério de avaliação ao prêmio (BR-17)
    link_resp = await client.post(
        f"/api/v1/awards/{award_id}/criteria",
        headers=admin_headers,
        json=[{"criterion_id": criterion.id, "weight": 2.5}]
    )
    assert link_resp.status_code == 200
    linked_data = link_resp.json()
    assert len(linked_data["criteria_links"]) == 1
    assert linked_data["criteria_links"][0]["criterion_id"] == criterion.id


@pytest.mark.asyncio
async def test_project_submission_quotas_and_advisor_consent(
    client: AsyncClient,
    admin_headers: dict,
    student_headers: dict,
    advisor_headers: dict,
    seed_student: Person,
    seed_advisor: Person,
    db_session: AsyncSession
):
    """Testa validação de cotas por nível (BR-04), submissão e fluxo de anuência do orientador (BR-05)."""
    today = date.today()
    event = Event(
        name="FECITEL Submissão Test",
        year=2026,
        start_date=today,
        end_date=today + timedelta(days=10)
    )
    db_session.add(event)
    await db_session.flush()

    area = KnowledgeArea(event_id=event.id, name="Engenharias")
    db_session.add(area)
    await db_session.flush()

    subarea = Subarea(area_id=area.id, name="Engenharia de Software")
    db_session.add(subarea)

    # Criar 5 estudantes para testar violação de cota do Ensino Médio (máx 4 alunos)
    run_id = uuid.uuid4().hex[:6]
    students = [seed_student]
    for i in range(2, 6):
        s = Person(name=f"Aluno Extra {i}", email=f"aluno{i}_{run_id}@teste.com", role=UserRole.STUDENT)
        db_session.add(s)
        students.append(s)

    await db_session.commit()
    await db_session.refresh(event)
    await db_session.refresh(subarea)

    # 1. Tentativa com 5 alunos no Ensino Médio deve falhar com 422 (BR-04)
    invalid_members = [
        {"person_id": s.id, "role": "STUDENT_MEMBER"} for s in students
    ]
    invalid_members.append({"person_id": seed_advisor.id, "role": "ADVISOR"})

    resp_quota_fail = await client.post(
        "/api/v1/projects",
        headers=student_headers,
        json={
            "event_id": event.id,
            "subarea_id": subarea.id,
            "education_level": "MEDIO",
            "title": "Projeto com Alunos em Excesso",
            "project_type": "SCIENTIFIC",
            "members": invalid_members
        }
    )
    assert resp_quota_fail.status_code == 422
    assert "Cota excedida" in resp_quota_fail.json()["detail"]

    # 2. Submissão válida com 2 alunos e 1 orientador
    valid_members = [
        {"person_id": students[0].id, "role": "STUDENT_LEADER"},
        {"person_id": students[1].id, "role": "STUDENT_MEMBER"},
        {"person_id": seed_advisor.id, "role": "ADVISOR"}
    ]
    submit_resp = await client.post(
        "/api/v1/projects",
        headers=student_headers,
        json={
            "event_id": event.id,
            "subarea_id": subarea.id,
            "education_level": "MEDIO",
            "title": "Sistema IoT para Eficiência Energética",
            "project_type": "TECHNOLOGICAL",
            "abstract": "Resumo do trabalho tecnológico inovador...",
            "members": valid_members
        }
    )
    assert submit_resp.status_code == 201, submit_resp.text
    project_data = submit_resp.json()
    project_id = project_data["id"]

    # Deve iniciar em WAITING_CONSENT com QR Code gerado (BR-05, BR-06)
    assert project_data["status"] == "WAITING_CONSENT"
    assert project_data["advisor_consent"] is False
    assert project_data["qrcode_token"].startswith("FECITEL-2026-")

    # 3. Aluno tentando conceder anuência deve ser rejeitado com 403 (BR-05)
    consent_fail = await client.post(
        f"/api/v1/projects/{project_id}/consent",
        headers=student_headers
    )
    assert consent_fail.status_code == 403

    # 4. Orientador formal titular concedendo a anuência digital
    consent_ok = await client.post(
        f"/api/v1/projects/{project_id}/consent",
        headers=advisor_headers
    )
    assert consent_ok.status_code == 200, consent_ok.text
    consent_data = consent_ok.json()
    assert consent_data["advisor_consent"] is True
    assert consent_data["new_status"] == "SUBMITTED"

    # 5. Tentativa de desativar a subárea agora vinculada ao projeto deve falhar (BR-16)
    del_sub_blocked = await client.delete(
        f"/api/v1/subareas/{subarea.id}",
        headers=admin_headers
    )
    assert del_sub_blocked.status_code == 400
    assert "Bloqueio de integridade" in del_sub_blocked.json()["detail"]


@pytest.mark.asyncio
async def test_universal_api_key_protection_on_get_and_mutations(
    unauthenticated_client: AsyncClient,
    client: AsyncClient,
    admin_headers: dict
):
    """
    Testa a Regra SEC-03: Proteção universal de todas as rotas por API Key.
    Garante que consultas GET (anteriormente desprotegidas) e mutações POST rejeitem
    qualquer requisição sem o cabeçalho X-API-Key com HTTP 401.
    """
    # 1. GET /events sem API Key deve falhar com 401
    resp_no_key_events = await unauthenticated_client.get("/api/v1/events")
    assert resp_no_key_events.status_code == 401
    assert "API Key ausente ou inválida" in resp_no_key_events.json()["detail"]

    # 2. GET /events com API Key incorreta deve falhar com 401
    resp_wrong_key = await unauthenticated_client.get(
        "/api/v1/events",
        headers={"X-API-Key": "chave_totalmente_invalida_123"}
    )
    assert resp_wrong_key.status_code == 401
    assert "API Key ausente ou inválida" in resp_wrong_key.json()["detail"]

    # 3. GET /events com API Key correta via cabeçalho X-API-Key deve retornar 200
    resp_valid_header = await unauthenticated_client.get(
        "/api/v1/events",
        headers={"X-API-Key": settings.API_KEY}
    )
    assert resp_valid_header.status_code == 200

    # 4. GET /events com API Key correta via query param fallback (?api_key=...) deve retornar 200
    resp_valid_query = await unauthenticated_client.get(f"/api/v1/events?api_key={settings.API_KEY}")
    assert resp_valid_query.status_code == 200

    # 5. GET /events/1/areas sem API Key deve falhar com 401
    resp_no_key_areas = await unauthenticated_client.get("/api/v1/events/1/areas")
    assert resp_no_key_areas.status_code == 401

    # 6. GET /events/1/awards sem API Key deve falhar com 401
    resp_no_key_awards = await unauthenticated_client.get("/api/v1/events/1/awards")
    assert resp_no_key_awards.status_code == 401

    # 7. GET /projects/1 sem API Key deve falhar com 401
    resp_no_key_projects = await unauthenticated_client.get("/api/v1/projects/1")
    assert resp_no_key_projects.status_code == 401

    # 8. POST /api/v1/events sem API Key (mesmo com token JWT de admin) deve falhar com 401
    token_only_headers = {k: v for k, v in admin_headers.items() if k != "X-API-Key"}
    resp_token_no_key = await unauthenticated_client.post(
        "/api/v1/events",
        headers=token_only_headers,
        json={"name": "Tentativa sem API Key"}
    )
    assert resp_token_no_key.status_code == 401
    assert "API Key ausente ou inválida" in resp_token_no_key.json()["detail"]


@pytest.mark.asyncio
async def test_evaluation_criteria_crud_and_integrity_locks(
    client: AsyncClient,
    admin_headers: dict,
    db_session: AsyncSession
):
    """Testa o ciclo de vida completo (CRUD) de critérios de avaliação do evento (Fase 2)."""
    today = date.today()

    # 1. Cadastrar edição do evento
    event_resp = await client.post(
        "/api/v1/events",
        headers=admin_headers,
        json={
            "name": "FECITEL Critérios Test",
            "year": 2026,
            "start_date": str(today),
            "end_date": str(today + timedelta(days=2)),
            "max_projects_per_evaluator": 4
        }
    )
    assert event_resp.status_code == 201
    event_id = event_resp.json()["id"]

    # 2. Criar critério via POST
    crit_create_payload = {
        "name": "Rigor Metodológico e Hipótese",
        "scientific_description": "Adequação do método científico proposto.",
        "technological_description": "Arquitetura e maturidade do protótipo.",
        "max_score": 10.0,
        "weight": 2.0
    }
    create_resp = await client.post(
        f"/api/v1/events/{event_id}/criteria",
        headers=admin_headers,
        json=crit_create_payload
    )
    assert create_resp.status_code == 201
    crit_data = create_resp.json()
    criterion_id = crit_data["id"]
    assert crit_data["name"] == "Rigor Metodológico e Hipótese"
    assert crit_data["weight"] == 2.0

    # 3. Listar critérios do evento via GET
    list_resp = await client.get(
        f"/api/v1/events/{event_id}/criteria",
        headers=admin_headers
    )
    assert list_resp.status_code == 200
    criteria_list = list_resp.json()
    assert len(criteria_list) == 1
    assert criteria_list[0]["id"] == criterion_id

    # 4. Atualizar critério via PUT
    update_payload = {
        "name": "Rigor Metodológico e Solução",
        "scientific_description": "Descrição atualizada para projetos científicos.",
        "weight": 2.5
    }
    put_resp = await client.put(
        f"/api/v1/events/{event_id}/criteria/{criterion_id}",
        headers=admin_headers,
        json=update_payload
    )
    assert put_resp.status_code == 200
    updated_crit = put_resp.json()
    assert updated_crit["name"] == "Rigor Metodológico e Solução"
    assert updated_crit["scientific_description"] == "Descrição atualizada para projetos científicos."
    assert updated_crit["weight"] == 2.5

    # 5. Excluir critério via DELETE
    del_resp = await client.delete(
        f"/api/v1/events/{event_id}/criteria/{criterion_id}",
        headers=admin_headers
    )
    assert del_resp.status_code == 204

    # 6. Listar novamente e confirmar ausência (soft-delete)
    list_after_del = await client.get(
        f"/api/v1/events/{event_id}/criteria",
        headers=admin_headers
    )
    assert list_after_del.status_code == 200
    assert len(list_after_del.json()) == 0

