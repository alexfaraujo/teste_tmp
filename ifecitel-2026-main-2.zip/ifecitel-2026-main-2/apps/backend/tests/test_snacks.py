"""Automated tests for Snack Management and Mobile Distribution (Rule BR-30)."""

from datetime import date
import uuid
import pytest
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.security import create_access_token
from app.models.enums import UserRole
from app.models.event import Event
from app.models.person import EventParticipant, EventParticipantRole, Person
from app.models.snack import SnackDelivery, SnackMoment


@pytest.fixture
def admin_headers(seed_admin: Person) -> dict:
    token = create_access_token(
        subject=str(seed_admin.id),
        claims={"role": "ADMIN", "email": seed_admin.email}
    )
    return {"Authorization": f"Bearer {token}", "X-API-Key": settings.API_KEY}


@pytest.fixture
async def setup_snack_env(db_session: AsyncSession):
    suffix = uuid.uuid4().hex[:6]
    event = Event(
        name=f"FECITEL Lanches {suffix}",
        year=2026,
        start_date=date(2026, 10, 1),
        end_date=date(2026, 10, 5),
    )
    db_session.add(event)
    await db_session.flush()

    # Participante 1: Estudante com código de barras
    p1 = Person(
        name=f"Aluno Lanche {suffix}",
        email=f"aluno_{suffix}@teste.com",
        cpf=f"111{suffix[:8]}",
        barcode=f"BC-ALU-{suffix}",
        role=UserRole.STUDENT,
    )
    db_session.add(p1)
    await db_session.flush()

    part1 = EventParticipant(
        event_id=event.id,
        person_id=p1.id,
        tshirt_size="M",
    )
    db_session.add(part1)

    role1 = EventParticipantRole(
        person_id=p1.id,
        event_id=event.id,
        role=UserRole.STUDENT,
    )
    db_session.add(role1)

    # Participante 2: Avaliador com código de barras
    p2 = Person(
        name=f"Avaliador Lanche {suffix}",
        email=f"eval_{suffix}@teste.com",
        cpf=f"222{suffix[:8]}",
        barcode=f"BC-EVA-{suffix}",
        role=UserRole.EVALUATOR,
    )
    db_session.add(p2)
    await db_session.flush()

    part2 = EventParticipant(
        event_id=event.id,
        person_id=p2.id,
        tshirt_size="G",
    )
    db_session.add(part2)

    role2 = EventParticipantRole(
        person_id=p2.id,
        event_id=event.id,
        role=UserRole.EVALUATOR,
    )
    db_session.add(role2)

    await db_session.commit()
    await db_session.refresh(event)
    await db_session.refresh(p1)
    await db_session.refresh(part1)
    await db_session.refresh(p2)
    await db_session.refresh(part2)

    return {
        "event": event,
        "student": p1,
        "student_participant": part1,
        "evaluator": p2,
        "evaluator_participant": part2,
    }


@pytest.mark.asyncio
async def test_snack_moment_crud(client: AsyncClient, admin_headers: dict, setup_snack_env: dict):
    event = setup_snack_env["event"]

    # 1. Criar momento de lanche
    payload = {
        "name": "Lanche da Tarde — Dia 1",
        "date": "2026-10-01",
        "start_time": "15:30",
        "end_time": "17:00",
        "is_active": True,
        "target_roles": "ALL",
        "total_budgeted": 250,
        "notes": "Entrega de suco e salgado",
    }
    resp = await client.post(
        f"/api/v1/snacks/events/{event.id}/moments",
        json=payload,
        headers=admin_headers,
    )
    assert resp.status_code == 201, resp.text
    data = resp.json()
    moment_id = data["id"]
    assert data["name"] == "Lanche da Tarde — Dia 1"
    assert data["total_budgeted"] == 250
    assert data["is_active"] is True

    # 2. Listar momentos
    resp_list = await client.get(
        f"/api/v1/snacks/events/{event.id}/moments",
        headers=admin_headers,
    )
    assert resp_list.status_code == 200
    moments = resp_list.json()
    assert len(moments) >= 1
    assert any(m["id"] == moment_id for m in moments)

    # 3. Atualizar momento
    resp_up = await client.put(
        f"/api/v1/snacks/moments/{moment_id}",
        json={"total_budgeted": 300, "notes": "Atualizado"},
        headers=admin_headers,
    )
    assert resp_up.status_code == 200
    assert resp_up.json()["total_budgeted"] == 300
    assert resp_up.json()["notes"] == "Atualizado"

    # 4. Toggle active
    resp_toggle = await client.patch(
        f"/api/v1/snacks/moments/{moment_id}/toggle?is_active=false",
        headers=admin_headers,
    )
    assert resp_toggle.status_code == 200
    assert resp_toggle.json()["is_active"] is False

    # Reativar
    await client.patch(
        f"/api/v1/snacks/moments/{moment_id}/toggle?is_active=true",
        headers=admin_headers,
    )

    # 5. Excluir (soft-delete)
    resp_del = await client.delete(
        f"/api/v1/snacks/moments/{moment_id}",
        headers=admin_headers,
    )
    assert resp_del.status_code == 204


@pytest.mark.asyncio
async def test_snack_delivery_success_and_duplicate_prevention(
    client: AsyncClient,
    admin_headers: dict,
    setup_snack_env: dict,
):
    event = setup_snack_env["event"]
    student = setup_snack_env["student"]

    # 1. Criar momento ativo
    resp_m = await client.post(
        f"/api/v1/snacks/events/{event.id}/moments",
        json={
            "name": f"Coffee Break {uuid.uuid4().hex[:4]}",
            "date": "2026-10-02",
            "is_active": True,
            "target_roles": "ALL",
            "total_budgeted": 100,
        },
        headers=admin_headers,
    )
    assert resp_m.status_code == 201
    moment_id = resp_m.json()["id"]

    # 2. Primeira leitura com código de barras -> SUCESSO
    deliver_req = {"scan_query": student.barcode}
    resp_deliv = await client.post(
        f"/api/v1/snacks/moments/{moment_id}/deliver",
        json=deliver_req,
        headers=admin_headers,
    )
    assert resp_deliv.status_code == 200
    deliv_data = resp_deliv.json()
    assert deliv_data["status"] == "SUCCESS"
    assert deliv_data["participant_name"] == student.name
    assert deliv_data["total_delivered"] == 1
    assert deliv_data["percentage_consumed"] == 1.0

    # 3. Segunda leitura idêntica -> BLOQUEIO POR DUPLICIDADE (ALREADY_DELIVERED)
    resp_dup = await client.post(
        f"/api/v1/snacks/moments/{moment_id}/deliver",
        json=deliver_req,
        headers=admin_headers,
    )
    assert resp_dup.status_code == 200
    dup_data = resp_dup.json()
    assert dup_data["status"] == "ALREADY_DELIVERED"
    assert "já foi retirado" in dup_data["message"]
    # Total entregue não deve incrementar
    assert dup_data["total_delivered"] == 1


@pytest.mark.asyncio
async def test_snack_delivery_role_restrictions(
    client: AsyncClient,
    admin_headers: dict,
    setup_snack_env: dict,
):
    event = setup_snack_env["event"]
    student = setup_snack_env["student"]
    evaluator = setup_snack_env["evaluator"]

    # Criar momento restrito apenas a AVALIADORES
    resp_m = await client.post(
        f"/api/v1/snacks/events/{event.id}/moments",
        json={
            "name": f"Lanche Sala Avaliadores {uuid.uuid4().hex[:4]}",
            "date": "2026-10-02",
            "is_active": True,
            "target_roles": "EVALUATOR",
            "total_budgeted": 50,
        },
        headers=admin_headers,
    )
    assert resp_m.status_code == 201
    moment_id = resp_m.json()["id"]

    # 1. Aluno tenta retirar lanche de avaliador -> ROLE_NOT_ALLOWED
    resp_student = await client.post(
        f"/api/v1/snacks/moments/{moment_id}/deliver",
        json={"scan_query": student.barcode},
        headers=admin_headers,
    )
    assert resp_student.status_code == 200
    res_data = resp_student.json()
    assert res_data["status"] == "ROLE_NOT_ALLOWED"
    assert "não possui autorização" in res_data["message"]

    # 2. Avaliador retira lanche -> SUCCESS
    resp_eval = await client.post(
        f"/api/v1/snacks/moments/{moment_id}/deliver",
        json={"scan_query": evaluator.barcode},
        headers=admin_headers,
    )
    assert resp_eval.status_code == 200
    assert resp_eval.json()["status"] == "SUCCESS"


@pytest.mark.asyncio
async def test_snack_delivery_moment_inactive(
    client: AsyncClient,
    admin_headers: dict,
    setup_snack_env: dict,
):
    event = setup_snack_env["event"]
    student = setup_snack_env["student"]

    # Criar momento INATIVO
    resp_m = await client.post(
        f"/api/v1/snacks/events/{event.id}/moments",
        json={
            "name": f"Lanche Fechado {uuid.uuid4().hex[:4]}",
            "date": "2026-10-02",
            "is_active": False,
            "target_roles": "ALL",
            "total_budgeted": 50,
        },
        headers=admin_headers,
    )
    assert resp_m.status_code == 201
    moment_id = resp_m.json()["id"]

    # Tenta retirar -> MOMENT_INACTIVE
    resp_deliv = await client.post(
        f"/api/v1/snacks/moments/{moment_id}/deliver",
        json={"scan_query": student.barcode},
        headers=admin_headers,
    )
    assert resp_deliv.status_code == 200
    assert resp_deliv.json()["status"] == "MOMENT_INACTIVE"


@pytest.mark.asyncio
async def test_snack_moment_report(
    client: AsyncClient,
    admin_headers: dict,
    setup_snack_env: dict,
):
    event = setup_snack_env["event"]
    student = setup_snack_env["student"]

    resp_m = await client.post(
        f"/api/v1/snacks/events/{event.id}/moments",
        json={
            "name": f"Lanche Relatório {uuid.uuid4().hex[:4]}",
            "date": "2026-10-03",
            "is_active": True,
            "target_roles": "ALL",
            "total_budgeted": 20,
        },
        headers=admin_headers,
    )
    moment_id = resp_m.json()["id"]

    # Entregar lanche
    await client.post(
        f"/api/v1/snacks/moments/{moment_id}/deliver",
        json={"scan_query": student.barcode},
        headers=admin_headers,
    )

    # Obter relatório
    resp_rep = await client.get(
        f"/api/v1/snacks/moments/{moment_id}/report",
        headers=admin_headers,
    )
    assert resp_rep.status_code == 200
    rep_data = resp_rep.json()
    assert rep_data["delivered_count"] == 1
    assert len(rep_data["deliveries"]) == 1
    assert rep_data["deliveries"][0]["participant_name"] == student.name


@pytest.mark.asyncio
async def test_get_eligible_participants_count(
    client: AsyncClient,
    admin_headers: dict,
    setup_snack_env: dict,
):
    event = setup_snack_env["event"]

    # 1. Total com ALL -> 2 (estudante + avaliador)
    resp_all = await client.get(
        f"/api/v1/snacks/events/{event.id}/eligible-count?target_roles=ALL",
        headers=admin_headers,
    )
    assert resp_all.status_code == 200
    assert resp_all.json()["count"] == 2

    # 2. Total apenas Estudantes e Orientadores -> 1
    resp_stud = await client.get(
        f"/api/v1/snacks/events/{event.id}/eligible-count?target_roles=STUDENT,ADVISOR,COADVISOR",
        headers=admin_headers,
    )
    assert resp_stud.status_code == 200
    assert resp_stud.json()["count"] == 1

    # 3. Total apenas Avaliadores -> 1
    resp_eval = await client.get(
        f"/api/v1/snacks/events/{event.id}/eligible-count?target_roles=EVALUATOR",
        headers=admin_headers,
    )
    assert resp_eval.status_code == 200
    assert resp_eval.json()["count"] == 1

    # 4. Total Equipe / Voluntários -> 0 no ambiente de teste
    resp_org = await client.get(
        f"/api/v1/snacks/events/{event.id}/eligible-count?target_roles=ORGANIZER,VOLUNTEER",
        headers=admin_headers,
    )
    assert resp_org.status_code == 200
    assert resp_org.json()["count"] == 0

