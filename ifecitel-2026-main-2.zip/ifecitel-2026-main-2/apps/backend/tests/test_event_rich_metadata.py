"""Automated tests for rich event metadata, education levels quotas, and administrator management."""

from datetime import date, timedelta
import pytest
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.security import create_access_token
from app.models.enums import EducationLevelEnum, EventAdminRole, UserRole
from app.models.person import Person


@pytest.fixture
def admin_headers(seed_admin: Person) -> dict:
    """Gera cabeçalho de autenticação Bearer e API Key para o Administrador."""
    token = create_access_token(
        subject=str(seed_admin.id),
        claims={"role": "ADMIN", "email": seed_admin.email}
    )
    return {"Authorization": f"Bearer {token}", "X-API-Key": settings.API_KEY}


@pytest.mark.asyncio
async def test_create_event_with_rich_metadata_education_levels_and_admins(
    client: AsyncClient,
    admin_headers: dict,
    db_session: AsyncSession,
    seed_admin: Person
):
    """Testa cadastro completo com metadados ricos, cotas de níveis e gestores."""
    today = date.today()
    payload = {
        "name": "FECITEL Pantanal 2027",
        "year": 2027,
        "description": "Feira Científica Regional e Tecnológica do Pantanal",
        "location": "Campus Coxim IFMS - Auditório Central",
        "workload_hours": 60,
        "max_projects": 180,
        "start_date": str(today),
        "end_date": str(today + timedelta(days=4)),
        "summary_extension": "pdf",
        "banner_extension": "pdf",
        "organizing_institution": "Instituto Federal de Mato Grosso do Sul",
        "theme": "Biodiversidade e Sustentabilidade",
        "contact_email": "contato.pantanal@ifms.edu.br",
        "website_url": "https://fecitel-pantanal.ifms.edu.br",
        "logo_url": "https://fecitel-pantanal.ifms.edu.br/assets/logo.png",
        "education_levels": [
            {"level_name": "MEDIO", "max_students": 3, "min_evaluators": 3},
            {"level_name": "FUNDAMENTAL", "max_students": 5, "min_evaluators": 2}
        ],
        "administrators": [
            {"email": "organizador.coxim@ifms.edu.br", "role": "ORGANIZER"},
            {"email": "operador.coxim@ifms.edu.br", "role": "OPERATOR"}
        ]
    }

    resp = await client.post("/api/v1/events", headers=admin_headers, json=payload)
    assert resp.status_code == 201, resp.text
    data = resp.json()

    assert data["name"] == "FECITEL Pantanal 2027"
    assert data["year"] == 2027
    assert data["description"] == "Feira Científica Regional e Tecnológica do Pantanal"
    assert data["location"] == "Campus Coxim IFMS - Auditório Central"
    assert data["workload_hours"] == 60
    assert data["max_projects"] == 180
    assert data["summary_extension"] == "pdf"
    assert data["banner_extension"] == "pdf"
    assert data["organizing_institution"] == "Instituto Federal de Mato Grosso do Sul"
    assert data["theme"] == "Biodiversidade e Sustentabilidade"
    assert data["contact_email"] == "contato.pantanal@ifms.edu.br"
    assert data["website_url"] == "https://fecitel-pantanal.ifms.edu.br"
    assert data["logo_url"] == "https://fecitel-pantanal.ifms.edu.br/assets/logo.png"

    # Validação dos níveis de ensino
    assert data["education_levels"] is not None
    assert len(data["education_levels"]) == 2
    levels_map = {lvl["level_name"]: lvl for lvl in data["education_levels"]}
    assert "MEDIO" in levels_map
    assert levels_map["MEDIO"]["max_students"] == 3
    assert levels_map["MEDIO"]["min_evaluators"] == 3
    assert "FUNDAMENTAL" in levels_map
    assert levels_map["FUNDAMENTAL"]["max_students"] == 5
    assert levels_map["FUNDAMENTAL"]["min_evaluators"] == 2

    # Validação dos administradores vinculados
    assert data["administrators"] is not None
    admin_emails = {a["email"]: a for a in data["administrators"]}
    assert seed_admin.email in admin_emails
    assert admin_emails[seed_admin.email]["role"] == "COORDINATOR"
    assert admin_emails[seed_admin.email]["is_owner"] is True

    assert "organizador.coxim@ifms.edu.br" in admin_emails
    assert admin_emails["organizador.coxim@ifms.edu.br"]["role"] == "ORGANIZER"
    assert admin_emails["organizador.coxim@ifms.edu.br"]["is_owner"] is False

    assert "operador.coxim@ifms.edu.br" in admin_emails
    assert admin_emails["operador.coxim@ifms.edu.br"]["role"] == "OPERATOR"
    assert admin_emails["operador.coxim@ifms.edu.br"]["is_owner"] is False


@pytest.mark.asyncio
async def test_update_event_rich_metadata_and_relations(
    client: AsyncClient,
    admin_headers: dict,
    db_session: AsyncSession,
    seed_admin: Person
):
    """Testa atualização dos parâmetros, cotas de níveis e equipe de gestores."""
    today = date.today()
    # 1. Cria evento inicial
    create_payload = {
        "name": "FECITEL Fronteira 2027",
        "year": 2027,
        "start_date": str(today),
        "end_date": str(today + timedelta(days=3)),
        "education_levels": [
            {"level_name": "MEDIO", "max_students": 4, "min_evaluators": 2}
        ],
        "administrators": [
            {"email": "antigo.organizador@ifms.edu.br", "role": "ORGANIZER"}
        ]
    }
    create_resp = await client.post("/api/v1/events", headers=admin_headers, json=create_payload)
    assert create_resp.status_code == 201
    event_id = create_resp.json()["id"]

    # 2. Atualiza metadados, níveis e administradores
    update_payload = {
        "name": "FECITEL Fronteira 2027 - Atualizada",
        "theme": "Tecnologia de Fronteira e Inovação",
        "workload_hours": 50,
        "location": "Ponta Porã - Ginásio",
        "education_levels": [
            {"level_name": "MEDIO", "max_students": 2, "min_evaluators": 4},
            {"level_name": "JUNIOR", "max_students": 3, "min_evaluators": 2}
        ],
        "administrators": [
            {"email": "novo.organizador@ifms.edu.br", "role": "COORDINATOR"}
        ]
    }
    update_resp = await client.put(f"/api/v1/events/{event_id}", headers=admin_headers, json=update_payload)
    assert update_resp.status_code == 200, update_resp.text
    updated = update_resp.json()

    assert updated["name"] == "FECITEL Fronteira 2027 - Atualizada"
    assert updated["theme"] == "Tecnologia de Fronteira e Inovação"
    assert updated["workload_hours"] == 50
    assert updated["location"] == "Ponta Porã - Ginásio"

    # Níveis de ensino atualizados
    assert len(updated["education_levels"]) == 2
    lvl_map = {lvl["level_name"]: lvl for lvl in updated["education_levels"]}
    assert lvl_map["MEDIO"]["max_students"] == 2
    assert lvl_map["MEDIO"]["min_evaluators"] == 4
    assert lvl_map["JUNIOR"]["max_students"] == 3
    assert lvl_map["JUNIOR"]["min_evaluators"] == 2

    # Administradores atualizados: antigo foi removido, novo adicionado, criador mantido
    admin_emails = {a["email"]: a for a in updated["administrators"]}
    assert seed_admin.email in admin_emails
    assert "novo.organizador@ifms.edu.br" in admin_emails
    assert "antigo.organizador@ifms.edu.br" not in admin_emails


@pytest.mark.asyncio
async def test_get_and_list_events_with_rich_metadata(
    client: AsyncClient,
    admin_headers: dict,
    db_session: AsyncSession,
    seed_admin: Person
):
    """Testa consulta individual e listagem paginada garantindo eager loading das novas propriedades."""
    today = date.today()
    create_payload = {
        "name": "FECITEL Campo Grande 2027",
        "year": 2027,
        "organizing_institution": "IFMS Campus Campo Grande",
        "theme": "Inteligência Artificial Aplicada",
        "contact_email": "ia.cg@ifms.edu.br",
        "website_url": "https://ia-fecitel.ifms.edu.br",
        "logo_url": "https://ia-fecitel.ifms.edu.br/logo.png",
        "start_date": str(today),
        "end_date": str(today + timedelta(days=2)),
        "education_levels": [
            {"level_name": "FUNDAMENTAL", "max_students": 5, "min_evaluators": 3}
        ]
    }
    create_resp = await client.post("/api/v1/events", headers=admin_headers, json=create_payload)
    assert create_resp.status_code == 201
    event_id = create_resp.json()["id"]

    # 1. GET individual
    get_resp = await client.get(f"/api/v1/events/{event_id}", headers=admin_headers)
    assert get_resp.status_code == 200
    get_data = get_resp.json()
    assert get_data["id"] == event_id
    assert get_data["theme"] == "Inteligência Artificial Aplicada"
    assert len(get_data["education_levels"]) == 1
    assert get_data["education_levels"][0]["level_name"] == "FUNDAMENTAL"

    # 2. GET paginado
    pag_resp = await client.get("/api/v1/events?page=1&limit=15", headers=admin_headers)
    assert pag_resp.status_code == 200
    pag_data = pag_resp.json()
    matched = [e for e in pag_data["items"] if e["id"] == event_id]
    assert len(matched) == 1
    assert matched[0]["theme"] == "Inteligência Artificial Aplicada"
    assert len(matched[0]["education_levels"]) == 1
