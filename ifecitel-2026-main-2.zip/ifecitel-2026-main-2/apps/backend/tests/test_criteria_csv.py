"""Testes para download de modelo e importação em lote / CSV de critérios de avaliação."""

from datetime import date, timedelta
import pytest
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.core.security import create_access_token, get_password_hash
from app.models.enums import UserRole
from app.models.person import Person


@pytest.fixture
async def organizer_person(db_session: AsyncSession) -> Person:
    """Organizador para testes de critérios."""
    email = "organizer.criteria@easyevent.test"
    stmt = select(Person).where(Person.email == email)
    res = await db_session.execute(stmt)
    p = res.scalar_one_or_none()
    if not p:
        p = Person(
            name="Coordenador de Avaliação",
            email=email,
            role=UserRole.ADMIN,
            password_hash=get_password_hash("SenhaSegura123!"),
            barcode="BC-ORG-CRIT-01"
        )
        db_session.add(p)
        await db_session.commit()
        await db_session.refresh(p)
    return p


@pytest.fixture
def organizer_headers(organizer_person: Person) -> dict:
    token = create_access_token(subject=str(organizer_person.id), claims={"email": organizer_person.email})
    return {
        "Authorization": f"Bearer {token}",
        "X-API-Key": "fecitel_secret_api_key_2026"
    }


@pytest.mark.asyncio
async def test_criteria_csv_template_and_batch_import(
    client: AsyncClient,
    organizer_headers: dict
):
    """Testa download do modelo esqueleto e importação atômica em lote (Upsert)."""
    today = date.today()

    # 1. Criar evento de teste
    event_resp = await client.post(
        "/api/v1/events",
        headers=organizer_headers,
        json={
            "name": "Feira Tecnológica de Teste CSV 2026",
            "year": 2026,
            "start_date": str(today),
            "end_date": str(today + timedelta(days=3))
        }
    )
    assert event_resp.status_code == 201
    event_id = event_resp.json()["id"]

    # 2. Testar download do modelo esqueleto CSV
    tmpl_resp = await client.get(
        f"/api/v1/events/{event_id}/criteria/template-csv",
        headers=organizer_headers
    )
    assert tmpl_resp.status_code == 200
    assert "text/csv" in tmpl_resp.headers["content-type"]
    text_content = tmpl_resp.content.decode("utf-8-sig")
    assert "nome;pergunta_unica;descricao_cientifica;descricao_tecnologica;nota_maxima;peso" in text_content
    assert "Critério 1: Rigor Metodológico" in text_content

    # 3. Testar importação em lote via JSON (batch)
    batch_data = {
        "items": [
            {
                "name": "Critério A: Criatividade e Originalidade",
                "pergunta_unica": "Como os alunos demonstraram inovação no trabalho?",
                "max_score": 10.0,
                "weight": 1.5
            },
            {
                "name": "Critério B: Domínio Teórico",
                "scientific_description": "Qual o embasamento teórico científico do projeto?",
                "technological_description": "Qual a fundamentação tecnológica da solução?",
                "max_score": 10.0,
                "weight": 2.0
            }
        ]
    }

    import_resp = await client.post(
        f"/api/v1/events/{event_id}/criteria/batch",
        headers=organizer_headers,
        json=batch_data
    )
    assert import_resp.status_code == 200
    res_json = import_resp.json()
    assert res_json["total"] == 2
    assert res_json["created_count"] == 2
    assert res_json["updated_count"] == 0
    assert len(res_json["items"]) == 2

    # Verificar que o Critério A recebeu a pergunta unificada em ambos os campos
    crit_a = next(c for c in res_json["items"] if "Criatividade" in c["name"])
    assert crit_a["scientific_description"] == "Como os alunos demonstraram inovação no trabalho?"
    assert crit_a["technological_description"] == "Como os alunos demonstraram inovação no trabalho?"
    assert crit_a["weight"] == 1.5

    # 4. Testar Upsert: reenviar o Critério A com novo peso e adicionar Critério C
    update_batch_data = {
        "items": [
            {
                "name": "Critério A: Criatividade e Originalidade",
                "pergunta_unica": "Pergunta atualizada com novos parâmetros",
                "max_score": 10.0,
                "weight": 3.0
            },
            {
                "name": "Critério C: Impacto Social",
                "pergunta_unica": "Qual o impacto na comunidade?",
                "max_score": 10.0,
                "weight": 1.0
            }
        ]
    }

    update_resp = await client.post(
        f"/api/v1/events/{event_id}/criteria/batch",
        headers=organizer_headers,
        json=update_batch_data
    )
    assert update_resp.status_code == 200
    update_json = update_resp.json()
    assert update_json["total"] == 2
    assert update_json["created_count"] == 1  # Critério C
    assert update_json["updated_count"] == 1  # Critério A

    # 5. Listar critérios do evento: deve conter A, B e C (B foi preservado intacto!)
    list_resp = await client.get(
        f"/api/v1/events/{event_id}/criteria",
        headers=organizer_headers
    )
    assert list_resp.status_code == 200
    criteria_list = list_resp.json()
    assert len(criteria_list) == 3
    names = [c["name"] for c in criteria_list]
    assert "Critério A: Criatividade e Originalidade" in names
    assert "Critério B: Domínio Teórico" in names
    assert "Critério C: Impacto Social" in names

    crit_a_updated = next(c for c in criteria_list if "Criatividade" in c["name"])
    assert crit_a_updated["weight"] == 3.0


@pytest.mark.asyncio
async def test_criteria_upload_csv_file(
    client: AsyncClient,
    organizer_headers: dict
):
    """Testa upload multipart de arquivo CSV com delimitador ';' e decimais com vírgula."""
    today = date.today()

    event_resp = await client.post(
        "/api/v1/events",
        headers=organizer_headers,
        json={
            "name": "Mostra Científica CSV File 2026",
            "year": 2026,
            "start_date": str(today),
            "end_date": str(today + timedelta(days=2))
        }
    )
    assert event_resp.status_code == 201
    event_id = event_resp.json()["id"]

    # Conteúdo CSV simulado com UTF-8 BOM, ponto e vírgula e decimais em pt-BR
    csv_raw = (
        "\uFEFF"
        "nome;pergunta_unica;descricao_cientifica;descricao_tecnologica;nota_maxima;peso\r\n"
        "Critério CSV 1;Pergunta unificada para todos os projetos;;;10,0;1,5\r\n"
        "Critério CSV 2;;Pergunta Científica Detalhada;Pergunta Tecnológica Detalhada;10,0;2,5\r\n"
    )

    files = {
        "file": ("criterios_teste.csv", csv_raw.encode("utf-8"), "text/csv")
    }

    upload_resp = await client.post(
        f"/api/v1/events/{event_id}/criteria/upload-csv",
        headers=organizer_headers,
        files=files
    )
    assert upload_resp.status_code == 200
    res = upload_resp.json()
    assert res["total"] == 2
    assert res["created_count"] == 2
    assert res["updated_count"] == 0

    crit2 = next(c for c in res["items"] if "CSV 2" in c["name"])
    assert crit2["scientific_description"] == "Pergunta Científica Detalhada"
    assert crit2["technological_description"] == "Pergunta Tecnológica Detalhada"
    assert crit2["weight"] == 2.5
