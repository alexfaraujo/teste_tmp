"""Automated tests for Category Conflict of Interest (Grande Área + Nível de Ensino) and Override (Regra BR-10 / Opção 2)."""

from datetime import date, timedelta
import uuid
import pytest
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.security import create_access_token
from app.models.enums import AllocationStatus, EducationLevelEnum, ProjectMemberRole, ProjectStatus, ProjectType, UserRole
from app.models.event import Event
from app.models.knowledge_area import KnowledgeArea, Subarea
from app.models.person import EventParticipant, EventParticipantRole, Person, PersonEducationLevel, PersonSubarea
from app.models.project import Project, ProjectMember


@pytest.fixture
def admin_headers(seed_admin: Person) -> dict:
    token = create_access_token(
        subject=str(seed_admin.id),
        claims={"role": "ADMIN", "email": seed_admin.email}
    )
    return {"Authorization": f"Bearer {token}", "X-API-Key": settings.API_KEY}


@pytest.mark.asyncio
async def test_category_conflict_checkin_auto_balance_and_manual_override(
    client: AsyncClient,
    db_session: AsyncSession,
    seed_admin: Person,
    admin_headers: dict
):
    """
    Testa o ciclo completo da proteção de conflito de interesses por categoria (Opção 2):
    1. Check-in automático bloqueia trabalhos da mesma Grande Área e Nível de projetos orientados.
    2. Auto-balanceamento em lote também bloqueia concorrentes da mesma categoria.
    3. Alocação manual sem override retorna HTTP 409 Conflict com mensagem explicativa.
    4. Alocação manual COM override_conflict=True permite a atribuição excepcional.
    5. Alocação manual para o PRÓPRIO projeto orientado é bloqueada incondicionalmente com HTTP 400 (sem override).
    6. Avaliador que orienta no Ensino Médio PODE avaliar trabalho da mesma Grande Área no Ensino Fundamental.
    """
    suffix = uuid.uuid4().hex[:6]
    today = date.today()

    # 1. Evento
    event = Event(
        name=f"FECITEL Conflito Categoria {suffix}",
        year=2026,
        start_date=today,
        end_date=today + timedelta(days=2),
        max_projects_per_evaluator=5
    )
    db_session.add(event)
    await db_session.flush()

    # 2. Grande Área e Subárea
    area_eng = KnowledgeArea(event_id=event.id, name=f"Engenharias {suffix}")
    db_session.add(area_eng)
    await db_session.flush()

    sub_robotica = Subarea(area_id=area_eng.id, name=f"Robótica {suffix}")
    db_session.add(sub_robotica)
    await db_session.flush()

    # 3. Professor Orientador (que também é credenciado como Avaliador)
    prof_evaluator = Person(
        name=f"Prof. Dr. Avaliador e Orientador {suffix}",
        email=f"prof.eval.{suffix}@fecitel.ifms.edu.br",
        role=UserRole.EVALUATOR
    )
    db_session.add(prof_evaluator)
    await db_session.flush()

    # Papéis do professor: EVALUATOR no evento
    role_eval = EventParticipantRole(
        event_id=event.id,
        person_id=prof_evaluator.id,
        role=UserRole.EVALUATOR
    )
    db_session.add(role_eval)

    # Participação no evento
    part_prof = EventParticipant(
        event_id=event.id,
        person_id=prof_evaluator.id,
        presence_confirmed=True,
        evaluator_presence_confirmed=True
    )
    db_session.add(part_prof)

    # Subárea do avaliador
    qual_sub = PersonSubarea(
        event_id=event.id,
        person_id=prof_evaluator.id,
        subarea_id=sub_robotica.id
    )
    db_session.add(qual_sub)

    # Níveis habilitados para o professor: MEDIO e FUNDAMENTAL
    lvl_medio = PersonEducationLevel(
        event_id=event.id,
        person_id=prof_evaluator.id,
        education_level=EducationLevelEnum.MEDIO
    )
    lvl_fund = PersonEducationLevel(
        event_id=event.id,
        person_id=prof_evaluator.id,
        education_level=EducationLevelEnum.FUNDAMENTAL
    )
    db_session.add_all([lvl_medio, lvl_fund])
    await db_session.flush()

    # 4. Projetos do Evento:
    # P1: Orientado pelo professor (Engenharias / Robótica / MEDIO)
    p1 = Project(
        event_id=event.id,
        subarea_id=sub_robotica.id,
        title=f"Projeto do Próprio Professor {suffix}",
        project_type=ProjectType.TECHNOLOGICAL,
        education_level=EducationLevelEnum.MEDIO,
        status=ProjectStatus.PRESENT,
        booth_number="E-01",
        qrcode_token=f"QR-P1-{suffix}"
    )
    db_session.add(p1)
    await db_session.flush()

    mem_prof = ProjectMember(
        project_id=p1.id,
        person_id=prof_evaluator.id,
        role=ProjectMemberRole.ADVISOR
    )
    db_session.add(mem_prof)

    # P2: Concorrente Direto (Engenharias / Robótica / MEDIO) - Orientado por OUTRA pessoa
    p2 = Project(
        event_id=event.id,
        subarea_id=sub_robotica.id,
        title=f"Projeto Concorrente de Ensino Médio {suffix}",
        project_type=ProjectType.TECHNOLOGICAL,
        education_level=EducationLevelEnum.MEDIO,
        status=ProjectStatus.PRESENT,
        booth_number="E-02",
        qrcode_token=f"QR-P2-{suffix}"
    )
    db_session.add(p2)

    # P3: Outro Concorrente Direto (Engenharias / Robótica / MEDIO)
    p3 = Project(
        event_id=event.id,
        subarea_id=sub_robotica.id,
        title=f"Projeto Concorrente Médio 2 {suffix}",
        project_type=ProjectType.TECHNOLOGICAL,
        education_level=EducationLevelEnum.MEDIO,
        status=ProjectStatus.PRESENT,
        booth_number="E-03",
        qrcode_token=f"QR-P3-{suffix}"
    )
    db_session.add(p3)

    # P4: Projeto de Ensino Fundamental na mesma Grande Área (Engenharias / Robótica / FUNDAMENTAL)
    p4 = Project(
        event_id=event.id,
        subarea_id=sub_robotica.id,
        title=f"Robô Mirim do Fundamental {suffix}",
        project_type=ProjectType.TECHNOLOGICAL,
        education_level=EducationLevelEnum.FUNDAMENTAL,
        status=ProjectStatus.PRESENT,
        booth_number="E-04",
        qrcode_token=f"QR-P4-{suffix}"
    )
    db_session.add(p4)
    await db_session.commit()

    # ──────────────────────────────────────────────────────────────────────────
    # TESTE 1: Check-in Automático do Avaliador
    # O professor orienta P1 (MEDIO). P2 e P3 são MEDIO (concorrentes). P4 é FUNDAMENTAL.
    # Ao fazer check-in dinâmico, o sistema DEVE ALOCAR P4 e NÃO PODE alocar P1, P2 nem P3.
    # ──────────────────────────────────────────────────────────────────────────
    resp_checkin = await client.post(
        f"/api/v1/allocations/evaluators/{prof_evaluator.id}/checkin?event_id={event.id}",
        headers=admin_headers
    )
    assert resp_checkin.status_code == 200, resp_checkin.text
    checkin_data = resp_checkin.json()
    allocated_ids = [item["project_id"] for item in checkin_data["allocated_projects"]]

    # P1 é o próprio trabalho -> NUNCA ALOCADO
    assert p1.id not in allocated_ids, "Falha: Avaliador foi alocado ao seu próprio projeto!"
    # P2 e P3 são da mesma área e nível -> BLOQUEIO RÍGIDO DE CATEGORIA
    assert p2.id not in allocated_ids, "Falha: Avaliador alocado a concorrente direto da mesma Grande Área e Nível!"
    assert p3.id not in allocated_ids, "Falha: Avaliador alocado a concorrente direto da mesma Grande Área e Nível!"
    # P4 é FUNDAMENTAL (nível diferente, sem conflito de premiação) -> DEVE SER ALOCADO
    assert p4.id in allocated_ids, "Falha: Projeto de nível diferente compatível deveria ter sido alocado!"

    # ──────────────────────────────────────────────────────────────────────────
    # TESTE 2: Alocação Manual SEM Override para Concorrente (P2)
    # Deve retornar HTTP 409 Conflict com mensagem explicativa
    # ──────────────────────────────────────────────────────────────────────────
    resp_manual_no_override = await client.post(
        "/api/v1/allocations/manual",
        json={
            "event_id": event.id,
            "project_id": p2.id,
            "evaluator_id": prof_evaluator.id,
            "override_conflict": False
        },
        headers=admin_headers
    )
    assert resp_manual_no_override.status_code == 409, resp_manual_no_override.text
    assert "Conflito de interesses por categoria" in resp_manual_no_override.json()["detail"]
    assert "override" in resp_manual_no_override.json()["detail"].lower()

    # ──────────────────────────────────────────────────────────────────────────
    # TESTE 3: Alocação Manual COM Override para Concorrente (P2)
    # Deve ser permitida com sucesso (HTTP 200)
    # ──────────────────────────────────────────────────────────────────────────
    resp_manual_override = await client.post(
        "/api/v1/allocations/manual",
        json={
            "event_id": event.id,
            "project_id": p2.id,
            "evaluator_id": prof_evaluator.id,
            "override_conflict": True,
            "override_reason": "Autorizado pela comissão devido à falta de avaliadores externos na feira."
        },
        headers=admin_headers
    )
    assert resp_manual_override.status_code in (200, 201), resp_manual_override.text
    assert resp_manual_override.json()["project_id"] == p2.id

    # ──────────────────────────────────────────────────────────────────────────
    # TESTE 4: Alocação Manual para o PRÓPRIO PROJETO (P1)
    # Mesmo com override_conflict=True, DEVE SER REJEITADA com HTTP 400 Bad Request!
    # ──────────────────────────────────────────────────────────────────────────
    resp_manual_own_project = await client.post(
        "/api/v1/allocations/manual",
        json={
            "event_id": event.id,
            "project_id": p1.id,
            "evaluator_id": prof_evaluator.id,
            "override_conflict": True
        },
        headers=admin_headers
    )
    assert resp_manual_own_project.status_code == 400, resp_manual_own_project.text
    assert "o avaliador é orientador ou membro da equipe deste projeto" in resp_manual_own_project.json()["detail"]

    # ──────────────────────────────────────────────────────────────────────────
    # TESTE 5: Auto-balanceamento em Lote
    # Executa o auto-balance e valida que P3 (outro concorrente MEDIO) NÃO é alocado
    # para o prof_evaluator
    # ──────────────────────────────────────────────────────────────────────────
    resp_auto = await client.post(
        "/api/v1/allocations/auto-balance",
        json={"event_id": event.id},
        headers=admin_headers
    )
    assert resp_auto.status_code == 200, resp_auto.text

    # Listar alocações do professor e conferir que P3 e P1 nunca foram atribuídos no automático
    resp_list = await client.get(
        f"/api/v1/allocations?event_id={event.id}&evaluator_id={prof_evaluator.id}",
        headers=admin_headers
    )
    assert resp_list.status_code == 200
    eval_alloc_proj_ids = [a["project_id"] for a in resp_list.json()]
    assert p1.id not in eval_alloc_proj_ids, "Falha: P1 (próprio) foi alocado!"
    assert p3.id not in eval_alloc_proj_ids, "Falha: P3 (concorrente direto) foi alocado pelo auto-balance!"

