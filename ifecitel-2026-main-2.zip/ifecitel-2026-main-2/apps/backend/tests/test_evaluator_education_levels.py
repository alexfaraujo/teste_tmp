"""Testes automatizados para distinção e qualificação de níveis de ensino dos avaliadores."""

from datetime import date, timedelta
import uuid
import pytest
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.security import create_access_token
from app.models.enums import EducationLevelEnum, ProjectStatus, ProjectType, UserRole
from app.models.event import Event
from app.models.knowledge_area import KnowledgeArea, Subarea
from app.models.person import Person
from app.models.project import Project


@pytest.fixture
def admin_headers(seed_admin: Person) -> dict:
    """Gera cabeçalho Bearer e API Key para o Administrador."""
    token = create_access_token(
        subject=str(seed_admin.id),
        claims={"role": "ADMIN", "email": seed_admin.email}
    )
    return {"Authorization": f"Bearer {token}", "X-API-Key": settings.API_KEY}


@pytest.mark.asyncio
async def test_evaluator_education_levels_flow(
    client: AsyncClient,
    db_session: AsyncSession,
    admin_headers: dict
):
    """
    Testa o fluxo completo de restrição de nível de ensino para avaliadores:
    - Cadastro de avaliador restrito ao nível FUNDAMENTAL.
    - Listagem e detalhamento retornando education_levels.
    - Tentativa de alocação manual em projeto MEDIO bloqueada (400).
    - Alocação manual em projeto FUNDAMENTAL permitida.
    - Alocação dinâmica no check-in filtrando estritamente pelo nível permitido.
    - Avaliador sem restrição alocando universalmente.
    - Atualização dos níveis via endpoint de participantes.
    """
    suffix = uuid.uuid4().hex[:6]
    today = date.today()

    # 1. Criar Evento
    event = Event(
        name=f"Feira Niveis Test {suffix}",
        year=2026,
        start_date=today,
        end_date=today + timedelta(days=3),
        max_projects_per_evaluator=5
    )
    db_session.add(event)
    await db_session.flush()

    # 2. Criar Área e Subárea
    area = KnowledgeArea(name=f"Ciências da Natureza {suffix}", event_id=event.id)
    db_session.add(area)
    await db_session.flush()

    subarea = Subarea(name=f"Biologia Geral {suffix}", area_id=area.id)
    db_session.add(subarea)
    await db_session.flush()

    # 3. Criar Avaliador 1 (restrito ao FUNDAMENTAL) via API de participantes
    evaluator1_payload = {
        "name": f"Prof. Avaliador Fundamental {suffix}",
        "email": f"eval_fund_{suffix}@teste.com",
        "cpf": "111.222.333-44",
        "roles": ["EVALUATOR"],
        "subarea_ids": [subarea.id],
        "education_levels": ["FUNDAMENTAL"]
    }
    res = await client.post(
        f"/api/v1/participants?event_id={event.id}",
        json=evaluator1_payload,
        headers=admin_headers
    )
    assert res.status_code == 201, res.text
    eval1_data = res.json()
    eval1_person_id = eval1_data["person_id"]
    assert eval1_data["education_levels"] == ["FUNDAMENTAL"]

    # 4. Verificar detalhes do participante
    res_detail = await client.get(
        f"/api/v1/participants/{eval1_person_id}?event_id={event.id}",
        headers=admin_headers
    )
    assert res_detail.status_code == 200
    assert res_detail.json()["education_levels"] == ["FUNDAMENTAL"]

    # 5. Criar 2 Projetos presentes na mesma subárea: um MEDIO e um FUNDAMENTAL
    proj_medio = Project(
        event_id=event.id,
        subarea_id=subarea.id,
        title=f"Projeto Ensino Médio {suffix}",
        project_type=ProjectType.SCIENTIFIC,
        education_level=EducationLevelEnum.MEDIO,
        booth_number=f"B-MED-{suffix}",
        qrcode_token=f"QR-MED-{suffix}",
        status=ProjectStatus.PRESENT
    )
    proj_fund = Project(
        event_id=event.id,
        subarea_id=subarea.id,
        title=f"Projeto Ensino Fundamental {suffix}",
        project_type=ProjectType.SCIENTIFIC,
        education_level=EducationLevelEnum.FUNDAMENTAL,
        booth_number=f"B-FUND-{suffix}",
        qrcode_token=f"QR-FUND-{suffix}",
        status=ProjectStatus.PRESENT
    )
    db_session.add_all([proj_medio, proj_fund])
    await db_session.commit()

    # 6. Alocação Manual: tentar alocar Avaliador 1 (FUNDAMENTAL) no Projeto Médio -> Deve falhar com 400
    res_manual_fail = await client.post(
        "/api/v1/allocations/manual",
        json={
            "event_id": event.id,
            "project_id": proj_medio.id,
            "evaluator_id": eval1_person_id
        },
        headers=admin_headers
    )
    assert res_manual_fail.status_code == 400
    assert "Incompatibilidade de nível de ensino" in res_manual_fail.json()["detail"]

    # 7. Alocação Manual: alocar Avaliador 1 (FUNDAMENTAL) no Projeto Fundamental -> Deve ter sucesso
    res_manual_ok = await client.post(
        "/api/v1/allocations/manual",
        json={
            "event_id": event.id,
            "project_id": proj_fund.id,
            "evaluator_id": eval1_person_id
        },
        headers=admin_headers
    )
    assert res_manual_ok.status_code == 201
    assert res_manual_ok.json()["project_id"] == proj_fund.id

    # 8. Testar Alocação Dinâmica por Check-in para Avaliador 2 (restrito ao MEDIO)
    evaluator2_payload = {
        "name": f"Prof. Avaliador Medio {suffix}",
        "email": f"eval_medio_{suffix}@teste.com",
        "roles": ["EVALUATOR"],
        "subarea_ids": [subarea.id],
        "education_levels": ["MEDIO"]
    }
    res_ev2 = await client.post(
        f"/api/v1/participants?event_id={event.id}",
        json=evaluator2_payload,
        headers=admin_headers
    )
    assert res_ev2.status_code == 201
    eval2_person_id = res_ev2.json()["person_id"]

    # Fazer check-in dinâmico do Avaliador 2
    res_checkin = await client.post(
        f"/api/v1/allocations/evaluators/{eval2_person_id}/checkin?event_id={event.id}",
        headers=admin_headers
    )
    assert res_checkin.status_code == 200
    checkin_data = res_checkin.json()
    # O avaliador 2 só pode receber o projeto de Ensino Médio, nunca o Fundamental
    allocated_ids = [p["project_id"] for p in checkin_data["allocated_projects"]]
    assert proj_medio.id in allocated_ids
    assert proj_fund.id not in allocated_ids

    # 9. Testar listagem de avaliadores (/allocations/evaluators?event_id=...)
    res_eval_list = await client.get(
        f"/api/v1/allocations/evaluators?event_id={event.id}",
        headers=admin_headers
    )
    assert res_eval_list.status_code == 200
    evals = {e["id"]: e for e in res_eval_list.json()}
    assert eval1_person_id in evals
    assert evals[eval1_person_id]["education_levels"] == ["FUNDAMENTAL"]
    assert eval2_person_id in evals
    assert evals[eval2_person_id]["education_levels"] == ["MEDIO"]

    # 10. Testar atualização de níveis do Avaliador 1 para incluir MEDIO e FUNDAMENTAL
    res_update = await client.patch(
        f"/api/v1/participants/{eval1_person_id}?event_id={event.id}",
        json={"education_levels": ["FUNDAMENTAL", "MEDIO"]},
        headers=admin_headers
    )
    assert res_update.status_code == 200
    updated_levels = res_update.json()["education_levels"]
    assert "FUNDAMENTAL" in updated_levels and "MEDIO" in updated_levels


@pytest.mark.asyncio
async def test_evaluator_graduacao_and_pos_graduacao_levels(
    client: AsyncClient,
    db_session: AsyncSession,
    admin_headers: dict
):
    """Testa restrição e compatibilidade de avaliadores com GRADUACAO e POS_GRADUACAO."""
    suffix = uuid.uuid4().hex[:6]
    today = date.today()

    event = Event(
        name=f"Feira Superior Test {suffix}",
        year=2026,
        start_date=today,
        end_date=today + timedelta(days=2),
        max_projects_per_evaluator=3
    )
    db_session.add(event)
    await db_session.flush()

    area = KnowledgeArea(name=f"Engenharias {suffix}", event_id=event.id)
    db_session.add(area)
    await db_session.flush()

    subarea = Subarea(name=f"Engenharia de Software {suffix}", area_id=area.id)
    db_session.add(subarea)
    await db_session.flush()

    # Criar Avaliador restrito a GRADUACAO
    eval_payload = {
        "name": f"Dr. Avaliador Graduacao {suffix}",
        "email": f"eval_grad_{suffix}@superior.edu.br",
        "roles": ["EVALUATOR"],
        "subarea_ids": [subarea.id],
        "education_levels": ["GRADUACAO"]
    }
    resp_eval = await client.post(
        f"/api/v1/participants?event_id={event.id}",
        headers=admin_headers,
        json=eval_payload
    )
    assert resp_eval.status_code == 201, resp_eval.text
    eval_id = resp_eval.json()["person_id"]

    # Criar Projeto GRADUACAO
    proj_grad = Project(
        event_id=event.id,
        title=f"Projeto Graduacao {suffix}",
        subarea_id=subarea.id,
        education_level=EducationLevelEnum.GRADUACAO,
        status=ProjectStatus.PRESENT,
        project_type=ProjectType.TECHNOLOGICAL,
        booth_number="G-01",
        qrcode_token=f"QR-GRAD-{suffix}"
    )
    # Criar Projeto POS_GRADUACAO
    proj_pos = Project(
        event_id=event.id,
        title=f"Projeto Pos-Graduacao {suffix}",
        subarea_id=subarea.id,
        education_level=EducationLevelEnum.POS_GRADUACAO,
        status=ProjectStatus.PRESENT,
        project_type=ProjectType.SCIENTIFIC,
        booth_number="PG-01",
        qrcode_token=f"QR-POS-{suffix}"
    )
    db_session.add_all([proj_grad, proj_pos])
    await db_session.commit()

    # Tentativa de alocação no projeto de POS_GRADUACAO deve falhar (400)
    resp_bad = await client.post(
        "/api/v1/allocations/manual",
        headers=admin_headers,
        json={"event_id": event.id, "evaluator_id": eval_id, "project_id": proj_pos.id}
    )
    assert resp_bad.status_code == 400
    assert "Incompatibilidade de nível de ensino" in resp_bad.json()["detail"]

    # Alocação no projeto de GRADUACAO deve ter sucesso (201)
    resp_ok = await client.post(
        "/api/v1/allocations/manual",
        headers=admin_headers,
        json={"event_id": event.id, "evaluator_id": eval_id, "project_id": proj_grad.id}
    )
    assert resp_ok.status_code == 201

