"""Automated integration tests for Dynamic Evaluator Allocation on Check-in (Regra BR-10)."""

from datetime import date, timedelta
import uuid
import pytest
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.security import create_access_token
from app.models.enums import AllocationStatus, AllocationType, EducationLevelEnum, ProjectMemberRole, ProjectStatus, ProjectType, UserRole
from app.models.event import Event
from app.models.knowledge_area import KnowledgeArea, Subarea
from app.models.person import Person, PersonSubarea
from app.models.project import Project, ProjectMember


@pytest.fixture
def admin_headers(seed_admin: Person) -> dict:
    token = create_access_token(
        subject=str(seed_admin.id),
        claims={"role": "ADMIN", "email": seed_admin.email}
    )
    return {"Authorization": f"Bearer {token}", "X-API-Key": settings.API_KEY}


@pytest.mark.asyncio
async def test_dynamic_evaluator_allocation_on_checkin_and_barcode(
    client: AsyncClient,
    db_session: AsyncSession,
    seed_admin: Person,
    admin_headers: dict
):
    """
    Testa a alocação dinâmica disparada no momento do check-in do avaliador (BR-10):
    1. Criação de evento com teto de 2 projetos por avaliador.
    2. Submissão de 3 projetos na mesma subárea, todos marcados como PRESENT.
    3. Criação de Avaliador 1 (com subárea vinculada) e Avaliador 2.
    4. Check-in do Avaliador 1 via endpoint dedicado:
       - Deve alocar os 2 primeiros trabalhos presentes (capacidade máxima = 2).
       - Os trabalhos ficam com 1 avaliador cada.
    5. Check-in do Avaliador 2 via leitura de código de barras (scan-barcode):
       - Deve priorizar o 3º trabalho (que ainda tem 0 avaliadores), assegurando delta <= 1.
       - Depois, aloca um dos trabalhos que tem 1 avaliador.
    6. Verificação de bloqueio de conflito de interesses.
    """
    suffix = uuid.uuid4().hex[:6]
    today = date.today()

    # 1. Evento
    event = Event(
        name=f"FECITEL Dinâmica {suffix}",
        year=2026,
        start_date=today,
        end_date=today + timedelta(days=2),
        max_projects_per_evaluator=2
    )
    db_session.add(event)
    await db_session.flush()

    # 2. Área e Subárea
    area = KnowledgeArea(event_id=event.id, name=f"Engenharias {suffix}")
    db_session.add(area)
    await db_session.flush()

    subarea = Subarea(area_id=area.id, name=f"Robótica {suffix}")
    db_session.add(subarea)
    await db_session.flush()

    # 3. Orientador e Alunos para os 3 projetos
    advisor = Person(
        name=f"Prof Orientador {suffix}",
        email=f"orientador.{suffix}@fecitel.ifms.edu.br",
        role=UserRole.ADVISOR
    )
    db_session.add(advisor)
    await db_session.flush()

    # 3 Projetos PRESENTES
    p1 = Project(
        event_id=event.id,
        subarea_id=subarea.id,
        title=f"Robô Explorador 1 {suffix}",
        project_type=ProjectType.TECHNOLOGICAL,
        education_level=EducationLevelEnum.MEDIO,
        status=ProjectStatus.PRESENT,
        booth_number="E-01",
        qrcode_token=f"QR-P1-{suffix}"
    )
    p2 = Project(
        event_id=event.id,
        subarea_id=subarea.id,
        title=f"Braço Biônico 2 {suffix}",
        project_type=ProjectType.TECHNOLOGICAL,
        education_level=EducationLevelEnum.FUNDAMENTAL,
        status=ProjectStatus.PRESENT,
        booth_number="E-02",
        qrcode_token=f"QR-P2-{suffix}"
    )
    p3 = Project(
        event_id=event.id,
        subarea_id=subarea.id,
        title=f"Drone Agrícola 3 {suffix}",
        project_type=ProjectType.TECHNOLOGICAL,
        education_level=EducationLevelEnum.FUNDAMENTAL,
        status=ProjectStatus.PRESENT,
        booth_number="E-03",
        qrcode_token=f"QR-P3-{suffix}"
    )
    db_session.add_all([p1, p2, p3])
    await db_session.flush()

    # Vincular orientador ao Projeto 1 (para testar conflito de interesses)
    m1 = ProjectMember(project_id=p1.id, person_id=advisor.id, role=ProjectMemberRole.ADVISOR)
    db_session.add(m1)
    await db_session.flush()

    # 4. Avaliador 1 (sem conflito)
    eval1 = Person(
        name=f"Avaliadora Clara {suffix}",
        email=f"clara.{suffix}@fecitel.ifms.edu.br",
        role=UserRole.EVALUATOR,
        barcode=f"BC-EVAL-CLARA-{suffix}"
    )
    # Avaliador 2 (que também é o orientador do P1 -> conflito com P1)
    # Qualificar ambos na subárea
    db_session.add(eval1)
    await db_session.flush()

    qual1 = PersonSubarea(person_id=eval1.id, subarea_id=subarea.id, event_id=event.id)
    qual_adv = PersonSubarea(person_id=advisor.id, subarea_id=subarea.id, event_id=event.id)
    db_session.add_all([qual1, qual_adv])
    await db_session.commit()

    # 5. Check-in do Avaliador 1 via Endpoint Direto
    checkin_resp = await client.post(
        f"/api/v1/allocations/evaluators/{eval1.id}/checkin?event_id={event.id}",
        headers=admin_headers
    )
    assert checkin_resp.status_code == 200, checkin_resp.text
    data1 = checkin_resp.json()
    assert data1["evaluator_id"] == eval1.id
    assert data1["evaluator_presence_confirmed"] is True
    assert data1["presence_confirmed"] is False  # Não passou pela recepção geral
    assert data1["allocated_projects_count"] == 2
    allocated_p_ids = [p["project_id"] for p in data1["allocated_projects"]]
    assert len(allocated_p_ids) == 2

    # 6. Check-in do Orientador/Avaliador via Barcode Scan
    advisor.barcode = f"BC-ADV-{suffix}"
    advisor.role = UserRole.EVALUATOR  # Multi-papel credenciado como avaliador
    await db_session.commit()

    # 6.1 Scan na Recepção Geral: Confirma presença física e ativa estande, SEM alocar avaliação
    scan_resp = await client.post(
        "/api/v1/logistics/scan-barcode",
        json={"barcode": advisor.barcode, "event_id": event.id},
        headers={"X-API-Key": settings.API_KEY}
    )
    assert scan_resp.status_code == 200, scan_resp.text
    scan_data = scan_resp.json()
    assert scan_data["presence_confirmed"] is True
    assert scan_data["allocated_projects_count"] is None
    assert "Sala dos Avaliadores" in scan_data["message"]

    # 6.2 Check-in na Sala dos Avaliadores (via /scan-checkin): Confirma presença de avaliador e aloca projetos
    eval_scan_resp = await client.post(
        "/api/v1/allocations/evaluators/scan-checkin",
        json={"barcode": advisor.barcode, "event_id": event.id},
        headers=admin_headers
    )
    assert eval_scan_resp.status_code == 200, eval_scan_resp.text
    eval_scan_data = eval_scan_resp.json()
    assert eval_scan_data["evaluator_presence_confirmed"] is True
    assert eval_scan_data["allocated_projects_count"] == 2

    # 7. Verificar que o orientador NÃO foi alocado ao Projeto 1 (conflito de interesses)
    allocs_resp = await client.get(
        f"/api/v1/allocations?event_id={event.id}&evaluator_id={advisor.id}",
        headers=admin_headers
    )
    assert allocs_resp.status_code == 200
    adv_allocs = allocs_resp.json()
    assert len(adv_allocs) == 2
    adv_project_ids = [a["project_id"] for a in adv_allocs]
    assert p1.id not in adv_project_ids, "Orientador não pode ser alocado ao próprio projeto P1!"
    assert p2.id in adv_project_ids
    assert p3.id in adv_project_ids

    # 8. Conferir a Regra de Ouro (delta <= 1):
    # Total de alocações: P1 tem 1 (eval1), P2 tem 2 (eval1 e advisor), P3 tem 1 (eval1)
    # A diferença máxima é 2 - 1 = 1 <= 1!
    all_allocs_resp = await client.get(
        f"/api/v1/allocations?event_id={event.id}",
        headers=admin_headers
    )
    assert all_allocs_resp.status_code == 200
    all_allocs = all_allocs_resp.json()
    assert len(all_allocs) == 4

    # 9. Testar avaliador que vai DIRETO para a Sala dos Avaliadores (sem passar pela portaria)
    eval_direct = Person(
        name=f"Avaliador Direto {suffix}",
        email=f"direto.{suffix}@fecitel.ifms.edu.br",
        role=UserRole.EVALUATOR,
        barcode=f"BC-DIRECT-{suffix}"
    )
    db_session.add(eval_direct)
    await db_session.flush()
    qual_direct = PersonSubarea(person_id=eval_direct.id, subarea_id=subarea.id, event_id=event.id)
    db_session.add(qual_direct)
    await db_session.commit()

    direct_resp = await client.post(
        "/api/v1/allocations/evaluators/scan-checkin",
        json={"barcode": eval_direct.barcode, "event_id": event.id},
        headers=admin_headers
    )
    assert direct_resp.status_code == 200, direct_resp.text
    direct_data = direct_resp.json()
    assert direct_data["presence_confirmed"] is False  # Veio direto para sala de avaliação, sem recepção
    assert direct_data["evaluator_presence_confirmed"] is True

    # 10. Testar rejeição de pessoa sem papel de avaliador na Sala dos Avaliadores
    non_eval = Person(
        name=f"Estudante Curioso {suffix}",
        email=f"curioso.{suffix}@escola.com",
        role=UserRole.STUDENT,
        barcode=f"BC-STUDENT-{suffix}"
    )
    db_session.add(non_eval)
    await db_session.commit()

    rej_resp = await client.post(
        "/api/v1/allocations/evaluators/scan-checkin",
        json={"barcode": non_eval.barcode, "event_id": event.id},
        headers=admin_headers
    )
    assert rej_resp.status_code == 400
    assert "não possui cadastro" in rej_resp.json()["detail"]

    # 11. Testar re-checkin de avaliador que já possui check-in:
    # Deve indicar already_checked_in == True, retornar a lista de trabalhos já alocados (não zerada) e mensagem clara
    recheck_resp = await client.post(
        "/api/v1/allocations/evaluators/scan-checkin",
        json={"barcode": advisor.barcode, "event_id": event.id},
        headers=admin_headers
    )
    assert recheck_resp.status_code == 200, recheck_resp.text
    recheck_data = recheck_resp.json()
    assert recheck_data["already_checked_in"] is True
    assert recheck_data["allocated_projects_count"] == 2
    assert len(recheck_data["allocated_projects"]) == 2
    assert "já realizado anteriormente" in recheck_data["message"]
