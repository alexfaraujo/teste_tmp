"""Pytest fixtures configured directly for PostgreSQL bare-metal (Zero Mocks)."""

from collections.abc import AsyncGenerator
import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.pool import NullPool

from app.core.config import settings
from app.core.database import Base, get_db
from app.core.security import get_password_hash
from app.main import app
from app.models.enums import UserRole
from app.models.person import Person

# Engine de teste com NullPool (evita retenção de conexões entre múltiplos event loops)
test_engine = create_async_engine(
    settings.DATABASE_URL,
    poolclass=NullPool,
    echo=False
)
TestSessionLocal = async_sessionmaker(
    bind=test_engine,
    class_=AsyncSession,
    autoflush=False,
    expire_on_commit=False
)


@pytest_asyncio.fixture(scope="session", autouse=True)
async def prepare_database():
    """Garante que todas as tabelas existem no PostgreSQL real antes dos testes."""
    from sqlalchemy import text
    async with test_engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
        await conn.execute(text("ALTER TABLE events ADD COLUMN IF NOT EXISTS owner_id INTEGER REFERENCES people(id) ON DELETE SET NULL;"))
        await conn.execute(text("CREATE INDEX IF NOT EXISTS ix_events_owner_id ON events(owner_id);"))
    yield
    await test_engine.dispose()


@pytest_asyncio.fixture
async def db_session() -> AsyncGenerator[AsyncSession, None]:
    """Fornece uma sessão transacional isolada para os testes no banco real."""
    async with TestSessionLocal() as session:
        yield session
        await session.rollback()


@pytest_asyncio.fixture
async def client(db_session: AsyncSession) -> AsyncGenerator[AsyncClient, None]:
    """Cliente HTTP assíncrono para testar endpoints da API com API Key corporativa configurada."""
    async def override_get_db():
        yield db_session

    app.dependency_overrides[get_db] = override_get_db
    transport = ASGITransport(app=app)
    async with AsyncClient(
        transport=transport,
        base_url="http://testserver",
        headers={"X-API-Key": settings.API_KEY}
    ) as ac:
        yield ac
    app.dependency_overrides.clear()


@pytest_asyncio.fixture
async def unauthenticated_client(db_session: AsyncSession) -> AsyncGenerator[AsyncClient, None]:
    """Cliente HTTP assíncrono sem API Key no cabeçalho (para testar rejeição universal da Regra SEC-03)."""
    async def override_get_db():
        yield db_session

    app.dependency_overrides[get_db] = override_get_db
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://testserver") as ac:
        yield ac
    app.dependency_overrides.clear()


@pytest_asyncio.fixture
async def seed_admin(db_session: AsyncSession) -> Person:
    """Cria ou recupera um administrador pré-cadastrado no banco real."""
    from sqlalchemy import select
    stmt = select(Person).where(Person.email == "admin.teste@fecitel.ifms.edu.br")
    res = await db_session.execute(stmt)
    admin = res.scalar_one_or_none()

    if not admin:
        admin = Person(
            name="Administrador de Teste",
            email="admin.teste@fecitel.ifms.edu.br",
            role=UserRole.ADMIN,
            password_hash=get_password_hash("SenhaSuperSegura123!"),
            barcode="BC-ADMIN-0001"
        )
        db_session.add(admin)
        await db_session.commit()
        await db_session.refresh(admin)

    return admin


@pytest_asyncio.fixture
async def seed_evaluator(db_session: AsyncSession) -> Person:
    """Cria ou recupera um avaliador pré-cadastrado no banco real."""
    from sqlalchemy import select
    stmt = select(Person).where(Person.email == "avaliador.teste@fecitel.ifms.edu.br")
    res = await db_session.execute(stmt)
    evaluator = res.scalar_one_or_none()

    if not evaluator:
        evaluator = Person(
            name="Prof. Dr. Avaliador Teste",
            email="avaliador.teste@fecitel.ifms.edu.br",
            role=UserRole.EVALUATOR,
            barcode="BC-EVAL-0001"
        )
        db_session.add(evaluator)
        await db_session.commit()
        await db_session.refresh(evaluator)

    return evaluator
