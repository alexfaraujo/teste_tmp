"""Unit tests for database URL formatting and special characters in passwords."""

from alembic.config import Config
from sqlalchemy.engine import make_url

from app.core.config import Settings, _build_safe_database_url


def test_password_with_special_characters_in_raw_url():
    """Valida que senhas com @, #, $, %, etc. em DATABASE_URL são tratadas e decodificadas corretamente."""
    raw_passwords = [
        "minha@senha#2026",
        "segredo$100%forte",
        "p@ss#word$123%teste",
        "pass:word/complex",
        "senha@com@varios@arrobas",
    ]

    for raw_pass in raw_passwords:
        raw_url = f"postgresql+asyncpg://fecitel_user:{raw_pass}@127.0.0.1:5432/fecitel_db"
        safe_url = _build_safe_database_url(raw_url)
        parsed = make_url(safe_url)

        # O host deve ser preservado estritamente como 127.0.0.1
        assert parsed.host == "127.0.0.1", f"Host corrompido para {raw_pass}: {parsed.host}"
        assert parsed.port == 5432
        assert parsed.database == "fecitel_db"
        assert parsed.username == "fecitel_user"
        # A senha decodificada pelo SQLAlchemy deve ser exatamente a senha original
        assert parsed.password == raw_pass, f"Senha decodificada difere da original: {parsed.password} != {raw_pass}"


def test_password_with_discrete_environment_variables():
    """Valida que variáveis separadas DB_USER, DB_PASSWORD, DB_HOST constroem a URL com escape seguro."""
    special_pass = "SenhaForte@#$2026%Com!Tudo"
    safe_url = _build_safe_database_url(
        raw_url="postgresql+asyncpg://fallback:fallback@localhost/db",
        db_user="admin_feiras",
        db_password=special_pass,
        db_host="localhost",
        db_port=5432,
        db_name="feiras_db",
        db_driver="postgresql+asyncpg"
    )
    parsed = make_url(safe_url)

    assert parsed.username == "admin_feiras"
    assert parsed.password == special_pass
    assert parsed.host == "localhost"
    assert parsed.port == 5432
    assert parsed.database == "feiras_db"


def test_already_percent_encoded_password_preserves_without_double_encoding():
    """Garante que se o administrador já passou a URL codificada (%40, %23), não há double-encoding (%2540)."""
    encoded_url = "postgresql+asyncpg://fecitel_user:minha%40senha%232026@127.0.0.1:5432/fecitel_db"
    safe_url = _build_safe_database_url(encoded_url)

    assert "%2540" not in safe_url, "Houve double-encoding indevido do símbolo @"
    assert "%2523" not in safe_url, "Houve double-encoding indevido do símbolo #"
    parsed = make_url(safe_url)
    assert parsed.password == "minha@senha#2026"


def test_alembic_configparser_compatibility_with_escaped_url():
    """Garante que a URL com percent-encoding (%) não quebra o ConfigParser do Alembic ao usar replace('%', '%%')."""
    raw_url = "postgresql+asyncpg://fecitel_user:p@ss#word%123@127.0.0.1:5432/fecitel_db"
    safe_url = _build_safe_database_url(raw_url)

    cfg = Config()
    # Deve executar sem levantar ValueError (invalid interpolation syntax)
    cfg.set_main_option("sqlalchemy.url", safe_url.replace("%", "%%"))
    retrieved_url = cfg.get_main_option("sqlalchemy.url")

    # Ao ler do ConfigParser, os %% voltam a ser %
    assert retrieved_url == safe_url
