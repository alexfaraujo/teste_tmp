"""Testes automatizados para upload de logo (PNG/JPG) e geração de crachás em PDF (Lote e Individual)."""

from datetime import date, timedelta
import io
import pytest
from httpx import AsyncClient
from PIL import Image
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.core.security import create_access_token, get_password_hash
from app.models.enums import UserRole, EducationLevelEnum
from app.models.event import Event
from app.models.person import Person, EventParticipant, EventParticipantRole


def _create_dummy_image(format_type: str = "PNG") -> bytes:
    """Gera uma imagem de 50x50 em memória para teste de upload."""
    img = Image.new("RGB", (50, 50), color=(13, 148, 136))
    buf = io.BytesIO()
    img.save(buf, format=format_type)
    return buf.getvalue()


@pytest.fixture
async def admin_person_badges(db_session: AsyncSession) -> Person:
    """Administrador para testes de crachás e upload de logos."""
    email = "admin.badges@easyevent.test"
    stmt = select(Person).where(Person.email == email)
    res = await db_session.execute(stmt)
    p = res.scalar_one_or_none()
    if not p:
        p = Person(
            name="Gestor de Crachás e Logos",
            email=email,
            role=UserRole.ADMIN,
            password_hash=get_password_hash("SenhaForte123!"),
            barcode="BC-ADMIN-BADGES-01",
        )
        db_session.add(p)
        await db_session.commit()
        await db_session.refresh(p)
    return p


@pytest.fixture
def admin_badges_headers(admin_person_badges: Person) -> dict:
    token = create_access_token(
        subject=str(admin_person_badges.id),
        claims={"email": admin_person_badges.email},
    )
    return {
        "Authorization": f"Bearer {token}",
        "X-API-Key": "fecitel_secret_api_key_2026",
    }


@pytest.mark.asyncio
async def test_upload_event_logo_png_and_jpg(
    client: AsyncClient,
    admin_badges_headers: dict,
    db_session: AsyncSession,
):
    """Testa upload de logotipo nos formatos PNG e JPG, e bloqueio de formatos inválidos."""
    today = date.today()
    evt_res = await client.post(
        "/api/v1/events",
        json={
            "name": "Feira Logo Test 2026",
            "year": 2026,
            "start_date": today.isoformat(),
            "end_date": (today + timedelta(days=4)).isoformat(),
            "location": "Campus Central",
        },
        headers=admin_badges_headers,
    )
    assert evt_res.status_code == 201
    event_id = evt_res.json()["id"]

    # 1. Upload avulso (temp) com PNG
    png_bytes = _create_dummy_image("PNG")
    temp_res = await client.post(
        "/api/v1/events/upload-logo",
        files={"file": ("logo.png", png_bytes, "image/png")},
        headers=admin_badges_headers,
    )
    assert temp_res.status_code == 200
    assert "/static/uploads/logos/logo_" in temp_res.json()["logo_url"]
    assert temp_res.json()["logo_url"].endswith(".png")

    # 2. Upload de JPG na edição do evento
    jpg_bytes = _create_dummy_image("JPEG")
    logo_res = await client.post(
        f"/api/v1/events/{event_id}/logo",
        files={"file": ("marca.jpg", jpg_bytes, "image/jpeg")},
        headers=admin_badges_headers,
    )
    assert logo_res.status_code == 200
    logo_url = logo_res.json()["logo_url"]
    assert "/static/uploads/logos/event_" in logo_url
    assert logo_url.endswith(".jpg")

    # Confirmar atualização no GET do evento
    get_res = await client.get(
        f"/api/v1/events/{event_id}",
        headers=admin_badges_headers,
    )
    assert get_res.status_code == 200
    assert get_res.json()["logo_url"] == logo_url

    # 3. Testar rejeição de formato inválido (ex: .txt)
    bad_res = await client.post(
        f"/api/v1/events/{event_id}/logo",
        files={"file": ("documento.txt", b"conteudo de texto", "text/plain")},
        headers=admin_badges_headers,
    )
    assert bad_res.status_code == 400
    assert "Formato de imagem inválido" in bad_res.json()["detail"]


@pytest.mark.asyncio
async def test_generate_badges_pdf_batch_and_individual(
    client: AsyncClient,
    admin_badges_headers: dict,
    db_session: AsyncSession,
):
    """Testa geração de crachás em lote e individual em PDF pronto para impressão."""
    today = date.today()
    evt_res = await client.post(
        "/api/v1/events",
        json={
            "name": "Mostra de Iniciação Científica 2026",
            "year": 2026,
            "start_date": today.isoformat(),
            "end_date": (today + timedelta(days=3)).isoformat(),
            "location": "Pavilhão de Exposições",
            "organizing_institution": "Instituto Federal IFMS",
        },
        headers=admin_badges_headers,
    )
    assert evt_res.status_code == 201
    event_id = evt_res.json()["id"]

    # 1. Cadastrar logo PNG para a feira
    png_bytes = _create_dummy_image("PNG")
    await client.post(
        f"/api/v1/events/{event_id}/logo",
        files={"file": ("logo_mostra.png", png_bytes, "image/png")},
        headers=admin_badges_headers,
    )

    # 2. Cadastrar Áreas e Subáreas
    await client.post(
        f"/api/v1/events/{event_id}/areas/batch",
        json={
            "items": [
                {"area": "Engenharias", "subarea": "Robótica"},
                {"area": "Ciências Exatas", "subarea": "Informática"},
            ]
        },
        headers=admin_badges_headers,
    )

    # 3. Importar participantes (Estudante, Orientador e Avaliador)
    part_res = await client.post(
        f"/api/v1/participants/batch?event_id={event_id}",
        json={
            "items": [
                {
                    "name": "Estudante Lucas Almeida",
                    "email": "lucas.cracha@estudante.edu.br",
                    "roles": ["STUDENT"],
                    "cpf": "111.222.333-44",
                    "affiliation": "IFMS",
                    "subareas": [],
                    "education_levels": ["MEDIO"],
                },
                {
                    "name": "Profa. Mariana Costa",
                    "email": "mariana.cracha@escola.edu.br",
                    "roles": ["ADVISOR"],
                    "affiliation": "IFMS",
                    "subareas": [],
                    "education_levels": [],
                },
                {
                    "name": "Dr. Carlos Avaliador",
                    "email": "carlos.cracha@universidade.br",
                    "roles": ["EVALUATOR"],
                    "affiliation": "UFMS",
                    "subareas": ["Engenharias -> Robótica"],
                    "education_levels": ["MEDIO", "GRADUACAO"],
                }
            ]
        },
        headers=admin_badges_headers,
    )
    assert part_res.status_code == 200
    part_data = part_res.json()
    first_part_id = part_data["items"][0]["participant_id"]
    first_person_id = part_data["items"][0]["person_id"]

    # 4. Exportar crachá individual em PDF usando participant_id
    ind_res = await client.get(
        f"/api/v1/participants/{first_part_id}/badge/pdf?event_id={event_id}",
        headers=admin_badges_headers,
    )
    assert ind_res.status_code == 200
    assert ind_res.headers["content-type"] == "application/pdf"
    assert "attachment; filename=" in ind_res.headers["content-disposition"]
    # Valida cabeçalho mágico de arquivo PDF (%PDF-)
    assert ind_res.content.startswith(b"%PDF-")
    assert len(ind_res.content) > 1000

    # 4b. Exportar crachá individual em PDF usando person_id (compatibilidade flexível)
    ind_res_person = await client.get(
        f"/api/v1/participants/{first_person_id}/badge/pdf?event_id={event_id}",
        headers=admin_badges_headers,
    )
    assert ind_res_person.status_code == 200
    assert ind_res_person.content.startswith(b"%PDF-")
    assert len(ind_res_person.content) > 1000

    # 5. Exportar lote completo de crachás em PDF (filter=all)
    batch_res = await client.get(
        f"/api/v1/events/{event_id}/badges/pdf?filter=all",
        headers=admin_badges_headers,
    )
    assert batch_res.status_code == 200
    assert batch_res.headers["content-type"] == "application/pdf"
    assert "attachment; filename=" in batch_res.headers["content-disposition"]
    assert batch_res.content.startswith(b"%PDF-")
    assert len(batch_res.content) > 2000

    # 6. Exportar lote filtrado (filter=evaluators)
    eval_res = await client.get(
        f"/api/v1/events/{event_id}/badges/pdf?filter=evaluators",
        headers=admin_badges_headers,
    )
    assert eval_res.status_code == 200
    assert eval_res.content.startswith(b"%PDF-")
