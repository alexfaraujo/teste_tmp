"""Testes automatizados para importação em lote de grandes áreas e subáreas do conhecimento (Regra BR-16)."""

from datetime import date, timedelta
import pytest
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.core.security import create_access_token, get_password_hash
from app.models.enums import UserRole
from app.models.person import Person
from app.models.knowledge_area import KnowledgeArea, Subarea


@pytest.fixture
async def admin_person_areas(db_session: AsyncSession) -> Person:
    """Administrador para testes de importação em lote de áreas."""
    email = "admin.batchareas@easyevent.test"
    stmt = select(Person).where(Person.email == email)
    res = await db_session.execute(stmt)
    p = res.scalar_one_or_none()
    if not p:
        p = Person(
            name="Gestor de Áreas",
            email=email,
            role=UserRole.ADMIN,
            password_hash=get_password_hash("SenhaSegura123!"),
            barcode="BC-ADMIN-AREAS-01"
        )
        db_session.add(p)
        await db_session.commit()
        await db_session.refresh(p)
    return p


@pytest.fixture
def admin_areas_headers(admin_person_areas: Person) -> dict:
    token = create_access_token(subject=str(admin_person_areas.id), claims={"email": admin_person_areas.email})
    return {
        "Authorization": f"Bearer {token}",
        "X-API-Key": "fecitel_secret_api_key_2026"
    }


@pytest.mark.asyncio
async def test_knowledge_areas_batch_import_and_idempotency(
    client: AsyncClient,
    admin_areas_headers: dict,
    db_session: AsyncSession
):
    """Testa criação em lote de áreas e subáreas, idempotência e reativação após soft-delete."""
    today = date.today()
    evt_res = await client.post(
        "/api/v1/events",
        json={
            "name": "Feira de Teste para Importação de Áreas 2026",
            "year": 2026,
            "start_date": today.isoformat(),
            "end_date": (today + timedelta(days=5)).isoformat(),
            "location": "Campus Central",
            "max_file_size_mb": 15,
            "max_projects_per_evaluator": 3
        },
        headers=admin_areas_headers
    )
    assert evt_res.status_code == 201
    event_id = evt_res.json()["id"]

    # 1. Primeira importação em lote com dados no formato tabular linha a linha (Opção 1)
    batch_payload = {
        "items": [
            {"area": "Ciências Exatas e da Terra", "subarea": "Matemática"},
            {"area": "Ciências Exatas e da Terra", "subarea": "Física"},
            {"area": "Ciências Exatas e da Terra", "subarea": "Química"},
            {"area": "Ciências Biológicas", "subarea": "Botânica"},
            {"area": "Ciências Biológicas", "subarea": "Zoologia"},
            {"area": "Ciências Humanas", "subarea": ""},
            {"area": "Multidisciplinar", "subarea": None},
        ]
    }

    res_import = await client.post(
        f"/api/v1/events/{event_id}/areas/batch",
        json=batch_payload,
        headers=admin_areas_headers
    )
    assert res_import.status_code == 200
    data = res_import.json()

    assert data["total_rows_processed"] == 7
    assert data["total_areas_processed"] == 4
    assert data["total_subareas_processed"] == 5
    assert data["created_areas_count"] == 4
    assert data["created_subareas_count"] == 5
    assert data["reused_areas_count"] == 0
    assert data["reused_subareas_count"] == 0
    assert len(data["items"]) == 4

    # Verificar estrutura das áreas retornadas
    exatas = next(a for a in data["items"] if a["name"] == "Ciências Exatas e da Terra")
    assert len(exatas["subareas"]) == 3
    sub_names = [s["name"] for s in exatas["subareas"]]
    assert "Matemática" in sub_names
    assert "Física" in sub_names
    assert "Química" in sub_names

    humanas = next(a for a in data["items"] if a["name"] == "Ciências Humanas")
    assert len(humanas["subareas"]) == 0

    # 2. Idempotência: re-executar exatamente a mesma importação não pode duplicar nem falhar
    res_repeat = await client.post(
        f"/api/v1/events/{event_id}/areas/batch",
        json=batch_payload,
        headers=admin_areas_headers
    )
    assert res_repeat.status_code == 200
    data_repeat = res_repeat.json()

    assert data_repeat["created_areas_count"] == 0
    assert data_repeat["reused_areas_count"] == 4
    assert data_repeat["created_subareas_count"] == 0
    assert data_repeat["reused_subareas_count"] == 5

    # 3. Soft-delete de uma subárea e teste de reativação pelo lote
    sub_fisica = next(s for s in exatas["subareas"] if s["name"] == "Física")
    del_res = await client.delete(f"/api/v1/subareas/{sub_fisica['id']}", headers=admin_areas_headers)
    assert del_res.status_code == 204

    # Confirmar que agora list_areas retorna apenas 2 subáreas para Exatas
    list_res = await client.get(f"/api/v1/events/{event_id}/areas", headers=admin_areas_headers)
    assert list_res.status_code == 200
    exatas_after_del = next(a for a in list_res.json() if a["name"] == "Ciências Exatas e da Terra")
    assert len(exatas_after_del["subareas"]) == 2

    # Reimportar o lote: deve reativar a subárea Física
    res_reactivate = await client.post(
        f"/api/v1/events/{event_id}/areas/batch",
        json=batch_payload,
        headers=admin_areas_headers
    )
    assert res_reactivate.status_code == 200
    data_reactivate = res_reactivate.json()

    assert data_reactivate["created_subareas_count"] == 1  # Física reativada
    assert data_reactivate["reused_subareas_count"] == 4
    exatas_reactivated = next(a for a in data_reactivate["items"] if a["name"] == "Ciências Exatas e da Terra")
    assert len(exatas_reactivated["subareas"]) == 3
