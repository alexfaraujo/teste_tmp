"""Testes para geração de modelo esqueleto e importação em lote / CSV de trabalhos científicos."""

from datetime import date, timedelta
import pytest
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.core.security import create_access_token, get_password_hash
from app.models.enums import UserRole, ProjectMemberRole, ProjectStatus
from app.models.person import Person


@pytest.fixture
async def organizer_person_proj(db_session: AsyncSession) -> Person:
    """Organizador para testes de projetos."""
    email = "organizer.projects@easyevent.test"
    stmt = select(Person).where(Person.email == email)
    res = await db_session.execute(stmt)
    p = res.scalar_one_or_none()
    if not p:
        p = Person(
            name="Coordenador Científico",
            email=email,
            role=UserRole.ADMIN,
            password_hash=get_password_hash("SenhaSegura123!"),
            barcode="BC-ORG-PROJ-01"
        )
        db_session.add(p)
        await db_session.commit()
        await db_session.refresh(p)
    return p


@pytest.fixture
def organizer_proj_headers(organizer_person_proj: Person) -> dict:
    token = create_access_token(subject=str(organizer_person_proj.id), claims={"email": organizer_person_proj.email})
    return {
        "Authorization": f"Bearer {token}",
        "X-API-Key": "fecitel_secret_api_key_2026"
    }


@pytest.mark.asyncio
async def test_projects_csv_template_and_batch_import(
    client: AsyncClient,
    organizer_proj_headers: dict
):
    """Testa download do modelo esqueleto com subáreas da feira e importação em lote via JSON."""
    today = date.today()

    # 1. Criar evento de teste
    event_resp = await client.post(
        "/api/v1/events",
        headers=organizer_proj_headers,
        json={
            "name": "Feira Científica Teste Trabalhos 2026",
            "year": 2026,
            "start_date": str(today),
            "end_date": str(today + timedelta(days=3))
        }
    )
    assert event_resp.status_code == 201
    event_id = event_resp.json()["id"]

    # 2. Criar Grande Área e Subáreas no evento
    area_resp = await client.post(
        f"/api/v1/events/{event_id}/areas",
        headers=organizer_proj_headers,
        json={"name": "Engenharias e Computação"}
    )
    assert area_resp.status_code == 201
    area_id = area_resp.json()["id"]

    sub1_resp = await client.post(
        f"/api/v1/areas/{area_id}/subareas",
        headers=organizer_proj_headers,
        json={"name": "Robótica Educacional"}
    )
    assert sub1_resp.status_code == 201

    sub2_resp = await client.post(
        f"/api/v1/areas/{area_id}/subareas",
        headers=organizer_proj_headers,
        json={"name": "Inteligência Artificial"}
    )
    assert sub2_resp.status_code == 201

    # 3. Testar download do modelo esqueleto CSV
    tmpl_resp = await client.get(
        f"/api/v1/projects/template-csv?event_id={event_id}",
        headers=organizer_proj_headers
    )
    assert tmpl_resp.status_code == 200
    assert "text/csv" in tmpl_resp.headers["content-type"]
    text_content = tmpl_resp.content.decode("utf-8-sig")
    assert "titulo;tipo;nivel;area_subarea;estande;ponto_energia;mesa_prototipo" in text_content
    assert "orientador_cpf" in text_content
    assert "orientador_instituicao" in text_content
    assert "orientador_camiseta" in text_content
    assert "autor1_cpf" in text_content
    assert "autor1_instituicao" in text_content
    assert "autor1_camiseta" in text_content
    assert "Engenharias e Computação -> Robótica Educacional" in text_content

    # 4. Testar importação em lote via JSON (batch)
    import secrets
    uid = secrets.token_hex(4)
    batch_data = {
        "auto_homologate": True,
        "items": [
            {
                "title": f"Sistema de Monitoramento com Arduino {uid}",
                "project_type": "TECHNOLOGICAL",
                "education_level": "MEDIO",
                "subarea_name": "Robótica Educacional",
                "booth_number": "E-01",
                "abstract": "Monitoramento térmico inteligente em estufas agrícolas.",
                "members": [
                    {
                        "name": "Prof. Orientador Teste",
                        "email": f"orientador.{uid}@escola.com",
                        "role": "ADVISOR",
                        "tshirt_size": "GG"
                    },
                    {
                        "name": "Estudante Autor 1",
                        "email": f"estudante1.{uid}@aluno.com",
                        "role": "STUDENT_LEADER",
                        "tshirt_size": "P"
                    },
                    {
                        "name": "Estudante Autor 2",
                        "email": f"estudante2.{uid}@aluno.com",
                        "role": "STUDENT_MEMBER",
                        "tshirt_size": "M"
                    }
                ]
            },
            {
                "title": f"Classificação de Imagens com Visão Computacional {uid}",
                "project_type": "SCIENTIFIC",
                "education_level": "MEDIO",
                "subarea_name": "Inteligência Artificial",
                "booth_number": "E-02",
                "abstract": "Reconhecimento de folhas doentes na agricultura familiar.",
                "members": [
                    {
                        "name": "Profa. Orientadora IA",
                        "email": f"orientadora.ia.{uid}@escola.com",
                        "role": "ADVISOR",
                        "tshirt_size": "G"
                    },
                    {
                        "name": "Estudante Líder IA",
                        "email": f"lider.ia.{uid}@aluno.com",
                        "role": "STUDENT_LEADER",
                        "tshirt_size": "PP"
                    }
                ]
            }
        ]
    }

    import_resp = await client.post(
        f"/api/v1/projects/batch?event_id={event_id}",
        headers=organizer_proj_headers,
        json=batch_data
    )
    assert import_resp.status_code == 200
    res_json = import_resp.json()
    assert res_json["total"] == 2
    assert res_json["created_count"] == 2
    assert res_json["updated_count"] == 0
    assert res_json["participants_created_count"] == 5  # 2 orientadores + 3 estudantes

    proj1 = next(p for p in res_json["items"] if "Arduino" in p["title"])
    assert proj1["status"] == "HOMOLOGATED"
    assert proj1["advisor_consent"] is True
    assert proj1["booth_number"] == "E-01"
    assert len(proj1["members"]) == 3
    m_advisor = next(m for m in proj1["members"] if m["role"] == "ADVISOR")
    assert m_advisor["tshirt_size"] == "GG"
    m_lead = next(m for m in proj1["members"] if m["role"] == "STUDENT_LEADER")
    assert m_lead["tshirt_size"] == "P"

    # 5. Testar Upsert: atualizar estande do Projeto 1 e adicionar Projeto 3
    update_batch = {
        "auto_homologate": True,
        "items": [
            {
                "title": f"Sistema de Monitoramento com Arduino {uid}",
                "project_type": "TECHNOLOGICAL",
                "education_level": "MEDIO",
                "subarea_name": "Robótica Educacional",
                "booth_number": "E-99",  # Estande atualizado
                "abstract": "Resumo atualizado com novos testes.",
                "members": [
                    {
                        "name": "Prof. Orientador Teste",
                        "email": f"orientador.{uid}@escola.com",
                        "role": "ADVISOR"
                    },
                    {
                        "name": "Estudante Autor 1",
                        "email": f"estudante1.{uid}@aluno.com",
                        "role": "STUDENT_LEADER"
                    }
                ]
            },
            {
                "title": f"Reciclagem de Polímeros para Filamentos 3D {uid}",
                "project_type": "TECHNOLOGICAL",
                "education_level": "MEDIO",
                "subarea_name": "Robótica Educacional",
                "booth_number": "E-03",
                "members": [
                    {
                        "name": "Prof. Orientador Teste",
                        "email": f"orientador.{uid}@escola.com",
                        "role": "ADVISOR"
                    },
                    {
                        "name": "Estudante Polímero",
                        "email": f"polimero.{uid}@aluno.com",
                        "role": "STUDENT_LEADER"
                    }
                ]
            }
        ]
    }

    update_resp = await client.post(
        f"/api/v1/projects/batch?event_id={event_id}",
        headers=organizer_proj_headers,
        json=update_batch
    )
    assert update_resp.status_code == 200
    up_json = update_resp.json()
    assert up_json["total"] == 2
    assert up_json["created_count"] == 1
    assert up_json["updated_count"] == 1

    # Verificar que o Projeto 1 agora tem estande E-99
    proj1_updated = next(p for p in up_json["items"] if "Arduino" in p["title"])
    assert proj1_updated["booth_number"] == "E-99"

    # Verificar lista geral de projetos da feira: deve conter 3 projetos
    list_resp = await client.get(
        f"/api/v1/projects?event_id={event_id}",
        headers=organizer_proj_headers
    )
    assert list_resp.status_code == 200
    all_projects = list_resp.json()
    assert len(all_projects) == 3


@pytest.mark.asyncio
async def test_projects_upload_csv_file(
    client: AsyncClient,
    organizer_proj_headers: dict
):
    """Testa upload de arquivo CSV com delimitador ';' e colunas dinâmicas de autores."""
    today = date.today()

    event_resp = await client.post(
        "/api/v1/events",
        headers=organizer_proj_headers,
        json={
            "name": "Feira Upload CSV Trabalhos 2026",
            "year": 2026,
            "start_date": str(today),
            "end_date": str(today + timedelta(days=2))
        }
    )
    assert event_resp.status_code == 201
    event_id = event_resp.json()["id"]

    # Criar Grande Área e Subárea
    area2_resp = await client.post(
        f"/api/v1/events/{event_id}/areas",
        headers=organizer_proj_headers,
        json={"name": "Ciências da Natureza"}
    )
    assert area2_resp.status_code == 201
    area2_id = area2_resp.json()["id"]

    sub_resp = await client.post(
        f"/api/v1/areas/{area2_id}/subareas",
        headers=organizer_proj_headers,
        json={"name": "Química Verde"}
    )
    assert sub_resp.status_code == 201

    csv_raw = (
        "\uFEFF"
        "titulo;tipo;nivel;subarea;estande;ponto_energia;mesa_prototipo;resumo;orientador_nome;orientador_email;orientador_camiseta;coorientador_nome;coorientador_email;coorientador_camiseta;autor1_nome;autor1_email;autor1_camiseta;autor2_nome;autor2_email;autor2_camiseta;autor3_nome;autor3_email;autor3_camiseta\r\n"
        "Biofilme Biodegradável à Base de Casca de Mandioca;Científico;Médio;Química Verde;Q-01;Sim;Não;Produção de plástico ecológico;Dr. Rogério Silva;rogerio.silva@escola.br;XG;;;;Camila Dias;camila@aluno.br;PP;Lucas Costa;lucas@aluno.br;G;Rafaela Lima;rafaela@aluno.br;M\r\n"
    )

    files = {
        "file": ("trabalhos_teste.csv", csv_raw.encode("utf-8"), "text/csv")
    }

    upload_resp = await client.post(
        f"/api/v1/projects/upload-csv?event_id={event_id}&auto_homologate=true",
        headers=organizer_proj_headers,
        files=files
    )
    assert upload_resp.status_code == 200
    res = upload_resp.json()
    assert res["total"] == 1
    assert res["created_count"] == 1
    proj = res["items"][0]
    assert proj["title"] == "Biofilme Biodegradável à Base de Casca de Mandioca"
    assert proj["booth_number"] == "Q-01"
    assert proj["status"] == "HOMOLOGATED"
    assert proj["needs_electricity"] is True
    assert proj["needs_table"] is False
    assert len(proj["members"]) == 4  # 1 orientador + 3 autores

    m_adv = next(m for m in proj["members"] if m["role"] == "ADVISOR")
    assert m_adv["tshirt_size"] == "XG"
    m_camila = next(m for m in proj["members"] if "Camila" in (m["person_name"] or ""))
    assert m_camila["tshirt_size"] == "PP"
    m_lucas = next(m for m in proj["members"] if "Lucas" in (m["person_name"] or ""))
    assert m_lucas["tshirt_size"] == "G"

    # Verificar que os cards de kit geram com sucesso com os dados importados
    kit_cards_resp = await client.get(
        f"/api/v1/events/{event_id}/kit-cards/pdf?mode=by_project",
        headers=organizer_proj_headers
    )
    assert kit_cards_resp.status_code == 200
    assert "application/pdf" in kit_cards_resp.headers["content-type"]

    # Testar atualização via PUT /projects/{project_id}
    put_resp = await client.put(
        f"/api/v1/projects/{proj['id']}",
        headers=organizer_proj_headers,
        json={
            "title": "Biofilme Biodegradável com Amido Modificado",
            "needs_electricity": False,
            "needs_table": True,
            "booth_number": "Q-02"
        }
    )
    assert put_resp.status_code == 200
    updated_proj = put_resp.json()
    assert updated_proj["title"] == "Biofilme Biodegradável com Amido Modificado"
    assert updated_proj["needs_electricity"] is False
    assert updated_proj["needs_table"] is True
    assert updated_proj["booth_number"] == "Q-02"


@pytest.mark.asyncio
async def test_projects_disambiguation_hierarchical_subareas(
    client: AsyncClient,
    organizer_proj_headers: dict
):
    """Testa que subáreas homônimas são desambiguadas via 'Área -> Subárea' e que nomes simples ambíguos são rejeitados com HTTP 400."""
    today = date.today()

    # 1. Criar evento
    event_resp = await client.post(
        "/api/v1/events",
        headers=organizer_proj_headers,
        json={
            "name": "Feira Subáreas Homônimas 2026",
            "year": 2026,
            "start_date": str(today),
            "end_date": str(today + timedelta(days=2))
        }
    )
    assert event_resp.status_code == 201
    event_id = event_resp.json()["id"]

    # 2. Criar duas Grandes Áreas distintas: "Ciências Exatas" e "Ciências Sociais Aplicadas"
    area1_resp = await client.post(
        f"/api/v1/events/{event_id}/areas",
        headers=organizer_proj_headers,
        json={"name": "Ciências Exatas"}
    )
    assert area1_resp.status_code == 201
    area1_id = area1_resp.json()["id"]

    area2_resp = await client.post(
        f"/api/v1/events/{event_id}/areas",
        headers=organizer_proj_headers,
        json={"name": "Ciências Sociais Aplicadas"}
    )
    assert area2_resp.status_code == 201
    area2_id = area2_resp.json()["id"]

    # 3. Criar a MESMA subárea ("Informática") em ambas as áreas
    sub_exatas_resp = await client.post(
        f"/api/v1/areas/{area1_id}/subareas",
        headers=organizer_proj_headers,
        json={"name": "Informática"}
    )
    assert sub_exatas_resp.status_code == 201
    sub_exatas_id = sub_exatas_resp.json()["id"]

    sub_sociais_resp = await client.post(
        f"/api/v1/areas/{area2_id}/subareas",
        headers=organizer_proj_headers,
        json={"name": "Informática"}
    )
    assert sub_sociais_resp.status_code == 201
    sub_sociais_id = sub_sociais_resp.json()["id"]

    # 4. Tentar importar trabalho informando apenas o nome simples "Informática" -> Deve falhar com 400
    ambiguous_batch = {
        "auto_homologate": True,
        "items": [
            {
                "title": "Projeto com Subárea Ambígua",
                "project_type": "SCIENTIFIC",
                "education_level": "MEDIO",
                "subarea_name": "Informática",
                "members": [
                    {"name": "Prof. Teste", "email": "teste.amb@escola.com", "role": "ADVISOR"},
                    {"name": "Aluno Teste", "email": "aluno.amb@escola.com", "role": "STUDENT_LEADER"}
                ]
            }
        ]
    }
    amb_resp = await client.post(
        f"/api/v1/projects/batch?event_id={event_id}",
        headers=organizer_proj_headers,
        json=ambiguous_batch
    )
    assert amb_resp.status_code == 400
    assert "ambígua" in amb_resp.json()["detail"].lower()
    assert "Ciências Exatas" in amb_resp.json()["detail"]
    assert "Ciências Sociais Aplicadas" in amb_resp.json()["detail"]

    # 5. Importar especificando a notação hierárquica 'Área -> Subárea' -> Deve ter sucesso e vincular ao ID correto
    exact_batch = {
        "auto_homologate": True,
        "items": [
            {
                "title": "Compilador Rust para Embarcados",
                "project_type": "TECHNOLOGICAL",
                "education_level": "MEDIO",
                "subarea_name": "Ciências Exatas -> Informática",
                "booth_number": "EX-01",
                "members": [
                    {"name": "Prof. Rust", "email": "rust.prof@escola.com", "role": "ADVISOR"},
                    {"name": "Aluno Rust", "email": "rust.aluno@escola.com", "role": "STUDENT_LEADER"}
                ]
            },
            {
                "title": "Impacto das Redes Sociais no Comércio Local",
                "project_type": "SCIENTIFIC",
                "education_level": "MEDIO",
                "subarea_name": "Ciências Sociais Aplicadas -> Informática",
                "booth_number": "SOC-01",
                "members": [
                    {"name": "Prof. Social", "email": "social.prof@escola.com", "role": "ADVISOR"},
                    {"name": "Aluno Social", "email": "social.aluno@escola.com", "role": "STUDENT_LEADER"}
                ]
            }
        ]
    }
    ok_resp = await client.post(
        f"/api/v1/projects/batch?event_id={event_id}",
        headers=organizer_proj_headers,
        json=exact_batch
    )
    assert ok_resp.status_code == 200
    res_items = ok_resp.json()["items"]
    assert len(res_items) == 2

    rust_proj = next(p for p in res_items if "Compilador" in p["title"])
    assert rust_proj["subarea_id"] == sub_exatas_id

    social_proj = next(p for p in res_items if "Impacto" in p["title"])
    assert social_proj["subarea_id"] == sub_sociais_id


@pytest.mark.asyncio
async def test_projects_upload_csv_with_cpfs(
    client: AsyncClient,
    organizer_proj_headers: dict
):
    """Testa importação de projetos via CSV contendo colunas de CPF para todos os integrantes."""
    today = date.today()

    event_resp = await client.post(
        "/api/v1/events",
        headers=organizer_proj_headers,
        json={
            "name": "Feira Projetos com CPFs 2026",
            "year": 2026,
            "start_date": str(today),
            "end_date": str(today + timedelta(days=2))
        }
    )
    assert event_resp.status_code == 201
    event_id = event_resp.json()["id"]

    # Criar Grande Área e Subárea
    area_resp = await client.post(
        f"/api/v1/events/{event_id}/areas",
        headers=organizer_proj_headers,
        json={"name": "Ciências Biológicas"}
    )
    assert area_resp.status_code == 201
    area_id = area_resp.json()["id"]

    sub_resp = await client.post(
        f"/api/v1/areas/{area_id}/subareas",
        headers=organizer_proj_headers,
        json={"name": "Microbiologia Aplicada"}
    )
    assert sub_resp.status_code == 201

    csv_raw = (
        "\uFEFF"
        "titulo;tipo;nivel;subarea;estande;ponto_energia;mesa_prototipo;resumo;orientador_nome;orientador_email;orientador_cpf;orientador_instituicao;orientador_camiseta;coorientador_nome;coorientador_email;coorientador_cpf;coorientador_instituicao;coorientador_camiseta;autor1_nome;autor1_email;autor1_cpf;autor1_instituicao;autor1_camiseta;autor2_nome;autor2_email;autor2_cpf;autor2_instituicao;autor2_camiseta\r\n"
        "Bactérias Probióticas Nativas do Cerrado;Científico;Médio;Microbiologia Aplicada;BIO-01;Sim;Sim;Isolamento e caracterização de probióticos do cerrado sul-mato-grossense;Dr. Marcos Vinicius;marcos.probiotico@escola.br;111.222.333-88;IFMS Três Lagoas;G;Dra. Luciana Mendes;luciana.probiotico@escola.br;222.333.444-99;UFMS;M;Thiago Silva;thiago.probiotico@aluno.br;333.444.555-11;IFMS Três Lagoas;M;Larissa Souza;larissa.probiotico@aluno.br;444.555.666-22;Escola Estadual;P\r\n"
    )

    files = {
        "file": ("trabalhos_com_cpf.csv", csv_raw.encode("utf-8"), "text/csv")
    }

    upload_resp = await client.post(
        f"/api/v1/projects/upload-csv?event_id={event_id}&auto_homologate=true",
        headers=organizer_proj_headers,
        files=files
    )
    assert upload_resp.status_code == 200
    res = upload_resp.json()
    assert res["total"] == 1
    assert res["created_count"] == 1
    proj = res["items"][0]
    assert proj["title"] == "Bactérias Probióticas Nativas do Cerrado"
    assert proj["booth_number"] == "BIO-01"

    # Buscar participantes do evento e conferir que os CPFs e afiliações foram gravados
    parts_resp = await client.get(
        f"/api/v1/participants?event_id={event_id}&limit=10",
        headers=organizer_proj_headers
    )
    assert parts_resp.status_code == 200
    parts_data = parts_resp.json()
    items = parts_data["items"]
    assert len(items) == 4

    p_marcos = next(p for p in items if "Marcos" in p["name"])
    assert p_marcos["cpf"] == "111.222.333-88"
    assert p_marcos["affiliation"] == "IFMS Três Lagoas"

    p_luciana = next(p for p in items if "Luciana" in p["name"])
    assert p_luciana["cpf"] == "222.333.444-99"
    assert p_luciana["affiliation"] == "UFMS"

    p_thiago = next(p for p in items if "Thiago" in p["name"])
    assert p_thiago["cpf"] == "333.444.555-11"
    assert p_thiago["affiliation"] == "IFMS Três Lagoas"

    p_larissa = next(p for p in items if "Larissa" in p["name"])
    assert p_larissa["cpf"] == "444.555.666-22"
    assert p_larissa["affiliation"] == "Escola Estadual"

