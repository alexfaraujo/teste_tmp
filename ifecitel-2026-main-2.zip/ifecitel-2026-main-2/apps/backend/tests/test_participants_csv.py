"""Testes automatizados para importação em lote de participantes (Regra BR-26 e BR-25)."""

from datetime import date, timedelta
import pytest
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.core.security import create_access_token, get_password_hash
from app.models.enums import UserRole, EducationLevelEnum
from app.models.person import Person, EventParticipant, EventParticipantRole, PersonEducationLevel, PersonSubarea
from app.models.knowledge_area import KnowledgeArea, Subarea


@pytest.fixture
async def admin_person_part_csv(db_session: AsyncSession) -> Person:
    """Administrador para testes de importação em lote de participantes."""
    email = "admin.batchpart@easyevent.test"
    stmt = select(Person).where(Person.email == email)
    res = await db_session.execute(stmt)
    p = res.scalar_one_or_none()
    if not p:
        p = Person(
            name="Gestor de Participantes Lote",
            email=email,
            role=UserRole.ADMIN,
            password_hash=get_password_hash("SenhaForte123!"),
            barcode="BC-ADMIN-PARTCSV-01"
        )
        db_session.add(p)
        await db_session.commit()
        await db_session.refresh(p)
    return p


@pytest.fixture
def admin_part_csv_headers(admin_person_part_csv: Person) -> dict:
    token = create_access_token(
        subject=str(admin_person_part_csv.id),
        claims={"email": admin_person_part_csv.email}
    )
    return {
        "Authorization": f"Bearer {token}",
        "X-API-Key": "fecitel_secret_api_key_2026"
    }


@pytest.mark.asyncio
async def test_participants_batch_import_and_idempotency(
    client: AsyncClient,
    admin_part_csv_headers: dict,
    db_session: AsyncSession
):
    """Testa importação em lote de participantes com múltiplos papéis, subáreas, níveis e idempotência."""
    today = date.today()
    evt_res = await client.post(
        "/api/v1/events",
        json={
            "name": "Feira de Teste de Importação de Participantes 2026",
            "year": 2026,
            "start_date": today.isoformat(),
            "end_date": (today + timedelta(days=5)).isoformat(),
            "location": "Campus Central",
            "workload_hours": 40,
            "max_projects": 100,
        },
        headers=admin_part_csv_headers,
    )
    assert evt_res.status_code == 201
    event_id = evt_res.json()["id"]

    # 1. Cadastrar Áreas e Subáreas para a feira
    area_res = await client.post(
        f"/api/v1/events/{event_id}/areas/batch",
        json={
            "items": [
                {"area": "Ciências Exatas e da Terra", "subarea": "Informática"},
                {"area": "Ciências Exatas e da Terra", "subarea": "Robótica e Automação"},
            ]
        },
        headers=admin_part_csv_headers,
    )
    assert area_res.status_code == 200

    # 2. Executar primeira importação em lote
    batch_payload = {
        "items": [
            {
                "name": "Mariana Santos",
                "email": "mariana.santos.batch@estudante.edu.br",
                "roles": ["STUDENT"],
                "cpf": "123.456.789-01",
                "affiliation": "IFMS Campus Três Lagoas",
                "tshirt_size": "P",
                "subareas": [],
                "education_levels": []
            },
            {
                "name": "Prof. Carlos Lima",
                "email": "carlos.lima.batch@escola.edu.br",
                "roles": ["ADVISOR"],
                "cpf": "234.567.890-12",
                "affiliation": "Escola Estadual Santos Dumont",
                "tshirt_size": "G",
                "subareas": [],
                "education_levels": []
            },
            {
                "name": "Profa. Ana Paula Mendes",
                "email": "ana.mendes.batch@escola.edu.br",
                "roles": ["ADVISOR", "EVALUATOR"],
                "cpf": "345.678.901-23",
                "affiliation": "IFMS Campus Três Lagoas",
                "tshirt_size": "M",
                "subareas": ["Informática", "Robótica e Automação"],
                "education_levels": ["MEDIO", "FUNDAMENTAL"]
            },
            {
                "name": "Dr. Roberto Souza",
                "email": "roberto.souza.batch@universidade.br",
                "roles": ["EVALUATOR"],
                "cpf": "456.789.012-34",
                "affiliation": "UFMS",
                "tshirt_size": "GG",
                "subareas": ["Informática"],
                "education_levels": []  # Universal
            }
        ]
    }

    import_res = await client.post(
        f"/api/v1/participants/batch?event_id={event_id}",
        json=batch_payload,
        headers=admin_part_csv_headers,
    )
    assert import_res.status_code == 200
    data = import_res.json()
    assert data["total_processed"] == 4
    assert data["created_count"] == 4
    assert data["updated_count"] == 0
    assert data["evaluators_count"] == 2
    assert len(data["items"]) == 4

    # Verificar Profa. Ana Paula Mendes (Orientador + Avaliador, 2 subáreas, 2 níveis)
    ana_item = next(i for i in data["items"] if i["email"] == "ana.mendes.batch@escola.edu.br")
    assert "ADVISOR" in ana_item["roles"]
    assert "EVALUATOR" in ana_item["roles"]
    assert set(ana_item["education_levels"]) == {"MEDIO", "FUNDAMENTAL"}
    assert ana_item["tshirt_size"] == "M"

    # Verificar listagem de participantes paginada
    list_res = await client.get(
        f"/api/v1/participants?event_id={event_id}&limit=15",
        headers=admin_part_csv_headers,
    )
    assert list_res.status_code == 200
    list_data = list_res.json()
    assert list_data["total"] == 4

    # 3. Testar Idempotência: reimportação do mesmo lote não duplica e marca como updated
    reimport_res = await client.post(
        f"/api/v1/participants/batch?event_id={event_id}",
        json=batch_payload,
        headers=admin_part_csv_headers,
    )
    assert reimport_res.status_code == 200
    reimport_data = reimport_res.json()
    assert reimport_data["total_processed"] == 4
    assert reimport_data["created_count"] == 0
    assert reimport_data["updated_count"] == 4

    # 4. Testar Soft-delete e Reativação
    person_id_to_delete = ana_item["person_id"]
    del_res = await client.delete(
        f"/api/v1/participants/{person_id_to_delete}?event_id={event_id}",
        headers=admin_part_csv_headers,
    )
    assert del_res.status_code == 200

    # Confirmar que total caiu para 3 na listagem ativa
    list_after_del = await client.get(
        f"/api/v1/participants?event_id={event_id}&limit=15",
        headers=admin_part_csv_headers,
    )
    assert list_after_del.json()["total"] == 3

    # Reimportar lote reativa a participante
    reactivate_res = await client.post(
        f"/api/v1/participants/batch?event_id={event_id}",
        json=batch_payload,
        headers=admin_part_csv_headers,
    )
    assert reactivate_res.status_code == 200
    reactivate_data = reactivate_res.json()
    assert reactivate_data["total_processed"] == 4

    # Confirmar que voltou para 4 na listagem ativa
    list_after_reactivate = await client.get(
        f"/api/v1/participants?event_id={event_id}&limit=15",
        headers=admin_part_csv_headers,
    )
    assert list_after_reactivate.json()["total"] == 4


@pytest.mark.asyncio
async def test_participants_batch_import_hierarchical_subareas_and_disambiguation(
    client: AsyncClient,
    admin_part_csv_headers: dict,
    db_session: AsyncSession
):
    """Testa resolução composta Área -> Subárea e bloqueio preventivo de ambiguidade."""
    today = date.today()
    evt_res = await client.post(
        "/api/v1/events",
        json={
            "name": "Feira Teste Desambiguação 2026",
            "year": 2026,
            "start_date": today.isoformat(),
            "end_date": (today + timedelta(days=3)).isoformat(),
            "location": "Campus Tecnológico",
            "workload_hours": 30,
            "max_projects": 50,
        },
        headers=admin_part_csv_headers,
    )
    assert evt_res.status_code == 201
    event_id = evt_res.json()["id"]

    # 1. Cadastrar duas grandes áreas com uma subárea homônima ("Informática")
    area_res = await client.post(
        f"/api/v1/events/{event_id}/areas/batch",
        json={
            "items": [
                {"area": "Ciências Exatas e da Terra", "subarea": "Informática"},
                {"area": "Ciências Sociais Aplicadas", "subarea": "Informática"},
                {"area": "Engenharias", "subarea": "Robótica e Automação"},
            ]
        },
        headers=admin_part_csv_headers,
    )
    assert area_res.status_code == 200

    # 2. Tentar importar avaliador usando apenas o nome simples ambíguo "Informática"
    ambiguous_payload = {
        "items": [
            {
                "name": "Dr. Avaliador Ambíguo",
                "email": "avaliador.ambiguo@universidade.br",
                "roles": ["EVALUATOR"],
                "subareas": ["Informática"],
                "education_levels": []
            }
        ]
    }
    fail_res = await client.post(
        f"/api/v1/participants/batch?event_id={event_id}",
        json=ambiguous_payload,
        headers=admin_part_csv_headers,
    )
    assert fail_res.status_code == 400
    fail_detail = fail_res.json()["detail"]
    assert "ambígua" in fail_detail.lower()
    assert "Ciências Exatas e da Terra" in fail_detail
    assert "Ciências Sociais Aplicadas" in fail_detail

    # 3. Importar com notação hierárquica usando '->' e '>'
    valid_payload = {
        "items": [
            {
                "name": "Dr. Avaliador Exatas",
                "email": "avaliador.exatas@universidade.br",
                "roles": ["EVALUATOR"],
                "subareas": ["Ciências Exatas e da Terra -> Informática", "Engenharias > Robótica e Automação"],
                "education_levels": ["MEDIO"]
            },
            {
                "name": "Dra. Avaliadora Sociais",
                "email": "avaliadora.sociais@universidade.br",
                "roles": ["EVALUATOR"],
                "subareas": ["Ciências Sociais Aplicadas: Informática"],
                "education_levels": ["GRADUACAO"]
            }
        ]
    }
    success_res = await client.post(
        f"/api/v1/participants/batch?event_id={event_id}",
        json=valid_payload,
        headers=admin_part_csv_headers,
    )
    assert success_res.status_code == 200
    success_data = success_res.json()
    assert success_data["created_count"] == 2
    assert success_data["evaluators_count"] == 2

    # 4. Validar se os IDs das subáreas foram vinculados com precisão
    # Buscar detalhes de Dr. Avaliador Exatas
    p1_res = await client.get(
        f"/api/v1/participants/{success_data['items'][0]['person_id']}?event_id={event_id}",
        headers=admin_part_csv_headers,
    )
    assert p1_res.status_code == 200
    p1_subareas = p1_res.json()["subareas"]
    assert len(p1_subareas) == 2
    p1_areas = {s["area_name"] for s in p1_subareas}
    assert "Ciências Exatas e da Terra" in p1_areas
    assert "Engenharias" in p1_areas

    # Buscar detalhes de Dra. Avaliadora Sociais
    p2_res = await client.get(
        f"/api/v1/participants/{success_data['items'][1]['person_id']}?event_id={event_id}",
        headers=admin_part_csv_headers,
    )
    assert p2_res.status_code == 200
    p2_subareas = p2_res.json()["subareas"]
    assert len(p2_subareas) == 1
    assert p2_subareas[0]["area_name"] == "Ciências Sociais Aplicadas"
    assert p2_subareas[0]["subarea_name"] == "Informática"
