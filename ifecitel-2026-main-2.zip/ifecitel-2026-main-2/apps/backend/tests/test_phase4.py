"""Automated tests for Phase 4: Evaluator Balanced Allocation (BR-10), Mobile-First QR Evaluation (BR-11, BR-12) and Universal API Key Protection (SEC-03)."""

from datetime import date, datetime, timedelta, timezone
import uuid
import pytest
from httpx import AsyncClient
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.security import create_access_token
from app.models.enums import AllocationStatus, AllocationType, EvaluationStatus, ProjectMemberRole, ProjectStatus, ProjectType, UserRole
from app.models.event import Event
from app.models.evaluation import EvaluationCriterion, EvaluatorAllocation
from app.models.knowledge_area import KnowledgeArea, Subarea
from app.models.person import EventParticipant, Person, PersonSubarea
from app.models.project import Project, ProjectMember


@pytest.fixture
def admin_headers(seed_admin: Person) -> dict:
    """Gera cabeçalho Bearer e API Key para o Administrador."""
    token = create_access_token(
        subject=str(seed_admin.id),
        claims={"role": "ADMIN", "email": seed_admin.email}
    )
    return {"Authorization": f"Bearer {token}", "X-API-Key": settings.API_KEY}


@pytest.fixture
def evaluator_headers(seed_evaluator: Person) -> dict:
    """Gera cabeçalho Bearer e API Key para o Avaliador."""
    token = create_access_token(
        subject=str(seed_evaluator.id),
        claims={"role": "EVALUATOR", "email": seed_evaluator.email}
    )
    return {"Authorization": f"Bearer {token}", "X-API-Key": settings.API_KEY}


@pytest.fixture
async def phase4_setup(db_session: AsyncSession, seed_admin: Person):
    """Cria um ambiente completo para a Fase 4 no banco real bare-metal."""
    suffix = uuid.uuid4().hex[:6]
    today = date.today()

    # 1. Evento
    event = Event(
        name=f"FECITEL Fase 4 Test {suffix}",
        year=2026,
        start_date=today,
        end_date=today + timedelta(days=3),
        max_projects_per_evaluator=3
    )
    db_session.add(event)
    await db_session.flush()

    # 2. Critérios de Avaliação Dinâmicos
    crit1 = EvaluationCriterion(
        event_id=event.id,
        name="Metodologia Científica e Rigor",
        scientific_description="Avalia o rigor do método hipotético-dedutivo e reprodutibilidade.",
        technological_description="Avalia a arquitetura, robustez e ciclo de vida do protótipo.",
        max_score=10.0,
        weight=1.0
    )
    crit2 = EvaluationCriterion(
        event_id=event.id,
        name="Inovação e Relevância Social",
        scientific_description="Impacto da descoberta para a fronteira do conhecimento.",
        technological_description="Inovação tecnológica e viabilidade de mercado ou aplicação social.",
        max_score=10.0,
        weight=1.0
    )
    db_session.add_all([crit1, crit2])
    await db_session.flush()

    # 3. Área e Subáreas de Conhecimento
    area = KnowledgeArea(event_id=event.id, name=f"Ciências Exatas {suffix}")
    db_session.add(area)
    await db_session.flush()

    subarea_a = Subarea(area_id=area.id, name=f"Computação {suffix}")
    subarea_b = Subarea(area_id=area.id, name=f"Engenharia {suffix}")
    db_session.add_all([subarea_a, subarea_b])
    await db_session.flush()

    # 4. Avaliadores
    evaluator1 = Person(
        name=f"Avaliador Alpha {suffix}",
        email=f"alpha.{suffix}@fecitel.ifms.edu.br",
        role=UserRole.EVALUATOR,
        barcode=f"BC-EVAL-A-{suffix}"
    )
    evaluator2 = Person(
        name=f"Avaliador Beta {suffix}",
        email=f"beta.{suffix}@fecitel.ifms.edu.br",
        role=UserRole.EVALUATOR,
        barcode=f"BC-EVAL-B-{suffix}"
    )
    evaluator3 = Person(
        name=f"Avaliador Gamma {suffix}",
        email=f"gamma.{suffix}@fecitel.ifms.edu.br",
        role=UserRole.EVALUATOR,
        barcode=f"BC-EVAL-G-{suffix}"
    )
    # Orientador (que também poderia ser avaliador mas gera conflito em seu próprio trabalho)
    advisor = Person(
        name=f"Orientador Dr {suffix}",
        email=f"advisor.{suffix}@fecitel.ifms.edu.br",
        role=UserRole.ADVISOR,
        barcode=f"BC-ADV-{suffix}"
    )
    student = Person(
        name=f"Estudante Autor {suffix}",
        email=f"student.{suffix}@fecitel.ifms.edu.br",
        role=UserRole.STUDENT,
        barcode=f"BC-STU-{suffix}"
    )
    db_session.add_all([evaluator1, evaluator2, evaluator3, advisor, student])
    await db_session.flush()

    # Qualificações de subárea para avaliadores
    ps1 = PersonSubarea(event_id=event.id, person_id=evaluator1.id, subarea_id=subarea_a.id)
    ps2 = PersonSubarea(event_id=event.id, person_id=evaluator2.id, subarea_id=subarea_a.id)
    ps3 = PersonSubarea(event_id=event.id, person_id=evaluator3.id, subarea_id=subarea_b.id)
    db_session.add_all([ps1, ps2, ps3])
    await db_session.flush()

    # 5. Projetos com Presença Confirmada (PRESENT)
    # Projeto 1 (Computação) - orientado por advisor
    proj1 = Project(
        event_id=event.id,
        subarea_id=subarea_a.id,
        title=f"Visão Computacional na Agricultura {suffix}",
        project_type=ProjectType.TECHNOLOGICAL,
        abstract="Sistema embarcado para contagem de pragas em lavouras de soja.",
        booth_number="A-01",
        qrcode_token=f"QR-BOOTH-A01-{suffix}",
        status=ProjectStatus.PRESENT,
        advisor_consent=True
    )
    db_session.add(proj1)
    await db_session.flush()

    m1_adv = ProjectMember(project_id=proj1.id, person_id=advisor.id, role=ProjectMemberRole.ADVISOR)
    m1_stu = ProjectMember(project_id=proj1.id, person_id=student.id, role=ProjectMemberRole.STUDENT_LEADER)
    db_session.add_all([m1_adv, m1_stu])

    # Projeto 2 (Computação)
    proj2 = Project(
        event_id=event.id,
        subarea_id=subarea_a.id,
        title=f"Criptografia Pós-Quântica {suffix}",
        project_type=ProjectType.SCIENTIFIC,
        abstract="Estudo comparativo de algoritmos baseados em reticulados.",
        booth_number="A-02",
        qrcode_token=f"QR-BOOTH-A02-{suffix}",
        status=ProjectStatus.PRESENT,
        advisor_consent=True
    )
    db_session.add(proj2)
    await db_session.flush()

    # Projeto 3 (Computação)
    proj3 = Project(
        event_id=event.id,
        subarea_id=subarea_a.id,
        title=f"Compiladores Otimizadores {suffix}",
        project_type=ProjectType.SCIENTIFIC,
        abstract="Otimizações baseadas em grafos de fluxo de controle.",
        booth_number="A-03",
        qrcode_token=f"QR-BOOTH-A03-{suffix}",
        status=ProjectStatus.PRESENT,
        advisor_consent=True
    )
    db_session.add(proj3)
    await db_session.flush()

    await db_session.commit()

    return {
        "event": event,
        "crit1": crit1,
        "crit2": crit2,
        "subarea_a": subarea_a,
        "subarea_b": subarea_b,
        "evaluator1": evaluator1,
        "evaluator2": evaluator2,
        "evaluator3": evaluator3,
        "advisor": advisor,
        "student": student,
        "proj1": proj1,
        "proj2": proj2,
        "proj3": proj3
    }


@pytest.mark.asyncio
async def test_qualify_evaluator_subareas(client: AsyncClient, admin_headers: dict, phase4_setup: dict):
    """Testa qualificação de avaliador em subáreas temáticas pelo Administrador (BR-10)."""
    data = phase4_setup
    eval1 = data["evaluator1"]
    event = data["event"]
    sub_a = data["subarea_a"]
    sub_b = data["subarea_b"]

    payload = {
        "person_id": eval1.id,
        "event_id": event.id,
        "subarea_ids": [sub_a.id, sub_b.id]
    }
    resp = await client.post("/api/v1/allocations/qualify", json=payload, headers=admin_headers)
    assert resp.status_code == 200, resp.text
    res_data = resp.json()
    assert res_data["person_id"] == eval1.id
    assert set(res_data["subarea_ids"]) == {sub_a.id, sub_b.id}


@pytest.mark.asyncio
async def test_auto_balance_allocation_golden_rule_delta_le_1(
    client: AsyncClient,
    admin_headers: dict,
    phase4_setup: dict,
    db_session: AsyncSession
):
    """
    Testa o Algoritmo de Alocação Balanceada de Avaliadores (BR-10 Momento 1).
    Garante:
    - Vinculação de subáreas compatíveis
    - Teto de trabalhos por avaliador respeitado
    - Conflito de interesse respeitado (orientador nunca avalia seu projeto)
    - Regra de Ouro: delta <= 1 entre quaisquer dois projetos da mesma subárea.
    """
    data = phase4_setup
    event = data["event"]
    eval1 = data["evaluator1"]
    eval2 = data["evaluator2"]
    eval3 = data["evaluator3"]
    advisor = data["advisor"]
    sub_a = data["subarea_a"]

    # 1. Qualificar avaliadores na subárea A
    for ev in [eval1, eval2, eval3]:
        resp_q = await client.post(
            "/api/v1/allocations/qualify",
            json={"person_id": ev.id, "event_id": event.id, "subarea_ids": [sub_a.id]},
            headers=admin_headers
        )
        assert resp_q.status_code == 200

    # 2. Qualificar o orientador também na subárea A (para testar se o algoritmo evita alocá-lo ao seu proj1)
    resp_q_adv = await client.post(
        "/api/v1/allocations/qualify",
        json={"person_id": advisor.id, "event_id": event.id, "subarea_ids": [sub_a.id]},
        headers=admin_headers
    )
    assert resp_q_adv.status_code == 200

    # 2.1 Confirmar presença dos avaliadores na Sala dos Avaliadores (BR-10)
    for ev in [eval1, eval2, eval3, advisor]:
        ep = EventParticipant(
            event_id=event.id,
            person_id=ev.id,
            presence_confirmed=True,
            evaluator_presence_confirmed=True
        )
        db_session.add(ep)
    await db_session.commit()

    # 3. Disparar algoritmo de auto-balanceamento pós-checkin
    resp_ab = await client.post(
        "/api/v1/allocations/auto-balance",
        json={"event_id": event.id},
        headers=admin_headers
    )
    assert resp_ab.status_code == 200, resp_ab.text
    summary = resp_ab.json()
    assert summary["golden_rule_satisfied"] is True
    assert summary["total_allocations_created"] > 0

    # 4. Inspecionar alocações geradas no evento
    resp_list = await client.get(f"/api/v1/allocations?event_id={event.id}", headers=admin_headers)
    assert resp_list.status_code == 200
    allocations = resp_list.json()

    # Contagem de avaliadores por projeto
    counts_by_project = {}
    for a in allocations:
        p_id = a["project_id"]
        counts_by_project[p_id] = counts_by_project.get(p_id, 0) + 1
        # Conflito de interesse: o orientador NUNCA pode ter sido alocado ao proj1
        if p_id == data["proj1"].id:
            assert a["evaluator_id"] != advisor.id, "Conflito de interesse violado: orientador alocado para próprio projeto!"

    # Checar se a Regra de Ouro delta <= 1 foi respeitada entre todos os projetos da subárea
    counts = list(counts_by_project.values())
    assert max(counts) - min(counts) <= 1, f"Regra de ouro violada! Contagens: {counts_by_project}"


@pytest.mark.asyncio
async def test_manual_allocation_and_conflict_of_interest(
    client: AsyncClient,
    admin_headers: dict,
    phase4_setup: dict
):
    """Testa alocação manual e bloqueio rígido de conflito de interesses (BR-10 Momento 2)."""
    data = phase4_setup
    event = data["event"]
    proj1 = data["proj1"]
    advisor = data["advisor"]
    eval1 = data["evaluator1"]

    # 1. Tentativa de alocar o orientador ao seu próprio projeto deve retornar 400
    resp_conflict = await client.post(
        "/api/v1/allocations/manual",
        json={"event_id": event.id, "project_id": proj1.id, "evaluator_id": advisor.id},
        headers=admin_headers
    )
    assert resp_conflict.status_code == 400
    assert "Conflito de interesses" in resp_conflict.json()["detail"]

    # 2. Alocação manual válida do avaliador 1 ao projeto 1
    resp_valid = await client.post(
        "/api/v1/allocations/manual",
        json={"event_id": event.id, "project_id": proj1.id, "evaluator_id": eval1.id},
        headers=admin_headers
    )
    assert resp_valid.status_code == 201
    alloc_data = resp_valid.json()
    assert alloc_data["project_id"] == proj1.id
    assert alloc_data["evaluator_id"] == eval1.id
    assert alloc_data["allocation_type"] == AllocationType.MANUAL_ADMIN.value

    # 3. Tentativa de alocação duplicada deve retornar 400
    resp_dup = await client.post(
        "/api/v1/allocations/manual",
        json={"event_id": event.id, "project_id": proj1.id, "evaluator_id": eval1.id},
        headers=admin_headers
    )
    assert resp_dup.status_code == 400

    # 4. Cancelamento da alocação
    alloc_id = alloc_data["id"]
    resp_cancel = await client.delete(f"/api/v1/allocations/{alloc_id}", headers=admin_headers)
    assert resp_cancel.status_code == 200
    assert resp_cancel.json()["status"] == AllocationStatus.CANCELLED.value

    # 4.1. Tentativa de re-cancelar a mesma alocação já cancelada deve retornar 400
    resp_recancel = await client.delete(f"/api/v1/allocations/{alloc_id}", headers=admin_headers)
    assert resp_recancel.status_code == 400
    assert "já se encontra cancelada" in resp_recancel.json()["detail"]

    # 4.2. Testar filtro por status no endpoint de listagem
    resp_cancelled_list = await client.get(
        f"/api/v1/allocations?event_id={event.id}&status=CANCELLED",
        headers=admin_headers
    )
    assert resp_cancelled_list.status_code == 200
    cancelled_ids = [a["id"] for a in resp_cancelled_list.json()]
    assert alloc_id in cancelled_ids

    # 4.3. Reativar alocação previamente cancelada via alocação manual
    resp_reactivate = await client.post(
        "/api/v1/allocations/manual",
        json={"event_id": event.id, "project_id": proj1.id, "evaluator_id": eval1.id},
        headers=admin_headers
    )
    assert resp_reactivate.status_code == 201
    assert resp_reactivate.json()["id"] == alloc_id
    assert resp_reactivate.json()["status"] == AllocationStatus.PENDING.value

    # Cancelar novamente para testar rebalanceamento com alocação cancelada
    await client.delete(f"/api/v1/allocations/{alloc_id}", headers=admin_headers)

    # 4.4. Auto-balance não deve falhar com chave duplicada quando existem alocações canceladas
    resp_autobal = await client.post(
        "/api/v1/allocations/auto-balance",
        json={"event_id": event.id},
        headers=admin_headers
    )
    assert resp_autobal.status_code == 200

    # 5. Tentativa de alocação de avaliador de subárea divergente (eval3 é Engenharia, proj1 é Computação)
    eval3 = data["evaluator3"]
    resp_subarea_mismatch = await client.post(
        "/api/v1/allocations/manual",
        json={"event_id": event.id, "project_id": proj1.id, "evaluator_id": eval3.id},
        headers=admin_headers
    )
    assert resp_subarea_mismatch.status_code == 400
    assert "Incompatibilidade de especialidade" in resp_subarea_mismatch.json()["detail"]

    # 6. Testar endpoint GET /api/v1/allocations/evaluators
    resp_evals_list = await client.get(
        f"/api/v1/allocations/evaluators?event_id={event.id}",
        headers=admin_headers
    )
    assert resp_evals_list.status_code == 200
    evals_list = resp_evals_list.json()
    assert len(evals_list) >= 3
    eval1_item = next((e for e in evals_list if e["id"] == eval1.id), None)
    assert eval1_item is not None
    assert len(eval1_item["subareas"]) > 0
    assert "area_name" in eval1_item["subareas"][0]


@pytest.mark.asyncio
async def test_get_evaluation_sheet_via_qrcode_mobile(
    client: AsyncClient,
    admin_headers: dict,
    phase4_setup: dict
):
    """Testa a leitura da ficha mobile-first via token de QR Code de bancada (BR-08, BR-11)."""
    data = phase4_setup
    event = data["event"]
    proj1 = data["proj1"]
    eval1 = data["evaluator1"]

    # Alocar eval1 para proj1
    await client.post(
        "/api/v1/allocations/manual",
        json={"event_id": event.id, "project_id": proj1.id, "evaluator_id": eval1.id},
        headers=admin_headers
    )

    eval1_token = create_access_token(
        subject=str(eval1.id),
        claims={"role": "EVALUATOR", "email": eval1.email}
    )
    eval1_headers = {"Authorization": f"Bearer {eval1_token}", "X-API-Key": settings.API_KEY}

    # Leitura da ficha pelo QR Code
    resp_sheet = await client.get(
        f"/api/v1/evaluations/sheet?qrcode={proj1.qrcode_token}",
        headers=eval1_headers
    )
    assert resp_sheet.status_code == 200, resp_sheet.text
    sheet = resp_sheet.json()
    assert sheet["project_id"] == proj1.id
    assert sheet["title"] == proj1.title
    assert sheet["project_type"] == ProjectType.TECHNOLOGICAL.value
    assert len(sheet["criteria"]) == 2
    # Critério deve ter descrição tecnológica (já que o projeto é TECHNOLOGICAL)
    assert "arquitetura" in sheet["criteria"][0]["description"].lower()


@pytest.mark.asyncio
async def test_submit_evaluation_and_simple_arithmetic_mean_br12(
    client: AsyncClient,
    admin_headers: dict,
    phase4_setup: dict
):
    """
    Testa:
    - Submissão de avaliação presencial Mobile-First com parecer geral consolidado único (BR-11)
    - Transição da máquina de estados: PRESENT -> UNDER_EVALUATION -> EVALUATED
    - Cálculo da nota final por média aritmética simples sem descarte de notas extremas (BR-12).
    """
    data = phase4_setup
    event = data["event"]
    proj = data["proj2"]
    crit1 = data["crit1"]
    crit2 = data["crit2"]
    eval1 = data["evaluator1"]
    eval2 = data["evaluator2"]

    # 1. Alocar dois avaliadores ao projeto
    await client.post(
        "/api/v1/allocations/manual",
        json={"event_id": event.id, "project_id": proj.id, "evaluator_id": eval1.id},
        headers=admin_headers
    )
    await client.post(
        "/api/v1/allocations/manual",
        json={"event_id": event.id, "project_id": proj.id, "evaluator_id": eval2.id},
        headers=admin_headers
    )

    token_e1 = create_access_token(subject=str(eval1.id), claims={"role": "EVALUATOR", "email": eval1.email})
    headers_e1 = {"Authorization": f"Bearer {token_e1}", "X-API-Key": settings.API_KEY}

    token_e2 = create_access_token(subject=str(eval2.id), claims={"role": "EVALUATOR", "email": eval2.email})
    headers_e2 = {"Authorization": f"Bearer {token_e2}", "X-API-Key": settings.API_KEY}

    # 2. Avaliador 1 submete avaliação: notas 8.0 e 10.0 (média do eval1 = 9.0)
    eval1_payload = {
        "project_id": proj.id,
        "general_feedback": "Excelente fundamentação teórica e clareza na apresentação dos resultados pelo time.",
        "status": "COMPLETED",
        "items": [
            {"criterion_id": crit1.id, "score": 8.0},
            {"criterion_id": crit2.id, "score": 10.0}
        ]
    }
    resp_e1 = await client.post("/api/v1/evaluations", json=eval1_payload, headers=headers_e1)
    assert resp_e1.status_code == 201, resp_e1.text
    e1_data = resp_e1.json()
    assert e1_data["final_score"] == 9.0

    # Verificar se o projeto transicionou para UNDER_EVALUATION
    resp_proj_check = await client.get(f"/api/v1/projects/{proj.id}", headers=admin_headers)
    assert resp_proj_check.json()["status"] == ProjectStatus.UNDER_EVALUATION.value

    # 3. Avaliador 2 submete avaliação sem observação (campo opcional): notas 7.0 e 7.0 (média do eval2 = 7.0)
    eval2_payload = {
        "project_id": proj.id,
        "status": "COMPLETED",
        "items": [
            {"criterion_id": crit1.id, "score": 7.0},
            {"criterion_id": crit2.id, "score": 7.0}
        ]
    }
    resp_e2 = await client.post("/api/v1/evaluations", json=eval2_payload, headers=headers_e2)
    assert resp_e2.status_code == 201, resp_e2.text
    e2_data = resp_e2.json()
    assert e2_data["final_score"] == 7.0
    assert e2_data["general_feedback"] is None

    # Todas as alocações do projeto foram concluídas -> projeto deve ser EVALUATED
    resp_proj_check2 = await client.get(f"/api/v1/projects/{proj.id}", headers=admin_headers)
    assert resp_proj_check2.json()["status"] == ProjectStatus.EVALUATED.value

    # 4. Verificar resumo e cálculo da nota final oficial por Média Aritmética Simples (BR-12)
    # (9.0 + 7.0) / 2 = 8.0
    resp_summary = await client.get(f"/api/v1/evaluations/project/{proj.id}/summary", headers=admin_headers)
    assert resp_summary.status_code == 200, resp_summary.text
    summary_data = resp_summary.json()
    assert summary_data["evaluations_count"] == 2
    assert len(summary_data["feedbacks"]) == 1
    assert summary_data["feedbacks"][0] == eval1_payload["general_feedback"]

    # 4.1. Verificar carregamento direto da ficha pelo ID do projeto (Subfase 5.1 - Modo Consulta / Readonly)
    resp_my_sheet = await client.get(f"/api/v1/evaluations/project/{proj.id}/my-sheet", headers=headers_e1)
    assert resp_my_sheet.status_code == 200, resp_my_sheet.text
    sheet_data = resp_my_sheet.json()
    assert sheet_data["project_id"] == proj.id
    assert sheet_data["current_feedback"] == eval1_payload["general_feedback"]
    assert any(c["current_score"] == 8.0 for c in sheet_data["criteria"])

    # Avaliador não alocado recebe 403
    eval3 = data["evaluator3"]
    token_e3 = create_access_token(subject=str(eval3.id), claims={"role": "EVALUATOR", "email": eval3.email})
    resp_fail = await client.get(
        f"/api/v1/evaluations/project/{proj.id}/my-sheet",
        headers={"Authorization": f"Bearer {token_e3}", "X-API-Key": settings.API_KEY}
    )
    assert resp_fail.status_code == 403

    # 5. Tentativa de cancelar alocação após avaliação realizada DEVE ser estritamente bloqueada (HTTP 400)
    allocs_list = (await client.get(f"/api/v1/allocations?event_id={event.id}&project_id={proj.id}", headers=admin_headers)).json()
    assert len(allocs_list) == 2
    for al in allocs_list:
        resp_cancel_fail = await client.delete(f"/api/v1/allocations/{al['id']}", headers=admin_headers)
        assert resp_cancel_fail.status_code == 400
        assert "não é possível cancelar" in resp_cancel_fail.json()["detail"].lower()


@pytest.mark.asyncio
async def test_sec03_universal_api_key_protection_phase4(
    unauthenticated_client: AsyncClient,
    phase4_setup: dict
):
    """Verifica que todas as rotas da Fase 4 (GET e POST) rejeitam requisições sem API Key (Regra SEC-03)."""
    # 1. Rota GET sem chave deve retornar 401
    resp_get = await unauthenticated_client.get("/api/v1/evaluations/sheet?qrcode=FAKE")
    assert resp_get.status_code == 401
    assert "API Key" in resp_get.json()["detail"]

    # 2. Rota POST sem chave deve retornar 401
    resp_post = await unauthenticated_client.post("/api/v1/allocations/auto-balance", json={"event_id": 1})
    assert resp_post.status_code == 401
    assert "API Key" in resp_post.json()["detail"]
