"""Testes automatizados para a geração de Adesivos de Bancada com QR Code em PDF."""

from datetime import date, timedelta
from typing import List, Tuple
import pytest
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.core.security import create_access_token, get_password_hash
from app.models.enums import EducationLevelEnum, ProjectMemberRole, ProjectStatus, ProjectType, UserRole
from app.models.event import Event, EventAdministrator, EventAdminRole
from app.models.knowledge_area import KnowledgeArea, Subarea
from app.models.person import Person
from app.models.project import Project, ProjectMember
from app.services.booth_sticker_service import generate_event_booth_stickers_pdf


@pytest.fixture
async def admin_sticker_user(db_session: AsyncSession) -> Person:
    """Administrador para testes de adesivos de bancada."""
    email = "admin.stickers@easyevent.test"
    stmt = select(Person).where(Person.email == email)
    res = await db_session.execute(stmt)
    p = res.scalar_one_or_none()
    if not p:
        p = Person(
            name="Gestor de Adesivos",
            email=email,
            role=UserRole.ADMIN,
            password_hash=get_password_hash("SenhaForte123!"),
            barcode="BC-ADMIN-STICKERS-01",
        )
        db_session.add(p)
        await db_session.commit()
        await db_session.refresh(p)
    return p


@pytest.fixture
def admin_sticker_headers(admin_sticker_user: Person) -> dict:
    token = create_access_token(
        subject=str(admin_sticker_user.id),
        claims={"email": admin_sticker_user.email},
    )
    return {
        "Authorization": f"Bearer {token}",
        "X-API-Key": "fecitel_secret_api_key_2026",
    }


@pytest.fixture
async def event_with_booth_stickers(db_session: AsyncSession, admin_sticker_user: Person) -> Tuple[Event, List[Project]]:
    """Cria um evento com projetos para teste dos adesivos de bancada."""
    import uuid
    uid = uuid.uuid4().hex[:6]
    today = date.today()
    evt = Event(
        name=f"Feira Científica Teste Adesivos {uid}",
        year=2026,
        start_date=today,
        end_date=today + timedelta(days=3),
        location="Pavilhão de Testes",
        organizing_institution="Instituto de Testes",
        owner_id=admin_sticker_user.id,
    )
    db_session.add(evt)
    await db_session.flush()

    # Vínculo administrativo
    admin_rel = EventAdministrator(
        event_id=evt.id,
        person_id=admin_sticker_user.id,
        role=EventAdminRole.ORGANIZER,
    )
    db_session.add(admin_rel)

    # Criar 2 Grandes Áreas e Subáreas
    area1 = KnowledgeArea(event_id=evt.id, name=f"Ciências Exatas {uid}")
    area2 = KnowledgeArea(event_id=evt.id, name=f"Ciências Biológicas {uid}")
    db_session.add_all([area1, area2])
    await db_session.flush()

    sub1 = Subarea(area_id=area1.id, name=f"Física Experimental {uid}")
    sub2 = Subarea(area_id=area2.id, name=f"Biotecnologia {uid}")
    db_session.add_all([sub1, sub2])
    await db_session.flush()

    # Projeto 1: Homologado, Científico, Tomada: Sim, Mesa: Não
    proj1 = Project(
        event_id=evt.id,
        subarea_id=sub1.id,
        title="Estudo da Eficiência Solar com Lentes Fresnel",
        project_type=ProjectType.SCIENTIFIC,
        education_level=EducationLevelEnum.MEDIO,
        abstract="Resumo do projeto de energia solar...",
        booth_number="A-01",
        needs_electricity=True,
        needs_table=False,
        qrcode_token=f"QR-STICKER-01-{uid}",
        status=ProjectStatus.HOMOLOGATED,
        advisor_consent=True,
    )

    # Projeto 2: Homologado, Tecnológico, Tomada: Não, Mesa: Sim
    proj2 = Project(
        event_id=evt.id,
        subarea_id=sub2.id,
        title="Purificação da Água com Biopolímeros",
        project_type=ProjectType.TECHNOLOGICAL,
        education_level=EducationLevelEnum.MEDIO,
        abstract="Resumo do projeto biotec...",
        booth_number="B-02",
        needs_electricity=False,
        needs_table=True,
        qrcode_token=f"QR-STICKER-02-{uid}",
        status=ProjectStatus.HOMOLOGATED,
        advisor_consent=True,
    )

    # Projeto 3: Em Rascunho (Draft)
    proj3 = Project(
        event_id=evt.id,
        subarea_id=sub1.id,
        title="Robô Seguidor de Linha",
        project_type=ProjectType.TECHNOLOGICAL,
        education_level=EducationLevelEnum.MEDIO,
        abstract="Resumo rascunho...",
        booth_number="C-03",
        needs_electricity=True,
        needs_table=True,
        qrcode_token=f"QR-STICKER-03-{uid}",
        status=ProjectStatus.DRAFT,
        advisor_consent=False,
    )

    db_session.add_all([proj1, proj2, proj3])
    await db_session.commit()
    await db_session.refresh(evt)
    await db_session.refresh(proj1)
    await db_session.refresh(proj2)
    await db_session.refresh(proj3)

    return evt, [proj1, proj2, proj3]


@pytest.mark.asyncio
async def test_booth_sticker_service_a5_direct(
    db_session: AsyncSession,
    event_with_booth_stickers: Tuple[Event, List[Project]],
):
    """Testa a geração direta no service para layout A5 (2 por folha)."""
    evt, projs = event_with_booth_stickers

    pdf_bytes = await generate_event_booth_stickers_pdf(
        db=db_session,
        event_id=evt.id,
        status_filter="homologated",
        layout="a5_double",
    )

    assert isinstance(pdf_bytes, bytes)
    assert len(pdf_bytes) > 1000
    assert pdf_bytes.startswith(b"%PDF-")


@pytest.mark.asyncio
async def test_booth_sticker_service_a6_direct(
    db_session: AsyncSession,
    event_with_booth_stickers: Tuple[Event, List[Project]],
):
    """Testa a geração direta no service para layout A6 (4 por folha)."""
    evt, projs = event_with_booth_stickers

    pdf_bytes = await generate_event_booth_stickers_pdf(
        db=db_session,
        event_id=evt.id,
        status_filter="all",
        layout="a6_quad",
    )

    assert isinstance(pdf_bytes, bytes)
    assert len(pdf_bytes) > 1000
    assert pdf_bytes.startswith(b"%PDF-")


@pytest.mark.asyncio
async def test_booth_sticker_service_single_project(
    db_session: AsyncSession,
    event_with_booth_stickers: Tuple[Event, List[Project]],
):
    """Testa a geração de adesivo para um único projeto específico."""
    evt, projs = event_with_booth_stickers
    target_proj = projs[0]

    pdf_bytes = await generate_event_booth_stickers_pdf(
        db=db_session,
        event_id=evt.id,
        project_id=target_proj.id,
        layout="a5_double",
    )

    assert isinstance(pdf_bytes, bytes)
    assert len(pdf_bytes) > 1000
    assert pdf_bytes.startswith(b"%PDF-")


@pytest.mark.asyncio
async def test_endpoint_export_event_booth_stickers_batch(
    client: AsyncClient,
    event_with_booth_stickers: Tuple[Event, List[Project]],
    admin_sticker_headers: dict,
):
    """Testa endpoint GET /api/v1/events/{event_id}/booth-stickers/pdf."""
    evt, projs = event_with_booth_stickers

    # 1. Testar layout A5 (padrão)
    res = await client.get(
        f"/api/v1/events/{evt.id}/booth-stickers/pdf?layout=a5_double&status_filter=homologated",
        headers=admin_sticker_headers,
    )
    assert res.status_code == 200
    assert res.headers["content-type"] == "application/pdf"
    assert "attachment" in res.headers["content-disposition"]
    assert res.content.startswith(b"%PDF-")

    # 2. Testar layout A6
    res_a6 = await client.get(
        f"/api/v1/events/{evt.id}/booth-stickers/pdf?layout=a6_quad&status_filter=all",
        headers=admin_sticker_headers,
    )
    assert res_a6.status_code == 200
    assert res_a6.content.startswith(b"%PDF-")


@pytest.mark.asyncio
async def test_endpoint_export_project_booth_sticker_individual(
    client: AsyncClient,
    event_with_booth_stickers: Tuple[Event, List[Project]],
    admin_sticker_headers: dict,
):
    """Testa endpoint GET /api/v1/projects/{project_id}/booth-sticker/pdf individual."""
    evt, projs = event_with_booth_stickers
    target_proj = projs[1]

    res = await client.get(
        f"/api/v1/projects/{target_proj.id}/booth-sticker/pdf?layout=a5_double",
        headers=admin_sticker_headers,
    )
    assert res.status_code == 200
    assert res.headers["content-type"] == "application/pdf"
    assert f"adesivo_bancada_projeto_{target_proj.id}" in res.headers["content-disposition"]
    assert res.content.startswith(b"%PDF-")
