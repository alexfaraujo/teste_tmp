"""Automated tests for Phase 5: Official Standings and Dual Ranking System (BR-12, BR-17 and SEC-03).

- Ranking 1: Regular/General awards considering ALL evaluation items:
  - Sub-ranking 1.1: By Knowledge Area and Education Level (MEDIO, FUNDAMENTAL, JUNIOR).
  - Sub-ranking 1.2: Overall Best Project of the fair (unifying all evaluated projects).
- Ranking 2: Specific awards considering EXCLUSIVELY the criteria linked via award_criteria.
- Universal API Key protection (SEC-03).
"""

from datetime import date, timedelta
import uuid
import pytest
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.security import create_access_token
from app.models.enums import EducationLevelEnum, ProjectMemberRole, ProjectStatus, ProjectType, UserRole
from app.models.event import Event
from app.models.evaluation import EvaluationCriterion
from app.models.knowledge_area import KnowledgeArea, Subarea
from app.models.person import Person, PersonSubarea
from app.models.project import Project, ProjectMember


@pytest.fixture
def admin_headers(seed_admin: Person) -> dict:
    """Gera cabeçalho Bearer e API Key para o Administrador."""
    token = create_access_token(
        subject=str(seed_admin.id),
        claims={"role": "ADMIN", "email": seed_admin.email}
    )
    return {"Authorization": f"Bearer {token}", "X-API-Key": settings.API_KEY}


@pytest.fixture
async def phase5_setup(db_session: AsyncSession):
    """Cria um cenário completo de apuração com múltiplos projetos, áreas, níveis e critérios no PostgreSQL real."""
    suffix = uuid.uuid4().hex[:6]
    today = date.today()

    # 1. Evento
    event = Event(
        name=f"FECITEL Fase 5 Apuração {suffix}",
        year=2026,
        start_date=today,
        end_date=today + timedelta(days=3),
        max_projects_per_evaluator=4
    )
    db_session.add(event)
    await db_session.flush()

    # 2. Critérios da Ficha de Avaliação
    # Critério 1: Metodologia e Rigor Científico (peso 1.0)
    crit_metodologia = EvaluationCriterion(
        event_id=event.id,
        name=f"Metodologia e Rigor {suffix}",
        scientific_description="Rigor e reprodutibilidade do método.",
        technological_description="Arquitetura e desenvolvimento.",
        max_score=10.0,
        weight=1.0
    )
    # Critério 2: Inovação e Criatividade (peso 1.0)
    crit_inovacao = EvaluationCriterion(
        event_id=event.id,
        name=f"Inovação e Criatividade {suffix}",
        scientific_description="Originalidade da hipótese.",
        technological_description="Solução disruptiva e patenteável.",
        max_score=10.0,
        weight=1.0
    )
    # Critério 3: Comunicação e Apresentação (peso 1.0)
    crit_comunicacao = EvaluationCriterion(
        event_id=event.id,
        name=f"Comunicação e Domínio {suffix}",
        scientific_description="Clareza na exposição oral.",
        technological_description="Demonstração prática do protótipo.",
        max_score=10.0,
        weight=1.0
    )
    db_session.add_all([crit_metodologia, crit_inovacao, crit_comunicacao])
    await db_session.flush()

    # 3. Grandes Áreas e Subáreas
    area_exatas = KnowledgeArea(event_id=event.id, name=f"Ciências Exatas {suffix}")
    area_bio = KnowledgeArea(event_id=event.id, name=f"Ciências Biológicas {suffix}")
    db_session.add_all([area_exatas, area_bio])
    await db_session.flush()

    sub_comp = Subarea(area_id=area_exatas.id, name=f"Computação {suffix}")
    sub_saude = Subarea(area_id=area_bio.id, name=f"Biotecnologia {suffix}")
    db_session.add_all([sub_comp, sub_saude])
    await db_session.flush()

    # 4. Avaliador
    evaluator = Person(
        name=f"Dr. Avaliador Geral {suffix}",
        email=f"eval.f5.{suffix}@fecitel.ifms.edu.br",
        role=UserRole.EVALUATOR,
        barcode=f"BC-EVAL5-{suffix}"
    )
    db_session.add(evaluator)
    await db_session.flush()

    # Qualificação de subáreas para o avaliador (Computação e Biotecnologia)
    ps_comp = PersonSubarea(event_id=event.id, person_id=evaluator.id, subarea_id=sub_comp.id)
    ps_saude = PersonSubarea(event_id=event.id, person_id=evaluator.id, subarea_id=sub_saude.id)
    db_session.add_all([ps_comp, ps_saude])
    await db_session.flush()

    # 5. Projetos Concorrentes:
    # Projeto A: Exatas - Ensino Médio
    # Notas: Metodologia=9.0, Inovação=7.0, Comunicação=8.0 -> Média Global = (9+7+8)/3 = 8.0
    # Mas em Inovação tem 7.0
    proj_a = Project(
        event_id=event.id,
        subarea_id=sub_comp.id,
        title=f"Projeto A (Exatas Médio) {suffix}",
        project_type=ProjectType.TECHNOLOGICAL,
        education_level=EducationLevelEnum.MEDIO,
        booth_number="EX-M1",
        qrcode_token=f"QR-A-{suffix}",
        status=ProjectStatus.PRESENT,
        advisor_consent=True
    )

    # Projeto B: Exatas - Ensino Médio
    # Notas: Metodologia=6.0, Inovação=10.0, Comunicação=5.0 -> Média Global = (6+10+5)/3 = 7.0
    # No prêmio específico de Inovação tem 10.0 (Campeão de Inovação!)
    proj_b = Project(
        event_id=event.id,
        subarea_id=sub_comp.id,
        title=f"Projeto B (Exatas Médio Campeão Inovação) {suffix}",
        project_type=ProjectType.TECHNOLOGICAL,
        education_level=EducationLevelEnum.MEDIO,
        booth_number="EX-M2",
        qrcode_token=f"QR-B-{suffix}",
        status=ProjectStatus.PRESENT,
        advisor_consent=True
    )

    # Projeto C: Exatas - Ensino Fundamental
    # Notas: Metodologia=8.5, Inovação=8.5, Comunicação=8.5 -> Média Global = 8.5
    proj_c = Project(
        event_id=event.id,
        subarea_id=sub_comp.id,
        title=f"Projeto C (Exatas Fundamental) {suffix}",
        project_type=ProjectType.SCIENTIFIC,
        education_level=EducationLevelEnum.FUNDAMENTAL,
        booth_number="EX-F1",
        qrcode_token=f"QR-C-{suffix}",
        status=ProjectStatus.PRESENT,
        advisor_consent=True
    )

    # Projeto D: Biológicas - Ensino Médio
    # Notas: Metodologia=10.0, Inovação=9.5, Comunicação=9.9 -> Média Global = 9.8 (Melhor Geral da Feira!)
    proj_d = Project(
        event_id=event.id,
        subarea_id=sub_saude.id,
        title=f"Projeto D (Biológicas Médio Melhor Geral) {suffix}",
        project_type=ProjectType.SCIENTIFIC,
        education_level=EducationLevelEnum.MEDIO,
        booth_number="BIO-M1",
        qrcode_token=f"QR-D-{suffix}",
        status=ProjectStatus.PRESENT,
        advisor_consent=True
    )

    db_session.add_all([proj_a, proj_b, proj_c, proj_d])
    await db_session.flush()
    await db_session.commit()

    return {
        "event": event,
        "crit_metodologia": crit_metodologia,
        "crit_inovacao": crit_inovacao,
        "crit_comunicacao": crit_comunicacao,
        "area_exatas": area_exatas,
        "area_bio": area_bio,
        "sub_comp": sub_comp,
        "sub_saude": sub_saude,
        "evaluator": evaluator,
        "proj_a": proj_a,
        "proj_b": proj_b,
        "proj_c": proj_c,
        "proj_d": proj_d
    }


@pytest.mark.asyncio
async def test_dual_ranking_system_phase5(
    client: AsyncClient,
    admin_headers: dict,
    phase5_setup: dict
):
    """
    Testa rigorosamente os dois rankings da Fase 5:
    1. Ranking 1 (Premiações Regulares por Área e Nível de Ensino - todos os itens):
       - Exatas Ensino Médio: 1º Projeto A (8.0), 2º Projeto B (7.0)
       - Exatas Ensino Fundamental: 1º Projeto C (8.5)
       - Biológicas Ensino Médio: 1º Projeto D (9.8)
    2. Ranking 1 (Melhor Geral da Feira - todos os itens):
       - 1º Projeto D (9.8)
       - 2º Projeto C (8.5)
       - 3º Projeto A (8.0)
       - 4º Projeto B (7.0)
    3. Ranking 2 (Premiação Específica de Inovação - apenas critério de Inovação):
       - 1º Projeto B (Nota 10.0 no critério de Inovação)
       - 2º Projeto D (Nota 9.5 no critério de Inovação)
       - 3º Projeto C (Nota 8.5 no critério de Inovação)
       - 4º Projeto A (Nota 7.0 no critério de Inovação)
    """
    data = phase5_setup
    event = data["event"]
    evaluator = data["evaluator"]
    c_met = data["crit_metodologia"]
    c_ino = data["crit_inovacao"]
    c_com = data["crit_comunicacao"]
    proj_a = data["proj_a"]
    proj_b = data["proj_b"]
    proj_c = data["proj_c"]
    proj_d = data["proj_d"]

    eval_token = create_access_token(
        subject=str(evaluator.id),
        claims={"role": "EVALUATOR", "email": evaluator.email}
    )
    eval_headers = {"Authorization": f"Bearer {eval_token}", "X-API-Key": settings.API_KEY}

    # 1. Alocar o avaliador aos 4 projetos
    for proj in [proj_a, proj_b, proj_c, proj_d]:
        resp_alloc = await client.post(
            "/api/v1/allocations/manual",
            json={"event_id": event.id, "project_id": proj.id, "evaluator_id": evaluator.id},
            headers=admin_headers
        )
        assert resp_alloc.status_code == 201

    # 2. Submeter avaliações presenciais (BR-11)
    # Projeto A: 9.0, 7.0, 8.0 -> Média = 8.0
    await client.post(
        "/api/v1/evaluations",
        json={
            "project_id": proj_a.id,
            "general_feedback": "Projeto A avaliado com consistência geral.",
            "status": "COMPLETED",
            "items": [
                {"criterion_id": c_met.id, "score": 9.0},
                {"criterion_id": c_ino.id, "score": 7.0},
                {"criterion_id": c_com.id, "score": 8.0}
            ]
        },
        headers=eval_headers
    )

    # Projeto B: 6.0, 10.0, 5.0 -> Média = 7.0
    await client.post(
        "/api/v1/evaluations",
        json={
            "project_id": proj_b.id,
            "general_feedback": "Projeto B com inovação disruptiva excepcional!",
            "status": "COMPLETED",
            "items": [
                {"criterion_id": c_met.id, "score": 6.0},
                {"criterion_id": c_ino.id, "score": 10.0},
                {"criterion_id": c_com.id, "score": 5.0}
            ]
        },
        headers=eval_headers
    )

    # Projeto C: 8.5, 8.5, 8.5 -> Média = 8.5
    await client.post(
        "/api/v1/evaluations",
        json={
            "project_id": proj_c.id,
            "general_feedback": "Projeto C do Ensino Fundamental com grande maturidade.",
            "status": "COMPLETED",
            "items": [
                {"criterion_id": c_met.id, "score": 8.5},
                {"criterion_id": c_ino.id, "score": 8.5},
                {"criterion_id": c_com.id, "score": 8.5}
            ]
        },
        headers=eval_headers
    )

    # Projeto D: 10.0, 9.5, 9.9 -> Média = 9.8
    await client.post(
        "/api/v1/evaluations",
        json={
            "project_id": proj_d.id,
            "general_feedback": "Projeto D exemplar em Biotecnologia, padrão ouro.",
            "status": "COMPLETED",
            "items": [
                {"criterion_id": c_met.id, "score": 10.0},
                {"criterion_id": c_ino.id, "score": 9.5},
                {"criterion_id": c_com.id, "score": 9.9}
            ]
        },
        headers=eval_headers
    )

    # =========================================================================
    # TESTE DO RANKING 1 (Premiações Regulares: Área e Nível de Ensino)
    # =========================================================================
    resp_area_level = await client.get(
        f"/api/v1/dashboard/leaderboard/area-level?event_id={event.id}",
        headers=admin_headers
    )
    assert resp_area_level.status_code == 200, resp_area_level.text
    groups = resp_area_level.json()
    assert len(groups) == 3, f"Esperado 3 grupos (Exatas Médio, Exatas Fundamental, Bio Médio), obteve {len(groups)}"

    # Verificar grupo Exatas - Ensino Médio
    exatas_medio = next(g for g in groups if "Exatas" in g["area_name"] and g["education_level"] == "MEDIO")
    assert exatas_medio["total_projects"] == 2
    # 1º Lugar deve ser Projeto A (8.0)
    assert exatas_medio["standings"][0]["project_id"] == proj_a.id
    assert exatas_medio["standings"][0]["final_score"] == 8.0
    assert exatas_medio["standings"][0]["rank_position"] == 1
    # 2º Lugar deve ser Projeto B (7.0)
    assert exatas_medio["standings"][1]["project_id"] == proj_b.id
    assert exatas_medio["standings"][1]["final_score"] == 7.0
    assert exatas_medio["standings"][1]["rank_position"] == 2

    # Verificar grupo Exatas - Ensino Fundamental
    exatas_fund = next(g for g in groups if "Exatas" in g["area_name"] and g["education_level"] == "FUNDAMENTAL")
    assert exatas_fund["total_projects"] == 1
    assert exatas_fund["standings"][0]["project_id"] == proj_c.id
    assert exatas_fund["standings"][0]["final_score"] == 8.5
    assert exatas_fund["standings"][0]["rank_position"] == 1

    # Verificar grupo Biológicas - Ensino Médio
    bio_medio = next(g for g in groups if "Biológicas" in g["area_name"] and g["education_level"] == "MEDIO")
    assert bio_medio["total_projects"] == 1
    assert bio_medio["standings"][0]["project_id"] == proj_d.id
    assert bio_medio["standings"][0]["final_score"] == 9.8
    assert bio_medio["standings"][0]["rank_position"] == 1

    # =========================================================================
    # TESTE DO RANKING 1 (Melhor Geral da Feira / Overall Best)
    # =========================================================================
    resp_overall = await client.get(
        f"/api/v1/dashboard/leaderboard/overall?event_id={event.id}",
        headers=admin_headers
    )
    assert resp_overall.status_code == 200, resp_overall.text
    overall = resp_overall.json()
    assert overall["total_evaluated_projects"] == 4

    # Ordem decrescente de nota considerando TODOS os itens:
    # 1º: Projeto D (9.8)
    # 2º: Projeto C (8.5)
    # 3º: Projeto A (8.0)
    # 4º: Projeto B (7.0)
    standings_overall = overall["standings"]
    assert standings_overall[0]["project_id"] == proj_d.id
    assert standings_overall[0]["final_score"] == 9.8
    assert standings_overall[0]["rank_position"] == 1

    assert standings_overall[1]["project_id"] == proj_c.id
    assert standings_overall[1]["final_score"] == 8.5
    assert standings_overall[1]["rank_position"] == 2

    assert standings_overall[2]["project_id"] == proj_a.id
    assert standings_overall[2]["final_score"] == 8.0
    assert standings_overall[2]["rank_position"] == 3

    assert standings_overall[3]["project_id"] == proj_b.id
    assert standings_overall[3]["final_score"] == 7.0
    assert standings_overall[3]["rank_position"] == 4

    # Validação da divisão por Nível de Ensino no Ranking Geral
    assert "by_education_level" in overall
    assert len(overall["by_education_level"]) > 0
    medio_group = next((g for g in overall["by_education_level"] if g["education_level"] == "MEDIO"), None)
    assert medio_group is not None
    assert medio_group["standings"][0]["project_id"] == proj_d.id
    assert medio_group["standings"][0]["rank_position"] == 1
    fund_group = next((g for g in overall["by_education_level"] if g["education_level"] == "FUNDAMENTAL"), None)
    assert fund_group is not None
    assert fund_group["standings"][0]["project_id"] == proj_c.id
    assert fund_group["standings"][0]["rank_position"] == 1

    # =========================================================================
    # TESTE DO RANKING 2 (Premiações Específicas / Prêmios Temáticos - Itens Indicados)
    # =========================================================================
    # Cadastrar Prêmio Especial "Troféu Inovação e Criatividade Tecnológica"
    # Vinculado EXCLUSIVAMENTE ao critério c_ino (Inovação)
    resp_award = await client.post(
        f"/api/v1/events/{event.id}/awards",
        json={
            "name": f"Troféu Inovação Disruptiva {data['area_exatas'].name}",
            "description": "Premiando a ideia mais criativa e inovadora do evento.",
            "sponsor": "Empresa Parceira Tech",
            "criteria_links": [
                {"criterion_id": c_ino.id, "weight": 1.0}
            ]
        },
        headers=admin_headers
    )
    assert resp_award.status_code == 201, resp_award.text
    award_data = resp_award.json()
    award_id = award_data["id"]

    # Obter apuração do prêmio específico
    resp_standings = await client.get(
        f"/api/v1/awards/{award_id}/standings",
        headers=admin_headers
    )
    assert resp_standings.status_code == 200, resp_standings.text
    award_standings = resp_standings.json()
    assert award_standings["award_id"] == award_id
    assert award_standings["criteria_considered"] == [c_ino.name]
    assert award_standings["total_competing_projects"] == 4

    # No ranking do prêmio específico de Inovação:
    # 1º: Projeto B (Nota 10.0 em Inovação - Vencedor!)
    # 2º: Projeto D (Nota 9.5 em Inovação)
    # 3º: Projeto C (Nota 8.5 em Inovação)
    # 4º: Projeto A (Nota 7.0 em Inovação)
    items = award_standings["standings"]
    assert items[0]["project_id"] == proj_b.id
    assert items[0]["award_score"] == 10.0
    assert items[0]["rank_position"] == 1

    assert items[1]["project_id"] == proj_d.id
    assert items[1]["award_score"] == 9.5
    assert items[1]["rank_position"] == 2

    assert items[2]["project_id"] == proj_c.id
    assert items[2]["award_score"] == 8.5
    assert items[2]["rank_position"] == 3

    assert items[3]["project_id"] == proj_a.id
    assert items[3]["award_score"] == 7.0
    assert items[3]["rank_position"] == 4


@pytest.mark.asyncio
async def test_sec03_universal_api_key_protection_phase5(
    unauthenticated_client: AsyncClient,
    phase5_setup: dict
):
    """Verifica que todas as rotas do Ranking 1 e Ranking 2 rejeitam requisições sem API Key (Regra SEC-03)."""
    event_id = phase5_setup["event"].id

    # 1. Rota Ranking 1 Área/Nível sem API Key deve retornar 401
    resp1 = await unauthenticated_client.get(f"/api/v1/dashboard/leaderboard/area-level?event_id={event_id}")
    assert resp1.status_code == 401
    assert "API Key" in resp1.json()["detail"]

    # 2. Rota Ranking 1 Geral sem API Key deve retornar 401
    resp2 = await unauthenticated_client.get(f"/api/v1/dashboard/leaderboard/overall?event_id={event_id}")
    assert resp2.status_code == 401
    assert "API Key" in resp2.json()["detail"]

    # 3. Rota Ranking 2 Prêmios Específicos sem API Key deve retornar 401
    resp3 = await unauthenticated_client.get("/api/v1/awards/1/standings")
    assert resp3.status_code == 401
    assert "API Key" in resp3.json()["detail"]


@pytest.mark.asyncio
async def test_update_award_and_criterion_name(
    client: AsyncClient,
    admin_headers: dict,
    phase5_setup: dict
):
    """Testa atualização de premiação (PUT /awards/{award_id}) e serialização de criterion_name."""
    event_id = phase5_setup["event"].id
    crit_inovacao = phase5_setup["crit_inovacao"]
    crit_metodologia = phase5_setup["crit_metodologia"]

    # 1. Cadastrar prêmio inicial
    create_payload = {
        "name": "Prêmio Sustentabilidade",
        "description": "Foco em sustentabilidade ambiental",
        "sponsor": "Empresa Verde",
        "criteria_links": [
            {"criterion_id": crit_inovacao.id, "weight": 2.0}
        ]
    }
    create_resp = await client.post(
        f"/api/v1/events/{event_id}/awards",
        json=create_payload,
        headers=admin_headers
    )
    assert create_resp.status_code == 201
    award_data = create_resp.json()
    award_id = award_data["id"]
    assert award_data["name"] == "Prêmio Sustentabilidade"
    assert len(award_data["criteria_links"]) == 1
    assert award_data["criteria_links"][0]["criterion_name"] == crit_inovacao.name

    # 2. Atualizar prêmio via PUT /awards/{award_id}
    update_payload = {
        "name": "Prêmio Sustentabilidade e Inovação 2026",
        "sponsor": "Instituto Verde & IFMS",
        "description": "Premiação especial atualizada",
        "criteria_links": [
            {"criterion_id": crit_inovacao.id, "weight": 3.0},
            {"criterion_id": crit_metodologia.id, "weight": 1.5}
        ]
    }
    put_resp = await client.put(
        f"/api/v1/awards/{award_id}",
        json=update_payload,
        headers=admin_headers
    )
    assert put_resp.status_code == 200
    updated_data = put_resp.json()
    assert updated_data["name"] == "Prêmio Sustentabilidade e Inovação 2026"
    assert updated_data["sponsor"] == "Instituto Verde & IFMS"
    assert len(updated_data["criteria_links"]) == 2
    # Verificar que os nomes dos critérios estão presentes
    crit_names = [cl["criterion_name"] for cl in updated_data["criteria_links"]]
    assert crit_inovacao.name in crit_names
    assert crit_metodologia.name in crit_names
