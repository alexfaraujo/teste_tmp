"""Automated tests for Authentication, OTP generation and Security rules (SEC-01, SEC-02)."""

import pytest
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.security import (
    generate_access_code,
    get_password_hash,
    verify_password
)
from app.models.person import Person


@pytest.mark.asyncio
async def test_access_code_generation_format():
    """Valida se o gerador de código OTP cumpre estritamente os requisitos da Regra SEC-01."""
    code = generate_access_code(year=2026)
    
    # 1. Deve ter exatamente 8 caracteres
    assert len(code) == 8, f"Código deve ter 8 caracteres, obteve {len(code)}"
    
    # 2. Deve ser 100% em CAIXA ALTA
    assert code == code.upper(), f"Código deve ser em caixa alta: {code}"
    
    # 3. Dois primeiros caracteres devem ser os últimos 2 dígitos do ano ('26')
    assert code.startswith("26"), f"Código deve iniciar com o ano '26': {code}"
    
    # 4. Os demais 6 caracteres devem conter exatamente 4 letras e 2 dígitos
    suffix = code[2:]
    letters_count = sum(c.isalpha() for c in suffix)
    digits_count = sum(c.isdigit() for c in suffix)
    assert letters_count == 4, f"Sufixo deve conter 4 letras, obteve {letters_count}"
    assert digits_count == 2, f"Sufixo deve conter 2 dígitos numéricos, obteve {digits_count}"


@pytest.mark.asyncio
async def test_bcrypt_password_hashing():
    """Valida se a função de hash de senhas bcrypt funciona corretamente com salt."""
    raw_password = "SenhaSuperSecretaFecitel2026"
    hashed = get_password_hash(raw_password)
    
    assert hashed != raw_password
    assert verify_password(raw_password, hashed) is True
    assert verify_password("SenhaIncorreta", hashed) is False


@pytest.mark.asyncio
async def test_admin_login_success(client: AsyncClient, seed_admin: Person):
    """Testa login bem-sucedido de Administrador com email e senha mestre."""
    response = await client.post(
        "/api/v1/auth/admin/login",
        json={
            "email": seed_admin.email,
            "password": "SenhaSuperSegura123!"
        }
    )
    assert response.status_code == 200, response.text
    data = response.json()
    assert "access_token" in data
    assert data["token_type"] == "bearer"
    assert data["expires_in_hours"] == 12
    assert data["role"] == "ADMIN"
    assert data["email"] == seed_admin.email


@pytest.mark.asyncio
async def test_admin_login_invalid_credentials(client: AsyncClient, seed_admin: Person):
    """Testa falha de login de administrador com senha incorreta."""
    response = await client.post(
        "/api/v1/auth/admin/login",
        json={
            "email": seed_admin.email,
            "password": "SenhaCompletamenteErrada"
        }
    )
    assert response.status_code == 401
    assert "Credenciais inválidas" in response.json()["detail"]


@pytest.mark.asyncio
async def test_participant_otp_request_and_login_flow(
    client: AsyncClient,
    seed_evaluator: Person
):
    """Testa o fluxo completo de solicitação e validação de OTP para participantes (Regra SEC-01)."""
    # 1. Solicitar código de acesso OTP
    request_resp = await client.post(
        "/api/v1/auth/request-code",
        json={"email": seed_evaluator.email}
    )
    assert request_resp.status_code == 200, request_resp.text
    req_data = request_resp.json()
    assert "Código de acesso" in req_data["message"]
    
    # Em ambiente de teste/debug, recuperamos o código gerado exposto no payload
    otp_code = req_data["dev_code"]
    assert len(otp_code) == 8
    
    # 2. Validar código em caixa alta e receber o token JWT
    verify_resp = await client.post(
        "/api/v1/auth/verify-code",
        json={
            "email": seed_evaluator.email,
            "access_code": otp_code
        }
    )
    assert verify_resp.status_code == 200, verify_resp.text
    token_data = verify_resp.json()
    assert "access_token" in token_data
    assert token_data["role"] == "EVALUATOR"
    
    # 3. Acessar endpoint protegido /auth/me usando o token emitido
    me_resp = await client.get(
        "/api/v1/auth/me",
        headers={"Authorization": f"Bearer {token_data['access_token']}"}
    )
    assert me_resp.status_code == 200
    user_data = me_resp.json()
    assert user_data["email"] == seed_evaluator.email
    assert user_data["name"] == seed_evaluator.name


@pytest.mark.asyncio
async def test_participant_otp_invalid_code(client: AsyncClient, seed_evaluator: Person):
    """Testa falha de validação quando o participante digita um código incorreto."""
    # 1. Solicita um código para gerar o hash inicial
    await client.post(
        "/api/v1/auth/request-code",
        json={"email": seed_evaluator.email}
    )

    # 2. Tenta verificar fornecendo código incorreto
    response = await client.post(
        "/api/v1/auth/verify-code",
        json={
            "email": seed_evaluator.email,
            "access_code": "26ZZZZ99"
        }
    )
    assert response.status_code == 401
    assert "Código de acesso inválido" in response.json()["detail"]


@pytest.mark.asyncio
async def test_soft_deleted_user_cannot_login(
    client: AsyncClient,
    db_session: AsyncSession,
    seed_evaluator: Person
):
    """Garante que registros com soft-delete (deleted_at preenchido) não conseguem solicitar código nem logar (BR-13)."""
    # Aplicar soft delete
    seed_evaluator.soft_delete()
    await db_session.commit()
    
    # Tentar solicitar código
    response = await client.post(
        "/api/v1/auth/request-code",
        json={"email": seed_evaluator.email}
    )
    assert response.status_code == 404
    
    # Restaurar usuário para não impactar fixtures subsequentes
    seed_evaluator.deleted_at = None
    await db_session.commit()
