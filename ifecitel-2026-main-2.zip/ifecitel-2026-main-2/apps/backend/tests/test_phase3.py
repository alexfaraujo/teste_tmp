"""Automated tests for Phase 3: Homologation, Barcode Check-in, Atomic Kit Checkout and Public TV Kiosk Dashboard."""

from datetime import date, datetime, timedelta, timezone
import uuid
import pytest
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.security import create_access_token
from app.models.enums import EducationLevelEnum, ProjectMemberRole, ProjectStatus, ProjectType, UserRole
from app.models.event import Event
from app.models.knowledge_area import KnowledgeArea, Subarea
from app.models.person import EventParticipant, Person
from app.models.project import Project, ProjectMember


@pytest.fixture
def admin_headers(seed_admin: Person) -> dict:
    """Gera cabeçalho Bearer e API Key para o Administrador."""
    token = create_access_token(
        subject=str(seed_admin.id),
        claims={"role": "ADMIN", "email": seed_admin.email}
    )
    return {"Authorization": f"Bearer {token}", "X-API-Key": settings.API_KEY}


@pytest.fixture
def advisor_headers(seed_advisor: Person) -> dict:
    """Gera cabeçalho Bearer e API Key para o Orientador."""
    token = create_access_token(
        subject=str(seed_advisor.id),
        claims={"role": "ADVISOR", "email": seed_advisor.email}
    )
    return {"Authorization": f"Bearer {token}", "X-API-Key": settings.API_KEY}


@pytest.fixture
def student_headers(seed_student: Person) -> dict:
    """Gera cabeçalho Bearer e API Key para o Estudante."""
    token = create_access_token(
        subject=str(seed_student.id),
        claims={"role": "STUDENT", "email": seed_student.email}
    )
    return {"Authorization": f"Bearer {token}", "X-API-Key": settings.API_KEY}


@pytest.fixture
async def seed_student(db_session: AsyncSession) -> Person:
    """Cria ou recupera estudante de teste no banco real."""
    from sqlalchemy import select
    stmt = select(Person).where(Person.email == "estudante.fase3@fecitel.ifms.edu.br")
    res = await db_session.execute(stmt)
    student = res.scalar_one_or_none()

    if not student:
        student = Person(
            name="Estudante Fase 3",
            email="estudante.fase3@fecitel.ifms.edu.br",
            role=UserRole.STUDENT,
            barcode="BC-STUDENT-F3"
        )
        db_session.add(student)
        await db_session.commit()
        await db_session.refresh(student)
    return student


@pytest.fixture
async def seed_advisor(db_session: AsyncSession) -> Person:
    """Cria ou recupera orientador de teste no banco real."""
    from sqlalchemy import select
    stmt = select(Person).where(Person.email == "orientador.fase3@fecitel.ifms.edu.br")
    res = await db_session.execute(stmt)
    advisor = res.scalar_one_or_none()

    if not advisor:
        advisor = Person(
            name="Orientador Fase 3",
            email="orientador.fase3@fecitel.ifms.edu.br",
            role=UserRole.ADVISOR,
            barcode="BC-ADVISOR-F3"
        )
        db_session.add(advisor)
        await db_session.commit()
        await db_session.refresh(advisor)
    return advisor


@pytest.mark.asyncio
async def test_project_homologation_and_booth_assignment(
    client: AsyncClient,
    admin_headers: dict,
    student_headers: dict,
    advisor_headers: dict,
    seed_student: Person,
    seed_advisor: Person,
    db_session: AsyncSession
):
    """Testa homologação de projeto com anuência do orientador e alocação de bancada (BR-06)."""
    today = date.today()
    run_id = uuid.uuid4().hex[:6]
    event = Event(
        name=f"FECITEL Homologação Test {run_id}",
        year=2026,
        start_date=today,
        end_date=today + timedelta(days=10)
    )
    db_session.add(event)
    await db_session.flush()

    area = KnowledgeArea(event_id=event.id, name=f"Ciências da Saúde {run_id}")
    db_session.add(area)
    await db_session.flush()

    subarea = Subarea(area_id=area.id, name=f"Medicina Preventiva {run_id}")
    db_session.add(subarea)
    await db_session.commit()
    await db_session.refresh(subarea)

    # 1. Submeter projeto (inicia em WAITING_CONSENT)
    sub_resp = await client.post(
        "/api/v1/projects",
        headers=student_headers,
        json={
            "event_id": event.id,
            "subarea_id": subarea.id,
            "education_level": "MEDIO",
            "title": "Estudo sobre Vacinação Comunitária",
            "project_type": "SCIENTIFIC",
            "members": [
                {"person_id": seed_student.id, "role": "STUDENT_LEADER"},
                {"person_id": seed_advisor.id, "role": "ADVISOR"}
            ]
        }
    )
    assert sub_resp.status_code == 201
    project_id = sub_resp.json()["id"]

    # 2. Tentar homologar antes da anuência do orientador deve falhar com 400 (BR-05, BR-06)
    homolog_fail = await client.patch(
        f"/api/v1/projects/{project_id}/homologate",
        headers=admin_headers,
        json={"homologated": True, "booth_number": "A-01"}
    )
    assert homolog_fail.status_code == 400
    assert "sem a anuência digital formal" in homolog_fail.json()["detail"]

    # 3. Orientador concede a anuência digital
    consent_resp = await client.post(
        f"/api/v1/projects/{project_id}/consent",
        headers=advisor_headers
    )
    assert consent_resp.status_code == 200

    # 4. Agora a coordenação homologa o trabalho e aloca o estande A-01
    homolog_ok = await client.patch(
        f"/api/v1/projects/{project_id}/homologate",
        headers=admin_headers,
        json={"homologated": True, "booth_number": "A-01"}
    )
    assert homolog_ok.status_code == 200
    data_homolog = homolog_ok.json()
    assert data_homolog["status"] == "HOMOLOGATED"
    assert data_homolog["booth_number"] == "A-01"

    # 5. Remanejar número de bancada para B-12
    booth_resp = await client.patch(
        f"/api/v1/projects/{project_id}/booth",
        headers=admin_headers,
        json={"booth_number": "B-12"}
    )
    assert booth_resp.status_code == 200
    assert booth_resp.json()["booth_number"] == "B-12"


@pytest.mark.asyncio
async def test_barcode_checkin_and_collective_presence_trigger(
    client: AsyncClient,
    db_session: AsyncSession
):
    """Testa bipagem de crachá individual e gatilho de presença coletiva da bancada (BR-08)."""
    today = date.today()
    run_id = uuid.uuid4().hex[:6]
    event = Event(
        name=f"FECITEL Checkin Test {run_id}",
        year=2026,
        start_date=today,
        end_date=today + timedelta(days=10)
    )
    db_session.add(event)
    await db_session.flush()

    area = KnowledgeArea(event_id=event.id, name=f"Biológicas {run_id}")
    db_session.add(area)
    await db_session.flush()

    subarea = Subarea(area_id=area.id, name=f"Genética {run_id}")
    db_session.add(subarea)
    await db_session.flush()

    barcode = f"BC-STUDENT-{run_id}"
    student = Person(
        name=f"Estudante Checkin {run_id}",
        email=f"student_{run_id}@teste.com",
        role=UserRole.STUDENT,
        barcode=barcode
    )
    db_session.add(student)
    await db_session.flush()

    # Projeto já homologado com estande C-05
    project = Project(
        event_id=event.id,
        subarea_id=subarea.id,
        title=f"Projeto Genética Avançada {run_id}",
        status=ProjectStatus.HOMOLOGATED,
        advisor_consent=True,
        booth_number="C-05",
        qrcode_token=f"FECITEL-2026-{run_id}"
    )
    db_session.add(project)
    await db_session.flush()

    # Vincular estudante ao projeto
    member = ProjectMember(
        project_id=project.id,
        person_id=student.id,
        role=ProjectMemberRole.STUDENT_LEADER
    )
    db_session.add(member)
    await db_session.commit()

    # 1. Bipar o código de barras no credenciamento da recepção
    scan_resp = await client.post(
        "/api/v1/logistics/scan-barcode",
        json={"barcode": barcode, "event_id": event.id}
    )
    assert scan_resp.status_code == 200, scan_resp.text
    scan_data = scan_resp.json()

    assert scan_data["person_id"] == student.id
    assert scan_data["presence_confirmed"] is True
    assert scan_data["booth_number"] == "C-05"
    assert scan_data["collective_presence_triggered"] is True
    assert scan_data["project_status"] == "PRESENT"

    # 2. Verificar se o status do projeto no banco foi atualizado para PRESENT
    await db_session.refresh(project)
    assert project.status == ProjectStatus.PRESENT


@pytest.mark.asyncio
async def test_atomic_kit_checkout_and_duplicate_prevention(
    client: AsyncClient,
    db_session: AsyncSession
):
    """Testa baixa atômica de entrega de kit e proteção contra retirada dupla (BR-09)."""
    today = date.today()
    run_id = uuid.uuid4().hex[:6]
    event = Event(
        name=f"FECITEL Kits Test {run_id}",
        year=2026,
        start_date=today,
        end_date=today + timedelta(days=10)
    )
    db_session.add(event)
    await db_session.flush()

    barcode = f"BC-KIT-{run_id}"
    person = Person(
        name=f"Participante Kit {run_id}",
        email=f"kit_{run_id}@teste.com",
        role=UserRole.STUDENT,
        barcode=barcode
    )
    db_session.add(person)
    await db_session.flush()

    # Participante com camiseta tamanho G e kit pendente
    participant = EventParticipant(
        event_id=event.id,
        person_id=person.id,
        tshirt_size="G",
        kit_delivered=False
    )
    db_session.add(participant)
    await db_session.commit()

    # 1. Primeira retirada de kit (guichê 1): deve ter sucesso
    resp_1 = await client.post(
        "/api/v1/logistics/checkout-kit",
        json={"barcode": barcode, "event_id": event.id}
    )
    assert resp_1.status_code == 200, resp_1.text
    data_1 = resp_1.json()
    assert data_1["kit_delivered"] is True
    assert data_1["tshirt_size"] == "G"

    # 2. Segunda tentativa de retirada (guichê 2 simultâneo): deve ser bloqueada com 409 Conflict
    resp_2 = await client.post(
        "/api/v1/logistics/checkout-kit",
        json={"barcode": barcode, "event_id": event.id}
    )
    assert resp_2.status_code == 409
    assert "Bloqueio atômico de duplicidade" in resp_2.json()["detail"]


@pytest.mark.asyncio
async def test_project_kits_summary_query(
    client: AsyncClient,
    db_session: AsyncSession
):
    """Testa endpoint de consulta da equipe e status de kits para triagem no guichê."""
    today = date.today()
    run_id = uuid.uuid4().hex[:6]
    event = Event(
        name=f"FECITEL Triagem Test {run_id}",
        year=2026,
        start_date=today,
        end_date=today + timedelta(days=10)
    )
    db_session.add(event)
    await db_session.flush()

    area = KnowledgeArea(event_id=event.id, name=f"Humanas {run_id}")
    db_session.add(area)
    await db_session.flush()

    subarea = Subarea(area_id=area.id, name=f"História Regional {run_id}")
    db_session.add(subarea)
    await db_session.flush()

    student = Person(
        name=f"Aluno Triagem {run_id}",
        email=f"triagem_{run_id}@teste.com",
        role=UserRole.STUDENT,
        barcode=f"BC-TRIAGEM-{run_id}"
    )
    db_session.add(student)
    await db_session.flush()

    part = EventParticipant(
        event_id=event.id,
        person_id=student.id,
        tshirt_size="GG",
        presence_confirmed=True,
        kit_delivered=True,
        kit_delivered_at=datetime.now(timezone.utc)
    )
    db_session.add(part)
    await db_session.flush()

    project = Project(
        event_id=event.id,
        subarea_id=subarea.id,
        title=f"Projeto Histórico {run_id}",
        booth_number="H-03",
        status=ProjectStatus.PRESENT,
        qrcode_token=f"FECITEL-2026-H-{run_id}"
    )
    db_session.add(project)
    await db_session.flush()

    member = ProjectMember(
        project_id=project.id,
        person_id=student.id,
        role=ProjectMemberRole.STUDENT_LEADER
    )
    db_session.add(member)
    await db_session.commit()

    resp = await client.get(f"/api/v1/logistics/project-kits/{project.id}")
    assert resp.status_code == 200
    data = resp.json()
    assert data["project_id"] == project.id
    assert data["booth_number"] == "H-03"
    assert len(data["members"]) == 1
    assert data["members"][0]["tshirt_size"] == "GG"
    assert data["members"][0]["presence_confirmed"] is True
    assert data["members"][0]["kit_delivered"] is True


@pytest.mark.asyncio
async def test_public_tv_dashboard_metrics_and_privacy_guarantee(
    client: AsyncClient,
    db_session: AsyncSession
):
    """
    Testa métricas do telão público de TV (BR-14) e valida a garantia de sigilo
    absoluto (sem vazamento de notas, rankings ou avaliadores).
    """
    today = date.today()
    run_id = uuid.uuid4().hex[:6]
    event = Event(
        name=f"FECITEL Telão Test {run_id}",
        year=2026,
        start_date=today,
        end_date=today + timedelta(days=10)
    )
    db_session.add(event)
    await db_session.flush()

    area = KnowledgeArea(event_id=event.id, name=f"Robótica {run_id}")
    db_session.add(area)
    await db_session.flush()

    subarea = Subarea(area_id=area.id, name=f"Automação {run_id}")
    db_session.add(subarea)
    await db_session.flush()

    # Projeto presente
    p1 = Project(
        event_id=event.id,
        subarea_id=subarea.id,
        title=f"Robô Explorador {run_id}",
        status=ProjectStatus.PRESENT,
        qrcode_token=f"FECITEL-2026-R1-{run_id}"
    )
    # Projeto apenas submetido (não presente na bancada)
    p2 = Project(
        event_id=event.id,
        subarea_id=subarea.id,
        title=f"Braço Robótico {run_id}",
        status=ProjectStatus.SUBMITTED,
        qrcode_token=f"FECITEL-2026-R2-{run_id}"
    )
    db_session.add_all([p1, p2])
    await db_session.commit()

    resp = await client.get(f"/api/v1/dashboard/public-tv?event_id={event.id}")
    assert resp.status_code == 200
    data = resp.json()

    assert data["event_id"] == event.id
    assert data["total_registered_projects"] >= 2
    assert data["total_present_projects"] >= 1
    assert "areas_progress" in data
    assert any(a["area_name"] == f"Robótica {run_id}" for a in data["areas_progress"])

    # Verificação dos campos de apuração da meta oficial (BR-21)
    assert "min_evaluators_default" in data
    assert "total_expected_evaluations" in data
    assert "evaluation_progress_percent" in data
    assert data["total_expected_evaluations"] >= 2  # Ao menos 1 projeto presente * 2 avaliadores
    
    area_item = next(a for a in data["areas_progress"] if a["area_name"] == f"Robótica {run_id}")
    assert "expected_evaluations" in area_item
    assert "progress_percent" in area_item
    assert "present_projects" in area_item
    assert "total_registered_evaluators" in data
    assert "total_present_evaluators" in data
    assert "total_registered_students_advisors" in data
    assert "total_present_students_advisors" in data

    # Garantia de Sigilo Absoluto (BR-14):
    # Nenhuma chave sensível pode estar presente no payload do quiosque
    forbidden_keys = {"grades", "scores", "evaluators", "ranking", "leaderboard", "individual_notes", "notes"}
    assert not any(k in data for k in forbidden_keys), "Violação de sigilo no telão público!"


@pytest.mark.asyncio
async def test_phase3_api_key_protection(
    unauthenticated_client: AsyncClient
):
    """Garante que todos os endpoints novos da Fase 3 respeitam a Regra SEC-03 (API Key)."""
    # 1. Logistics scan-barcode sem API Key deve retornar 401
    resp_scan = await unauthenticated_client.post(
        "/api/v1/logistics/scan-barcode",
        json={"barcode": "QUALQUER", "event_id": 1}
    )
    assert resp_scan.status_code == 401

    # 2. Logistics checkout-kit sem API Key deve retornar 401
    resp_kit = await unauthenticated_client.post(
        "/api/v1/logistics/checkout-kit",
        json={"barcode": "QUALQUER", "event_id": 1}
    )
    assert resp_kit.status_code == 401

    # 3. Dashboard public-tv sem API Key deve retornar 401
    resp_tv = await unauthenticated_client.get("/api/v1/dashboard/public-tv?event_id=1")
    assert resp_tv.status_code == 401


@pytest.mark.asyncio
async def test_list_projects_pagination_and_rejection(
    client: AsyncClient,
    admin_headers: dict,
    advisor_headers: dict,
    seed_student: Person,
    seed_advisor: Person,
    db_session: AsyncSession
):
    """Testa listagem com paginação real BR-18, filtros, busca e indeferimento com justificativa."""
    today = date.today()
    run_id = uuid.uuid4().hex[:6]
    event = Event(
        name=f"FECITEL Paginação Test {run_id}",
        year=2026,
        start_date=today,
        end_date=today + timedelta(days=10)
    )
    db_session.add(event)
    await db_session.flush()

    area = KnowledgeArea(event_id=event.id, name=f"Exatas {run_id}")
    db_session.add(area)
    await db_session.flush()

    subarea = Subarea(area_id=area.id, name=f"Matemática Aplicada {run_id}")
    db_session.add(subarea)
    await db_session.commit()

    # Criar 2 projetos
    p1 = Project(
        event_id=event.id,
        subarea_id=subarea.id,
        title=f"Projeto Alpha {run_id}",
        status=ProjectStatus.WAITING_CONSENT,
        advisor_consent=False,
        qrcode_token=f"TOKEN-P1-{run_id}"
    )
    p2 = Project(
        event_id=event.id,
        subarea_id=subarea.id,
        title=f"Projeto Beta {run_id}",
        status=ProjectStatus.SUBMITTED,
        advisor_consent=True,
        qrcode_token=f"TOKEN-P2-{run_id}"
    )
    db_session.add_all([p1, p2])
    await db_session.commit()

    # 1. Listar sem paginação
    resp = await client.get(f"/api/v1/projects?event_id={event.id}", headers=admin_headers)
    assert resp.status_code == 200
    assert len(resp.json()) == 2

    # 2. Listar com paginação real (BR-18)
    resp_pag = await client.get(
        f"/api/v1/projects?event_id={event.id}&page=1&limit=15",
        headers=admin_headers
    )
    assert resp_pag.status_code == 200
    pag_data = resp_pag.json()
    assert pag_data["total"] == 2
    assert pag_data["page"] == 1
    assert pag_data["limit"] == 15
    assert pag_data["total_pages"] == 1
    assert len(pag_data["items"]) == 2

    # 3. Busca por termo
    resp_search = await client.get(
        f"/api/v1/projects?event_id={event.id}&page=1&limit=15&search=Alpha",
        headers=admin_headers
    )
    assert resp_search.status_code == 200
    assert resp_search.json()["total"] == 1
    assert resp_search.json()["items"][0]["title"] == f"Projeto Alpha {run_id}"

    # 4. Filtro por status
    resp_filter = await client.get(
        f"/api/v1/projects?event_id={event.id}&status=SUBMITTED",
        headers=admin_headers
    )
    assert resp_filter.status_code == 200
    assert len(resp_filter.json()) == 1
    assert resp_filter.json()[0]["title"] == f"Projeto Beta {run_id}"

    # 5. Indeferir (rejeitar) projeto com justificativa
    resp_reject = await client.patch(
        f"/api/v1/projects/{p2.id}/homologate",
        headers=admin_headers,
        json={
            "homologated": False,
            "rejection_reason": "Metodologia científica insuficiente"
        }
    )
    assert resp_reject.status_code == 200
    assert resp_reject.json()["status"] == "REJECTED"
    assert resp_reject.json()["rejection_reason"] == "Metodologia científica insuficiente"


@pytest.mark.asyncio
async def test_multi_project_logistics_checkin_and_kits(
    client: AsyncClient,
    db_session: AsyncSession
):
    """
    Testa credenciamento de participante com múltiplos trabalhos vinculados (ex: Orientador com 2 estandes).
    Verifica se a resposta da API retorna todos os trabalhos, presença coletiva em todos eles,
    e o status individual dos kits por estande.
    """
    today = date.today()
    run_id = uuid.uuid4().hex[:6]
    event = Event(
        name=f"FECITEL Multi Project Test {run_id}",
        year=2026,
        start_date=today,
        end_date=today + timedelta(days=5)
    )
    db_session.add(event)
    await db_session.flush()

    area = KnowledgeArea(event_id=event.id, name=f"Exatas {run_id}")
    db_session.add(area)
    await db_session.flush()

    sub1 = Subarea(area_id=area.id, name=f"Robótica {run_id}")
    sub2 = Subarea(area_id=area.id, name=f"IA {run_id}")
    db_session.add_all([sub1, sub2])
    await db_session.flush()

    # Orientador de 2 projetos
    advisor = Person(
        name=f"Prof Orientador Multi {run_id}",
        email=f"prof_multi_{run_id}@teste.com",
        role=UserRole.ADVISOR,
        barcode=f"BC-MULTI-ADV-{run_id}"
    )
    # Alunos
    student1 = Person(
        name=f"Aluno Robótica {run_id}",
        email=f"aluno_rob_{run_id}@teste.com",
        role=UserRole.STUDENT,
        barcode=f"BC-ALUNO-ROB-{run_id}"
    )
    student2 = Person(
        name=f"Aluno IA {run_id}",
        email=f"aluno_ia_{run_id}@teste.com",
        role=UserRole.STUDENT,
        barcode=f"BC-ALUNO-IA-{run_id}"
    )
    db_session.add_all([advisor, student1, student2])
    await db_session.flush()

    # Projeto 1 - Estande A-10
    proj1 = Project(
        event_id=event.id,
        subarea_id=sub1.id,
        title=f"Braço Robótico {run_id}",
        status=ProjectStatus.HOMOLOGATED,
        advisor_consent=True,
        booth_number="A-10",
        qrcode_token=f"QR-ROB-{run_id}"
    )
    # Projeto 2 - Estande B-20
    proj2 = Project(
        event_id=event.id,
        subarea_id=sub2.id,
        title=f"Visão Computacional {run_id}",
        status=ProjectStatus.HOMOLOGATED,
        advisor_consent=True,
        booth_number="B-20",
        qrcode_token=f"QR-IA-{run_id}"
    )
    db_session.add_all([proj1, proj2])
    await db_session.flush()

    # Membros do Projeto 1
    m1_adv = ProjectMember(project_id=proj1.id, person_id=advisor.id, role=ProjectMemberRole.ADVISOR)
    m1_stu = ProjectMember(project_id=proj1.id, person_id=student1.id, role=ProjectMemberRole.STUDENT_LEADER)
    # Membros do Projeto 2
    m2_adv = ProjectMember(project_id=proj2.id, person_id=advisor.id, role=ProjectMemberRole.ADVISOR)
    m2_stu = ProjectMember(project_id=proj2.id, person_id=student2.id, role=ProjectMemberRole.STUDENT_LEADER)
    db_session.add_all([m1_adv, m1_stu, m2_adv, m2_stu])
    await db_session.commit()

    # 1. Bipar o crachá do orientador
    scan_resp = await client.post(
        "/api/v1/logistics/scan-barcode",
        json={"barcode": advisor.barcode, "event_id": event.id}
    )
    assert scan_resp.status_code == 200, scan_resp.text
    data = scan_resp.json()

    # Verifica presença individual
    assert data["person_id"] == advisor.id
    assert data["presence_confirmed"] is True
    assert data["collective_presence_triggered"] is True

    # Verifica lista de projetos vinculados
    assert "projects" in data
    assert len(data["projects"]) == 2

    booths = [p["booth_number"] for p in data["projects"]]
    assert "A-10" in booths
    assert "B-20" in booths

    for p in data["projects"]:
        assert p["status"] == "PRESENT"
        assert p["role_in_project"] == "ADVISOR"
        assert p["all_kits_delivered"] is False

    # Verifica mensagem informativa
    assert "2 trabalhos vinculados" in data["message"]

    # Verifica atualização no banco para PRESENT em ambos
    await db_session.refresh(proj1)
    await db_session.refresh(proj2)
    assert proj1.status == ProjectStatus.PRESENT
    assert proj2.status == ProjectStatus.PRESENT

    # 2. Dar baixa no pacote de kits do Projeto 1 (Estande A-10)
    checkout_p1 = await client.post(f"/api/v1/logistics/project-kits/{proj1.id}/checkout")
    assert checkout_p1.status_code == 200
    p1_summary = checkout_p1.json()
    assert all(m["kit_delivered"] for m in p1_summary["members"])

    # 3. Bipar novamente o orientador e verificar que Projeto 1 está com kit entregue e Projeto 2 com kit pendente
    scan_resp2 = await client.post(
        "/api/v1/logistics/scan-barcode",
        json={"barcode": advisor.barcode, "event_id": event.id}
    )
    assert scan_resp2.status_code == 200
    data2 = scan_resp2.json()
    p1_item = next(p for p in data2["projects"] if p["id"] == proj1.id)
    p2_item = next(p for p in data2["projects"] if p["id"] == proj2.id)
    assert p1_item["all_kits_delivered"] is True
    assert p2_item["all_kits_delivered"] is False

    # 4. Bipar o QR Code do estande do Projeto 2 diretamente
    scan_booth_resp = await client.post(
        "/api/v1/logistics/scan-barcode",
        json={"barcode": f"QR-IA-{run_id}", "event_id": event.id}
    )
    assert scan_booth_resp.status_code == 200
    booth_data = scan_booth_resp.json()
    assert booth_data["is_project_scan"] is True
    assert booth_data["project_id"] == proj2.id
    assert len(booth_data["projects"]) == 1
    assert booth_data["projects"][0]["all_kits_delivered"] is False

