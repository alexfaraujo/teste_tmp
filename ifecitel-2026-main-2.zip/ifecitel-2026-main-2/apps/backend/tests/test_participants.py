"""Automated tests for Participant Management CRUD and Role Assignment (Regras BR-16, BR-18, BR-19)."""

from datetime import date
import uuid
import pytest
from httpx import AsyncClient
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.security import create_access_token
from app.models.enums import EducationLevelEnum, ProjectMemberRole, ProjectStatus, ProjectType, UserRole
from app.models.event import Event
from app.models.knowledge_area import KnowledgeArea, Subarea
from app.models.person import EventParticipant, Person
from app.models.project import Project, ProjectMember


@pytest.fixture
def admin_headers(seed_admin: Person) -> dict:
    """Gera cabeçalho Bearer e API Key para o Administrador."""
    token = create_access_token(
        subject=str(seed_admin.id),
        claims={"role": "ADMIN", "email": seed_admin.email}
    )
    return {"Authorization": f"Bearer {token}", "X-API-Key": settings.API_KEY}


@pytest.fixture
async def setup_event(db_session: AsyncSession) -> Event:
    """Cria uma edição de evento isolada para os testes de participantes."""
    unique_suffix = uuid.uuid4().hex[:6]
    event = Event(
        name=f"FECITEL Participantes {unique_suffix}",
        year=2026,
        start_date=date(2026, 10, 1),
        end_date=date(2026, 10, 5),
        max_projects_per_evaluator=3,
        max_file_size_mb=25,
    )
    db_session.add(event)
    await db_session.commit()
    await db_session.refresh(event)
    return event


@pytest.fixture
async def setup_subarea(db_session: AsyncSession, setup_event: Event) -> Subarea:
    """Cria área e subárea para vincular a avaliador."""
    area = KnowledgeArea(event_id=setup_event.id, name=f"Ciências Exatas {uuid.uuid4().hex[:4]}")
    db_session.add(area)
    await db_session.flush()

    subarea = Subarea(area_id=area.id, name="Matemática Aplicada")
    db_session.add(subarea)
    await db_session.commit()
    await db_session.refresh(subarea)
    return subarea


@pytest.mark.asyncio
async def test_create_participant_and_assign_evaluator_role(
    client: AsyncClient,
    admin_headers: dict,
    setup_event: Event,
    setup_subarea: Subarea
):
    """Testa criação de novo participante com papel EVALUATOR e subárea vinculada."""
    unique_id = uuid.uuid4().hex[:6]
    email = f"avaliador.{unique_id}@teste.com"

    payload = {
        "name": "Dr. Avaliador Teste",
        "email": email,
        "cpf": "123.456.789-00",
        "affiliation": "Universidade Estadual",
        "role": "EVALUATOR",
        "tshirt_size": "G",
        "subarea_ids": [setup_subarea.id],
    }

    response = await client.post(
        f"/api/v1/participants?event_id={setup_event.id}",
        json=payload,
        headers=admin_headers
    )

    assert response.status_code == 201
    data = response.json()
    assert data["name"] == "Dr. Avaliador Teste"
    assert data["email"] == email
    assert data["cpf"] == "123.456.789-00"
    assert data["affiliation"] == "Universidade Estadual"
    assert data["role"] == "EVALUATOR"
    assert data["tshirt_size"] == "G"
    assert data["barcode"] is not None
    assert data["barcode"].startswith("BC-")

    # Consultar detalhes
    detail_res = await client.get(
        f"/api/v1/participants/{data['person_id']}?event_id={setup_event.id}",
        headers=admin_headers
    )
    assert detail_res.status_code == 200
    detail_data = detail_res.json()
    assert len(detail_data["subareas"]) == 1
    assert detail_data["subareas"][0]["subarea_id"] == setup_subarea.id


@pytest.mark.asyncio
async def test_list_participants_pagination_and_search(
    client: AsyncClient,
    admin_headers: dict,
    setup_event: Event
):
    """Testa listagem paginada (BR-18) e busca textual por nome/CPF."""
    # Criar 3 participantes
    for i in range(3):
        p_payload = {
            "name": f"Participante Alfa {i}",
            "email": f"alfa{i}.{uuid.uuid4().hex[:4]}@teste.com",
            "cpf": f"111.222.333-0{i}",
            "affiliation": "IFMS Campus Corumbá",
            "role": "STUDENT",
            "tshirt_size": "M",
        }
        await client.post(
            f"/api/v1/participants?event_id={setup_event.id}",
            json=p_payload,
            headers=admin_headers
        )

    # Listar com paginação
    list_res = await client.get(
        f"/api/v1/participants?event_id={setup_event.id}&page=1&limit=2",
        headers=admin_headers
    )
    assert list_res.status_code == 200
    data = list_res.json()
    assert data["total"] == 3
    assert data["page"] == 1
    assert data["limit"] == 2
    assert data["total_pages"] == 2
    assert len(data["items"]) == 2

    # Busca por nome
    search_res = await client.get(
        f"/api/v1/participants?event_id={setup_event.id}&search=Alfa 1",
        headers=admin_headers
    )
    assert search_res.status_code == 200
    s_data = search_res.json()
    assert s_data["total"] == 1
    assert "Alfa 1" in s_data["items"][0]["name"]

    # Busca por CPF numérico sem pontuação
    cpf_res = await client.get(
        f"/api/v1/participants?event_id={setup_event.id}&search=11122233301",
        headers=admin_headers
    )
    assert cpf_res.status_code == 200
    c_data = cpf_res.json()
    assert c_data["total"] == 1
    assert c_data["items"][0]["cpf"] == "111.222.333-01"


@pytest.mark.asyncio
async def test_update_participant_data(
    client: AsyncClient,
    admin_headers: dict,
    setup_event: Event
):
    """Testa atualização cadastral (correção de nome, CPF, papel e tamanho de camiseta)."""
    p_payload = {
        "name": "Nome Com Erro de Digitacao",
        "email": f"correcao.{uuid.uuid4().hex[:4]}@teste.com",
        "cpf": "000.000.000-00",
        "affiliation": "Escola X",
        "role": "STUDENT",
        "tshirt_size": "P",
    }
    create_res = await client.post(
        f"/api/v1/participants?event_id={setup_event.id}",
        json=p_payload,
        headers=admin_headers
    )
    person_id = create_res.json()["person_id"]

    # Atualizar dados
    update_payload = {
        "name": "Nome Corrigido",
        "cpf": "999.888.777-66",
        "affiliation": "IFMS Campus Campo Grande",
        "role": "ADVISOR",
        "tshirt_size": "GG",
    }
    patch_res = await client.patch(
        f"/api/v1/participants/{person_id}?event_id={setup_event.id}",
        json=update_payload,
        headers=admin_headers
    )
    assert patch_res.status_code == 200
    p_data = patch_res.json()
    assert p_data["name"] == "Nome Corrigido"
    assert p_data["cpf"] == "999.888.777-66"
    assert p_data["affiliation"] == "IFMS Campus Campo Grande"
    assert p_data["role"] == "ADVISOR"
    assert p_data["tshirt_size"] == "GG"


@pytest.mark.asyncio
async def test_delete_participant_with_project_integrity_check(
    client: AsyncClient,
    admin_headers: dict,
    setup_event: Event,
    setup_subarea: Subarea,
    db_session: AsyncSession
):
    """Testa trava de integridade ao tentar excluir participante vinculado a projeto (BR-16)."""
    # 1. Criar participante
    p_payload = {
        "name": "Aluno Autor Projeto",
        "email": f"autor.{uuid.uuid4().hex[:4]}@teste.com",
        "role": "STUDENT",
        "tshirt_size": "M",
    }
    create_res = await client.post(
        f"/api/v1/participants?event_id={setup_event.id}",
        json=p_payload,
        headers=admin_headers
    )
    person_id = create_res.json()["person_id"]

    # 2. Criar projeto e vincular participante como membro da equipe
    project = Project(
        event_id=setup_event.id,
        subarea_id=setup_subarea.id,
        title="Projeto de Astronomia Comunitária",
        abstract="Estudo sobre observação estelar",
        education_level=EducationLevelEnum.MEDIO,
        project_type=ProjectType.SCIENTIFIC,
        status=ProjectStatus.HOMOLOGATED,
        qrcode_token=f"QR-{uuid.uuid4().hex[:8]}",
    )
    db_session.add(project)
    await db_session.flush()

    member = ProjectMember(
        project_id=project.id,
        person_id=person_id,
        role=ProjectMemberRole.STUDENT_LEADER,
    )
    db_session.add(member)
    await db_session.commit()

    # 3. Tentar excluir participante vinculado -> Deve falhar com HTTP 400
    del_res = await client.delete(
        f"/api/v1/participants/{person_id}?event_id={setup_event.id}",
        headers=admin_headers
    )
    assert del_res.status_code == 400
    err_detail = del_res.json()["detail"]
    assert "Projeto de Astronomia Comunitária" in err_detail

    # 4. Remover membro do projeto
    member.deleted_at = setup_event.created_at
    await db_session.commit()

    # 5. Tentar excluir novamente -> Agora deve ter sucesso
    del_res_ok = await client.delete(
        f"/api/v1/participants/{person_id}?event_id={setup_event.id}",
        headers=admin_headers
    )
    assert del_res_ok.status_code == 200
    assert "sucesso" in del_res_ok.json()["message"]


@pytest.mark.asyncio
async def test_participant_multiple_roles_and_filtering(
    client: AsyncClient,
    admin_headers: dict,
    setup_event: Event,
    setup_subarea: Subarea
):
    """Testa criação e sincronização de múltiplos papéis (Opção 1) e filtros cruzados."""
    unique_id = uuid.uuid4().hex[:6]
    email = f"multi.{unique_id}@teste.com"

    # 1. Cadastrar participante como Orientador E Avaliador simultaneamente
    payload = {
        "name": "Prof. Orientador e Avaliador",
        "email": email,
        "cpf": "999.888.777-66",
        "affiliation": "IFMS Campus Corumbá",
        "roles": ["ADVISOR", "EVALUATOR"],
        "tshirt_size": "GG",
        "subarea_ids": [setup_subarea.id],
    }

    create_res = await client.post(
        f"/api/v1/participants?event_id={setup_event.id}",
        json=payload,
        headers=admin_headers
    )
    assert create_res.status_code == 201
    created = create_res.json()
    assert "ADVISOR" in created["roles"]
    assert "EVALUATOR" in created["roles"]
    person_id = created["person_id"]

    # 2. Filtrar por ADVISOR -> participante deve ser listado
    res_adv = await client.get(
        f"/api/v1/participants?event_id={setup_event.id}&role=ADVISOR",
        headers=admin_headers
    )
    assert res_adv.status_code == 200
    adv_items = res_adv.json()["items"]
    assert any(item["person_id"] == person_id for item in adv_items)

    # 3. Filtrar por EVALUATOR -> participante também deve ser listado
    res_eval = await client.get(
        f"/api/v1/participants?event_id={setup_event.id}&role=EVALUATOR",
        headers=admin_headers
    )
    assert res_eval.status_code == 200
    eval_items = res_eval.json()["items"]
    assert any(item["person_id"] == person_id for item in eval_items)

    # 4. Detalhes completos devem trazer subárea vinculada
    detail_res = await client.get(
        f"/api/v1/participants/{person_id}?event_id={setup_event.id}",
        headers=admin_headers
    )
    assert detail_res.status_code == 200
    detail = detail_res.json()
    assert set(detail["roles"]) == {"ADVISOR", "EVALUATOR"}
    assert len(detail["subareas"]) == 1
    assert detail["subareas"][0]["subarea_id"] == setup_subarea.id

    # 5. Atualizar papéis para [EVALUATOR, STUDENT]
    update_res = await client.patch(
        f"/api/v1/participants/{person_id}?event_id={setup_event.id}",
        json={"roles": ["EVALUATOR", "STUDENT"]},
        headers=admin_headers
    )
    assert update_res.status_code == 200
    updated = update_res.json()
    assert set(updated["roles"]) == {"EVALUATOR", "STUDENT"}

    # 6. Bloqueio de ADMIN em atualização de participantes (Doc 039)
    update_admin_fail = await client.patch(
        f"/api/v1/participants/{person_id}?event_id={setup_event.id}",
        json={"roles": ["EVALUATOR", "ADMIN"]},
        headers=admin_headers
    )
    assert update_admin_fail.status_code == 400
    assert "Equipe da Feira" in update_admin_fail.json()["detail"]

