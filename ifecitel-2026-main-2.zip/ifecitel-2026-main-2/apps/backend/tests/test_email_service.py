"""Unit tests for EmailService (SMTP access code and notifications)."""

import smtplib
from unittest.mock import MagicMock, patch
import pytest

from app.core.config import settings
from app.services.email_service import EmailService


def test_send_access_code_success():
    """Testa envio de código de acesso com sucesso via EmailService."""
    with patch("smtplib.SMTP") as mock_smtp_cls:
        mock_server = MagicMock()
        mock_smtp_cls.return_value.__enter__.return_value = mock_server

        success = EmailService.send_access_code(
            to_email="teste@exemplo.com",
            nome="Alex Araújo",
            codigo="26ABCD12"
        )

        assert success is True
        mock_smtp_cls.assert_called_once_with(settings.smtp_host, settings.smtp_port, timeout=10)
        assert mock_server.send_message.called
        sent_msg = mock_server.send_message.call_args[0][0]
        assert sent_msg["To"] == "Alex Araújo <teste@exemplo.com>"
        assert sent_msg["Subject"] == "Seu Código de Acesso - EasyEvent"
        assert f"<{settings.email_address}>" in sent_msg["From"]
        payload = sent_msg.get_content()
        assert "Olá Alex Araújo" in payload
        assert "26ABCD12" in payload
        assert "EasyEvent" in payload


def test_send_access_code_failure_tolerance():
    """Testa tolerância a falha quando o servidor SMTP está offline ou inacessível."""
    with patch("smtplib.SMTP", side_effect=smtplib.SMTPConnectError(421, "Connection refused")):
        success = EmailService.send_access_code(
            to_email="teste@exemplo.com",
            nome="Alex Araújo",
            codigo="26ABCD12"
        )
        assert success is False


def test_send_email_success():
    """Testa envio de email genérico com sucesso."""
    with patch("smtplib.SMTP") as mock_smtp_cls:
        mock_server = MagicMock()
        mock_smtp_cls.return_value.__enter__.return_value = mock_server

        success = EmailService.send_email(
            to_email="destinatario@exemplo.com",
            subject="Aviso Importante",
            body="Conteúdo do email informativo",
            to_name="Destinatário"
        )

        assert success is True
        mock_smtp_cls.assert_called_once_with(settings.smtp_host, settings.smtp_port, timeout=10)
        assert mock_server.send_message.called
        sent_msg = mock_server.send_message.call_args[0][0]
        assert sent_msg["To"] == "Destinatário <destinatario@exemplo.com>"
        assert sent_msg["Subject"] == "Aviso Importante"


def test_send_email_failure_tolerance():
    """Testa envio de email genérico quando ocorre falha."""
    with patch("smtplib.SMTP", side_effect=Exception("Timeout")):
        success = EmailService.send_email(
            to_email="destinatario@exemplo.com",
            subject="Aviso Importante",
            body="Conteúdo"
        )
        assert success is False
