"""Unit tests for individual project submission and update with members and quotas."""

import uuid
from datetime import date, timedelta
import pytest
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.security import create_access_token
from app.models.enums import EducationLevelEnum, ProjectMemberRole, ProjectStatus, ProjectType, UserRole
from app.models.event import Event
from app.models.knowledge_area import KnowledgeArea, Subarea
from app.models.person import EventParticipant, Person


@pytest.fixture
def admin_headers(seed_admin: Person) -> dict:
    """Gera cabeçalho Bearer e API Key para o Administrador."""
    token = create_access_token(
        subject=str(seed_admin.id),
        claims={"role": "ADMIN", "email": seed_admin.email}
    )
    return {"Authorization": f"Bearer {token}", "X-API-Key": settings.API_KEY}


@pytest.mark.asyncio
async def test_project_create_and_update_with_members(
    client: AsyncClient,
    admin_headers: dict,
    db_session: AsyncSession
):
    today = date.today()
    run_id = uuid.uuid4().hex[:6]

    # 1. Setup Event & Subarea
    event = Event(
        name=f"FECITEL Members Test {run_id}",
        year=2026,
        start_date=today,
        end_date=today + timedelta(days=10)
    )
    db_session.add(event)
    await db_session.flush()

    area = KnowledgeArea(event_id=event.id, name=f"Engenharia {run_id}")
    db_session.add(area)
    await db_session.flush()

    subarea = Subarea(area_id=area.id, name=f"Robótica {run_id}")
    db_session.add(subarea)

    # 2. Setup Participants (Advisor, Coadvisor, Students)
    advisor = Person(name="Prof Orientador", email=f"orientador_{run_id}@teste.com", cpf=f"111{run_id[:8]}", role=UserRole.ADVISOR)
    coadvisor = Person(name="Prof Coorientador", email=f"coorientador_{run_id}@teste.com", cpf=f"222{run_id[:8]}", role=UserRole.ADVISOR)
    student1 = Person(name="Aluno Lider", email=f"lider_{run_id}@teste.com", cpf=f"333{run_id[:8]}", role=UserRole.STUDENT)
    student2 = Person(name="Aluno 2", email=f"aluno2_{run_id}@teste.com", cpf=f"444{run_id[:8]}", role=UserRole.STUDENT)
    student3 = Person(name="Aluno 3", email=f"aluno3_{run_id}@teste.com", cpf=f"555{run_id[:8]}", role=UserRole.STUDENT)
    student4 = Person(name="Aluno 4", email=f"aluno4_{run_id}@teste.com", cpf=f"666{run_id[:8]}", role=UserRole.STUDENT)
    student5 = Person(name="Aluno 5", email=f"aluno5_{run_id}@teste.com", cpf=f"777{run_id[:8]}", role=UserRole.STUDENT)

    people = [advisor, coadvisor, student1, student2, student3, student4, student5]
    for p in people:
        db_session.add(p)
    await db_session.flush()

    # Vínculo como participantes do evento
    for p in people:
        db_session.add(EventParticipant(event_id=event.id, person_id=p.id))
    await db_session.commit()

    # 3. Test duplicate person in submission -> 422
    dup_resp = await client.post(
        "/api/v1/projects",
        headers=admin_headers,
        json={
            "event_id": event.id,
            "subarea_id": subarea.id,
            "education_level": "MEDIO",
            "title": "Projeto com Integrante Duplicado",
            "members": [
                {"person_id": advisor.id, "role": "ADVISOR"},
                {"person_id": advisor.id, "role": "STUDENT_LEADER"}
            ]
        }
    )
    assert dup_resp.status_code == 422
    assert "mesmo participante não pode ser selecionado" in dup_resp.json()["detail"]

    # 4. Test quota violation on submission -> 422 (MEDIO allows max 4 students, sending 5)
    quota_resp = await client.post(
        "/api/v1/projects",
        headers=admin_headers,
        json={
            "event_id": event.id,
            "subarea_id": subarea.id,
            "education_level": "MEDIO",
            "title": "Projeto com 5 Estudantes no Médio",
            "members": [
                {"person_id": advisor.id, "role": "ADVISOR"},
                {"person_id": student1.id, "role": "STUDENT_LEADER"},
                {"person_id": student2.id, "role": "STUDENT_MEMBER"},
                {"person_id": student3.id, "role": "STUDENT_MEMBER"},
                {"person_id": student4.id, "role": "STUDENT_MEMBER"},
                {"person_id": student5.id, "role": "STUDENT_MEMBER"}
            ]
        }
    )
    assert quota_resp.status_code == 422
    assert "Cota excedida" in quota_resp.json()["detail"]

    # 5. Successful creation with auto_homologate and booth_number
    valid_create_resp = await client.post(
        "/api/v1/projects",
        headers=admin_headers,
        json={
            "event_id": event.id,
            "subarea_id": subarea.id,
            "education_level": "MEDIO",
            "title": "Braço Robótico Automatizado",
            "project_type": "TECHNOLOGICAL",
            "booth_number": "B-42",
            "auto_homologate": True,
            "members": [
                {"person_id": advisor.id, "role": "ADVISOR"},
                {"person_id": student1.id, "role": "STUDENT_LEADER"},
                {"person_id": student2.id, "role": "STUDENT_MEMBER"}
            ]
        }
    )
    assert valid_create_resp.status_code == 201, valid_create_resp.text
    created_proj = valid_create_resp.json()
    assert created_proj["status"] == "HOMOLOGATED"
    assert created_proj["advisor_consent"] is True
    assert created_proj["booth_number"] == "B-42"
    assert len(created_proj["members"]) == 3

    # Checar se person_cpf veio exposto
    adv_member = next(m for m in created_proj["members"] if m["role"] == "ADVISOR")
    assert adv_member["person_cpf"] == advisor.cpf
    assert adv_member["person_name"] == advisor.name

    proj_id = created_proj["id"]

    # 6. Test update: change members (add coadvisor, replace student2 with student3 and student4)
    update_resp = await client.put(
        f"/api/v1/projects/{proj_id}",
        headers=admin_headers,
        json={
            "title": "Braço Robótico Atualizado com IA",
            "members": [
                {"person_id": advisor.id, "role": "ADVISOR"},
                {"person_id": coadvisor.id, "role": "COADVISOR"},
                {"person_id": student1.id, "role": "STUDENT_LEADER"},
                {"person_id": student3.id, "role": "STUDENT_MEMBER"},
                {"person_id": student4.id, "role": "STUDENT_MEMBER"}
            ]
        }
    )
    assert update_resp.status_code == 200, update_resp.text
    updated_proj = update_resp.json()
    assert updated_proj["title"] == "Braço Robótico Atualizado com IA"
    assert len(updated_proj["members"]) == 5
    roles = {m["role"] for m in updated_proj["members"]}
    assert "ADVISOR" in roles
    assert "COADVISOR" in roles
    assert "STUDENT_LEADER" in roles
    assert "STUDENT_MEMBER" in roles

    # 7. Test update with quota violation -> 422
    update_fail_resp = await client.put(
        f"/api/v1/projects/{proj_id}",
        headers=admin_headers,
        json={
            "members": [
                {"person_id": advisor.id, "role": "ADVISOR"},
                {"person_id": student1.id, "role": "STUDENT_LEADER"},
                {"person_id": student2.id, "role": "STUDENT_MEMBER"},
                {"person_id": student3.id, "role": "STUDENT_MEMBER"},
                {"person_id": student4.id, "role": "STUDENT_MEMBER"},
                {"person_id": student5.id, "role": "STUDENT_MEMBER"}
            ]
        }
    )
    assert update_fail_resp.status_code == 422
    assert "Cota excedida" in update_fail_resp.json()["detail"]
