"""Testes automatizados para a geração de Cards de Kits em PDF (Individual e Coletivo por Projeto)."""

from datetime import date, timedelta
from typing import List, Tuple
import pytest
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.core.security import create_access_token, get_password_hash
from app.models.enums import EducationLevelEnum, ProjectMemberRole, ProjectStatus, ProjectType, UserRole
from app.models.event import Event, EventAdministrator, EventAdminRole
from app.models.knowledge_area import KnowledgeArea, Subarea
from app.models.person import EventParticipant, EventParticipantRole, Person
from app.models.project import Project, ProjectMember
from app.services.kit_card_service import generate_event_kit_cards_pdf


@pytest.fixture
async def admin_kit_user(db_session: AsyncSession) -> Person:
    """Administrador para os testes de geração de cards de kits."""
    email = "admin.kits@easyevent.test"
    stmt = select(Person).where(Person.email == email)
    res = await db_session.execute(stmt)
    p = res.scalar_one_or_none()
    if not p:
        p = Person(
            name="Gestor de Kits",
            email=email,
            role=UserRole.ADMIN,
            password_hash=get_password_hash("SenhaForte123!"),
            barcode="BC-ADMIN-KITS-01",
        )
        db_session.add(p)
        await db_session.commit()
        await db_session.refresh(p)
    return p


@pytest.fixture
def admin_kit_headers(admin_kit_user: Person) -> dict:
    token = create_access_token(
        subject=str(admin_kit_user.id),
        claims={"email": admin_kit_user.email},
    )
    return {
        "Authorization": f"Bearer {token}",
        "X-API-Key": "fecitel_secret_api_key_2026",
    }


@pytest.fixture
async def event_with_projects(db_session: AsyncSession, admin_kit_user: Person) -> Tuple[Event, List[Project]]:
    """Cria um evento completo com área, subárea, projetos homologados, membros e camisetas."""
    today = date.today()
    evt = Event(
        name="Feira Tecnológica de Teste Kits 2026",
        year=2026,
        start_date=today,
        end_date=today + timedelta(days=3),
        location="Pavilhão de Testes",
        organizing_institution="IFMS Campus Três Lagoas",
        owner_id=admin_kit_user.id,
    )
    db_session.add(evt)
    await db_session.flush()

    # Vínculo administrativo
    admin_link = EventAdministrator(
        event_id=evt.id,
        person_id=admin_kit_user.id,
        role=EventAdminRole.COORDINATOR,
    )
    db_session.add(admin_link)

    # Área e Subárea
    area = KnowledgeArea(event_id=evt.id, name="Ciências Exatas")
    db_session.add(area)
    await db_session.flush()

    sub = Subarea(area_id=area.id, name="Automação e Robótica")
    db_session.add(sub)
    await db_session.flush()

    import uuid
    uid = uuid.uuid4().hex[:6]

    # Pessoas: Orientador e Estudantes
    orientador = Person(
        name="Prof. Carlos Eduardo Silva",
        email=f"carlos.kits.{uid}@escola.edu.br",
        role=UserRole.ADVISOR,
        affiliation="Escola Estadual Fernando Corrêa",
        barcode=f"BC-ORIENTADOR-{uid}",
    )
    aluno1 = Person(
        name="Lucas Gabriel de Almeida",
        email=f"lucas.kits.{uid}@escola.edu.br",
        role=UserRole.STUDENT,
        affiliation="Escola Estadual Fernando Corrêa",
        barcode=f"BC-ALUNO1-{uid}",
    )
    aluno2 = Person(
        name="Beatriz dos Santos Ramos",
        email=f"beatriz.kits.{uid}@escola.edu.br",
        role=UserRole.STUDENT,
        affiliation="Escola Estadual Fernando Corrêa",
        barcode=f"BC-ALUNO2-{uid}",
    )
    db_session.add_all([orientador, aluno1, aluno2])
    await db_session.flush()

    # Participações com tamanhos de camisetas
    part_orientador = EventParticipant(
        event_id=evt.id,
        person_id=orientador.id,
        tshirt_size="GG",
        presence_confirmed=False,
    )
    part_aluno1 = EventParticipant(
        event_id=evt.id,
        person_id=aluno1.id,
        tshirt_size="M",
        presence_confirmed=False,
    )
    part_aluno2 = EventParticipant(
        event_id=evt.id,
        person_id=aluno2.id,
        tshirt_size="P",
        presence_confirmed=False,
    )
    db_session.add_all([part_orientador, part_aluno1, part_aluno2])

    # Projeto Homologado com Estande e Infraestrutura
    proj1 = Project(
        event_id=evt.id,
        subarea_id=sub.id,
        title="Braço Robótico de Baixo Custo para Triagem de Resíduos",
        project_type=ProjectType.TECHNOLOGICAL,
        education_level=EducationLevelEnum.MEDIO,
        abstract="Projeto de automação robótica para separação e reciclagem.",
        booth_number="A-04",
        qrcode_token=f"TOKEN-QR-PROJ-01-{uid}",
        status=ProjectStatus.HOMOLOGATED,
        advisor_consent=True,
        needs_electricity=True,
        needs_table=True,
    )
    db_session.add(proj1)
    await db_session.flush()

    # Membros do projeto
    m_orientador = ProjectMember(
        project_id=proj1.id,
        person_id=orientador.id,
        role=ProjectMemberRole.ADVISOR,
    )
    m_aluno1 = ProjectMember(
        project_id=proj1.id,
        person_id=aluno1.id,
        role=ProjectMemberRole.STUDENT_LEADER,
    )
    m_aluno2 = ProjectMember(
        project_id=proj1.id,
        person_id=aluno2.id,
        role=ProjectMemberRole.STUDENT_MEMBER,
    )
    db_session.add_all([m_orientador, m_aluno1, m_aluno2])

    # Segundo Projeto (Estande B-02)
    proj2 = Project(
        event_id=evt.id,
        subarea_id=sub.id,
        title="Aplicativo Mobile para Gestão de Hortas Comunitárias",
        project_type=ProjectType.SCIENTIFIC,
        education_level=EducationLevelEnum.MEDIO,
        abstract="Aplicativo desenvolvido com React Native para agricultores urbanos.",
        booth_number="B-02",
        qrcode_token=f"TOKEN-QR-PROJ-02-{uid}",
        status=ProjectStatus.PRESENT,
        advisor_consent=True,
        needs_electricity=False,
        needs_table=True,
    )
    db_session.add(proj2)
    await db_session.flush()

    m2 = ProjectMember(
        project_id=proj2.id,
        person_id=aluno1.id,
        role=ProjectMemberRole.STUDENT_LEADER,
    )
    db_session.add(m2)

    await db_session.commit()
    await db_session.refresh(evt)

    return evt, [proj1, proj2]


@pytest.mark.asyncio
async def test_generate_project_kit_cards_service_direct(
    db_session: AsyncSession,
    event_with_projects: Tuple[Event, List[Project]],
):
    """Testa geração direta via service do PDF no formato coletivo por projeto (2 por folha)."""
    evt, projects = event_with_projects

    # 1. Geração com camisetas apenas para alunos (orientadores desmarcados)
    pdf_bytes = await generate_event_kit_cards_pdf(
        db=db_session,
        event_id=evt.id,
        card_format="project",
        include_tshirt_students=True,
        include_tshirt_advisors=False,
        include_tshirt_coadvisors=False,
        sort_by="booth",
        status_filter="homologated",
    )

    assert isinstance(pdf_bytes, bytes)
    assert len(pdf_bytes) > 1000
    assert pdf_bytes.startswith(b"%PDF-")


@pytest.mark.asyncio
async def test_generate_individual_kit_cards_service_direct(
    db_session: AsyncSession,
    event_with_projects: Tuple[Event, List[Project]],
):
    """Testa geração direta via service do PDF no formato individual por participante (6 por folha)."""
    evt, projects = event_with_projects

    pdf_bytes = await generate_event_kit_cards_pdf(
        db=db_session,
        event_id=evt.id,
        card_format="individual",
        include_tshirt_students=True,
        include_tshirt_advisors=True,
        include_tshirt_coadvisors=False,
        sort_by="title",
        status_filter="all",
    )

    assert isinstance(pdf_bytes, bytes)
    assert len(pdf_bytes) > 1000
    assert pdf_bytes.startswith(b"%PDF-")


@pytest.mark.asyncio
async def test_kit_cards_pdf_endpoint_via_events(
    client: AsyncClient,
    admin_kit_headers: dict,
    event_with_projects: Tuple[Event, List[Project]],
):
    """Testa a rota GET /api/v1/events/{event_id}/kit-cards/pdf via API HTTP."""
    evt, _ = event_with_projects

    # Formato Coletivo por Projeto
    res_proj = await client.get(
        f"/api/v1/events/{evt.id}/kit-cards/pdf?format=project&include_tshirt_students=true&include_tshirt_advisors=false&sort_by=booth",
        headers=admin_kit_headers,
    )
    assert res_proj.status_code == 200
    assert res_proj.headers["content-type"] == "application/pdf"
    assert f"cards_kits_evento_{evt.id}_project.pdf" in res_proj.headers["content-disposition"]
    assert len(res_proj.content) > 1000

    # Formato Individual por Participante
    res_ind = await client.get(
        f"/api/v1/events/{evt.id}/kit-cards/pdf?format=individual&include_tshirt_students=true&include_tshirt_advisors=true&sort_by=school",
        headers=admin_kit_headers,
    )
    assert res_ind.status_code == 200
    assert res_ind.headers["content-type"] == "application/pdf"
    assert f"cards_kits_evento_{evt.id}_individual.pdf" in res_ind.headers["content-disposition"]
    assert len(res_ind.content) > 1000


@pytest.mark.asyncio
async def test_kit_cards_pdf_endpoint_via_logistics(
    client: AsyncClient,
    admin_kit_headers: dict,
    event_with_projects: Tuple[Event, List[Project]],
):
    """Testa a rota complementar GET /api/v1/logistics/events/{event_id}/kit-cards/pdf."""
    evt, _ = event_with_projects

    res = await client.get(
        f"/api/v1/logistics/events/{evt.id}/kit-cards/pdf?format=project&status_filter=homologated",
        headers=admin_kit_headers,
    )
    assert res.status_code == 200
    assert res.headers["content-type"] == "application/pdf"
    assert len(res.content) > 1000


@pytest.mark.asyncio
async def test_stand_barcode_scan_and_project_package_checkout(
    client: AsyncClient,
    admin_kit_headers: dict,
    event_with_projects: Tuple[Event, List[Project]],
):
    """
    Testa a padronização do código do pacote com o estande:
    1. Bipar o qrcode_token do estande na rota /logistics/scan-barcode identifica o projeto
       e promove seu status para PRESENT.
    2. Qualquer integrante pode retirar o kit: chamada a /logistics/project-kits/{id}/checkout
       dá baixa atômica em todos os kits da equipe e confirma presença de todos.
    """
    evt, projects = event_with_projects
    proj1 = projects[0]

    # 1. Bipar o código do estande (qrcode_token)
    res_scan = await client.post(
        "/api/v1/logistics/scan-barcode",
        headers=admin_kit_headers,
        json={"barcode": proj1.qrcode_token, "event_id": evt.id},
    )
    assert res_scan.status_code == 200
    scan_data = res_scan.json()
    assert scan_data["is_project_scan"] is True
    assert scan_data["project_id"] == proj1.id
    assert scan_data["project_status"] == "PRESENT"
    assert "identificado" in scan_data["message"]

    # 2. Realizar a baixa coletiva de todos os kits da equipe
    res_checkout = await client.post(
        f"/api/v1/logistics/project-kits/{proj1.id}/checkout",
        headers=admin_kit_headers,
    )
    assert res_checkout.status_code == 200
    checkout_data = res_checkout.json()
    assert checkout_data["project_id"] == proj1.id
    assert len(checkout_data["members"]) >= 2
    for m in checkout_data["members"]:
        assert m["kit_delivered"] is True
        assert m["presence_confirmed"] is True
