"""Testes de isolamento multi-tenant por evento e hierarquia administrativa (Regra BR-23)."""

from datetime import date, timedelta
import pytest
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.security import create_access_token, get_password_hash
from app.models.enums import EventAdminRole, UserRole
from app.models.person import Person


from sqlalchemy import select

@pytest.fixture
async def admin1(db_session: AsyncSession) -> Person:
    """Primeiro organizador independente (Prof. Alex)."""
    stmt = select(Person).where(Person.email == "alex.silva.teste@ifms.edu.br")
    res = await db_session.execute(stmt)
    p = res.scalar_one_or_none()
    if not p:
        p = Person(
            name="Prof. Alex Silva",
            email="alex.silva.teste@ifms.edu.br",
            role=UserRole.ADMIN,
            password_hash=get_password_hash("Senha123!"),
            barcode="BC-ALEX-01"
        )
        db_session.add(p)
        await db_session.commit()
        await db_session.refresh(p)
    return p


@pytest.fixture
async def admin2(db_session: AsyncSession) -> Person:
    """Segundo organizador independente (Prof. Rogério)."""
    stmt = select(Person).where(Person.email == "rogerio.santos.teste@ifms.edu.br")
    res = await db_session.execute(stmt)
    p = res.scalar_one_or_none()
    if not p:
        p = Person(
            name="Prof. Rogério Santos",
            email="rogerio.santos.teste@ifms.edu.br",
            role=UserRole.ADMIN,
            password_hash=get_password_hash("Senha123!"),
            barcode="BC-ROGERIO-02"
        )
        db_session.add(p)
        await db_session.commit()
        await db_session.refresh(p)
    return p


@pytest.fixture
def headers_admin1(admin1: Person) -> dict:
    token = create_access_token(subject=str(admin1.id), claims={"email": admin1.email})
    return {
        "Authorization": f"Bearer {token}",
        "X-API-Key": "fecitel_secret_api_key_2026"
    }


@pytest.fixture
def headers_admin2(admin2: Person) -> dict:
    token = create_access_token(subject=str(admin2.id), claims={"email": admin2.email})
    return {
        "Authorization": f"Bearer {token}",
        "X-API-Key": "fecitel_secret_api_key_2026"
    }


@pytest.mark.asyncio
async def test_strict_multi_tenant_isolation_and_visibility(
    client: AsyncClient,
    headers_admin1: dict,
    headers_admin2: dict,
    admin1: Person,
    admin2: Person
):
    """Garante que feiras criadas por um administrador são estritamente invisíveis para outros (BR-23)."""
    today = date.today()

    # 1. Admin 1 cadastra a Feira 1
    resp1 = await client.post(
        "/api/v1/events",
        headers=headers_admin1,
        json={
            "name": "Feira de Robótica de Três Lagoas 2026",
            "year": 2026,
            "start_date": str(today),
            "end_date": str(today + timedelta(days=3))
        }
    )
    assert resp1.status_code == 201
    event1 = resp1.json()
    assert event1["owner_id"] == admin1.id
    assert event1["user_role"] == "COORDINATOR"
    assert event1["is_owner"] is True

    # 2. Admin 2 cadastra a Feira 2
    resp2 = await client.post(
        "/api/v1/events",
        headers=headers_admin2,
        json={
            "name": "Mostra Científica do Pantanal 2026",
            "year": 2026,
            "start_date": str(today),
            "end_date": str(today + timedelta(days=4))
        }
    )
    assert resp2.status_code == 201
    event2 = resp2.json()
    assert event2["owner_id"] == admin2.id
    assert event2["user_role"] == "COORDINATOR"
    assert event2["is_owner"] is True

    # 3. Admin 1 lista suas feiras: deve ver Feira 1 e NÃO ver Feira 2
    list_admin1 = await client.get("/api/v1/events", headers=headers_admin1)
    assert list_admin1.status_code == 200
    events_a1 = list_admin1.json()
    ids_a1 = [e["id"] for e in events_a1]
    assert event1["id"] in ids_a1
    assert event2["id"] not in ids_a1

    # 4. Admin 2 lista suas feiras: deve ver Feira 2 e NÃO ver Feira 1
    list_admin2 = await client.get("/api/v1/events", headers=headers_admin2)
    assert list_admin2.status_code == 200
    events_a2 = list_admin2.json()
    ids_a2 = [e["id"] for e in events_a2]
    assert event2["id"] in ids_a2
    assert event1["id"] not in ids_a2

    # 5. Tentativa de visualização direta de feira alheia via ID deve retornar 403 Forbidden
    cross_get_1 = await client.get(f"/api/v1/events/{event2['id']}", headers=headers_admin1)
    assert cross_get_1.status_code == 403
    assert "Acesso negado" in cross_get_1.json()["detail"]

    cross_get_2 = await client.get(f"/api/v1/events/{event1['id']}", headers=headers_admin2)
    assert cross_get_2.status_code == 403

    # 5.1 Tentativa de acessar o dashboard/admin-overview da feira alheia deve retornar 403
    cross_dash_1 = await client.get(f"/api/v1/dashboard/admin-overview?event_id={event2['id']}", headers=headers_admin1)
    assert cross_dash_1.status_code == 403
    assert "Acesso negado" in cross_dash_1.json()["detail"]

    cross_dash_2 = await client.get(f"/api/v1/dashboard/admin-overview?event_id={event1['id']}", headers=headers_admin2)
    assert cross_dash_2.status_code == 403
    assert "Acesso negado" in cross_dash_2.json()["detail"]

    # 5.2 Tentativa de listar projetos ou participantes da feira alheia deve retornar 403
    cross_proj = await client.get(f"/api/v1/projects?event_id={event1['id']}", headers=headers_admin2)
    assert cross_proj.status_code == 403

    cross_part = await client.get(f"/api/v1/participants?event_id={event1['id']}", headers=headers_admin2)
    assert cross_part.status_code == 403
    assert "Acesso negado" in cross_get_2.json()["detail"]


@pytest.mark.asyncio
async def test_team_delegation_hierarchy_and_permissions(
    client: AsyncClient,
    headers_admin1: dict,
    headers_admin2: dict,
    admin1: Person,
    admin2: Person
):
    """Testa convite de administradores, papéis hierárquicos e blindagem do dono soberano."""
    today = date.today()

    # Admin 1 cria a Feira Principal
    create_resp = await client.post(
        "/api/v1/events",
        headers=headers_admin1,
        json={
            "name": "FECITEC — Feira de Inovação e Tecnologia",
            "year": 2026,
            "start_date": str(today),
            "end_date": str(today + timedelta(days=2))
        }
    )
    assert create_resp.status_code == 201
    event_id = create_resp.json()["id"]

    # Inicialmente, Admin 2 não possui acesso
    check_initial = await client.get(f"/api/v1/events/{event_id}", headers=headers_admin2)
    assert check_initial.status_code == 403

    # Admin 1 convida Admin 2 como ORGANIZER
    invite_resp = await client.post(
        f"/api/v1/events/{event_id}/admins",
        headers=headers_admin1,
        json={
            "email": admin2.email,
            "role": "ORGANIZER"
        }
    )
    assert invite_resp.status_code == 201
    invite_data = invite_resp.json()
    assert invite_data["person_id"] == admin2.id
    assert invite_data["role"] == "ORGANIZER"

    # Agora, Admin 2 visualiza a feira na sua lista e com papel ORGANIZER
    list_resp2 = await client.get("/api/v1/events", headers=headers_admin2)
    assert list_resp2.status_code == 200
    my_events = list_resp2.json()
    ev_item = next(e for e in my_events if e["id"] == event_id)
    assert ev_item["user_role"] == "ORGANIZER"
    assert ev_item["is_owner"] is False

    # Admin 2 (como ORGANIZER) PODE criar critérios de avaliação
    crit_resp = await client.post(
        f"/api/v1/events/{event_id}/criteria",
        headers=headers_admin2,
        json={
            "name": "Clareza da Apresentação Oral",
            "max_score": 10.0,
            "weight": 1.0
        }
    )
    assert crit_resp.status_code == 201

    # Admin 2 (como ORGANIZER) NÃO PODE alterar dados cadastrais da feira (exclusivo COORDINATOR)
    update_fail = await client.put(
        f"/api/v1/events/{event_id}",
        headers=headers_admin2,
        json={"name": "Nome Alterado por Membro"}
    )
    assert update_fail.status_code == 403
    assert "COORDINATOR" in update_fail.json()["detail"]

    # Admin 2 (como ORGANIZER) NÃO PODE convidar outros administradores
    invite_fail = await client.post(
        f"/api/v1/events/{event_id}/admins",
        headers=headers_admin2,
        json={"email": "outro@teste.com", "role": "OPERATOR"}
    )
    assert invite_fail.status_code == 403

    # Admin 1 altera o papel do Admin 2 para OPERATOR
    downgrade_resp = await client.put(
        f"/api/v1/events/{event_id}/admins/{admin2.id}",
        headers=headers_admin1,
        json={"role": "OPERATOR"}
    )
    assert downgrade_resp.status_code == 200
    assert downgrade_resp.json()["role"] == "OPERATOR"

    # Agora Admin 2 (como OPERATOR) NÃO PODE mais criar critérios de avaliação (requer ORGANIZER)
    crit_fail = await client.post(
        f"/api/v1/events/{event_id}/criteria",
        headers=headers_admin2,
        json={
            "name": "Rigor Metodológico",
            "max_score": 10.0,
            "weight": 2.0
        }
    )
    assert crit_fail.status_code == 403
    assert "ORGANIZER" in crit_fail.json()["detail"]

    # Admin 2 (como OPERATOR) NÃO PODE acessar listagem de participantes (requer ORGANIZER - Doc 039)
    part_fail = await client.get(
        f"/api/v1/participants?event_id={event_id}",
        headers=headers_admin2
    )
    assert part_fail.status_code == 403
    assert "ORGANIZER" in part_fail.json()["detail"]

    # Admin 2 (como OPERATOR) NÃO PODE realizar alocação manual de avaliador (requer ORGANIZER - Doc 039)
    alloc_fail = await client.post(
        "/api/v1/allocations/manual",
        headers=headers_admin2,
        json={
            "event_id": event_id,
            "project_id": 999,
            "evaluator_id": 999
        }
    )
    assert alloc_fail.status_code == 403
    assert "ORGANIZER" in alloc_fail.json()["detail"]

    # Admin 2 (como OPERATOR) NÃO PODE vincular subáreas de avaliador (requer ORGANIZER - Doc 039)
    qual_fail = await client.post(
        "/api/v1/allocations/qualify",
        headers=headers_admin2,
        json={
            "event_id": event_id,
            "person_id": 999,
            "subarea_ids": [1]
        }
    )
    assert qual_fail.status_code == 403
    assert "ORGANIZER" in qual_fail.json()["detail"]

    # Tentativa de criar participante com papel ADMIN deve retornar 400 Bad Request (Doc 039)
    part_admin_fail = await client.post(
        f"/api/v1/participants?event_id={event_id}",
        headers=headers_admin1,
        json={
            "name": "Tentativa Admin",
            "email": "tentativa.admin@ifms.edu.br",
            "role": "ADMIN"
        }
    )
    assert part_admin_fail.status_code == 400
    assert "Equipe da Feira" in part_admin_fail.json()["detail"]

    # Tentativa de remover o Coordenador Geral soberano da feira deve ser expressamente bloqueada
    remove_owner_fail = await client.delete(
        f"/api/v1/events/{event_id}/admins/{admin1.id}",
        headers=headers_admin1
    )
    assert remove_owner_fail.status_code == 400
    assert "soberano" in remove_owner_fail.json()["detail"]

    # Admin 1 revoga o acesso do Admin 2
    remove_resp = await client.delete(
        f"/api/v1/events/{event_id}/admins/{admin2.id}",
        headers=headers_admin1
    )
    assert remove_resp.status_code == 204

    # Admin 2 volta a receber 403 Forbidden ao tentar acessar a feira
    check_revoked = await client.get(f"/api/v1/events/{event_id}", headers=headers_admin2)
    assert check_revoked.status_code == 403
