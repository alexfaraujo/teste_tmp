# FECITEL — Backend API Central

<p align="center">
  <img src="https://img.shields.io/badge/Python-3.11+-3776AB?style=for-the-badge&logo=python&logoColor=white" alt="Python 3.11+" />
  <img src="https://img.shields.io/badge/FastAPI-0.110+-009688?style=for-the-badge&logo=fastapi&logoColor=white" alt="FastAPI" />
  <img src="https://img.shields.io/badge/PostgreSQL-15+-4169E1?style=for-the-badge&logo=postgresql&logoColor=white" alt="PostgreSQL 15+" />
  <img src="https://img.shields.io/badge/SQLAlchemy-2.0%20Async-D71F00?style=for-the-badge&logo=sqlalchemy&logoColor=white" alt="SQLAlchemy 2.0" />
  <img src="https://img.shields.io/badge/Pydantic-v2-E92063?style=for-the-badge&logo=pydantic&logoColor=white" alt="Pydantic v2" />
  <img src="https://img.shields.io/badge/Pytest-Bare--Metal-0A9EDC?style=for-the-badge&logo=pytest&logoColor=white" alt="Pytest" />
  <img src="https://img.shields.io/badge/Uvicorn-Async%20Worker-499848?style=for-the-badge&logo=gunicorn&logoColor=white" alt="Uvicorn" />
</p>

---

## 1. Visão Geral do Módulo

O **`apps/backend`** é o núcleo de processamento e dados do ecossistema **FECITEL**. Desenvolvido como uma API RESTful assíncrona de altíssimo desempenho (*bare-metal*), ele centraliza todas as regras de negócio, persistência no PostgreSQL, controle de concorrência atômica, autenticação dual e distribuição balanceada de avaliações para os eventos de ciência e tecnologia.

### Principais Responsabilidades:
*   **Autenticação Dual Segura:** Administradores via credenciais e bcrypt; participantes via código OTP exclusivo de 8 caracteres (`YY` + 4 letras + 2 dígitos) enviado por e-mail com mascaramento de tela.
*   **Gestão Completa de Eventos (Multi-Evento BR-01):** Suporte a multi-eventos simultâneos com trava temporal incondicional após a data de encerramento (`end_date`), busca textual com debounce e paginação real (BR-18).
*   **Estrutura Acadêmica Dinâmica (BR-16):** CRUD de áreas e subáreas do conhecimento com proteção referencial estrita e reativação automática de registros em soft delete sem erros 400.
*   **Homologação Documental e Bancadas (BR-05, BR-06, BR-08):** Validação impeditiva de anuência do orientador para deferimento, indeferimento com justificativa registrada e alocação de estandes.
*   **Paginação Real Universal (BR-18):** Consultas otimizadas por offset/limit de 15 itens por página em todas as rotas de listagem.
*   **Algoritmo de Alocação de Avaliadores:** Distribuição pós-check-in com garantia da Regra de Ouro (diferença entre projetos da mesma subárea com delta $\le 1$).
*   **Logística com Lock Atômico:** Entrega de kits com prevenção atômica em nível de banco contra retiradas simultâneas duplicadas.
*   **Dashboard de Telão Confiável:** Endpoint público de alta frequência para o quiosque com segregação lógica de notas e ranqueamento.

---

## 2. Tecnologias e Dependências Principais

| Tecnologia | Versão Mínima | Função na Arquitetura |
| :--- | :--- | :--- |
| **Python** | `3.11+` | Ambiente de execução nativo da linguagem |
| **FastAPI** | `0.110+` | Framework web assíncrono para construção dos endpoints REST |
| **Uvicorn** | `0.29+` | Servidor ASGI de alta performance com hot-reload |
| **SQLAlchemy** | `2.0+` | ORM assíncrono para modelagem de entidades e consultas tipadas |
| **AsyncPG** | `0.29+` | Driver assíncrono nativo em C para comunicação ultra-rápida com PostgreSQL |
| **Alembic** | `1.13+` | Controle de versionamento e migrações do esquema de banco de dados |
| **Pydantic** | `v2.6+` | Validação de payloads, serialização de respostas e tipagem estrita |
| **Passlib / Bcrypt** | `1.7+` | Criptografia de senhas mestres administrativas com salt 12 |
| **PyJWT** | `2.8+` | Emissão e validação de tokens Bearer JWT com validade de 12h |
| **Pytest / AnyIO** | `8.0+` | Suíte de testes automatizados executados diretamente no PostgreSQL real |

---

## 3. Arquitetura e Organização de Diretórios

```
apps/backend/
├── app/
│   ├── api/
│   │   └── v1/
│   │       ├── endpoints/       # Rotas REST agrupadas (auth, events, projects, etc.)
│   │       └── router.py        # Agregador central das rotas v1
│   ├── core/
│   │   ├── config.py            # Leitura de variáveis de ambiente com Pydantic Settings
│   │   ├── database.py          # Engine assíncrona, SessionLocal e dependências de DB
│   │   └── security.py          # Hashing bcrypt, geração do OTP de 8 dígitos e JWT
│   ├── models/                  # Entidades SQLAlchemy com deleted_at universal
│   ├── schemas/                 # Contratos Pydantic de entrada e saída
│   ├── services/                # Regras de negócio e transações diretas (sem repositórios vazios)
│   └── main.py                  # Ponto de entrada FastAPI, CORS e middlewares
├── alembic/                     # Scripts de migração de esquema de banco
├── tests/                       # Testes de integração diretos no PostgreSQL bare-metal
├── .env.example                 # Modelo canônico das variáveis de ambiente
├── requirements.txt             # Dependências Python com versões fixadas
├── run.sh                       # Script de inicialização individual automatizada
└── README.md                    # Esta documentação
```

---

## 4. Variáveis de Ambiente (`.env`)

Crie seu arquivo local copiando o modelo padrão:
```bash
cp .env.example .env
```

| Variável | Valor Padrão / Exemplo | Descrição |
| :--- | :--- | :--- |
| `ENVIRONMENT` | `development` | Ambiente de execução (`development`, `production`) |
| `PORT` | `8000` | Porta local do servidor Uvicorn |
| `HOST` | `127.0.0.1` | Host de escuta local |
| `DATABASE_URL` | `postgresql+asyncpg://fecitel_user:fecitel_secret_2026@localhost:5432/fecitel_db` | String de conexão com PostgreSQL via asyncpg |
| `JWT_SECRET_KEY` | `chave_secreta_minimo_32_chars` | Chave de assinatura criptográfica para tokens JWT |
| `JWT_ALGORITHM` | `HS256` | Algoritmo de assinatura do token |
| `ACCESS_TOKEN_EXPIRE_HOURS`| `12` | Tempo de expiração do token de sessão |
| `API_KEY` | `fecitel_secret_api_key_2026` | Chave corporativa obrigatória para todas as rotas da API |
| `SMTP_HOST` | `smtp.gmail.com` | Host do servidor SMTP para envio de e-mails com códigos OTP |
| `SMTP_PORT` | `587` | Porta de conexão TLS do servidor de e-mail |
| `SMTP_USER` | `notificacoes@fecitel.ifms.edu.br` | Conta autenticada no servidor de e-mail |
| `SMTP_PASSWORD` | `senha_app_segura` | Senha ou token de app para SMTP |
| `UPLOAD_DIR` | `../../storage/uploads` | Diretório em disco para armazenamento de arquivos |
| `MAX_FILE_SIZE_MB` | `20` | Tamanho máximo permitido para uploads em streaming |

> [!IMPORTANT]
> **Proteção Obrigatória por API Key (Regra SEC-03):**  
> Todas as rotas sob `/api/v1/*` — **incluindo expressamente todas as consultas `GET` de leitura**, além de mutações `POST`, `PUT`, `DELETE` — são protegidas e exigem o cabeçalho HTTP:  
> `X-API-Key: fecitel_secret_api_key_2026`  
> Requisições que omitirem o cabeçalho ou fornecerem chave inválida receberão `HTTP 401 Unauthorized`. Para rotas autenticadas por perfil (Admin, Orientador, Avaliador, Aluno), o cabeçalho `Authorization: Bearer <token>` também deve ser fornecido cumulativamente (segurança em camadas).

---

## 5. Como Executar

### Opção A: Execução via Script Shell Automatizado (Recomendada)
O script `run.sh` detecta ou cria o ambiente virtual `.venv`, instala dependências ausentes e inicia o servidor com *hot-reload*:

```bash
chmod +x run.sh
./run.sh
```

### Opção B: Execução Manual
```bash
# 1. Ativar o ambiente virtual
python3 -m venv .venv
source .venv/bin/activate

# 2. Instalar dependências
pip install --upgrade pip
pip install -r requirements.txt

# 3. Executar o servidor Uvicorn
uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload
```

---

## 6. Endpoints Principais e Documentação Interativa

Com o servidor ativo na porta `8000`, a documentação interativa estará acessível em:
*   **Swagger UI:** [`http://localhost:8000/docs`](http://localhost:8000/docs)
*   **Redoc:** [`http://localhost:8000/redoc`](http://localhost:8000/redoc)

| Método | Rota | Descrição |
| :--- | :--- | :--- |
| `POST` | `/api/v1/auth/admin/login` | Autenticação de administradores com email e senha |
| `POST` | `/api/v1/auth/request-code` | Geração e envio por e-mail de código OTP de 8 caracteres |
| `POST` | `/api/v1/auth/verify-code` | Validação do código OTP mascarado e emissão de JWT |
| `GET/POST`| `/api/v1/events` | Gestão de edições do evento, paginação real e busca textual |
| `GET/POST`| `/api/v1/events/{id}/areas` | Gestão de áreas e subáreas com reativação de soft-delete |
| `GET/POST`| `/api/v1/events/{id}/awards` | Gestão de premiações e associação a critérios |
| `GET/POST`| `/api/v1/projects` | Listagem paginada (15/pág), filtros, busca e submissão |
| `POST` | `/api/v1/projects/{id}/consent` | Anuência digital formal do orientador titular (BR-05) |
| `PATCH`| `/api/v1/projects/{id}/homologate`| Homologação/indeferimento com justificativa (BR-06) |
| `PATCH`| `/api/v1/projects/{id}/booth` | Alocação ou remanejamento de bancada/estande (BR-08) |
| `POST` | `/api/v1/logistics/check-in` | Leitura de código de barras e baixa atômica de kits |
| `POST` | `/api/v1/allocations/auto` | Alocação automática balanceada pós-credenciamento |
| `GET` | `/api/v1/evaluations/my-projects`| Lista de projetos atribuídos ao avaliador autenticado |
| `POST` | `/api/v1/evaluations` | Envio de notas por critério com parecer consolidado único |
| `GET` | `/api/v1/dashboard/public-tv` | Dados públicos agregados para quiosque de TVs (sem notas) |

---

## 7. Execução de Testes Automatizados (Sem Mocks)

Os testes são executados diretamente contra o PostgreSQL local na porta 5432:

```bash
source .venv/bin/activate
pytest -v -s
```
