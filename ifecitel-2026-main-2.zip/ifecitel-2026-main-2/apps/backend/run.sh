#!/usr/bin/env bash
# ==============================================================================
# FECITEL Backend API — Script de Inicialização Individual
# ==============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "${SCRIPT_DIR}"

echo "============================================================"
echo "🚀 FECITEL — Inicializando Backend API (FastAPI)"
echo "============================================================"

# 1. Checagem de Python 3.11+
if ! command -v python3 &> /dev/null; then
    echo "❌ Erro: python3 não encontrado no PATH. Instale o Python 3.11 ou superior."
    exit 1
fi

PYTHON_VERSION=$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
echo "ℹ️  Python detectado: versão ${PYTHON_VERSION}"

# 2. Gerenciamento do Ambiente Virtual (.venv)
if [ ! -d ".venv" ]; then
    echo "📦 Criando ambiente virtual Python (.venv)..."
    python3 -m venv .venv
fi

# Ativação do ambiente virtual
# shellcheck source=/dev/null
source .venv/bin/activate

# 3. Verificação do arquivo .env
if [ ! -f ".env" ]; then
    echo "⚠️  Arquivo .env não encontrado. Copiando de .env.example..."
    cp .env.example .env
    echo "✅ Arquivo .env criado com sucesso."
fi

# 4. Instalação e atualização de dependências
echo "📥 Verificando dependências Python..."
pip install --upgrade pip --quiet
pip install -r requirements.txt --quiet

# 5. Execução do Servidor Uvicorn
PORT=${PORT:-8000}
HOST=${HOST:-127.0.0.1}

echo "🌐 Iniciando servidor FastAPI em http://${HOST}:${PORT}"
echo "📖 Swagger UI disponível em http://${HOST}:${PORT}/docs"
echo "🛑 Pressione Ctrl+C para encerrar o backend."
echo "============================================================"

# Se existir o app/main.py, inicia o uvicorn; caso contrário, aguarda scaffold
if [ -f "app/main.py" ]; then
    exec uvicorn app.main:app --host "${HOST}" --port "${PORT}" --reload
else
    echo "ℹ️  Scaffolding inicial: app/main.py será gerado na Fase 1."
    echo "✅ Ambiente virtual e dependências configurados com sucesso!"
fi
