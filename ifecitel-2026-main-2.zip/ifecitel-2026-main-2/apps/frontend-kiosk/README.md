# FECITEL — Módulo Telão TV Kiosk (Painel Público)

<p align="center">
  <img src="https://img.shields.io/badge/Next.js-14+-000000?style=for-the-badge&logo=nextdotjs&logoColor=white" alt="Next.js 14+" />
  <img src="https://img.shields.io/badge/React-18+-61DAFB?style=for-the-badge&logo=react&logoColor=black" alt="React 18+" />
  <img src="https://img.shields.io/badge/TypeScript-5+-3178C6?style=for-the-badge&logo=typescript&logoColor=white" alt="TypeScript 5+" />
  <img src="https://img.shields.io/badge/Tailwind_CSS-3.4+-06B6D4?style=for-the-badge&logo=tailwindcss&logoColor=white" alt="Tailwind CSS" />
  <img src="https://img.shields.io/badge/Display-4K_%2F_1080p-F59E0B?style=for-the-badge&logo=youtube&logoColor=white" alt="4K / 1080p Ultra-Wide" />
  <img src="https://img.shields.io/badge/Auto--Refresh-Silent%2030s-10B981?style=for-the-badge&logo=socketdotio&logoColor=white" alt="Auto Refresh" />
  <img src="https://img.shields.io/badge/Sigilo-Absoluto%20de%20Notas-E11D48?style=for-the-badge&logo=shield&logoColor=white" alt="Sigilo Absoluto" />
</p>

---

## 1. Visão Geral do Módulo

O **`apps/frontend-kiosk`** é a aplicação web especializada de exibição contínua para **Smart TVs, Telões de LED e Projetores** instalados nos corredores, auditórios e praça central da **FECITEL**.

Concebida para operação 100% autônoma e silenciosa em modo tela cheia (*Fullscreen Kiosk*), a aplicação exibe métricas institucionais em tempo real para participantes, orientadores e visitantes, respeitando rigorosamente a governança de **sigilo absoluto de notas individuais e ranqueamentos parciais**.

### Principais Responsabilidades:
*   **Sigilo Absoluto de Notas e Ranqueamentos:** É terminantemente proibido exibir notas, nomes de avaliadores, pareceres ou ranqueamento parcial no painel público.
*   **Métricas Agregadas e Institucionais Permitidas:**
    *   Total de projetos credenciados na bancada de apresentação.
    *   Contador consolidado de avaliações finalizadas por grande área do conhecimento.
    *   Total de participantes credenciados e escolas/instituições presentes.
    *   Quadro de avisos dinâmicos e cronograma geral da feira.
*   **Design para Longa Distância (TVs 1080p e 4K):** Tipografia ampla com escala rem otimizada, alto contraste, **Dark Mode nativo padrão** para evitar fadiga visual e layout *landscape* sem necessidade de rolagem vertical.
*   **Atualização Silenciosa em Background:** Sincronização automática a cada 30 segundos consumindo o endpoint público `/api/v1/dashboard/public-tv` sem piscar tela ou recarregar a página.

---

## 2. Tecnologias e Dependências Principais

| Tecnologia | Versão | Finalidade |
| :--- | :--- | :--- |
| **Next.js** | `14+ (App Router)` | Renderização de alto desempenho para dashboards autônomos contínuos |
| **React** | `18+` | Atualização reativa de contadores e cartões de estatísticas |
| **TypeScript** | `5+` | Tipagem estrita dos dados agregados recebidos da API pública |
| **Tailwind CSS** | `3.4+` | Grid CSS responsivo para telas Full HD (1080p) e Ultra HD (4K) |
| **SWR** | `2.2+` | Busca silenciosa periódica em background com auto-revalidação e cache |
| **Lucide React** | `0.350+` | Ícones de alta legibilidade para estatísticas da feira |

---

## 3. Arquitetura e Organização de Diretórios

```
apps/frontend-kiosk/
├── src/
│   ├── app/                     # Next.js App Router para Telões
│   │   ├── tv/                  # Rota pública principal do dashboard de telão
│   │   │   └── page.tsx         # Grid de estatísticas agregadas e avisos
│   │   ├── globals.css          # Estilização Kiosk Dark Mode (sem barras de rolagem)
│   │   └── layout.tsx           # Layout com metatags anti-sleep e tela cheia
│   ├── components/
│   │   ├── cards/               # Cartões de métricas (projetos, presenças, escolas)
│   │   ├── charts/              # Barras de progresso de avaliações por grande área
│   │   └── ticker/              # Faixa inferior de avisos e cronograma dinâmico
│   ├── hooks/
│   │   └── useKioskData.ts      # Hook com SWR configurado para polling a cada 30s
│   ├── services/                # Chamada HTTP para GET /api/v1/dashboard/public-tv
│   └── types/                   # Tipos de dados agregados públicos
├── public/                      # Brasões e logos institucionais de alta resolução
├── .env.example                 # Modelo de variáveis de ambiente do Kiosk
├── package.json                 # Dependências e scripts npm
├── tailwind.config.ts           # Cores do Dark Mode com contraste institucional
├── tsconfig.json                # Configurações TypeScript
└── README.md                    # Esta documentação
```

---

## 4. Variáveis de Ambiente (`.env.local`)

Copie o modelo para criar seu arquivo local:
```bash
cp .env.example .env.local
```

| Variável | Valor Padrão / Exemplo | Descrição |
| :--- | :--- | :--- |
| `NEXT_PUBLIC_API_URL` | `http://localhost:8000/api/v1` | URL base da API FastAPI central |
| `NEXT_PUBLIC_APP_NAME` | `FECITEL — Painel Público TV Kiosk` | Nome do sistema exibido na TV |
| `NEXT_PUBLIC_REFRESH_INTERVAL_MS`| `30000` | Intervalo de atualização silenciosa (30 segundos) |
| `PORT` | `3003` | Porta local de execução do servidor Next.js |

---

## 5. Como Executar

```bash
# 1. Instalar dependências
npm install

# 2. Iniciar em modo de desenvolvimento na porta 3003
npm run dev -- -p 3003
```

Para abrir o telão:
*   Acesse no navegador da Smart TV ou do computador conectado ao telão:  
    [`http://localhost:3003/tv`](http://localhost:3003/tv)
*   Pressione a tecla `F11` para ativar o modo de **Tela Cheia (Fullscreen)**.
