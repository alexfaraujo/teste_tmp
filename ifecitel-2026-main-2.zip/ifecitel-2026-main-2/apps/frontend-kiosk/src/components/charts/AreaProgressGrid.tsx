"use client";

import React from "react";
import { AreaEvaluationProgress } from "@/types";
import { Award, Compass, Dna, FlaskConical, Wrench } from "lucide-react";

interface AreaProgressGridProps {
  areas: AreaEvaluationProgress[];
}

export default function AreaProgressGrid({ areas }: AreaProgressGridProps) {
  // Ícones dinâmicos por palavra-chave da área
  const getAreaIcon = (name: string) => {
    const lower = name.toLowerCase();
    if (lower.includes("exatas") || lower.includes("terra")) {
      return <FlaskConical className="w-5 h-5 text-blue-400" />;
    }
    if (lower.includes("bio") || lower.includes("saúde") || lower.includes("saude")) {
      return <Dna className="w-5 h-5 text-teal-400" />;
    }
    if (lower.includes("humana") || lower.includes("social") || lower.includes("linguagem")) {
      return <Compass className="w-5 h-5 text-amber-400" />;
    }
    return <Wrench className="w-5 h-5 text-indigo-400" />;
  };

  return (
    <div className="p-6 rounded-3xl bg-slate-900/80 border border-slate-800 shadow-2xl space-y-5">
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <div className="flex items-center gap-2.5">
          <Award className="w-5 h-5 text-teal-400" />
          <h3 className="text-base font-black uppercase tracking-wider text-white">
            Andamento dos Estandes por Grande Área
          </h3>
        </div>

        <span className="text-xs font-medium text-slate-400">
          Progresso consolidado das avaliações presenciais (Sigilo Regra BR-14)
        </span>
      </div>

      {areas.length === 0 ? (
        <div className="p-8 text-center text-slate-500 text-sm">
          Nenhuma área temática registrada para esta edição.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-5">
          {areas.map((area) => {
            // Utiliza o progresso oficial calculado pelo backend com base na cota de avaliadores por projeto
            const expectedTotal =
              area.expected_evaluations && area.expected_evaluations > 0
                ? area.expected_evaluations
                : area.total_projects > 0
                ? area.total_projects * 3
                : 1;

            const percent =
              area.progress_percent !== undefined
                ? Math.round(area.progress_percent)
                : Math.min(100, Math.round((area.evaluations_completed / expectedTotal) * 100));

            const isDone = percent >= 100;
            const presentCount =
              area.present_projects !== undefined ? area.present_projects : 0;

            return (
              <div
                key={area.area_id}
                className="p-5 rounded-2xl bg-slate-950/70 border border-slate-800/90 flex flex-col justify-between space-y-3.5 shadow-lg hover:border-slate-700/80 transition-colors"
              >
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2.5 truncate">
                    <div className="w-10 h-10 rounded-xl bg-slate-800/90 border border-slate-700/50 flex items-center justify-center flex-shrink-0">
                      {getAreaIcon(area.area_name)}
                    </div>
                    <span className="font-bold text-sm text-slate-100 truncate" title={area.area_name}>
                      {area.area_name}
                    </span>
                  </div>

                  <span
                    className={`px-2.5 py-1 rounded-full text-xs font-mono font-bold tracking-wider ${
                      isDone
                        ? "bg-teal-500/20 text-teal-300 border border-teal-500/30"
                        : "bg-blue-500/20 text-blue-300 border border-blue-500/30"
                    }`}
                  >
                    {percent}%
                  </span>
                </div>

                {/* Barra de Progresso */}
                <div className="w-full h-3 rounded-full bg-slate-800/90 overflow-hidden shadow-inner border border-slate-700/30">
                  <div
                    className={`h-full rounded-full transition-all duration-1000 ${
                      isDone
                        ? "bg-gradient-to-r from-teal-500 to-emerald-400"
                        : "bg-gradient-to-r from-blue-600 via-teal-500 to-emerald-400"
                    }`}
                    style={{ width: `${percent}%` }}
                  />
                </div>

                {/* Opção 1C: Exibição de presentes e inscritos juntos + avaliações esperadas */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 text-xs text-slate-400 font-medium pt-1">
                  <div className="flex items-center gap-1.5">
                    <span className="inline-block w-1.5 h-1.5 rounded-full bg-teal-400" />
                    <span>
                      <strong className="text-white font-bold">{presentCount}</strong> presentes de{" "}
                      <strong className="text-slate-200 font-semibold">{area.total_projects}</strong> inscritos
                    </span>
                  </div>
                  <div className="font-mono text-slate-300">
                    <span className="text-teal-300 font-bold">{area.evaluations_completed}</span> de {expectedTotal} avaliações
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
