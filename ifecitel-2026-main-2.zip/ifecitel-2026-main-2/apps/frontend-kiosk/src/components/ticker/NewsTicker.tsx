"use client";

import React from "react";
import { Info, ShieldCheck } from "lucide-react";

interface NewsTickerProps {
  customMessage?: string;
}

export default function NewsTicker({ customMessage }: NewsTickerProps) {
  const message =
    customMessage ||
    "O painel exibido é apenas o resumo do evento para leitura pública. Para qualquer dúvida específica sobre o evento, procure um membro da comissão organizadora.";

  return (
    <footer className="w-full bg-slate-950 border-t border-slate-800/80 px-4 py-2.5 flex items-center justify-between gap-3 overflow-hidden select-none z-20">
      {/* Badge fixo do informativo */}
      <div className="flex-shrink-0 flex items-center gap-1.5 px-3 py-1 rounded-lg bg-teal-500/20 text-teal-300 border border-teal-500/30 text-xs font-black uppercase tracking-wider">
        <Info className="w-3.5 h-3.5 text-teal-400" />
        <span>Informativo</span>
      </div>

      {/* Frase Única para Leitura Pública */}
      <div className="flex-1 text-center px-2">
        <p className="text-xs md:text-sm text-slate-300 font-medium tracking-wide">
          {message}
        </p>
      </div>

      {/* Badge de Conformidade BR-14 */}
      <div className="hidden lg:flex flex-shrink-0 items-center gap-1.5 px-2.5 py-1 rounded-lg bg-blue-900/30 text-blue-300 text-[11px] font-bold border border-blue-800/40">
        <ShieldCheck className="w-3.5 h-3.5 text-blue-400" />
        <span>Dados Públicos Homologados</span>
      </div>
    </footer>
  );
}

