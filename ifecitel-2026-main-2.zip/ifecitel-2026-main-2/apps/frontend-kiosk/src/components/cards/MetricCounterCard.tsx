"use client";

import React from "react";

interface MetricCounterCardProps {
  title: string;
  value: number | string;
  subtext: string;
  icon: React.ReactNode;
  accentColor?: "blue" | "teal" | "amber" | "purple";
  badgeText?: string;
  percentage?: number;
}

export default function MetricCounterCard({
  title,
  value,
  subtext,
  icon,
  accentColor = "blue",
  badgeText,
  percentage,
}: MetricCounterCardProps) {
  const colorStyles = {
    blue: {
      bg: "from-blue-950/70 via-slate-900 to-slate-950",
      border: "border-blue-800/60",
      iconBg: "bg-blue-500/20 text-blue-300 border-blue-400/30",
      ringColor: "#38bdf8",
      ringGlow: "rgba(56, 189, 248, 0.4)",
      numberColor: "text-white",
      glow: "shadow-[0_0_35px_rgba(37,99,235,0.18)]",
    },
    teal: {
      bg: "from-teal-950/70 via-slate-900 to-slate-950",
      border: "border-teal-800/60",
      iconBg: "bg-teal-500/20 text-teal-300 border-teal-400/30",
      ringColor: "#2dd4bf",
      ringGlow: "rgba(45, 212, 191, 0.4)",
      numberColor: "text-teal-300",
      glow: "shadow-[0_0_35px_rgba(20,184,166,0.18)]",
    },
    amber: {
      bg: "from-amber-950/70 via-slate-900 to-slate-950",
      border: "border-amber-800/60",
      iconBg: "bg-amber-500/20 text-amber-300 border-amber-400/30",
      ringColor: "#fbbf24",
      ringGlow: "rgba(251, 191, 36, 0.4)",
      numberColor: "text-amber-300",
      glow: "shadow-[0_0_35px_rgba(245,158,11,0.18)]",
    },
    purple: {
      bg: "from-indigo-950/70 via-slate-900 to-slate-950",
      border: "border-indigo-800/60",
      iconBg: "bg-indigo-500/20 text-indigo-300 border-indigo-400/30",
      ringColor: "#a78bfa",
      ringGlow: "rgba(167, 139, 250, 0.4)",
      numberColor: "text-indigo-300",
      glow: "shadow-[0_0_35px_rgba(99,102,241,0.18)]",
    },
  };

  const style = colorStyles[accentColor];

  // Opção 4B Ampliada: Medidor Circular SVG de Alta Visibilidade para Telões (corpo do card)
  const radius = 35;
  const circumference = 2 * Math.PI * radius;
  const validPercentage =
    percentage !== undefined ? Math.min(100, Math.max(0, Math.round(percentage))) : undefined;
  const strokeDashoffset =
    validPercentage !== undefined
      ? circumference - (validPercentage / 100) * circumference
      : circumference;

  return (
    <div
      className={`relative p-5 sm:p-6 rounded-3xl bg-gradient-to-br ${style.bg} border ${style.border} ${style.glow} shadow-2xl flex flex-col justify-between transition-transform duration-300 hover:scale-[1.01]`}
    >
      {/* Cabeçalho do Card: Título nítido à esquerda e Ícone estilizado à direita */}
      <div className="flex items-center justify-between gap-3">
        <span className="text-xs sm:text-sm font-black uppercase tracking-wider text-slate-300 truncate">
          {title}
        </span>

        <div
          className={`w-10 h-10 rounded-xl border flex items-center justify-center flex-shrink-0 ${style.iconBg}`}
        >
          {icon}
        </div>
      </div>

      {/* Corpo do Card: Valor da Quantidade em Destaque ao lado do Medidor Circular Ampliado */}
      <div className="my-3 sm:my-4 flex items-center justify-between gap-3">
        <div className="min-w-0 flex-1">
          <span
            className={`font-mono font-black text-5xl sm:text-6xl tracking-tight leading-none ${style.numberColor}`}
          >
            {value}
          </span>
        </div>

        {validPercentage !== undefined && (
          <div className="relative w-20 h-20 sm:w-22 sm:h-22 xl:w-24 xl:h-24 flex items-center justify-center flex-shrink-0">
            <svg className="w-full h-full -rotate-90 transform" viewBox="0 0 88 88">
              {/* Trilha de fundo translúcida */}
              <circle
                cx="44"
                cy="44"
                r={radius}
                className="text-white/10"
                stroke="currentColor"
                strokeWidth="6"
                fill="transparent"
              />
              {/* Anel de progresso preenchido proporcionalmente com brilho */}
              <circle
                cx="44"
                cy="44"
                r={radius}
                stroke={style.ringColor}
                strokeWidth="6.5"
                strokeDasharray={circumference}
                strokeDashoffset={strokeDashoffset}
                strokeLinecap="round"
                fill="transparent"
                style={{ filter: `drop-shadow(0 0 6px ${style.ringGlow})` }}
                className="transition-all duration-1000 ease-out"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
              <span className="font-mono text-sm sm:text-base xl:text-lg font-black text-white tracking-tight">
                {validPercentage}%
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Rodapé do Card: Subtexto informativo e Selo de status */}
      <div className="flex items-center justify-between text-xs sm:text-sm pt-3 border-t border-white/10 gap-2">
        <span className="text-slate-300 font-medium truncate">{subtext}</span>
        {badgeText && (
          <span className="px-2 py-0.5 rounded-md font-bold text-[10px] sm:text-xs uppercase tracking-wider bg-white/10 text-white border border-white/15 flex-shrink-0">
            {badgeText}
          </span>
        )}
      </div>
    </div>
  );
}
