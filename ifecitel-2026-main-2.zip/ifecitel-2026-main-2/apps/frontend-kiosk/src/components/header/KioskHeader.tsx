"use client";

import React, { useEffect, useState } from "react";
import { Award, Clock, Maximize2, Minimize2, Radio, Sparkles } from "lucide-react";
import { useFullscreen } from "@/hooks/useFullscreen";

interface KioskHeaderProps {
  eventName: string;
  isUpdating?: boolean;
}

export default function KioskHeader({
  eventName,
  isUpdating = false,
}: KioskHeaderProps) {
  const { isFullscreen, toggleFullscreen } = useFullscreen();
  const [timeStr, setTimeStr] = useState<string>("");
  const [dateStr, setDateStr] = useState<string>("");

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeStr(
        now.toLocaleTimeString("pt-BR", {
          hour: "2-digit",
          minute: "2-digit",
          second: "2-digit",
        })
      );
      setDateStr(
        now.toLocaleDateString("pt-BR", {
          weekday: "long",
          day: "2-digit",
          month: "long",
          year: "numeric",
        })
      );
    };

    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <header className="px-6 py-4 bg-gradient-to-r from-slate-900 via-blue-950 to-slate-900 border-b border-blue-900/60 shadow-xl flex items-center justify-between select-none">
      {/* Lado Esquerdo: Identidade Visual Institucional */}
      <div className="flex items-center gap-4">
        <div className="w-12 h-12 rounded-2xl bg-teal-500/20 border border-teal-400/40 flex items-center justify-center text-teal-300 shadow-inner">
          <Award className="w-7 h-7" />
        </div>

        <div>
          <div className="flex items-center gap-2">
            <span className="font-black text-2xl text-white tracking-tight">
              EasyEvent
            </span>
            <span className="px-2 py-0.5 rounded-md text-[10px] font-black uppercase tracking-wider bg-teal-500/20 text-teal-300 border border-teal-400/30">
              TELÃO TV
            </span>
          </div>
          <p className="text-xs text-blue-200/90 font-medium">
            Painel Oficial de Acompanhamento
          </p>
        </div>
      </div>

      {/* Centro: Edição do Evento e Status Ao Vivo */}
      <div className="text-center hidden md:flex flex-col items-center">
        <div className="flex items-center gap-2">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider bg-red-500/20 text-red-400 border border-red-500/30">
            <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
            <Radio className="w-3.5 h-3.5" />
            <span>AO VIVO</span>
          </span>
          {isUpdating && (
            <span className="text-[11px] text-teal-400 animate-pulse font-bold">
              Atualizando dados...
            </span>
          )}
        </div>
        <h2 className="text-base font-black text-white mt-1 tracking-wide">
          {eventName || "Painel de Acompanhamento do Evento"}
        </h2>
      </div>

      {/* Lado Direito: Relógio Oficial de Precisão & Fullscreen */}
      <div className="flex items-center gap-4">
        <div className="text-right">
          <div className="font-mono text-2xl font-black text-teal-300 tracking-wider flex items-center justify-end gap-1.5 leading-none">
            <Clock className="w-5 h-5 text-teal-400" />
            <span>{timeStr || "--:--:--"}</span>
          </div>
          <p className="text-[11px] text-blue-200/80 capitalize mt-1">
            {dateStr}
          </p>
        </div>

        <button
          type="button"
          onClick={toggleFullscreen}
          className="p-2.5 rounded-xl bg-white/10 hover:bg-white/20 active:scale-95 text-blue-200 hover:text-white transition-all shadow-sm"
          title={isFullscreen ? "Sair da Tela Cheia" : "Modo Tela Cheia (Kiosk)"}
        >
          {isFullscreen ? (
            <Minimize2 className="w-5 h-5" />
          ) : (
            <Maximize2 className="w-5 h-5" />
          )}
        </button>
      </div>
    </header>
  );
}
