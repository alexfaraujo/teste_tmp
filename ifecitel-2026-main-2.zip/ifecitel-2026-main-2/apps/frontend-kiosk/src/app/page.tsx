"use client";

import { Suspense, useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import {
  AlertTriangle,
  Presentation,
  RefreshCw,
  TrendingUp,
  UserCheck,
  Users,
} from "lucide-react";
import { useKioskData } from "@/hooks/useKioskData";
import { getActiveEvent } from "@/services/kiosk.service";
import { EventItem } from "@/types";
import KioskHeader from "@/components/header/KioskHeader";
import MetricCounterCard from "@/components/cards/MetricCounterCard";
import AreaProgressGrid from "@/components/charts/AreaProgressGrid";
import NewsTicker from "@/components/ticker/NewsTicker";

function KioskDashboardContent() {
  const searchParams = useSearchParams();
  const paramEventId = searchParams.get("event_id") || searchParams.get("eventId");

  const [activeEventId, setActiveEventId] = useState<number | undefined>(
    paramEventId ? parseInt(paramEventId, 10) : undefined
  );

  // Se não foi passado event_id via URL, busca o evento ativo do backend
  useEffect(() => {
    if (activeEventId) return;

    let isMounted = true;
    getActiveEvent()
      .then((active: EventItem | null) => {
        if (isMounted && active) {
          setActiveEventId(active.id);
        }
      })
      .catch((err: unknown) => {
        console.error("Erro ao carregar evento ativo:", err);
      });

    return () => {
      isMounted = false;
    };
  }, [activeEventId]);

  const { data, isLoading, isUpdating, error, refresh } = useKioskData(activeEventId);

  // Estado de Carregamento Inicial
  if (isLoading && !data) {
    return (
      <div className="min-h-screen bg-slate-950 text-white flex flex-col justify-between">
        <KioskHeader eventName="EasyEvent — Carregando..." isUpdating={true} />
        <main className="flex-1 max-w-7xl w-full mx-auto p-6 flex flex-col justify-center items-center gap-6">
          <div className="w-16 h-16 rounded-full border-4 border-teal-500/20 border-t-teal-400 animate-spin" />
          <p className="text-slate-400 font-medium animate-pulse text-lg">
            Sincronizando dados com a central do EasyEvent...
          </p>
        </main>
        <NewsTicker />
      </div>
    );
  }

  // Estado de Erro de Conexão
  if (error && !data) {
    return (
      <div className="min-h-screen bg-slate-950 text-white flex flex-col justify-between">
        <KioskHeader eventName="EasyEvent" />
        <main className="flex-1 max-w-3xl w-full mx-auto p-6 flex flex-col justify-center items-center text-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-red-500/20 text-red-400 border border-red-500/30 flex items-center justify-center">
            <AlertTriangle className="w-8 h-8" />
          </div>
          <h2 className="text-2xl font-black">Falha na Conexão com o Servidor</h2>
          <p className="text-slate-400 text-sm max-w-md">
            Não foi possível carregar as métricas públicas do evento. Verifique se o backend está
            em execução e tente novamente.
          </p>
          <button
            type="button"
            onClick={() => refresh()}
            className="mt-2 inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-500 active:scale-95 text-white font-bold transition-all shadow-lg shadow-teal-900/40"
          >
            <RefreshCw className="w-4 h-4" />
            <span>Tentar Novamente</span>
          </button>
        </main>
        <NewsTicker />
      </div>
    );
  }

  const kioskData = data || {
    event_id: activeEventId || 1,
    event_name: "Painel de Acompanhamento do Evento",
    total_registered_participants: 0,
    total_present_participants: 0,
    total_registered_students_advisors: 0,
    total_present_students_advisors: 0,
    total_registered_evaluators: 0,
    total_present_evaluators: 0,
    total_registered_projects: 0,
    total_present_projects: 0,
    total_evaluations_completed: 0,
    areas_progress: [],
    updated_at: new Date().toISOString(),
  };

  // Progresso consolidado oficial calculado pelo backend com base no min_evaluators do evento
  const progressPercent =
    kioskData.evaluation_progress_percent !== undefined
      ? Math.round(kioskData.evaluation_progress_percent)
      : (() => {
          const baseProjects =
            kioskData.total_present_projects > 0
              ? kioskData.total_present_projects
              : kioskData.total_registered_projects;
          const expectedTotal =
            kioskData.total_expected_evaluations || (baseProjects > 0 ? baseProjects * 3 : 1);
          return Math.min(
            100,
            Math.round((kioskData.total_evaluations_completed / expectedTotal) * 100)
          );
        })();

  // Cálculos de percentuais para os medidores circulares dos cards de topo (Opção 4B)
  const presentProjects = kioskData.total_present_projects;
  const registeredProjects = kioskData.total_registered_projects;
  const projectsPercent =
    registeredProjects > 0 ? (presentProjects / registeredProjects) * 100 : 0;

  const presentStudentsAdvisors =
    kioskData.total_present_students_advisors ?? kioskData.total_present_participants;
  const registeredStudentsAdvisors =
    kioskData.total_registered_students_advisors ?? kioskData.total_registered_participants;
  const participantsPercent =
    registeredStudentsAdvisors > 0
      ? (presentStudentsAdvisors / registeredStudentsAdvisors) * 100
      : 0;

  const presentEvaluators = kioskData.total_present_evaluators ?? 0;
  const registeredEvaluators = kioskData.total_registered_evaluators ?? 0;
  const evaluatorsPercent =
    registeredEvaluators > 0 ? (presentEvaluators / registeredEvaluators) * 100 : 0;

  return (
    <div className="min-h-screen bg-slate-950 text-white flex flex-col justify-between overflow-x-hidden">
      {/* Cabeçalho Oficial do Kiosk com Relógio e Status Ao Vivo */}
      <KioskHeader
        eventName={kioskData.event_name}
        isUpdating={isUpdating}
      />

      {/* Conteúdo Principal do Telão */}
      <main className="flex-1 max-w-[1700px] w-full mx-auto px-6 py-6 space-y-6 flex flex-col justify-center">
        {/* Linha de Cartões Métricos Principais (4 Colunas - Opção 4B) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          {/* Card 1: Projetos em Estande */}
          <MetricCounterCard
            title="Projetos em Estande"
            value={presentProjects}
            subtext={`de ${registeredProjects} inscritos`}
            percentage={projectsPercent}
            icon={<Presentation className="w-5 h-5" />}
            accentColor="blue"
            badgeText="Em Estande"
          />

          {/* Card 2: Participantes Presentes (Estudantes, Orientadores e Coorientadores) */}
          <MetricCounterCard
            title="Participantes Presentes"
            value={presentStudentsAdvisors}
            subtext={`de ${registeredStudentsAdvisors} alunos e orientadores`}
            percentage={participantsPercent}
            icon={<Users className="w-5 h-5" />}
            accentColor="teal"
            badgeText="Alunos & Orientadores"
          />

          {/* Card 3: Avaliadores Presentes (Substitui Pareceres Homologados) */}
          <MetricCounterCard
            title="Avaliadores Presentes"
            value={presentEvaluators}
            subtext={`de ${registeredEvaluators} credenciados`}
            percentage={evaluatorsPercent}
            icon={<UserCheck className="w-5 h-5" />}
            accentColor="amber"
            badgeText="Corpo de Avaliadores"
          />

          {/* Card 4: Progresso Consolidado da Feira */}
          <MetricCounterCard
            title="Progresso da Feira"
            value={`${progressPercent}%`}
            subtext={
              kioskData.total_expected_evaluations
                ? `${kioskData.total_evaluations_completed} de ${kioskData.total_expected_evaluations} avaliações esperadas`
                : "Percentual consolidado"
            }
            percentage={progressPercent}
            icon={<TrendingUp className="w-5 h-5" />}
            accentColor="purple"
            badgeText="Geral"
          />
        </div>

        {/* Seção Principal: Andamento por Área Expandido para Largura Total (100%) */}
        <div className="w-full">
          <AreaProgressGrid areas={kioskData.areas_progress || []} />
        </div>
      </main>

      {/* Ticker / Letreiro Digital na Base da Tela */}
      <NewsTicker />
    </div>
  );
}

export default function KioskDashboardPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen bg-slate-950 text-white flex flex-col justify-between">
          <KioskHeader eventName="EasyEvent — Carregando..." isUpdating={true} />
          <main className="flex-1 flex justify-center items-center">
            <div className="w-12 h-12 rounded-full border-4 border-teal-500/20 border-t-teal-400 animate-spin" />
          </main>
          <NewsTicker />
        </div>
      }
    >
      <KioskDashboardContent />
    </Suspense>
  );
}
