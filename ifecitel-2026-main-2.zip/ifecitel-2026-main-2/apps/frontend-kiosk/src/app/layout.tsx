import type { Metadata, Viewport } from "next";
import "./globals.css";

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  themeColor: "#0b1120",
};

export const metadata: Metadata = {
  title: "EasyEvent — Telão TV Kiosk",
  description: "Painel de Acompanhamento ao Vivo das Avaliações e Métricas do Evento",
  icons: {
    icon: "/favicon.ico",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR" className="dark h-full">
      <body className="h-full bg-slate-950 text-slate-100 antialiased font-sans flex flex-col justify-between overflow-x-hidden select-none">
        {children}
      </body>
    </html>
  );
}
