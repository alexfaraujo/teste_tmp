"use client";

import useSWR from "swr";
import kioskService from "@/services/kiosk.service";
import { PublicTvDashboardResponse } from "@/types";

const REFRESH_INTERVAL =
  Number(process.env.NEXT_PUBLIC_REFRESH_INTERVAL_MS) || 30000;

export function useKioskData(eventId?: number | null) {
  const { data, error, isLoading, isValidating, mutate } = useSWR<PublicTvDashboardResponse>(
    eventId ? ["public-tv-metrics", eventId] : null,
    () => (eventId ? kioskService.getPublicTvMetrics(eventId) : Promise.reject("Sem evento")),
    {
      refreshInterval: REFRESH_INTERVAL,
      revalidateOnFocus: true,
      revalidateOnReconnect: true,
      dedupingInterval: 5000,
      keepPreviousData: true, // Mantém a tela sem piscar durante a revalidação
      isPaused: () => typeof document !== "undefined" && document.hidden,
    }
  );

  return {
    data,
    error,
    isLoading: isLoading && !data,
    isUpdating: isValidating,
    refresh: mutate,
  };
}
