import { EventItem, PublicTvDashboardResponse } from "@/types";

const API_BASE_URL =
  process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000/api/v1";
const API_KEY =
  process.env.NEXT_PUBLIC_API_KEY || "fecitel_secret_api_key_2026";

class KioskService {
  private getHeaders(): HeadersInit {
    return {
      "Content-Type": "application/json",
      "X-API-Key": API_KEY,
    };
  }

  public async getPublicTvMetrics(
    eventId: number
  ): Promise<PublicTvDashboardResponse> {
    const res = await fetch(
      `${API_BASE_URL}/dashboard/public-tv?event_id=${eventId}`,
      {
        headers: this.getHeaders(),
        cache: "no-store",
      }
    );

    if (!res.ok) {
      const errorData = await res.json().catch(() => ({}));
      throw new Error(
        errorData.detail || `Erro ao carregar métricas do telão: HTTP ${res.status}`
      );
    }

    return res.json();
  }

  public async listEvents(): Promise<EventItem[]> {
    const res = await fetch(`${API_BASE_URL}/events`, {
      headers: this.getHeaders(),
      cache: "no-store",
    });

    if (!res.ok) {
      throw new Error(`Erro ao listar eventos: HTTP ${res.status}`);
    }

    const data = await res.json();
    return Array.isArray(data) ? data : data.items || [];
  }

  public async getActiveEvent(): Promise<EventItem | null> {
    try {
      const events = await this.listEvents();
      if (events.length === 0) return null;
      // Retorna o primeiro ativo ou o mais recente por ano
      const active = events.find((e) => e.is_active);
      return active || events[0];
    } catch (err) {
      console.warn("Falha ao buscar evento ativo:", err);
      return null;
    }
  }
}

const kioskService = new KioskService();

export const getPublicTvMetrics = (eventId: number) =>
  kioskService.getPublicTvMetrics(eventId);
export const listEvents = () => kioskService.listEvents();
export const getActiveEvent = () => kioskService.getActiveEvent();

export { kioskService };
export default kioskService;
