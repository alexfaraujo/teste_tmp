export interface AreaEvaluationProgress {
  area_id: number;
  area_name: string;
  total_projects: number;
  present_projects?: number;
  evaluations_completed: number;
  expected_evaluations?: number;
  progress_percent?: number;
}

export interface PublicTvDashboardResponse {
  event_id: number;
  event_name: string;
  total_registered_participants: number;
  total_present_participants: number;
  total_registered_students_advisors?: number;
  total_present_students_advisors?: number;
  total_registered_evaluators?: number;
  total_present_evaluators?: number;
  total_registered_projects: number;
  total_present_projects: number;
  total_evaluations_completed: number;
  areas_progress: AreaEvaluationProgress[];
  updated_at: string;
  min_evaluators_default?: number;
  total_expected_evaluations?: number;
  evaluation_progress_percent?: number;
}

export interface EventItem {
  id: number;
  name: string;
  edition_year: number;
  description?: string | null;
  location?: string | null;
  is_active: boolean;
}
