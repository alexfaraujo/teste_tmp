"use client";

import React, { createContext, useContext, useEffect, useState } from "react";
import { UserProfile } from "@/types";
import authService, { RequestCodeResponse } from "@/services/auth.service";

interface AuthContextType {
  user: UserProfile | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  loginWithCode: (email: string, code: string) => Promise<void>;
  requestCode: (email: string) => Promise<RequestCodeResponse>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    try {
      const storedToken =
        localStorage.getItem("easyevent_evaluator_token") ||
        localStorage.getItem("fecitel_evaluator_token");
      const storedUser =
        localStorage.getItem("easyevent_evaluator_user") ||
        localStorage.getItem("fecitel_evaluator_user");

      if (storedToken && storedUser) {
        setToken(storedToken);
        setUser(JSON.parse(storedUser));
      }
    } catch (e) {
      console.error("Erro ao carregar sessão local:", e);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const requestCode = async (email: string): Promise<RequestCodeResponse> => {
    return await authService.requestCode(email);
  };

  const loginWithCode = async (email: string, code: string): Promise<void> => {
    const res = await authService.verifyCode(email, code);
    setToken(res.access_token);
    setUser({
      id: res.id,
      name: res.name,
      email: res.email,
      role: res.role,
      barcode: res.barcode,
    });
  };

  const logout = () => {
    authService.logout();
    setToken(null);
    setUser(null);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        isAuthenticated: !!token && !!user,
        isLoading,
        loginWithCode,
        requestCode,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth(): AuthContextType {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth deve ser utilizado dentro de um AuthProvider");
  }
  return context;
}
