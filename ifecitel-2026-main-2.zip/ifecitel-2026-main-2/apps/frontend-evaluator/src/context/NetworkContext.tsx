"use client";

import React, { createContext, useContext, useEffect, useState, useCallback } from "react";
import offlineQueueService from "@/services/offlineQueue.service";
import { EvaluationCreatePayload, QueuedEvaluation } from "@/types";

interface NetworkContextType {
  isOnline: boolean;
  queue: QueuedEvaluation[];
  pendingCount: number;
  isSyncing: boolean;
  lastSyncTime: Date | null;
  syncNotification: string | null;
  clearNotification: () => void;
  syncNow: () => Promise<{ total: number; synced: number; failed: number }>;
  enqueueEvaluation: (
    projectId: number,
    payload: EvaluationCreatePayload,
    projectTitle: string,
    boothNumber?: string | null
  ) => QueuedEvaluation;
  isProjectInQueue: (projectId: number) => boolean;
  getQueuedForProject: (projectId: number) => QueuedEvaluation | undefined;
}

const NetworkContext = createContext<NetworkContextType | undefined>(undefined);

export function NetworkProvider({ children }: { children: React.ReactNode }) {
  const [isOnline, setIsOnline] = useState<boolean>(true);
  const [queue, setQueue] = useState<QueuedEvaluation[]>([]);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [lastSyncTime, setLastSyncTime] = useState<Date | null>(null);
  const [syncNotification, setSyncNotification] = useState<string | null>(null);

  const refreshQueue = useCallback(() => {
    const currentQueue = offlineQueueService.getQueue();
    setQueue(currentQueue);
  }, []);

  const syncNow = useCallback(async () => {
    if (isSyncing) return { total: 0, synced: 0, failed: 0 };
    setIsSyncing(true);
    try {
      const result = await offlineQueueService.syncQueue();
      refreshQueue();
      if (result.synced > 0) {
        setLastSyncTime(new Date());
        const msg =
          result.synced === 1
            ? "1 avaliação salva localmente foi sincronizada com sucesso!"
            : `${result.synced} avaliações salvas localmente foram sincronizadas com sucesso!`;
        setSyncNotification(msg);
        setTimeout(() => setSyncNotification(null), 6000);
      }
      return result;
    } finally {
      setIsSyncing(false);
    }
  }, [isSyncing, refreshQueue]);

  useEffect(() => {
    if (typeof window === "undefined") return;

    // Inicializar estado de conectividade e fila
    setIsOnline(navigator.onLine);
    refreshQueue();

    const handleOnline = () => {
      setIsOnline(true);
      // Ao voltar a ter conexão, tentar sincronizar imediatamente qualquer avaliação pendente
      syncNow();
    };

    const handleOffline = () => {
      setIsOnline(false);
    };

    const handleQueueUpdated = () => {
      refreshQueue();
    };

    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);
    window.addEventListener("easyevent:queue-updated", handleQueueUpdated);
    window.addEventListener("fecitel:queue-updated", handleQueueUpdated);

    // Se já estiver online ao inicializar e houver itens na fila, sincronizar
    const initialQueue = offlineQueueService.getQueue();
    if (navigator.onLine && initialQueue.length > 0) {
      syncNow();
    }

    return () => {
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
      window.removeEventListener("easyevent:queue-updated", handleQueueUpdated);
      window.removeEventListener("fecitel:queue-updated", handleQueueUpdated);
    };
  }, [refreshQueue, syncNow]);

  const enqueueEvaluation = (
    projectId: number,
    payload: EvaluationCreatePayload,
    projectTitle: string,
    boothNumber?: string | null
  ) => {
    const item = offlineQueueService.enqueue({
      projectId,
      projectTitle,
      boothNumber,
      payload,
    });
    refreshQueue();
    return item;
  };

  const isProjectInQueue = (projectId: number) => {
    return queue.some((q) => q.projectId === projectId);
  };

  const getQueuedForProject = (projectId: number) => {
    return queue.find((q) => q.projectId === projectId);
  };

  const clearNotification = () => setSyncNotification(null);

  return (
    <NetworkContext.Provider
      value={{
        isOnline,
        queue,
        pendingCount: queue.length,
        isSyncing,
        lastSyncTime,
        syncNotification,
        clearNotification,
        syncNow,
        enqueueEvaluation,
        isProjectInQueue,
        getQueuedForProject,
      }}
    >
      {children}
    </NetworkContext.Provider>
  );
}

export function useNetwork() {
  const context = useContext(NetworkContext);
  if (!context) {
    throw new Error("useNetwork deve ser utilizado dentro de um NetworkProvider");
  }
  return context;
}
