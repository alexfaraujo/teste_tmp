export type UserRole = "ADMIN" | "STUDENT" | "ADVISOR" | "COADVISOR" | "EVALUATOR";

export type ProjectType = "SCIENTIFIC" | "TECHNOLOGICAL";

export type AllocationStatus = "PENDING" | "COMPLETED" | "CANCELLED";

export type EvaluationStatus = "DRAFT" | "COMPLETED";

export interface UserProfile {
  id: number;
  name: string;
  email: string;
  role: string;
  barcode?: string | null;
}

export interface TokenResponse {
  access_token: string;
  token_type: string;
  expires_in_hours: number;
  id: number;
  name: string;
  email: string;
  role: string;
  barcode?: string | null;
}

export interface AllocationItem {
  id: number;
  event_id: number;
  project_id: number;
  project_title: string;
  booth_number?: string | null;
  subarea_name: string;
  area_name?: string | null;
  evaluator_id: number;
  evaluator_name: string;
  allocation_type: string;
  status: AllocationStatus;
  allocated_at: string;
  qrcode_token?: string | null;
}

export interface EvaluationCriterionSheetItem {
  criterion_id: number;
  name: string;
  description: string;
  max_score: number;
  weight: number;
  current_score?: number | null;
}

export interface EvaluationSheetResponse {
  project_id: number;
  title: string;
  abstract?: string | null;
  project_type: ProjectType;
  booth_number?: string | null;
  subarea_name: string;
  area_name?: string | null;
  education_level?: string | null;
  school_name?: string | null;
  authors: string[];
  advisor_name?: string | null;
  coadvisor_name?: string | null;
  qrcode_token?: string | null;
  criteria: EvaluationCriterionSheetItem[];
  current_feedback?: string | null;
}

export interface EvaluationItemInput {
  criterion_id: number;
  score: number;
}

export interface EvaluationCreatePayload {
  project_id: number;
  general_feedback?: string | null;
  items: EvaluationItemInput[];
  status?: EvaluationStatus;
}

export interface EvaluationItemResponse {
  id: number;
  criterion_id: number;
  criterion_name: string;
  score: number;
}

export interface EvaluationResponse {
  id: number;
  project_id: number;
  evaluator_id: number;
  evaluator_name: string;
  status: EvaluationStatus;
  general_feedback?: string | null;
  evaluated_at?: string | null;
  final_score: number;
  items: EvaluationItemResponse[];
}

export interface QueuedEvaluation {
  id: string;
  projectId: number;
  projectTitle: string;
  boothNumber?: string | null;
  payload: EvaluationCreatePayload;
  createdAt: string;
  attempts: number;
  lastError?: string | null;
}

