"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/context/AuthContext";

export default function RootPage() {
  const router = useRouter();
  const { isAuthenticated, isLoading } = useAuth();

  useEffect(() => {
    if (!isLoading) {
      if (isAuthenticated) {
        router.replace("/projects");
      } else {
        router.replace("/login");
      }
    }
  }, [isAuthenticated, isLoading, router]);

  return (
    <div className="flex-1 flex flex-col items-center justify-center p-6 text-slate-500">
      <div className="w-8 h-8 border-4 border-fecitel-blue-600 border-t-transparent rounded-full animate-spin mb-4" />
      <p className="text-sm font-medium">Carregando EasyEvent Avaliação...</p>
    </div>
  );
}
