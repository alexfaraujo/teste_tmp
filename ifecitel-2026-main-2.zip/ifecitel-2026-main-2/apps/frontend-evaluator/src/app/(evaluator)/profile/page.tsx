"use client";

import React, { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import {
  Award,
  BarChart2,
  CheckCircle2,
  Clock,
  ExternalLink,
  GraduationCap,
  Mail,
  QrCode,
  ShieldCheck,
  Sparkles,
  User,
  Zap,
  Smartphone,
  Wifi,
  WifiOff,
  CloudUpload,
  RefreshCw,
} from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { useNetwork } from "@/context/NetworkContext";
import evaluatorService from "@/services/evaluator.service";
import QRCodeView from "@/components/badge/QRCodeView";
import { AllocationItem } from "@/types";

export default function ProfilePage() {
  const { user } = useAuth();
  const {
    isOnline,
    pendingCount: offlinePendingCount,
    isSyncing,
    syncNow,
    lastSyncTime,
  } = useNetwork();
  const router = useRouter();

  const [allocations, setAllocations] = useState<AllocationItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    async function loadStats() {
      try {
        const data = await evaluatorService.getMyAllocations();
        setAllocations(data);
      } catch (err) {
        console.warn("Falha ao carregar estatísticas do avaliador:", err);
      } finally {
        setIsLoading(false);
      }
    }

    loadStats();
  }, []);

  const totalCount = allocations.length;
  const completedCount = allocations.filter((a) => a.status === "COMPLETED").length;
  const pendingCount = allocations.filter((a) => a.status === "PENDING").length;
  const progressPercent = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

  // Iniciais para o avatar
  const getInitials = (name?: string) => {
    if (!name) return "AV";
    const parts = name.trim().split(" ");
    if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
  };

  return (
    <div className="p-4 space-y-5 pb-8 animate-in fade-in duration-200">
      {/* Título da Seção */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-black text-slate-900 dark:text-white flex items-center gap-2">
            <span>Meu Crachá Digital</span>
            <span className="inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-bold bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300 border border-teal-200 dark:border-teal-800">
              OFICIAL
            </span>
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Credencial e resumo de avaliações no EasyEvent
          </p>
        </div>
      </div>

      {/* CRACHÁ DIGITAL OFICIAL DO AVALIADOR */}
      <div className="relative rounded-3xl bg-gradient-to-b from-fecitel-blue-900 via-blue-950 to-slate-900 text-white p-5 shadow-2xl border border-blue-800/60 overflow-hidden">
        {/* Orifício estético de cordão do crachá */}
        <div className="w-14 h-2.5 rounded-full bg-black/40 border border-white/20 mx-auto mb-3 shadow-inner" />

        {/* Linha Superior da Instituição */}
        <div className="flex items-center justify-between border-b border-white/10 pb-3 mb-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-teal-400/20 border border-teal-400/40 flex items-center justify-center text-teal-300">
              <Award className="w-4 h-4" />
            </div>
            <div>
              <span className="font-black text-xs tracking-wider">EasyEvent</span>
              <p className="text-[9px] text-blue-200 font-medium">Plataforma de Avaliação</p>
            </div>
          </div>

          <span className="px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-teal-500/20 text-teal-300 border border-teal-400/30">
            Avaliador
          </span>
        </div>

        {/* Identificação da Pessoa */}
        <div className="flex items-center gap-3.5 mb-4">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-teal-400 to-teal-600 text-fecitel-blue-950 font-black text-lg flex items-center justify-center shadow-lg flex-shrink-0 border-2 border-white/20">
            {getInitials(user?.name)}
          </div>

          <div className="truncate">
            <h2 className="text-base font-black text-white leading-tight truncate">
              {user?.name || "Avaliador(a) Convidado(a)"}
            </h2>
            <div className="flex items-center gap-1.5 text-xs text-blue-200 mt-0.5 truncate">
              <Mail className="w-3 h-3 flex-shrink-0 text-teal-400" />
              <span className="truncate">{user?.email || "avaliador@fecitel.ifms.edu.br"}</span>
            </div>
            <p className="text-[10px] uppercase font-bold text-teal-300 tracking-wider mt-1">
              Comissão Científica de Avaliação
            </p>
          </div>
        </div>

        {/* QR Code Escaneável para Portaria / Credenciamento / Sala dos Avaliadores */}
        <div className="flex justify-center my-3">
          <QRCodeView
            value={user?.barcode || `BC-EVAL-${user?.id || "00"}`}
            className="w-full max-w-[240px]"
          />
        </div>

        {/* Orientação ao Avaliador */}
        <p className="text-[10px] text-center text-blue-200/80 leading-relaxed mt-2 font-medium">
          Apresente este QR Code no leitor da Sala dos Avaliadores ou na Recepção para confirmação de presença e conferência.
        </p>
      </div>

      {/* QUADRO DE PRODUTIVIDADE E AVALIAÇÕES */}
      <div className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <BarChart2 className="w-4 h-4 text-fecitel-blue-600 dark:text-blue-400" />
            <h3 className="text-xs font-black uppercase tracking-wider text-slate-800 dark:text-slate-200">
              Minhas Avaliações Alocadas
            </h3>
          </div>

          <span className="text-xs font-mono font-bold text-fecitel-blue-900 dark:text-blue-400">
            {completedCount} de {totalCount} ({progressPercent}%)
          </span>
        </div>

        {/* Barra de Progresso Geral */}
        <div className="w-full h-2 rounded-full bg-slate-100 dark:bg-slate-700 overflow-hidden">
          <div
            className="h-full bg-teal-500 rounded-full transition-all duration-500"
            style={{ width: `${progressPercent}%` }}
          />
        </div>

        {/* Contadores em Grid de 3 Colunas */}
        <div className="grid grid-cols-3 gap-2 pt-1 text-center">
          <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-700">
            <span className="text-[10px] uppercase font-bold text-slate-400 block">Total</span>
            <span className="font-mono text-xl font-black text-slate-800 dark:text-slate-200">
              {isLoading ? "—" : totalCount}
            </span>
          </div>

          <div className="p-2.5 rounded-xl bg-teal-50 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-800">
            <span className="text-[10px] uppercase font-bold text-teal-600 dark:text-teal-400 block">
              Avaliados
            </span>
            <span className="font-mono text-xl font-black text-teal-700 dark:text-teal-300">
              {isLoading ? "—" : completedCount}
            </span>
          </div>

          <div className="p-2.5 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800">
            <span className="text-[10px] uppercase font-bold text-amber-600 dark:text-amber-400 block">
              Pendentes
            </span>
            <span className="font-mono text-xl font-black text-amber-700 dark:text-amber-300">
              {isLoading ? "—" : pendingCount}
            </span>
          </div>
        </div>

        {/* Botão de Ação Rápida */}
        <button
          type="button"
          onClick={() => router.push("/projects")}
          className="w-full py-2.5 px-4 rounded-xl bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 text-slate-700 dark:text-slate-200 text-xs font-bold transition-all flex items-center justify-center gap-1.5 touch-target"
        >
          <span>Ir para Lista de Trabalhos Alocados</span>
          <ExternalLink className="w-3.5 h-3.5 text-slate-400" />
        </button>
      </div>

      {/* CONECTIVIDADE E ARMAZENAMENTO OFFLINE */}
      <div className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-sm space-y-3 text-xs">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 font-black uppercase tracking-wider text-slate-700 dark:text-slate-300">
            <Smartphone className="w-4 h-4 text-teal-600 dark:text-teal-400" />
            <span>Conectividade & Fila Local</span>
          </div>

          <span
            className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md font-bold text-[10px] ${
              isOnline
                ? "bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300 border border-teal-200 dark:border-teal-800"
                : "bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800"
            }`}
          >
            {isOnline ? (
              <>
                <Wifi className="w-3 h-3 text-teal-500" />
                <span>Online</span>
              </>
            ) : (
              <>
                <WifiOff className="w-3 h-3 text-amber-500 animate-pulse" />
                <span>Modo Offline</span>
              </>
            )}
          </span>
        </div>

        <div className="divide-y divide-slate-100 dark:divide-slate-700/60">
          <div className="flex items-center justify-between py-2">
            <span className="text-slate-500 dark:text-slate-400">Status da Rede</span>
            <span className="font-bold text-slate-800 dark:text-slate-200">
              {isOnline ? "Conectado aos Servidores FECITEL" : "Sem Conexão (Gravando no Aparelho)"}
            </span>
          </div>

          <div className="flex items-center justify-between py-2">
            <span className="text-slate-500 dark:text-slate-400">Fila Offline no Celular</span>
            <span
              className={`font-mono font-bold ${
                offlinePendingCount > 0 ? "text-amber-600 dark:text-amber-400" : "text-teal-600 dark:text-teal-400"
              }`}
            >
              {offlinePendingCount === 0
                ? "0 pendentes (Sincronizado)"
                : `${offlinePendingCount} aguardando envio`}
            </span>
          </div>

          {lastSyncTime && (
            <div className="flex items-center justify-between py-2">
              <span className="text-slate-500 dark:text-slate-400">Última Sincronização</span>
              <span className="font-mono text-slate-600 dark:text-slate-300 text-[11px]">
                {lastSyncTime.toLocaleTimeString("pt-BR")}
              </span>
            </div>
          )}
        </div>

        {offlinePendingCount > 0 && (
          <button
            type="button"
            disabled={isSyncing || !isOnline}
            onClick={() => syncNow()}
            className="w-full py-2.5 px-4 rounded-xl bg-teal-600 hover:bg-teal-700 disabled:bg-slate-300 text-white font-bold text-xs shadow-sm flex items-center justify-center gap-2 touch-target"
          >
            {isSyncing ? (
              <>
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                <span>Sincronizando avaliações...</span>
              </>
            ) : (
              <>
                <CloudUpload className="w-3.5 h-3.5" />
                <span>Sincronizar {offlinePendingCount} Avaliação(ões) Agora</span>
              </>
            )}
          </button>
        )}
      </div>

      {/* INFORMAÇÕES DO SISTEMA E SEGURANÇA */}
      <div className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-sm space-y-2.5 text-xs">
        <div className="flex items-center gap-2 font-black uppercase tracking-wider text-slate-700 dark:text-slate-300">
          <ShieldCheck className="w-4 h-4 text-teal-600 dark:text-teal-400" />
          <span>Informações da Sessão</span>
        </div>

        <div className="divide-y divide-slate-100 dark:divide-slate-700/60">
          <div className="flex items-center justify-between py-2">
            <span className="text-slate-500 dark:text-slate-400">Tipo de Autenticação</span>
            <span className="font-bold text-slate-800 dark:text-slate-200">Código OTP (8 caracteres)</span>
          </div>

          <div className="flex items-center justify-between py-2">
            <span className="text-slate-500 dark:text-slate-400">Validade da Sessão</span>
            <span className="font-bold text-teal-600 dark:text-teal-400">Ativa (12 horas)</span>
          </div>

          <div className="flex items-center justify-between py-2">
            <span className="text-slate-500 dark:text-slate-400">ID do Usuário</span>
            <span className="font-mono font-bold text-slate-800 dark:text-slate-200">#{user?.id || 0}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
