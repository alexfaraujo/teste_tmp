"use client";

import React, { Suspense, useEffect, useState } from "react";
import { useParams, useRouter, useSearchParams } from "next/navigation";
import {
  ArrowLeft,
  ArrowRight,
  Award,
  Check,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Edit3,
  Eye,
  FileCheck,
  HelpCircle,
  MessageSquare,
  QrCode,
  Send,
  Sparkles,
  AlertCircle,
  Clock,
  WifiOff,
  CloudUpload,
} from "lucide-react";
import evaluatorService from "@/services/evaluator.service";
import BannerConferenceCard from "@/components/banner/BannerConferenceCard";
import ScoreStepper from "@/components/steppers/ScoreStepper";
import { EvaluationSheetResponse } from "@/types";
import { useNetwork } from "@/context/NetworkContext";

function EvaluatePageContent() {
  const params = useParams();
  const router = useRouter();
  const searchParams = useSearchParams();
  const projectId = Number(params.id);
  const isReadOnly = searchParams.get("mode") === "readonly";

  const { enqueueEvaluation, getQueuedForProject } = useNetwork();
  const [isOfflineSubmitted, setIsOfflineSubmitted] = useState(false);
  const [isQueuedOffline, setIsQueuedOffline] = useState(false);

  const [activeTab, setActiveTab] = useState<"BANNER" | "GRADING">("BANNER");
  const [sheet, setSheet] = useState<EvaluationSheetResponse | null>(null);
  const [scores, setScores] = useState<Record<number, number>>({});
  const [feedback, setFeedback] = useState("");

  // Índice da pergunta atual no Wizard (0 a sheet.criteria.length - 1 para critérios, e sheet.criteria.length para a tela final de síntese/parecer)
  const [currentStep, setCurrentStep] = useState(0);

  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  useEffect(() => {
    async function loadSheetData() {
      // 1. Se for modo somente-leitura (consulta de trabalho já avaliado):
      if (isReadOnly) {
        // Verificar se este projeto foi avaliado offline e está aguardando envio na fila
        const queuedItem = getQueuedForProject(projectId);
        if (queuedItem) {
          setIsQueuedOffline(true);
          const cachedSheetRaw =
            sessionStorage.getItem(`fecitel_sheet_${projectId}`) ||
            localStorage.getItem(`fecitel_sheet_cache_${projectId}`);
          let sheetBase: EvaluationSheetResponse | null = null;
          if (cachedSheetRaw) {
            try {
              sheetBase = JSON.parse(cachedSheetRaw);
            } catch {}
          }
          if (sheetBase) {
            const initialScores: Record<number, number> = {};
            for (const item of queuedItem.payload.items) {
              initialScores[item.criterion_id] = item.score;
            }
            setSheet(sheetBase);
            setScores(initialScores);
            setFeedback(queuedItem.payload.general_feedback || "");
            setIsLoading(false);
            return;
          }
        }

        try {
          const sheetData = await evaluatorService.getMyProjectEvaluationSheet(projectId);
          setSheet(sheetData);
          const initialScores: Record<number, number> = {};
          for (const c of sheetData.criteria) {
            initialScores[c.criterion_id] = c.current_score ?? 0.0;
          }
          setScores(initialScores);
          if (sheetData.current_feedback) {
            setFeedback(sheetData.current_feedback);
          }
          setIsLoading(false);
          return;
        } catch (err: any) {
          console.error("Erro ao carregar ficha em modo consulta:", err);
          setErrorMessage(
            err.response?.data?.detail || "Falha ao carregar a avaliação concluída."
          );
          setIsLoading(false);
          return;
        }
      }

      // 2. Fluxo de avaliação: verificar validação de estande por QR Code no sessionStorage
      const validatedToken =
        sessionStorage.getItem(`easyevent_validated_project_${projectId}`) ||
        sessionStorage.getItem(`fecitel_validated_project_${projectId}`);
      if (!validatedToken) {
        router.replace(`/scan?projectId=${projectId}`);
        return;
      }

      // 3. Carregar dados da ficha do sessionStorage ou consultar API
      const storedSheet =
        sessionStorage.getItem(`easyevent_sheet_${projectId}`) ||
        sessionStorage.getItem(`fecitel_sheet_${projectId}`);
      let currentSheetData: EvaluationSheetResponse | null = null;

      if (storedSheet) {
        try {
          currentSheetData = JSON.parse(storedSheet);
        } catch (e) {
          console.warn("Falha ao recuperar ficha em cache:", e);
        }
      }

      if (!currentSheetData) {
        try {
          currentSheetData = await evaluatorService.getEvaluationSheet(validatedToken);
        } catch (err: any) {
          console.error("Erro ao carregar ficha de avaliação:", err);
          setErrorMessage(
            err.response?.data?.detail || "Falha ao carregar a ficha de avaliação. Tente escanear novamente."
          );
          setIsLoading(false);
          return;
        }
      }

      setSheet(currentSheetData);
      // Guardar backup dos dados da ficha no localStorage para caso a aba seja recarregada offline
      try {
        localStorage.setItem(`fecitel_sheet_cache_${projectId}`, JSON.stringify(currentSheetData));
      } catch {}

      // 4. Recuperar notas parciais salvas no sessionStorage ou localStorage se houver
      const savedScores =
        sessionStorage.getItem(`fecitel_scores_project_${projectId}`) ||
        localStorage.getItem(`fecitel_draft_scores_project_${projectId}`);
      const savedFeedback =
        sessionStorage.getItem(`fecitel_feedback_project_${projectId}`) ||
        localStorage.getItem(`fecitel_draft_feedback_project_${projectId}`);

      const initialScores: Record<number, number> = {};
      for (const c of currentSheetData.criteria) {
        initialScores[c.criterion_id] = c.current_score ?? 0.0;
      }

      if (savedScores) {
        try {
          const parsedScores = JSON.parse(savedScores);
          Object.assign(initialScores, parsedScores);
        } catch (e) {
          // ignore
        }
      }

      setScores(initialScores);

      if (savedFeedback) {
        setFeedback(savedFeedback);
      } else if (currentSheetData.current_feedback) {
        setFeedback(currentSheetData.current_feedback);
      }

      setIsLoading(false);
    }

    loadSheetData();
  }, [projectId, router, isReadOnly, getQueuedForProject]);

  const handleScoreChange = (criterionId: number, score: number) => {
    if (isReadOnly) return;
    setScores((prev) => {
      const updated = { ...prev, [criterionId]: score };
      try {
        sessionStorage.setItem(`fecitel_scores_project_${projectId}`, JSON.stringify(updated));
        localStorage.setItem(`fecitel_draft_scores_project_${projectId}`, JSON.stringify(updated));
      } catch {}
      return updated;
    });
  };

  const handleFeedbackChange = (text: string) => {
    if (isReadOnly) return;
    setFeedback(text);
    try {
      sessionStorage.setItem(`fecitel_feedback_project_${projectId}`, text);
      localStorage.setItem(`fecitel_draft_feedback_project_${projectId}`, text);
    } catch {}
  };

  // Cálculo em tempo real da média ponderada (Regra BR-12)
  const computeWeightedAverage = () => {
    if (!sheet || sheet.criteria.length === 0) return 0.0;
    let totalWeight = 0;
    let totalScore = 0;

    for (const c of sheet.criteria) {
      const w = c.weight || 1.0;
      const s = scores[c.criterion_id] ?? 0.0;
      totalScore += s * w;
      totalWeight += w;
    }

    if (totalWeight <= 0) return 0.0;
    return Math.round((totalScore / totalWeight) * 100) / 100;
  };

  const weightedAverage = computeWeightedAverage();
  const totalCriteria = sheet?.criteria.length || 0;
  const isSummaryStep = currentStep === totalCriteria;
  const currentCriterion = sheet?.criteria[currentStep];

  const handleOpenConfirm = (e: React.FormEvent) => {
    e.preventDefault();
    if (isReadOnly) return;
    setErrorMessage(null);
    setShowConfirmModal(true);
  };

  const handleSubmitEvaluation = async () => {
    if (!sheet || isReadOnly) return;
    setIsSubmitting(true);
    setErrorMessage(null);

    const items = sheet.criteria.map((c) => ({
      criterion_id: c.criterion_id,
      score: scores[c.criterion_id] ?? 0.0,
    }));

    const payload = {
      project_id: sheet.project_id,
      general_feedback: feedback.trim() ? feedback.trim() : undefined,
      items,
      status: "COMPLETED" as const,
    };

    const clearDrafts = () => {
      try {
        sessionStorage.removeItem(`fecitel_scores_project_${projectId}`);
        sessionStorage.removeItem(`fecitel_feedback_project_${projectId}`);
        localStorage.removeItem(`fecitel_draft_scores_project_${projectId}`);
        localStorage.removeItem(`fecitel_draft_feedback_project_${projectId}`);
      } catch {}
    };

    // 1. Caso o aparelho esteja offline no momento do clique:
    if (!navigator.onLine) {
      enqueueEvaluation(sheet.project_id, payload, sheet.title, sheet.booth_number);
      clearDrafts();
      setIsSubmitting(false);
      setShowConfirmModal(false);
      setIsOfflineSubmitted(true);
      setShowSuccessModal(true);
      return;
    }

    // 2. Tentar submissão normal via API REST:
    try {
      await evaluatorService.submitEvaluation(payload);
      clearDrafts();
      setShowConfirmModal(false);
      setIsOfflineSubmitted(false);
      setShowSuccessModal(true);
    } catch (err: any) {
      console.warn("Erro ao enviar avaliação:", err);
      const isNetworkError =
        !err.response ||
        err.code === "ECONNABORTED" ||
        err.message?.toLowerCase().includes("network") ||
        err.response?.status === 502 ||
        err.response?.status === 503 ||
        err.response?.status === 504;

      if (isNetworkError) {
        // Tolerância a falhas na feira: salva com segurança na fila offline local
        enqueueEvaluation(sheet.project_id, payload, sheet.title, sheet.booth_number);
        clearDrafts();
        setShowConfirmModal(false);
        setIsOfflineSubmitted(true);
        setShowSuccessModal(true);
      } else {
        setShowConfirmModal(false);
        setErrorMessage(
          err.response?.data?.detail || "Falha ao registrar a avaliação. Verifique suas notas e tente novamente."
        );
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-6 text-slate-500">
        <div className="w-8 h-8 border-4 border-fecitel-blue-600 border-t-transparent rounded-full animate-spin mb-3" />
        <p className="text-xs font-medium">Carregando ficha de avaliação...</p>
      </div>
    );
  }

  if (!sheet) {
    return (
      <div className="p-6 text-center space-y-3">
        <div className="w-12 h-12 rounded-2xl bg-red-100 text-red-600 flex items-center justify-center mx-auto">
          <AlertCircle className="w-6 h-6" />
        </div>
        <h2 className="text-base font-bold text-slate-800">Ficha não encontrada</h2>
        <p className="text-xs text-slate-500">{errorMessage || "Valide o estande novamente."}</p>
        <button
          onClick={() => router.push(isReadOnly ? "/projects" : `/scan?projectId=${projectId}`)}
          className="px-4 py-2 rounded-xl bg-fecitel-blue-900 text-white text-xs font-bold"
        >
          {isReadOnly ? "Voltar aos Meus Trabalhos" : "Voltar para Leitor QR Code"}
        </button>
      </div>
    );
  }

  return (
    <div className="p-4 space-y-4">
      {/* Barra de Retorno e Identificação do Estande */}
      <div className="flex items-center justify-between">
        <button
          onClick={() => router.push("/projects")}
          className="inline-flex items-center gap-1.5 text-xs font-bold text-fecitel-blue-900 dark:text-blue-400 hover:underline py-1"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Meus Trabalhos</span>
        </button>

        <div className="flex items-center gap-2">
          {isReadOnly && (
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg text-[10px] font-black bg-teal-50 dark:bg-teal-950/60 border border-teal-200 dark:border-teal-800 text-teal-700 dark:text-teal-300">
              <CheckCircle2 className="w-3 h-3 text-teal-600 dark:text-teal-400" />
              AVALIADO
            </span>
          )}
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-lg text-[11px] font-black bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-800 text-fecitel-blue-900 dark:text-blue-300">
            ESTANDE {sheet.booth_number || "CONFIRMADO"}
          </span>
        </div>
      </div>

      {/* Banner de Aviso de Modo Consulta / Somente-Leitura */}
      {isReadOnly && (
        <div
          className={`p-3 rounded-2xl border flex items-center justify-between text-xs shadow-sm ${
            isQueuedOffline
              ? "bg-amber-50 dark:bg-amber-950/40 border-amber-300 dark:border-amber-800 text-amber-900 dark:text-amber-200"
              : "bg-teal-50 dark:bg-teal-950/40 border-teal-200 dark:border-teal-800/60 text-teal-800 dark:text-teal-200"
          }`}
        >
          <div className="flex items-center gap-2">
            {isQueuedOffline ? (
              <WifiOff className="w-4 h-4 text-amber-600 dark:text-amber-400 flex-shrink-0" />
            ) : (
              <CheckCircle2 className="w-4 h-4 text-teal-600 dark:text-teal-400 flex-shrink-0" />
            )}
            <span className="font-medium leading-tight">
              {isQueuedOffline ? (
                <>
                  Avaliação <strong>gravada no celular</strong>: aguardando reconexão de rede para transmissão à apuração.
                </>
              ) : (
                <>
                  Visualização <strong>somente-leitura</strong>: avaliação finalizada e registrada no banco de dados.
                </>
              )}
            </span>
          </div>
        </div>
      )}

      {/* Navegação por Abas Principais: 1. Banner vs 2. Avaliação Passo a Passo */}
      <div className="grid grid-cols-2 p-1 rounded-2xl bg-slate-200/80 dark:bg-slate-800 shadow-inner">
        <button
          type="button"
          onClick={() => setActiveTab("BANNER")}
          className={`py-2.5 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 touch-target ${
            activeTab === "BANNER"
              ? "bg-white dark:bg-slate-700 text-fecitel-blue-900 dark:text-white shadow-sm"
              : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
          }`}
        >
          <FileCheck className="w-4 h-4" />
          <span>1. Banner</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab("GRADING")}
          className={`py-2.5 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 touch-target ${
            activeTab === "GRADING"
              ? "bg-white dark:bg-slate-700 text-fecitel-blue-900 dark:text-white shadow-sm"
              : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
          }`}
        >
          <Award className="w-4 h-4" />
          <span>
            {isReadOnly
              ? "2. Notas & Síntese"
              : `2. Avaliação (${currentStep < totalCriteria ? `${currentStep + 1}/${totalCriteria}` : "Síntese"})`}
          </span>
        </button>
      </div>

      {/* Alerta de Erro */}
      {errorMessage && (
        <div className="p-3.5 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 flex items-start gap-2.5 text-red-700 dark:text-red-300 text-xs">
          <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5 text-red-600" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* ABA 1: Conferência do Banner Físico */}
      {activeTab === "BANNER" && (
        <BannerConferenceCard
          sheet={sheet}
          proceedButtonLabel={isReadOnly ? "Ver Notas Registradas →" : "Avançar para Avaliação e Notas"}
          onProceedToGrading={() => {
            setActiveTab("GRADING");
            setCurrentStep(0);
          }}
        />
      )}

      {/* ABA 2: Ficha Paginada Passo a Passo (Wizard: Uma Pergunta por Vez) */}
      {activeTab === "GRADING" && (
        <div className="space-y-4">
          {/* Card Superior de Média Ponderada em Tempo Real */}
          <div className="p-3.5 rounded-2xl bg-gradient-to-br from-fecitel-blue-900 to-blue-950 text-white shadow-md">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-[10px] uppercase tracking-wider font-semibold text-teal-300">
                  {isReadOnly ? "Média Ponderada Homologada" : "Média Ponderada em Tempo Real"}
                </p>
                <div className="flex items-baseline gap-1 mt-0.5">
                  <span className="font-mono text-2xl font-black text-white">
                    {weightedAverage.toFixed(2)}
                  </span>
                  <span className="text-[11px] text-blue-200 font-semibold">/ 10.0 pts</span>
                </div>
              </div>

              <div className="text-right">
                <span className="text-[11px] font-bold text-teal-300 bg-teal-500/20 px-2.5 py-1 rounded-lg border border-teal-500/30">
                  {isSummaryStep
                    ? "Síntese Final"
                    : `Pergunta ${currentStep + 1} de ${totalCriteria}`}
                </span>
              </div>
            </div>

            {/* Barra de Progresso Visual */}
            <div className="w-full h-1.5 bg-blue-950/60 rounded-full mt-2.5 overflow-hidden">
              <div
                className="h-full bg-teal-400 transition-all duration-300 rounded-full"
                style={{
                  width: `${Math.round(((currentStep + 1) / (totalCriteria + 1)) * 100)}%`,
                }}
              />
            </div>
          </div>

          {/* Régua de Navegação Rápida entre Perguntas (Atalhos Diretos) */}
          <div className="p-2 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-sm flex items-center justify-between gap-1 overflow-x-auto">
            {sheet.criteria.map((c, idx) => {
              const isCurrent = currentStep === idx;
              const hasScore = scores[c.criterion_id] !== undefined;

              return (
                <button
                  key={c.criterion_id}
                  type="button"
                  onClick={() => setCurrentStep(idx)}
                  className={`flex-1 py-1.5 px-1 rounded-xl text-[11px] font-bold transition-all flex flex-col items-center justify-center min-w-[40px] touch-target ${
                    isCurrent
                      ? "bg-fecitel-blue-900 text-white shadow-md scale-105"
                      : hasScore
                      ? "bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300 border border-teal-200 dark:border-teal-800"
                      : "bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300"
                  }`}
                  title={`Ir para Critério ${idx + 1}: ${c.name}`}
                >
                  <span>Q{idx + 1}</span>
                  <span className="text-[9px] font-mono opacity-80">
                    {hasScore ? `${(scores[c.criterion_id] ?? 0).toFixed(1)}` : "—"}
                  </span>
                </button>
              );
            })}

            {/* Botão de Atalho para a Síntese Final e Observações */}
            <button
              type="button"
              onClick={() => setCurrentStep(totalCriteria)}
              className={`py-1.5 px-2 rounded-xl text-[11px] font-bold transition-all flex flex-col items-center justify-center min-w-[50px] touch-target ${
                isSummaryStep
                  ? "bg-teal-600 text-white shadow-md scale-105"
                  : feedback.trim().length > 0
                  ? "bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300 border border-teal-200 dark:border-teal-800"
                  : "bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300"
              }`}
              title="Ir para a Síntese Final e Observações"
            >
              <span>Síntese</span>
              <span className="text-[9px] opacity-80">
                {feedback.trim().length > 0 ? "Obs ✓" : "Final"}
              </span>
            </button>
          </div>

          {/* CARD DA PERGUNTA ATUAL (Quando currentStep < totalCriteria) */}
          {!isSummaryStep && currentCriterion && (
            <div className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-sm space-y-4 animate-in fade-in duration-150">
              {/* Cabeçalho do Critério */}
              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-black uppercase tracking-wider text-fecitel-blue-900 dark:text-blue-400">
                    Critério {currentStep + 1} de {totalCriteria}
                  </span>
                  <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400">
                    Peso: {currentCriterion.weight.toFixed(1)}x • Máx: {currentCriterion.max_score.toFixed(1)} pts
                  </span>
                </div>

                <h3 className="text-base font-bold text-slate-900 dark:text-white leading-snug">
                  {currentCriterion.name}
                </h3>
              </div>

              {/* Pergunta Adaptada ao Trabalho */}
              <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-700/80">
                <p className="text-xs text-slate-700 dark:text-slate-200 leading-relaxed font-medium">
                  {currentCriterion.description || "Avalie o desempenho do trabalho conforme este critério."}
                </p>
              </div>

              {/* Seletor Tátil de Notas ou Display Somente-Leitura */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-xs font-bold uppercase tracking-wider text-slate-500">
                    {isReadOnly ? "Nota Homologada do Critério:" : "Atribuir Nota ao Critério:"}
                  </label>
                  <span className="text-xs font-bold text-teal-600 dark:text-teal-400">
                    Nota: {(scores[currentCriterion.criterion_id] ?? 0).toFixed(1)} pts
                  </span>
                </div>

                {isReadOnly ? (
                  <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-center space-y-1">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                      Nota Oficial Homologada
                    </span>
                    <div className="flex items-baseline justify-center gap-1">
                      <span className="font-mono text-3xl font-black text-fecitel-blue-900 dark:text-blue-400">
                        {(scores[currentCriterion.criterion_id] ?? 0).toFixed(1)}
                      </span>
                      <span className="text-xs font-semibold text-slate-400">
                        / {currentCriterion.max_score.toFixed(1)} pts
                      </span>
                    </div>
                    <p className="text-[11px] text-teal-600 dark:text-teal-400 font-semibold flex items-center justify-center gap-1 pt-0.5">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Nota registrada oficialmente</span>
                    </p>
                  </div>
                ) : (
                  <ScoreStepper
                    key={currentCriterion.criterion_id}
                    value={scores[currentCriterion.criterion_id] ?? 0.0}
                    onChange={(val) => handleScoreChange(currentCriterion.criterion_id, val)}
                    maxScore={currentCriterion.max_score}
                  />
                )}
              </div>

              {/* Barra de Navegação: Anterior / Próximo */}
              <div className="grid grid-cols-2 gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setCurrentStep((prev) => Math.max(0, prev - 1))}
                  disabled={currentStep === 0}
                  className="py-3 px-4 rounded-xl border border-slate-300 dark:border-slate-600 font-bold text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 active:scale-95 disabled:opacity-30 touch-target flex items-center justify-center gap-1.5"
                >
                  <ChevronLeft className="w-4 h-4" />
                  <span>Anterior</span>
                </button>

                <button
                  type="button"
                  onClick={() => setCurrentStep((prev) => prev + 1)}
                  className="py-3 px-4 rounded-xl bg-fecitel-blue-900 hover:bg-fecitel-blue-800 active:scale-[0.99] text-white font-bold text-xs shadow-md shadow-blue-950/20 touch-target flex items-center justify-center gap-1.5"
                >
                  <span>
                    {currentStep === totalCriteria - 1
                      ? isReadOnly
                        ? "Ver Síntese Final"
                        : "Revisar e Finalizar"
                      : "Próximo"}
                  </span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* ETAPA FINAL: SÍNTESE, PARECER GERAL E SUBMISSÃO (Quando currentStep === totalCriteria) */}
          {isSummaryStep && (
            <form onSubmit={handleOpenConfirm} className="space-y-4 animate-in fade-in duration-150">
              {/* Card de Resumo de Todas as Notas Atribuídas */}
              <div className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-sm space-y-3">
                <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-2">
                  <div className="flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-teal-600 dark:text-teal-400" />
                    <h3 className="text-xs font-black uppercase tracking-wider text-slate-800 dark:text-slate-200">
                      Conferência de Notas dos Critérios
                    </h3>
                  </div>
                  <span className="text-xs font-mono font-bold text-teal-600 dark:text-teal-400">
                    Média: {weightedAverage.toFixed(2)} pts
                  </span>
                </div>

                <div className="space-y-2">
                  {sheet.criteria.map((c, idx) => {
                    const score = scores[c.criterion_id] ?? 0.0;
                    return (
                      <div
                        key={c.criterion_id}
                        className="flex items-center justify-between p-2 rounded-xl bg-slate-50 dark:bg-slate-900/40 text-xs"
                      >
                        <div className="truncate pr-2">
                          <span className="font-bold text-slate-800 dark:text-slate-200">
                            {idx + 1}. {c.name}
                          </span>
                          <span className="text-slate-400 text-[10px] block">
                            Peso {c.weight.toFixed(1)}x
                          </span>
                        </div>

                        <div className="flex items-center gap-2 flex-shrink-0">
                          <span className="font-mono font-black text-fecitel-blue-900 dark:text-blue-400 text-sm">
                            {score.toFixed(1)}
                          </span>
                          <button
                            type="button"
                            onClick={() => setCurrentStep(idx)}
                            className="p-1 text-slate-400 hover:text-fecitel-blue-600 dark:hover:text-blue-400"
                            title={isReadOnly ? "Inspecionar este critério" : "Editar nota deste critério"}
                          >
                            {isReadOnly ? (
                              <Eye className="w-3.5 h-3.5" />
                            ) : (
                              <Edit3 className="w-3.5 h-3.5" />
                            )}
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Observações sobre o Trabalho (Opcional ou Somente-Leitura) */}
              <div className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-sm space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-slate-800 dark:text-slate-200">
                    <MessageSquare className="w-4 h-4 text-teal-600 dark:text-teal-400" />
                    <span>
                      {isReadOnly ? "Observações Registradas" : "Observações sobre o Trabalho"}
                    </span>
                  </div>
                  <span className="text-[10px] font-bold text-slate-400 dark:text-slate-400 bg-slate-100 dark:bg-slate-700 px-2 py-0.5 rounded-full">
                    {isReadOnly ? "Homologado" : "Opcional"}
                  </span>
                </div>

                {isReadOnly ? (
                  feedback.trim() ? (
                    <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs text-slate-800 dark:text-slate-200 leading-relaxed font-medium">
                      {feedback}
                    </div>
                  ) : (
                    <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-900 border border-dashed border-slate-200 dark:border-slate-700 text-xs text-slate-400 italic text-center">
                      Nenhuma observação foi registrada pelo avaliador.
                    </div>
                  )
                ) : (
                  <>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      Campo opcional caso você queira registrar considerações, pontos de destaque ou sugestões de aprimoramento para a equipe de estudantes.
                    </p>

                    <textarea
                      rows={4}
                      value={feedback}
                      onChange={(e) => handleFeedbackChange(e.target.value)}
                      placeholder="Deixe uma observação sobre o trabalho se achar pertinente (opcional)..."
                      className="w-full p-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white text-xs placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-fecitel-blue-600 font-sans"
                    />
                  </>
                )}
              </div>

              {/* Botões de Ação da Etapa Final */}
              {isReadOnly ? (
                <div className="space-y-2 pt-1">
                  <button
                    type="button"
                    onClick={() => router.push("/projects")}
                    className="w-full py-4 px-5 rounded-2xl bg-fecitel-blue-900 hover:bg-fecitel-blue-800 active:scale-[0.99] text-white font-bold text-sm shadow-xl shadow-blue-950/20 transition-all flex items-center justify-center gap-2 touch-target"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    <span>Voltar aos Meus Trabalhos</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setCurrentStep(0)}
                    className="w-full py-2.5 px-4 rounded-xl text-xs font-medium text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 touch-target"
                  >
                    Rever critérios desde a pergunta 1
                  </button>
                </div>
              ) : (
                <div className="space-y-2 pt-1">
                  <button
                    type="submit"
                    className="w-full py-4 px-5 rounded-2xl bg-teal-600 hover:bg-teal-700 active:scale-[0.99] text-white font-bold text-sm shadow-xl shadow-teal-950/20 transition-all flex items-center justify-center gap-2 touch-target"
                  >
                    <Send className="w-4 h-4" />
                    <span>Finalizar e Submeter Avaliação</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setCurrentStep(totalCriteria - 1)}
                    className="w-full py-2.5 px-4 rounded-xl text-xs font-medium text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 touch-target"
                  >
                    ← Voltar para o último critério
                  </button>
                </div>
              )}
            </form>
          )}
        </div>
      )}

      {/* Modal de Confirmação antes do Envio */}
      {!isReadOnly && showConfirmModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="w-full max-w-sm rounded-2xl bg-white dark:bg-slate-900 p-5 text-slate-900 dark:text-white shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-teal-100 dark:bg-teal-950/60 text-teal-600 dark:text-teal-400 flex items-center justify-center mx-auto">
              <Award className="w-6 h-6" />
            </div>

            <div className="text-center space-y-1">
              <h3 className="text-base font-bold">Confirmar Avaliação?</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 truncate max-w-xs mx-auto">
                {sheet.title}
              </p>
            </div>

            {/* Resumo da Nota */}
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-center">
              <p className="text-[10px] uppercase font-bold text-slate-400">Nota Final Calculada</p>
              <p className="text-2xl font-black font-mono text-fecitel-blue-900 dark:text-blue-400 mt-0.5">
                {weightedAverage.toFixed(2)} pts
              </p>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowConfirmModal(false)}
                className="py-3 px-3 rounded-xl border border-slate-300 dark:border-slate-700 font-bold text-xs text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 touch-target"
              >
                Voltar e Revisar
              </button>

              <button
                type="button"
                onClick={handleSubmitEvaluation}
                disabled={isSubmitting}
                className="py-3 px-3 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs shadow-md shadow-teal-950/20 touch-target flex items-center justify-center gap-1.5 disabled:opacity-50"
              >
                {isSubmitting ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Enviando...</span>
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Confirmar Envio</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal de Sucesso */}
      {!isReadOnly && showSuccessModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="w-full max-w-sm rounded-2xl bg-white dark:bg-slate-900 p-6 text-slate-900 dark:text-white shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4 text-center">
            <div
              className={`w-16 h-16 rounded-2xl flex items-center justify-center mx-auto shadow-inner ${
                isOfflineSubmitted
                  ? "bg-amber-100 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400"
                  : "bg-teal-100 dark:bg-teal-950/60 text-teal-600 dark:text-teal-400"
              }`}
            >
              {isOfflineSubmitted ? (
                <WifiOff className="w-9 h-9" />
              ) : (
                <CheckCircle2 className="w-10 h-10" />
              )}
            </div>

            <div>
              <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider mb-1.5 border bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700">
                {isOfflineSubmitted ? "Salvo no Aparelho • Fila Offline" : "Oficialmente Homologado"}
              </div>
              <h3 className="text-lg font-black text-slate-900 dark:text-white">
                {isOfflineSubmitted ? "Avaliação Salva no Celular!" : "Avaliação Concluída!"}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 leading-relaxed">
                {isOfflineSubmitted
                  ? "Devido a instabilidade no sinal do pavilhão, suas notas e parecer foram guardados com segurança no seu dispositivo. Eles serão enviados para a apuração oficial da FECITEL automaticamente assim que a conexão retornar."
                  : "As notas e as observações foram registradas com sucesso no banco de apuração oficial da FECITEL."}
              </p>
            </div>

            <div className="space-y-2 pt-2">
              <button
                type="button"
                onClick={() => router.push("/projects")}
                className="w-full py-3.5 px-4 rounded-xl bg-fecitel-blue-900 hover:bg-fecitel-blue-800 text-white font-bold text-xs shadow-md shadow-blue-950/20 touch-target flex items-center justify-center gap-2"
              >
                <span>Voltar aos Meus Trabalhos</span>
              </button>

              <button
                type="button"
                onClick={() => router.push("/scan")}
                className="w-full py-3 px-4 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-200 font-bold text-xs touch-target flex items-center justify-center gap-2"
              >
                <QrCode className="w-4 h-4 text-teal-600" />
                <span>Avaliar Próximo Trabalho</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default function EvaluatePage() {
  return (
    <Suspense
      fallback={
        <div className="flex-1 flex flex-col items-center justify-center p-6 text-slate-500">
          <div className="w-8 h-8 border-4 border-fecitel-blue-600 border-t-transparent rounded-full animate-spin mb-3" />
          <p className="text-xs font-medium">Carregando...</p>
        </div>
      }
    >
      <EvaluatePageContent />
    </Suspense>
  );
}
