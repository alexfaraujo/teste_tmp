"use client";

import React, { useEffect, useState } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import dynamic from "next/dynamic";
import { ArrowLeft, MapPin, AlertTriangle, CheckCircle2, ShieldAlert, Sparkles } from "lucide-react";
import evaluatorService from "@/services/evaluator.service";
import { AllocationItem } from "@/types";

// Importar QrScanner com SSR desativado para garantir execução apenas no navegador
const QrScanner = dynamic(() => import("@/components/scanner/QrScanner"), {
  ssr: false,
  loading: () => (
    <div className="aspect-square max-w-[320px] mx-auto rounded-2xl bg-slate-950 flex flex-col items-center justify-center text-slate-400 p-4">
      <div className="w-8 h-8 border-4 border-teal-500 border-t-transparent rounded-full animate-spin mb-2" />
      <p className="text-xs font-medium">Carregando leitor de câmera...</p>
    </div>
  ),
});

export default function ScanPage() {
  const searchParams = useSearchParams();
  const router = useRouter();

  const targetProjectId = searchParams.get("projectId");
  const targetTitle = searchParams.get("title");
  const targetBooth = searchParams.get("booth");

  const [expectedToken, setExpectedToken] = useState<string | null>(null);
  const [errorAlert, setErrorAlert] = useState<string | null>(null);
  const [successAlert, setSuccessAlert] = useState<string | null>(null);

  // Buscar token esperado caso o avaliador tenha selecionado um trabalho específico
  useEffect(() => {
    async function findExpectedToken() {
      if (!targetProjectId) return;
      try {
        const allocs = await evaluatorService.getMyAllocations();
        const target = allocs.find((a: AllocationItem) => a.project_id === Number(targetProjectId));
        if (target && target.qrcode_token) {
          setExpectedToken(target.qrcode_token);
        }
      } catch (e) {
        console.warn("Não foi possível carregar token esperado:", e);
      }
    }

    findExpectedToken();
  }, [targetProjectId]);

  const handleScanSuccess = async (scannedRaw: string) => {
    setErrorAlert(null);
    setSuccessAlert(null);

    // Extrair token limpo caso o QR code contenha uma URL
    let token = scannedRaw.trim();
    if (token.includes("?qrcode=")) {
      token = token.split("?qrcode=")[1].split("&")[0];
    } else if (token.includes("/eval/")) {
      token = token.split("/eval/")[1].split("/")[0];
    }

    try {
      // 1. Consultar a ficha no backend para validar autenticidade e alocação
      const sheet = await evaluatorService.getEvaluationSheet(token);

      // 2. Validação Rígida de Estande (Regra de Ouro)
      if (targetProjectId && sheet.project_id !== Number(targetProjectId)) {
        // INCONSISTÊNCIA DE ESTANDE DETECTADA: O QR Code pertence a outro projeto!
        setErrorAlert(
          `Atenção: Inconsistência de Estande Detectada! Você selecionou avaliar o projeto "${targetTitle || targetProjectId}" (Estande ${
            targetBooth || "A Definir"
          }), mas escaneou o QR Code do projeto "${sheet.title}" (Estande ${
            sheet.booth_number || "A Definir"
          }). Por favor, dirija-se ao estande correto para realizar a avaliação presencial!`
        );
        return;
      }

      // 3. Sucesso na Validação
      setSuccessAlert(
        `Estande ${sheet.booth_number || ""} validado com sucesso para o projeto "${sheet.title}". Abrindo ficha de avaliação...`
      );

      // Salvar a validação no sessionStorage
      sessionStorage.setItem(`easyevent_validated_project_${sheet.project_id}`, token);
      sessionStorage.setItem(`easyevent_sheet_${sheet.project_id}`, JSON.stringify(sheet));
      sessionStorage.setItem(`fecitel_validated_project_${sheet.project_id}`, token);
      sessionStorage.setItem(`fecitel_sheet_${sheet.project_id}`, JSON.stringify(sheet));

      // Redirecionar para a Ficha de Avaliação após breve confirmação
      setTimeout(() => {
        router.push(`/evaluate/${sheet.project_id}`);
      }, 700);
    } catch (err: any) {
      console.error("Erro na leitura do QR Code:", err);
      const detail =
        err.response?.data?.detail ||
        "QR Code inválido, não homologado ou você não possui alocação ativa para este trabalho na feira.";
      setErrorAlert(detail);
    }
  };

  return (
    <div className="p-4 space-y-4">
      {/* Botão de Retorno */}
      <button
        onClick={() => router.push("/projects")}
        className="inline-flex items-center gap-1.5 text-xs font-bold text-fecitel-blue-900 dark:text-blue-400 hover:underline py-1"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Voltar para Meus Trabalhos</span>
      </button>

      {/* Card Informativo do Projeto Selecionado */}
      {targetProjectId ? (
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-800 border-2 border-fecitel-blue-500/40 shadow-sm space-y-2">
          <div className="flex items-center justify-between">
            <div className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-800 text-fecitel-blue-900 dark:text-blue-300 font-black text-xs">
              <MapPin className="w-3.5 h-3.5 text-fecitel-blue-600" />
              <span>ESTANDE {targetBooth || "A DEFINIR"}</span>
            </div>
            <span className="text-[10px] font-bold text-teal-600 dark:text-teal-400 uppercase tracking-wider">
              Aguardando Leitura
            </span>
          </div>

          <h2 className="text-sm font-bold text-slate-900 dark:text-white leading-snug">
            {targetTitle || `Projeto #${targetProjectId}`}
          </h2>

          <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed pt-1 border-t border-slate-100 dark:border-slate-700">
            Aproxime a câmera do <strong>QR Code afixado no estande</strong> para comprovar que você está diante do trabalho correto.
          </p>
        </div>
      ) : (
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-sm space-y-1">
          <h2 className="text-base font-bold text-slate-900 dark:text-white">
            Validação Presencial por QR Code
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Aponte a câmera para o QR Code de qualquer trabalho alocado a você no pavilhão de exposições.
          </p>
        </div>
      )}

      {/* Alerta de Inconsistência de Estande / Erro */}
      {errorAlert && (
        <div className="p-4 rounded-2xl bg-red-50 dark:bg-red-950/50 border-2 border-red-500 dark:border-red-800 text-red-900 dark:text-red-200 shadow-lg animate-in fade-in zoom-in-95 duration-200 space-y-2">
          <div className="flex items-center gap-2 font-black text-sm text-red-700 dark:text-red-400">
            <ShieldAlert className="w-5 h-5 flex-shrink-0" />
            <span>Inconsistência de Estande!</span>
          </div>
          <p className="text-xs font-medium leading-relaxed">{errorAlert}</p>
        </div>
      )}

      {/* Alerta de Sucesso e Validação Positiva */}
      {successAlert && (
        <div className="p-4 rounded-2xl bg-teal-50 dark:bg-teal-950/50 border-2 border-teal-500 dark:border-teal-800 text-teal-900 dark:text-teal-200 shadow-lg animate-in fade-in zoom-in-95 duration-200 flex items-start gap-2.5">
          <CheckCircle2 className="w-5 h-5 flex-shrink-0 mt-0.5 text-teal-600 dark:text-teal-400" />
          <p className="text-xs font-bold leading-relaxed">{successAlert}</p>
        </div>
      )}

      {/* Câmera e Scanner QR Code */}
      <QrScanner
        onScanSuccess={handleScanSuccess}
        expectedToken={expectedToken}
        boothNumber={targetBooth}
      />
    </div>
  );
}
