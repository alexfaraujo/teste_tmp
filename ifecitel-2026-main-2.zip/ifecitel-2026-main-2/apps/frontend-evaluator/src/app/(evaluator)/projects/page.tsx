"use client";

import React, { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/context/AuthContext";
import evaluatorService from "@/services/evaluator.service";
import { AllocationItem } from "@/types";
import {
  AlertCircle,
  CheckCircle2,
  Clock,
  MapPin,
  QrCode,
  RefreshCw,
  Search,
  Sparkles,
  Tag,
  Inbox,
  ArrowRight,
  Eye,
  CloudUpload,
} from "lucide-react";
import { useNetwork } from "@/context/NetworkContext";

export default function ProjectsPage() {
  const router = useRouter();
  const { user } = useAuth();
  const {
    isProjectInQueue,
    isOnline,
    pendingCount: offlinePendingCount,
    syncNow,
    isSyncing,
  } = useNetwork();

  const [allocations, setAllocations] = useState<AllocationItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [filter, setFilter] = useState<"ALL" | "PENDING" | "COMPLETED">("ALL");
  const [searchTerm, setSearchTerm] = useState("");

  const loadAllocations = async (showRefreshSpinner = false) => {
    if (showRefreshSpinner) {
      setIsRefreshing(true);
    } else {
      setIsLoading(true);
    }
    setErrorMsg(null);

    try {
      const data = await evaluatorService.getMyAllocations();
      setAllocations(data);
    } catch (err: any) {
      console.error("Erro ao carregar alocações:", err);
      setErrorMsg(
        err.response?.data?.detail || "Não foi possível carregar os trabalhos alocados. Tente novamente."
      );
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  };

  useEffect(() => {
    loadAllocations();
  }, []);

  const totalCount = allocations.length;
  const pendingCount = allocations.filter((a) => a.status === "PENDING").length;
  const completedCount = allocations.filter((a) => a.status === "COMPLETED").length;

  const filteredAllocations = allocations.filter((a) => {
    // Filtro por status
    if (filter === "PENDING" && a.status !== "PENDING") return false;
    if (filter === "COMPLETED" && a.status !== "COMPLETED") return false;

    // Filtro por busca textual (título ou estande)
    if (searchTerm.trim()) {
      const term = searchTerm.toLowerCase();
      const matchTitle = a.project_title.toLowerCase().includes(term);
      const matchBooth = a.booth_number?.toLowerCase().includes(term);
      const matchSubarea = a.subarea_name.toLowerCase().includes(term);
      return matchTitle || matchBooth || matchSubarea;
    }

    return true;
  });

  const handleStartEvaluation = (project: AllocationItem) => {
    // Se o trabalho já foi avaliado ou está gravado na fila offline local, abre em modo somente-leitura
    if (project.status === "COMPLETED" || isProjectInQueue(project.project_id)) {
      router.push(`/evaluate/${project.project_id}?mode=readonly`);
      return;
    }

    // Se pendente, redireciona para validação obrigatória de estande via QR Code
    const params = new URLSearchParams({
      projectId: project.project_id.toString(),
      title: project.project_title,
      booth: project.booth_number || "",
    });
    router.push(`/scan?${params.toString()}`);
  };

  return (
    <div className="p-4 space-y-4">
      {/* Card de Boas-Vindas & Estatísticas */}
      <div className="p-4 rounded-2xl bg-gradient-to-br from-fecitel-blue-900 to-blue-950 text-white shadow-lg relative overflow-hidden">
        <div className="relative z-10">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-teal-300 uppercase tracking-wider">
                Painel do Avaliador
              </p>
              <h2 className="text-lg font-bold mt-0.5 truncate max-w-[240px]">
                {user?.name ? user.name.split(" ")[0] : "Avaliador"}
              </h2>
            </div>
            <button
              onClick={() => loadAllocations(true)}
              disabled={isRefreshing}
              className="p-2.5 rounded-xl bg-white/10 hover:bg-white/20 active:scale-95 text-white transition-all touch-target flex items-center justify-center"
              title="Atualizar lista"
            >
              <RefreshCw className={`w-4 h-4 ${isRefreshing ? "animate-spin" : ""}`} />
            </button>
          </div>

          {/* Mini-estatísticas em cards pill */}
          <div className="grid grid-cols-3 gap-2 mt-4 pt-3 border-t border-white/10 text-center">
            <div className="bg-white/10 rounded-xl p-2">
              <p className="text-[10px] text-blue-200 font-medium uppercase">Total</p>
              <p className="text-base font-black text-white">{totalCount}</p>
            </div>
            <div className="bg-amber-500/20 border border-amber-400/30 rounded-xl p-2">
              <p className="text-[10px] text-amber-200 font-medium uppercase">Pendentes</p>
              <p className="text-base font-black text-amber-300">{pendingCount}</p>
            </div>
            <div className="bg-teal-500/20 border border-teal-400/30 rounded-xl p-2">
              <p className="text-[10px] text-teal-200 font-medium uppercase">Avaliados</p>
              <p className="text-base font-black text-teal-300">{completedCount}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Card de Sincronização de Avaliações Salvas no Aparelho (Offline) */}
      {offlinePendingCount > 0 && (
        <div className="p-3.5 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-800 flex items-center justify-between gap-3 shadow-sm animate-in fade-in">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-200 dark:bg-amber-900/60 flex items-center justify-center text-amber-800 dark:text-amber-200 flex-shrink-0">
              <CloudUpload className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-bold text-amber-900 dark:text-amber-200">
                {offlinePendingCount} {offlinePendingCount === 1 ? "avaliação salva" : "avaliações salvas"} no celular
              </p>
              <p className="text-[11px] text-amber-700 dark:text-amber-400">
                Aguardando conexão com a internet para transmissão.
              </p>
            </div>
          </div>

          <button
            type="button"
            disabled={isSyncing || !isOnline}
            onClick={() => syncNow()}
            className="py-2 px-3 rounded-xl bg-amber-600 hover:bg-amber-700 disabled:bg-amber-300 dark:disabled:bg-amber-900 text-white font-bold text-xs shadow-sm flex items-center gap-1.5 touch-target flex-shrink-0"
          >
            {isSyncing ? (
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <span>Sincronizar</span>
            )}
          </button>
        </div>
      )}

      {/* Orientações Rápidas de Avaliação Presencial */}
      <div className="p-3.5 rounded-xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900 flex items-start gap-2.5 text-blue-900 dark:text-blue-200 text-xs">
        <Sparkles className="w-4 h-4 flex-shrink-0 mt-0.5 text-blue-600 dark:text-blue-400" />
        <div>
          <span className="font-bold">Regra de Estande:</span> Dirija-se ao estande indicado e toque em <strong>Avaliar Trabalho</strong> para escanear o QR Code de confirmação de presença no estande.
        </div>
      </div>

      {/* Mensagem de Erro (se houver) */}
      {errorMsg && (
        <div className="p-3.5 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 flex items-start gap-2.5 text-red-700 dark:text-red-300 text-sm">
          <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5 text-red-600 dark:text-red-400" />
          <div className="flex-1">
            <p className="font-semibold">Erro ao carregar</p>
            <p className="text-xs mt-0.5">{errorMsg}</p>
          </div>
          <button
            onClick={() => loadAllocations()}
            className="text-xs font-bold underline ml-2"
          >
            Tentar novamente
          </button>
        </div>
      )}

      {/* Barra de Filtros Segmentados */}
      <div className="flex items-center gap-1.5 p-1 rounded-xl bg-slate-200/80 dark:bg-slate-800">
        <button
          type="button"
          onClick={() => setFilter("ALL")}
          className={`flex-1 py-2 px-2 rounded-lg text-xs font-bold transition-all text-center touch-target ${
            filter === "ALL"
              ? "bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm"
              : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
          }`}
        >
          Todos ({totalCount})
        </button>
        <button
          type="button"
          onClick={() => setFilter("PENDING")}
          className={`flex-1 py-2 px-2 rounded-lg text-xs font-bold transition-all text-center touch-target ${
            filter === "PENDING"
              ? "bg-white dark:bg-slate-700 text-amber-700 dark:text-amber-300 shadow-sm"
              : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
          }`}
        >
          Pendentes ({pendingCount})
        </button>
        <button
          type="button"
          onClick={() => setFilter("COMPLETED")}
          className={`flex-1 py-2 px-2 rounded-lg text-xs font-bold transition-all text-center touch-target ${
            filter === "COMPLETED"
              ? "bg-white dark:bg-slate-700 text-teal-700 dark:text-teal-300 shadow-sm"
              : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
          }`}
        >
          Avaliados ({completedCount})
        </button>
      </div>

      {/* Campo de Busca Rápida */}
      {totalCount > 4 && (
        <div className="relative">
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Buscar por título, estande ou subárea..."
            className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-fecitel-blue-600"
          />
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
        </div>
      )}

      {/* Lista de Cards dos Trabalhos */}
      {isLoading ? (
        <div className="py-12 flex flex-col items-center justify-center text-slate-400">
          <div className="w-8 h-8 border-4 border-fecitel-blue-600 border-t-transparent rounded-full animate-spin mb-3" />
          <p className="text-xs font-medium">Carregando seus trabalhos alocados...</p>
        </div>
      ) : filteredAllocations.length === 0 ? (
        <div className="py-12 px-4 text-center rounded-2xl bg-white dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800">
          <div className="w-12 h-12 rounded-2xl bg-slate-100 dark:bg-slate-700 text-slate-400 flex items-center justify-center mx-auto mb-3">
            <Inbox className="w-6 h-6" />
          </div>
          <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200">
            {totalCount === 0
              ? "Nenhum trabalho alocado no momento"
              : "Nenhum trabalho encontrado neste filtro"}
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-xs mx-auto">
            {totalCount === 0
              ? "Sua lista será atualizada automaticamente assim que a Comissão Científica registrar sua presença na Sala dos Avaliadores."
              : "Tente selecionar outra aba de filtro ou limpar o campo de busca."}
          </p>
          {totalCount === 0 && (
            <button
              onClick={() => loadAllocations(true)}
              className="mt-4 px-4 py-2 rounded-xl bg-fecitel-blue-900 hover:bg-fecitel-blue-800 text-white text-xs font-bold shadow transition-all touch-target"
            >
              Verificar Novas Alocações
            </button>
          )}
        </div>
      ) : (
        <div className="space-y-3">
          {filteredAllocations.map((project) => {
            const isCompleted = project.status === "COMPLETED";
            const isQueued = isProjectInQueue(project.project_id);

            return (
              <div
                key={project.id}
                className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-sm hover:shadow-md transition-all flex flex-col justify-between gap-3"
              >
                {/* Linha Superior: Estande & Status */}
                <div className="flex items-center justify-between gap-2">
                  <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-800 text-fecitel-blue-900 dark:text-blue-300 font-black text-xs">
                    <MapPin className="w-3.5 h-3.5 text-fecitel-blue-600 dark:text-blue-400" />
                    <span>ESTANDE {project.booth_number || "A DEFINIR"}</span>
                  </div>

                  {isQueued ? (
                    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-50 dark:bg-amber-950/60 border border-amber-300 dark:border-amber-800 text-amber-700 dark:text-amber-300 font-bold text-[11px]">
                      <Clock className="w-3.5 h-3.5 text-amber-600 animate-pulse" />
                      <span>Salvo no Celular</span>
                    </span>
                  ) : isCompleted ? (
                    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-teal-50 dark:bg-teal-950/60 border border-teal-200 dark:border-teal-800 text-teal-700 dark:text-teal-300 font-bold text-[11px]">
                      <CheckCircle2 className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
                      <span>Concluído</span>
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-50 dark:bg-amber-950/60 border border-amber-200 dark:border-amber-800 text-amber-700 dark:text-amber-300 font-bold text-[11px]">
                      <Clock className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                      <span>Pendente</span>
                    </span>
                  )}
                </div>

                {/* Título Oficial do Projeto */}
                <div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white leading-snug line-clamp-2">
                    {project.project_title}
                  </h3>

                  {/* Subárea e Área de Conhecimento */}
                  <div className="flex items-center gap-1.5 mt-2 text-slate-500 dark:text-slate-400 text-xs">
                    <Tag className="w-3.5 h-3.5 flex-shrink-0 text-slate-400" />
                    <span className="truncate">
                      {project.subarea_name}
                      {project.area_name ? ` • ${project.area_name}` : ""}
                    </span>
                  </div>
                </div>

                {/* Botão de Ação Tátil */}
                <button
                  type="button"
                  onClick={() => handleStartEvaluation(project)}
                  className={`w-full py-3 px-4 rounded-xl font-bold text-sm shadow-md transition-all flex items-center justify-center gap-2 touch-target ${
                    isQueued
                      ? "bg-amber-100 dark:bg-amber-950/50 hover:bg-amber-200 text-amber-900 dark:text-amber-200 border border-amber-300 dark:border-amber-800"
                      : isCompleted
                      ? "bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 text-slate-700 dark:text-slate-200"
                      : "bg-fecitel-blue-900 hover:bg-fecitel-blue-800 active:scale-[0.99] text-white shadow-blue-950/20"
                  }`}
                >
                  {isQueued ? (
                    <>
                      <Eye className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                      <span>Ver Avaliação Salva no Celular</span>
                    </>
                  ) : isCompleted ? (
                    <>
                      <Eye className="w-4 h-4 text-teal-600 dark:text-teal-400" />
                      <span>Ver / Revisar Avaliação</span>
                    </>
                  ) : (
                    <>
                      <QrCode className="w-4 h-4 text-teal-400" />
                      <span>Avaliar Trabalho (Validar Estande)</span>
                      <ArrowRight className="w-4 h-4 ml-auto" />
                    </>
                  )}
                </button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
