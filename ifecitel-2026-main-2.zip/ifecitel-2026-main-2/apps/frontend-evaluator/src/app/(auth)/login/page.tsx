"use client";

import React, { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/context/AuthContext";
import { KeyRound, Mail, ArrowRight, CheckCircle2, AlertCircle, Sparkles, ShieldCheck } from "lucide-react";

export default function LoginPage() {
  const router = useRouter();
  const { isAuthenticated, isLoading, loginWithCode, requestCode } = useAuth();

  const [step, setStep] = useState<"EMAIL" | "CODE">("EMAIL");
  const [email, setEmail] = useState("");
  const [accessCode, setAccessCode] = useState("");
  const [devCode, setDevCode] = useState<string | null>(null);

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  useEffect(() => {
    if (!isLoading && isAuthenticated) {
      router.replace("/projects");
    }
  }, [isAuthenticated, isLoading, router]);

  const handleRequestCode = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    if (!email.trim() || !email.includes("@")) {
      setErrorMsg("Informe um endereço de e-mail válido.");
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await requestCode(email);
      setSuccessMsg(res.message || "Código de acesso enviado para seu e-mail!");
      if (res.dev_code) {
        setDevCode(res.dev_code);
      }
      setStep("CODE");
    } catch (err: any) {
      const detail = err.response?.data?.detail || "Falha ao solicitar código. Verifique se o e-mail está cadastrado na feira.";
      setErrorMsg(detail);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleVerifyCode = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    const cleanCode = accessCode.trim().toUpperCase();
    if (cleanCode.length !== 8) {
      setErrorMsg("O código de acesso deve conter exatamente 8 caracteres alfanuméricos.");
      return;
    }

    setIsSubmitting(true);
    try {
      await loginWithCode(email, cleanCode);
      router.replace("/projects");
    } catch (err: any) {
      const detail = err.response?.data?.detail || "Código de acesso incorreto ou expirado. Tente novamente.";
      setErrorMsg(detail);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-6 text-slate-500">
        <div className="w-8 h-8 border-4 border-fecitel-blue-600 border-t-transparent rounded-full animate-spin mb-4" />
        <p className="text-sm font-medium">Carregando autenticação...</p>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col justify-between p-6">
      {/* Cabeçalho Institucional Mobile */}
      <div className="pt-6 text-center">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-fecitel-blue-900 text-white shadow-lg mb-4 ring-4 ring-blue-100 dark:ring-blue-950">
          <KeyRound className="w-8 h-8 text-teal-400" />
        </div>
        <h1 className="text-2xl font-black tracking-tight text-fecitel-blue-900 dark:text-blue-400">
          EasyEvent
        </h1>
        <p className="text-xs font-semibold uppercase tracking-widest text-teal-600 dark:text-teal-400 mt-0.5">
          Gestão e Avaliação de Eventos
        </p>
        <p className="text-sm text-slate-600 dark:text-slate-400 mt-2 font-medium">
          Portal de Avaliação Presencial
        </p>
      </div>

      {/* Formulário Interativo em Duas Etapas */}
      <div className="my-auto py-6">
        {errorMsg && (
          <div className="mb-4 p-3.5 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 flex items-start gap-2.5 text-red-700 dark:text-red-300 text-sm">
            <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5 text-red-600 dark:text-red-400" />
            <span>{errorMsg}</span>
          </div>
        )}

        {successMsg && (
          <div className="mb-4 p-3.5 rounded-xl bg-teal-50 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-900 flex items-start gap-2.5 text-teal-800 dark:text-teal-300 text-sm">
            <CheckCircle2 className="w-5 h-5 flex-shrink-0 mt-0.5 text-teal-600 dark:text-teal-400" />
            <span>{successMsg}</span>
          </div>
        )}

        {step === "EMAIL" ? (
          <form onSubmit={handleRequestCode} className="space-y-4">
            <div>
              <label htmlFor="email" className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300 mb-1.5">
                E-mail do Avaliador
              </label>
              <div className="relative">
                <input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="avaliador@exemplo.com"
                  required
                  autoFocus
                  autoComplete="email"
                  className="w-full pl-11 pr-4 py-3.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-fecitel-blue-600 font-medium text-base touch-target"
                />
                <Mail className="w-5 h-5 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1.5">
                Digite o e-mail cadastrado na comissão de avaliação da feira.
              </p>
            </div>

            <button
              type="submit"
              disabled={isSubmitting || !email.trim()}
              className="w-full py-3.5 px-4 rounded-xl bg-fecitel-blue-900 hover:bg-fecitel-blue-800 active:scale-[0.99] text-white font-bold text-base shadow-lg shadow-blue-950/20 transition-all flex items-center justify-center gap-2 touch-target disabled:opacity-50"
            >
              {isSubmitting ? (
                <>
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Enviando código...</span>
                </>
              ) : (
                <>
                  <span>Solicitar Código de Acesso</span>
                  <ArrowRight className="w-5 h-5" />
                </>
              )}
            </button>

            <div className="text-center pt-2">
              <button
                type="button"
                onClick={() => setStep("CODE")}
                className="text-xs font-semibold text-fecitel-blue-600 dark:text-blue-400 hover:underline py-2"
              >
                Já possuo meu código de 8 caracteres →
              </button>
            </div>
          </form>
        ) : (
          <form onSubmit={handleVerifyCode} className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label htmlFor="accessCode" className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300">
                  Código de Acesso (8 dígitos)
                </label>
                <span className="text-[11px] font-mono text-slate-500">
                  {accessCode.length}/8
                </span>
              </div>
              <div className="relative">
                <input
                  id="accessCode"
                  type="text"
                  maxLength={8}
                  value={accessCode}
                  onChange={(e) => setAccessCode(e.target.value.toUpperCase())}
                  placeholder="EX: 26AB1234"
                  required
                  autoFocus
                  autoComplete="one-time-code"
                  className="w-full px-4 py-3.5 text-center tracking-[0.3em] font-mono font-black text-2xl rounded-xl border-2 border-fecitel-blue-600 dark:border-blue-500 bg-white dark:bg-slate-800 text-fecitel-blue-900 dark:text-white placeholder-slate-300 focus:outline-none focus:ring-4 focus:ring-blue-100 dark:focus:ring-blue-900 touch-target"
                />
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1.5 text-center">
                Insira o código alfanumérico enviado para: <br />
                <span className="font-semibold text-slate-700 dark:text-slate-200">{email || "seu e-mail"}</span>
              </p>
            </div>

            {/* Facilidade para Modo de Desenvolvimento / Testes */}
            {devCode && (
              <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-center">
                <div className="flex items-center justify-center gap-1.5 text-xs font-bold text-amber-800 dark:text-amber-300 mb-1">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Código de Acesso Detectado:</span>
                </div>
                <button
                  type="button"
                  onClick={() => setAccessCode(devCode)}
                  className="px-3 py-1.5 rounded-lg bg-amber-200 dark:bg-amber-900 hover:bg-amber-300 text-amber-900 dark:text-amber-100 font-mono font-bold text-sm transition-colors"
                >
                  {devCode} (Clique para preencher)
                </button>
              </div>
            )}

            <button
              type="submit"
              disabled={isSubmitting || accessCode.trim().length !== 8}
              className="w-full py-3.5 px-4 rounded-xl bg-teal-600 hover:bg-teal-700 active:scale-[0.99] text-white font-bold text-base shadow-lg shadow-teal-900/20 transition-all flex items-center justify-center gap-2 touch-target disabled:opacity-50"
            >
              {isSubmitting ? (
                <>
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Validando código...</span>
                </>
              ) : (
                <>
                  <ShieldCheck className="w-5 h-5" />
                  <span>Entrar na Avaliação</span>
                </>
              )}
            </button>

            <div className="flex items-center justify-between pt-2">
              <button
                type="button"
                onClick={() => setStep("EMAIL")}
                className="text-xs font-medium text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 py-2"
              >
                ← Alterar e-mail
              </button>
              <button
                type="button"
                onClick={handleRequestCode}
                disabled={isSubmitting}
                className="text-xs font-semibold text-fecitel-blue-600 dark:text-blue-400 hover:underline py-2"
              >
                Reenviar código
              </button>
            </div>
          </form>
        )}
      </div>

      {/* Rodapé Informativo e Seguro */}
      <div className="pt-6 pb-2 border-t border-slate-200 dark:border-slate-800 text-center">
        <div className="flex items-center justify-center gap-1.5 text-xs text-slate-500 dark:text-slate-400 font-medium">
          <ShieldCheck className="w-4 h-4 text-teal-600" />
          <span>Acesso Seguro sem Senhas Estáticas</span>
        </div>
        <p className="text-[11px] text-slate-400 dark:text-slate-500 mt-1">
          Plataforma de Avaliação Presencial de Eventos
        </p>
      </div>
    </div>
  );
}
