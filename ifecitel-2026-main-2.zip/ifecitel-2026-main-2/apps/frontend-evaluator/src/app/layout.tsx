import type { Metadata, Viewport } from "next";
import "./globals.css";
import { AuthProvider } from "@/context/AuthContext";
import { NetworkProvider } from "@/context/NetworkContext";
import ServiceWorkerRegister from "@/components/pwa/ServiceWorkerRegister";

export const metadata: Metadata = {
  title: "EasyEvent — Avaliação Presencial",
  description: "Módulo Mobile-First PWA para Avaliação Presencial de Feiras e Eventos",
  manifest: "/manifest.json",
  icons: {
    icon: "/favicon.ico",
    apple: "/icons/apple-touch-icon.png",
  },
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "EasyEvent Avaliação",
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  themeColor: "#1E3A8A",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR" className="h-full">
      <body className="h-full antialiased font-sans bg-slate-100 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col justify-start">
        <AuthProvider>
          <NetworkProvider>
            <ServiceWorkerRegister />
            <div className="w-full max-w-md mx-auto min-h-screen bg-white dark:bg-slate-900 shadow-2xl flex flex-col relative overflow-x-hidden">
              {children}
            </div>
          </NetworkProvider>
        </AuthProvider>
      </body>
    </html>
  );
}
