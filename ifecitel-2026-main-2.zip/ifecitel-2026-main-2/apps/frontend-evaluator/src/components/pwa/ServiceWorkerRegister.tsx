"use client";

import { useEffect } from "react";

export default function ServiceWorkerRegister() {
  useEffect(() => {
    if (typeof window !== "undefined" && "serviceWorker" in navigator) {
      if (process.env.NODE_ENV === "production") {
        window.addEventListener("load", () => {
          navigator.serviceWorker
            .register("/sw.js")
            .then((registration) => {
              console.log("PWA Service Worker ativo:", registration.scope);
            })
            .catch((err) => {
              console.warn("Falha no registro do Service Worker:", err);
            });
        });
      } else {
        // Em desenvolvimento, desregistrar o Service Worker e limpar caches
        // para não interferir com o Fast Refresh e compilação do Next.js
        navigator.serviceWorker.getRegistrations().then((registrations) => {
          for (const registration of registrations) {
            registration.unregister();
          }
        });
        if ("caches" in window) {
          caches.keys().then((keys) => {
            for (const key of keys) {
              caches.delete(key);
            }
          });
        }
      }
    }
  }, []);

  return null;
}
