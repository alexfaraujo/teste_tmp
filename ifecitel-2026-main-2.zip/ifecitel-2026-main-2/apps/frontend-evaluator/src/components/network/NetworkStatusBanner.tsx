"use client";

import React from "react";
import { useNetwork } from "@/context/NetworkContext";
import { CheckCircle2, CloudUpload, Loader2, WifiOff, X } from "lucide-react";

export default function NetworkStatusBanner() {
  const {
    isOnline,
    pendingCount,
    isSyncing,
    syncNotification,
    clearNotification,
    syncNow,
  } = useNetwork();

  // 1. Notificação de sincronização bem-sucedida
  if (syncNotification) {
    return (
      <div className="bg-emerald-600 text-white px-4 py-2.5 flex items-center justify-between text-xs font-semibold shadow-md animate-in slide-in-from-top duration-200">
        <div className="flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-200 flex-shrink-0" />
          <span>{syncNotification}</span>
        </div>
        <button
          type="button"
          onClick={clearNotification}
          className="p-1 rounded-md hover:bg-emerald-700 text-emerald-100 transition-colors ml-2"
          aria-label="Fechar aviso"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>
    );
  }

  // 2. Dispositivo desconectado (Offline)
  if (!isOnline) {
    return (
      <div className="bg-amber-500 text-amber-950 px-4 py-2 flex items-center justify-between text-xs font-semibold shadow-md animate-in slide-in-from-top duration-200">
        <div className="flex items-center gap-2">
          <WifiOff className="w-4 h-4 text-amber-900 flex-shrink-0 animate-pulse" />
          <div>
            <span className="font-black">Modo Offline</span>
            <span className="hidden sm:inline"> — Sem conexão. </span>
            <span className="text-[11px] opacity-90 block sm:inline">
              Avaliações salvas com segurança no aparelho.
            </span>
          </div>
        </div>
        {pendingCount > 0 && (
          <span className="px-2 py-0.5 rounded-full bg-amber-950 text-amber-100 text-[10px] font-mono font-bold">
            {pendingCount} pendente{pendingCount > 1 ? "s" : ""}
          </span>
        )}
      </div>
    );
  }

  // 3. Online mas existem avaliações salvas na fila aguardando sincronização
  if (pendingCount > 0) {
    return (
      <div className="bg-fecitel-blue-900 text-blue-100 px-4 py-2 flex items-center justify-between text-xs font-semibold shadow-md border-b border-blue-800 animate-in slide-in-from-top duration-200">
        <div className="flex items-center gap-2">
          <CloudUpload className="w-4 h-4 text-teal-400 flex-shrink-0" />
          <div>
            <span className="font-bold text-white">
              {pendingCount} {pendingCount === 1 ? "avaliação salva" : "avaliações salvas"}
            </span>
            <span className="text-[11px] text-blue-200 ml-1 hidden sm:inline">
              no celular aguardando sincronização.
            </span>
          </div>
        </div>

        <button
          type="button"
          disabled={isSyncing}
          onClick={() => syncNow()}
          className="py-1 px-2.5 rounded-lg bg-teal-500 hover:bg-teal-400 disabled:bg-teal-700 text-slate-950 text-[11px] font-bold shadow transition-all flex items-center gap-1.5 touch-target flex-shrink-0"
        >
          {isSyncing ? (
            <>
              <Loader2 className="w-3 h-3 animate-spin text-slate-950" />
              <span>Sincronizando...</span>
            </>
          ) : (
            <>
              <span>Sincronizar Agora</span>
            </>
          )}
        </button>
      </div>
    );
  }

  return null;
}
