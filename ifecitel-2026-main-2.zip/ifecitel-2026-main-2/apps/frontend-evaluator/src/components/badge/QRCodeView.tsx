"use client";

import React, { useEffect, useState } from "react";
import QRCode from "qrcode";
import { QrCode as QrCodeIcon } from "lucide-react";

interface QRCodeViewProps {
  value: string;
  size?: number;
  className?: string;
}

export default function QRCodeView({
  value,
  size = 180,
  className = "",
}: QRCodeViewProps) {
  const [svgContent, setSvgContent] = useState<string>("");

  useEffect(() => {
    if (!value) return;

    QRCode.toString(
      value,
      {
        type: "svg",
        margin: 2,
        errorCorrectionLevel: "M",
        color: {
          dark: "#0f172a",
          light: "#ffffff",
        },
      },
      (err, string) => {
        if (err) {
          console.error("Falha ao gerar QR Code:", err);
          return;
        }
        setSvgContent(string);
      }
    );
  }, [value]);

  return (
    <div
      className={`bg-white rounded-2xl p-3.5 shadow-md border border-slate-200/80 flex flex-col items-center justify-center text-center ${className}`}
    >
      {/* Container do QR Code SVG */}
      <div className="relative w-44 h-44 flex items-center justify-center bg-white rounded-xl overflow-hidden">
        {svgContent ? (
          <div
            className="w-full h-full flex items-center justify-center [&>svg]:w-full [&>svg]:h-full"
            dangerouslySetInnerHTML={{ __html: svgContent }}
          />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center text-slate-400 gap-1.5 animate-pulse">
            <QrCodeIcon className="w-8 h-8" />
            <span className="text-[10px] font-medium">Gerando QR Code...</span>
          </div>
        )}
      </div>

      {/* Identificador legível abaixo do QR Code */}
      <div className="mt-2.5 pt-2 border-t border-slate-100 w-full flex items-center justify-between px-2">
        <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400">
          Credencial
        </span>
        <span className="font-mono text-xs font-black tracking-wider text-slate-800">
          {value}
        </span>
      </div>
    </div>
  );
}
