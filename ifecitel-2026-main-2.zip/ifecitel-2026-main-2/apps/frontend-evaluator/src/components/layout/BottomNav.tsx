"use client";

import React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { ClipboardList, QrCode, UserCheck } from "lucide-react";

export default function BottomNav() {
  const pathname = usePathname();

  const isProjectsActive = pathname === "/projects";
  const isScanActive = pathname === "/scan";
  const isProfileActive = pathname === "/profile";

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 safe-bottom shadow-[0_-4px_16px_rgba(0,0,0,0.06)]">
      <div className="max-w-md mx-auto grid grid-cols-3 h-16">
        {/* Aba: Meus Trabalhos */}
        <Link
          href="/projects"
          className={`flex flex-col items-center justify-center transition-colors touch-target ${
            isProjectsActive
              ? "text-fecitel-blue-900 dark:text-blue-400 font-bold"
              : "text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 font-medium"
          }`}
        >
          <div className="relative">
            <ClipboardList className={`w-5 h-5 ${isProjectsActive ? "stroke-[2.5]" : ""}`} />
            {isProjectsActive && (
              <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-fecitel-blue-900 dark:bg-blue-400" />
            )}
          </div>
          <span className="text-[11px] mt-1">Trabalhos</span>
        </Link>

        {/* Aba: Escanear QR */}
        <Link
          href="/scan"
          className={`flex flex-col items-center justify-center transition-colors touch-target ${
            isScanActive
              ? "text-teal-600 dark:text-teal-400 font-bold"
              : "text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 font-medium"
          }`}
        >
          <div className="relative">
            <QrCode className={`w-5 h-5 ${isScanActive ? "stroke-[2.5]" : ""}`} />
            {isScanActive && (
              <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-teal-600 dark:bg-teal-400" />
            )}
          </div>
          <span className="text-[11px] mt-1">Escanear</span>
        </Link>

        {/* Aba: Meu Perfil / Crachá */}
        <Link
          href="/profile"
          className={`flex flex-col items-center justify-center transition-colors touch-target ${
            isProfileActive
              ? "text-fecitel-blue-900 dark:text-blue-400 font-bold"
              : "text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 font-medium"
          }`}
        >
          <div className="relative">
            <UserCheck className={`w-5 h-5 ${isProfileActive ? "stroke-[2.5]" : ""}`} />
            {isProfileActive && (
              <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-fecitel-blue-900 dark:bg-blue-400" />
            )}
          </div>
          <span className="text-[11px] mt-1">Crachá</span>
        </Link>
      </div>
    </nav>
  );
}
