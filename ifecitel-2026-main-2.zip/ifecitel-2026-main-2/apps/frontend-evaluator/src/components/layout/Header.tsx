"use client";

import React, { useState } from "react";
import { useAuth } from "@/context/AuthContext";
import Link from "next/link";
import { Award, LogOut, User, Wifi } from "lucide-react";

export default function Header() {
  const { user, logout } = useAuth();
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-fecitel-blue-900 text-white shadow-md border-b border-blue-950">
      <div className="px-4 py-3 flex items-center justify-between">
        {/* Marca EasyEvent */}
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-teal-500/20 border border-teal-400/40 flex items-center justify-center text-teal-300">
            <Award className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-black tracking-tight text-base leading-none">EasyEvent</span>
              <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-semibold bg-teal-500/20 text-teal-300 border border-teal-500/30">
                PWA
              </span>
            </div>
            <p className="text-[11px] text-blue-200 font-medium leading-tight mt-0.5">
              Avaliação de Trabalhos
            </p>
          </div>
        </div>

        {/* Avaliador Conectado & Ações */}
        <div className="flex items-center gap-1.5">
          <Link
            href="/profile"
            className="flex items-center gap-2 p-1.5 rounded-xl hover:bg-white/10 active:scale-95 transition-all text-left"
            title="Ver meu crachá e perfil"
          >
            <div className="w-8 h-8 rounded-xl bg-teal-400/20 border border-teal-400/30 flex items-center justify-center text-teal-300 font-black text-xs">
              <User className="w-4 h-4" />
            </div>
            <div className="text-left hidden sm:block">
              <p className="text-xs font-semibold leading-tight max-w-[120px] truncate text-white">
                {user?.name || "Avaliador"}
              </p>
              <div className="flex items-center gap-1 text-[10px] text-teal-300">
                <span className="w-1.5 h-1.5 rounded-full bg-teal-400 animate-pulse" />
                <span>Crachá</span>
              </div>
            </div>
          </Link>

          <button
            onClick={() => setShowLogoutConfirm(true)}
            aria-label="Sair da conta"
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 active:scale-95 text-blue-200 hover:text-white transition-all touch-target flex items-center justify-center"
          >
            <LogOut className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Modal de Confirmação de Logout */}
      {showLogoutConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm">
          <div className="w-full max-w-xs rounded-2xl bg-white dark:bg-slate-900 p-5 text-slate-900 dark:text-white shadow-2xl border border-slate-200 dark:border-slate-800 animate-in fade-in zoom-in-95 duration-150">
            <div className="w-12 h-12 rounded-xl bg-red-100 dark:bg-red-950/50 text-red-600 dark:text-red-400 flex items-center justify-center mx-auto mb-3">
              <LogOut className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-center">Encerrar Sessão?</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 text-center mt-1 mb-4">
              Você precisará do seu código de 8 caracteres para autenticar novamente.
            </p>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setShowLogoutConfirm(false)}
                className="py-2.5 px-3 rounded-xl border border-slate-300 dark:border-slate-700 font-medium text-xs text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 touch-target"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowLogoutConfirm(false);
                  logout();
                }}
                className="py-2.5 px-3 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs shadow-md shadow-red-900/20 touch-target"
              >
                Sim, Sair
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
