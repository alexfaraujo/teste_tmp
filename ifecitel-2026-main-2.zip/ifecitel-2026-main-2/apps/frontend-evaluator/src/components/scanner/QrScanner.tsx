"use client";

import React, { useEffect, useRef, useState } from "react";
import { Camera, RefreshCw, AlertCircle, Sparkles, SwitchCamera, Keyboard } from "lucide-react";
import { Html5Qrcode } from "html5-qrcode";

interface QrScannerProps {
  onScanSuccess: (decodedText: string) => void;
  expectedToken?: string | null;
  boothNumber?: string | null;
}

export default function QrScanner({
  onScanSuccess,
  expectedToken,
  boothNumber,
}: QrScannerProps) {
  const scannerRef = useRef<Html5Qrcode | null>(null);
  const containerId = "html5-qr-scanner-viewport";

  const [cameraActive, setCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [facingMode, setFacingMode] = useState<"environment" | "user">("environment");
  const [manualCode, setManualCode] = useState("");
  const [showManualInput, setShowManualInput] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);

  useEffect(() => {
    let isMounted = true;

    async function startCamera() {
      try {
        setCameraError(null);

        // Se já houver instância rodando, parar antes de recriar
        if (scannerRef.current) {
          try {
            if (scannerRef.current.isScanning) {
              await scannerRef.current.stop();
            }
            await scannerRef.current.clear();
          } catch (e) {
            console.warn("Erro ao limpar scanner anterior:", e);
          }
        }

        const scanner = new Html5Qrcode(containerId);
        scannerRef.current = scanner;

        const config = {
          fps: 10,
          qrbox: { width: 220, height: 220 },
          aspectRatio: 1.0,
        };

        await scanner.start(
          { facingMode: facingMode },
          config,
          (decodedText) => {
            if (!isMounted || isProcessing) return;
            handleSuccess(decodedText);
          },
          () => {
            // Ignorar frames sem QR code para não poluir logs
          }
        );

        if (isMounted) {
          setCameraActive(true);
        }
      } catch (err: any) {
        console.warn("Falha ao inicializar câmera:", err);
        if (isMounted) {
          setCameraActive(false);
          setCameraError(
            "Não foi possível acessar a câmera do dispositivo (permissão não concedida ou sem HTTPS). Utilize a entrada manual de código abaixo para testar."
          );
          setShowManualInput(true);
        }
      }
    }

    startCamera();

    return () => {
      isMounted = false;
      if (scannerRef.current) {
        try {
          if (scannerRef.current.isScanning) {
            scannerRef.current.stop().catch(() => {});
          }
          scannerRef.current.clear();
        } catch (e) {
          // ignore cleanup errors
        }
      }
    };
  }, [facingMode]);

  const handleSuccess = async (decodedText: string) => {
    setIsProcessing(true);
    // Pausar a câmera após leitura para evitar leituras em loop
    if (scannerRef.current && scannerRef.current.isScanning) {
      try {
        await scannerRef.current.pause(true);
      } catch (e) {
        // ignore
      }
    }
    onScanSuccess(decodedText.trim());
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualCode.trim()) return;
    setIsProcessing(true);
    onScanSuccess(manualCode.trim());
  };

  const toggleCamera = () => {
    setFacingMode((prev) => (prev === "environment" ? "user" : "environment"));
  };

  return (
    <div className="space-y-4">
      {/* Viewport da Câmera HTML5 */}
      <div className="relative rounded-2xl overflow-hidden bg-slate-950 border-2 border-slate-700 shadow-xl aspect-square max-w-[320px] mx-auto flex items-center justify-center">
        <div id={containerId} className="w-full h-full object-cover" />

        {/* Mira Tátil sobreposta */}
        {cameraActive && !isProcessing && (
          <div className="pointer-events-none absolute inset-0 flex items-center justify-center p-8">
            <div className="w-52 h-52 relative border-2 border-teal-400/80 rounded-2xl animate-pulse">
              <div className="absolute -top-1 -left-1 w-6 h-6 border-t-4 border-l-4 border-teal-400 rounded-tl-lg" />
              <div className="absolute -top-1 -right-1 w-6 h-6 border-t-4 border-r-4 border-teal-400 rounded-tr-lg" />
              <div className="absolute -bottom-1 -left-1 w-6 h-6 border-b-4 border-l-4 border-teal-400 rounded-bl-lg" />
              <div className="absolute -bottom-1 -right-1 w-6 h-6 border-b-4 border-r-4 border-teal-400 rounded-br-lg" />
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-[10px] uppercase tracking-wider font-bold text-teal-300 bg-slate-900/80 px-2 py-0.5 rounded-full">
                  Mire no QR Code
                </span>
              </div>
            </div>
          </div>
        )}

        {/* Overlay de Processamento */}
        {isProcessing && (
          <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-xs flex flex-col items-center justify-center text-white p-4">
            <RefreshCw className="w-8 h-8 text-teal-400 animate-spin mb-2" />
            <p className="text-xs font-bold">Validando estande...</p>
          </div>
        )}

        {/* Mensagem de Câmera Desativada / Erro */}
        {!cameraActive && !isProcessing && (
          <div className="p-6 text-center text-slate-400 flex flex-col items-center justify-center">
            <Camera className="w-10 h-10 text-slate-600 mb-2" />
            <p className="text-xs font-semibold text-slate-300">Câmera indisponível</p>
            <p className="text-[11px] text-slate-500 mt-1 max-w-[200px]">
              Use a digitação manual do código logo abaixo.
            </p>
          </div>
        )}

        {/* Botão de Alternar Câmera (se ativa) */}
        {cameraActive && (
          <button
            type="button"
            onClick={toggleCamera}
            className="absolute top-3 right-3 p-2 rounded-xl bg-slate-900/80 hover:bg-slate-800 text-white shadow-md border border-slate-700 active:scale-95 touch-target flex items-center justify-center"
            title="Alternar Câmera"
          >
            <SwitchCamera className="w-4 h-4 text-teal-400" />
          </button>
        )}
      </div>

      {/* Alerta de Câmera com Orientação de Fallback */}
      {cameraError && (
        <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 flex items-start gap-2 text-amber-800 dark:text-amber-200 text-xs">
          <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5 text-amber-600 dark:text-amber-400" />
          <span>{cameraError}</span>
        </div>
      )}

      {/* Fallback de Entrada Manual de Código / Token */}
      <div className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-xs font-bold text-slate-700 dark:text-slate-200">
            <Keyboard className="w-4 h-4 text-fecitel-blue-600 dark:text-blue-400" />
            <span>Validação por Código Manual</span>
          </div>
          <button
            type="button"
            onClick={() => setShowManualInput(!showManualInput)}
            className="text-[11px] font-semibold text-fecitel-blue-600 dark:text-blue-400 hover:underline"
          >
            {showManualInput ? "Ocultar" : "Digitar Código"}
          </button>
        </div>

        {showManualInput && (
          <form onSubmit={handleManualSubmit} className="space-y-2 pt-1">
            <div className="relative">
              <input
                type="text"
                value={manualCode}
                onChange={(e) => setManualCode(e.target.value.trim())}
                placeholder="Ex: QR-A-944ed2 ou código do estande"
                className="w-full px-3.5 py-3 rounded-xl border border-slate-300 dark:border-slate-600 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white text-xs font-mono font-bold focus:outline-none focus:ring-2 focus:ring-fecitel-blue-600 touch-target"
              />
            </div>

            {expectedToken && (
              <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
                <span>Código esperado do estande:</span>
                <button
                  type="button"
                  onClick={() => setManualCode(expectedToken)}
                  className="font-mono font-bold text-teal-600 dark:text-teal-400 hover:underline"
                >
                  {expectedToken} (Preencher)
                </button>
              </div>
            )}

            <button
              type="submit"
              disabled={isProcessing || !manualCode.trim()}
              className="w-full py-3 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold shadow-md shadow-teal-950/20 active:scale-[0.99] transition-all touch-target disabled:opacity-50"
            >
              {isProcessing ? "Validando..." : "Validar Código do Estande"}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
