"use client";

import React, { useState, useEffect } from "react";
import { Minus, Plus, Edit2 } from "lucide-react";

interface ScoreStepperProps {
  value: number;
  onChange: (val: number) => void;
  maxScore?: number;
  minScore?: number;
}

export default function ScoreStepper({
  value,
  onChange,
  maxScore = 10.0,
  minScore = 0.0,
}: ScoreStepperProps) {
  // Estado local para digitação fluida de números reais (ex: "8", "8.", "8.5" ou "8,5")
  const [inputText, setInputText] = useState<string>(value.toFixed(1));
  const [isFocused, setIsFocused] = useState<boolean>(false);

  // Sincronizar o input quando o valor externo mudar e o campo não estiver em foco
  useEffect(() => {
    if (!isFocused) {
      setInputText(value.toFixed(1));
    }
  }, [value, isFocused]);

  const triggerHaptic = () => {
    if (typeof window !== "undefined" && "vibrate" in navigator) {
      try {
        navigator.vibrate(15);
      } catch (e) {
        // ignore
      }
    }
  };

  const updateScore = (newScore: number) => {
    triggerHaptic();
    const clamped = Math.max(minScore, Math.min(maxScore, newScore));
    const rounded = Math.round(clamped * 10) / 10;
    onChange(rounded);
    setInputText(rounded.toFixed(1));
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = e.target.value;

    // Se o usuário limpar o campo
    if (raw === "") {
      setInputText("");
      return;
    }

    // Máscara para número real: permitir apenas dígitos, ponto e vírgula
    let cleaned = raw.replace(/[^0-9.,]/g, "");

    // Limitar a apenas um único separador decimal (ponto ou vírgula)
    const sepIndex = cleaned.search(/[.,]/);
    if (sepIndex !== -1) {
      const sep = cleaned[sepIndex];
      const intPart = cleaned.slice(0, sepIndex);
      const decPart = cleaned.slice(sepIndex + 1).replace(/[.,]/g, "").slice(0, 1); // máximo 1 casa decimal
      cleaned = `${intPart}${sep}${decPart}`;
    }

    // Se começar com ponto ou vírgula, adicionar zero antes (ex: ",5" -> "0,5")
    if (cleaned.startsWith(".") || cleaned.startsWith(",")) {
      cleaned = `0${cleaned}`;
    }

    // Validar limites contra maxScore e minScore
    const normalized = cleaned.replace(",", ".");
    const parsed = parseFloat(normalized);

    if (!isNaN(parsed)) {
      if (parsed > maxScore) {
        cleaned = maxScore.toFixed(1);
        onChange(maxScore);
      } else if (parsed < minScore) {
        cleaned = minScore.toFixed(1);
        onChange(minScore);
      } else {
        // Se ainda está digitando o separador (ex: "8." ou "8,"), não altera float antes do decimal
        if (!cleaned.endsWith(".") && !cleaned.endsWith(",")) {
          onChange(Math.round(parsed * 10) / 10);
        }
      }
    }

    setInputText(cleaned);
  };

  const handleBlur = () => {
    setIsFocused(false);
    const normalized = inputText.replace(",", ".");
    const parsed = parseFloat(normalized);
    if (isNaN(parsed) || inputText.trim() === "") {
      onChange(minScore);
      setInputText(minScore.toFixed(1));
    } else {
      const clamped = Math.max(minScore, Math.min(maxScore, Math.round(parsed * 10) / 10));
      onChange(clamped);
      setInputText(clamped.toFixed(1));
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      (e.target as HTMLInputElement).blur();
    }
  };

  return (
    <div className="space-y-2">
      {/* Controles Táteis Principais (-0.5, -0.1, Input Editável Real, +0.1, +0.5) */}
      <div className="flex items-center justify-between gap-1.5 p-2 rounded-2xl bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
        {/* Decremento -0.5 */}
        <button
          type="button"
          onClick={() => updateScore(value - 0.5)}
          disabled={value <= minScore}
          aria-label="Diminuir 0.5 ponto"
          className="flex-1 h-12 rounded-xl bg-white dark:bg-slate-800 hover:bg-slate-50 text-slate-800 dark:text-slate-200 font-bold text-xs border border-slate-200 dark:border-slate-700 shadow-sm active:scale-95 disabled:opacity-30 touch-target flex items-center justify-center"
        >
          -0.5
        </button>

        {/* Decremento -0.1 */}
        <button
          type="button"
          onClick={() => updateScore(value - 0.1)}
          disabled={value <= minScore}
          aria-label="Diminuir 0.1 ponto"
          className="w-12 h-12 rounded-xl bg-white dark:bg-slate-800 hover:bg-slate-50 text-slate-800 dark:text-slate-200 font-bold border border-slate-200 dark:border-slate-700 shadow-sm active:scale-95 disabled:opacity-30 touch-target flex items-center justify-center"
        >
          <Minus className="w-4 h-4" />
        </button>

        {/* Campo Central Editável com Máscara para Número Real */}
        <div className="flex flex-col items-center justify-center px-1">
          <input
            type="text"
            inputMode="decimal"
            value={inputText}
            onChange={handleInputChange}
            onBlur={handleBlur}
            onKeyDown={handleKeyDown}
            onFocus={(e) => {
              setIsFocused(true);
              e.target.select();
            }}
            placeholder="0.0"
            aria-label="Digitar nota do critério"
            className="w-24 h-12 text-center font-mono text-2xl font-black text-fecitel-blue-900 dark:text-blue-400 bg-white dark:bg-slate-800 border-2 border-slate-300 dark:border-slate-600 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-teal-500 shadow-inner"
          />
          <span className="block text-[9px] font-semibold uppercase tracking-wider text-slate-400 mt-1">
            máx: {maxScore.toFixed(1)} pts
          </span>
        </div>

        {/* Incremento +0.1 */}
        <button
          type="button"
          onClick={() => updateScore(value + 0.1)}
          disabled={value >= maxScore}
          aria-label="Aumentar 0.1 ponto"
          className="w-12 h-12 rounded-xl bg-white dark:bg-slate-800 hover:bg-slate-50 text-slate-800 dark:text-slate-200 font-bold border border-slate-200 dark:border-slate-700 shadow-sm active:scale-95 disabled:opacity-30 touch-target flex items-center justify-center"
        >
          <Plus className="w-4 h-4" />
        </button>

        {/* Incremento +0.5 */}
        <button
          type="button"
          onClick={() => updateScore(value + 0.5)}
          disabled={value >= maxScore}
          aria-label="Aumentar 0.5 ponto"
          className="flex-1 h-12 rounded-xl bg-teal-50 dark:bg-teal-950/60 hover:bg-teal-100 text-teal-800 dark:text-teal-300 font-bold text-xs border border-teal-200 dark:border-teal-800 shadow-sm active:scale-95 disabled:opacity-30 touch-target flex items-center justify-center"
        >
          +0.5
        </button>
      </div>

      {/* Instrução Amigável e Neutra */}
      <div className="flex items-center justify-center gap-1.5 text-[11px] text-slate-500 dark:text-slate-400 pt-0.5">
        <Edit2 className="w-3 h-3 text-slate-400 flex-shrink-0" />
        <span>Digite a nota diretamente no campo central ou ajuste nos botões <strong>+/-</strong></span>
      </div>
    </div>
  );
}
