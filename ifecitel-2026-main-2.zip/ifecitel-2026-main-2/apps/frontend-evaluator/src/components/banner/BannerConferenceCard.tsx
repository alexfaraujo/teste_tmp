"use client";

import React from "react";
import { EvaluationSheetResponse } from "@/types";
import {
  Award,
  BookOpen,
  CheckCircle2,
  FileText,
  GraduationCap,
  MapPin,
  School,
  Sparkles,
  Tag,
  Users,
  ArrowRight,
} from "lucide-react";

interface BannerConferenceCardProps {
  sheet: EvaluationSheetResponse;
  onProceedToGrading: () => void;
  proceedButtonLabel?: string;
}

export default function BannerConferenceCard({
  sheet,
  onProceedToGrading,
  proceedButtonLabel = "Avançar para Avaliação e Notas",
}: BannerConferenceCardProps) {
  const isScientific = sheet.project_type === "SCIENTIFIC";

  return (
    <div className="space-y-4">
      {/* Selo de Orientação de Conferência */}
      <div className="p-3.5 rounded-2xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 flex items-start gap-2.5 text-xs text-blue-900 dark:text-blue-200">
        <Sparkles className="w-4 h-4 text-blue-600 dark:text-blue-400 flex-shrink-0 mt-0.5" />
        <div>
          <span className="font-bold">Conferência do Banner Físico:</span> Verifique se o título, autores e orientadores abaixo correspondem aos dados impressos no banner exposto no estande.
        </div>
      </div>

      {/* Cartão de Identificação Geral do Trabalho */}
      <div className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-sm space-y-3">
        {/* Estande & Tipo de Projeto */}
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-fecitel-blue-50 dark:bg-blue-950/60 border border-fecitel-blue-200 dark:border-blue-800 text-fecitel-blue-900 dark:text-blue-300 font-black text-xs">
            <MapPin className="w-3.5 h-3.5 text-fecitel-blue-600" />
            <span>ESTANDE {sheet.booth_number || "A DEFINIR"}</span>
          </div>

          <span
            className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-xl text-xs font-bold ${
              isScientific
                ? "bg-teal-50 dark:bg-teal-950/50 text-teal-700 dark:text-teal-300 border border-teal-200 dark:border-teal-800"
                : "bg-purple-50 dark:bg-purple-950/50 text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-800"
            }`}
          >
            {isScientific ? "🔬 Científico" : "⚙️ Tecnológico"}
          </span>
        </div>

        {/* Título do Projeto */}
        <div>
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
            Título Oficial
          </span>
          <h2 className="text-base font-extrabold text-slate-900 dark:text-white leading-snug mt-0.5">
            {sheet.title}
          </h2>
        </div>

        {/* Área e Subárea */}
        <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-100 dark:border-slate-700/60 flex items-center gap-2 text-xs">
          <Tag className="w-4 h-4 text-fecitel-blue-600 dark:text-blue-400 flex-shrink-0" />
          <div className="truncate">
            <span className="font-bold text-slate-700 dark:text-slate-200">
              {sheet.subarea_name}
            </span>
            {sheet.area_name && (
              <span className="text-slate-500 dark:text-slate-400">
                {" "}• {sheet.area_name}
              </span>
            )}
            {sheet.education_level && (
              <span className="text-teal-600 dark:text-teal-400 font-semibold">
                {" "}• Nível: {sheet.education_level}
              </span>
            )}
          </div>
        </div>

        {/* Escola / Instituição */}
        {sheet.school_name && (
          <div className="flex items-start gap-2 text-xs text-slate-600 dark:text-slate-300">
            <School className="w-4 h-4 text-slate-400 flex-shrink-0 mt-0.5" />
            <div>
              <span className="font-bold text-slate-700 dark:text-slate-200">Escola:</span>{" "}
              <span>{sheet.school_name}</span>
            </div>
          </div>
        )}

        {/* Autores / Estudantes Pesquisadores */}
        <div className="pt-2 border-t border-slate-100 dark:border-slate-700 space-y-1.5">
          <div className="flex items-center gap-1.5 text-xs font-bold text-slate-700 dark:text-slate-200">
            <Users className="w-4 h-4 text-teal-600 dark:text-teal-400" />
            <span>Autores / Estudantes Pesquisadores:</span>
          </div>
          {sheet.authors && sheet.authors.length > 0 ? (
            <div className="flex flex-wrap gap-1.5">
              {sheet.authors.map((author, index) => (
                <span
                  key={index}
                  className="inline-flex items-center px-2.5 py-1 rounded-lg text-xs font-semibold bg-slate-100 dark:bg-slate-700 text-slate-800 dark:text-slate-200"
                >
                  {author}
                </span>
              ))}
            </div>
          ) : (
            <p className="text-xs text-slate-400 italic">Integrantes vinculados no formulário de inscrição.</p>
          )}
        </div>

        {/* Orientadores */}
        {(sheet.advisor_name || sheet.coadvisor_name) && (
          <div className="pt-2 border-t border-slate-100 dark:border-slate-700 space-y-1">
            <div className="flex items-center gap-1.5 text-xs font-bold text-slate-700 dark:text-slate-200">
              <GraduationCap className="w-4 h-4 text-fecitel-blue-600 dark:text-blue-400" />
              <span>Orientação:</span>
            </div>
            <div className="text-xs space-y-0.5 text-slate-600 dark:text-slate-300 pl-5">
              {sheet.advisor_name && (
                <p>
                  <strong>Orientador(a):</strong> {sheet.advisor_name}
                </p>
              )}
              {sheet.coadvisor_name && (
                <p>
                  <strong>Coorientador(a):</strong> {sheet.coadvisor_name}
                </p>
              )}
            </div>
          </div>
        )}

        {/* Resumo do Trabalho */}
        {sheet.abstract && (
          <div className="pt-2 border-t border-slate-100 dark:border-slate-700 space-y-1.5">
            <div className="flex items-center gap-1.5 text-xs font-bold text-slate-700 dark:text-slate-200">
              <FileText className="w-4 h-4 text-slate-400" />
              <span>Resumo do Trabalho:</span>
            </div>
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-900/40 text-xs text-slate-600 dark:text-slate-300 leading-relaxed max-h-48 overflow-y-auto">
              {sheet.abstract}
            </div>
          </div>
        )}
      </div>

      {/* Botão de Avanço para a Ficha de Notas */}
      <div className="pt-2">
        <button
          type="button"
          onClick={onProceedToGrading}
          className="w-full py-4 px-5 rounded-2xl bg-fecitel-blue-900 hover:bg-fecitel-blue-800 active:scale-[0.99] text-white font-bold text-sm shadow-xl shadow-blue-950/20 transition-all flex items-center justify-center gap-2 touch-target"
        >
          <span>{proceedButtonLabel}</span>
          <ArrowRight className="w-5 h-5 text-teal-400" />
        </button>
      </div>
    </div>
  );
}
