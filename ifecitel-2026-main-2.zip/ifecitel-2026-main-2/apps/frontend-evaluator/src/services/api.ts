import axios from "axios";

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000/api/v1";
const API_KEY = "fecitel_secret_api_key_2026";

export const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    "Content-Type": "application/json",
    "X-API-Key": API_KEY,
  },
});

// Interceptor de Requisição: Ajusta dinamicamente a baseURL para o IP da rede local e injeta Bearer Token
api.interceptors.request.use((config) => {
  if (typeof window !== "undefined") {
    const hostname = window.location.hostname;
    // Se acessado por IP da rede local (ex: celular em 192.168.x.x), direciona para a API no mesmo IP
    if (hostname && hostname !== "localhost" && hostname !== "127.0.0.1") {
      config.baseURL = `http://${hostname}:8000/api/v1`;
    }
    const token =
      localStorage.getItem("easyevent_evaluator_token") ||
      localStorage.getItem("fecitel_evaluator_token");
    if (token && config.headers) {
      config.headers.Authorization = `Bearer ${token}`;
    }
  }
  return config;
});

// Interceptor de Resposta: Redireciona para /login em caso de 401
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (typeof window !== "undefined" && error.response?.status === 401) {
      // Ignorar 401 da rota de verificação de código para exibir erro na tela de login
      if (!error.config?.url?.includes("/auth/verify-code") && !error.config?.url?.includes("/auth/request-code")) {
        localStorage.removeItem("easyevent_evaluator_token");
        localStorage.removeItem("easyevent_evaluator_user");
        localStorage.removeItem("fecitel_evaluator_token");
        localStorage.removeItem("fecitel_evaluator_user");
        if (window.location.pathname !== "/login") {
          window.location.href = "/login";
        }
      }
    }
    return Promise.reject(error);
  }
);

export default api;
