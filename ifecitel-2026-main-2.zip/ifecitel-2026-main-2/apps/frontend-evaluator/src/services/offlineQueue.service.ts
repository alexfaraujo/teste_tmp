import { EvaluationCreatePayload, QueuedEvaluation } from "@/types";
import evaluatorService from "./evaluator.service";

const QUEUE_STORAGE_KEY = "easyevent_offline_evaluation_queue";
const LEGACY_QUEUE_STORAGE_KEY = "fecitel_offline_evaluation_queue";

class OfflineQueueService {
  private isWindowAvailable(): boolean {
    return typeof window !== "undefined" && typeof window.localStorage !== "undefined";
  }

  public getQueue(): QueuedEvaluation[] {
    if (!this.isWindowAvailable()) return [];
    try {
      const raw = localStorage.getItem(QUEUE_STORAGE_KEY) || localStorage.getItem(LEGACY_QUEUE_STORAGE_KEY);
      if (!raw) return [];
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? parsed : [];
    } catch (err) {
      console.warn("Erro ao ler fila offline do localStorage:", err);
      return [];
    }
  }

  private saveQueue(queue: QueuedEvaluation[]): void {
    if (!this.isWindowAvailable()) return;
    try {
      localStorage.setItem(QUEUE_STORAGE_KEY, JSON.stringify(queue));
      // Limpa chave legada se vazia ou espelha
      localStorage.removeItem(LEGACY_QUEUE_STORAGE_KEY);
      window.dispatchEvent(new CustomEvent("easyevent:queue-updated"));
      window.dispatchEvent(new CustomEvent("fecitel:queue-updated"));
    } catch (err) {
      console.error("Falha ao salvar fila offline no localStorage:", err);
    }
  }

  public enqueue(item: {
    projectId: number;
    projectTitle: string;
    boothNumber?: string | null;
    payload: EvaluationCreatePayload;
  }): QueuedEvaluation {
    const queue = this.getQueue();
    // Remover duplicata do mesmo projeto se já existir
    const filtered = queue.filter((q) => q.projectId !== item.projectId);

    const queuedItem: QueuedEvaluation = {
      id: `eval_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      projectId: item.projectId,
      projectTitle: item.projectTitle,
      boothNumber: item.boothNumber,
      payload: item.payload,
      createdAt: new Date().toISOString(),
      attempts: 0,
      lastError: null,
    };

    filtered.push(queuedItem);
    this.saveQueue(filtered);
    return queuedItem;
  }

  public remove(id: string): void {
    const queue = this.getQueue();
    const filtered = queue.filter((q) => q.id !== id);
    this.saveQueue(filtered);
  }

  public removeByProjectId(projectId: number): void {
    const queue = this.getQueue();
    const filtered = queue.filter((q) => q.projectId !== projectId);
    this.saveQueue(filtered);
  }

  public isProjectQueued(projectId: number): boolean {
    return this.getQueue().some((q) => q.projectId === projectId);
  }

  public getQueuedByProjectId(projectId: number): QueuedEvaluation | undefined {
    return this.getQueue().find((q) => q.projectId === projectId);
  }

  public async syncQueue(): Promise<{ total: number; synced: number; failed: number }> {
    if (!this.isWindowAvailable() || !navigator.onLine) {
      return { total: 0, synced: 0, failed: 0 };
    }

    const queue = this.getQueue();
    if (queue.length === 0) {
      return { total: 0, synced: 0, failed: 0 };
    }

    let synced = 0;
    let failed = 0;
    const remainingQueue: QueuedEvaluation[] = [];

    for (const item of queue) {
      try {
        await evaluatorService.submitEvaluation(item.payload);
        synced++;
        // Limpar rascunhos de sessão/local se existirem
        try {
          sessionStorage.removeItem(`easyevent_scores_project_${item.projectId}`);
          sessionStorage.removeItem(`easyevent_feedback_project_${item.projectId}`);
          localStorage.removeItem(`easyevent_draft_scores_project_${item.projectId}`);
          localStorage.removeItem(`easyevent_draft_feedback_project_${item.projectId}`);
          sessionStorage.removeItem(`fecitel_scores_project_${item.projectId}`);
          sessionStorage.removeItem(`fecitel_feedback_project_${item.projectId}`);
          localStorage.removeItem(`fecitel_draft_scores_project_${item.projectId}`);
          localStorage.removeItem(`fecitel_draft_feedback_project_${item.projectId}`);
        } catch {
          // ignore
        }
      } catch (err: any) {
        failed++;
        console.warn(`Erro ao sincronizar avaliação do projeto #${item.projectId}:`, err);
        const errorMsg =
          err.response?.data?.detail || err.message || "Erro de conexão ao enviar";
        
        // Se for erro definitivo de autorização ou se projeto já foi concluído pelo avaliador
        if (err.response?.status === 400 && String(errorMsg).includes("já foi avaliado")) {
          // Já foi homologado no servidor, podemos remover com sucesso
          synced++;
        } else {
          remainingQueue.push({
            ...item,
            attempts: item.attempts + 1,
            lastError: errorMsg,
          });
        }
      }
    }

    this.saveQueue(remainingQueue);

    if (this.isWindowAvailable()) {
      window.dispatchEvent(
        new CustomEvent("easyevent:queue-synced", {
          detail: { total: queue.length, synced, failed },
        })
      );
      window.dispatchEvent(
        new CustomEvent("fecitel:queue-synced", {
          detail: { total: queue.length, synced, failed },
        })
      );
    }

    return { total: queue.length, synced, failed };
  }
}

const offlineQueueService = new OfflineQueueService();
export default offlineQueueService;
