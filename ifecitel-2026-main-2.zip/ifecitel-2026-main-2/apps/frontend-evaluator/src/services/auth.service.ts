import api from "./api";
import { TokenResponse, UserProfile } from "@/types";

export interface RequestCodeResponse {
  message: string;
  email: string;
  dev_code?: string;
}

export const authService = {
  /**
   * Solicita o envio do código OTP de 8 caracteres por e-mail para o avaliador.
   */
  async requestCode(email: string): Promise<RequestCodeResponse> {
    const response = await api.post<RequestCodeResponse>("/auth/request-code", {
      email: email.trim().toLowerCase(),
    });
    return response.data;
  },

  /**
   * Valida o código de acesso de 8 caracteres e obtém o token JWT Bearer.
   */
  async verifyCode(email: string, accessCode: string): Promise<TokenResponse> {
    const cleanCode = accessCode.trim().toUpperCase();
    const response = await api.post<TokenResponse>("/auth/verify-code", {
      email: email.trim().toLowerCase(),
      access_code: cleanCode,
    });

    if (response.data.access_token) {
      localStorage.setItem("easyevent_evaluator_token", response.data.access_token);
      localStorage.setItem(
        "easyevent_evaluator_user",
        JSON.stringify({
          id: response.data.id,
          name: response.data.name,
          email: response.data.email,
          role: response.data.role,
          barcode: response.data.barcode,
        })
      );
    }

    return response.data;
  },

  /**
   * Obtém os dados do perfil do usuário autenticado atual.
   */
  async getMe(): Promise<UserProfile> {
    const response = await api.get<UserProfile>("/auth/me");
    return response.data;
  },

  /**
   * Encerra a sessão do avaliador no dispositivo.
   */
  logout(): void {
    if (typeof window !== "undefined") {
      localStorage.removeItem("easyevent_evaluator_token");
      localStorage.removeItem("easyevent_evaluator_user");
      localStorage.removeItem("fecitel_evaluator_token");
      localStorage.removeItem("fecitel_evaluator_user");
      window.location.href = "/login";
    }
  },
};

export default authService;
