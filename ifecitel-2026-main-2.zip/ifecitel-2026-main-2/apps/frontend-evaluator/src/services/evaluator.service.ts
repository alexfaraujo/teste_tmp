import api from "./api";
import {
  AllocationItem,
  EvaluationCreatePayload,
  EvaluationResponse,
  EvaluationSheetResponse,
} from "@/types";

export const evaluatorService = {
  /**
   * Obtém os trabalhos alocados para o avaliador autenticado.
   */
  async getMyAllocations(eventId?: number): Promise<AllocationItem[]> {
    const params: Record<string, any> = {};
    if (eventId) {
      params.event_id = eventId;
    }
    const response = await api.get<AllocationItem[]>("/allocations/my", { params });
    return response.data;
  },

  /**
   * Carrega a ficha de avaliação adaptada lendo o token do QR Code do estande.
   */
  async getEvaluationSheet(qrcode: string): Promise<EvaluationSheetResponse> {
    const response = await api.get<EvaluationSheetResponse>("/evaluations/sheet", {
      params: { qrcode: qrcode.trim() },
    });
    return response.data;
  },

  /**
   * Carrega a ficha de avaliação diretamente pelo ID do projeto (modo somente-leitura ou consulta).
   */
  async getMyProjectEvaluationSheet(projectId: number): Promise<EvaluationSheetResponse> {
    const response = await api.get<EvaluationSheetResponse>(`/evaluations/project/${projectId}/my-sheet`);
    return response.data;
  },

  /**
   * Submete a avaliação e as notas com parecer geral consolidado único (BR-11, BR-12).
   */
  async submitEvaluation(payload: EvaluationCreatePayload): Promise<EvaluationResponse> {
    const response = await api.post<EvaluationResponse>("/evaluations", payload);
    return response.data;
  },

  /**
   * Obtém resumo oficial das avaliações e média do trabalho (BR-12).
   */
  async getProjectSummary(projectId: number): Promise<any> {
    const response = await api.get(`/evaluations/project/${projectId}/summary`);
    return response.data;
  },
};

export default evaluatorService;
