# FECITEL — Módulo do Avaliador Mobile-First (PWA)

<p align="center">
  <img src="https://img.shields.io/badge/Next.js-14+-000000?style=for-the-badge&logo=nextdotjs&logoColor=white" alt="Next.js 14+" />
  <img src="https://img.shields.io/badge/PWA-Mobile--First-5A0FC8?style=for-the-badge&logo=pwa&logoColor=white" alt="PWA Ready" />
  <img src="https://img.shields.io/badge/React-18+-61DAFB?style=for-the-badge&logo=react&logoColor=black" alt="React 18+" />
  <img src="https://img.shields.io/badge/TypeScript-5+-3178C6?style=for-the-badge&logo=typescript&logoColor=white" alt="TypeScript 5+" />
  <img src="https://img.shields.io/badge/Tailwind_CSS-3.4+-06B6D4?style=for-the-badge&logo=tailwindcss&logoColor=white" alt="Tailwind CSS" />
  <img src="https://img.shields.io/badge/QR_Scanner-HTML5%20Camera-10B981?style=for-the-badge&logo=qr-code&logoColor=white" alt="QR Scanner" />
  <img src="https://img.shields.io/badge/Touch_UX-One--Hand%20Design-FF6B6B?style=for-the-badge&logo=apple&logoColor=white" alt="Mobile Touch UX" />
</p>

---

## 1. Visão Geral do Módulo

O **`apps/frontend-evaluator`** é a aplicação web progressiva (**PWA Mobile-First**) concebida exclusivamente para o trabalho dinâmico dos avaliadores presenciais durante os dias de realização da **FECITEL**.

Otimizada especificamente para uso em smartphones com operação confortável por **uma única mão**, a aplicação elimina pranchetas de papel, garantindo rapidez no acesso às fichas de avaliação através da câmera do celular e segurança no envio das notas e pareceres consolidados.

### Principais Responsabilidades:
*   **Autenticação sem Senha Estática (OTP):** Login rápido digitando o código pessoal de 8 caracteres alfanuméricos em caixa alta recebido por e-mail, protegido por campo mascarado (`type="password"`).
*   **Leitor de QR Code de Bancada:** Ativação instantânea da câmera do smartphone para escanear a bancada do projeto e carregar imediatamente a ficha do trabalho alocado.
*   **Ajuste Tátil de Notas com Steppers (+ / -):** Interface tátil intuitiva com botões grandes de incremento e decremento para notas de 0.0 a 10.0 por critério, evitando erros de digitação em teclados virtuais pequenos.
*   **Parecer Consolidado Único:** Um único campo de texto de síntese qualitativa e observações gerais ao término da avaliação, orientando a evolução do projeto científico.
*   **Operação Resiliente PWA:** Armazenamento temporário de dados e estado em caso de instabilidades pontuais na rede Wi-Fi do pavilhão de exposições.

---

## 2. Tecnologias e Dependências Principais

| Tecnologia | Versão | Finalidade |
| :--- | :--- | :--- |
| **Next.js** | `14+ (App Router)` | Framework React com otimizações PWA e alta velocidade de renderização |
| **React** | `18+` | Construção de componentes táteis responsivos e fluidos |
| **TypeScript** | `5+` | Segurança de tipos para notas, critérios e dados do projeto avaliado |
| **Tailwind CSS** | `3.4+` | Estilização mobile com temas Dia/Noite e áreas de toque mínimas de 48px |
| **HTML5-QRCode** | `2.3+` | Acesso à câmera nativa para leitura instantânea de QR Codes de bancada |
| **Lucide React** | `0.350+` | Ícones para botões numéricos (`Plus`, `Minus`, `CheckCircle`, `QrCode`) |
| **Axios** | `1.6+` | Comunicação com o backend e envio assíncrono das avaliações |

---

## 3. Arquitetura e Organização de Diretórios

```
apps/frontend-evaluator/
├── src/
│   ├── app/                     # Next.js App Router (Mobile-First)
│   │   ├── (auth)/
│   │   │   └── login/           # Tela de login com código OTP de 8 caracteres
│   │   ├── (evaluator)/
│   │   │   ├── projects/        # Lista de projetos alocados ao avaliador
│   │   │   ├── scanner/         # Câmera com leitor de QR Code de bancada
│   │   │   ├── evaluate/[id]/   # Ficha digital com critérios, steppers e parecer
│   │   │   └── layout.tsx       # Layout mobile com barra inferior de navegação tátil
│   │   ├── globals.css          # Estilos globais e suporte a safe-area em celulares
│   │   ├── manifest.ts          # Manifesto PWA para instalação como app na tela inicial
│   │   └── layout.tsx           # Layout raiz com viewport meta tags mobile
│   ├── components/
│   │   ├── scanner/             # Componente de câmera e mira de leitura QR Code
│   │   ├── steppers/            # Controles táteis de notas (+ / -) com feedback sonoro/haptic
│   │   └── ui/                  # Cards de projetos, badges de área e botões táteis
│   ├── services/                # Integrações HTTP com a API FastAPI
│   └── types/                   # Tipagens de critérios e respostas de avaliação
├── public/
│   ├── icons/                   # Ícones PWA para Android e iOS (192x192, 512x512)
│   └── sw.js                    # Service worker básico para cache PWA
├── .env.example                 # Modelo de variáveis de ambiente
├── package.json                 # Manifesto de pacotes e scripts npm
├── tailwind.config.ts           # Configuração de paleta tátil (Dark / Light)
├── tsconfig.json                # Configurações TypeScript
└── README.md                    # Esta documentação
```

---

## 4. Variáveis de Ambiente (`.env.local`)

Copie o modelo para criar seu arquivo local:
```bash
cp .env.example .env.local
```

| Variável | Valor Padrão / Exemplo | Descrição |
| :--- | :--- | :--- |
| `NEXT_PUBLIC_API_URL` | `http://localhost:8000/api/v1` | URL base da API FastAPI central |
| `NEXT_PUBLIC_APP_NAME` | `FECITEL — Avaliação Presencial` | Título oficial exibido no cabeçalho e PWA |
| `PORT` | `3002` | Porta local de execução do servidor Next.js |

---

## 5. Como Executar

```bash
# 1. Instalar dependências
npm install

# 2. Iniciar em modo de desenvolvimento na porta 3002
npm run dev -- -p 3002
```

Acesse no navegador do computador ou no smartphone (conectado na mesma rede Wi-Fi):  
[`http://localhost:3002`](http://localhost:3002)

---

## 6. Fluxo de Uso do Avaliador

```mermaid
graph TD
    A["1. Login com Código OTP (8 caracteres)"] --> B["2. Painel de Projetos Alocados"]
    B --> C{"Forma de Abertura"}
    C -->|Opção 1| D["Escanear QR Code da Bancada via Câmera"]
    C -->|Opção 2| E["Selecionar Projeto na Lista"]
    D --> F["3. Ficha de Avaliação com Steppers (+ / -)"]
    E --> F
    F --> G["4. Preenchimento de Notas por Critério"]
    G --> H["5. Parecer Consolidado Único Final"]
    H --> I["6. Envio Seguro e Conclusão"]
```
