// Service Worker do PWA EasyEvent Avaliação Presencial
const CACHE_NAME = "easyevent-evaluator-v1";
const STATIC_ASSETS = [
  "/",
  "/projects",
  "/profile",
  "/manifest.json",
  "/favicon.ico",
  "/icons/icon-192x192.png",
  "/icons/icon-512x512.png"
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(STATIC_ASSETS).catch((err) => {
        console.warn("Falha parcial ao pré-carregar cache:", err);
      });
    })
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.map((key) => {
          if (key !== CACHE_NAME) {
            return caches.delete(key);
          }
        })
      );
    })
  );
  self.clients.claim();
});

// Network-First com fallback para cache
self.addEventListener("fetch", (event) => {
  // Ignorar requisições para a API REST e recursos internos do Next.js
  if (
    event.request.url.includes("/api/") ||
    event.request.url.includes("/_next/") ||
    event.request.url.includes("__next") ||
    event.request.url.includes("webpack-hmr")
  ) {
    return;
  }

  // Apenas métodos GET são elegíveis para cache
  if (event.request.method !== "GET") {
    return;
  }

  event.respondWith(
    fetch(event.request)
      .then((response) => {
        // Se a resposta for válida, clonar e atualizar cache
        if (response && response.status === 200 && response.type === "basic") {
          const responseToCache = response.clone();
          caches.open(CACHE_NAME).then((cache) => {
            cache.put(event.request, responseToCache);
          });
        }
        return response;
      })
      .catch(() => {
        // Se a rede falhar, buscar no cache
        return caches.match(event.request).then((cachedResponse) => {
          if (cachedResponse) {
            return cachedResponse;
          }
          // Se for navegação de página, fallback para página inicial
          if (event.request.mode === "navigate") {
            return caches.match("/projects");
          }
        });
      })
  );
});
