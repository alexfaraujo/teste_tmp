"use client";

import React, { useEffect, useState, useMemo } from "react";
import {
  UserCheck,
  Search,
  Plus,
  Pencil,
  Trash2,
  Eye,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  Filter,
  Shirt,
  MapPin,
  Calendar,
  Layers,
  GraduationCap,
  Sparkles,
  BookOpen,
  Upload,
  FileSpreadsheet,
  Download,
  Printer,
} from "lucide-react";
import { useActiveEvent } from "../../../context/EventContext";
import { RequireActiveEvent } from "../../../components/common/RequireActiveEvent";
import { participantService } from "../../../services/participant.service";
import { eventService } from "../../../services/event.service";
import { areaService } from "../../../services/area.service";
import {
  EducationLevel,
  KnowledgeArea,
  PaginatedParticipantsResponse,
  ParticipantCreatePayload,
  ParticipantDetail,
  ParticipantItem,
  ParticipantUpdatePayload,
  UserRole,
} from "../../../types";
import { Button } from "../../../components/ui/Button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "../../../components/ui/Card";
import { Modal } from "../../../components/ui/Modal";
import { Input } from "../../../components/ui/Input";
import { Pagination } from "../../../components/ui/Pagination";
import { ParticipantsCsvImportModal } from "../../../components/participants/ParticipantsCsvImportModal";
import { downloadParticipantsCsvTemplate } from "../../../utils/participantCsv";

const AVAILABLE_ROLES: { role: UserRole; label: string; desc: string }[] = [
  { role: "STUDENT", label: "Estudante", desc: "Autor ou coautor de projeto na feira" },
  { role: "ADVISOR", label: "Orientador", desc: "Docente ou orientador responsável" },
  { role: "COADVISOR", label: "Coorientador", desc: "Coorientador de projeto" },
  { role: "EVALUATOR", label: "Avaliador", desc: "Avaliador técnico das sessões" },
];

const EDUCATION_LEVEL_OPTIONS: { level: EducationLevel; label: string; badgeColor: string }[] = [
  {
    level: "JUNIOR",
    label: "Ensino Fundamental I",
    badgeColor: "bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950 dark:text-amber-300 dark:border-amber-800",
  },
  {
    level: "FUNDAMENTAL",
    label: "Ensino Fundamental II",
    badgeColor: "bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950 dark:text-emerald-300 dark:border-emerald-800",
  },
  {
    level: "MEDIO",
    label: "Ensino Médio / Técnico",
    badgeColor: "bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-950 dark:text-blue-300 dark:border-blue-800",
  },
  {
    level: "GRADUACAO",
    label: "Graduação / Ensino Superior",
    badgeColor: "bg-purple-50 text-purple-700 border-purple-200 dark:bg-purple-950 dark:text-purple-300 dark:border-purple-800",
  },
  {
    level: "POS_GRADUACAO",
    label: "Pós-Graduação",
    badgeColor: "bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-950 dark:text-rose-300 dark:border-rose-800",
  },
];

export default function ParticipantsPage() {
  return (
    <RequireActiveEvent minRole="ORGANIZER" featureName="a Gestão de Participantes e Papéis">
      <ParticipantsContent />
    </RequireActiveEvent>
  );
}

function ParticipantsContent() {
  const { activeEvent } = useActiveEvent();

  // Data States
  const [participants, setParticipants] = useState<ParticipantItem[]>([]);
  const [areas, setAreas] = useState<KnowledgeArea[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // CSV Import Modal State
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);

  // Badges Export State
  const [isBadgesModalOpen, setIsBadgesModalOpen] = useState(false);
  const [selectedBadgeFilter, setSelectedBadgeFilter] = useState<"all" | "projects" | "evaluators" | "staff">("all");
  const [isDownloadingBadges, setIsDownloadingBadges] = useState(false);
  const [badgeModalError, setBadgeModalError] = useState<string | null>(null);
  const [downloadingBadgeId, setDownloadingBadgeId] = useState<number | null>(null);

  // Subáreas planas para modelo e validação CSV
  const flatSubareas = useMemo(() => {
    return areas.flatMap((area) =>
      (area.subareas || []).map((sub) => ({
        id: sub.id,
        name: sub.name,
        area_name: area.name,
      }))
    );
  }, [areas]);

  // Pagination (BR-18: 15 itens por página)
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalItems, setTotalItems] = useState(0);
  const PAGE_SIZE = 15;

  // Filter States
  const [searchTerm, setSearchTerm] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [roleFilter, setRoleFilter] = useState<string>("ALL");
  const [presenceFilter, setPresenceFilter] = useState<string>("ALL");
  const [kitFilter, setKitFilter] = useState<string>("ALL");

  // Create Modal State
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [createFormData, setCreateFormData] = useState<ParticipantCreatePayload>({
    name: "",
    email: "",
    cpf: "",
    affiliation: "",
    role: "STUDENT",
    roles: ["STUDENT"],
    tshirt_size: "M",
    barcode: "",
    subarea_ids: [],
    education_levels: [],
  });
  const [isSubmittingCreate, setIsSubmittingCreate] = useState(false);
  const [createModalError, setCreateModalError] = useState<string | null>(null);

  // Edit Modal State
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editingPersonId, setEditingPersonId] = useState<number | null>(null);
  const [editFormData, setEditFormData] = useState<ParticipantUpdatePayload>({
    name: "",
    email: "",
    cpf: "",
    affiliation: "",
    role: "STUDENT",
    roles: ["STUDENT"],
    tshirt_size: "M",
    barcode: "",
    kit_delivered: false,
    presence_confirmed: false,
    subarea_ids: [],
    education_levels: [],
  });
  const [isSubmittingEdit, setIsSubmittingEdit] = useState(false);
  const [editModalError, setEditModalError] = useState<string | null>(null);


  // Details Modal State
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [selectedDetail, setSelectedDetail] = useState<ParticipantDetail | null>(null);
  const [isLoadingDetail, setIsLoadingDetail] = useState(false);

  // Debounce search input (300ms)
  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedSearch(searchTerm);
      setCurrentPage(1);
    }, 300);
    return () => clearTimeout(handler);
  }, [searchTerm]);

  // Reset page when other filters change
  useEffect(() => {
    setCurrentPage(1);
  }, [roleFilter, presenceFilter, kitFilter]);

  // Load Areas for subarea selection in modals
  useEffect(() => {
    async function loadAreas() {
      if (!activeEvent) return;
      try {
        const areaData = await areaService.getAreas(activeEvent.id);
        setAreas(areaData);
      } catch (err) {
        console.error("Erro ao carregar áreas:", err);
      }
    }
    loadAreas();
  }, [activeEvent?.id]);

  // Load Participants with server-side pagination (BR-18)
  async function loadParticipants() {
    if (!activeEvent) return;

    setIsLoading(true);
    setError(null);

    const presenceParam =
      presenceFilter === "ALL" ? undefined : presenceFilter === "TRUE";
    const kitParam = kitFilter === "ALL" ? undefined : kitFilter === "TRUE";

    try {
      const response: PaginatedParticipantsResponse =
        await participantService.getParticipants({
          event_id: activeEvent.id,
          page: currentPage,
          limit: PAGE_SIZE,
          search: debouncedSearch,
          role: roleFilter,
          presence: presenceParam,
          kit_delivered: kitParam,
        });

      setParticipants(response.items);
      setTotalPages(response.total_pages);
      setTotalItems(response.total);
    } catch (err: any) {
      setError(
        err.response?.data?.detail || "Erro ao carregar participantes do evento."
      );
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    loadParticipants();
  }, [activeEvent?.id, currentPage, debouncedSearch, roleFilter, presenceFilter, kitFilter]);

  // Handle Batch Badges Download (PDF)
  const handleDownloadBadgesPdf = async () => {
    if (!activeEvent?.id) return;
    setIsDownloadingBadges(true);
    setBadgeModalError(null);
    try {
      await eventService.downloadBadgesPdf(activeEvent.id, selectedBadgeFilter);
      setIsBadgesModalOpen(false);
      setSuccessMessage("PDF de crachás gerado e baixado com sucesso!");
    } catch (err: any) {
      setBadgeModalError(err.response?.data?.detail || "Erro ao gerar PDF de crachás.");
    } finally {
      setIsDownloadingBadges(false);
    }
  };

  // Handle Single Participant Badge Download (PDF)
  const handleDownloadSingleBadge = async (item: ParticipantItem) => {
    if (!activeEvent?.id) return;
    setDownloadingBadgeId(item.participant_id);
    try {
      await participantService.downloadParticipantBadgePdf(
        item.person_id || item.participant_id,
        activeEvent.id,
        item.name
      );
      setSuccessMessage(`Crachá de "${item.name}" baixado com sucesso!`);
    } catch (err: any) {
      setError(err.response?.data?.detail || `Erro ao gerar crachá de ${item.name}.`);
    } finally {
      setDownloadingBadgeId(null);
    }
  };

  // Handle Create Submit
  const handleCreateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeEvent) return;

    if (!createFormData.roles || createFormData.roles.length === 0) {
      setCreateModalError("Selecione pelo menos um papel para o participante no evento.");
      return;
    }

    setIsSubmittingCreate(true);
    setCreateModalError(null);

    try {
      await participantService.createParticipant(activeEvent.id, createFormData);
      setIsCreateModalOpen(false);
      setSuccessMessage("Participante cadastrado com sucesso!");
      setCreateFormData({
        name: "",
        email: "",
        cpf: "",
        affiliation: "",
        role: "STUDENT",
        roles: ["STUDENT"],
        tshirt_size: "M",
        barcode: "",
        subarea_ids: [],
        education_levels: [],
      });
      await loadParticipants();
    } catch (err: any) {
      setCreateModalError(
        err.response?.data?.detail || "Erro ao cadastrar participante."
      );
    } finally {
      setIsSubmittingCreate(false);
    }
  };

  // Open Edit Modal
  const handleOpenEdit = async (item: ParticipantItem) => {
    if (!activeEvent) return;
    setEditingPersonId(item.person_id);
    setEditModalError(null);

    // Carregar detalhes para trazer subáreas se for avaliador
    try {
      const detail = await participantService.getParticipant(
        item.person_id,
        activeEvent.id
      );
      const activeRoles = detail.roles && detail.roles.length > 0 ? detail.roles : [detail.role];
      setEditFormData({
        name: detail.name,
        email: detail.email,
        cpf: detail.cpf || "",
        affiliation: detail.affiliation || "",
        role: activeRoles[0] || "STUDENT",
        roles: activeRoles,
        tshirt_size: detail.tshirt_size,
        barcode: detail.barcode || "",
        kit_delivered: detail.kit_delivered,
        presence_confirmed: detail.presence_confirmed,
        subarea_ids: detail.subareas.map((s) => s.subarea_id),
        education_levels: detail.education_levels || [],
      });
      setIsEditModalOpen(true);
    } catch (err: any) {
      alert("Erro ao buscar dados completos do participante.");
    }
  };

  // Handle Edit Submit
  const handleEditSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeEvent || !editingPersonId) return;

    if (!editFormData.roles || editFormData.roles.length === 0) {
      setEditModalError("Selecione pelo menos um papel para o participante no evento.");
      return;
    }

    setIsSubmittingEdit(true);
    setEditModalError(null);

    try {
      await participantService.updateParticipant(
        editingPersonId,
        activeEvent.id,
        editFormData
      );
      setIsEditModalOpen(false);
      setSuccessMessage("Dados do participante atualizados com sucesso!");
      await loadParticipants();
    } catch (err: any) {
      setEditModalError(
        err.response?.data?.detail || "Erro ao atualizar participante."
      );
    } finally {
      setIsSubmittingEdit(false);
    }
  };


  // Open Details Modal
  const handleOpenDetails = async (item: ParticipantItem) => {
    if (!activeEvent) return;
    setIsLoadingDetail(true);
    setIsDetailModalOpen(true);
    try {
      const detail = await participantService.getParticipant(
        item.person_id,
        activeEvent.id
      );
      setSelectedDetail(detail);
    } catch (err: any) {
      alert("Erro ao carregar detalhes do participante.");
      setIsDetailModalOpen(false);
    } finally {
      setIsLoadingDetail(false);
    }
  };

  // Handle Delete (Trava BR-16)
  const handleDelete = async (item: ParticipantItem) => {
    if (!activeEvent) return;
    const confirmMsg = `Tem certeza que deseja desvincular ${item.name} desta edição da feira?`;
    if (!confirm(confirmMsg)) return;

    try {
      const res = await participantService.deleteParticipant(
        item.person_id,
        activeEvent.id
      );
      setSuccessMessage(res.message);
      await loadParticipants();
    } catch (err: any) {
      alert(
        err.response?.data?.detail ||
          "Não foi possível remover o participante. Verifique se há vínculos ativos."
      );
    }
  };

  // Helper Badge Papel
  const renderRoleBadge = (role: UserRole) => {
    switch (role) {
      case "STUDENT":
        return (
          <span className="px-2 py-0.5 rounded-full text-[11px] font-semibold bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800">
            Estudante
          </span>
        );
      case "ADVISOR":
        return (
          <span className="px-2 py-0.5 rounded-full text-[11px] font-semibold bg-purple-50 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-800">
            Orientador
          </span>
        );
      case "COADVISOR":
        return (
          <span className="px-2 py-0.5 rounded-full text-[11px] font-semibold bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800">
            Coorientador
          </span>
        );
      case "EVALUATOR":
        return (
          <span className="px-2 py-0.5 rounded-full text-[11px] font-semibold bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300 border border-teal-200 dark:border-teal-800">
            Avaliador
          </span>
        );
      case "ADMIN":
        return (
          <span className="px-2 py-0.5 rounded-full text-[11px] font-semibold bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-800">
            Administrador
          </span>
        );
      default:
        return <span>{role}</span>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white flex items-center gap-2.5">
            <UserCheck className="text-teal-600 dark:text-teal-400" size={26} />
            Gestão de Participantes
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            Controle de dados cadastrais, correção de inconsistências de importação, papéis e entrega de kits.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <Button
            variant="outline"
            size="md"
            onClick={() => {
              if (activeEvent?.id) {
                downloadParticipantsCsvTemplate(activeEvent.id, flatSubareas);
              }
            }}
            title="Baixar modelo oficial de planilha CSV para cadastro de participantes"
            className="text-xs"
          >
            <Download size={14} className="mr-1.5" />
            Baixar Modelo CSV
          </Button>

          <Button
            variant="outline"
            size="md"
            onClick={() => setIsImportModalOpen(true)}
            className="text-xs border-teal-300 dark:border-teal-700 text-teal-700 dark:text-teal-300 hover:bg-teal-50 dark:hover:bg-teal-950/40"
            title="Importar participantes em lote via arquivo CSV"
          >
            <Upload size={14} className="mr-1.5 text-teal-600 dark:text-teal-400" />
            Importar CSV
          </Button>

          <Button
            variant="outline"
            size="md"
            onClick={() => {
              setBadgeModalError(null);
              setIsBadgesModalOpen(true);
            }}
            className="text-xs border-indigo-300 dark:border-indigo-700 text-indigo-700 dark:text-indigo-300 hover:bg-indigo-50 dark:hover:bg-indigo-950/40"
            title="Exportar Crachás da feira em lote em formato PDF pronto para impressão"
          >
            <Printer size={14} className="mr-1.5 text-indigo-600 dark:text-indigo-400" />
            Exportar Crachás (PDF)
          </Button>

          <Button
            variant="primary"
            size="md"
            onClick={() => {
              setCreateModalError(null);
              setIsCreateModalOpen(true);
            }}
          >
            <Plus size={16} className="mr-1.5" />
            Novo Participante
          </Button>

          <Button
            variant="outline"
            size="md"
            onClick={loadParticipants}
            title="Recarregar participantes"
          >
            <RefreshCw size={15} />
          </Button>
        </div>
      </div>

      {/* Alerts */}
      {error && (
        <div className="p-4 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 text-red-700 dark:text-red-300 text-sm flex items-center gap-3">
          <AlertCircle size={18} className="flex-shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {successMessage && (
        <div className="p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900 text-emerald-700 dark:text-emerald-300 text-sm flex items-center gap-3">
          <CheckCircle2 size={18} className="flex-shrink-0" />
          <span>{successMessage}</span>
        </div>
      )}

      {/* Filter & Search Bar */}
      <Card>
        <CardContent className="p-4 space-y-3">
          <div className="flex flex-col md:flex-row gap-3">
            {/* Search Input */}
            <div className="relative flex-1">
              <Search
                size={16}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
              />
              <input
                type="text"
                placeholder="Buscar por nome, e-mail, CPF (com/sem máscara) ou código de barras..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-9 pr-4 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg text-sm text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-500/20"
              />
            </div>

            {/* Filter Role */}
            <select
              value={roleFilter}
              onChange={(e) => setRoleFilter(e.target.value)}
              className="px-3 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg text-xs font-medium text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500/20"
            >
              <option value="ALL">Todos os Papéis</option>
              <option value="STUDENT">Estudantes</option>
              <option value="ADVISOR">Orientadores</option>
              <option value="COADVISOR">Coorientadores</option>
              <option value="EVALUATOR">Avaliadores</option>
            </select>

            {/* Filter Presence */}
            <select
              value={presenceFilter}
              onChange={(e) => setPresenceFilter(e.target.value)}
              className="px-3 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg text-xs font-medium text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500/20"
            >
              <option value="ALL">Presença: Todos</option>
              <option value="TRUE">Confirmados</option>
              <option value="FALSE">Pendentes</option>
            </select>

            {/* Filter Kit */}
            <select
              value={kitFilter}
              onChange={(e) => setKitFilter(e.target.value)}
              className="px-3 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg text-xs font-medium text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500/20"
            >
              <option value="ALL">Kit: Todos</option>
              <option value="TRUE">Entregues</option>
              <option value="FALSE">Não Retirados</option>
            </select>
          </div>
        </CardContent>
      </Card>

      {/* Table Card */}
      <Card>
        <CardHeader className="pb-3 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Relação de Participantes do Evento</CardTitle>
              <CardDescription>
                Exibindo {participants.length} de {totalItems} participantes registrados na edição.
              </CardDescription>
            </div>
          </div>
        </CardHeader>

        <CardContent className="p-0">
          {isLoading ? (
            <div className="py-16 text-center text-sm text-slate-500">
              Carregando participantes...
            </div>
          ) : participants.length === 0 ? (
            <div className="py-16 text-center text-sm text-slate-500">
              Nenhum participante encontrado com os filtros selecionados.
            </div>
          ) : (
            <>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead className="bg-slate-50 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-800 text-xs font-semibold text-slate-500 uppercase tracking-wider">
                    <tr>
                      <th className="py-3 px-3">Participante</th>
                      <th className="py-3 px-3">Documento & Vínculo</th>
                      <th className="py-3 px-3">Papel</th>
                      <th className="py-3 px-2 text-center">Camiseta</th>
                      <th className="py-3 px-3 text-center">Presença</th>
                      <th className="py-3 px-3 text-center">Kit</th>
                      <th className="py-3 px-3 text-right">Ações</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 dark:divide-slate-800 text-xs">
                    {participants.map((item) => (
                      <tr
                        key={item.participant_id}
                        className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors"
                      >
                        <td className="py-3 px-3">
                          <div className="font-semibold text-slate-900 dark:text-white">
                            {item.name}
                          </div>
                          <div className="text-[11px] text-slate-400 font-mono">
                            {item.email}
                          </div>
                        </td>

                        <td className="py-3 px-3 whitespace-nowrap">
                          <div className="font-mono text-slate-700 dark:text-slate-300">
                            {item.cpf || <span className="text-slate-400">—</span>}
                          </div>
                          <div className="text-[11px] text-slate-400 max-w-[140px] truncate" title={item.affiliation || ""}>
                            {item.affiliation || "Não informado"}
                          </div>
                          {item.barcode && (
                            <div className="mt-0.5">
                              <span className="inline-flex items-center font-mono text-[10px] text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 px-1.5 py-0.5 rounded border border-slate-200 dark:border-slate-800" title={`Código de Barras: ${item.barcode}`}>
                                {item.barcode}
                              </span>
                            </div>
                          )}
                        </td>

                        <td className="py-3 px-3">
                          <div className="flex flex-wrap gap-1 max-w-[190px]">
                            {(item.roles && item.roles.length > 0 ? item.roles : [item.role]).map((r) => (
                              <React.Fragment key={r}>{renderRoleBadge(r)}</React.Fragment>
                            ))}
                          </div>
                          {(item.roles?.includes("EVALUATOR") || item.role === "EVALUATOR") &&
                            item.education_levels &&
                            item.education_levels.length > 0 && (
                              <div className="flex flex-wrap gap-1 mt-1">
                                {item.education_levels.map((lvl) => (
                                  <span
                                    key={lvl}
                                    className="px-1.5 py-0.5 rounded text-[10px] font-medium bg-indigo-50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800"
                                    title={`Habilitado para avaliar: ${lvl}`}
                                  >
                                    {lvl === "MEDIO" ? "Médio" : lvl === "FUNDAMENTAL" ? "Fund." : "Júnior"}
                                  </span>
                                ))}
                              </div>
                            )}
                        </td>

                        <td className="py-3 px-2 whitespace-nowrap text-center">
                          <span className="px-2 py-0.5 rounded font-mono font-bold text-[11px] bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
                            {item.tshirt_size}
                          </span>
                        </td>

                        <td className="py-3 px-3 whitespace-nowrap text-center">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[11px] font-medium ${
                              item.presence_confirmed
                                ? "bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800"
                                : "bg-slate-100 dark:bg-slate-800 text-slate-500 border border-slate-200 dark:border-slate-700"
                            }`}
                          >
                            {item.presence_confirmed ? "Presente ✅" : "Pendente ⏳"}
                          </span>
                        </td>

                        <td className="py-3 px-3 whitespace-nowrap text-center">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[11px] font-medium ${
                              item.kit_delivered
                                ? "bg-teal-50 dark:bg-teal-950 text-teal-700 dark:text-teal-300 border border-teal-200 dark:border-teal-800"
                                : "bg-slate-100 dark:bg-slate-800 text-slate-500 border border-slate-200 dark:border-slate-700"
                            }`}
                          >
                            {item.kit_delivered ? "Entregue 👕" : "Pendente"}
                          </span>
                        </td>

                        <td className="py-3 px-3 text-right whitespace-nowrap">
                          <div className="inline-flex items-center justify-end gap-1">
                            <button
                              title="Imprimir Crachá Individual (PDF)"
                              onClick={() => handleDownloadSingleBadge(item)}
                              disabled={downloadingBadgeId === item.participant_id}
                              className="p-1.5 text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-950/50 rounded-lg transition-colors disabled:opacity-50"
                            >
                              {downloadingBadgeId === item.participant_id ? (
                                <RefreshCw size={14} className="animate-spin text-indigo-600" />
                              ) : (
                                <Printer size={14} />
                              )}
                            </button>

                            <button
                              title="Ver Detalhes e Projetos"
                              onClick={() => handleOpenDetails(item)}
                              className="p-1.5 text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-950/50 rounded-lg transition-colors"
                            >
                              <Eye size={14} />
                            </button>

                            <button
                              title="Editar Participante"
                              onClick={() => handleOpenEdit(item)}
                              className="p-1.5 text-amber-600 hover:bg-amber-50 dark:hover:bg-amber-950/50 rounded-lg transition-colors"
                            >
                              <Pencil size={14} />
                            </button>

                            <button
                              title="Desvincular Participante"
                              onClick={() => handleDelete(item)}
                              className="p-1.5 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/50 rounded-lg transition-colors"
                            >
                              <Trash2 size={14} />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Paginação Real Server-Side (BR-18: 15 itens por página) */}
              <div className="p-4 border-t border-slate-200 dark:border-slate-800">
                <Pagination
                  currentPage={currentPage}
                  totalPages={totalPages}
                  totalItems={totalItems}
                  limit={PAGE_SIZE}
                  onPageChange={setCurrentPage}
                  isLoading={isLoading}
                />
              </div>
            </>
          )}
        </CardContent>
      </Card>

      {/* Modal: Novo Participante (UX-01 Compliant) */}
      <Modal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        title="Cadastrar Novo Participante no Evento"
        error={createModalError}
      >
        <form onSubmit={handleCreateSubmit} className="space-y-3.5">
          <Input
            label="Nome Completo *"
            required
            value={createFormData.name}
            onChange={(e) => setCreateFormData({ ...createFormData, name: e.target.value })}
            placeholder="Ex: Maria dos Santos"
          />

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <Input
              label="E-mail *"
              type="email"
              required
              value={createFormData.email}
              onChange={(e) => setCreateFormData({ ...createFormData, email: e.target.value })}
              placeholder="exemplo@ifms.edu.br"
            />

            <Input
              label="CPF"
              value={createFormData.cpf || ""}
              onChange={(e) => setCreateFormData({ ...createFormData, cpf: e.target.value })}
              placeholder="000.000.000-00"
            />
          </div>

          {/* Seleção de Múltiplos Papéis (Opção 1) */}
          <div className="space-y-1.5">
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
              Papéis do Participante no Evento * (Selecione um ou mais)
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 p-2.5 bg-slate-50 dark:bg-slate-950 rounded-lg border border-slate-200 dark:border-slate-800">
              {AVAILABLE_ROLES.map(({ role, label, desc }) => {
                const isSelected = (createFormData.roles || []).includes(role);
                return (
                  <label
                    key={role}
                    className={`flex items-start gap-2 p-2 rounded-md border cursor-pointer transition-colors ${
                      isSelected
                        ? "bg-teal-50/80 dark:bg-teal-950/40 border-teal-300 dark:border-teal-700"
                        : "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700"
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={isSelected}
                      onChange={(e) => {
                        const current = createFormData.roles || [];
                        const updated = e.target.checked
                          ? [...current, role]
                          : current.filter((r) => r !== role);
                        setCreateFormData({
                          ...createFormData,
                          roles: updated,
                          role: updated[0] || "STUDENT",
                        });
                      }}
                      className="mt-0.5 rounded border-slate-300 text-teal-600 focus:ring-teal-500"
                    />
                    <div className="text-xs">
                      <span className="font-semibold text-slate-900 dark:text-white block">
                        {label}
                      </span>
                      <span className="text-[10px] text-slate-500 dark:text-slate-400 block leading-tight">
                        {desc}
                      </span>
                    </div>
                  </label>
                );
              })}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Tamanho da Camiseta *
              </label>
              <select
                value={createFormData.tshirt_size}
                onChange={(e) => setCreateFormData({ ...createFormData, tshirt_size: e.target.value })}
                className="w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg text-xs font-medium text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500/20"
              >
                <option value="PP">PP</option>
                <option value="P">P</option>
                <option value="M">M</option>
                <option value="G">G</option>
                <option value="GG">GG</option>
                <option value="XGG">XGG</option>
              </select>
            </div>

            <Input
              label="Afiliação / Escola"
              value={createFormData.affiliation || ""}
              onChange={(e) => setCreateFormData({ ...createFormData, affiliation: e.target.value })}
              placeholder="Ex: IFMS ou Escola Silva"
            />
          </div>

          <Input
            label="Código de Barras do Crachá (Opcional - gerado automaticamente se vazio)"
            value={createFormData.barcode || ""}
            onChange={(e) => setCreateFormData({ ...createFormData, barcode: e.target.value })}
            placeholder="Ex: BC-99881"
          />

          {/* Se for avaliador, exibir seleção de subáreas */}
          {createFormData.roles?.includes("EVALUATOR") && (
            <>
              <div className="space-y-2 pt-1 border-t border-slate-100 dark:border-slate-800">
                <label className="block text-xs font-bold text-teal-700 dark:text-teal-400">
                  Subáreas de Conhecimento do Avaliador
                </label>
                <div className="max-h-36 overflow-y-auto space-y-1.5 p-2 bg-slate-50 dark:bg-slate-950 rounded-lg border border-slate-200 dark:border-slate-800 text-xs">
                  {areas.map((area) => (
                    <div key={area.id} className="space-y-1">
                      <span className="text-[10px] font-bold text-slate-400 uppercase">
                        {area.name}
                      </span>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 pl-1.5">
                        {area.subareas?.map((sub) => {
                          const isChecked = createFormData.subarea_ids?.includes(sub.id);
                          return (
                            <label
                              key={sub.id}
                              className="flex items-center gap-1.5 text-xs text-slate-700 dark:text-slate-300 cursor-pointer"
                            >
                              <input
                                type="checkbox"
                                checked={isChecked}
                                onChange={(e) => {
                                  const current = createFormData.subarea_ids || [];
                                  const updated = e.target.checked
                                    ? [...current, sub.id]
                                    : current.filter((id) => id !== sub.id);
                                  setCreateFormData({ ...createFormData, subarea_ids: updated });
                                }}
                                className="rounded border-slate-300 text-teal-600 focus:ring-teal-500"
                              />
                              <span>{sub.name}</span>
                            </label>
                          );
                        })}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Níveis de Ensino Permitidos para o Avaliador */}
              <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-bold text-indigo-700 dark:text-indigo-400">
                    Níveis de Ensino Permitidos para Avaliação
                  </label>
                  <span className="text-[10px] text-slate-400">
                    (Opcional - vazio avalia qualquer nível)
                  </span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 p-2.5 bg-slate-50 dark:bg-slate-950 rounded-lg border border-slate-200 dark:border-slate-800 text-xs">
                  {EDUCATION_LEVEL_OPTIONS.map((opt) => {
                    const isChecked = createFormData.education_levels?.includes(opt.level);
                    return (
                      <label
                        key={opt.level}
                        className="flex items-center gap-2 text-xs text-slate-700 dark:text-slate-300 cursor-pointer select-none"
                      >
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={(e) => {
                            const current = createFormData.education_levels || [];
                            const updated = e.target.checked
                              ? [...current, opt.level]
                              : current.filter((lvl) => lvl !== opt.level);
                            setCreateFormData({ ...createFormData, education_levels: updated });
                          }}
                          className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                        />
                        <span>{opt.label}</span>
                      </label>
                    );
                  })}
                </div>
              </div>
            </>
          )}

          <div className="flex justify-end gap-3 pt-3">
            <Button
              type="button"
              variant="outline"
              onClick={() => setIsCreateModalOpen(false)}
            >
              Cancelar
            </Button>
            <Button
              type="submit"
              variant="primary"
              isLoading={isSubmittingCreate}
            >
              Salvar Participante
            </Button>
          </div>
        </form>
      </Modal>

      {/* Modal: Editar Participante (UX-01 Compliant) */}
      <Modal
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        title="Editar Dados do Participante"
        error={editModalError}
      >
        <form onSubmit={handleEditSubmit} className="space-y-3.5">
          <Input
            label="Nome Completo *"
            required
            value={editFormData.name || ""}
            onChange={(e) => setEditFormData({ ...editFormData, name: e.target.value })}
          />

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <Input
              label="E-mail *"
              type="email"
              required
              value={editFormData.email || ""}
              onChange={(e) => setEditFormData({ ...editFormData, email: e.target.value })}
            />

            <Input
              label="CPF"
              value={editFormData.cpf || ""}
              onChange={(e) => setEditFormData({ ...editFormData, cpf: e.target.value })}
            />
          </div>

          {/* Seleção de Múltiplos Papéis (Opção 1) */}
          <div className="space-y-1.5">
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
              Papéis do Participante no Evento * (Selecione um ou mais)
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 p-2.5 bg-slate-50 dark:bg-slate-950 rounded-lg border border-slate-200 dark:border-slate-800">
              {AVAILABLE_ROLES.map(({ role, label, desc }) => {
                const isSelected = (editFormData.roles || []).includes(role);
                return (
                  <label
                    key={role}
                    className={`flex items-start gap-2 p-2 rounded-md border cursor-pointer transition-colors ${
                      isSelected
                        ? "bg-teal-50/80 dark:bg-teal-950/40 border-teal-300 dark:border-teal-700"
                        : "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700"
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={isSelected}
                      onChange={(e) => {
                        const current = editFormData.roles || [];
                        const updated = e.target.checked
                          ? [...current, role]
                          : current.filter((r) => r !== role);
                        setEditFormData({
                          ...editFormData,
                          roles: updated,
                          role: updated[0] || "STUDENT",
                        });
                      }}
                      className="mt-0.5 rounded border-slate-300 text-teal-600 focus:ring-teal-500"
                    />
                    <div className="text-xs">
                      <span className="font-semibold text-slate-900 dark:text-white block">
                        {label}
                      </span>
                      <span className="text-[10px] text-slate-500 dark:text-slate-400 block leading-tight">
                        {desc}
                      </span>
                    </div>
                  </label>
                );
              })}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Tamanho da Camiseta *
              </label>
              <select
                value={editFormData.tshirt_size}
                onChange={(e) => setEditFormData({ ...editFormData, tshirt_size: e.target.value })}
                className="w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg text-xs font-medium text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500/20"
              >
                <option value="PP">PP</option>
                <option value="P">P</option>
                <option value="M">M</option>
                <option value="G">G</option>
                <option value="GG">GG</option>
                <option value="XGG">XGG</option>
              </select>
            </div>

            <Input
              label="Afiliação / Escola"
              value={editFormData.affiliation || ""}
              onChange={(e) => setEditFormData({ ...editFormData, affiliation: e.target.value })}
            />
          </div>

          <Input
            label="Código de Barras do Crachá"
            value={editFormData.barcode || ""}
            onChange={(e) => setEditFormData({ ...editFormData, barcode: e.target.value })}
          />

          {/* Status de Presença e Kit */}
          <div className="grid grid-cols-2 gap-3 p-3 bg-slate-50 dark:bg-slate-950 rounded-lg border border-slate-200 dark:border-slate-800">
            <label className="flex items-center gap-2 text-xs font-medium text-slate-700 dark:text-slate-300 cursor-pointer">
              <input
                type="checkbox"
                checked={editFormData.presence_confirmed || false}
                onChange={(e) =>
                  setEditFormData({ ...editFormData, presence_confirmed: e.target.checked })
                }
                className="rounded border-slate-300 text-teal-600 focus:ring-teal-500"
              />
              <span>Presença Confirmada</span>
            </label>

            <label className="flex items-center gap-2 text-xs font-medium text-slate-700 dark:text-slate-300 cursor-pointer">
              <input
                type="checkbox"
                checked={editFormData.kit_delivered || false}
                onChange={(e) =>
                  setEditFormData({ ...editFormData, kit_delivered: e.target.checked })
                }
                className="rounded border-slate-300 text-teal-600 focus:ring-teal-500"
              />
              <span>Kit Entregue</span>
            </label>
          </div>

          {/* Subáreas se for avaliador */}
          {editFormData.roles?.includes("EVALUATOR") && (
            <>
              <div className="space-y-2 pt-1 border-t border-slate-100 dark:border-slate-800">
                <label className="block text-xs font-bold text-teal-700 dark:text-teal-400">
                  Subáreas de Conhecimento do Avaliador
                </label>
                <div className="max-h-36 overflow-y-auto space-y-1.5 p-2 bg-slate-50 dark:bg-slate-950 rounded-lg border border-slate-200 dark:border-slate-800 text-xs">
                  {areas.map((area) => (
                    <div key={area.id} className="space-y-1">
                      <span className="text-[10px] font-bold text-slate-400 uppercase">
                        {area.name}
                      </span>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 pl-1.5">
                        {area.subareas?.map((sub) => {
                          const isChecked = editFormData.subarea_ids?.includes(sub.id);
                          return (
                            <label
                              key={sub.id}
                              className="flex items-center gap-1.5 text-xs text-slate-700 dark:text-slate-300 cursor-pointer"
                            >
                              <input
                                type="checkbox"
                                checked={isChecked}
                                onChange={(e) => {
                                  const current = editFormData.subarea_ids || [];
                                  const updated = e.target.checked
                                    ? [...current, sub.id]
                                    : current.filter((id) => id !== sub.id);
                                  setEditFormData({ ...editFormData, subarea_ids: updated });
                                }}
                                className="rounded border-slate-300 text-teal-600 focus:ring-teal-500"
                              />
                              <span>{sub.name}</span>
                            </label>
                          );
                        })}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Níveis de Ensino Permitidos para o Avaliador */}
              <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-bold text-indigo-700 dark:text-indigo-400">
                    Níveis de Ensino Permitidos para Avaliação
                  </label>
                  <span className="text-[10px] text-slate-400">
                    (Opcional - vazio avalia qualquer nível)
                  </span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 p-2.5 bg-slate-50 dark:bg-slate-950 rounded-lg border border-slate-200 dark:border-slate-800 text-xs">
                  {EDUCATION_LEVEL_OPTIONS.map((opt) => {
                    const isChecked = editFormData.education_levels?.includes(opt.level);
                    return (
                      <label
                        key={opt.level}
                        className="flex items-center gap-2 text-xs text-slate-700 dark:text-slate-300 cursor-pointer select-none"
                      >
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={(e) => {
                            const current = editFormData.education_levels || [];
                            const updated = e.target.checked
                              ? [...current, opt.level]
                              : current.filter((lvl) => lvl !== opt.level);
                            setEditFormData({ ...editFormData, education_levels: updated });
                          }}
                          className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                        />
                        <span>{opt.label}</span>
                      </label>
                    );
                  })}
                </div>
              </div>
            </>
          )}

          <div className="flex justify-end gap-3 pt-3">
            <Button
              type="button"
              variant="outline"
              onClick={() => setIsEditModalOpen(false)}
            >
              Cancelar
            </Button>
            <Button
              type="submit"
              variant="primary"
              isLoading={isSubmittingEdit}
            >
              Salvar Alterações
            </Button>
          </div>
        </form>
      </Modal>

      {/* Modal: Detalhes do Participante */}
      <Modal
        isOpen={isDetailModalOpen}
        onClose={() => setIsDetailModalOpen(false)}
        title="Detalhes do Participante"
      >
        {isLoadingDetail ? (
          <div className="py-8 text-center text-sm text-slate-500">
            Carregando detalhes...
          </div>
        ) : selectedDetail ? (
          <div className="space-y-4 text-xs">
            <div className="p-3.5 bg-slate-50 dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-sm text-slate-900 dark:text-white">
                  {selectedDetail.name}
                </span>
                <div className="flex flex-wrap gap-1">
                  {(selectedDetail.roles && selectedDetail.roles.length > 0
                    ? selectedDetail.roles
                    : [selectedDetail.role]
                  ).map((r) => (
                    <React.Fragment key={r}>{renderRoleBadge(r)}</React.Fragment>
                  ))}
                </div>
              </div>
              <p className="text-slate-500">{selectedDetail.email}</p>
              <div className="grid grid-cols-2 gap-2 pt-1 border-t border-slate-200 dark:border-slate-800">
                <div>
                  <span className="text-[10px] text-slate-400 uppercase font-semibold">
                    CPF
                  </span>
                  <p className="font-mono text-slate-700 dark:text-slate-300">
                    {selectedDetail.cpf || "Não informado"}
                  </p>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 uppercase font-semibold">
                    Afiliação
                  </span>
                  <p className="text-slate-700 dark:text-slate-300">
                    {selectedDetail.affiliation || "Não informado"}
                  </p>
                </div>
              </div>
            </div>

            {/* Projetos em que atua */}
            <div className="space-y-2">
              <h4 className="font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                <BookOpen size={15} className="text-blue-600" />
                Projetos Vinculados nesta Edição ({selectedDetail.projects.length})
              </h4>
              {selectedDetail.projects.length === 0 ? (
                <p className="text-slate-400 italic">
                  Nenhum projeto científico vinculado diretamente.
                </p>
              ) : (
                <div className="space-y-1.5">
                  {selectedDetail.projects.map((p) => (
                    <div
                      key={p.project_id}
                      className="p-2.5 bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-800 flex items-center justify-between"
                    >
                      <div>
                        <span className="font-semibold text-slate-900 dark:text-white">
                          {p.booth_number ? `[${p.booth_number}] ` : ""}
                          {p.title}
                        </span>
                        <div className="text-[11px] text-slate-400">
                          ID: #{p.project_id} · Função: {p.member_role}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Subáreas de Avaliação */}
            {(selectedDetail.roles?.includes("EVALUATOR") || selectedDetail.role === "EVALUATOR") && (
              <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                <h4 className="font-bold text-teal-700 dark:text-teal-400 flex items-center gap-1.5">
                  <Sparkles size={15} />
                  Subáreas Qualificadas para Avaliação ({selectedDetail.subareas.length})
                </h4>

                {selectedDetail.subareas.length === 0 ? (
                  <p className="text-slate-400 italic">
                    Nenhuma subárea vinculada ainda.
                  </p>
                ) : (
                  <div className="flex flex-wrap gap-1.5">
                    {selectedDetail.subareas.map((s) => (
                      <span
                        key={s.subarea_id}
                        className="px-2.5 py-1 bg-teal-50 dark:bg-teal-950 text-teal-800 dark:text-teal-200 border border-teal-200 dark:border-teal-800 rounded-lg text-xs"
                      >
                        <strong className="font-semibold">{s.area_name}</strong> &gt; {s.subarea_name}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Níveis de Ensino Habilitados para Avaliação */}
            {(selectedDetail.roles?.includes("EVALUATOR") || selectedDetail.role === "EVALUATOR") && (
              <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                <h4 className="font-bold text-indigo-700 dark:text-indigo-400 flex items-center gap-1.5">
                  <GraduationCap size={15} />
                  Níveis de Ensino Habilitados
                </h4>

                {!selectedDetail.education_levels || selectedDetail.education_levels.length === 0 ? (
                  <p className="text-slate-500 italic text-xs">
                    Todos os níveis permitidos (sem restrição).
                  </p>
                ) : (
                  <div className="flex flex-wrap gap-1.5">
                    {selectedDetail.education_levels.map((lvl) => {
                      const opt = EDUCATION_LEVEL_OPTIONS.find((o) => o.level === lvl);
                      return (
                        <span
                          key={lvl}
                          className={`px-2.5 py-0.5 rounded-full text-[11px] font-medium border ${opt?.badgeColor || "bg-slate-100 text-slate-700"}`}
                        >
                          {opt?.label || lvl}
                        </span>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

            <div className="flex justify-end pt-3">
              <Button
                type="button"
                variant="outline"
                onClick={() => setIsDetailModalOpen(false)}
              >
                Fechar
              </Button>
            </div>
          </div>
        ) : null}
      </Modal>

      {/* Modal: Exportação de Crachás em Lote (PDF) */}
      <Modal
        isOpen={isBadgesModalOpen}
        onClose={() => setIsBadgesModalOpen(false)}
        title="Exportar Crachás para Impressão (PDF)"
        error={badgeModalError}
        maxWidth="max-w-lg"
      >
        <div className="space-y-4">
          <p className="text-xs text-slate-500 dark:text-slate-400 -mt-2">
            Geração de folhas padrão A4 prontas para impressão com 4 crachás por folha (grid 2x2), linhas pontilhadas de corte, guia para furo de cordão, logotipo da feira e código de barras Code128 vetorial.
          </p>

          <div className="space-y-2">
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
              Selecione o Lote de Crachás a Ser Gerado:
            </label>
            <div className="space-y-2">
              {[
                {
                  id: "all",
                  label: "Todos os Crachás da Feira",
                  desc: "PDF consolidado: Trabalhos Científicos (autores), Equipe Organizadora e Avaliadores.",
                },
                {
                  id: "projects",
                  label: "Apenas Trabalhos Científicos",
                  desc: "Agrupados por projeto na sequência: Orientador → Coorientador → Estudantes.",
                },
                {
                  id: "evaluators",
                  label: "Apenas Avaliadores Credenciados",
                  desc: "Crachás com lista de subáreas temáticas e níveis de ensino autorizados.",
                },
                {
                  id: "staff",
                  label: "Apenas Equipe Organizadora e Apoio",
                  desc: "Coordenadores gerais, comissão organizadora e equipe de apoio/staff.",
                },
              ].map((opt) => (
                <label
                  key={opt.id}
                  className={`flex items-start gap-3 p-3 rounded-xl border cursor-pointer transition-all ${
                    selectedBadgeFilter === opt.id
                      ? "border-indigo-500 bg-indigo-50/40 dark:bg-indigo-950/30 text-indigo-950 dark:text-indigo-200"
                      : "border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-900/50 text-slate-700 dark:text-slate-300"
                  }`}
                >
                  <input
                    type="radio"
                    name="badgeFilter"
                    value={opt.id}
                    checked={selectedBadgeFilter === opt.id}
                    onChange={() => setSelectedBadgeFilter(opt.id as any)}
                    className="mt-0.5 text-indigo-600 focus:ring-indigo-500"
                  />
                  <div>
                    <div className="text-xs font-bold text-slate-900 dark:text-white">
                      {opt.label}
                    </div>
                    <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                      {opt.desc}
                    </div>
                  </div>
                </label>
              ))}
            </div>
          </div>

          <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200 dark:border-slate-700/60 text-[11px] text-slate-600 dark:text-slate-400 flex items-start gap-2">
            <Sparkles size={16} className="text-indigo-500 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-slate-800 dark:text-slate-200">
                Padrão Gráfico de Alta Definição
              </p>
              <p className="mt-0.5">
                Os crachás utilizam o logotipo oficial cadastrado na feira (PNG/JPG) e código de barras padrão <strong>Code128</strong> direto no leitor de credenciamento.
              </p>
            </div>
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => setIsBadgesModalOpen(false)}
              disabled={isDownloadingBadges}
            >
              Cancelar
            </Button>
            <Button
              type="button"
              variant="primary"
              size="sm"
              onClick={handleDownloadBadgesPdf}
              disabled={isDownloadingBadges}
              className="bg-indigo-600 hover:bg-indigo-700 text-white"
            >
              {isDownloadingBadges ? (
                <>
                  <RefreshCw size={14} className="animate-spin mr-1.5" />
                  Gerando PDF...
                </>
              ) : (
                <>
                  <Printer size={14} className="mr-1.5" />
                  Gerar e Baixar PDF
                </>
              )}
            </Button>
          </div>
        </div>
      </Modal>

      {/* Modal: Importação em Lote de Participantes via CSV */}
      {activeEvent?.id && (
        <ParticipantsCsvImportModal
          isOpen={isImportModalOpen}
          onClose={() => setIsImportModalOpen(false)}
          eventId={activeEvent.id}
          subareas={flatSubareas}
          existingParticipants={participants}
          onSuccess={(summary) => {
            setSuccessMessage(
              `Importação concluída com sucesso: ${summary.total} participante(s) processado(s) (${summary.created} novo(s), ${summary.updated} atualizado(s), ${summary.evaluators} avaliador(es) qualificado(s)).`
            );
            loadParticipants();
            setTimeout(() => setSuccessMessage(null), 7000);
          }}
        />
      )}
    </div>
  );
}
