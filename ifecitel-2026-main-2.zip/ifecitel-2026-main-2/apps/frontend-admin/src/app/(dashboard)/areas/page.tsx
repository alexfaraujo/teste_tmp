"use client";

import React, { useEffect, useState } from "react";
import Link from "next/link";
import {
  Plus,
  Trash2,
  FolderPlus,
  Tag,
  BookOpen,
  AlertCircle,
  CheckCircle2,
  Calendar,
  ArrowRight,
  Layers,
  Sparkles,
  Download,
  Upload,
} from "lucide-react";
import { areaService } from "../../../services/area.service";
import { KnowledgeArea } from "../../../types";
import { useActiveEvent } from "../../../context/EventContext";
import { RequireActiveEvent } from "../../../components/common/RequireActiveEvent";
import { Button } from "../../../components/ui/Button";
import { Card, CardContent, CardHeader, CardTitle } from "../../../components/ui/Card";
import { Modal } from "../../../components/ui/Modal";
import { Input } from "../../../components/ui/Input";
import { downloadAreasCsvTemplate } from "../../../utils/areaCsv";
import { AreasCsvImportModal } from "../../../components/areas/AreasCsvImportModal";

export default function KnowledgeAreasPage() {
  return (
    <RequireActiveEvent minRole="ORGANIZER" featureName="as Áreas e Subáreas do Conhecimento">
      <KnowledgeAreasContent />
    </RequireActiveEvent>
  );
}

function KnowledgeAreasContent() {
  const { activeEvent } = useActiveEvent();
  const [areas, setAreas] = useState<KnowledgeArea[]>([]);
  const [isLoadingAreas, setIsLoadingAreas] = useState(false);

  // Modals
  const [isAreaModalOpen, setIsAreaModalOpen] = useState(false);
  const [isSubareaModalOpen, setIsSubareaModalOpen] = useState(false);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [targetArea, setTargetArea] = useState<KnowledgeArea | null>(null);
  const [areaModalError, setAreaModalError] = useState<string | null>(null);
  const [subareaModalError, setSubareaModalError] = useState<string | null>(null);

  // Form states
  const [areaName, setAreaName] = useState("");
  const [subareaName, setSubareaName] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Notifications (page level)
  const [notification, setNotification] = useState<{
    type: "success" | "error";
    text: string;
  } | null>(null);

  const openAreaModal = () => {
    setAreaModalError(null);
    setAreaName("");
    setIsAreaModalOpen(true);
  };

  const closeAreaModal = () => {
    setAreaModalError(null);
    setIsAreaModalOpen(false);
  };

  const openSubareaModal = (area: KnowledgeArea) => {
    setSubareaModalError(null);
    setSubareaName("");
    setTargetArea(area);
    setIsSubareaModalOpen(true);
  };

  const closeSubareaModal = () => {
    setSubareaModalError(null);
    setTargetArea(null);
    setIsSubareaModalOpen(false);
  };

  // Load areas whenever activeEvent changes
  useEffect(() => {
    if (!activeEvent) {
      setAreas([]);
      return;
    }

    async function loadAreas(eventId: number) {
      setIsLoadingAreas(true);
      try {
        const areaList = await areaService.getAreas(eventId);
        setAreas(areaList);
      } catch (err: any) {
        setNotification({
          type: "error",
          text: "Erro ao carregar áreas e subáreas do conhecimento.",
        });
      } finally {
        setIsLoadingAreas(false);
      }
    }

    loadAreas(activeEvent.id);
  }, [activeEvent]);

  const refreshAreas = async () => {
    if (!activeEvent) return;
    try {
      const areaList = await areaService.getAreas(activeEvent.id);
      setAreas(areaList);
    } catch (err: any) {
      console.error("Erro ao atualizar áreas:", err);
    }
  };

  const handleCreateArea = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeEvent) return;

    if (!areaName.trim()) {
      setAreaModalError("Informe o nome da grande área.");
      return;
    }

    setIsSubmitting(true);
    setAreaModalError(null);
    try {
      await areaService.createArea(activeEvent.id, {
        name: areaName.trim(),
      });
      closeAreaModal();
      setNotification({
        type: "success",
        text: "Grande Área do Conhecimento cadastrada com sucesso!",
      });
      await refreshAreas();
    } catch (err: any) {
      setAreaModalError(err.response?.data?.detail || "Erro ao cadastrar grande área.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCreateSubarea = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetArea) return;

    if (!subareaName.trim()) {
      setSubareaModalError("Informe o nome da subárea.");
      return;
    }

    setIsSubmitting(true);
    setSubareaModalError(null);
    try {
      await areaService.createSubarea(targetArea.id, {
        name: subareaName.trim(),
      });
      closeSubareaModal();
      setNotification({
        type: "success",
        text: "Subárea cadastrada com sucesso!",
      });
      await refreshAreas();
    } catch (err: any) {
      setSubareaModalError(err.response?.data?.detail || "Erro ao cadastrar subárea.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteArea = async (area: KnowledgeArea) => {
    if (
      !confirm(
        `Tem certeza que deseja excluir a área "${area.name}"?\nEsta ação falhará se houver subáreas vinculadas a ela.`
      )
    ) {
      return;
    }
    setNotification(null);
    try {
      await areaService.deleteArea(area.id);
      setNotification({
        type: "success",
        text: `Área "${area.name}" removida com sucesso.`,
      });
      await refreshAreas();
    } catch (err: any) {
      // Bloqueio de integridade referencial
      setNotification({
        type: "error",
        text:
          err.response?.data?.detail ||
          "Não é possível excluir: existem subáreas ativas vinculadas a esta área.",
      });
    }
  };

  const handleDeleteSubarea = async (subareaId: number, subareaNameStr: string) => {
    if (
      !confirm(
        `Tem certeza que deseja excluir a subárea "${subareaNameStr}"?\nEsta ação falhará se houver projetos vinculados a ela.`
      )
    ) {
      return;
    }
    setNotification(null);
    try {
      await areaService.deleteSubarea(subareaId);
      setNotification({
        type: "success",
        text: `Subárea "${subareaNameStr}" removida com sucesso.`,
      });
      await refreshAreas();
    } catch (err: any) {
      // Bloqueio de integridade referencial
      setNotification({
        type: "error",
        text:
          err.response?.data?.detail ||
          "Não é possível excluir: existem projetos ativos vinculados a esta subárea.",
      });
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white flex items-center gap-2.5">
            <BookOpen className="text-teal-600 dark:text-teal-400" size={26} />
            Áreas e Subáreas do Conhecimento
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            Estrutura temática científica para classificação de projetos e distribuição por afinidade de avaliadores.
          </p>
        </div>

        <div className="flex items-center flex-wrap gap-2">
          <Button
            variant="outline"
            onClick={() => downloadAreasCsvTemplate(activeEvent?.id)}
            className="text-xs"
            title="Baixar modelo esqueleto CSV compatível com Microsoft Excel"
          >
            <Download size={15} className="mr-1.5 text-blue-600 dark:text-blue-400" />
            Baixar Modelo CSV
          </Button>

          <Button
            variant="primary"
            onClick={() => setIsImportModalOpen(true)}
            className="text-xs"
            title="Importar grandes áreas e subáreas em lote via planilha CSV com pré-visualização"
          >
            <Upload size={15} className="mr-1.5" />
            Importar CSV
          </Button>

          <Button
            variant="outline"
            onClick={openAreaModal}
            disabled={isLoadingAreas}
            className="text-xs"
          >
            <Plus size={16} className="mr-1.5 text-slate-600 dark:text-slate-300" />
            Nova Grande Área
          </Button>
        </div>
      </div>

      {/* Notification Banner */}
      {notification && (
        <div
          className={`p-4 rounded-xl text-sm flex items-start justify-between gap-3 border transition-all ${
            notification.type === "success"
              ? "bg-emerald-50 text-emerald-800 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-800"
              : "bg-rose-50 text-rose-800 border-rose-200 dark:bg-rose-950/40 dark:text-rose-300 dark:border-rose-800"
          }`}
        >
          <div className="flex items-start gap-2.5">
            {notification.type === "success" ? (
              <CheckCircle2 size={18} className="flex-shrink-0 mt-0.5 text-emerald-600 dark:text-emerald-400" />
            ) : (
              <AlertCircle size={18} className="flex-shrink-0 mt-0.5 text-rose-600 dark:text-rose-400" />
            )}
            <span>{notification.text}</span>
          </div>
          <button
            onClick={() => setNotification(null)}
            className="text-xs font-semibold opacity-70 hover:opacity-100"
          >
            Fechar
          </button>
        </div>
      )}

      {/* Active Event Banner & Switch Link (BR-19) */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-blue-50 dark:bg-blue-950/50 text-blue-600 dark:text-blue-400">
            <Calendar size={22} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                Edição Ativa no Painel
              </span>
              <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-blue-100 dark:bg-blue-900/60 text-blue-800 dark:text-blue-300">
                Ano {activeEvent?.year}
              </span>
            </div>
            <p className="text-base font-semibold text-slate-900 dark:text-white mt-0.5">
              {activeEvent?.name}
            </p>
          </div>
        </div>

        <Link href="/events">
          <Button variant="outline" size="sm" className="gap-1.5 text-xs">
            <span>Trocar Edição</span>
            <ArrowRight size={13} />
          </Button>
        </Link>
      </div>

      {/* Main Content Area */}
      {isLoadingAreas ? (
        <div className="py-16 text-center text-sm text-slate-400">
          Carregando áreas e subáreas temáticas...
        </div>
      ) : areas.length === 0 ? (
        <Card className="p-12 text-center">
          <Layers size={36} className="mx-auto text-slate-300 dark:text-slate-600 mb-3" />
          <h3 className="text-base font-semibold text-slate-900 dark:text-white">
            Nenhuma Grande Área cadastrada
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 mb-4">
            A edição &quot;{activeEvent?.name}&quot; ainda não possui áreas temáticas cadastradas.
          </p>
          <Button onClick={openAreaModal} variant="primary" size="sm">
            <Plus size={14} className="mr-1.5" />
            Cadastrar Primeira Grande Área
          </Button>
        </Card>
      ) : (
        <div className="space-y-4">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 px-1">
            <span>
              Total: <strong>{areas.length}</strong> {areas.length === 1 ? "grande área" : "grandes áreas"} cadastradas
            </span>
          </div>

          {areas.map((area) => {
            const activeSubareas = area.subareas?.filter((s) => !s.deleted_at) || [];
            return (
            <Card key={area.id} className="overflow-hidden border border-slate-200 dark:border-slate-800">
              <CardHeader className="bg-slate-50/75 dark:bg-slate-800/40 flex flex-col sm:flex-row sm:items-center justify-between gap-3 py-3.5 px-4 border-b border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-teal-50 dark:bg-teal-950/60 text-teal-600 dark:text-teal-400">
                    <BookOpen size={18} />
                  </div>
                  <div>
                    <CardTitle className="text-base font-bold text-slate-900 dark:text-white">
                      {area.name}
                    </CardTitle>
                    <span className="text-xs text-slate-400">
                      {activeSubareas.length} {activeSubareas.length === 1 ? "subárea vinculada" : "subáreas vinculadas"}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-end sm:self-auto">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => openSubareaModal(area)}
                    className="text-xs gap-1.5"
                  >
                    <FolderPlus size={14} />
                    <span>Adicionar Subárea</span>
                  </Button>

                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-rose-600 hover:text-rose-700 hover:bg-rose-50 dark:hover:bg-rose-950/40 p-2"
                    onClick={() => handleDeleteArea(area)}
                    title="Excluir Área"
                  >
                    <Trash2 size={16} />
                  </Button>
                </div>
              </CardHeader>

              <CardContent className="p-4">
                <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-3">
                  Subáreas Especializadas
                </div>

                {activeSubareas.length === 0 ? (
                  <div className="p-4 rounded-lg bg-slate-50/50 dark:bg-slate-900/30 border border-dashed border-slate-200 dark:border-slate-800 text-center">
                    <p className="text-xs text-slate-400 italic">
                      Nenhuma subárea cadastrada nesta grande área. Clique em &quot;Adicionar Subárea&quot; para cadastrar as especialidades científicas.
                    </p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
                    {activeSubareas.map((sub) => (
                      <div
                        key={sub.id}
                        className="flex items-center justify-between p-3 rounded-lg border border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs shadow-sm hover:border-teal-500/40 transition-colors group"
                      >
                        <div className="flex items-center gap-2.5 truncate min-w-0 pr-2">
                          <Tag size={13} className="text-teal-600 dark:text-teal-400 flex-shrink-0" />
                          <span className="font-semibold text-slate-800 dark:text-slate-200 truncate">
                            {sub.name}
                          </span>
                        </div>

                        <button
                          onClick={() => handleDeleteSubarea(sub.id, sub.name)}
                          className="text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 p-1 rounded transition-colors opacity-70 group-hover:opacity-100 flex-shrink-0"
                          title={`Excluir subárea "${sub.name}"`}
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
            );
          })}
        </div>
      )}

      {/* Modal: Nova Grande Área */}
      <Modal
        isOpen={isAreaModalOpen}
        onClose={closeAreaModal}
        error={areaModalError}
        title="Cadastrar Nova Grande Área do Conhecimento"
      >
        <form onSubmit={handleCreateArea} className="space-y-4">
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Cadastre uma grande área científica (CNPq/CAPES) para a edição selecionada (Ex: Ciências Exatas e da Terra, Ciências Humanas, etc.).
          </p>

          <Input
            label="Nome da Grande Área *"
            required
            placeholder="Ex: Ciências Exatas e da Terra"
            value={areaName}
            onChange={(e) => setAreaName(e.target.value)}
          />

          <div className="flex justify-end gap-2 pt-4 border-t border-slate-100 dark:border-slate-800">
            <Button
              type="button"
              variant="outline"
              onClick={closeAreaModal}
              disabled={isSubmitting}
            >
              Cancelar
            </Button>
            <Button type="submit" variant="primary" isLoading={isSubmitting}>
              Salvar Grande Área
            </Button>
          </div>
        </form>
      </Modal>

      {/* Modal: Nova Subárea */}
      <Modal
        isOpen={isSubareaModalOpen}
        onClose={closeSubareaModal}
        error={subareaModalError}
        title={`Nova Subárea em "${targetArea?.name || ""}"`}
      >
        <form onSubmit={handleCreateSubarea} className="space-y-4">
          <p className="text-xs text-slate-500 dark:text-slate-400">
            A subárea é utilizada para categorizar projetos e direcioná-los a avaliadores que possuam afinidade com a temática correspondente.
          </p>

          <Input
            label="Nome da Subárea *"
            required
            placeholder="Ex: Ciência da Computação / Robótica"
            value={subareaName}
            onChange={(e) => setSubareaName(e.target.value)}
          />

          <div className="flex justify-end gap-2 pt-4 border-t border-slate-100 dark:border-slate-800">
            <Button
              type="button"
              variant="outline"
              onClick={closeSubareaModal}
              disabled={isSubmitting}
            >
              Cancelar
            </Button>
            <Button type="submit" variant="primary" isLoading={isSubmitting}>
              Salvar Subárea
            </Button>
          </div>
        </form>
      </Modal>

      {/* Modal de Importação em Lote via Planilha CSV */}
      {activeEvent && (
        <AreasCsvImportModal
          isOpen={isImportModalOpen}
          onClose={() => setIsImportModalOpen(false)}
          eventId={activeEvent.id}
          existingAreas={areas}
          onSuccess={async (summary) => {
            setNotification({
              type: "success",
              text: `Importação concluída com sucesso! ${summary.totalAreas} grande(s) área(s) e ${summary.totalSubareas} subárea(s) sincronizada(s): ${summary.createdAreas} nova(s) área(s) e ${summary.createdSubareas} nova(s) subárea(s) criada(s).`,
            });
            await refreshAreas();
          }}
        />
      )}
    </div>
  );
}
