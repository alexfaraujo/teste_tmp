"use client";

import React, { useEffect, useState, useRef, useCallback } from "react";
import Link from "next/link";
import {
  Calendar,
  Sparkles,
  ArrowRight,
  Activity,
  AlertCircle,
  Tv,
  Copy,
  Check,
  ExternalLink,
  Bell,
  X,
  CheckCircle2,
  Users,
} from "lucide-react";
import { dashboardService } from "../../services/dashboard.service";
import { allocationService, AutoBalanceSummaryResponse } from "../../services/allocation.service";
import { AdminOverviewResponse, CriticalProjectItem } from "../../types";
import { useActiveEvent } from "../../context/EventContext";
import { RequireActiveEvent } from "../../components/common/RequireActiveEvent";
import { Button } from "../../components/ui/Button";
import { Modal } from "../../components/ui/Modal";
import { QuickActionsBar } from "../../components/dashboard/QuickActionsBar";
import { AdminKpiCards } from "../../components/dashboard/AdminKpiCards";
import { AreaRiskGrid } from "../../components/dashboard/AreaRiskGrid";
import { CriticalProjectsWidget } from "../../components/dashboard/CriticalProjectsWidget";
import { ManualAllocationModal } from "../../components/dashboard/ManualAllocationModal";
import { EventAdminsModal } from "../../components/events/EventAdminsModal";

interface ToastNotification {
  id: string;
  message: string;
  type: "info" | "success" | "warning";
  timestamp: string;
}

export default function DashboardPage() {
  return (
    <RequireActiveEvent featureName="o Painel de Visão Geral">
      <DashboardContent />
    </RequireActiveEvent>
  );
}

function DashboardContent() {
  const { activeEvent, clearActiveEvent } = useActiveEvent();

  // Estados de Dados Principais
  const [data, setData] = useState<AdminOverviewResponse | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);

  // Estados de Polling em Tempo Real (6A: 30 segundos)
  const POLL_INTERVAL = 30;
  const [secondsRemaining, setSecondsRemaining] = useState<number>(POLL_INTERVAL);
  const [isPaused, setIsPaused] = useState(false);

  // Estados de Notificações em Tempo Real (6B: Toasts)
  const [toasts, setToasts] = useState<ToastNotification[]>([]);
  const prevDataRef = useRef<AdminOverviewResponse | null>(null);

  // Estados dos Modais de Intervenção Rápida (5: Auto-Balance e Manual)
  const [isAutoBalanceModalOpen, setIsAutoBalanceModalOpen] = useState(false);
  const [isAutoBalancing, setIsAutoBalancing] = useState(false);
  const [balanceSummary, setBalanceSummary] = useState<AutoBalanceSummaryResponse | null>(null);

  const [isManualModalOpen, setIsManualModalOpen] = useState(false);
  const [manualInitialProject, setManualInitialProject] = useState<CriticalProjectItem | null>(null);

  // Modal de Gestão da Equipe do Evento (exclusivo para Coordenadores)
  const [isTeamModalOpen, setIsTeamModalOpen] = useState(false);

  // Perfil administrativo do usuário no evento ativo
  const isOperator = activeEvent?.user_role === "OPERATOR";
  const isCoordinator = Boolean(activeEvent?.is_owner || activeEvent?.user_role === "COORDINATOR");

  // Adiciona notificação Toast temporária
  const addToast = useCallback((message: string, type: "info" | "success" | "warning" = "info") => {
    const id = `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    const newToast: ToastNotification = {
      id,
      message,
      type,
      timestamp: new Date().toLocaleTimeString(),
    };
    setToasts((prev) => [newToast, ...prev.slice(0, 4)]);

    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 5000);
  }, []);

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Função Central de Busca dos Dados: Requisição Única Otimizada para Toda a Tela
  const loadAdminOverview = useCallback(
    async (eventId: number, isManualRefresh = false) => {
      if (isManualRefresh) setIsRefreshing(true);
      setError(null);

      try {
        const overview = await dashboardService.getAdminOverview(eventId);

        // Disparo de Alertas Toast em Tempo Real (6B) comparando com o ciclo anterior
        if (prevDataRef.current && prevDataRef.current.event_id === eventId) {
          const prev = prevDataRef.current;
          const curr = overview;

          // 1. Novo avaliador fez check-in
          if (curr.kpis.evaluators.present > prev.kpis.evaluators.present) {
            const diff = curr.kpis.evaluators.present - prev.kpis.evaluators.present;
            addToast(
              `🟢 ${diff} novo(s) avaliador(es) credenciado(s) na Sala dos Avaliadores!`,
              "success"
            );
          }

          // 2. Nova avaliação homologada
          if (curr.kpis.progress.evaluations_completed > prev.kpis.progress.evaluations_completed) {
            const diff = curr.kpis.progress.evaluations_completed - prev.kpis.progress.evaluations_completed;
            addToast(
              `🎉 ${diff} nova(s) ficha(s) de avaliação concluída(s) e homologada(s)!`,
              "success"
            );
          }

          // 3. Novo projeto credenciado no estande
          if (curr.kpis.projects.present > prev.kpis.projects.present) {
            const diff = curr.kpis.projects.present - prev.kpis.projects.present;
            addToast(
              `📋 ${diff} novo(s) projeto(s) credenciado(s) em estande!`,
              "info"
            );
          }
        }

        prevDataRef.current = overview;
        setData(overview);
        setLastUpdated(new Date());
      } catch (err: any) {
        if (err.response?.status === 403) {
          clearActiveEvent();
          setError("Acesso não autorizado para esta feira. O contexto foi redefinido.");
        } else {
          setError(
            err.response?.data?.detail || "Erro ao carregar dados consolidados da Visão Geral."
          );
        }
      } finally {
        setIsLoading(false);
        setIsRefreshing(false);
      }
    },
    [addToast]
  );

  // Carrega ao mudar o evento ativo
  useEffect(() => {
    if (activeEvent?.id) {
      setIsLoading(true);
      setSecondsRemaining(POLL_INTERVAL);
      loadAdminOverview(activeEvent.id);
    }
  }, [activeEvent?.id, loadAdminOverview]);

  // Ciclo de Polling Inteligente de 30 Segundos (6A)
  useEffect(() => {
    if (!activeEvent?.id || isPaused) return;

    const timer = setInterval(() => {
      setSecondsRemaining((prev) => {
        if (prev <= 1) {
          loadAdminOverview(activeEvent.id);
          return POLL_INTERVAL;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [activeEvent?.id, isPaused, loadAdminOverview]);

  // Handler de Atualização Manual Forçada
  const handleManualRefresh = () => {
    if (activeEvent?.id) {
      setSecondsRemaining(POLL_INTERVAL);
      loadAdminOverview(activeEvent.id, true);
    }
  };

  // Handler de Auto-Balance (Regra de Ouro delta <= 1)
  const handleAutoBalance = async () => {
    if (!activeEvent?.id) return;
    setIsAutoBalancing(true);
    try {
      const summary = await allocationService.autoBalance(activeEvent.id);
      setBalanceSummary(summary);
      setIsAutoBalanceModalOpen(true);
      addToast(`⚖️ Auto-balanceamento concluído: ${summary.total_allocations_created} alocações geradas.`, "success");
      loadAdminOverview(activeEvent.id, true);
    } catch (err: any) {
      addToast(err.response?.data?.detail || "Erro ao executar rebalanceamento automático.", "warning");
    } finally {
      setIsAutoBalancing(false);
    }
  };

  // Handler para alocar a partir de um projeto crítico específico
  const handleAllocateCriticalProject = (project: CriticalProjectItem) => {
    setManualInitialProject(project);
    setIsManualModalOpen(true);
  };

  const kioskPort = process.env.NEXT_PUBLIC_KIOSK_PORT || "3003";
  const kioskUrl =
    typeof window !== "undefined" && activeEvent?.id
      ? `${window.location.protocol}//${window.location.hostname}:${kioskPort}/?event_id=${activeEvent.id}`
      : `http://localhost:3003/?event_id=${activeEvent?.id || 1}`;

  const handleCopyKioskUrl = () => {
    if (typeof navigator !== "undefined" && navigator.clipboard) {
      navigator.clipboard.writeText(kioskUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  return (
    <div className="space-y-8 relative">
      {/* =========================================================================
          NOTIFICAÇÕES TOAST EM TEMPO REAL (6B)
         ========================================================================= */}
      {toasts.length > 0 && (
        <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-2 max-w-sm w-full pointer-events-none">
          {toasts.map((toast) => (
            <div
              key={toast.id}
              className={`p-3.5 rounded-2xl shadow-xl border pointer-events-auto flex items-start justify-between gap-3 text-xs font-semibold backdrop-blur-md transition-all animate-in slide-in-from-right-4 ${
                toast.type === "success"
                  ? "bg-emerald-900/90 text-white border-emerald-500/50 shadow-emerald-950/40"
                  : toast.type === "warning"
                  ? "bg-amber-900/90 text-white border-amber-500/50 shadow-amber-950/40"
                  : "bg-blue-900/90 text-white border-blue-500/50 shadow-blue-950/40"
              }`}
            >
              <div className="flex items-start gap-2">
                <Bell size={15} className="mt-0.5 flex-shrink-0 animate-bounce" />
                <div>
                  <p>{toast.message}</p>
                  <span className="text-[10px] opacity-75 font-mono">{toast.timestamp}</span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => removeToast(toast.id)}
                className="opacity-70 hover:opacity-100 p-0.5"
              >
                <X size={14} />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* =========================================================================
          CABEÇALHO OFICIAL: Título + Edição Ativa + Banner Kiosk TV
         ========================================================================= */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white flex items-center gap-2.5">
            <Activity className="text-blue-600 dark:text-blue-400" size={26} />
            Centro de Comando & Visão Geral
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            War Room consolidado em tempo real: aderência de avaliadores, estandes críticos e apuração oficial.
          </p>
        </div>

        {/* Edição Ativa (BR-19, BR-20) */}
        {activeEvent && (
          <div className="flex items-center gap-3 p-3 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm">
            <div className="p-2 rounded-xl bg-blue-50 dark:bg-blue-950/50 text-blue-600 dark:text-blue-400">
              <Calendar size={18} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                  Edição Ativa:
                </span>
                <span className="text-[11px] font-bold px-1.5 py-0.2 rounded bg-blue-100 dark:bg-blue-900/60 text-blue-800 dark:text-blue-300">
                  {activeEvent.year}
                </span>
                <span className="text-[11px] font-black px-2 py-0.5 rounded bg-amber-100 dark:bg-amber-950/70 text-amber-800 dark:text-amber-300 border border-amber-300 dark:border-amber-800/80">
                  ID: #{activeEvent.id}
                </span>
              </div>
              <p className="text-xs font-semibold text-slate-900 dark:text-white max-w-[200px] truncate">
                {activeEvent.name}
              </p>
            </div>
            {isCoordinator && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsTeamModalOpen(true)}
                className="ml-2 text-xs gap-1.5 py-1 h-8 text-blue-700 dark:text-blue-300 border-blue-200 dark:border-blue-900 bg-blue-50/60 dark:bg-blue-950/40 hover:bg-blue-100 dark:hover:bg-blue-900/60"
                title="Gerenciar Equipe do Evento (Coordenadores, Organizadores e Apoio)"
              >
                <Users size={13} />
                <span>Equipe</span>
              </Button>
            )}
            <Link href="/events" className="ml-1.5">
              <Button variant="outline" size="sm" className="text-xs gap-1 py-1 h-8">
                <span>Trocar</span>
                <ArrowRight size={12} />
              </Button>
            </Link>
          </div>
        )}
      </div>

      {/* Banner de Integração com o Telão TV Kiosk (BR-20) */}
      {activeEvent && (
        <div className="p-4 rounded-2xl bg-gradient-to-r from-slate-900 via-blue-950 to-slate-900 text-white border border-blue-900/60 shadow-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-11 h-11 rounded-xl bg-teal-500/20 border border-teal-400/40 text-teal-300 flex items-center justify-center flex-shrink-0">
              <Tv size={22} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-black uppercase tracking-wider text-teal-400">
                  Telão TV Kiosk ao Vivo (Público)
                </span>
                <span className="text-[11px] font-black px-2 py-0.5 rounded bg-teal-500/20 text-teal-300 border border-teal-400/30">
                  ID: #{activeEvent.id}
                </span>
              </div>
              <p className="text-xs text-blue-200/90 mt-0.5 font-medium">
                URL oficial configurada para Smart TVs do pavilhão:{" "}
                <code className="px-1.5 py-0.5 rounded bg-black/40 text-teal-300 font-mono text-[11px]">
                  {kioskUrl}
                </code>
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2.5 flex-shrink-0">
            <button
              type="button"
              onClick={handleCopyKioskUrl}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-blue-500/40 bg-blue-900/60 hover:bg-blue-800/80 text-white text-xs font-semibold transition-all h-9 active:scale-95 shadow-sm"
              title="Copiar link do Telão TV para a área de transferência"
            >
              {copied ? <Check size={14} className="text-teal-400" /> : <Copy size={14} />}
              <span>{copied ? "URL Copiada!" : "Copiar Link"}</span>
            </button>
            <a
              href={kioskUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white text-xs font-bold transition-all shadow-md active:scale-95 h-9"
            >
              <ExternalLink size={14} />
              <span>Abrir Telão da TV</span>
            </a>
          </div>
        </div>
      )}

      {/* Erro se houver */}
      {error && (
        <div className="p-4 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 text-red-700 dark:text-red-300 text-sm flex items-center gap-3">
          <AlertCircle size={18} className="flex-shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* =========================================================================
          BARRA DE AÇÕES RÁPIDAS & CONTROLES DE TEMPO REAL (Dimensão 1A + 5 + 6A)
         ========================================================================= */}
      <QuickActionsBar
        onAutoBalance={handleAutoBalance}
        onRefresh={handleManualRefresh}
        isPaused={isPaused}
        onTogglePause={() => setIsPaused(!isPaused)}
        secondsRemaining={secondsRemaining}
        totalInterval={POLL_INTERVAL}
        isRefreshing={isRefreshing}
        lastUpdated={lastUpdated}
        isOperator={isOperator}
      />

      {/* Estado de Carregamento Inicial */}
      {isLoading ? (
        <div className="p-16 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-center space-y-3">
          <div className="w-10 h-10 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-sm font-bold text-slate-700 dark:text-slate-300">
            Sincronizando Centro de Comando do EasyEvent...
          </p>
          <p className="text-xs text-slate-400">
            Carregando presenças, estandes, avaliadores e diagnóstico de risco em requisição única.
          </p>
        </div>
      ) : data ? (
        <>
          {/* =========================================================================
              OS 4 CARDS MÉTRICOS ENRIQUECIDOS COM SVG CIRCULAR (2A.3, 2B, 2C, 2D)
             ========================================================================= */}
          <AdminKpiCards kpis={data.kpis} />

          {/* =========================================================================
              WIDGET DE TRABALHOS CRÍTICOS & GAPS DE AVALIAÇÃO (Dimensão 4A)
             ========================================================================= */}
          <CriticalProjectsWidget
            criticalProjects={data.critical_projects}
            onAllocateProject={handleAllocateCriticalProject}
            canAllocate={!isOperator}
            headerAction={
              <Link
                href={`/monitor/critical-projects?event_id=${data.event_id}`}
                target="_blank"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-blue-200 dark:border-blue-900 bg-blue-50/60 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 hover:bg-blue-100 dark:hover:bg-blue-900/60 text-xs font-semibold transition-colors shadow-sm"
                title="Abrir Trabalhos Críticos em Nova Janela / Monitor Separado"
              >
                <ExternalLink size={13} />
                <span>Abrir em Nova Janela</span>
              </Link>
            }
          />

          {/* =========================================================================
              GRID DE GRANDES ÁREAS COM TERMÔMETRO DE COBERTURA DE AVALIADORES (Dimensão 3A)
             ========================================================================= */}
          <AreaRiskGrid
            areas={data.areas_diagnostic}
            canRegisterEvaluator={!isOperator}
            headerAction={
              <Link
                href={`/monitor/areas-risk?event_id=${data.event_id}`}
                target="_blank"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-teal-200 dark:border-teal-900 bg-teal-50/60 dark:bg-teal-950/40 text-teal-700 dark:text-teal-300 hover:bg-teal-100 dark:hover:bg-teal-900/60 text-xs font-semibold transition-colors shadow-sm"
                title="Abrir Termômetro de Áreas em Nova Janela / Monitor Separado"
              >
                <ExternalLink size={13} />
                <span>Abrir em Nova Janela</span>
              </Link>
            }
          />
        </>
      ) : null}

      {/* =========================================================================
          MODAL 1: RESUMO DO AUTO-BALANCEAMENTO (5.1)
         ========================================================================= */}
      {balanceSummary && (
        <Modal
          isOpen={isAutoBalanceModalOpen}
          onClose={() => setIsAutoBalanceModalOpen(false)}
          title="Relatório de Rebalanceamento Automático (Δ ≤ 1)"
        >
          <div className="space-y-4">
            <div className="p-3.5 rounded-xl bg-purple-50 dark:bg-purple-950/40 border border-purple-200 dark:border-purple-800/80 text-purple-800 dark:text-purple-200 text-xs flex items-center gap-2.5">
              <CheckCircle2 size={18} className="text-purple-600 flex-shrink-0" />
              <span>{balanceSummary.message}</span>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                <span className="text-slate-400 text-[10px] font-bold uppercase block">Novas Alocações Criadas</span>
                <span className="text-2xl font-black text-slate-900 dark:text-white mt-1 block font-mono">
                  {balanceSummary.total_allocations_created}
                </span>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                <span className="text-slate-400 text-[10px] font-bold uppercase block">Regra de Ouro (Δ ≤ 1)</span>
                <span className={`text-base font-black mt-1 block ${
                  balanceSummary.golden_rule_satisfied ? "text-emerald-600" : "text-amber-600"
                }`}>
                  {balanceSummary.golden_rule_satisfied ? "✓ Satisfeita" : "Atenção (Disparidade)"}
                </span>
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <Button
                type="button"
                variant="primary"
                size="sm"
                onClick={() => setIsAutoBalanceModalOpen(false)}
                className="bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold"
              >
                Concluir
              </Button>
            </div>
          </div>
        </Modal>
      )}

      {/* =========================================================================
          MODAL 2: ALOCAÇÃO MANUAL ÁGIL (5.2)
         ========================================================================= */}
      {activeEvent?.id && (
        <ManualAllocationModal
          isOpen={isManualModalOpen}
          onClose={() => setIsManualModalOpen(false)}
          eventId={activeEvent.id}
          initialProject={manualInitialProject}
          projects={data?.critical_projects || []}
          onSuccess={() => {
            if (activeEvent?.id) {
              loadAdminOverview(activeEvent.id, true);
            }
          }}
        />
      )}

      {/* =========================================================================
          MODAL 3: GESTÃO DA EQUIPE DO EVENTO (Centralizado para Coordenadores)
         ========================================================================= */}
      {activeEvent && isTeamModalOpen && (
        <EventAdminsModal
          isOpen={isTeamModalOpen}
          onClose={() => setIsTeamModalOpen(false)}
          event={activeEvent}
        />
      )}
    </div>
  );
}
