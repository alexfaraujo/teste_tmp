"use client";

import React, { useEffect, useState, useMemo } from "react";
import {
  ListChecks,
  Plus,
  Search,
  CheckCircle2,
  AlertCircle,
  Pencil,
  Trash2,
  FlaskConical,
  Cpu,
  HelpCircle,
  Scale,
  Download,
  Upload,
} from "lucide-react";
import { useActiveEvent } from "../../../context/EventContext";
import { RequireActiveEvent } from "../../../components/common/RequireActiveEvent";
import { criterionService } from "../../../services/criterion.service";
import { EvaluationCriterion } from "../../../types";
import { Button } from "../../../components/ui/Button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "../../../components/ui/Card";
import { Modal } from "../../../components/ui/Modal";
import { Input } from "../../../components/ui/Input";
import { Pagination } from "../../../components/ui/Pagination";
import { CriteriaCsvImportModal } from "../../../components/criteria/CriteriaCsvImportModal";
import { downloadCriteriaCsvTemplate } from "../../../utils/criteriaCsv";

export default function CriteriaPage() {
  const { activeEvent } = useActiveEvent();

  const [criteria, setCriteria] = useState<EvaluationCriterion[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [notification, setNotification] = useState<{
    type: "success" | "error";
    text: string;
  } | null>(null);

  // Modal de Importação CSV
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);

  // Busca e Paginação (BR-18)
  const [searchTerm, setSearchTerm] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 8;

  // Estado do Modal de Cadastro / Edição
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCriterionId, setEditingCriterionId] = useState<number | null>(null);
  const [name, setName] = useState("");
  const [isSingleType, setIsSingleType] = useState(false);
  const [singleQuestion, setSingleQuestion] = useState("");
  const [scientificDescription, setScientificDescription] = useState("");
  const [technologicalDescription, setTechnologicalDescription] = useState("");
  const [maxScore, setMaxScore] = useState<number>(10.0);
  const [weight, setWeight] = useState<number>(1.0);
  const [modalError, setModalError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Estado do Modal de Exclusão
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [deletingCriterion, setDeletingCriterion] = useState<EvaluationCriterion | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [deleteModalError, setDeleteModalError] = useState<string | null>(null);

  async function loadCriteria() {
    if (!activeEvent) return;
    setIsLoading(true);
    try {
      const data = await criterionService.getCriteria(activeEvent.id);
      setCriteria(data);
    } catch (err: any) {
      setNotification({
        type: "error",
        text: "Erro ao carregar os critérios de avaliação da edição.",
      });
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    loadCriteria();
  }, [activeEvent?.id]);

  // Filtragem e Paginação
  const filteredCriteria = useMemo(() => {
    if (!searchTerm.trim()) return criteria;
    const term = searchTerm.toLowerCase();
    return criteria.filter(
      (c) =>
        c.name.toLowerCase().includes(term) ||
        (c.scientific_description &&
          c.scientific_description.toLowerCase().includes(term)) ||
        (c.technological_description &&
          c.technological_description.toLowerCase().includes(term))
    );
  }, [criteria, searchTerm]);

  const totalPages = Math.ceil(filteredCriteria.length / itemsPerPage) || 1;
  const paginatedCriteria = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    return filteredCriteria.slice(start, start + itemsPerPage);
  }, [filteredCriteria, currentPage, itemsPerPage]);

  // Abrir Modal de Criação
  const handleOpenCreateModal = () => {
    setEditingCriterionId(null);
    setName("");
    setScientificDescription("");
    setTechnologicalDescription("");
    setSingleQuestion("");
    setIsSingleType(false);
    setMaxScore(10.0);
    setWeight(1.0);
    setModalError(null);
    setIsModalOpen(true);
  };

  // Abrir Modal de Edição
  const handleOpenEditModal = (crit: EvaluationCriterion) => {
    setEditingCriterionId(crit.id);
    setName(crit.name);
    const sci = crit.scientific_description || "";
    const tech = crit.technological_description || "";
    setScientificDescription(sci);
    setTechnologicalDescription(tech);
    const hasSameQuestion = Boolean(sci && tech && sci.trim() === tech.trim());
    setIsSingleType(hasSameQuestion);
    setSingleQuestion(sci || tech);
    setMaxScore(Number(crit.max_score) || 10.0);
    setWeight(Number(crit.weight) || 1.0);
    setModalError(null);
    setIsModalOpen(true);
  };

  // Salvar Critério (Create / Update)
  const handleSubmitCriterion = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeEvent) return;

    if (!name.trim()) {
      setModalError("O identificador / título do critério é obrigatório.");
      return;
    }

    let sciText = scientificDescription.trim();
    let techText = technologicalDescription.trim();

    if (isSingleType) {
      const unifiedText = (singleQuestion || scientificDescription || technologicalDescription).trim();
      if (!unifiedText) {
        setModalError("A pergunta da avaliação é obrigatória.");
        return;
      }
      sciText = unifiedText;
      techText = unifiedText;
    } else {
      if (!sciText) {
        setModalError("A pergunta / formulação para trabalhos científicos é obrigatória.");
        return;
      }
      if (!techText) {
        setModalError("A pergunta / formulação para trabalhos tecnológicos é obrigatória.");
        return;
      }
    }

    if (maxScore <= 0) {
      setModalError("A pontuação máxima deve ser maior do que zero.");
      return;
    }

    if (weight <= 0) {
      setModalError("O peso padrão deve ser maior do que zero.");
      return;
    }

    setIsSubmitting(true);
    setModalError(null);

    const payload = {
      name: name.trim(),
      scientific_description: sciText,
      technological_description: techText,
      max_score: maxScore,
      weight: weight,
    };

    try {
      if (editingCriterionId) {
        await criterionService.updateCriterion(
          activeEvent.id,
          editingCriterionId,
          payload
        );
        setNotification({
          type: "success",
          text: `Critério "${name.trim()}" atualizado com sucesso!`,
        });
      } else {
        await criterionService.createCriterion(activeEvent.id, payload);
        setNotification({
          type: "success",
          text: `Critério "${name.trim()}" cadastrado com sucesso!`,
        });
      }

      setIsModalOpen(false);
      await loadCriteria();
    } catch (err: any) {
      setModalError(
        err.response?.data?.detail || "Erro ao salvar o critério de avaliação."
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  // Abrir Modal de Exclusão
  const handleOpenDeleteModal = (crit: EvaluationCriterion) => {
    setDeletingCriterion(crit);
    setDeleteModalError(null);
    setIsDeleteModalOpen(true);
  };

  // Confirmar Exclusão
  const handleConfirmDelete = async () => {
    if (!activeEvent || !deletingCriterion) return;
    setIsDeleting(true);
    setDeleteModalError(null);

    try {
      await criterionService.deleteCriterion(activeEvent.id, deletingCriterion.id);
      setNotification({
        type: "success",
        text: `Critério "${deletingCriterion.name}" desativado com sucesso!`,
      });
      setIsDeleteModalOpen(false);
      setDeletingCriterion(null);
      await loadCriteria();
    } catch (err: any) {
      setDeleteModalError(
        err.response?.data?.detail || "Erro ao excluir o critério de avaliação."
      );
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <RequireActiveEvent minRole="ORGANIZER" featureName="os Critérios de Avaliação">
      <div className="space-y-6 max-w-7xl mx-auto">
        {/* Page Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white flex items-center gap-2.5">
              <ListChecks className="text-blue-600 dark:text-blue-400" size={26} />
              Critérios de Avaliação da Edição
            </h1>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
              Parametrização unificada das perguntas da ficha mobile para projetos científicos e tecnológicos.
            </p>
          </div>

          <div className="flex items-center flex-wrap gap-2">
            <Button
              variant="outline"
              onClick={() => downloadCriteriaCsvTemplate(activeEvent?.id)}
              className="text-xs"
              title="Baixar modelo esqueleto CSV compatível com Microsoft Excel"
            >
              <Download size={15} className="mr-1.5 text-blue-600 dark:text-blue-400" />
              Baixar Modelo CSV
            </Button>

            <Button
              variant="primary"
              onClick={() => setIsImportModalOpen(true)}
              className="text-xs"
              title="Importar critérios de avaliação em lote via planilha CSV com pré-visualização"
            >
              <Upload size={15} className="mr-1.5" />
              Importar CSV
            </Button>

            <Button
              variant="outline"
              onClick={handleOpenCreateModal}
              className="text-xs"
            >
              <Plus size={16} className="mr-1.5 text-slate-600 dark:text-slate-300" />
              Novo Critério
            </Button>
          </div>
        </div>

        {/* Banner Explicativo da Mecânica de Pergunta Dual / Unificada */}
        <div className="p-4 rounded-xl bg-gradient-to-r from-blue-50 via-indigo-50/60 to-teal-50/70 dark:from-slate-900 dark:via-blue-950/30 dark:to-teal-950/20 border border-blue-200/80 dark:border-blue-900/50 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <div className="p-2.5 rounded-xl bg-blue-600 text-white shadow-sm flex-shrink-0">
              <Scale size={20} />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                Flexibilidade na Ficha de Avaliação: Pergunta Dual ou Pergunta Única
              </h3>
              <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 leading-relaxed">
                Cada critério cadastrado compartilha <strong>a mesma pontuação máxima</strong>, <strong>o mesmo peso padrão</strong> e <strong>a mesma ordem na ficha</strong>.
              </p>
              <ul className="text-xs text-slate-600 dark:text-slate-300 mt-1.5 space-y-1">
                <li>
                  • <strong>Eventos com distinção metodológica:</strong> Cadastre perguntas diferentes para trabalhos <span className="font-bold text-blue-700 dark:text-blue-300">🔬 Científicos</span> e <span className="font-bold text-teal-700 dark:text-teal-300">⚙️ Tecnológicos</span>. O app mobile exibirá automaticamente a formulação correspondente ao tipo do trabalho.
                </li>
                <li>
                  • <strong>Eventos com tipo único de trabalho:</strong> Marque a opção <em>&quot;Evento com tipo único de trabalho&quot;</em> no cadastro do critério para definir uma pergunta única para todos os trabalhos. Todos os trabalhos do evento serão tratados como científicos e receberão essa mesma pergunta.
                </li>
              </ul>
            </div>
          </div>
        </div>

        {/* Notificação Externa */}
        {notification && (
          <div
            className={`p-4 rounded-xl text-sm flex items-start justify-between gap-2.5 border ${
              notification.type === "success"
                ? "bg-emerald-50 text-emerald-800 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-800"
                : "bg-rose-50 text-rose-800 border-rose-200 dark:bg-rose-950/40 dark:text-rose-300 dark:border-rose-800"
            }`}
          >
            <div className="flex items-start gap-2.5">
              {notification.type === "success" ? (
                <CheckCircle2 size={18} className="flex-shrink-0 mt-0.5" />
              ) : (
                <AlertCircle size={18} className="flex-shrink-0 mt-0.5" />
              )}
              <span>{notification.text}</span>
            </div>
            <button
              onClick={() => setNotification(null)}
              className="text-xs font-semibold hover:underline opacity-80"
            >
              Fechar
            </button>
          </div>
        )}

        {/* Barra de Busca e Filtros */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800">
          <div className="relative flex-1 max-w-md">
            <Search
              size={16}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
            />
            <input
              type="text"
              placeholder="Buscar por nome ou orientações do critério..."
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full pl-9 pr-4 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/20"
            />
          </div>

          <div className="text-xs text-slate-500 dark:text-slate-400">
            Total: <strong>{filteredCriteria.length}</strong> critério(s) configurado(s)
          </div>
        </div>

        {/* Lista de Critérios */}
        {isLoading ? (
          <div className="py-16 text-center text-slate-500 text-sm animate-pulse">
            Carregando critérios de avaliação da edição ativa...
          </div>
        ) : filteredCriteria.length === 0 ? (
          <Card className="p-12 text-center text-slate-500">
            <ListChecks size={40} className="mx-auto mb-3 text-slate-400 opacity-60" />
            <p className="font-semibold text-slate-700 dark:text-slate-300">
              Nenhum critério de avaliação encontrado.
            </p>
            <p className="text-xs text-slate-400 mt-1">
              Clique em &quot;Novo Critério&quot; para cadastrar as perguntas da ficha de avaliação.
            </p>
          </Card>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            {paginatedCriteria.map((crit) => (
              <Card
                key={crit.id}
                className="flex flex-col justify-between hover:shadow-md transition-shadow border-slate-200 dark:border-slate-800"
              >
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-3">
                      <div className="p-2.5 rounded-xl bg-blue-50 dark:bg-blue-950/50 text-blue-600 dark:text-blue-400 border border-blue-200 dark:border-blue-900/60 flex-shrink-0">
                        <Scale size={20} />
                      </div>
                      <div>
                        <CardTitle className="text-base font-bold text-slate-900 dark:text-white leading-tight">
                          {crit.name}
                        </CardTitle>
                        <div className="flex items-center gap-2 mt-1">
                          <span className="text-[11px] font-semibold px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
                            Nota Máx: {Number(crit.max_score).toFixed(1)} pts
                          </span>
                          <span className="text-[11px] font-bold px-2 py-0.5 rounded-md bg-blue-50 dark:bg-blue-950 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-900">
                            Peso: {Number(crit.weight).toFixed(1)}x
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Ações */}
                    <div className="flex items-center gap-1.5 flex-shrink-0">
                      <button
                        onClick={() => handleOpenEditModal(crit)}
                        className="p-1.5 text-slate-500 hover:text-blue-600 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
                        title="Editar critério"
                      >
                        <Pencil size={15} />
                      </button>
                      <button
                        onClick={() => handleOpenDeleteModal(crit)}
                        className="p-1.5 text-slate-500 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition-colors"
                        title="Excluir critério"
                      >
                        <Trash2 size={15} />
                      </button>
                    </div>
                  </div>
                </CardHeader>

                <CardContent className="p-4 bg-slate-50/60 dark:bg-slate-800/30 border-t border-slate-100 dark:border-slate-800 space-y-3">
                  {crit.scientific_description &&
                  crit.technological_description &&
                  crit.scientific_description.trim() === crit.technological_description.trim() ? (
                    /* Caso de Tipo Único de Trabalho: Mesma Pergunta */
                    <div className="p-3 rounded-lg bg-indigo-50/60 dark:bg-indigo-950/20 border border-indigo-200/70 dark:border-indigo-900/40 text-xs">
                      <div className="flex items-center gap-1.5 text-indigo-700 dark:text-indigo-400 font-bold mb-1.5">
                        <CheckCircle2 size={14} />
                        <span>Pergunta Unificada (Tipo Único de Trabalho):</span>
                      </div>
                      <p className="text-slate-700 dark:text-slate-300 text-xs leading-relaxed">
                        {crit.scientific_description}
                      </p>
                    </div>
                  ) : (
                    /* Caso de Pergunta Dual: Científica vs Tecnológica */
                    <>
                      {/* Pergunta para Projetos Científicos */}
                      <div className="p-3 rounded-lg bg-blue-50/50 dark:bg-blue-950/20 border border-blue-200/70 dark:border-blue-900/40 text-xs">
                        <div className="flex items-center gap-1.5 text-blue-700 dark:text-blue-400 font-bold mb-1.5">
                          <FlaskConical size={14} />
                          <span>Pergunta para Trabalhos Científicos:</span>
                        </div>
                        <p className="text-slate-700 dark:text-slate-300 text-xs leading-relaxed">
                          {crit.scientific_description || (
                            <span className="italic text-slate-400">
                              Nenhuma formulação científica registrada.
                            </span>
                          )}
                        </p>
                      </div>

                      {/* Pergunta para Projetos Tecnológicos */}
                      <div className="p-3 rounded-lg bg-teal-50/50 dark:bg-teal-950/20 border border-teal-200/70 dark:border-teal-900/40 text-xs">
                        <div className="flex items-center gap-1.5 text-teal-700 dark:text-teal-400 font-bold mb-1.5">
                          <Cpu size={14} />
                          <span>Pergunta para Trabalhos Tecnológicos:</span>
                        </div>
                        <p className="text-slate-700 dark:text-slate-300 text-xs leading-relaxed">
                          {crit.technological_description || (
                            <span className="italic text-slate-400">
                              Nenhuma formulação tecnológica registrada.
                            </span>
                          )}
                        </p>
                      </div>
                    </>
                  )}

                  <div className="pt-1 flex items-center justify-between text-[11px] text-slate-400 dark:text-slate-500">
                    <span>Ordem, peso e nota unificados</span>
                    <span className="flex items-center gap-1">
                      {crit.scientific_description &&
                      crit.technological_description &&
                      crit.scientific_description.trim() === crit.technological_description.trim()
                        ? "Aplicada a todos os trabalhos"
                        : "Alternância automática por tipo de projeto"}
                    </span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Paginação */}
        {filteredCriteria.length > itemsPerPage && (
          <div className="pt-2">
            <Pagination
              currentPage={currentPage}
              totalPages={totalPages}
              totalItems={filteredCriteria.length}
              limit={itemsPerPage}
              onPageChange={setCurrentPage}
            />
          </div>
        )}

        {/* MODAL: Cadastrar / Editar Critério (UX-01) */}
        <Modal
          isOpen={isModalOpen}
          onClose={() => !isSubmitting && setIsModalOpen(false)}
          title={
            editingCriterionId
              ? "Editar Critério de Avaliação"
              : "Cadastrar Novo Critério de Avaliação"
          }
          error={modalError}
        >
          <form onSubmit={handleSubmitCriterion} className="space-y-4">
            <div className="p-3 rounded-xl bg-blue-50/80 dark:bg-blue-950/40 border border-blue-200/80 dark:border-blue-900/60 text-xs text-blue-900 dark:text-blue-300 leading-relaxed">
              <strong>Orientações de Avaliação:</strong> A pontuação máxima, o peso e a ordem na ficha são rigorosamente unificados. 
              {isSingleType
                ? " Com a opção de tipo único ativada, a pergunta digitada abaixo será aplicada a todos os projetos da feira."
                : " Em eventos com divisão metodológica, o app mobile selecionará automaticamente a pergunta correspondente se o trabalho for Científico ou Tecnológico."}
            </div>

            <Input
              label="Identificador / Título do Critério *"
              placeholder="Ex: Critério 1: Rigor Metodológico / Projeto de Engenharia"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Pontuação Máxima * (unificada)
                </label>
                <input
                  type="number"
                  step="0.5"
                  min="1"
                  max="100"
                  value={maxScore}
                  onChange={(e) => setMaxScore(parseFloat(e.target.value) || 10.0)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-bold focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Peso Padrão na Ficha * (unificado)
                </label>
                <input
                  type="number"
                  step="0.1"
                  min="0.1"
                  max="10.0"
                  value={weight}
                  onChange={(e) => setWeight(parseFloat(e.target.value) || 1.0)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-bold focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                  required
                />
              </div>
            </div>

            {/* Checkbox: Evento com Tipo Único de Trabalho */}
            <div className="p-3 bg-slate-50 dark:bg-slate-800/70 rounded-xl border border-slate-200 dark:border-slate-700">
              <label className="flex items-start gap-2.5 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={isSingleType}
                  onChange={(e) => {
                    const checked = e.target.checked;
                    setIsSingleType(checked);
                    if (checked) {
                      const text = singleQuestion || scientificDescription || technologicalDescription;
                      setSingleQuestion(text);
                      setScientificDescription(text);
                      setTechnologicalDescription(text);
                    }
                  }}
                  className="mt-0.5 h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500 cursor-pointer"
                />
                <div className="text-xs">
                  <span className="font-semibold text-slate-800 dark:text-slate-200 block">
                    Evento com tipo único de trabalho (sem divisão entre Científico e Tecnológico)
                  </span>
                  <span className="text-slate-500 dark:text-slate-400 block mt-0.5 leading-relaxed">
                    Marque esta opção se o evento não separa projetos científicos de tecnológicos. O sistema preencherá as duas formulações com a mesma pergunta para que todos os trabalhos recebam esse enunciado.
                  </span>
                </div>
              </label>
            </div>

            {isSingleType ? (
              /* Campo Único de Pergunta */
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-semibold text-indigo-700 dark:text-indigo-400 flex items-center gap-1.5">
                    <HelpCircle size={14} />
                    Pergunta da Avaliação (Pergunta Única) *
                  </label>
                  <span className="text-[10px] text-slate-400">Aplicada a todos os trabalhos</span>
                </div>
                <textarea
                  rows={3}
                  placeholder="Ex: Como a equipe definiu a proposta, desenvolveu a metodologia de pesquisa/execução e apresentou as conclusões?"
                  value={singleQuestion}
                  onChange={(e) => {
                    const val = e.target.value;
                    setSingleQuestion(val);
                    setScientificDescription(val);
                    setTechnologicalDescription(val);
                  }}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  required
                />
                <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                  Esta mesma redação será aplicada tanto no fluxo de projetos científicos quanto tecnológicos.
                </p>
              </div>
            ) : (
              /* Campos Separados: Científico vs Tecnológico */
              <>
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-semibold text-blue-700 dark:text-blue-400 flex items-center gap-1.5">
                      <FlaskConical size={14} />
                      Pergunta para Trabalho Científico *
                    </label>
                    <span className="text-[10px] text-slate-400">Exibida em projetos científicos</span>
                  </div>
                  <textarea
                    rows={3}
                    placeholder="Ex: Como a equipe formulou a hipótese científica, conduziu o método experimental, controlou as variáveis e analisou criticamente os dados obtidos?"
                    value={scientificDescription}
                    onChange={(e) => setScientificDescription(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                    required
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-semibold text-teal-700 dark:text-teal-400 flex items-center gap-1.5">
                      <Cpu size={14} />
                      Pergunta para Trabalho Tecnológico *
                    </label>
                    <span className="text-[10px] text-slate-400">Exibida em projetos tecnológicos</span>
                  </div>
                  <textarea
                    rows={3}
                    placeholder="Ex: Como a equipe definiu a demanda técnica, projetou a arquitetura do protótipo/solução de engenharia e validou experimentalmente o funcionamento?"
                    value={technologicalDescription}
                    onChange={(e) => setTechnologicalDescription(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                    required
                  />
                </div>
              </>
            )}

            <div className="flex justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
              <Button
                type="button"
                variant="outline"
                onClick={() => setIsModalOpen(false)}
                disabled={isSubmitting}
              >
                Cancelar
              </Button>
              <Button type="submit" variant="primary" isLoading={isSubmitting}>
                {editingCriterionId ? "Atualizar Critério" : "Salvar Critério"}
              </Button>
            </div>
          </form>
        </Modal>

        {/* MODAL: Confirmação de Exclusão (UX-01) */}
        <Modal
          isOpen={isDeleteModalOpen}
          onClose={() => !isDeleting && setIsDeleteModalOpen(false)}
          title="Desativar Critério de Avaliação"
          error={deleteModalError}
        >
          <div className="space-y-4">
            <div className="p-3.5 bg-amber-50 dark:bg-amber-950/40 rounded-xl border border-amber-200 dark:border-amber-900/60 text-xs text-amber-800 dark:text-amber-300 leading-relaxed">
              Você tem certeza de que deseja desativar o critério{" "}
              <strong>&quot;{deletingCriterion?.name}&quot;</strong>?
              <br />
              <span className="block mt-1 text-[11px] text-amber-700 dark:text-amber-400">
                Atenção: Critérios que já possuem notas registradas em avaliações de projetos não podem ser excluídos para garantir a integridade histórica.
              </span>
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
              <Button
                type="button"
                variant="outline"
                onClick={() => setIsDeleteModalOpen(false)}
                disabled={isDeleting}
              >
                Cancelar
              </Button>
              <Button
                type="button"
                variant="danger"
                isLoading={isDeleting}
                onClick={handleConfirmDelete}
              >
                Sim, Desativar
              </Button>
            </div>
          </div>
        </Modal>

        {/* MODAL: Importação em Lote via Planilha CSV com Pré-visualização */}
        {activeEvent && (
          <CriteriaCsvImportModal
            isOpen={isImportModalOpen}
            onClose={() => setIsImportModalOpen(false)}
            eventId={activeEvent.id}
            existingCriteria={criteria}
            onSuccess={async (summary) => {
              setNotification({
                type: "success",
                text: `Importação concluída com sucesso! ${summary.total} critério(s) sincronizado(s): ${summary.created} novo(s) criado(s) e ${summary.updated} atualizado(s).`,
              });
              await loadCriteria();
            }}
          />
        )}
      </div>
    </RequireActiveEvent>
  );
}
