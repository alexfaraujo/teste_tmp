"use client";

import React, { useEffect, useRef, useState, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import Link from "next/link";
import {
  UtensilsCrossed,
  ScanBarcode,
  Camera,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Clock,
  User,
  ArrowLeft,
  Volume2,
  VolumeX,
  RefreshCw,
  Search,
  Sparkles,
  SwitchCamera,
} from "lucide-react";
import { Html5Qrcode } from "html5-qrcode";
import { useActiveEvent } from "../../../../context/EventContext";
import { RequireActiveEvent } from "../../../../components/common/RequireActiveEvent";
import { snackService } from "../../../../services/snack.service";
import { SnackMoment, SnackDeliverScanResponse } from "../../../../types";
import { Button } from "../../../../components/ui/Button";

// Web Audio API para feedback sonoro sintetizado nativo
function playAudioTone(type: "success" | "error" | "warning") {
  try {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return;
    const ctx = new AudioContextClass();

    if (type === "success") {
      // Bip duplo ascendente alegre (C5 -> G5)
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.setValueAtTime(523.25, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(783.99, ctx.currentTime + 0.15);
      gain.gain.setValueAtTime(0.3, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.25);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.25);
    } else if (type === "error") {
      // Bip grave descendente de alerta (F3 -> C3)
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sawtooth";
      osc.frequency.setValueAtTime(174.61, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(130.81, ctx.currentTime + 0.3);
      gain.gain.setValueAtTime(0.4, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.35);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.35);
    } else {
      // Alerta médio
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "triangle";
      osc.frequency.setValueAtTime(440, ctx.currentTime);
      gain.gain.setValueAtTime(0.3, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.2);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.2);
    }
  } catch (e) {
    // AudioContext pode ser bloqueado antes de interação do usuário
  }

  // Feedback tátil em smartphones
  if (typeof navigator !== "undefined" && navigator.vibrate) {
    if (type === "success") {
      navigator.vibrate([70]);
    } else if (type === "error") {
      navigator.vibrate([150, 100, 150]);
    }
  }
}

function SnackDistributionContent() {
  const searchParams = useSearchParams();
  const { activeEvent } = useActiveEvent();

  const [moments, setMoments] = useState<SnackMoment[]>([]);
  const [selectedMomentId, setSelectedMomentId] = useState<number | null>(null);
  const [isLoadingMoments, setIsLoadingMoments] = useState(true);

  // Input do leitor de código de barras físico
  const [barcodeInput, setBarcodeInput] = useState("");
  const barcodeInputRef = useRef<HTMLInputElement>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Câmera do Celular (html5-qrcode)
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const scannerRef = useRef<Html5Qrcode | null>(null);
  const cameraViewportId = "html5-snack-camera-viewport";

  // Áudio habilitado
  const [soundEnabled, setSoundEnabled] = useState(true);

  // Feedback do último scan
  const [lastScan, setLastScan] = useState<SnackDeliverScanResponse | null>(null);
  const [recentHistory, setRecentHistory] = useState<SnackDeliverScanResponse[]>([]);

  // Carregar momentos
  useEffect(() => {
    async function init() {
      if (!activeEvent) return;
      setIsLoadingMoments(true);
      try {
        const data = await snackService.getMoments(activeEvent.id);
        setMoments(data);

        // Se veio moment_id pela URL
        const paramId = searchParams.get("moment_id");
        if (paramId) {
          const found = data.find((m) => m.id === Number(paramId));
          if (found) {
            setSelectedMomentId(found.id);
          } else if (data.length > 0) {
            setSelectedMomentId(data[0].id);
          }
        } else {
          // Selecionar o primeiro ativo ou o primeiro da lista
          const activeOne = data.find((m) => m.is_active);
          if (activeOne) {
            setSelectedMomentId(activeOne.id);
          } else if (data.length > 0) {
            setSelectedMomentId(data[0].id);
          }
        }
      } catch (err) {
        console.error("Erro ao carregar momentos:", err);
      } finally {
        setIsLoadingMoments(false);
      }
    }
    init();
  }, [activeEvent?.id]);

  // Manter auto-focus no campo de leitor de código de barras físico
  useEffect(() => {
    if (!isCameraActive && barcodeInputRef.current) {
      barcodeInputRef.current.focus();
    }
  }, [isCameraActive, lastScan]);

  // Inicializar câmera quando ativada
  useEffect(() => {
    let isMounted = true;

    async function startScanner() {
      if (!isCameraActive) return;
      try {
        setCameraError(null);
        if (scannerRef.current) {
          try {
            if (scannerRef.current.isScanning) {
              await scannerRef.current.stop();
            }
            await scannerRef.current.clear();
          } catch (e) {
            // limpar instância anterior
          }
        }

        const scanner = new Html5Qrcode(cameraViewportId);
        scannerRef.current = scanner;

        const config = {
          fps: 10,
          qrbox: { width: 280, height: 180 }, // Caixa retangular para facilitar códigos de barras lineares
          aspectRatio: 1.0,
        };

        await scanner.start(
          { facingMode: "environment" },
          config,
          (decodedText) => {
            if (!isMounted || isSubmitting) return;
            handleProcessBarcode(decodedText);
          },
          () => {}
        );
      } catch (err: any) {
        console.warn("Falha ao abrir câmera:", err);
        if (isMounted) {
          setCameraError(
            "Não foi possível acessar a câmera do aparelho. Conceda permissão ou use o leitor físico USB/OTG."
          );
          setIsCameraActive(false);
        }
      }
    }

    if (isCameraActive) {
      startScanner();
    } else {
      if (scannerRef.current) {
        try {
          if (scannerRef.current.isScanning) {
            scannerRef.current.stop().catch(() => {});
          }
        } catch (e) {}
      }
    }

    return () => {
      isMounted = false;
      if (scannerRef.current) {
        try {
          if (scannerRef.current.isScanning) {
            scannerRef.current.stop().catch(() => {});
          }
        } catch (e) {}
      }
    };
  }, [isCameraActive, selectedMomentId]);

  const activeMoment = moments.find((m) => m.id === selectedMomentId);

  // Processamento do código de barras
  async function handleProcessBarcode(code: string) {
    const cleanCode = code.trim();
    if (!cleanCode || !selectedMomentId || isSubmitting) return;

    setIsSubmitting(true);
    setBarcodeInput("");

    try {
      const resp = await snackService.deliverSnack(selectedMomentId, {
        scan_query: cleanCode,
      });

      setLastScan(resp);
      setRecentHistory((prev) => [resp, ...prev.slice(0, 9)]);

      // Atualizar contadores locais do momento
      setMoments((prev) =>
        prev.map((m) =>
          m.id === selectedMomentId
            ? {
                ...m,
                total_delivered: resp.total_delivered,
                percentage_consumed: resp.percentage_consumed,
              }
            : m
        )
      );

      // Feedback sonoro
      if (soundEnabled) {
        if (resp.status === "SUCCESS") {
          playAudioTone("success");
        } else if (resp.status === "ALREADY_DELIVERED") {
          playAudioTone("error");
        } else {
          playAudioTone("warning");
        }
      }
    } catch (err: any) {
      const errorMsg = err.response?.data?.detail || "Erro de comunicação ao validar crachá.";
      const errorResp: SnackDeliverScanResponse = {
        status: "NOT_FOUND",
        message: errorMsg,
        moment_id: selectedMomentId,
        moment_name: activeMoment?.name || "Lanche",
        total_delivered: activeMoment?.total_delivered || 0,
        total_budgeted: activeMoment?.total_budgeted || 0,
        percentage_consumed: activeMoment?.percentage_consumed || 0,
      };
      setLastScan(errorResp);
      if (soundEnabled) playAudioTone("error");
    } finally {
      setIsSubmitting(false);
      if (!isCameraActive && barcodeInputRef.current) {
        barcodeInputRef.current.focus();
      }
    }
  }

  function handleFormSubmit(e: React.FormEvent) {
    e.preventDefault();
    handleProcessBarcode(barcodeInput);
  }

  return (
    <RequireActiveEvent minRole="OPERATOR" featureName="a Distribuição de Lanches">
      <div className="max-w-xl mx-auto space-y-4 pb-12">
        {/* Barra Superior de Navegação e Controles */}
        <div className="flex items-center justify-between gap-2 pt-1">
          <Link
            href="/snacks"
            className="text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white flex items-center gap-1 bg-white dark:bg-slate-900 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-800"
          >
            <ArrowLeft size={14} />
            Voltar
          </Link>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setSoundEnabled(!soundEnabled)}
              className="p-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white text-xs flex items-center gap-1.5"
              title={soundEnabled ? "Desativar Bip Sonoro" : "Ativar Bip Sonoro"}
            >
              {soundEnabled ? (
                <>
                  <Volume2 size={16} className="text-teal-600" />
                  <span className="hidden sm:inline">Som Ativo</span>
                </>
              ) : (
                <>
                  <VolumeX size={16} className="text-slate-400" />
                  <span className="hidden sm:inline">Mudo</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Seletor do Momento de Lanche */}
        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1.5">
            Momento de Lanche Ativo:
          </label>
          <select
            value={selectedMomentId || ""}
            onChange={(e) => setSelectedMomentId(Number(e.target.value))}
            className="w-full px-3 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm font-bold text-slate-900 dark:text-white focus:outline-none"
          >
            {moments.map((m) => (
              <option key={m.id} value={m.id}>
                {m.name} {m.is_active ? "🟢 (Aberto)" : "⚪ (Fechado)"}
              </option>
            ))}
          </select>

          {activeMoment && (
            <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
              <div>
                <span className="text-slate-400 block text-[11px]">Progresso da Fila:</span>
                <span className="font-bold text-slate-900 dark:text-white text-sm">
                  {activeMoment.total_delivered} / {activeMoment.total_budgeted || 0} entregues
                </span>
              </div>
              <div className="text-right">
                <span className="text-slate-400 block text-[11px]">Cota Consumida:</span>
                <span className="font-mono font-black text-teal-600 dark:text-teal-400 text-sm">
                  {activeMoment.percentage_consumed.toFixed(0)}%
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Alerta de Momento Fechado */}
        {activeMoment && !activeMoment.is_active && (
          <div className="p-3.5 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-800 text-amber-800 dark:text-amber-200 text-xs flex items-center gap-2.5 font-medium">
            <AlertTriangle size={17} className="flex-shrink-0 text-amber-600" />
            <span>
              Este momento está marcado como <strong>fechado</strong> no painel. Abra a fila no menu
              anterior para registrar novas entregas.
            </span>
          </div>
        )}

        {/* Painel Central de Feedback Visual Instantâneo */}
        {lastScan && (
          <div
            className={`p-5 rounded-2xl border-2 transition-all duration-300 shadow-md ${
              lastScan.status === "SUCCESS"
                ? "bg-emerald-50 dark:bg-emerald-950/40 border-emerald-500 text-emerald-950 dark:text-emerald-100"
                : lastScan.status === "ALREADY_DELIVERED"
                ? "bg-red-50 dark:bg-red-950/40 border-red-500 text-red-950 dark:text-red-100 animate-shake"
                : "bg-amber-50 dark:bg-amber-950/40 border-amber-400 text-amber-950 dark:text-amber-100"
            }`}
          >
            <div className="flex items-start gap-3.5">
              <div className="mt-0.5 flex-shrink-0">
                {lastScan.status === "SUCCESS" && (
                  <CheckCircle2 size={32} className="text-emerald-600 dark:text-emerald-400" />
                )}
                {lastScan.status === "ALREADY_DELIVERED" && (
                  <XCircle size={32} className="text-red-600 dark:text-red-400" />
                )}
                {(lastScan.status === "ROLE_NOT_ALLOWED" ||
                  lastScan.status === "MOMENT_INACTIVE" ||
                  lastScan.status === "NOT_FOUND") && (
                  <AlertTriangle size={32} className="text-amber-600 dark:text-amber-400" />
                )}
              </div>

              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-black uppercase tracking-wider">
                    {lastScan.status === "SUCCESS"
                      ? "✅ Lanche Entregue!"
                      : lastScan.status === "ALREADY_DELIVERED"
                      ? "ℹ️ Lanche Já Retirado Hoje"
                      : "⚠️ Informação de Acesso"}
                  </span>
                  {lastScan.delivered_at && (
                    <span className="text-[11px] font-mono opacity-70">
                      {new Date(lastScan.delivered_at).toLocaleTimeString("pt-BR")}
                    </span>
                  )}
                </div>

                <h2 className="text-lg font-black mt-1 leading-snug">
                  {lastScan.participant_name || "Participante não identificado"}
                </h2>

                <p className="text-xs mt-1 opacity-90 leading-relaxed">
                  {lastScan.message}
                </p>

                {lastScan.participant_role && (
                  <div className="flex flex-wrap items-center gap-1.5 mt-2.5">
                    <span className="px-2 py-0.5 rounded bg-black/10 dark:bg-white/10 text-[11px] font-bold">
                      {lastScan.participant_role}
                    </span>

                    {lastScan.booth_number && (
                      <span className="px-2 py-0.5 rounded bg-black/10 dark:bg-white/10 text-[11px] font-mono font-bold">
                        Estande {lastScan.booth_number}
                      </span>
                    )}

                    {lastScan.participant_barcode && (
                      <span className="px-2 py-0.5 rounded bg-black/10 dark:bg-white/10 text-[11px] font-mono">
                        {lastScan.participant_barcode}
                      </span>
                    )}
                  </div>
                )}

                {lastScan.project_title && (
                  <p className="text-[11px] mt-1.5 opacity-80 line-clamp-1 italic">
                    Trabalho: {lastScan.project_title}
                  </p>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Câmera do Smartphone (Visualizador html5-qrcode) */}
        {isCameraActive ? (
          <div className="bg-slate-900 p-4 rounded-2xl border border-slate-700 shadow-md text-white text-center">
            <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-800">
              <span className="text-xs font-bold flex items-center gap-2 text-teal-400">
                <Camera size={16} />
                Câmera Ativa — Aponte para o Crachá
              </span>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsCameraActive(false)}
                className="text-xs border-slate-700 text-slate-300 hover:bg-slate-800"
              >
                Desativar Câmera
              </Button>
            </div>

            <div
              id={cameraViewportId}
              className="w-full max-w-sm mx-auto overflow-hidden rounded-xl border-2 border-teal-500/60 bg-black min-h-[220px]"
            />

            <p className="text-[11px] text-slate-400 mt-2.5">
              Posicione o código de barras linear ou QR Code dentro da área demarcada.
            </p>
          </div>
        ) : (
          /* Modo Leitor Físico USB/OTG ou Digitação */
          <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs text-center space-y-4">
            <div className="w-14 h-14 rounded-2xl bg-teal-50 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-900 flex items-center justify-center text-teal-600 dark:text-teal-400 mx-auto">
              <ScanBarcode size={28} />
            </div>

            <div>
              <h3 className="font-bold text-slate-900 dark:text-white text-base">
                Pronto para Bipar Crachá
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-xs mx-auto">
                Conecte a pistola USB no celular via adaptador OTG ou use a câmera abaixo.
              </p>
            </div>

            <form onSubmit={handleFormSubmit} className="space-y-2.5">
              <div className="relative">
                <input
                  ref={barcodeInputRef}
                  type="text"
                  value={barcodeInput}
                  onChange={(e) => setBarcodeInput(e.target.value)}
                  placeholder="Aguardando bip do leitor ou digite o código..."
                  disabled={isSubmitting}
                  className="w-full pl-4 pr-12 py-3 bg-slate-50 dark:bg-slate-800 border-2 border-slate-300 dark:border-slate-700 focus:border-teal-500 dark:focus:border-teal-400 rounded-xl text-center font-mono font-bold text-slate-900 dark:text-white focus:outline-none transition-colors"
                />
                <button
                  type="submit"
                  disabled={!barcodeInput.trim() || isSubmitting}
                  className="absolute right-2 top-2 bottom-2 px-3 bg-teal-600 hover:bg-teal-700 disabled:opacity-30 text-white rounded-lg text-xs font-bold transition-colors"
                >
                  OK
                </button>
              </div>
            </form>

            <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsCameraActive(true)}
                className="text-xs text-teal-600 dark:text-teal-400 border-teal-200 dark:border-teal-900"
              >
                <Camera size={15} className="mr-1.5" />
                Usar Câmera do Celular
              </Button>
            </div>
          </div>
        )}

        {/* Histórico Recente da Fila */}
        {recentHistory.length > 0 && (
          <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-1.5">
              <Clock size={14} />
              Últimas Leituras no Dispositivo:
            </h4>
            <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
              {recentHistory.map((item, idx) => (
                <div key={idx} className="py-2 flex items-center justify-between gap-2">
                  <div className="min-w-0 flex items-center gap-2">
                    {item.status === "SUCCESS" ? (
                      <span className="w-2 h-2 rounded-full bg-emerald-500 flex-shrink-0" />
                    ) : (
                      <span className="w-2 h-2 rounded-full bg-red-500 flex-shrink-0" />
                    )}
                    <span className="font-semibold text-slate-900 dark:text-white truncate">
                      {item.participant_name || "Desconhecido"}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">
                      {item.participant_barcode || ""}
                    </span>
                  </div>

                  <span
                    className={`font-mono text-[11px] font-bold whitespace-nowrap ${
                      item.status === "SUCCESS"
                        ? "text-emerald-600 dark:text-emerald-400"
                        : item.status === "ALREADY_DELIVERED"
                        ? "text-amber-600 dark:text-amber-400"
                        : "text-red-600 dark:text-red-400"
                    }`}
                  >
                    {item.status === "SUCCESS"
                      ? "Entregue"
                      : item.status === "ALREADY_DELIVERED"
                      ? "Já Retirado"
                      : "Não Liberado"}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </RequireActiveEvent>
  );
}

export default function SnackDistributionPage() {
  return (
    <Suspense fallback={<div className="p-8 text-center text-slate-500">Carregando scanner de lanches...</div>}>
      <SnackDistributionContent />
    </Suspense>
  );
}
