"use client";

import React, { useEffect, useState } from "react";
import Link from "next/link";
import {
  UtensilsCrossed,
  Plus,
  QrCode,
  CheckCircle2,
  AlertCircle,
  Clock,
  Users,
  Calendar,
  Sparkles,
  ToggleLeft,
  ToggleRight,
  FileText,
  Trash2,
  Edit2,
  RefreshCw,
  Search,
} from "lucide-react";
import { useActiveEvent } from "../../../context/EventContext";
import { RequireActiveEvent } from "../../../components/common/RequireActiveEvent";
import { snackService } from "../../../services/snack.service";
import { SnackMoment, SnackMomentReport } from "../../../types";
import { Button } from "../../../components/ui/Button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "../../../components/ui/Card";

export default function SnacksPage() {
  const { activeEvent } = useActiveEvent();

  const [moments, setMoments] = useState<SnackMoment[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Modal de Criação / Edição
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingMoment, setEditingMoment] = useState<SnackMoment | null>(null);
  const [formName, setFormName] = useState("");
  const [formDate, setFormDate] = useState("");
  const [formStartTime, setFormStartTime] = useState("");
  const [formEndTime, setFormEndTime] = useState("");
  const [formIsActive, setFormIsActive] = useState(false);
  const [formTargetRoles, setFormTargetRoles] = useState("ALL");
  const [formTotalBudgeted, setFormTotalBudgeted] = useState("150");
  const [formNotes, setFormNotes] = useState("");
  const [isSaving, setIsSaving] = useState(false);
  const [isLoadingCount, setIsLoadingCount] = useState(false);
  const [eligibleCountText, setEligibleCountText] = useState<string | null>(null);

  // Modal de Relatório
  const [reportModalOpen, setReportModalOpen] = useState(false);
  const [selectedReport, setSelectedReport] = useState<SnackMomentReport | null>(null);
  const [isLoadingReport, setIsLoadingReport] = useState(false);
  const [reportSearch, setReportSearch] = useState("");

  const isOperator = activeEvent?.user_role === "OPERATOR";

  async function loadMoments() {
    if (!activeEvent) return;
    setIsLoading(true);
    setError(null);
    try {
      const data = await snackService.getMoments(activeEvent.id);
      setMoments(data);
    } catch (err: any) {
      setError(
        err.response?.data?.detail || "Erro ao carregar os momentos de lanche do evento."
      );
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    loadMoments();
  }, [activeEvent?.id]);

  async function updateBudgetedForRoles(targetRoles: string) {
    if (!activeEvent?.id) return;
    setIsLoadingCount(true);
    try {
      const count = await snackService.getEligibleCount(activeEvent.id, targetRoles);
      if (count > 0) {
        setFormTotalBudgeted(String(count));
        setEligibleCountText(`${count} participante(s) inscrito(s) com este perfil.`);
      } else {
        setFormTotalBudgeted("150");
        setEligibleCountText("Nenhum participante com este perfil ainda. Preenchido com valor padrão: 150.");
      }
    } catch {
      setFormTotalBudgeted("150");
      setEligibleCountText("Valor padrão sugerido: 150.");
    } finally {
      setIsLoadingCount(false);
    }
  }

  function openCreateModal() {
    setEditingMoment(null);
    setFormName("");
    setFormDate(new Date().toISOString().split("T")[0]);
    setFormStartTime("15:30");
    setFormEndTime("17:00");
    setFormIsActive(true);
    setFormTargetRoles("ALL");
    setFormTotalBudgeted("150");
    setFormNotes("");
    setEligibleCountText(null);
    setIsModalOpen(true);
    updateBudgetedForRoles("ALL");
  }

  function openEditModal(moment: SnackMoment) {
    setEditingMoment(moment);
    setFormName(moment.name);
    setFormDate(moment.date);
    setFormStartTime(moment.start_time || "");
    setFormEndTime(moment.end_time || "");
    setFormIsActive(moment.is_active);
    const roles = moment.target_roles || "ALL";
    setFormTargetRoles(roles);
    setFormTotalBudgeted(String(moment.total_budgeted || 0));
    setFormNotes(moment.notes || "");
    setEligibleCountText(null);
    setIsModalOpen(true);
  }

  async function handleTargetRolesChange(newRoles: string) {
    setFormTargetRoles(newRoles);
    if (!editingMoment) {
      await updateBudgetedForRoles(newRoles);
    }
  }

  async function handleSaveMoment(e: React.FormEvent) {
    e.preventDefault();
    if (!activeEvent || !formName.trim() || !formDate) return;

    setIsSaving(true);
    try {
      if (editingMoment) {
        await snackService.updateMoment(editingMoment.id, {
          name: formName.trim(),
          date: formDate,
          start_time: formStartTime || null,
          end_time: formEndTime || null,
          is_active: formIsActive,
          target_roles: formTargetRoles,
          total_budgeted: Number(formTotalBudgeted) || 0,
          notes: formNotes.trim() || null,
        });
      } else {
        await snackService.createMoment(activeEvent.id, {
          name: formName.trim(),
          date: formDate,
          start_time: formStartTime || null,
          end_time: formEndTime || null,
          is_active: formIsActive,
          target_roles: formTargetRoles,
          total_budgeted: Number(formTotalBudgeted) || 0,
          notes: formNotes.trim() || null,
        });
      }
      setIsModalOpen(false);
      await loadMoments();
    } catch (err: any) {
      alert(err.response?.data?.detail || "Erro ao salvar o momento de lanche.");
    } finally {
      setIsSaving(false);
    }
  }

  async function handleToggleActive(moment: SnackMoment) {
    try {
      await snackService.toggleMomentActive(moment.id, !moment.is_active);
      await loadMoments();
    } catch (err: any) {
      alert(err.response?.data?.detail || "Erro ao alterar status do momento.");
    }
  }

  async function handleDeleteMoment(momentId: number) {
    if (!confirm("Tem certeza que deseja excluir este momento de lanche?")) return;
    try {
      await snackService.deleteMoment(momentId);
      await loadMoments();
    } catch (err: any) {
      alert(err.response?.data?.detail || "Erro ao excluir o momento de lanche.");
    }
  }

  async function handleOpenReport(momentId: number) {
    setIsLoadingReport(true);
    setReportModalOpen(true);
    setReportSearch("");
    try {
      const data = await snackService.getMomentReport(momentId);
      setSelectedReport(data);
    } catch (err: any) {
      alert(err.response?.data?.detail || "Erro ao carregar relatório de entregas.");
      setReportModalOpen(false);
    } finally {
      setIsLoadingReport(false);
    }
  }

  // Cálculos de resumo
  const activeMomentsCount = moments.filter((m) => m.is_active).length;
  const totalDeliveredAll = moments.reduce((acc, m) => acc + m.total_delivered, 0);
  const totalBudgetedAll = moments.reduce((acc, m) => acc + (m.total_budgeted || 0), 0);

  const filteredDeliveries = selectedReport?.deliveries.filter((d) => {
    if (!reportSearch.trim()) return true;
    const q = reportSearch.toLowerCase();
    return (
      d.participant_name.toLowerCase().includes(q) ||
      (d.participant_barcode && d.participant_barcode.toLowerCase().includes(q)) ||
      (d.project_title && d.project_title.toLowerCase().includes(q)) ||
      (d.booth_number && d.booth_number.toLowerCase().includes(q))
    );
  }) || [];

  return (
    <RequireActiveEvent minRole="OPERATOR" featureName="o Controle de Lanches e Coffee Break">
      <div className="space-y-6 max-w-7xl mx-auto">
        {/* Page Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white flex items-center gap-2.5">
              <UtensilsCrossed className="text-amber-500" size={26} />
              Lanches & Coffee Break
            </h1>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
              Organização e distribuição de lanches com confirmação rápida por leitor de código de barras ou celular.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <Link href="/snacks/distribution">
              <Button
                variant="primary"
                size="md"
                className="bg-teal-600 hover:bg-teal-700 text-white shadow-xs font-semibold"
              >
                <QrCode size={17} className="mr-1.5" />
                Abrir Distribuição In Loco (Scanner)
              </Button>
            </Link>

            {!isOperator && (
              <Button variant="outline" size="md" onClick={openCreateModal}>
                <Plus size={16} className="mr-1" />
                Novo Momento
              </Button>
            )}

            <Button
              variant="outline"
              size="md"
              onClick={loadMoments}
              disabled={isLoading}
              title="Recarregar"
            >
              <RefreshCw size={15} className={isLoading ? "animate-spin" : ""} />
            </Button>
          </div>
        </div>

        {/* Alerta de Erro */}
        {error && (
          <div className="p-4 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 text-red-700 dark:text-red-300 text-sm flex items-center gap-3">
            <AlertCircle size={18} className="flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* KPIs Rápidos */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <Card className="border-slate-200 dark:border-slate-800 shadow-2xs">
            <CardContent className="p-4 flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900 flex items-center justify-center text-amber-600 dark:text-amber-400 flex-shrink-0">
                <Clock size={24} />
              </div>
              <div>
                <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
                  Momentos Cadastrados
                </p>
                <h3 className="text-2xl font-black text-slate-900 dark:text-white mt-0.5">
                  {moments.length}
                </h3>
                <p className="text-[11px] text-slate-400">
                  {activeMomentsCount > 0 ? (
                    <span className="text-emerald-600 dark:text-emerald-400 font-bold flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                      {activeMomentsCount} aberto(s) agora
                    </span>
                  ) : (
                    "Nenhum momento aberto agora"
                  )}
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="border-slate-200 dark:border-slate-800 shadow-2xs">
            <CardContent className="p-4 flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-teal-50 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-900 flex items-center justify-center text-teal-600 dark:text-teal-400 flex-shrink-0">
                <CheckCircle2 size={24} />
              </div>
              <div>
                <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
                  Total de Lanches Entregues
                </p>
                <h3 className="text-2xl font-black text-slate-900 dark:text-white mt-0.5">
                  {totalDeliveredAll}
                </h3>
                <p className="text-[11px] text-slate-400">
                  Meta estimada: {totalBudgetedAll} unidades
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="border-slate-200 dark:border-slate-800 shadow-2xs">
            <CardContent className="p-4 flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900 flex items-center justify-center text-blue-600 dark:text-blue-400 flex-shrink-0">
                <Users size={24} />
              </div>
              <div>
                <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
                  Controle Individual
                </p>
                <h3 className="text-base font-bold text-slate-900 dark:text-white mt-0.5">
                  1 Lanche por Pessoa
                </h3>
                <p className="text-[11px] text-slate-400">
                  Garante que todos os participantes recebam sua refeição
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Lista de Momentos de Lanche */}
        <Card className="border-slate-200 dark:border-slate-800 shadow-sm">
          <CardHeader className="pb-3 border-b border-slate-200 dark:border-slate-800">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <CardTitle className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <UtensilsCrossed size={18} className="text-amber-500" />
                  Programação dos Momentos de Alimentação
                </CardTitle>
                <CardDescription className="text-xs mt-0.5">
                  Configure dias, horários e permissões de lanche da edição do evento.
                </CardDescription>
              </div>
            </div>
          </CardHeader>

          <CardContent className="p-0">
            {isLoading ? (
              <div className="py-16 text-center text-sm text-slate-500 animate-pulse">
                Carregando momentos de lanche...
              </div>
            ) : moments.length === 0 ? (
              <div className="py-16 text-center text-slate-500">
                <UtensilsCrossed size={40} className="mx-auto mb-3 text-slate-400 opacity-60" />
                <p className="font-semibold text-slate-700 dark:text-slate-300">
                  Nenhum momento de lanche cadastrado.
                </p>
                <p className="text-xs text-slate-400 mt-1 max-w-md mx-auto">
                  Cadastre momentos como &quot;Lanche da Tarde — Dia 1&quot; ou &quot;Coffee Break de Abertura&quot; para iniciar a distribuição.
                </p>
                {!isOperator && (
                  <Button
                    variant="primary"
                    size="sm"
                    className="mt-4"
                    onClick={openCreateModal}
                  >
                    <Plus size={15} className="mr-1" />
                    Cadastrar Primeiro Momento
                  </Button>
                )}
              </div>
            ) : (
              <div className="divide-y divide-slate-200 dark:divide-slate-800">
                {moments.map((moment) => {
                  const pct = moment.percentage_consumed || 0;
                  return (
                    <div
                      key={moment.id}
                      className="p-4 hover:bg-slate-50/50 dark:hover:bg-slate-800/20 transition-colors flex flex-col md:flex-row md:items-center justify-between gap-4"
                    >
                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-center gap-2 mb-1">
                          <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                            {moment.name}
                          </h3>
                          {moment.is_active ? (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800">
                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                              Aberto p/ Distribuição
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded-full text-[11px] font-semibold bg-slate-100 dark:bg-slate-800 text-slate-500 border border-slate-200 dark:border-slate-700">
                              Fechado
                            </span>
                          )}

                          <span className="px-2 py-0.5 rounded text-[10px] font-medium bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-900">
                            Público:{" "}
                            {moment.target_roles === "ALL"
                              ? "Todos os Participantes"
                              : moment.target_roles}
                          </span>
                        </div>

                        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-500 dark:text-slate-400">
                          <span className="flex items-center gap-1">
                            <Calendar size={13} className="text-slate-400" />
                            {new Date(moment.date + "T12:00:00").toLocaleDateString("pt-BR")}
                          </span>

                          {(moment.start_time || moment.end_time) && (
                            <span className="flex items-center gap-1">
                              <Clock size={13} className="text-slate-400" />
                              {moment.start_time || "--:--"} às {moment.end_time || "--:--"}
                            </span>
                          )}

                          {moment.notes && (
                            <span className="text-[11px] text-slate-400 italic">
                              &ldquo;{moment.notes}&rdquo;
                            </span>
                          )}
                        </div>

                        {/* Barra de Progresso */}
                        <div className="mt-3 max-w-md">
                          <div className="flex items-center justify-between text-[11px] text-slate-600 dark:text-slate-400 mb-1 font-medium">
                            <span>
                              Entregues: <strong>{moment.total_delivered}</strong> de{" "}
                              <strong>{moment.total_budgeted || 0}</strong>
                            </span>
                            <span className="font-mono font-bold text-slate-900 dark:text-white">
                              {pct.toFixed(0)}%
                            </span>
                          </div>
                          <div className="w-full bg-slate-200 dark:bg-slate-800 rounded-full h-2 overflow-hidden">
                            <div
                              className={`h-2 rounded-full transition-all duration-500 ${
                                pct >= 100
                                  ? "bg-purple-600"
                                  : pct >= 80
                                  ? "bg-amber-500"
                                  : "bg-teal-600"
                              }`}
                              style={{ width: `${Math.min(pct, 100)}%` }}
                            />
                          </div>
                        </div>
                      </div>

                      {/* Ações */}
                      <div className="flex flex-wrap items-center gap-2">
                        <Link href={`/snacks/distribution?moment_id=${moment.id}`}>
                          <Button
                            variant="primary"
                            size="sm"
                            className="bg-teal-600 hover:bg-teal-700 text-white font-semibold"
                          >
                            <QrCode size={14} className="mr-1" />
                            Distribuir na Fila
                          </Button>
                        </Link>

                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleOpenReport(moment.id)}
                          title="Relatório de Entregas"
                        >
                          <FileText size={14} className="mr-1 text-slate-500" />
                          Relatório
                        </Button>

                        {!isOperator && (
                          <>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleToggleActive(moment)}
                              title={moment.is_active ? "Fechar Fila" : "Abrir Fila"}
                              className={
                                moment.is_active
                                  ? "text-emerald-700 border-emerald-300 dark:text-emerald-300"
                                  : "text-slate-500"
                              }
                            >
                              {moment.is_active ? (
                                <>
                                  <ToggleRight size={16} className="mr-1 text-emerald-600" />
                                  Aberto
                                </>
                              ) : (
                                <>
                                  <ToggleLeft size={16} className="mr-1 text-slate-400" />
                                  Fechado
                                </>
                              )}
                            </Button>

                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => openEditModal(moment)}
                              title="Editar Momento"
                            >
                              <Edit2 size={14} className="text-slate-500" />
                            </Button>

                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDeleteMoment(moment.id)}
                              title="Excluir Momento"
                              className="text-red-600 hover:bg-red-50 dark:hover:bg-red-950/40"
                            >
                              <Trash2 size={14} />
                            </Button>
                          </>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Modal de Criação / Edição */}
        {isModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-lg shadow-xl overflow-hidden animate-in fade-in zoom-in-95">
              <div className="p-5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <UtensilsCrossed size={20} className="text-amber-500" />
                  <h3 className="font-bold text-slate-900 dark:text-white">
                    {editingMoment ? "Editar Momento de Lanche" : "Novo Momento de Lanche"}
                  </h3>
                </div>
                <button
                  onClick={() => setIsModalOpen(false)}
                  className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 text-lg"
                >
                  ✕
                </button>
              </div>

              <form onSubmit={handleSaveMoment} className="p-5 space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Nome do Momento *
                  </label>
                  <input
                    type="text"
                    required
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    placeholder="Ex: Lanche da Tarde — Dia 1"
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-sm text-slate-900 dark:text-white focus:outline-none"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      Data *
                    </label>
                    <input
                      type="date"
                      required
                      value={formDate}
                      onChange={(e) => setFormDate(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-sm text-slate-900 dark:text-white focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      Início
                    </label>
                    <input
                      type="time"
                      value={formStartTime}
                      onChange={(e) => setFormStartTime(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-sm text-slate-900 dark:text-white focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      Término
                    </label>
                    <input
                      type="time"
                      value={formEndTime}
                      onChange={(e) => setFormEndTime(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-sm text-slate-900 dark:text-white focus:outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      Público-Alvo Autorizado
                    </label>
                    <select
                      value={formTargetRoles}
                      onChange={(e) => handleTargetRolesChange(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-sm text-slate-900 dark:text-white focus:outline-none"
                    >
                      <option value="ALL">Todos os Participantes Credenciados</option>
                      <option value="STUDENT,ADVISOR,COADVISOR">Apenas Alunos e Orientadores</option>
                      <option value="EVALUATOR">Apenas Avaliadores</option>
                      <option value="ORGANIZER,VOLUNTEER">Apenas Equipe e Voluntários</option>
                    </select>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                        Quantidade Estimada (Meta)
                      </label>
                      {isLoadingCount && (
                        <span className="text-[11px] text-teal-600 dark:text-teal-400 flex items-center gap-1 font-medium">
                          <RefreshCw size={11} className="animate-spin" />
                          Consultando inscritos...
                        </span>
                      )}
                    </div>
                    <input
                      type="number"
                      min="0"
                      value={formTotalBudgeted}
                      onChange={(e) => setFormTotalBudgeted(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-sm text-slate-900 dark:text-white focus:outline-none"
                    />
                    {eligibleCountText && (
                      <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 flex items-center gap-1">
                        <span>💡</span>
                        <span>{eligibleCountText}</span>
                      </p>
                    )}
                    {editingMoment && (
                      <button
                        type="button"
                        onClick={() => updateBudgetedForRoles(formTargetRoles)}
                        className="text-[11px] text-teal-600 hover:text-teal-700 dark:text-teal-400 font-semibold mt-1 inline-block underline"
                      >
                        Sugerir meta a partir dos inscritos atuais
                      </button>
                    )}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Instruções / Observações
                  </label>
                  <textarea
                    value={formNotes}
                    onChange={(e) => setFormNotes(e.target.value)}
                    rows={2}
                    placeholder="Ex: Servido no refeitório bloco A. Necessário apresentar crachá."
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs text-slate-900 dark:text-white focus:outline-none resize-none"
                  />
                </div>

                <div className="flex items-center gap-2 pt-2">
                  <input
                    type="checkbox"
                    id="isActiveCheck"
                    checked={formIsActive}
                    onChange={(e) => setFormIsActive(e.target.checked)}
                    className="w-4 h-4 rounded text-teal-600 focus:ring-teal-500"
                  />
                  <label htmlFor="isActiveCheck" className="text-xs font-semibold text-slate-700 dark:text-slate-300 cursor-pointer">
                    Abrir fila imediatamente para distribuição
                  </label>
                </div>

                <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex items-center justify-end gap-2">
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => setIsModalOpen(false)}
                  >
                    Cancelar
                  </Button>
                  <Button
                    type="submit"
                    variant="primary"
                    size="sm"
                    disabled={isSaving}
                  >
                    {isSaving ? "Salvando..." : editingMoment ? "Atualizar Momento" : "Criar Momento"}
                  </Button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Modal de Relatório de Entregas */}
        {reportModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-3xl shadow-xl overflow-hidden animate-in fade-in zoom-in-95 flex flex-col max-h-[90vh]">
              <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-slate-900 dark:text-white flex items-center gap-2">
                    <FileText size={18} className="text-teal-600" />
                    Relatório de Entregas — {selectedReport?.moment.name}
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                    Total entregue: <strong>{selectedReport?.delivered_count || 0}</strong> lanches
                  </p>
                </div>
                <button
                  onClick={() => setReportModalOpen(false)}
                  className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 text-lg"
                >
                  ✕
                </button>
              </div>

              {/* Filtro de Busca */}
              <div className="p-3 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40">
                <div className="relative">
                  <Search size={15} className="absolute left-3 top-2.5 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Filtrar por nome, crachá, estande ou projeto..."
                    value={reportSearch}
                    onChange={(e) => setReportSearch(e.target.value)}
                    className="w-full pl-9 pr-3 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs text-slate-900 dark:text-white focus:outline-none"
                  />
                </div>
              </div>

              {/* Tabela de Entregas */}
              <div className="flex-1 overflow-y-auto p-0">
                {isLoadingReport ? (
                  <div className="p-12 text-center text-xs text-slate-500 animate-pulse">
                    Carregando histórico de entregas...
                  </div>
                ) : filteredDeliveries.length === 0 ? (
                  <div className="p-12 text-center text-xs text-slate-500">
                    Nenhuma entrega registrada para este momento até o momento.
                  </div>
                ) : (
                  <table className="w-full text-left text-xs">
                    <thead className="text-[11px] font-bold text-slate-500 uppercase border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 sticky top-0">
                      <tr>
                        <th className="py-2.5 px-4">Participante</th>
                        <th className="py-2.5 px-4">Crachá / Papel</th>
                        <th className="py-2.5 px-4">Projeto / Estande</th>
                        <th className="py-2.5 px-4">Horário</th>
                        <th className="py-2.5 px-4">Operador</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                      {filteredDeliveries.map((item) => (
                        <tr
                          key={item.id}
                          className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors"
                        >
                          <td className="py-2.5 px-4 font-semibold text-slate-900 dark:text-white">
                            {item.participant_name}
                            {item.affiliation && (
                              <span className="block text-[10px] text-slate-400 font-normal">
                                {item.affiliation}
                              </span>
                            )}
                          </td>
                          <td className="py-2.5 px-4 whitespace-nowrap">
                            <span className="font-mono text-teal-600 dark:text-teal-400 font-bold block">
                              {item.participant_barcode || "—"}
                            </span>
                            <span className="text-[10px] text-slate-400">
                              {item.participant_role}
                            </span>
                          </td>
                          <td className="py-2.5 px-4">
                            {item.project_title ? (
                              <div>
                                <span className="line-clamp-1 font-medium text-slate-800 dark:text-slate-200">
                                  {item.project_title}
                                </span>
                                {item.booth_number && (
                                  <span className="text-[10px] font-mono text-teal-600 dark:text-teal-400">
                                    Estande {item.booth_number}
                                  </span>
                                )}
                              </div>
                            ) : (
                              <span className="text-slate-400 text-[11px]">—</span>
                            )}
                          </td>
                          <td className="py-2.5 px-4 whitespace-nowrap font-mono text-slate-600 dark:text-slate-300">
                            {new Date(item.delivered_at).toLocaleTimeString("pt-BR")}
                          </td>
                          <td className="py-2.5 px-4 whitespace-nowrap text-slate-500 text-[11px]">
                            {item.delivered_by_name || "Operador"}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>

              <div className="p-3 border-t border-slate-200 dark:border-slate-800 flex justify-between items-center bg-slate-50 dark:bg-slate-900 text-xs text-slate-500">
                <span>
                  Exibindo <strong>{filteredDeliveries.length}</strong> de{" "}
                  <strong>{selectedReport?.deliveries.length || 0}</strong> registros
                </span>
                <Button variant="outline" size="sm" onClick={() => setReportModalOpen(false)}>
                  Fechar
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </RequireActiveEvent>
  );
}
