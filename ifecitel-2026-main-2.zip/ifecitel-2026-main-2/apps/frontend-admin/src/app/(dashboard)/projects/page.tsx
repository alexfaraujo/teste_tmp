"use client";

import React, { useEffect, useState, useMemo } from "react";
import Link from "next/link";
import {
  Plus,
  FileText,
  Search,
  CheckCircle2,
  XCircle,
  MapPin,
  Users,
  AlertCircle,
  Eye,
  Calendar,
  ArrowRight,
  Filter,
  X,
  FileCheck2,
  FileSpreadsheet,
  AlertTriangle,
  QrCode,
  GraduationCap,
  ExternalLink,
  RotateCcw,
  Download,
  Upload,
  Pencil,
  Zap,
  Box,
  Package,
} from "lucide-react";
import { ProjectsCsvImportModal } from "../../../components/projects/ProjectsCsvImportModal";
import { KitCardsModal } from "../../../components/logistics/KitCardsModal";
import { BoothStickersModal } from "../../../components/projects/BoothStickersModal";
import { ParticipantSelect } from "../../../components/projects/ParticipantSelect";
import {
  downloadProjectsCsvTemplate,
  SubareaSimple,
} from "../../../utils/projectsCsv";
import { useActiveEvent } from "../../../context/EventContext";
import { RequireActiveEvent } from "../../../components/common/RequireActiveEvent";
import { projectService } from "../../../services/project.service";
import { areaService } from "../../../services/area.service";
import { participantService } from "../../../services/participant.service";
import {
  EducationLevel,
  KnowledgeArea,
  ParticipantItem,
  ProjectItem,
  ProjectMemberInput,
  ProjectMemberRole,
  ProjectStatus,
} from "../../../types";
import { Button } from "../../../components/ui/Button";
import { Card, CardContent } from "../../../components/ui/Card";
import { StatusBadge } from "../../../components/ui/Badge";
import { Modal } from "../../../components/ui/Modal";
import { Input } from "../../../components/ui/Input";
import { Pagination } from "../../../components/ui/Pagination";

export default function ProjectsPage() {
  return (
    <RequireActiveEvent minRole="ORGANIZER" featureName="os Trabalhos Científicos e Homologação">
      <ProjectsContent />
    </RequireActiveEvent>
  );
}

function ProjectsContent() {
  const { activeEvent } = useActiveEvent();

  // Data States
  const [projects, setProjects] = useState<ProjectItem[]>([]);
  const [areas, setAreas] = useState<KnowledgeArea[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Pagination (BR-18: 15 itens por página)
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalItems, setTotalItems] = useState(0);

  // Filter States
  const [searchTerm, setSearchTerm] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("ALL");
  const [levelFilter, setLevelFilter] = useState<string>("ALL");
  const [subareaFilter, setSubareaFilter] = useState<string>("ALL");

  // Notifications
  const [notification, setNotification] = useState<{
    type: "success" | "error";
    text: string;
  } | null>(null);

  // Details Modal State
  const [detailsProject, setDetailsProject] = useState<ProjectItem | null>(null);
  const [isDetailsModalOpen, setIsDetailsModalOpen] = useState(false);

  // Homologation Modal State
  const [homologateProject, setHomologateProject] = useState<ProjectItem | null>(null);
  const [isHomologateModalOpen, setIsHomologateModalOpen] = useState(false);
  const [homologateDecision, setHomologateDecision] = useState<"APPROVE" | "REJECT">("APPROVE");
  const [boothInput, setBoothInput] = useState("");
  const [rejectionReasonInput, setRejectionReasonInput] = useState("");
  const [isSubmittingHomologation, setIsSubmittingHomologation] = useState(false);
  const [homologateError, setHomologateError] = useState<string | null>(null);

  // Standalone Booth Modal State
  const [boothProject, setBoothProject] = useState<ProjectItem | null>(null);
  const [isBoothModalOpen, setIsBoothModalOpen] = useState(false);
  const [standaloneBoothInput, setStandaloneBoothInput] = useState("");
  const [isSubmittingBooth, setIsSubmittingBooth] = useState(false);
  const [boothError, setBoothError] = useState<string | null>(null);

  // Participants for author selection (BR-04, BR-05)
  const [eventParticipants, setEventParticipants] = useState<ParticipantItem[]>([]);
  const [isLoadingParticipants, setIsLoadingParticipants] = useState(false);

  // Edit Project Modal State
  const [editingProject, setEditingProject] = useState<ProjectItem | null>(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editFormData, setEditFormData] = useState<{
    title: string;
    project_type: "SCIENTIFIC" | "TECHNOLOGICAL";
    education_level: EducationLevel;
    subarea_id: number;
    booth_number: string;
    abstract: string;
    needs_electricity: boolean;
    needs_table: boolean;
  }>({
    title: "",
    project_type: "SCIENTIFIC",
    education_level: "MEDIO",
    subarea_id: 0,
    booth_number: "",
    abstract: "",
    needs_electricity: false,
    needs_table: false,
  });
  const [editAdvisorId, setEditAdvisorId] = useState<number | null>(null);
  const [editAdvisorFallback, setEditAdvisorFallback] = useState<{
    name?: string | null;
    email?: string | null;
    cpf?: string | null;
  } | null>(null);
  const [showEditCoadvisor, setShowEditCoadvisor] = useState(false);
  const [editCoadvisorId, setEditCoadvisorId] = useState<number | null>(null);
  const [editCoadvisorFallback, setEditCoadvisorFallback] = useState<{
    name?: string | null;
    email?: string | null;
    cpf?: string | null;
  } | null>(null);
  const [editLeaderId, setEditLeaderId] = useState<number | null>(null);
  const [editLeaderFallback, setEditLeaderFallback] = useState<{
    name?: string | null;
    email?: string | null;
    cpf?: string | null;
  } | null>(null);
  const [editAdditionalStudents, setEditAdditionalStudents] = useState<
    {
      person_id: number | null;
      fallback?: { name?: string | null; email?: string | null; cpf?: string | null } | null;
    }[]
  >([]);
  const [isSubmittingEdit, setIsSubmittingEdit] = useState(false);
  const [editError, setEditError] = useState<string | null>(null);

  // Create Project Modal State
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [createFormData, setCreateFormData] = useState<{
    title: string;
    project_type: "SCIENTIFIC" | "TECHNOLOGICAL";
    education_level: EducationLevel;
    subarea_id: number;
    booth_number: string;
    abstract: string;
    needs_electricity: boolean;
    needs_table: boolean;
    auto_homologate: boolean;
  }>({
    title: "",
    project_type: "SCIENTIFIC",
    education_level: "MEDIO",
    subarea_id: 0,
    booth_number: "",
    abstract: "",
    needs_electricity: false,
    needs_table: false,
    auto_homologate: true,
  });
  const [createAdvisorId, setCreateAdvisorId] = useState<number | null>(null);
  const [showCreateCoadvisor, setShowCreateCoadvisor] = useState(false);
  const [createCoadvisorId, setCreateCoadvisorId] = useState<number | null>(null);
  const [createLeaderId, setCreateLeaderId] = useState<number | null>(null);
  const [createAdditionalStudentIds, setCreateAdditionalStudentIds] = useState<
    (number | null)[]
  >([]);
  const [isSubmittingCreate, setIsSubmittingCreate] = useState(false);
  const [createError, setCreateError] = useState<string | null>(null);

  // Download template state
  const [isDownloadingTemplate, setIsDownloadingTemplate] = useState(false);

  // Batch CSV Import Modal State
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);

  // Kit Cards Modal State
  const [isKitCardsModalOpen, setIsKitCardsModalOpen] = useState(false);

  // Booth Stickers Modal State
  const [isBoothStickersModalOpen, setIsBoothStickersModalOpen] = useState(false);
  const [downloadingStickerId, setDownloadingStickerId] = useState<number | null>(null);

  // Lista achatada de subáreas para o gerador e parser de CSV
  const flattenedSubareas: SubareaSimple[] = useMemo(() => {
    const list: SubareaSimple[] = [];
    for (const area of areas) {
      if (area.subareas) {
        for (const sub of area.subareas) {
          list.push({
            id: sub.id,
            name: sub.name,
            area_name: area.name,
          });
        }
      }
    }
    return list;
  }, [areas]);

  // Cota máxima de estudantes configurada no evento ativo para modelo CSV
  const maxStudents = useMemo(() => {
    if (!activeEvent?.education_levels || activeEvent.education_levels.length === 0) {
      return 5;
    }
    const maxVal = Math.max(...activeEvent.education_levels.map((l) => l.max_students || 0));
    return maxVal > 0 ? maxVal : 5;
  }, [activeEvent]);

  // Debounce search input (300ms)
  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedSearch(searchTerm);
      setPage(1); // Resetar para página 1 ao alterar a busca
    }, 300);
    return () => clearTimeout(handler);
  }, [searchTerm]);

  // Cota máxima de estudantes por nível de ensino (Regra BR-04 e config de evento)
  const getMaxStudentsForLevel = (level: EducationLevel): number => {
    const levelConfig = activeEvent?.education_levels?.find((l) => l.level_name === level);
    if (levelConfig?.max_students) {
      return levelConfig.max_students;
    }
    switch (level) {
      case "MEDIO":
      case "POS_GRADUACAO":
        return 4;
      case "FUNDAMENTAL":
      case "JUNIOR":
      case "GRADUACAO":
      default:
        return 5;
    }
  };

  // Carregar lista de áreas/subáreas e participantes da edição ativa
  useEffect(() => {
    if (!activeEvent) return;
    const currentEventId = activeEvent.id;
    async function loadAreasAndParticipants() {
      try {
        const [areasData, partData] = await Promise.all([
          areaService.getAreas(currentEventId),
          participantService.getParticipants({ event_id: currentEventId, limit: 1000 })
        ]);
        setAreas(areasData);
        setEventParticipants(partData.items || []);
      } catch (err) {
        console.error("Erro ao carregar dados iniciais:", err);
      }
    }
    loadAreasAndParticipants();
  }, [activeEvent]);

  // Carregar projetos paginados do evento ativo
  const loadProjects = async () => {
    if (!activeEvent) return;
    setIsLoading(true);
    try {
      const res = await projectService.getPaginatedProjects({
        event_id: activeEvent.id,
        page,
        limit: 15,
        search: debouncedSearch.trim() || undefined,
        status: statusFilter !== "ALL" ? statusFilter : undefined,
        education_level: levelFilter !== "ALL" ? (levelFilter as EducationLevel) : undefined,
        subarea_id: subareaFilter !== "ALL" ? Number(subareaFilter) : undefined,
      });

      setProjects(res.items);
      setTotalItems(res.total);
      setTotalPages(res.total_pages || 1);
    } catch (err: any) {
      console.error("Erro ao carregar projetos:", err);
      setNotification({
        type: "error",
        text: err.response?.data?.detail || "Erro ao consultar a lista de trabalhos da edição.",
      });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadProjects();
  }, [activeEvent, page, debouncedSearch, statusFilter, levelFilter, subareaFilter]);

  // Resetar página quando filtros mudarem
  const handleStatusFilterChange = (val: string) => {
    setStatusFilter(val);
    setPage(1);
  };

  const handleLevelFilterChange = (val: string) => {
    setLevelFilter(val);
    setPage(1);
  };

  const handleSubareaFilterChange = (val: string) => {
    setSubareaFilter(val);
    setPage(1);
  };

  const clearFilters = () => {
    setSearchTerm("");
    setDebouncedSearch("");
    setStatusFilter("ALL");
    setLevelFilter("ALL");
    setSubareaFilter("ALL");
    setPage(1);
  };

  const isFiltered =
    debouncedSearch !== "" ||
    statusFilter !== "ALL" ||
    levelFilter !== "ALL" ||
    subareaFilter !== "ALL";

  // Abrir Modal de Detalhes
  const openDetails = (project: ProjectItem) => {
    setDetailsProject(project);
    setIsDetailsModalOpen(true);
  };

  // Abrir Modal de Homologação
  const openHomologateModal = (project: ProjectItem) => {
    setHomologateProject(project);
    setHomologateDecision(project.status === "REJECTED" ? "REJECT" : "APPROVE");
    setBoothInput(project.booth_number || "");
    setRejectionReasonInput(project.rejection_reason || "");
    setHomologateError(null);
    setIsHomologateModalOpen(true);
  };

  // Submeter Homologação (Deferir ou Indeferir)
  const handleSubmitHomologation = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!homologateProject) return;

    // Se deferir, verificar se possui anuência do orientador
    if (homologateDecision === "APPROVE" && !homologateProject.advisor_consent) {
      setHomologateError(
        "Bloqueio de Homologação: O orientador formal ainda não concedeu a anuência digital. Não é permitido deferir este trabalho."
      );
      return;
    }

    if (homologateDecision === "REJECT" && !rejectionReasonInput.trim()) {
      setHomologateError("Por favor, justifique o motivo do indeferimento deste trabalho.");
      return;
    }

    setIsSubmittingHomologation(true);
    setHomologateError(null);

    try {
      await projectService.homologateProject(homologateProject.id, {
        homologated: homologateDecision === "APPROVE",
        booth_number:
          homologateDecision === "APPROVE" && boothInput.trim()
            ? boothInput.trim()
            : undefined,
        rejection_reason:
          homologateDecision === "REJECT" ? rejectionReasonInput.trim() : undefined,
      });

      setIsHomologateModalOpen(false);
      setNotification({
        type: "success",
        text:
          homologateDecision === "APPROVE"
            ? `Trabalho "${homologateProject.title}" homologado com sucesso!`
            : `Trabalho "${homologateProject.title}" indeferido.`,
      });
      await loadProjects();
    } catch (err: any) {
      setHomologateError(
        err.response?.data?.detail || "Erro ao processar homologação do trabalho."
      );
    } finally {
      setIsSubmittingHomologation(false);
    }
  };

  // Abrir Modal de Alocação de Estande
  const openBoothModal = (project: ProjectItem) => {
    setBoothProject(project);
    setStandaloneBoothInput(project.booth_number || "");
    setBoothError(null);
    setIsBoothModalOpen(true);
  };

  // Submeter Alocação de Estande
  const handleSubmitBooth = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!boothProject) return;

    if (!standaloneBoothInput.trim()) {
      setBoothError("Informe a identificação do estande (ex: A-12).");
      return;
    }

    setIsSubmittingBooth(true);
    setBoothError(null);

    try {
      await projectService.assignBooth(boothProject.id, standaloneBoothInput.trim());
      setIsBoothModalOpen(false);
      setNotification({
        type: "success",
        text: `Estande "${standaloneBoothInput.trim().toUpperCase()}" atribuído ao trabalho "${boothProject.title}".`,
      });
      await loadProjects();
    } catch (err: any) {
      setBoothError(
        err.response?.data?.detail || "Erro ao alocar número de estande."
      );
    } finally {
      setIsSubmittingBooth(false);
    }
  };

  // Abrir Modal de Edição de Projeto
  const openEditModal = async (project: ProjectItem) => {
    setEditingProject(project);
    setEditFormData({
      title: project.title,
      project_type: project.project_type,
      education_level: project.education_level,
      subarea_id: project.subarea_id,
      booth_number: project.booth_number || "",
      abstract: project.abstract || "",
      needs_electricity: Boolean(project.needs_electricity),
      needs_table: Boolean(project.needs_table),
    });

    let currentMembers = project.members || [];
    try {
      const full = await projectService.getProject(project.id);
      if (full.members) {
        currentMembers = full.members;
      }
    } catch (e) {
      console.warn("Não foi possível recarregar detalhes do projeto, usando dados em cache:", e);
    }

    const advisor = currentMembers.find((m) => m.role === "ADVISOR");
    const coadvisor = currentMembers.find((m) => m.role === "COADVISOR");
    const leader = currentMembers.find((m) => m.role === "STUDENT_LEADER");
    const additionalStudents = currentMembers.filter((m) => m.role === "STUDENT_MEMBER");

    setEditAdvisorId(advisor ? advisor.person_id : null);
    setEditAdvisorFallback(
      advisor
        ? { name: advisor.person_name, email: advisor.person_email, cpf: advisor.person_cpf }
        : null
    );

    if (coadvisor) {
      setShowEditCoadvisor(true);
      setEditCoadvisorId(coadvisor.person_id);
      setEditCoadvisorFallback({
        name: coadvisor.person_name,
        email: coadvisor.person_email,
        cpf: coadvisor.person_cpf,
      });
    } else {
      setShowEditCoadvisor(false);
      setEditCoadvisorId(null);
      setEditCoadvisorFallback(null);
    }

    setEditLeaderId(leader ? leader.person_id : null);
    setEditLeaderFallback(
      leader
        ? { name: leader.person_name, email: leader.person_email, cpf: leader.person_cpf }
        : null
    );

    setEditAdditionalStudents(
      additionalStudents.map((s) => ({
        person_id: s.person_id,
        fallback: { name: s.person_name, email: s.person_email, cpf: s.person_cpf },
      }))
    );

    setEditError(null);
    setIsEditModalOpen(true);
  };

  // Submeter Edição de Projeto
  const handleSubmitEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProject) return;

    if (!editFormData.title.trim()) {
      setEditError("O título do trabalho é obrigatório.");
      return;
    }

    if (!editFormData.subarea_id) {
      setEditError("Selecione uma subárea temática válida.");
      return;
    }

    if (!editAdvisorId) {
      setEditError("É obrigatório selecionar exatamente 1 Orientador cadastrado.");
      return;
    }

    if (!editLeaderId) {
      setEditError("É obrigatório selecionar 1 Estudante Líder cadastrado.");
      return;
    }

    const members: ProjectMemberInput[] = [
      { person_id: editAdvisorId, role: "ADVISOR" },
      { person_id: editLeaderId, role: "STUDENT_LEADER" },
    ];

    if (showEditCoadvisor && editCoadvisorId) {
      members.push({ person_id: editCoadvisorId, role: "COADVISOR" });
    }

    for (const s of editAdditionalStudents) {
      if (s.person_id) {
        members.push({ person_id: s.person_id, role: "STUDENT_MEMBER" });
      }
    }

    const allIds = members.map((m) => m.person_id);
    if (new Set(allIds).size !== allIds.length) {
      setEditError("Um mesmo participante não pode ser selecionado em mais de um papel no mesmo trabalho.");
      return;
    }

    const studentCount = members.filter(
      (m) => m.role === "STUDENT_LEADER" || m.role === "STUDENT_MEMBER"
    ).length;
    const maxStudentsAllowed = getMaxStudentsForLevel(editFormData.education_level);
    if (studentCount > maxStudentsAllowed) {
      setEditError(
        `Cota excedida: O nível ${editFormData.education_level} permite no máximo ${maxStudentsAllowed} estudantes (selecionados: ${studentCount}).`
      );
      return;
    }

    setIsSubmittingEdit(true);
    setEditError(null);

    try {
      const updated = await projectService.updateProject(editingProject.id, {
        title: editFormData.title.trim(),
        project_type: editFormData.project_type,
        education_level: editFormData.education_level,
        subarea_id: editFormData.subarea_id,
        booth_number: editFormData.booth_number.trim() || null,
        abstract: editFormData.abstract.trim() || null,
        needs_electricity: editFormData.needs_electricity,
        needs_table: editFormData.needs_table,
        members,
      });

      setProjects((prev) =>
        prev.map((p) => (p.id === updated.id ? updated : p))
      );
      setIsEditModalOpen(false);
      setEditingProject(null);
      setNotification({
        type: "success",
        text: `Trabalho "${updated.title}" atualizado com sucesso!`,
      });
      await loadProjects();
    } catch (err: any) {
      setEditError(
        err.response?.data?.detail || "Erro ao salvar alterações do trabalho."
      );
    } finally {
      setIsSubmittingEdit(false);
    }
  };

  // Abrir Modal de Criação de Projeto
  const openCreateModal = () => {
    let initialSubareaId = 0;
    for (const area of areas) {
      if (area.subareas && area.subareas.length > 0) {
        initialSubareaId = area.subareas[0].id;
        break;
      }
    }
    setCreateFormData({
      title: "",
      project_type: "SCIENTIFIC",
      education_level: "MEDIO",
      subarea_id: initialSubareaId,
      booth_number: "",
      abstract: "",
      needs_electricity: false,
      needs_table: false,
      auto_homologate: true,
    });
    setCreateAdvisorId(null);
    setShowCreateCoadvisor(false);
    setCreateCoadvisorId(null);
    setCreateLeaderId(null);
    setCreateAdditionalStudentIds([]);
    setCreateError(null);
    setIsCreateModalOpen(true);
  };

  // Submeter Criação de Novo Projeto Manualmente
  const handleSubmitCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeEvent) return;

    if (!createFormData.title.trim()) {
      setCreateError("O título do trabalho é obrigatório.");
      return;
    }

    if (!createFormData.subarea_id) {
      setCreateError("Selecione uma subárea temática válida.");
      return;
    }

    if (!createAdvisorId) {
      setCreateError("É obrigatório selecionar exatamente 1 Orientador cadastrado.");
      return;
    }

    if (!createLeaderId) {
      setCreateError("É obrigatório selecionar 1 Estudante Líder cadastrado.");
      return;
    }

    const members: ProjectMemberInput[] = [
      { person_id: createAdvisorId, role: "ADVISOR" },
      { person_id: createLeaderId, role: "STUDENT_LEADER" },
    ];

    if (showCreateCoadvisor && createCoadvisorId) {
      members.push({ person_id: createCoadvisorId, role: "COADVISOR" });
    }

    for (const id of createAdditionalStudentIds) {
      if (id) {
        members.push({ person_id: id, role: "STUDENT_MEMBER" });
      }
    }

    const allIds = members.map((m) => m.person_id);
    if (new Set(allIds).size !== allIds.length) {
      setCreateError("Um mesmo participante não pode ser selecionado em mais de um papel no mesmo trabalho.");
      return;
    }

    const studentCount = members.filter(
      (m) => m.role === "STUDENT_LEADER" || m.role === "STUDENT_MEMBER"
    ).length;
    const maxStudentsAllowed = getMaxStudentsForLevel(createFormData.education_level);
    if (studentCount > maxStudentsAllowed) {
      setCreateError(
        `Cota excedida: O nível ${createFormData.education_level} permite no máximo ${maxStudentsAllowed} estudantes (selecionados: ${studentCount}).`
      );
      return;
    }

    setIsSubmittingCreate(true);
    setCreateError(null);

    try {
      const created = await projectService.createProject({
        event_id: activeEvent.id,
        subarea_id: createFormData.subarea_id,
        education_level: createFormData.education_level,
        title: createFormData.title.trim(),
        project_type: createFormData.project_type,
        abstract: createFormData.abstract.trim() || undefined,
        needs_electricity: createFormData.needs_electricity,
        needs_table: createFormData.needs_table,
        booth_number: createFormData.booth_number.trim() || undefined,
        auto_homologate: createFormData.auto_homologate,
        members,
      });

      setIsCreateModalOpen(false);
      setNotification({
        type: "success",
        text: `Trabalho "${created.title}" cadastrado com sucesso!`,
      });
      await loadProjects();
    } catch (err: any) {
      setCreateError(
        err.response?.data?.detail || "Erro ao cadastrar novo trabalho."
      );
    } finally {
      setIsSubmittingCreate(false);
    }
  };

  // Download do template CSV oficial com fallback
  const handleDownloadTemplate = async () => {
    if (!activeEvent) return;
    try {
      setIsDownloadingTemplate(true);
      const blob = await projectService.downloadTemplateCsv(activeEvent.id);
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", `modelo_trabalhos_easyevent_evento_${activeEvent.id}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.warn("Falha ao baixar modelo do backend, usando gerador local:", err);
      downloadProjectsCsvTemplate(activeEvent.id, flattenedSubareas, maxStudents);
    } finally {
      setIsDownloadingTemplate(false);
    }
  };

  // Download individual do adesivo de bancada com QR Code
  const handleDownloadSingleBoothSticker = async (projectId: number) => {
    setDownloadingStickerId(projectId);
    try {
      await projectService.downloadProjectBoothStickerPdf(projectId, "a5_double");
      setNotification({
        type: "success",
        text: `Adesivo com QR Code do Trabalho #${projectId} baixado com sucesso!`,
      });
    } catch (err: any) {
      setNotification({
        type: "error",
        text:
          err.response?.data?.detail ||
          err.message ||
          `Erro ao baixar o adesivo do trabalho #${projectId}.`,
      });
    } finally {
      setDownloadingStickerId(null);
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Cabeçalho da Página */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white flex items-center gap-2.5">
            <FileText className="text-blue-600 dark:text-blue-400" size={26} />
            Trabalhos Científicos e Homologação
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            Gestão do ciclo de vida, validação de anuência do orientador, homologação documental e alocação de estandes.
          </p>
        </div>

        <div className="flex items-center flex-wrap gap-2">
          <Button
            variant="outline"
            onClick={() => setIsBoothStickersModalOpen(true)}
            className="text-xs border-indigo-300 dark:border-indigo-700 bg-white dark:bg-slate-900 text-indigo-800 dark:text-indigo-200 hover:bg-indigo-50"
            title="Gerar e imprimir adesivos com QR Code para as bancadas físicas dos projetos"
          >
            <QrCode size={15} className="mr-1.5 text-indigo-600 dark:text-indigo-400" />
            Adesivos de Bancada (PDF)
          </Button>

          <Button
            variant="outline"
            onClick={() => setIsKitCardsModalOpen(true)}
            className="text-xs border-teal-300 dark:border-teal-700 bg-white dark:bg-slate-900 text-teal-800 dark:text-teal-200 hover:bg-teal-50"
            title="Gerar e imprimir cards de kits individuais ou coletivos por estande"
          >
            <Package size={15} className="mr-1.5 text-teal-600 dark:text-teal-400" />
            Cards de Kits (PDF)
          </Button>

          <Button
            variant="outline"
            onClick={handleDownloadTemplate}
            disabled={isDownloadingTemplate}
            className="text-xs"
            title="Baixar modelo esqueleto CSV compatível com Microsoft Excel"
          >
            {isDownloadingTemplate ? (
              <RotateCcw size={14} className="mr-1.5 animate-spin text-blue-600" />
            ) : (
              <Download size={15} className="mr-1.5 text-blue-600 dark:text-blue-400" />
            )}
            Baixar Modelo CSV
          </Button>

          <Button
            variant="outline"
            onClick={() => setIsImportModalOpen(true)}
            className="text-xs"
            title="Importar trabalhos científicos em lote via planilha CSV com pré-visualização"
          >
            <Upload size={15} className="mr-1.5 text-slate-600 dark:text-slate-300" />
            Importar CSV
          </Button>

          <Button
            variant="primary"
            onClick={openCreateModal}
            className="text-xs shadow-sm"
            title="Cadastrar manualmente um novo trabalho científico nesta edição"
          >
            <Plus size={15} className="mr-1.5" />
            Novo Trabalho
          </Button>
        </div>
      </div>

      {/* Notificação Toast/Banner */}
      {notification && (
        <div
          className={`p-4 rounded-xl text-sm flex items-start justify-between gap-3 border transition-all ${
            notification.type === "success"
              ? "bg-emerald-50 text-emerald-800 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-800"
              : "bg-rose-50 text-rose-800 border-rose-200 dark:bg-rose-950/40 dark:text-rose-300 dark:border-rose-800"
          }`}
        >
          <div className="flex items-start gap-2.5">
            {notification.type === "success" ? (
              <CheckCircle2
                size={18}
                className="flex-shrink-0 mt-0.5 text-emerald-600 dark:text-emerald-400"
              />
            ) : (
              <AlertCircle
                size={18}
                className="flex-shrink-0 mt-0.5 text-rose-600 dark:text-rose-400"
              />
            )}
            <span>{notification.text}</span>
          </div>
          <button
            onClick={() => setNotification(null)}
            className="text-xs font-semibold opacity-70 hover:opacity-100"
          >
            Fechar
          </button>
        </div>
      )}

      {/* Banner de Edição Ativa no Painel (Multi-Evento BR-01, BR-19) */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-blue-50 dark:bg-blue-950/50 text-blue-600 dark:text-blue-400">
            <Calendar size={22} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                Edição Ativa no Painel
              </span>
              <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-blue-100 dark:bg-blue-900/60 text-blue-800 dark:text-blue-300">
                Ano {activeEvent?.year}
              </span>
            </div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white mt-0.5">
              {activeEvent?.name}
            </h2>
          </div>
        </div>

        <Link href="/events" className="self-start sm:self-auto">
          <Button variant="outline" size="sm">
            <span>Trocar Edição</span>
            <ArrowRight size={14} />
          </Button>
        </Link>
      </div>

      {/* Barra de Filtros e Pesquisa */}
      <Card className="p-4 shadow-sm border-slate-200 dark:border-slate-800">
        <div className="flex flex-col gap-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {/* Input de Busca */}
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                <Search size={16} />
              </div>
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Buscar por título, token ou estande..."
                className="w-full pl-9 pr-8 py-2 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
              />
              {searchTerm && (
                <button
                  onClick={() => setSearchTerm("")}
                  className="absolute inset-y-0 right-0 pr-2.5 flex items-center text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                  aria-label="Limpar busca"
                >
                  <X size={14} />
                </button>
              )}
            </div>

            {/* Filtro de Status */}
            <div>
              <select
                value={statusFilter}
                onChange={(e) => handleStatusFilterChange(e.target.value)}
                className="w-full py-2 px-3 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="ALL">Todos os Status</option>
                <option value="WAITING_CONSENT">Aguardando Anuência do Orientador</option>
                <option value="SUBMITTED">Submetidos (Aguardando Homologação)</option>
                <option value="HOMOLOGATED">Homologados</option>
                <option value="REJECTED">Indeferidos / Rejeitados</option>
                <option value="PRESENT">Presentes na Feira</option>
                <option value="ABSENT">Ausentes</option>
              </select>
            </div>

            {/* Filtro de Nível de Ensino */}
            <div>
              <select
                value={levelFilter}
                onChange={(e) => handleLevelFilterChange(e.target.value)}
                className="w-full py-2 px-3 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="ALL">Todos os Níveis de Ensino</option>
                <option value="JUNIOR">Ensino Fundamental I (Até 5 alunos)</option>
                <option value="FUNDAMENTAL">Ensino Fundamental II (Até 5 alunos)</option>
                <option value="MEDIO">Ensino Médio / Técnico (Até 4 alunos)</option>
                <option value="GRADUACAO">Graduação / Ensino Superior (Até 5 alunos)</option>
                <option value="POS_GRADUACAO">Pós-Graduação (Até 4 alunos)</option>
              </select>
            </div>

            {/* Filtro de Subárea */}
            <div>
              <select
                value={subareaFilter}
                onChange={(e) => handleSubareaFilterChange(e.target.value)}
                className="w-full py-2 px-3 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="ALL">Todas as Subáreas</option>
                {areas.map((area) => (
                  <optgroup key={area.id} label={area.name}>
                    {area.subareas?.map((sub) => (
                      <option key={sub.id} value={sub.id}>
                        {sub.name}
                      </option>
                    ))}
                  </optgroup>
                ))}
              </select>
            </div>
          </div>

          {/* Indicador de Filtro Ativo e Botão Reset */}
          {isFiltered && (
            <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800 text-xs">
              <div className="text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                <Filter size={13} className="text-blue-500" />
                Filtros ativos aplicados na listagem
              </div>
              <button
                onClick={clearFilters}
                className="inline-flex items-center gap-1 text-blue-600 dark:text-blue-400 font-semibold hover:underline"
              >
                <RotateCcw size={12} />
                Limpar todos os filtros
              </button>
            </div>
          )}
        </div>
      </Card>

      {/* Tabela de Trabalhos */}
      <Card className="overflow-hidden shadow-sm border-slate-200 dark:border-slate-800">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 font-semibold uppercase tracking-wider">
              <tr>
                <th className="py-3 px-4">Trabalho / Título</th>
                <th className="py-3 px-4">Área & Nível</th>
                <th className="py-3 px-4">Anuência do Orientador</th>
                <th className="py-3 px-4">Estande</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {isLoading ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-slate-400 animate-pulse">
                    Carregando trabalhos científicos...
                  </td>
                </tr>
              ) : projects.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-slate-400">
                    <FileText size={32} className="mx-auto mb-2 opacity-40" />
                    {isFiltered
                      ? "Nenhum trabalho encontrado para os filtros selecionados."
                      : "Nenhum trabalho submetido para esta edição ainda."}
                  </td>
                </tr>
              ) : (
                projects.map((proj) => (
                  <tr
                    key={proj.id}
                    className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40 transition-colors"
                  >
                    {/* Título & Token */}
                    <td className="py-3.5 px-4 max-w-xs sm:max-w-sm">
                      <div className="font-bold text-slate-900 dark:text-white line-clamp-2">
                        {proj.title}
                      </div>
                      <div className="flex flex-wrap items-center gap-1.5 mt-1.5">
                        <span className="inline-flex items-center gap-1 font-mono text-[10px] text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 px-1.5 py-0.5 rounded">
                          <QrCode size={10} />
                          {proj.qrcode_token}
                        </span>
                        <span className="inline-flex items-center text-[10px] font-medium px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                          {proj.project_type === "SCIENTIFIC" ? "🔬 Científico" : "⚙️ Tecnológico"}
                        </span>
                        {/* Indicadores de Infraestrutura */}
                        {proj.needs_electricity ? (
                          <span
                            className="inline-flex items-center gap-1 text-[10px] font-semibold text-amber-700 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/60 border border-amber-200 dark:border-amber-800 px-1.5 py-0.5 rounded"
                            title="O projeto necessita de ponto de energia elétrica (tomada)"
                          >
                            <Zap size={10} className="fill-amber-500 text-amber-500" />
                            Tomada: Sim
                          </span>
                        ) : (
                          <span
                            className="inline-flex items-center gap-1 text-[10px] text-slate-400 dark:text-slate-500 bg-slate-100/70 dark:bg-slate-800/50 px-1.5 py-0.5 rounded"
                            title="O projeto não necessita de ponto de energia elétrica"
                          >
                            <Zap size={10} className="opacity-40" />
                            Tomada: Não
                          </span>
                        )}

                        {proj.needs_table ? (
                          <span
                            className="inline-flex items-center gap-1 text-[10px] font-semibold text-blue-700 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-800 px-1.5 py-0.5 rounded"
                            title="O projeto necessita de mesa/bancada para protótipo"
                          >
                            <Box size={10} className="text-blue-500" />
                            Mesa: Sim
                          </span>
                        ) : (
                          <span
                            className="inline-flex items-center gap-1 text-[10px] text-slate-400 dark:text-slate-500 bg-slate-100/70 dark:bg-slate-800/50 px-1.5 py-0.5 rounded"
                            title="O projeto não necessita de mesa/bancada para protótipo"
                          >
                            <Box size={10} className="opacity-40" />
                            Mesa: Não
                          </span>
                        )}
                      </div>
                    </td>

                    {/* Área & Nível */}
                    <td className="py-3.5 px-4">
                      <div className="text-slate-900 dark:text-white font-medium">
                        {proj.subarea_name || "—"}
                      </div>
                      <div className="text-[11px] text-slate-500 dark:text-slate-400">
                        {proj.area_name}
                      </div>
                      <div className="mt-1">
                        <span className="inline-flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                          <GraduationCap size={10} />
                          {proj.education_level === "MEDIO"
                            ? "Ensino Médio"
                            : proj.education_level === "FUNDAMENTAL"
                            ? "Fundamental II"
                            : proj.education_level === "JUNIOR"
                            ? "Fundamental I"
                            : proj.education_level === "GRADUACAO"
                            ? "Graduação"
                            : proj.education_level === "POS_GRADUACAO"
                            ? "Pós-Graduação"
                            : proj.education_level}
                        </span>
                      </div>
                    </td>

                    {/* Anuência Formal */}
                    <td className="py-3.5 px-4">
                      {proj.advisor_consent ? (
                        <div className="inline-flex items-center gap-1 text-emerald-700 dark:text-emerald-400 text-xs font-semibold bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 px-2 py-0.5 rounded-full">
                          <CheckCircle2 size={13} />
                          Anuência Concedida
                        </div>
                      ) : (
                        <div className="inline-flex items-center gap-1 text-amber-700 dark:text-amber-400 text-xs font-semibold bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 px-2 py-0.5 rounded-full">
                          <AlertTriangle size={13} />
                          Pendente de Anuência
                        </div>
                      )}
                    </td>

                    {/* Estande */}
                    <td className="py-3.5 px-4">
                      {proj.booth_number ? (
                        <span className="inline-flex items-center gap-1 px-2 py-1 bg-blue-50 dark:bg-blue-950/50 text-blue-700 dark:text-blue-300 font-mono font-bold rounded-lg border border-blue-200 dark:border-blue-800">
                          <MapPin size={12} />
                          {proj.booth_number}
                        </span>
                      ) : (
                        <span className="text-slate-400 text-xs">—</span>
                      )}
                    </td>

                    {/* Status */}
                    <td className="py-3.5 px-4">
                      <StatusBadge status={proj.status} />
                    </td>

                    {/* Ações */}
                    <td className="py-3.5 px-4 text-right">
                      <div className="inline-flex items-center gap-1.5">
                        {/* Botão Ver Detalhes */}
                        <button
                          onClick={() => openDetails(proj)}
                          className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 transition-colors"
                          title="Ver detalhes completos do trabalho"
                        >
                          <Eye size={15} />
                        </button>

                        {/* Botão Editar Trabalho */}
                        <button
                          onClick={() => openEditModal(proj)}
                          className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:bg-amber-50 dark:hover:bg-amber-950/50 hover:text-amber-600 dark:hover:text-amber-400 text-slate-700 dark:text-slate-200 transition-colors"
                          title="Editar dados cadastrais do trabalho e infraestrutura"
                        >
                          <Pencil size={15} />
                        </button>

                        {/* Botão Homologação (Deferir/Indeferir) */}
                        <button
                          onClick={() => openHomologateModal(proj)}
                          className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:bg-blue-50 dark:hover:bg-blue-950/50 hover:text-blue-600 dark:hover:text-blue-400 text-slate-700 dark:text-slate-200 transition-colors"
                          title="Homologar ou indeferir submissão"
                        >
                          <FileCheck2 size={15} />
                        </button>

                        {/* Botão Alocar Estande */}
                        <button
                          onClick={() => openBoothModal(proj)}
                          className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:bg-teal-50 dark:hover:bg-teal-950/50 hover:text-teal-600 dark:hover:text-teal-400 text-slate-700 dark:text-slate-200 transition-colors"
                          title="Alocar ou editar número do estande"
                        >
                          <MapPin size={15} />
                        </button>

                        {/* Botão Adesivo de Bancada (PDF) Individual */}
                        <button
                          onClick={() => handleDownloadSingleBoothSticker(proj.id)}
                          disabled={downloadingStickerId === proj.id}
                          className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:bg-indigo-50 dark:hover:bg-indigo-950/50 hover:text-indigo-600 dark:hover:text-indigo-400 text-slate-700 dark:text-slate-200 transition-colors"
                          title="Baixar adesivo com QR Code para bancada deste trabalho (PDF)"
                        >
                          {downloadingStickerId === proj.id ? (
                            <RotateCcw size={15} className="animate-spin text-indigo-600" />
                          ) : (
                            <QrCode size={15} />
                          )}
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Rodapé de Paginação Real (BR-18: 15 itens por página) */}
        <div className="p-4 border-t border-slate-200 dark:border-slate-800">
          <Pagination
            currentPage={page}
            totalPages={totalPages}
            totalItems={totalItems}
            limit={15}
            onPageChange={(p) => setPage(p)}
            isLoading={isLoading}
          />
        </div>
      </Card>

      {/* MODAL 1: DETALHES COMPLETOS DO TRABALHO */}
      <Modal
        isOpen={isDetailsModalOpen}
        onClose={() => setIsDetailsModalOpen(false)}
        title="Detalhes do Trabalho Científico"
      >
        {detailsProject && (
          <div className="space-y-4 text-xs">
            <div>
              <span className="font-semibold text-slate-500 uppercase tracking-wider text-[10px]">
                Título da Pesquisa
              </span>
              <h4 className="text-sm font-bold text-slate-900 dark:text-white mt-0.5">
                {detailsProject.title}
              </h4>
            </div>

            <div className="grid grid-cols-2 gap-3 p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200 dark:border-slate-800">
              <div>
                <span className="text-slate-500 text-[10px] block">Status Atual</span>
                <div className="mt-1">
                  <StatusBadge status={detailsProject.status} />
                </div>
              </div>
              <div>
                <span className="text-slate-500 text-[10px] block">Estande</span>
                <span className="font-bold font-mono text-sm text-slate-900 dark:text-white">
                  {detailsProject.booth_number || "Não alocado"}
                </span>
              </div>
              <div>
                <span className="text-slate-500 text-[10px] block">Área & Subárea</span>
                <span className="font-medium text-slate-900 dark:text-white">
                  {detailsProject.area_name} &gt; {detailsProject.subarea_name}
                </span>
              </div>
              <div>
                <span className="text-slate-500 text-[10px] block">Token QR do Estande</span>
                <span className="font-mono text-slate-900 dark:text-white">
                  {detailsProject.qrcode_token}
                </span>
              </div>
            </div>

            {/* Infraestrutura do Estande */}
            <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200 dark:border-slate-800 space-y-2">
              <span className="text-slate-500 text-[10px] font-semibold uppercase tracking-wider block">
                Infraestrutura do Estande
              </span>
              <div className="grid grid-cols-2 gap-3 pt-0.5">
                <div className="flex items-center gap-2">
                  <div
                    className={`p-2 rounded-lg ${
                      detailsProject.needs_electricity
                        ? "bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300"
                        : "bg-slate-100 text-slate-400 dark:bg-slate-800 dark:text-slate-500"
                    }`}
                  >
                    <Zap size={16} />
                  </div>
                  <div>
                    <span className="text-slate-500 text-[10px] block">Ponto de Energia (Tomada)</span>
                    <span className="font-bold text-xs text-slate-900 dark:text-white">
                      {detailsProject.needs_electricity ? "Sim, necessita" : "Não necessita"}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <div
                    className={`p-2 rounded-lg ${
                      detailsProject.needs_table
                        ? "bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-300"
                        : "bg-slate-100 text-slate-400 dark:bg-slate-800 dark:text-slate-500"
                    }`}
                  >
                    <Box size={16} />
                  </div>
                  <div>
                    <span className="text-slate-500 text-[10px] block">Mesa para Protótipo</span>
                    <span className="font-bold text-xs text-slate-900 dark:text-white">
                      {detailsProject.needs_table ? "Sim, necessita" : "Não necessita"}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Anuência Formal do Orientador */}
            <div
              className={`p-3 rounded-xl border ${
                detailsProject.advisor_consent
                  ? "bg-emerald-50/60 border-emerald-200 dark:bg-emerald-950/30 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300"
                  : "bg-amber-50/60 border-amber-200 dark:bg-amber-950/30 dark:border-amber-800 text-amber-800 dark:text-amber-300"
              }`}
            >
              <div className="flex items-center gap-2 font-bold">
                {detailsProject.advisor_consent ? (
                  <>
                    <CheckCircle2 size={16} className="text-emerald-600 dark:text-emerald-400" />
                    <span>Anuência Digital Concedida pelo Orientador</span>
                  </>
                ) : (
                  <>
                    <AlertTriangle size={16} className="text-amber-600 dark:text-amber-400" />
                    <span>Pendente de Anuência do Orientador</span>
                  </>
                )}
              </div>
              <p className="mt-1 text-[11px] leading-relaxed opacity-90">
                {detailsProject.advisor_consent
                  ? `Autorização confirmada pelo orientador em ${
                      detailsProject.advisor_consent_at
                        ? new Date(detailsProject.advisor_consent_at).toLocaleString("pt-BR")
                        : "data registrada"
                    }. Trabalho apto para deferimento.`
                  : "O orientador formalmente indicado na submissão ainda não concedeu a anuência digital. O projeto não pode ser homologado enquanto a autorização estiver pendente."}
              </p>
            </div>

            {/* Motivo do Indeferimento (se houver) */}
            {detailsProject.rejection_reason && (
              <div className="p-3 rounded-xl border border-rose-200 dark:border-rose-800 bg-rose-50/60 dark:bg-rose-950/30 text-rose-800 dark:text-rose-300">
                <div className="font-bold flex items-center gap-1.5 mb-1">
                  <XCircle size={14} className="text-rose-600" />
                  Motivo do Indeferimento:
                </div>
                <p className="text-[11px] leading-relaxed">
                  {detailsProject.rejection_reason}
                </p>
              </div>
            )}

            {/* Resumo do Trabalho */}
            <div>
              <span className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                Resumo / Abstract:
              </span>
              <p className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 leading-relaxed max-h-36 overflow-y-auto">
                {detailsProject.abstract || "Nenhum resumo cadastrado."}
              </p>
            </div>

            {/* Equipe / Integrantes */}
            <div>
              <span className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                Equipe e Orientação:
              </span>
              <div className="space-y-1.5">
                {detailsProject.members && detailsProject.members.length > 0 ? (
                  detailsProject.members.map((m) => (
                    <div
                      key={m.id}
                      className="flex items-center justify-between p-2 rounded-lg bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800"
                    >
                      <div className="flex items-center gap-2">
                        <Users size={14} className="text-slate-400" />
                        <div>
                          <span className="font-bold text-slate-900 dark:text-white">
                            {m.person_name || `Pessoa #${m.person_id}`}
                          </span>
                          {m.person_email && (
                            <span className="text-[11px] text-slate-500 block">
                              {m.person_email}
                            </span>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {m.tshirt_size && (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                            👕 {m.tshirt_size}
                          </span>
                        )}
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300">
                          {(m.role === "STUDENT_LEADER" || m.role === "STUDENT_MEMBER") && "Estudante"}
                          {m.role === "ADVISOR" && "Orientador"}
                          {m.role === "COADVISOR" && "Coorientador"}
                        </span>
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="text-slate-400 text-xs">Membros não listados.</p>
                )}
              </div>
            </div>

            {/* Arquivos Submetidos */}
            {(detailsProject.summary_file_url ||
              detailsProject.banner_file_url ||
              detailsProject.logbook_file_url) && (
              <div>
                <span className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Arquivos Submetidos:
                </span>
                <div className="flex flex-wrap gap-2">
                  {detailsProject.summary_file_url && (
                    <a
                      href={detailsProject.summary_file_url}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800 hover:underline"
                    >
                      <ExternalLink size={12} />
                      Resumo Expandido
                    </a>
                  )}
                  {detailsProject.banner_file_url && (
                    <a
                      href={detailsProject.banner_file_url}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-teal-50 dark:bg-teal-950/40 text-teal-700 dark:text-teal-300 border border-teal-200 dark:border-teal-800 hover:underline"
                    >
                      <ExternalLink size={12} />
                      Banner
                    </a>
                  )}
                  {detailsProject.logbook_file_url && (
                    <a
                      href={detailsProject.logbook_file_url}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-purple-50 dark:bg-purple-950/40 text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-800 hover:underline"
                    >
                      <ExternalLink size={12} />
                      Diário de Bordo
                    </a>
                  )}
                </div>
              </div>
            )}

            <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex justify-end">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsDetailsModalOpen(false)}
              >
                Fechar
              </Button>
            </div>
          </div>
        )}
      </Modal>

      {/* MODAL 2: HOMOLOGAÇÃO (DEFERIR / INDEFERIR) */}
      <Modal
        isOpen={isHomologateModalOpen}
        onClose={() => setIsHomologateModalOpen(false)}
        title="Homologação Documental da Submissão"
        error={homologateError}
      >
        {homologateProject && (
          <form onSubmit={handleSubmitHomologation} className="space-y-4 text-xs">
            <div>
              <span className="font-semibold text-slate-500 uppercase tracking-wider text-[10px]">
                Trabalho a Homologar
              </span>
              <h4 className="text-sm font-bold text-slate-900 dark:text-white mt-0.5">
                {homologateProject.title}
              </h4>
            </div>

            {/* Aviso se não tiver anuência */}
            {!homologateProject.advisor_consent && (
              <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-amber-800 dark:text-amber-300">
                <div className="flex items-center gap-2 font-bold mb-1">
                  <AlertTriangle size={15} className="text-amber-600 dark:text-amber-400" />
                  Atenção: Ausência de Anuência do Orientador
                </div>
                <p className="text-[11px] leading-relaxed">
                  O orientador titular formalmente indicado ainda não concedeu anuência digital a este trabalho. Apenas trabalhos com anuência do orientador podem ser deferidos para a feira presencial.
                </p>
              </div>
            )}

            {/* Escolha da Decisão */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
                Decisão da Coordenação:
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setHomologateDecision("APPROVE")}
                  className={`p-3 rounded-xl border flex flex-col items-center gap-1.5 transition-all text-center ${
                    homologateDecision === "APPROVE"
                      ? "border-emerald-500 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-900 dark:text-emerald-200 ring-2 ring-emerald-500/20 font-bold"
                      : "border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-400"
                  }`}
                >
                  <CheckCircle2 size={20} className="text-emerald-600 dark:text-emerald-400" />
                  <span>Deferir Submissão</span>
                  <span className="text-[10px] font-normal opacity-80">
                    Aprovar para a Feira
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setHomologateDecision("REJECT")}
                  className={`p-3 rounded-xl border flex flex-col items-center gap-1.5 transition-all text-center ${
                    homologateDecision === "REJECT"
                      ? "border-rose-500 bg-rose-50 dark:bg-rose-950/40 text-rose-900 dark:text-rose-200 ring-2 ring-rose-500/20 font-bold"
                      : "border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-400"
                  }`}
                >
                  <XCircle size={20} className="text-rose-600 dark:text-rose-400" />
                  <span>Indeferir Submissão</span>
                  <span className="text-[10px] font-normal opacity-80">
                    Reprovar com Justificativa
                  </span>
                </button>
              </div>
            </div>

            {/* Se Deferir: Alocação Opcional de Estande */}
            {homologateDecision === "APPROVE" && (
              <div className="space-y-1.5 pt-2 border-t border-slate-100 dark:border-slate-800">
                <Input
                  label="Número do Estande (Opcional na homologação):"
                  placeholder="Ex: A-12, B-04"
                  value={boothInput}
                  onChange={(e) => setBoothInput(e.target.value)}
                  helperText="Você pode definir ou alterar o estande agora ou posteriormente."
                />
              </div>
            )}

            {/* Se Indeferir: Justificativa Obrigatória */}
            {homologateDecision === "REJECT" && (
              <div className="space-y-1.5 pt-2 border-t border-slate-100 dark:border-slate-800">
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Justificativa do Indeferimento (Obrigatória):
                </label>
                <textarea
                  rows={3}
                  value={rejectionReasonInput}
                  onChange={(e) => setRejectionReasonInput(e.target.value)}
                  placeholder="Ex: Documentação comprobatória incompleta ou ausência de adequação às normas científicas..."
                  className="w-full px-3.5 py-2.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
            )}

            {/* Ações do Modal */}
            <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex justify-end gap-2">
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => setIsHomologateModalOpen(false)}
                disabled={isSubmittingHomologation}
              >
                Cancelar
              </Button>
              <Button
                type="submit"
                variant={homologateDecision === "APPROVE" ? "primary" : "danger"}
                size="sm"
                isLoading={isSubmittingHomologation}
              >
                {homologateDecision === "APPROVE"
                  ? "Confirmar Homologação (Deferir)"
                  : "Confirmar Indeferimento"}
              </Button>
            </div>
          </form>
        )}
      </Modal>

      {/* MODAL 3: ALOCAÇÃO DE ESTANDE */}
      <Modal
        isOpen={isBoothModalOpen}
        onClose={() => setIsBoothModalOpen(false)}
        title="Alocar Estande de Apresentação"
        error={boothError}
      >
        {boothProject && (
          <form onSubmit={handleSubmitBooth} className="space-y-4 text-xs">
            <div>
              <span className="font-semibold text-slate-500 uppercase tracking-wider text-[10px]">
                Trabalho Selecionado
              </span>
              <h4 className="text-sm font-bold text-slate-900 dark:text-white mt-0.5">
                {boothProject.title}
              </h4>
            </div>

            <div className="space-y-1.5">
              <Input
                label="Identificação do Estande:"
                placeholder="Ex: A-12, B-05, C-18"
                value={standaloneBoothInput}
                onChange={(e) => setStandaloneBoothInput(e.target.value)}
                helperText="Código alfanumérico que será associado ao crachá e ao QR Code de estande."
                required
              />
            </div>

            <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex justify-end gap-2">
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => setIsBoothModalOpen(false)}
                disabled={isSubmittingBooth}
              >
                Cancelar
              </Button>
              <Button
                type="submit"
                variant="primary"
                size="sm"
                isLoading={isSubmittingBooth}
              >
                Salvar Estande
              </Button>
            </div>
          </form>
        )}
      </Modal>

      {/* MODAL 4: EDITAR TRABALHO CIENTÍFICO / TECNOLÓGICO */}
      <Modal
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        title="Editar Dados do Trabalho Científico"
        error={editError}
        maxWidth="max-w-2xl"
      >
        {editingProject && (() => {
          const editSelectedIds = [
            editAdvisorId,
            showEditCoadvisor ? editCoadvisorId : null,
            editLeaderId,
            ...editAdditionalStudents.map((s) => s.person_id),
          ].filter((id): id is number => Boolean(id));

          const editMaxStudents = getMaxStudentsForLevel(editFormData.education_level);
          const editRemainingStudentSlots = Math.max(
            0,
            editMaxStudents - 1 - editAdditionalStudents.length
          );

          return (
            <form onSubmit={handleSubmitEdit} className="space-y-4 text-xs">
              <Input
                label="Título do Trabalho:"
                value={editFormData.title}
                onChange={(e) => setEditFormData({ ...editFormData, title: e.target.value })}
                required
              />

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Tipo do Projeto:
                  </label>
                  <select
                    value={editFormData.project_type}
                    onChange={(e) => setEditFormData({ ...editFormData, project_type: e.target.value as any })}
                    className="w-full py-2 px-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="SCIENTIFIC">Científico</option>
                    <option value="TECHNOLOGICAL">Tecnológico</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Nível de Ensino:
                  </label>
                  <select
                    value={editFormData.education_level}
                    onChange={(e) => setEditFormData({ ...editFormData, education_level: e.target.value as any })}
                    className="w-full py-2 px-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="JUNIOR">Ensino Fundamental I (Júnior)</option>
                    <option value="FUNDAMENTAL">Ensino Fundamental II</option>
                    <option value="MEDIO">Ensino Médio / Técnico</option>
                    <option value="GRADUACAO">Graduação / Superior</option>
                    <option value="POS_GRADUACAO">Pós-Graduação</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Subárea Temática:
                  </label>
                  <select
                    value={editFormData.subarea_id}
                    onChange={(e) => setEditFormData({ ...editFormData, subarea_id: Number(e.target.value) })}
                    className="w-full py-2 px-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    {areas.map((area) => (
                      <optgroup key={area.id} label={area.name}>
                        {area.subareas?.map((sub) => (
                          <option key={sub.id} value={sub.id}>
                            {sub.name}
                          </option>
                        ))}
                      </optgroup>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Número / Código do Estande:
                  </label>
                  <input
                    type="text"
                    placeholder="Ex: A-12, B-04"
                    value={editFormData.booth_number}
                    onChange={(e) => setEditFormData({ ...editFormData, booth_number: e.target.value })}
                    className="w-full py-2 px-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono"
                  />
                </div>
              </div>

              {/* Checkboxes de Infraestrutura */}
              <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200 dark:border-slate-800 space-y-2.5">
                <span className="font-semibold text-slate-700 dark:text-slate-300 block text-[11px]">
                  Necessidades de Infraestrutura no Estande:
                </span>

                <label className="flex items-center gap-2.5 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={editFormData.needs_electricity}
                    onChange={(e) => setEditFormData({ ...editFormData, needs_electricity: e.target.checked })}
                    className="h-4 w-4 rounded border-slate-300 text-amber-600 focus:ring-amber-500"
                  />
                  <span className="text-slate-800 dark:text-slate-200 text-xs flex items-center gap-1.5">
                    <Zap size={14} className={editFormData.needs_electricity ? "text-amber-500 fill-amber-500" : "text-slate-400"} />
                    O projeto necessita de ponto de energia elétrica (tomada)?
                  </span>
                </label>

                <label className="flex items-center gap-2.5 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={editFormData.needs_table}
                    onChange={(e) => setEditFormData({ ...editFormData, needs_table: e.target.checked })}
                    className="h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="text-slate-800 dark:text-slate-200 text-xs flex items-center gap-1.5">
                    <Box size={14} className={editFormData.needs_table ? "text-blue-500" : "text-slate-400"} />
                    Necessita de mesa/bancada para o protótipo?
                  </span>
                </label>
              </div>

              {/* Seção de Autores (Orientação e Estudantes) - BR-04 e BR-05 */}
              <div className="p-3.5 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200 dark:border-slate-800 space-y-3.5">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-800 dark:text-slate-200 block text-xs flex items-center gap-1.5">
                    <Users size={14} className="text-blue-500" />
                    Autores do Trabalho (Participantes Cadastrados)
                  </span>
                  <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
                    Cota do nível: até {editMaxStudents} estudantes
                  </span>
                </div>

                <div className="p-2.5 bg-blue-50/70 dark:bg-blue-950/30 rounded-lg border border-blue-100 dark:border-blue-900/40 text-[11px] text-blue-800 dark:text-blue-300 flex items-start gap-2">
                  <AlertCircle size={14} className="text-blue-600 shrink-0 mt-0.5" />
                  <span>
                    Apenas participantes previamente cadastrados nesta edição da feira podem ser associados como autores. Precisa cadastrar alguém novo?{" "}
                    <Link
                      href="/participants"
                      target="_blank"
                      className="font-bold underline hover:text-blue-900 dark:hover:text-blue-200 inline-flex items-center gap-0.5"
                    >
                      Abrir Participantes <ExternalLink size={10} />
                    </Link>
                  </span>
                </div>

                {/* Orientação */}
                <div className="space-y-3 pt-1">
                  <ParticipantSelect
                    label="Orientador (Obrigatório)"
                    role="ADVISOR"
                    required
                    eventId={activeEvent?.id}
                    selectedPersonId={editAdvisorId}
                    fallbackInfo={editAdvisorFallback}
                    participants={eventParticipants}
                    disabledPersonIds={editSelectedIds.filter((id) => id !== editAdvisorId)}
                    onSelect={(p) => {
                      setEditAdvisorId(p ? p.person_id : null);
                      setEditAdvisorFallback(p ? { name: p.name, email: p.email, cpf: p.cpf } : null);
                    }}
                  />

                  {showEditCoadvisor ? (
                    <ParticipantSelect
                      label="Coorientador (Opcional - máx 1)"
                      role="COADVISOR"
                      eventId={activeEvent?.id}
                      selectedPersonId={editCoadvisorId}
                      fallbackInfo={editCoadvisorFallback}
                      participants={eventParticipants}
                      disabledPersonIds={editSelectedIds.filter((id) => id !== editCoadvisorId)}
                      onSelect={(p) => {
                        setEditCoadvisorId(p ? p.person_id : null);
                        setEditCoadvisorFallback(p ? { name: p.name, email: p.email, cpf: p.cpf } : null);
                      }}
                      onRemove={() => {
                        setShowEditCoadvisor(false);
                        setEditCoadvisorId(null);
                        setEditCoadvisorFallback(null);
                      }}
                    />
                  ) : (
                    <button
                      type="button"
                      onClick={() => setShowEditCoadvisor(true)}
                      className="text-[11px] font-semibold text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 flex items-center gap-1 py-1"
                    >
                      <Plus size={13} />
                      Adicionar Coorientador (opcional)
                    </button>
                  )}
                </div>

                {/* Estudantes */}
                <div className="space-y-3 pt-2 border-t border-slate-200 dark:border-slate-700/60">
                  <ParticipantSelect
                    label="Estudante Líder (Obrigatório)"
                    role="STUDENT_LEADER"
                    required
                    eventId={activeEvent?.id}
                    selectedPersonId={editLeaderId}
                    fallbackInfo={editLeaderFallback}
                    participants={eventParticipants}
                    disabledPersonIds={editSelectedIds.filter((id) => id !== editLeaderId)}
                    onSelect={(p) => {
                      setEditLeaderId(p ? p.person_id : null);
                      setEditLeaderFallback(p ? { name: p.name, email: p.email, cpf: p.cpf } : null);
                    }}
                  />

                  {editAdditionalStudents.map((student, sIdx) => (
                    <ParticipantSelect
                      key={sIdx}
                      label={`Estudante Integrante ${sIdx + 2}`}
                      role="STUDENT_MEMBER"
                      eventId={activeEvent?.id}
                      selectedPersonId={student.person_id}
                      fallbackInfo={student.fallback}
                      participants={eventParticipants}
                      disabledPersonIds={editSelectedIds.filter((id) => id !== student.person_id)}
                      onSelect={(p) => {
                        const updated = [...editAdditionalStudents];
                        updated[sIdx] = {
                          person_id: p ? p.person_id : null,
                          fallback: p ? { name: p.name, email: p.email, cpf: p.cpf } : null,
                        };
                        setEditAdditionalStudents(updated);
                      }}
                      onRemove={() => {
                        setEditAdditionalStudents(
                          editAdditionalStudents.filter((_, idx) => idx !== sIdx)
                        );
                      }}
                    />
                  ))}

                  {editRemainingStudentSlots > 0 ? (
                    <button
                      type="button"
                      onClick={() => {
                        setEditAdditionalStudents([
                          ...editAdditionalStudents,
                          { person_id: null, fallback: null },
                        ]);
                      }}
                      className="w-full py-2 border border-dashed border-slate-300 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-300 hover:border-blue-500 hover:text-blue-600 dark:hover:border-blue-400 dark:hover:text-blue-400 transition-colors flex items-center justify-center gap-1.5"
                    >
                      <Plus size={14} />
                      Adicionar Estudante ({editRemainingStudentSlots} vaga(s) restante(s))
                    </button>
                  ) : (
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 italic text-center py-1">
                      Cota máxima de {editMaxStudents} estudantes atingida para este nível de ensino.
                    </p>
                  )}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Resumo do Trabalho:
                </label>
                <textarea
                  rows={3}
                  value={editFormData.abstract}
                  onChange={(e) => setEditFormData({ ...editFormData, abstract: e.target.value })}
                  placeholder="Breve descrição dos objetivos e metodologia do trabalho..."
                  className="w-full p-2.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex justify-end gap-2">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setIsEditModalOpen(false)}
                  disabled={isSubmittingEdit}
                >
                  Cancelar
                </Button>
                <Button
                  type="submit"
                  variant="primary"
                  size="sm"
                  isLoading={isSubmittingEdit}
                >
                  Salvar Alterações
                </Button>
              </div>
            </form>
          );
        })()}
      </Modal>

      {/* MODAL: CADASTRAR NOVO TRABALHO MANUAL */}
      <Modal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        title="Cadastrar Novo Trabalho Científico"
        error={createError}
        maxWidth="max-w-2xl"
      >
        {(() => {
          const createSelectedIds = [
            createAdvisorId,
            showCreateCoadvisor ? createCoadvisorId : null,
            createLeaderId,
            ...createAdditionalStudentIds,
          ].filter((id): id is number => Boolean(id));

          const createMaxStudents = getMaxStudentsForLevel(createFormData.education_level);
          const createRemainingStudentSlots = Math.max(
            0,
            createMaxStudents - 1 - createAdditionalStudentIds.length
          );

          return (
            <form onSubmit={handleSubmitCreate} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Título do Trabalho: <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ex: Análise da Eficiência Energética de Painéis Solares Fotovoltaicos"
                  value={createFormData.title}
                  onChange={(e) => setCreateFormData({ ...createFormData, title: e.target.value })}
                  className="w-full py-2 px-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Tipo de Projeto: <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={createFormData.project_type}
                    onChange={(e) => setCreateFormData({ ...createFormData, project_type: e.target.value as any })}
                    className="w-full py-2 px-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="SCIENTIFIC">Científico</option>
                    <option value="TECHNOLOGICAL">Tecnológico</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Nível de Ensino: <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={createFormData.education_level}
                    onChange={(e) => setCreateFormData({ ...createFormData, education_level: e.target.value as any })}
                    className="w-full py-2 px-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="JUNIOR">Ensino Fundamental I (Júnior)</option>
                    <option value="FUNDAMENTAL">Ensino Fundamental II</option>
                    <option value="MEDIO">Ensino Médio / Técnico</option>
                    <option value="GRADUACAO">Graduação / Superior</option>
                    <option value="POS_GRADUACAO">Pós-Graduação</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Subárea Temática: <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={createFormData.subarea_id}
                    onChange={(e) => setCreateFormData({ ...createFormData, subarea_id: Number(e.target.value) })}
                    className="w-full py-2 px-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value={0} disabled>Selecione a subárea...</option>
                    {areas.map((area) => (
                      <optgroup key={area.id} label={area.name}>
                        {area.subareas?.map((sub) => (
                          <option key={sub.id} value={sub.id}>
                            {sub.name}
                          </option>
                        ))}
                      </optgroup>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Número / Código do Estande:
                  </label>
                  <input
                    type="text"
                    placeholder="Ex: A-12, B-04, 105"
                    value={createFormData.booth_number}
                    onChange={(e) => setCreateFormData({ ...createFormData, booth_number: e.target.value })}
                    className="w-full py-2 px-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono"
                  />
                </div>
              </div>

              {/* Checkboxes de Infraestrutura */}
              <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200 dark:border-slate-800 space-y-2.5">
                <span className="font-semibold text-slate-700 dark:text-slate-300 block text-[11px]">
                  Necessidades de Infraestrutura no Estande:
                </span>

                <label className="flex items-center gap-2.5 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={createFormData.needs_electricity}
                    onChange={(e) => setCreateFormData({ ...createFormData, needs_electricity: e.target.checked })}
                    className="h-4 w-4 rounded border-slate-300 text-amber-600 focus:ring-amber-500"
                  />
                  <span className="text-slate-800 dark:text-slate-200 text-xs flex items-center gap-1.5">
                    <Zap size={14} className={createFormData.needs_electricity ? "text-amber-500 fill-amber-500" : "text-slate-400"} />
                    O projeto necessita de ponto de energia elétrica (tomada)?
                  </span>
                </label>

                <label className="flex items-center gap-2.5 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={createFormData.needs_table}
                    onChange={(e) => setCreateFormData({ ...createFormData, needs_table: e.target.checked })}
                    className="h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="text-slate-800 dark:text-slate-200 text-xs flex items-center gap-1.5">
                    <Box size={14} className={createFormData.needs_table ? "text-blue-500" : "text-slate-400"} />
                    Necessita de mesa/bancada para o protótipo?
                  </span>
                </label>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Resumo do Trabalho:
                </label>
                <textarea
                  rows={3}
                  value={createFormData.abstract}
                  onChange={(e) => setCreateFormData({ ...createFormData, abstract: e.target.value })}
                  placeholder="Breve descrição dos objetivos e metodologia do trabalho..."
                  className="w-full p-2.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                />
              </div>

              {/* Opção de Homologação Automática */}
              <div className="p-3 bg-emerald-50/70 dark:bg-emerald-950/30 rounded-xl border border-emerald-200 dark:border-emerald-800">
                <label className="flex items-start gap-2.5 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={createFormData.auto_homologate}
                    onChange={(e) => setCreateFormData({ ...createFormData, auto_homologate: e.target.checked })}
                    className="h-4 w-4 rounded border-slate-300 text-emerald-600 focus:ring-emerald-500 mt-0.5"
                  />
                  <div className="text-xs space-y-0.5">
                    <span className="font-bold text-emerald-900 dark:text-emerald-200 block">
                      Homologar e conceder anuência formal automaticamente
                    </span>
                    <span className="text-emerald-700 dark:text-emerald-400 block text-[11px]">
                      Habilita imediatamente o trabalho para emissão de adesivos de bancada, retirada de kits e avaliação.
                    </span>
                  </div>
                </label>
              </div>

              {/* Seção de Autores (Orientação e Estudantes) - BR-04 e BR-05 */}
              <div className="p-3.5 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200 dark:border-slate-800 space-y-3.5">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-800 dark:text-slate-200 block text-xs flex items-center gap-1.5">
                    <Users size={14} className="text-blue-500" />
                    Autores do Trabalho (Participantes Cadastrados)
                  </span>
                  <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
                    Cota do nível: até {createMaxStudents} estudantes
                  </span>
                </div>

                <div className="p-2.5 bg-blue-50/70 dark:bg-blue-950/30 rounded-lg border border-blue-100 dark:border-blue-900/40 text-[11px] text-blue-800 dark:text-blue-300 flex items-start gap-2">
                  <AlertCircle size={14} className="text-blue-600 shrink-0 mt-0.5" />
                  <span>
                    Apenas participantes previamente cadastrados nesta edição da feira podem ser associados como autores. Precisa cadastrar alguém novo?{" "}
                    <Link
                      href="/participants"
                      target="_blank"
                      className="font-bold underline hover:text-blue-900 dark:hover:text-blue-200 inline-flex items-center gap-0.5"
                    >
                      Abrir Participantes <ExternalLink size={10} />
                    </Link>
                  </span>
                </div>

                {/* Orientação */}
                <div className="space-y-3 pt-1">
                  <ParticipantSelect
                    label="Orientador (Obrigatório)"
                    role="ADVISOR"
                    required
                    eventId={activeEvent?.id}
                    selectedPersonId={createAdvisorId}
                    participants={eventParticipants}
                    disabledPersonIds={createSelectedIds.filter((id) => id !== createAdvisorId)}
                    onSelect={(p) => setCreateAdvisorId(p ? p.person_id : null)}
                  />

                  {showCreateCoadvisor ? (
                    <ParticipantSelect
                      label="Coorientador (Opcional - máx 1)"
                      role="COADVISOR"
                      eventId={activeEvent?.id}
                      selectedPersonId={createCoadvisorId}
                      participants={eventParticipants}
                      disabledPersonIds={createSelectedIds.filter((id) => id !== createCoadvisorId)}
                      onSelect={(p) => setCreateCoadvisorId(p ? p.person_id : null)}
                      onRemove={() => {
                        setShowCreateCoadvisor(false);
                        setCreateCoadvisorId(null);
                      }}
                    />
                  ) : (
                    <button
                      type="button"
                      onClick={() => setShowCreateCoadvisor(true)}
                      className="text-[11px] font-semibold text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 flex items-center gap-1 py-1"
                    >
                      <Plus size={13} />
                      Adicionar Coorientador (opcional)
                    </button>
                  )}
                </div>

                {/* Estudantes */}
                <div className="space-y-3 pt-2 border-t border-slate-200 dark:border-slate-700/60">
                  <ParticipantSelect
                    label="Estudante Líder (Obrigatório)"
                    role="STUDENT_LEADER"
                    required
                    eventId={activeEvent?.id}
                    selectedPersonId={createLeaderId}
                    participants={eventParticipants}
                    disabledPersonIds={createSelectedIds.filter((id) => id !== createLeaderId)}
                    onSelect={(p) => setCreateLeaderId(p ? p.person_id : null)}
                  />

                  {createAdditionalStudentIds.map((studentId, sIdx) => (
                    <ParticipantSelect
                      key={sIdx}
                      label={`Estudante Integrante ${sIdx + 2}`}
                      role="STUDENT_MEMBER"
                      eventId={activeEvent?.id}
                      selectedPersonId={studentId}
                      participants={eventParticipants}
                      disabledPersonIds={createSelectedIds.filter((id) => id !== studentId)}
                      onSelect={(p) => {
                        const updated = [...createAdditionalStudentIds];
                        updated[sIdx] = p ? p.person_id : null;
                        setCreateAdditionalStudentIds(updated);
                      }}
                      onRemove={() => {
                        setCreateAdditionalStudentIds(
                          createAdditionalStudentIds.filter((_, idx) => idx !== sIdx)
                        );
                      }}
                    />
                  ))}

                  {createRemainingStudentSlots > 0 ? (
                    <button
                      type="button"
                      onClick={() => {
                        setCreateAdditionalStudentIds([...createAdditionalStudentIds, null]);
                      }}
                      className="w-full py-2 border border-dashed border-slate-300 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-300 hover:border-blue-500 hover:text-blue-600 dark:hover:border-blue-400 dark:hover:text-blue-400 transition-colors flex items-center justify-center gap-1.5"
                    >
                      <Plus size={14} />
                      Adicionar Estudante ({createRemainingStudentSlots} vaga(s) restante(s))
                    </button>
                  ) : (
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 italic text-center py-1">
                      Cota máxima de {createMaxStudents} estudantes atingida para este nível de ensino.
                    </p>
                  )}
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex justify-end gap-2">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setIsCreateModalOpen(false)}
                  disabled={isSubmittingCreate}
                >
                  Cancelar
                </Button>
                <Button
                  type="submit"
                  variant="primary"
                  size="sm"
                  isLoading={isSubmittingCreate}
                >
                  Cadastrar Trabalho
                </Button>
              </div>
            </form>
          );
        })()}
      </Modal>

      {/* MODAL 4: IMPORTAÇÃO EM LOTE CSV */}
      {activeEvent && (
        <ProjectsCsvImportModal
          isOpen={isImportModalOpen}
          onClose={() => setIsImportModalOpen(false)}
          eventId={activeEvent.id}
          subareas={flattenedSubareas}
          existingProjects={projects}
          maxStudents={maxStudents}
          onSuccess={(summary) => {
            setNotification({
              type: "success",
              text: `Importação em lote concluída com sucesso: ${summary.created} trabalhos criados e ${summary.updated} atualizados (${summary.total} no total).`,
            });
            loadProjects();
          }}
        />
      )}

      {/* MODAL 5: CARDS DE KITS PDF */}
      {activeEvent && (
        <KitCardsModal
          isOpen={isKitCardsModalOpen}
          onClose={() => setIsKitCardsModalOpen(false)}
          eventId={activeEvent.id}
          eventName={activeEvent.name}
          onSuccess={(msg) => {
            setNotification({
              type: "success",
              text: msg,
            });
          }}
        />
      )}

      {/* MODAL 6: ADESIVOS DE BANCADA COM QR CODE PDF */}
      {activeEvent && (
        <BoothStickersModal
          isOpen={isBoothStickersModalOpen}
          onClose={() => setIsBoothStickersModalOpen(false)}
          eventId={activeEvent.id}
          eventName={activeEvent.name}
          areas={areas}
          onSuccess={(msg) => {
            setNotification({
              type: "success",
              text: msg,
            });
          }}
        />
      )}
    </div>
  );
}
