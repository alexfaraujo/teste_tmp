"use client";

import React, { useEffect, useState, useMemo, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import Link from "next/link";
import {
  Trophy,
  Medal,
  Award,
  BookOpen,
  GraduationCap,
  Sparkles,
  Printer,
  AlertCircle,
  Filter,
  ExternalLink,
  ChevronRight,
  RotateCcw,
} from "lucide-react";
import { useActiveEvent } from "../../../context/EventContext";
import { RequireActiveEvent } from "../../../components/common/RequireActiveEvent";
import { dashboardService } from "../../../services/dashboard.service";
import { awardService } from "../../../services/award.service";
import { areaService } from "../../../services/area.service";
import {
  AreaLevelLeaderboardGroup,
  LevelLeaderboardGroup,
  OverallLeaderboardResponse,
  AwardItem,
  AwardStandingsResponse,
  KnowledgeArea,
} from "../../../types";
import { Button } from "../../../components/ui/Button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "../../../components/ui/Card";

function ResultsContent() {
  const searchParams = useSearchParams();
  const { activeEvent } = useActiveEvent();

  const [activeTab, setActiveTab] = useState<"area-level" | "overall" | "awards">(
    (searchParams.get("tab") as "area-level" | "overall" | "awards") || "area-level"
  );

  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Tab 1: Área e Nível de Ensino (Ranking 1)
  const [areaLevelGroups, setAreaLevelGroups] = useState<
    AreaLevelLeaderboardGroup[]
  >([]);
  const [areas, setAreas] = useState<KnowledgeArea[]>([]);
  const [selectedAreaFilter, setSelectedAreaFilter] = useState<string>("ALL");
  const [selectedLevelFilter, setSelectedLevelFilter] = useState<string>("ALL");

  // Tab 2: Melhor Geral da Feira (Ranking 1)
  const [overallStandings, setOverallStandings] =
    useState<OverallLeaderboardResponse | null>(null);
  const [selectedOverallLevelFilter, setSelectedOverallLevelFilter] =
    useState<string>("ALL");

  // Tab 3: Premiações Específicas (Ranking 2)
  const [awards, setAwards] = useState<AwardItem[]>([]);
  const [selectedAwardId, setSelectedAwardId] = useState<number | null>(null);
  const [awardStandings, setAwardStandings] =
    useState<AwardStandingsResponse | null>(null);
  const [isLoadingAward, setIsLoadingAward] = useState(false);

  // Carregar dados gerais do evento
  async function loadInitialData() {
    if (!activeEvent) return;
    setIsLoading(true);
    setError(null);

    try {
      const [areaLevelData, overallData, awardsData, areasData] =
        await Promise.all([
          dashboardService.getAreaLevelLeaderboard(activeEvent.id),
          dashboardService.getOverallLeaderboard(activeEvent.id),
          awardService.getAwards(activeEvent.id),
          areaService.getAreas(activeEvent.id),
        ]);

      setAreaLevelGroups(areaLevelData);
      setOverallStandings(overallData);
      setAwards(awardsData);
      setAreas(areasData);

      // Se veio parâmetro award_id pela URL ou há premiações cadastradas
      const paramAwardId = searchParams.get("award_id");
      if (paramAwardId) {
        const found = awardsData.find((a) => a.id === Number(paramAwardId));
        if (found) {
          setSelectedAwardId(found.id);
        } else if (awardsData.length > 0) {
          setSelectedAwardId(awardsData[0].id);
        }
      } else if (awardsData.length > 0) {
        setSelectedAwardId(awardsData[0].id);
      }
    } catch (err: any) {
      setError(
        err.response?.data?.detail ||
          "Erro ao apurar as notas e classificações oficiais do evento."
      );
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    loadInitialData();
  }, [activeEvent?.id]);

  // Carregar apuração do prêmio específico selecionado
  useEffect(() => {
    async function loadAwardStandings(awardId: number) {
      setIsLoadingAward(true);
      try {
        const data = await awardService.getAwardStandings(awardId);
        setAwardStandings(data);
      } catch (err: any) {
        setAwardStandings(null);
      } finally {
        setIsLoadingAward(false);
      }
    }

    if (selectedAwardId) {
      loadAwardStandings(selectedAwardId);
    }
  }, [selectedAwardId]);

  // Grupos de Área e Nível Filtrados
  const filteredAreaLevelGroups = useMemo(() => {
    return areaLevelGroups.filter((group) => {
      const matchesArea =
        selectedAreaFilter === "ALL" ||
        String(group.area_id) === selectedAreaFilter;
      const matchesLevel =
        selectedLevelFilter === "ALL" ||
        group.education_level === selectedLevelFilter;
      return matchesArea && matchesLevel;
    });
  }, [areaLevelGroups, selectedAreaFilter, selectedLevelFilter]);

  // Opções de Níveis de Ensino disponíveis para filtro na Tab 2 (Melhor Geral da Feira)
  const availableOverallLevels = useMemo(() => {
    if (overallStandings?.by_education_level && overallStandings.by_education_level.length > 0) {
      return overallStandings.by_education_level.map((g) => ({
        value: g.education_level,
        label: g.education_level_label,
      }));
    }
    return [
      { value: "JUNIOR", label: "Ensino Fundamental I" },
      { value: "FUNDAMENTAL", label: "Ensino Fundamental II" },
      { value: "MEDIO", label: "Ensino Médio" },
      { value: "GRADUACAO", label: "Graduação" },
      { value: "POS_GRADUACAO", label: "Pós-Graduação" },
    ];
  }, [overallStandings]);

  // Grupos por Nível de Ensino no Ranking Geral (Melhor Geral da Feira)
  const overallLevelGroups = useMemo<LevelLeaderboardGroup[]>(() => {
    if (!overallStandings) return [];

    // Se o backend forneceu by_education_level diretamente:
    let groups = overallStandings.by_education_level || [];

    // Fallback de retrocompatibilidade se a API não retornar by_education_level:
    if (groups.length === 0 && overallStandings.standings.length > 0) {
      const levelOrder = ["JUNIOR", "FUNDAMENTAL", "MEDIO", "GRADUACAO", "POS_GRADUACAO"];
      const levelLabels: Record<string, string> = {
        JUNIOR: "Ensino Fundamental I",
        FUNDAMENTAL: "Ensino Fundamental II",
        MEDIO: "Ensino Médio",
        GRADUACAO: "Graduação",
        POS_GRADUACAO: "Pós-Graduação",
      };

      const grouped: Record<string, typeof overallStandings.standings> = {};
      for (const item of overallStandings.standings) {
        const lvl = item.education_level || "MEDIO";
        if (!grouped[lvl]) grouped[lvl] = [];
        grouped[lvl].push(item);
      }

      const keys = Object.keys(grouped).sort((a, b) => {
        const ia = levelOrder.indexOf(a);
        const ib = levelOrder.indexOf(b);
        return (ia === -1 ? 99 : ia) - (ib === -1 ? 99 : ib);
      });

      groups = keys.map((lvl) => {
        const items = [...grouped[lvl]].sort((a, b) => {
          if (b.final_score !== a.final_score) return b.final_score - a.final_score;
          if (b.evaluations_count !== a.evaluations_count) return b.evaluations_count - a.evaluations_count;
          return a.project_id - b.project_id;
        });
        return {
          education_level: lvl as any,
          education_level_label: levelLabels[lvl] || lvl,
          total_projects: items.length,
          standings: items.map((p, idx) => ({ ...p, rank_position: idx + 1 })),
        };
      });
    }

    if (selectedOverallLevelFilter === "ALL") {
      return groups;
    }
    return groups.filter((g) => g.education_level === selectedOverallLevelFilter);
  }, [overallStandings, selectedOverallLevelFilter]);

  // Função auxiliar para badge de colocação
  const getRankBadge = (rank: number) => {
    if (rank === 1) {
      return (
        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-black bg-amber-100 dark:bg-amber-950/60 text-amber-900 dark:text-amber-200 border border-amber-300 dark:border-amber-700 shadow-2xs">
          <Trophy size={13} className="text-amber-500 fill-amber-500" />
          1º Lugar (Ouro)
        </span>
      );
    }
    if (rank === 2) {
      return (
        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-slate-200 dark:bg-slate-800 text-slate-800 dark:text-slate-200 border border-slate-300 dark:border-slate-700 shadow-2xs">
          <Medal size={13} className="text-slate-500 fill-slate-400" />
          2º Lugar (Prata)
        </span>
      );
    }
    if (rank === 3) {
      return (
        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-amber-50 dark:bg-amber-950/30 text-amber-800 dark:text-amber-300 border border-amber-200 dark:border-amber-800 shadow-2xs">
          <Medal size={13} className="text-amber-700 fill-amber-600" />
          3º Lugar (Bronze)
        </span>
      );
    }
    return (
      <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold text-slate-500 dark:text-slate-400">
        {rank}º Lugar
      </span>
    );
  };

  return (
    <RequireActiveEvent minRole="ORGANIZER" featureName="a Classificação Oficial e Resultados">
      <div className="space-y-6 max-w-7xl mx-auto">
        {/* Cabeçalho de Impressão (Exibido apenas na Ata Oficial impressa) */}
        <div className="hidden print:block mb-8 text-center border-b-2 border-slate-800 pb-4">
          <h1 className="text-xl font-black uppercase tracking-wider text-black">
            {activeEvent?.name || "EasyEvent — Gestão de Eventos"}
          </h1>
          <h2 className="text-lg font-bold text-slate-800 mt-1">
            Ata Oficial de Homologação de Resultados e Premiações
          </h2>
          <p className="text-xs text-slate-600 mt-1">
            Edição {activeEvent?.year || new Date().getFullYear()} • Relatório Consolidado de Avaliação
          </p>
          <p className="text-[10px] text-slate-500 mt-0.5">
            Documento emitido pelo Painel do Administrador em {new Date().toLocaleDateString("pt-BR")} às {new Date().toLocaleTimeString("pt-BR")}
          </p>
        </div>

        {/* Page Header da Tela (Oculto na impressão) */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 print:hidden">
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white flex items-center gap-2.5">
              <Trophy className="text-amber-500" size={26} />
              Classificação e Apuração Oficial
            </h1>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
              Sistema Dual de Premiação: <strong>Ranking 1</strong> (Área/Nível via Média Simples e Melhor Geral) e <strong>Ranking 2</strong> (Premiações Específicas Ponderadas).
            </p>
          </div>

          <div className="flex items-center gap-3">
            <Button
              variant="outline"
              size="md"
              onClick={() => window.print()}
              title="Imprimir Ata Oficial formatada para assinatura"
            >
              <Printer size={16} className="mr-1.5 text-slate-600 dark:text-slate-300" />
              Imprimir Ata Oficial
            </Button>
          </div>
        </div>

        {/* Alerta de Erro */}
        {error && (
          <div className="p-4 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 text-red-700 dark:text-red-300 text-sm flex items-center gap-3 print:hidden">
            <AlertCircle size={18} className="flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Abas de Navegação (Oculto na impressão) */}
        <div className="flex border-b border-slate-200 dark:border-slate-800 space-x-6 print:hidden">
          <button
            onClick={() => setActiveTab("area-level")}
            className={`pb-3 text-xs sm:text-sm font-bold flex items-center gap-2 border-b-2 transition-colors cursor-pointer ${
              activeTab === "area-level"
                ? "border-blue-600 text-blue-600 dark:text-blue-400"
                : "border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300"
            }`}
          >
            <BookOpen size={16} />
            Por Área e Nível (Ranking 1)
          </button>

          <button
            onClick={() => setActiveTab("overall")}
            className={`pb-3 text-xs sm:text-sm font-bold flex items-center gap-2 border-b-2 transition-colors cursor-pointer ${
              activeTab === "overall"
                ? "border-blue-600 text-blue-600 dark:text-blue-400"
                : "border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300"
            }`}
          >
            <Sparkles size={16} />
            Melhor Geral da Feira (Ranking 1)
          </button>

          <button
            onClick={() => setActiveTab("awards")}
            className={`pb-3 text-xs sm:text-sm font-bold flex items-center gap-2 border-b-2 transition-colors cursor-pointer ${
              activeTab === "awards"
                ? "border-blue-600 text-blue-600 dark:text-blue-400"
                : "border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300"
            }`}
          >
            <Award size={16} />
            Premiações Específicas (Ranking 2)
          </button>
        </div>

        {/* ======================================================== */}
        {/* ABA 1: POR ÁREA E NÍVEL DE ENSINO (RANKING 1)             */}
        {/* ======================================================== */}
        {(activeTab === "area-level" || typeof window === "undefined") && (
          <div className="space-y-6">
            {/* Caixa Explicativa (Oculto na impressão) */}
            <div className="bg-blue-50/70 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-900/40 rounded-xl p-4 text-xs text-blue-900 dark:text-blue-300 leading-relaxed print:hidden">
              <strong>Média Aritmética Simples (sem Descarte de Notas):</strong> As notas finais dos projetos na categoria principal são calculadas somando-se as notas de <strong>todos os critérios</strong> da ficha de avaliação e dividindo-se pela quantidade de fichas submetidas.
            </div>

            {/* Filtros Rápidos (Oculto na impressão) */}
            <div className="flex flex-wrap items-center gap-3 bg-white dark:bg-slate-900 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 print:hidden">
              <div className="flex items-center gap-2">
                <Filter size={15} className="text-slate-400" />
                <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Filtrar Grupo:
                </span>
              </div>

              {/* Grande Área */}
              <select
                value={selectedAreaFilter}
                onChange={(e) => setSelectedAreaFilter(e.target.value)}
                className="px-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-medium text-slate-900 dark:text-white focus:outline-none"
              >
                <option value="ALL">Todas as Grandes Áreas</option>
                {areas.map((a) => (
                  <option key={a.id} value={String(a.id)}>
                    {a.name}
                  </option>
                ))}
              </select>

              {/* Nível de Ensino */}
              <select
                value={selectedLevelFilter}
                onChange={(e) => setSelectedLevelFilter(e.target.value)}
                className="px-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-medium text-slate-900 dark:text-white focus:outline-none"
              >
                <option value="ALL">Todos os Níveis de Ensino</option>
                <option value="JUNIOR">Ensino Fundamental I</option>
                <option value="FUNDAMENTAL">Ensino Fundamental II</option>
                <option value="MEDIO">Ensino Médio</option>
                <option value="GRADUACAO">Graduação</option>
                <option value="POS_GRADUACAO">Pós-Graduação</option>
              </select>

              {(selectedAreaFilter !== "ALL" || selectedLevelFilter !== "ALL") && (
                <button
                  onClick={() => {
                    setSelectedAreaFilter("ALL");
                    setSelectedLevelFilter("ALL");
                  }}
                  className="text-xs text-blue-600 dark:text-blue-400 font-semibold hover:underline flex items-center gap-1"
                >
                  <RotateCcw size={12} />
                  Limpar Filtros
                </button>
              )}
            </div>

            {/* Listagem de Grupos */}
            {isLoading ? (
              <div className="py-16 text-center text-sm text-slate-500 animate-pulse">
                Apurando notas oficiais por grande área e nível de ensino...
              </div>
            ) : filteredAreaLevelGroups.length === 0 ? (
              <Card className="p-12 text-center text-slate-500">
                <BookOpen size={40} className="mx-auto mb-3 text-slate-400 opacity-60" />
                <p className="font-semibold text-slate-700 dark:text-slate-300">
                  Nenhum resultado registrado para os filtros selecionados.
                </p>
                <p className="text-xs text-slate-400 mt-1">
                  Certifique-se de que os avaliadores já concluíram e enviaram as fichas de avaliação.
                </p>
              </Card>
            ) : (
              filteredAreaLevelGroups.map((group, gIdx) => {
                const top3 = group.standings.slice(0, 3);
                return (
                  <Card key={gIdx} className="overflow-hidden border-slate-200 dark:border-slate-800 shadow-sm">
                    <CardHeader className="pb-3 border-b border-slate-200 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-800/40">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                        <div>
                          <CardTitle className="text-base font-bold flex items-center gap-2 text-slate-900 dark:text-white">
                            <GraduationCap size={19} className="text-blue-600" />
                            {group.area_name}
                          </CardTitle>
                          <CardDescription className="text-xs mt-0.5">
                            Nível:{" "}
                            <strong>
                              {group.education_level === "MEDIO"
                                ? "Ensino Médio"
                                : group.education_level === "FUNDAMENTAL"
                                ? "Ensino Fundamental II"
                                : group.education_level === "JUNIOR"
                                ? "Ensino Fundamental I"
                                : group.education_level === "GRADUACAO"
                                ? "Graduação"
                                : "Pós-Graduação"}
                            </strong>{" "}
                            • {group.total_projects} trabalho(s) avaliado(s)
                          </CardDescription>
                        </div>

                        <span className="text-xs font-semibold px-2.5 py-1 rounded-md bg-blue-100 dark:bg-blue-950 text-blue-800 dark:text-blue-300 border border-blue-200 dark:border-blue-900 w-fit">
                          Ranking Oficial por Categoria
                        </span>
                      </div>
                    </CardHeader>

                    <CardContent className="p-0">
                      {/* Pódio Visual (1º, 2º e 3º) - Oculto na impressão simples */}
                      {top3.length > 0 && (
                        <div className="p-4 bg-gradient-to-r from-slate-50 via-blue-50/20 to-slate-50 dark:from-slate-900 dark:via-blue-950/20 dark:to-slate-900 border-b border-slate-200 dark:border-slate-800 print:hidden">
                          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-3">
                            Pódio de Vencedores:
                          </span>
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                            {top3.map((pod, pIdx) => (
                              <div
                                key={pod.project_id}
                                className={`p-3 rounded-xl border flex flex-col justify-between ${
                                  pIdx === 0
                                    ? "bg-amber-50/90 border-amber-300 dark:bg-amber-950/40 dark:border-amber-800 shadow-2xs"
                                    : pIdx === 1
                                    ? "bg-slate-100/90 border-slate-300 dark:bg-slate-800/60 dark:border-slate-700"
                                    : "bg-amber-50/40 border-amber-200/80 dark:bg-amber-950/20 dark:border-amber-900/60"
                                }`}
                              >
                                <div>
                                  <div className="flex items-center justify-between gap-2 mb-1.5">
                                    {getRankBadge(pod.rank_position)}
                                    {pod.booth_number && (
                                      <span className="text-[11px] font-mono font-bold text-blue-600 dark:text-blue-400 bg-white dark:bg-slate-900 px-1.5 py-0.5 rounded border border-slate-200 dark:border-slate-700">
                                        Estande {pod.booth_number}
                                      </span>
                                    )}
                                  </div>
                                  <h4 className="text-xs font-bold text-slate-900 dark:text-white line-clamp-2 leading-snug" title={pod.title}>
                                    {pod.title}
                                  </h4>
                                  <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 truncate">
                                    {pod.area_name ? `${pod.area_name} > ` : ""}{pod.subarea_name}
                                  </p>
                                </div>

                                <div className="mt-2.5 pt-2 border-t border-black/5 dark:border-white/5 flex items-center justify-between">
                                  <span className="text-[10px] text-slate-400">
                                    {pod.evaluations_count} ficha(s)
                                  </span>
                                  <span className="font-mono font-black text-sm text-slate-900 dark:text-white">
                                    {pod.final_score.toFixed(2)} pts
                                  </span>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Tabela Completa de Classificação */}
                      <div className="overflow-x-auto">
                        <table className="w-full text-left text-xs">
                          <thead className="text-[11px] font-bold text-slate-500 uppercase border-b border-slate-200 dark:border-slate-800 bg-slate-50/40 dark:bg-slate-900">
                            <tr>
                              <th className="py-2.5 px-4 w-36">Colocação</th>
                              <th className="py-2.5 px-4 w-24">Estande</th>
                              <th className="py-2.5 px-4">Trabalho Científico</th>
                              <th className="py-2.5 px-4">Área & Subárea</th>
                              <th className="py-2.5 px-4 text-center">Fichas</th>
                              <th className="py-2.5 px-4 text-right">Nota Final</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                            {group.standings.map((p) => (
                              <tr
                                key={p.project_id}
                                className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors"
                              >
                                <td className="py-2.5 px-4 whitespace-nowrap">
                                  {getRankBadge(p.rank_position)}
                                </td>

                                <td className="py-2.5 px-4 font-mono font-bold text-blue-600 dark:text-blue-400 whitespace-nowrap">
                                  {p.booth_number ? (
                                    <span className="bg-blue-50 dark:bg-blue-950 px-2 py-0.5 rounded border border-blue-200 dark:border-blue-900">
                                      {p.booth_number}
                                    </span>
                                  ) : (
                                    <span className="text-slate-400">—</span>
                                  )}
                                </td>

                                <td className="py-2.5 px-4">
                                  <div className="font-semibold text-slate-900 dark:text-white line-clamp-1">
                                    {p.title}
                                  </div>
                                  <div className="text-[10px] text-slate-400 font-mono">
                                    ID: #{p.project_id}
                                  </div>
                                </td>

                                <td className="py-2.5 px-4 text-slate-600 dark:text-slate-300 whitespace-nowrap">
                                  {p.area_name ? `${p.area_name} > ` : ""}{p.subarea_name}
                                </td>

                                <td className="py-2.5 px-4 text-center whitespace-nowrap font-medium text-slate-600 dark:text-slate-400">
                                  {p.evaluations_count}
                                </td>

                                <td className="py-2.5 px-4 text-right whitespace-nowrap font-mono font-bold text-sm text-slate-900 dark:text-white">
                                  {p.final_score.toFixed(2)}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </CardContent>
                  </Card>
                );
              })
            )}
          </div>
        )}

        {/* ======================================================== */}
        {/* ABA 2: MELHOR GERAL DA FEIRA (RANKING 1 - OVERALL)        */}
        {/* ======================================================== */}
        {activeTab === "overall" && (
          <div className="space-y-6">
            <div className="bg-teal-50/70 dark:bg-teal-950/30 border border-teal-200 dark:border-teal-900/40 rounded-xl p-4 text-xs text-teal-900 dark:text-teal-300 leading-relaxed print:hidden flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <strong>Melhor Geral da Feira (Classificação por Nível de Ensino):</strong> Classificação dos projetos com maiores notas gerais da feira, divididos em um ranking exclusivo para cada nível de ensino configurado para o evento, independentemente da Grande Área do Conhecimento.
              </div>
              <div className="whitespace-nowrap font-semibold text-teal-800 dark:text-teal-200 text-xs">
                Total avaliado no evento: <strong>{overallStandings?.total_evaluated_projects || 0}</strong> trabalhos
              </div>
            </div>

            {/* Filtro Rápido de Nível de Ensino (Oculto na impressão) */}
            <div className="flex flex-wrap items-center gap-3 bg-white dark:bg-slate-900 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 print:hidden">
              <div className="flex items-center gap-2">
                <Filter size={15} className="text-slate-400" />
                <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Filtrar Nível de Ensino:
                </span>
              </div>

              <select
                value={selectedOverallLevelFilter}
                onChange={(e) => setSelectedOverallLevelFilter(e.target.value)}
                className="px-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-medium text-slate-900 dark:text-white focus:outline-none"
              >
                <option value="ALL">Todos os Níveis de Ensino</option>
                {availableOverallLevels.map((lvl) => (
                  <option key={lvl.value} value={lvl.value}>
                    {lvl.label}
                  </option>
                ))}
              </select>

              {selectedOverallLevelFilter !== "ALL" && (
                <button
                  onClick={() => setSelectedOverallLevelFilter("ALL")}
                  className="text-xs text-teal-600 dark:text-teal-400 font-semibold hover:underline flex items-center gap-1"
                >
                  <RotateCcw size={12} />
                  Limpar Filtro
                </button>
              )}
            </div>

            {/* Listagem de Rankings por Nível de Ensino */}
            {isLoading ? (
              <div className="py-16 text-center text-sm text-slate-500 animate-pulse">
                Carregando apuração oficial por nível de ensino...
              </div>
            ) : overallLevelGroups.length === 0 ? (
              <Card className="p-12 text-center text-slate-500">
                <Sparkles size={40} className="mx-auto mb-3 text-slate-400 opacity-60" />
                <p className="font-semibold text-slate-700 dark:text-slate-300">
                  Nenhum resultado registrado para o ranking geral.
                </p>
                <p className="text-xs text-slate-400 mt-1">
                  Certifique-se de que os avaliadores já concluíram e enviaram as fichas de avaliação.
                </p>
              </Card>
            ) : (
              overallLevelGroups.map((group) => (
                <Card
                  key={group.education_level}
                  className="border-slate-200 dark:border-slate-800 shadow-sm"
                >
                  <CardHeader className="pb-3 border-b border-slate-200 dark:border-slate-800">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <div>
                        <CardTitle className="text-base font-bold flex items-center gap-2 text-slate-900 dark:text-white">
                          <Trophy size={19} className="text-amber-500" />
                          Melhor Geral da Feira — {group.education_level_label}
                        </CardTitle>
                        <CardDescription className="text-xs mt-0.5">
                          Total de trabalhos avaliados neste nível:{" "}
                          <strong>{group.total_projects}</strong>
                        </CardDescription>
                      </div>
                    </div>
                  </CardHeader>

                  <CardContent className="p-0">
                    {group.standings.length === 0 ? (
                      <div className="py-12 text-center text-xs text-slate-500">
                        Nenhum trabalho avaliado registrado para {group.education_level_label.toLowerCase()}.
                      </div>
                    ) : (
                      <div>
                        {/* Pódio Visual do Nível */}
                        <div className="p-4 bg-gradient-to-r from-slate-50 via-teal-50/20 to-slate-50 dark:from-slate-900 dark:via-teal-950/20 dark:to-slate-900 border-b border-slate-200 dark:border-slate-800 print:hidden">
                          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-3">
                            Top 3 — {group.education_level_label}:
                          </span>
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                            {group.standings.slice(0, 3).map((pod, pIdx) => (
                              <div
                                key={pod.project_id}
                                className={`p-3 rounded-xl border flex flex-col justify-between ${
                                  pIdx === 0
                                    ? "bg-amber-50/90 border-amber-300 dark:bg-amber-950/40 dark:border-amber-800 shadow-2xs"
                                    : pIdx === 1
                                    ? "bg-slate-100/90 border-slate-300 dark:bg-slate-800/60 dark:border-slate-700"
                                    : "bg-amber-50/40 border-amber-200/80 dark:bg-amber-950/20 dark:border-amber-900/60"
                                }`}
                              >
                                <div>
                                  <div className="flex items-center justify-between gap-2 mb-1.5">
                                    {getRankBadge(pod.rank_position)}
                                    {pod.booth_number && (
                                      <span className="text-[11px] font-mono font-bold text-teal-600 dark:text-teal-400 bg-white dark:bg-slate-900 px-1.5 py-0.5 rounded border border-slate-200 dark:border-slate-700">
                                        Estande {pod.booth_number}
                                      </span>
                                    )}
                                  </div>
                                  <h4
                                    className="text-xs font-bold text-slate-900 dark:text-white line-clamp-2 leading-snug"
                                    title={pod.title}
                                  >
                                    {pod.title}
                                  </h4>
                                  <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 truncate">
                                    {pod.area_name ? `${pod.area_name} > ` : ""}
                                    {pod.subarea_name}
                                  </p>
                                </div>

                                <div className="mt-2.5 pt-2 border-t border-black/5 dark:border-white/5 flex items-center justify-between">
                                  <span className="text-[10px] text-slate-400">
                                    {pod.evaluations_count} ficha(s)
                                  </span>
                                  <span className="font-mono font-black text-sm text-slate-900 dark:text-white">
                                    {pod.final_score.toFixed(2)} pts
                                  </span>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* Tabela do Nível */}
                        <div className="overflow-x-auto">
                          <table className="w-full text-left text-xs">
                            <thead className="text-[11px] font-bold text-slate-500 uppercase border-b border-slate-200 dark:border-slate-800 bg-slate-50/40 dark:bg-slate-900">
                              <tr>
                                <th className="py-2.5 px-4 w-36">Colocação</th>
                                <th className="py-2.5 px-4 w-24">Estande</th>
                                <th className="py-2.5 px-4">Trabalho Científico</th>
                                <th className="py-2.5 px-4">Área & Subárea</th>
                                <th className="py-2.5 px-4 text-center">Fichas</th>
                                <th className="py-2.5 px-4 text-right">Média Final</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                              {group.standings.map((p) => (
                                <tr
                                  key={p.project_id}
                                  className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors"
                                >
                                  <td className="py-2.5 px-4 whitespace-nowrap">
                                    {getRankBadge(p.rank_position)}
                                  </td>

                                  <td className="py-2.5 px-4 font-mono font-bold text-teal-600 dark:text-teal-400 whitespace-nowrap">
                                    {p.booth_number ? (
                                      <span className="bg-teal-50 dark:bg-teal-950 px-2 py-0.5 rounded border border-teal-200 dark:border-teal-900">
                                        {p.booth_number}
                                      </span>
                                    ) : (
                                      <span className="text-slate-400">—</span>
                                    )}
                                  </td>

                                  <td className="py-2.5 px-4">
                                    <div className="font-semibold text-slate-900 dark:text-white line-clamp-1">
                                      {p.title}
                                    </div>
                                    <div className="text-[10px] text-slate-400 font-mono">
                                      ID: #{p.project_id}
                                    </div>
                                  </td>

                                  <td className="py-2.5 px-4 text-slate-600 dark:text-slate-300 whitespace-nowrap">
                                    {p.area_name ? `${p.area_name} > ` : ""}
                                    {p.subarea_name}
                                  </td>

                                  <td className="py-2.5 px-4 text-center whitespace-nowrap font-medium text-slate-600 dark:text-slate-400">
                                    {p.evaluations_count}
                                  </td>

                                  <td className="py-2.5 px-4 text-right whitespace-nowrap font-mono font-bold text-sm text-slate-900 dark:text-white">
                                    {p.final_score.toFixed(2)}
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        )}

        {/* ======================================================== */}
        {/* ABA 3: PREMIAÇÕES ESPECÍFICAS (RANKING 2)                */}
        {/* ======================================================== */}
        {activeTab === "awards" && (
          <div className="space-y-6">
            <div className="bg-purple-50/70 dark:bg-purple-950/30 border border-purple-200 dark:border-purple-900/40 rounded-xl p-4 text-xs text-purple-900 dark:text-purple-300 leading-relaxed print:hidden">
              <strong>Premiações Específicas / Prêmios Especiais:</strong> Apuração baseada estritamente nas notas dos <strong>critérios e perguntas vinculadas</strong> no cadastro da premiação, aplicando seus respectivos pesos ponderados.
            </div>

            {/* Seletor de Premiação Especial */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 print:hidden">
              <div className="flex items-center gap-2">
                <Award size={16} className="text-purple-600" />
                <span className="text-xs font-bold text-slate-800 dark:text-slate-200 whitespace-nowrap">
                  Selecionar Premiação:
                </span>
                <select
                  value={selectedAwardId || ""}
                  onChange={(e) => setSelectedAwardId(Number(e.target.value))}
                  className="px-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-semibold text-slate-900 dark:text-white focus:outline-none"
                >
                  {awards.map((aw) => (
                    <option key={aw.id} value={aw.id}>
                      {aw.name} {aw.sponsor ? `(Patrocínio: ${aw.sponsor})` : ""}
                    </option>
                  ))}
                </select>
              </div>

              <Link
                href="/awards"
                className="text-xs font-semibold text-purple-600 dark:text-purple-400 hover:underline flex items-center gap-1"
              >
                Gerenciar Premiações
                <ExternalLink size={12} />
              </Link>
            </div>

            {/* Conteúdo da Premiação Selecionada */}
            {awards.length === 0 ? (
              <Card className="p-12 text-center text-slate-500">
                <Award size={40} className="mx-auto mb-3 text-slate-400 opacity-60" />
                <p className="font-semibold text-slate-700 dark:text-slate-300">
                  Nenhuma premiação específica cadastrada nesta edição.
                </p>
                <p className="text-xs text-slate-400 mt-1 mb-4">
                  Cadastre troféus especiais na tela de Premiações para habilitar a apuração do Ranking 2.
                </p>
                <Link href="/awards">
                  <Button variant="primary" size="sm">
                    Ir para Premiações
                  </Button>
                </Link>
              </Card>
            ) : (
              <Card className="border-slate-200 dark:border-slate-800 shadow-sm">
                <CardHeader className="pb-3 border-b border-slate-200 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-800/40">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div>
                      <CardTitle className="text-base font-bold flex items-center gap-2 text-slate-900 dark:text-white">
                        <Award size={19} className="text-purple-600" />
                        {awardStandings?.award_name || "Premiação Selecionada"}
                      </CardTitle>
                      <CardDescription className="text-xs mt-0.5">
                        {awardStandings?.sponsor && (
                          <span className="text-purple-600 dark:text-purple-400 font-semibold mr-1.5">
                            Patrocínio: {awardStandings.sponsor} •
                          </span>
                        )}
                        {awardStandings?.total_competing_projects || 0} trabalho(s) concorrente(s)
                      </CardDescription>
                    </div>

                    {awardStandings && awardStandings.criteria_considered.length > 0 && (
                      <div className="text-[11px] text-slate-500 dark:text-slate-400 bg-white dark:bg-slate-900 px-2.5 py-1 rounded-lg border border-slate-200 dark:border-slate-800">
                        Critérios:{" "}
                        <strong className="text-slate-700 dark:text-slate-300">
                          {awardStandings.criteria_considered.join(", ")}
                        </strong>
                      </div>
                    )}
                  </div>
                </CardHeader>

                <CardContent className="p-0">
                  {isLoadingAward ? (
                    <div className="py-16 text-center text-sm text-slate-500 animate-pulse">
                      Calculando notas ponderadas da premiação...
                    </div>
                  ) : !awardStandings || awardStandings.standings.length === 0 ? (
                    <div className="py-16 text-center text-sm text-slate-500">
                      Nenhum trabalho elegível ou avaliado para os critérios desta premiação.
                    </div>
                  ) : (
                    <div>
                      {/* Pódio Visual da Premiação */}
                      <div className="p-4 bg-gradient-to-r from-slate-50 via-purple-50/20 to-slate-50 dark:from-slate-900 dark:via-purple-950/20 dark:to-slate-900 border-b border-slate-200 dark:border-slate-800 print:hidden">
                        <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-3">
                          Classificados ao Troféu:
                        </span>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                          {awardStandings.standings.slice(0, 3).map((pod, pIdx) => (
                            <div
                              key={pod.project_id}
                              className={`p-3 rounded-xl border flex flex-col justify-between ${
                                pIdx === 0
                                  ? "bg-amber-50/90 border-amber-300 dark:bg-amber-950/40 dark:border-amber-800 shadow-2xs"
                                  : pIdx === 1
                                  ? "bg-slate-100/90 border-slate-300 dark:bg-slate-800/60 dark:border-slate-700"
                                  : "bg-amber-50/40 border-amber-200/80 dark:bg-amber-950/20 dark:border-amber-900/60"
                              }`}
                            >
                              <div>
                                <div className="flex items-center justify-between gap-2 mb-1.5">
                                  {getRankBadge(pod.rank_position)}
                                  {pod.booth_number && (
                                    <span className="text-[11px] font-mono font-bold text-purple-600 dark:text-purple-400 bg-white dark:bg-slate-900 px-1.5 py-0.5 rounded border border-slate-200 dark:border-slate-700">
                                      Estande {pod.booth_number}
                                    </span>
                                  )}
                                </div>
                                <h4 className="text-xs font-bold text-slate-900 dark:text-white line-clamp-2 leading-snug" title={pod.title}>
                                  {pod.title}
                                </h4>
                                <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 truncate">
                                  {pod.subarea_name}
                                </p>
                              </div>

                              <div className="mt-2.5 pt-2 border-t border-black/5 dark:border-white/5 flex items-center justify-between">
                                <span className="text-[10px] text-slate-400">
                                  {pod.evaluations_count} ficha(s)
                                </span>
                                <span className="font-mono font-black text-sm text-purple-700 dark:text-purple-300">
                                  {pod.award_score.toFixed(2)} pts
                                </span>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Tabela do Prêmio */}
                      <div className="overflow-x-auto">
                        <table className="w-full text-left text-xs">
                          <thead className="text-[11px] font-bold text-slate-500 uppercase border-b border-slate-200 dark:border-slate-800 bg-slate-50/40 dark:bg-slate-900">
                            <tr>
                              <th className="py-2.5 px-4 w-36">Colocação</th>
                              <th className="py-2.5 px-4 w-24">Estande</th>
                              <th className="py-2.5 px-4">Trabalho Científico</th>
                              <th className="py-2.5 px-4">Subárea</th>
                              <th className="py-2.5 px-4">Nível</th>
                              <th className="py-2.5 px-4 text-center">Fichas</th>
                              <th className="py-2.5 px-4 text-right">Nota do Prêmio</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                            {awardStandings.standings.map((p) => (
                              <tr
                                key={p.project_id}
                                className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors"
                              >
                                <td className="py-2.5 px-4 whitespace-nowrap">
                                  {getRankBadge(p.rank_position)}
                                </td>

                                <td className="py-2.5 px-4 font-mono font-bold text-purple-600 dark:text-purple-400 whitespace-nowrap">
                                  {p.booth_number ? (
                                    <span className="bg-purple-50 dark:bg-purple-950 px-2 py-0.5 rounded border border-purple-200 dark:border-purple-900">
                                      {p.booth_number}
                                    </span>
                                  ) : (
                                    <span className="text-slate-400">—</span>
                                  )}
                                </td>

                                <td className="py-2.5 px-4">
                                  <div className="font-semibold text-slate-900 dark:text-white line-clamp-1">
                                    {p.title}
                                  </div>
                                  <div className="text-[10px] text-slate-400 font-mono">
                                    ID: #{p.project_id}
                                  </div>
                                </td>

                                <td className="py-2.5 px-4 text-slate-600 dark:text-slate-300 whitespace-nowrap">
                                  {p.subarea_name}
                                </td>

                                <td className="py-2.5 px-4 whitespace-nowrap text-slate-600 dark:text-slate-300">
                                  {p.education_level === "MEDIO"
                                    ? "Ensino Médio"
                                    : p.education_level === "FUNDAMENTAL"
                                    ? "Ensino Fundamental"
                                    : "Iniciação Júnior"}
                                </td>

                                <td className="py-2.5 px-4 text-center whitespace-nowrap font-medium text-slate-600 dark:text-slate-400">
                                  {p.evaluations_count}
                                </td>

                                <td className="py-2.5 px-4 text-right whitespace-nowrap font-mono font-bold text-sm text-purple-700 dark:text-purple-400">
                                  {p.award_score.toFixed(2)}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}
          </div>
        )}

        {/* Termo de Homologação e Assinaturas (Aparece estritamente na impressão da Ata) */}
        <div className="hidden print:block mt-12 pt-8 border-t border-slate-400 text-xs text-black">
          <p className="leading-relaxed text-justify mb-8">
            Aos {new Date().toLocaleDateString("pt-BR")}, reuniu-se a Comissão Científica e a Coordenação Geral da <strong>{activeEvent?.name}</strong> para apuração e homologação definitiva das notas atribuídas pelos avaliadores ad hoc devidamente credenciados. As notas foram processadas respeitando o cálculo oficial de Média Aritmética Simples (sem descarte de notas) e as diretrizes de Premiações Específicas Ponderadas. Nada mais havendo a constar, lavrou-se a presente Ata Oficial de Homologação de Resultados.
          </p>

          <div className="grid grid-cols-3 gap-8 text-center pt-8">
            <div className="border-t border-black pt-2">
              <p className="font-bold">Coordenador Geral</p>
              <p className="text-[10px] text-slate-600">{activeEvent?.name || "Comissão Organizadora"}</p>
            </div>
            <div className="border-t border-black pt-2">
              <p className="font-bold">Presidente da Comissão Científica</p>
              <p className="text-[10px] text-slate-600">Comissão de Avaliação</p>
            </div>
            <div className="border-t border-black pt-2">
              <p className="font-bold">Direção-Geral do Campus</p>
              <p className="text-[10px] text-slate-600">IFMS Campus Três Lagoas</p>
            </div>
          </div>
        </div>
      </div>
    </RequireActiveEvent>
  );
}

export default function ResultsPage() {
  return (
    <Suspense fallback={<div className="p-8 text-center text-slate-500">Carregando classificação oficial...</div>}>
      <ResultsContent />
    </Suspense>
  );
}
