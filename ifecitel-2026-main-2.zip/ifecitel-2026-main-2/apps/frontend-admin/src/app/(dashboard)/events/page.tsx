"use client";

import React, { useEffect, useState, useRef } from "react";
import {
  Plus,
  Calendar,
  Lock,
  CheckCircle2,
  Clock,
  AlertCircle,
  Pencil,
  Play,
  Sparkles,
  Check,
  Search,
  X,
  Tv,
  Users,
  Crown,
  Shield,
  Ticket,
  Building2,
  MapPin,
  GraduationCap,
  Sliders,
  Globe,
  Mail,
  Trash2,
  FileText,
  Layers,
  Award,
  Upload,
  Image as ImageIcon,
  Loader2
} from "lucide-react";
import { clsx } from "clsx";
import { eventService } from "../../../services/event.service";
import { EventItem, EventAdminRole, EducationLevel } from "../../../types";
import { useActiveEvent } from "../../../context/EventContext";
import { Button } from "../../../components/ui/Button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "../../../components/ui/Card";
import { Modal } from "../../../components/ui/Modal";
import { Input } from "../../../components/ui/Input";
import { Pagination } from "../../../components/ui/Pagination";
import { EventAdminsModal } from "../../../components/events/EventAdminsModal";

type ModalTab = "geral" | "identidade" | "parametros" | "niveis" | "equipe";

interface EducationLevelState {
  enabled: boolean;
  max_students: number;
  min_evaluators: number;
}

interface EventFormState {
  name: string;
  year: number;
  description: string;
  location: string;
  workload_hours: number;
  max_projects: number;
  start_date: string;
  end_date: string;
  summary_extension: string;
  banner_extension: string;
  max_file_size_mb: number;
  max_projects_per_evaluator: number;
  organizing_institution: string;
  theme: string;
  contact_email: string;
  website_url: string;
  logo_url: string;
  education_levels: {
    MEDIO: EducationLevelState;
    FUNDAMENTAL: EducationLevelState;
    JUNIOR: EducationLevelState;
    GRADUACAO: EducationLevelState;
    POS_GRADUACAO: EducationLevelState;
  };
  administrators: { email: string; role: EventAdminRole }[];
}

const defaultFormState: EventFormState = {
  name: "",
  year: new Date().getFullYear(),
  description: "",
  location: "Campus do IFMS",
  workload_hours: 40,
  max_projects: 150,
  start_date: new Date().toISOString().split("T")[0],
  end_date: new Date(Date.now() + 3 * 86400000).toISOString().split("T")[0],
  summary_extension: "pdf",
  banner_extension: "pdf",
  max_file_size_mb: 20,
  max_projects_per_evaluator: 4,
  organizing_institution: "",
  theme: "",
  contact_email: "",
  website_url: "",
  logo_url: "",
  education_levels: {
    JUNIOR: { enabled: false, max_students: 5, min_evaluators: 2 },
    FUNDAMENTAL: { enabled: true, max_students: 5, min_evaluators: 2 },
    MEDIO: { enabled: true, max_students: 4, min_evaluators: 2 },
    GRADUACAO: { enabled: false, max_students: 5, min_evaluators: 2 },
    POS_GRADUACAO: { enabled: false, max_students: 4, min_evaluators: 2 },
  },
  administrators: [],
};

function getLogoDisplayUrl(url?: string | null): string {
  if (!url) return "";
  if (url.startsWith("http://") || url.startsWith("https://") || url.startsWith("blob:") || url.startsWith("data:")) {
    return url;
  }
  const apiBase = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000/api/v1";
  const backendBase = apiBase.replace(/\/api\/v1\/?$/, "");
  return `${backendBase}${url.startsWith("/") ? "" : "/"}${url}`;
}

function buildEventPayload(f: EventFormState) {
  const levels: { level_name: EducationLevel; max_students: number; min_evaluators: number }[] = [];
  if (f.education_levels.JUNIOR.enabled) {
    levels.push({
      level_name: "JUNIOR",
      max_students: Number(f.education_levels.JUNIOR.max_students) || 5,
      min_evaluators: Number(f.education_levels.JUNIOR.min_evaluators) || 2,
    });
  }
  if (f.education_levels.FUNDAMENTAL.enabled) {
    levels.push({
      level_name: "FUNDAMENTAL",
      max_students: Number(f.education_levels.FUNDAMENTAL.max_students) || 5,
      min_evaluators: Number(f.education_levels.FUNDAMENTAL.min_evaluators) || 2,
    });
  }
  if (f.education_levels.MEDIO.enabled) {
    levels.push({
      level_name: "MEDIO",
      max_students: Number(f.education_levels.MEDIO.max_students) || 4,
      min_evaluators: Number(f.education_levels.MEDIO.min_evaluators) || 2,
    });
  }
  if (f.education_levels.GRADUACAO.enabled) {
    levels.push({
      level_name: "GRADUACAO",
      max_students: Number(f.education_levels.GRADUACAO.max_students) || 5,
      min_evaluators: Number(f.education_levels.GRADUACAO.min_evaluators) || 2,
    });
  }
  if (f.education_levels.POS_GRADUACAO.enabled) {
    levels.push({
      level_name: "POS_GRADUACAO",
      max_students: Number(f.education_levels.POS_GRADUACAO.max_students) || 4,
      min_evaluators: Number(f.education_levels.POS_GRADUACAO.min_evaluators) || 2,
    });
  }

  return {
    name: f.name.trim(),
    year: Number(f.year),
    description: f.description.trim() || undefined,
    location: f.location.trim() || "Campus do IFMS",
    workload_hours: Number(f.workload_hours) || 40,
    max_projects: Number(f.max_projects) || 150,
    start_date: f.start_date,
    end_date: f.end_date,
    summary_extension: f.summary_extension.trim() || "pdf",
    banner_extension: f.banner_extension.trim() || "pdf",
    max_file_size_mb: Number(f.max_file_size_mb) || 20,
    max_projects_per_evaluator: Number(f.max_projects_per_evaluator) || 4,
    organizing_institution: f.organizing_institution.trim() || undefined,
    theme: f.theme.trim() || undefined,
    contact_email: f.contact_email.trim() || undefined,
    website_url: f.website_url.trim() || undefined,
    logo_url: f.logo_url.trim() || undefined,
    education_levels: levels,
    administrators: f.administrators.length > 0 ? f.administrators : undefined,
  };
}

export default function EventsPage() {
  const { activeEvent, setActiveEvent, clearActiveEvent } = useActiveEvent();
  const [events, setEvents] = useState<EventItem[]>([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalEvents, setTotalEvents] = useState(0);
  const [searchQuery, setSearchQuery] = useState("");
  const [isLoading, setIsLoading] = useState(true);

  // Modais de Criação e Edição
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [modalError, setModalError] = useState<string | null>(null);
  const [editModalError, setEditModalError] = useState<string | null>(null);
  const [notification, setNotification] = useState<{ type: "success" | "error"; text: string } | null>(null);
  const [targetEditEvent, setTargetEditEvent] = useState<EventItem | null>(null);
  const [selectedTeamEvent, setSelectedTeamEvent] = useState<EventItem | null>(null);

  // Abas dos Formulários
  const [createTab, setCreateTab] = useState<ModalTab>("geral");
  const [editTab, setEditTab] = useState<ModalTab>("geral");

  // Estado dos formulários
  const [form, setForm] = useState<EventFormState>(defaultFormState);
  const [editForm, setEditForm] = useState<EventFormState>(defaultFormState);

  // Inputs temporários para equipe
  const [createAdminEmail, setCreateAdminEmail] = useState("");
  const [createAdminRole, setCreateAdminRole] = useState<EventAdminRole>("ORGANIZER");
  const [editAdminEmail, setEditAdminEmail] = useState("");
  const [editAdminRole, setEditAdminRole] = useState<EventAdminRole>("ORGANIZER");

  // Upload de Logotipo
  const [isUploadingCreateLogo, setIsUploadingCreateLogo] = useState(false);
  const [isUploadingEditLogo, setIsUploadingEditLogo] = useState(false);
  const createLogoInputRef = useRef<HTMLInputElement>(null);
  const editLogoInputRef = useRef<HTMLInputElement>(null);

  const handleUploadLogo = async (file: File, isEdit: boolean) => {
    const ext = file.name.split(".").pop()?.toLowerCase();
    if (!ext || !["png", "jpg", "jpeg"].includes(ext)) {
      const msg = "Formato de arquivo inválido. Selecione apenas imagens PNG ou JPG/JPEG.";
      if (isEdit) setEditModalError(msg);
      else setModalError(msg);
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      const msg = "O arquivo excede o limite máximo permitido de 5MB.";
      if (isEdit) setEditModalError(msg);
      else setModalError(msg);
      return;
    }

    if (isEdit) {
      setIsUploadingEditLogo(true);
      setEditModalError(null);
    } else {
      setIsUploadingCreateLogo(true);
      setModalError(null);
    }

    try {
      const res = await eventService.uploadTempLogo(file);
      if (isEdit) {
        setEditForm((prev) => ({ ...prev, logo_url: res.logo_url }));
      } else {
        setForm((prev) => ({ ...prev, logo_url: res.logo_url }));
      }
    } catch (err: any) {
      const msg = err.response?.data?.detail || "Erro ao realizar upload do logotipo.";
      if (isEdit) setEditModalError(msg);
      else setModalError(msg);
    } finally {
      if (isEdit) setIsUploadingEditLogo(false);
      else setIsUploadingCreateLogo(false);
    }
  };

  const isInitialMount = useRef(true);

  const openModal = () => {
    setForm(defaultFormState);
    setCreateTab("geral");
    setCreateAdminEmail("");
    setCreateAdminRole("ORGANIZER");
    setModalError(null);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setModalError(null);
    setIsModalOpen(false);
  };

  async function loadEvents(page = 1, search = searchQuery) {
    setIsLoading(true);
    setError(null);
    try {
      const data = await eventService.getPaginatedEvents(page, 15, search);
      setEvents(data.items);
      setTotalEvents(data.total);
      setTotalPages(data.total_pages);
      setCurrentPage(data.page);

      if (data.total === 0 && activeEvent) {
        clearActiveEvent();
      }
    } catch (err: any) {
      setError(
        err.response?.data?.detail || "Erro ao carregar edições de eventos cadastrados."
      );
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    if (isInitialMount.current) {
      isInitialMount.current = false;
      loadEvents(1, "");
      return;
    }
    const timer = setTimeout(() => {
      setCurrentPage(1);
      loadEvents(1, searchQuery);
    }, 300);
    return () => clearTimeout(timer);
  }, [searchQuery]);

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    loadEvents(page, searchQuery);
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setModalError(null);
    try {
      const payload = buildEventPayload(form);
      await eventService.createEvent(payload);
      closeModal();
      setForm(defaultFormState);
      setNotification({
        type: "success",
        text: `Edição "${payload.name}" cadastrada com sucesso!`,
      });
      await loadEvents(1);
    } catch (err: any) {
      setModalError(err.response?.data?.detail || "Erro ao cadastrar edição do evento.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSelectEvent = (event: EventItem) => {
    setActiveEvent(event);
    setNotification({
      type: "success",
      text: `Edição "${event.name}" (${event.year}) selecionada! Agora ativa em todas as páginas do sistema.`,
    });
  };

  const openEditModal = (event: EventItem) => {
    setTargetEditEvent(event);
    const levelsMap = {
      JUNIOR: { enabled: false, max_students: 5, min_evaluators: 2 },
      FUNDAMENTAL: { enabled: false, max_students: 5, min_evaluators: 2 },
      MEDIO: { enabled: false, max_students: 4, min_evaluators: 2 },
      GRADUACAO: { enabled: false, max_students: 5, min_evaluators: 2 },
      POS_GRADUACAO: { enabled: false, max_students: 4, min_evaluators: 2 },
    };

    if (event.education_levels && event.education_levels.length > 0) {
      for (const el of event.education_levels) {
        if (el.level_name in levelsMap) {
          levelsMap[el.level_name as keyof typeof levelsMap] = {
            enabled: true,
            max_students: el.max_students,
            min_evaluators: el.min_evaluators,
          };
        }
      }
    } else {
      levelsMap.MEDIO.enabled = true;
      levelsMap.FUNDAMENTAL.enabled = true;
    }

    const adminsList = (event.administrators || [])
      .filter((a) => !a.is_owner && a.person_id !== event.owner_id)
      .map((a) => ({ email: a.email, role: a.role as EventAdminRole }));

    setEditForm({
      name: event.name,
      year: event.year,
      description: event.description || "",
      location: event.location || "Campus do IFMS",
      workload_hours: event.workload_hours ?? 40,
      max_projects: event.max_projects ?? 150,
      start_date: event.start_date,
      end_date: event.end_date,
      summary_extension: event.summary_extension || "pdf",
      banner_extension: event.banner_extension || "pdf",
      max_file_size_mb: event.max_file_size_mb ?? 20,
      max_projects_per_evaluator: event.max_projects_per_evaluator ?? 4,
      organizing_institution: event.organizing_institution || "",
      theme: event.theme || "",
      contact_email: event.contact_email || "",
      website_url: event.website_url || "",
      logo_url: event.logo_url || "",
      education_levels: levelsMap,
      administrators: adminsList,
    });
    setEditTab("geral");
    setEditAdminEmail("");
    setEditAdminRole("ORGANIZER");
    setEditModalError(null);
    setIsEditModalOpen(true);
  };

  const closeEditModal = () => {
    setTargetEditEvent(null);
    setEditModalError(null);
    setIsEditModalOpen(false);
  };

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetEditEvent) return;

    setIsSubmitting(true);
    setEditModalError(null);
    try {
      const payload = buildEventPayload(editForm);
      const updated = await eventService.updateEvent(targetEditEvent.id, payload);
      if (activeEvent?.id === updated.id) {
        setActiveEvent(updated);
      }
      setNotification({
        type: "success",
        text: `Edição "${updated.name}" atualizada com sucesso!`,
      });
      closeEditModal();
      await loadEvents(currentPage);
    } catch (err: any) {
      setEditModalError(err.response?.data?.detail || "Erro ao atualizar parâmetros da edição.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const isEventClosed = (endDateStr: string) => {
    const today = new Date().toISOString().split("T")[0];
    return endDateStr < today;
  };

  const addAdminToForm = (isEdit: boolean) => {
    const email = (isEdit ? editAdminEmail : createAdminEmail).trim().toLowerCase();
    const role = isEdit ? editAdminRole : createAdminRole;

    if (!email || !email.includes("@")) {
      const err = "Informe um endereço de e-mail válido para o gestor.";
      if (isEdit) setEditModalError(err);
      else setModalError(err);
      return;
    }

    const currentList = isEdit ? editForm.administrators : form.administrators;
    if (currentList.some((a) => a.email.toLowerCase() === email)) {
      const err = "Este gestor já foi adicionado à lista.";
      if (isEdit) setEditModalError(err);
      else setModalError(err);
      return;
    }

    if (isEdit) {
      setEditForm({
        ...editForm,
        administrators: [...editForm.administrators, { email, role }],
      });
      setEditAdminEmail("");
      setEditModalError(null);
    } else {
      setForm({
        ...form,
        administrators: [...form.administrators, { email, role }],
      });
      setCreateAdminEmail("");
      setModalError(null);
    }
  };

  const removeAdminFromForm = (email: string, isEdit: boolean) => {
    if (isEdit) {
      setEditForm({
        ...editForm,
        administrators: editForm.administrators.filter((a) => a.email !== email),
      });
    } else {
      setForm({
        ...form,
        administrators: form.administrators.filter((a) => a.email !== email),
      });
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white flex items-center gap-2.5">
            <Calendar className="text-blue-600 dark:text-blue-400" size={26} />
            Edições do Evento
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            Gestão de feiras, níveis de ensino e cotas de participantes, comissão gestora e encerramento de edições.
          </p>
        </div>

        <Button
          onClick={openModal}
          variant="primary"
          className="self-start sm:self-auto"
        >
          <Plus size={16} />
          <span>Nova Edição</span>
        </Button>
      </div>

      {/* Active Event Banner (BR-19, BR-20) */}
      {activeEvent && (
        <div className="p-4 rounded-2xl bg-gradient-to-r from-blue-50 via-indigo-50/50 to-transparent dark:from-blue-950/40 dark:via-indigo-950/20 dark:to-transparent border border-blue-200 dark:border-blue-900/60 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center flex-shrink-0 shadow-sm">
              <Sparkles size={20} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold uppercase tracking-wider text-blue-700 dark:text-blue-400">
                  Edição Ativa no Painel
                </span>
                <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-bold bg-blue-200/80 dark:bg-blue-900/60 text-blue-800 dark:text-blue-200">
                  Ano {activeEvent.year}
                </span>
                <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-black bg-amber-100 dark:bg-amber-950/70 text-amber-800 dark:text-amber-300 border border-amber-300 dark:border-amber-800/80">
                  ID: #{activeEvent.id}
                </span>
              </div>
              <p className="text-base font-semibold text-slate-900 dark:text-white mt-0.5">
                {activeEvent.name}
              </p>
              {activeEvent.theme && (
                <p className="text-xs text-indigo-700 dark:text-indigo-300 italic mt-0.5">
                  &ldquo;{activeEvent.theme}&rdquo;
                </p>
              )}
            </div>
          </div>
          <div className="flex items-center gap-3 sm:text-right">
            <a
              href={`http://localhost:3003/?event_id=${activeEvent.id}`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white text-xs font-bold transition-all shadow-sm active:scale-95"
            >
              <Tv size={14} />
              <span>Ver no Telão TV</span>
            </a>
          </div>
        </div>
      )}

      {/* Notifications */}
      {notification && (
        <div
          className={clsx(
            "p-4 rounded-xl text-sm flex items-center justify-between border",
            notification.type === "success"
              ? "bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300"
              : "bg-rose-50 dark:bg-rose-950/40 border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-300"
          )}
        >
          <div className="flex items-center gap-2">
            {notification.type === "success" ? (
              <CheckCircle2 size={18} className="text-emerald-600 dark:text-emerald-400" />
            ) : (
              <AlertCircle size={18} className="text-rose-600 dark:text-rose-400" />
            )}
            <span>{notification.text}</span>
          </div>
          <button
            onClick={() => setNotification(null)}
            className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 text-xs font-semibold"
          >
            Fechar
          </button>
        </div>
      )}

      {/* Search Input */}
      <div className="relative max-w-md">
        <Search
          size={16}
          className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none"
        />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Buscar edição por nome da feira..."
          className="w-full pl-9 pr-9 py-2 text-sm rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors"
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery("")}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
          >
            <X size={15} />
          </button>
        )}
      </div>

      {/* Main Content */}
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map((i) => (
            <div
              key={i}
              className="h-64 rounded-2xl bg-slate-100 dark:bg-slate-800/40 animate-pulse border border-slate-200 dark:border-slate-800"
            />
          ))}
        </div>
      ) : error ? (
        <div className="p-6 rounded-2xl bg-rose-50 dark:bg-rose-950/20 border border-rose-200 dark:border-rose-900/50 text-rose-800 dark:text-rose-300 text-sm">
          {error}
        </div>
      ) : events.length === 0 ? (
        <div className="text-center py-16 px-4 rounded-2xl border-2 border-dashed border-slate-200 dark:border-slate-800">
          <div className="w-12 h-12 rounded-2xl bg-blue-50 dark:bg-blue-950 text-blue-600 dark:text-blue-400 flex items-center justify-center mx-auto mb-3">
            <Calendar size={24} />
          </div>
          <h3 className="text-base font-semibold text-slate-900 dark:text-white">
            Nenhuma edição encontrada
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-sm mx-auto">
            {searchQuery
              ? `Não foram encontradas edições com o termo "${searchQuery}".`
              : "Cadastre uma nova edição da feira científica para iniciar as operações."}
          </p>
          <Button onClick={openModal} variant="primary" size="sm" className="mt-4">
            <Plus size={15} />
            <span>Criar Primeira Edição</span>
          </Button>
        </div>
      ) : (
        <>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {events.map((event) => {
            const isSelected = activeEvent?.id === event.id;
            const closed = isEventClosed(event.end_date);

            return (
              <Card
                key={event.id}
                className={clsx(
                  "relative overflow-hidden flex flex-col justify-between transition-all duration-200",
                  isSelected
                    ? "ring-2 ring-blue-500 shadow-md border-blue-300 dark:border-blue-700 bg-blue-50/20 dark:bg-blue-950/10"
                    : "hover:border-slate-300 dark:hover:border-slate-700"
                )}
              >
                <CardHeader>
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-3 min-w-0">
                      {event.logo_url && (
                        <img
                          src={getLogoDisplayUrl(event.logo_url)}
                          alt={`Logo ${event.name}`}
                          className="w-11 h-11 object-contain rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-1 flex-shrink-0 mt-0.5"
                        />
                      )}
                      <div className="min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-xs font-bold text-blue-600 dark:text-blue-400 uppercase tracking-wider">
                          Ano {event.year}
                        </span>
                        <span className="text-[11px] font-black px-1.5 py-0.5 rounded bg-amber-100 dark:bg-amber-950/70 text-amber-800 dark:text-amber-300 border border-amber-300 dark:border-amber-800/80">
                          ID: #{event.id}
                        </span>
                        {event.is_owner || event.user_role === "COORDINATOR" ? (
                          <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-amber-50 text-amber-700 dark:bg-amber-950/50 dark:text-amber-300 border border-amber-200 dark:border-amber-800 flex items-center gap-1">
                            <Crown size={11} className="text-amber-500" />
                            Coordenador Geral
                          </span>
                        ) : event.user_role === "ORGANIZER" ? (
                          <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 dark:bg-blue-950/50 dark:text-blue-300 border border-blue-200 dark:border-blue-800 flex items-center gap-1">
                            <Shield size={11} className="text-blue-500" />
                            Comissão
                          </span>
                        ) : event.user_role === "OPERATOR" ? (
                          <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-teal-50 text-teal-700 dark:bg-teal-950/50 dark:text-teal-300 border border-teal-200 dark:border-teal-800 flex items-center gap-1">
                            <Ticket size={11} className="text-teal-500" />
                            Apoio
                          </span>
                        ) : null}
                      </div>
                      <CardTitle className="text-lg mt-1 font-bold text-slate-900 dark:text-white leading-snug">
                        {event.name}
                      </CardTitle>
                      {event.theme && (
                        <p className="text-xs font-medium text-indigo-600 dark:text-indigo-400 mt-1 italic">
                          &ldquo;{event.theme}&rdquo;
                        </p>
                      )}
                    </div>
                  </div>

                    {closed ? (
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-red-50 dark:bg-red-950 text-red-700 dark:text-red-300 border border-red-200 dark:border-red-900 flex-shrink-0">
                        <Lock size={12} />
                        Encerrado
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-900 flex-shrink-0">
                        <CheckCircle2 size={12} />
                        Ativo
                      </span>
                    )}
                  </div>

                  <CardDescription className="space-y-1.5 mt-2.5">
                    {event.organizing_institution && (
                      <div className="flex items-center gap-1.5 text-xs text-slate-600 dark:text-slate-300">
                        <Building2 size={13} className="text-slate-400 flex-shrink-0" />
                        <span className="truncate">{event.organizing_institution}</span>
                      </div>
                    )}
                    <div className="flex items-center gap-1.5 text-xs text-slate-600 dark:text-slate-300">
                      <MapPin size={13} className="text-slate-400 flex-shrink-0" />
                      <span className="truncate">{event.location || "Campus do IFMS"}</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400">
                      <Clock size={13} className="text-slate-400 flex-shrink-0" />
                      <span>{event.start_date} até {event.end_date}</span>
                    </div>
                  </CardDescription>
                </CardHeader>

                <CardContent className="pt-2 space-y-3">
                  {/* Níveis de ensino configurados */}
                  {event.education_levels && event.education_levels.length > 0 && (
                    <div className="flex flex-wrap gap-1.5">
                      {event.education_levels.map((el) => (
                        <span
                          key={el.id || el.level_name}
                          className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700"
                        >
                          <GraduationCap size={10} className="text-blue-500" />
                          {el.level_name === "MEDIO"
                            ? "Médio"
                            : el.level_name === "FUNDAMENTAL"
                            ? "Fundamental II"
                            : el.level_name === "JUNIOR"
                            ? "Fundamental I"
                            : el.level_name === "GRADUACAO"
                            ? "Graduação"
                            : "Pós-Graduação"}
                          <span className="text-slate-400">({el.max_students} alunos)</span>
                        </span>
                      ))}
                    </div>
                  )}

                  {/* Parâmetros técnicos */}
                  <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl space-y-1.5 text-xs text-slate-600 dark:text-slate-300">
                    <div className="flex justify-between">
                      <span className="text-slate-400">Carga Horária:</span>
                      <span className="font-semibold text-slate-900 dark:text-white">
                        {event.workload_hours ?? 40} horas certificadas
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Teto por avaliador:</span>
                      <span className="font-semibold text-slate-900 dark:text-white">
                        {event.max_projects_per_evaluator} trabalhos
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Limite de anexo:</span>
                      <span className="font-semibold text-slate-900 dark:text-white">
                        {event.max_file_size_mb} MB (PDF)
                      </span>
                    </div>
                  </div>

                  {closed && (
                    <div className="p-2 rounded-lg bg-amber-50 dark:bg-amber-950/40 text-amber-800 dark:text-amber-300 text-[11px] flex items-center gap-1.5">
                      <Lock size={12} className="flex-shrink-0" />
                      <span>Edição arquivada para modificações: os dados estão em modo somente leitura.</span>
                    </div>
                  )}

                  {/* Actions */}
                  <div className="pt-3 border-t border-slate-100 dark:border-slate-800/80 flex items-center gap-2">
                    <Button
                      type="button"
                      variant={isSelected ? "secondary" : "primary"}
                      size="sm"
                      className={clsx(
                        "flex-1 text-xs",
                        isSelected && "bg-blue-100 text-blue-800 dark:bg-blue-900/60 dark:text-blue-200 border border-blue-300 dark:border-blue-700 font-bold"
                      )}
                      onClick={() => handleSelectEvent(event)}
                    >
                      {isSelected ? (
                        <>
                          <Check size={14} className="mr-1.5 text-blue-600 dark:text-blue-400" />
                          Edição Selecionada
                        </>
                      ) : (
                        <>
                          <Play size={14} className="mr-1.5" />
                          Ativar Edição
                        </>
                      )}
                    </Button>

                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      disabled={closed}
                      onClick={() => openEditModal(event)}
                      title={closed ? "Edição encerrada (somente leitura)" : "Editar parâmetros da edição"}
                    >
                      <Pencil size={14} />
                    </Button>

                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => setSelectedTeamEvent(event)}
                      title="Gerenciar Equipe e Níveis de Acesso"
                      className="text-slate-600 dark:text-slate-300"
                    >
                      <Users size={14} />
                    </Button>

                    <a
                      href={`http://localhost:3003/?event_id=${event.id}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-2 rounded-xl border border-slate-200 dark:border-slate-700 text-teal-600 dark:text-teal-400 hover:bg-teal-50 dark:hover:bg-teal-950/40 transition-colors flex items-center justify-center"
                      title="Abrir Telão TV desta edição"
                    >
                      <Tv size={15} />
                    </a>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {totalEvents > 0 && (
          <Pagination
            currentPage={currentPage}
            totalPages={totalPages}
            totalItems={totalEvents}
            limit={15}
            onPageChange={handlePageChange}
            isLoading={isLoading}
          />
        )}
        </>
      )}

      {/* Modal de Criação */}
      <Modal
        isOpen={isModalOpen}
        onClose={closeModal}
        error={modalError}
        maxWidth="max-w-3xl"
        title="Cadastrar Nova Edição do Evento"
      >
        <form onSubmit={handleCreate} className="space-y-4">
          {/* Tabs Navigation */}
          <div className="flex border-b border-slate-200 dark:border-slate-800 pb-1 mb-4 overflow-x-auto gap-1">
            {[
              { id: "geral", label: "Geral & Período", icon: Calendar },
              { id: "identidade", label: "Identidade & Contato", icon: Building2 },
              { id: "parametros", label: "Parâmetros & Anexos", icon: Sliders },
              { id: "niveis", label: "Níveis de Ensino & Cotas", icon: GraduationCap },
              { id: "equipe", label: "Equipe Gestora", icon: Users },
            ].map((tab) => {
              const Icon = tab.icon;
              const isActive = createTab === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setCreateTab(tab.id as ModalTab)}
                  className={clsx(
                    "px-3 py-2 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap",
                    isActive
                      ? "bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300"
                      : "text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
                  )}
                >
                  <Icon size={14} />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

          {/* Aba 1: Geral & Período */}
          {createTab === "geral" && (
            <div className="space-y-3">
              <Input
                label="Nome da Edição *"
                required
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="Ex: FECITEL 2026 — Edição Presencial"
              />

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <Input
                  label="Ano *"
                  type="number"
                  required
                  value={form.year.toString()}
                  onChange={(e) => setForm({ ...form, year: Number(e.target.value) })}
                />
                <Input
                  label="Início *"
                  type="date"
                  required
                  value={form.start_date}
                  onChange={(e) => setForm({ ...form, start_date: e.target.value })}
                />
                <Input
                  label="Término *"
                  type="date"
                  required
                  value={form.end_date}
                  onChange={(e) => setForm({ ...form, end_date: e.target.value })}
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <Input
                  label="Local do Evento *"
                  required
                  value={form.location}
                  onChange={(e) => setForm({ ...form, location: e.target.value })}
                  placeholder="Ex: Campus do IFMS"
                />
                <Input
                  label="Carga Horária (horas) *"
                  type="number"
                  required
                  value={form.workload_hours.toString()}
                  onChange={(e) => setForm({ ...form, workload_hours: Number(e.target.value) })}
                  helperText="Carga total do certificado (padrão: 40h)"
                />
                <Input
                  label="Limite de Projetos *"
                  type="number"
                  required
                  value={form.max_projects.toString()}
                  onChange={(e) => setForm({ ...form, max_projects: Number(e.target.value) })}
                  helperText="Capacidade total de stands (padrão: 150)"
                />
              </div>
            </div>
          )}

          {/* Aba 2: Identidade & Contato */}
          {createTab === "identidade" && (
            <div className="space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <Input
                  label="Instituição Organizadora"
                  value={form.organizing_institution}
                  onChange={(e) => setForm({ ...form, organizing_institution: e.target.value })}
                  placeholder="Ex: Instituto Federal de Mato Grosso do Sul"
                />
                <Input
                  label="Tema Oficial da Edição"
                  value={form.theme}
                  onChange={(e) => setForm({ ...form, theme: e.target.value })}
                  placeholder="Ex: Inteligência Artificial e Sustentabilidade"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <Input
                  label="E-mail de Contato"
                  type="email"
                  value={form.contact_email}
                  onChange={(e) => setForm({ ...form, contact_email: e.target.value })}
                  placeholder="Ex: fecitel@ifms.edu.br"
                />
                <Input
                  label="Website Oficial"
                  type="url"
                  value={form.website_url}
                  onChange={(e) => setForm({ ...form, website_url: e.target.value })}
                  placeholder="Ex: https://fecitel.ifms.edu.br"
                />
              </div>

              {/* Upload de Logotipo do Evento (PNG ou JPG) */}
              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Logotipo Oficial da Edição (PNG ou JPG/JPEG)
                </label>
                <input
                  type="file"
                  ref={createLogoInputRef}
                  accept=".png,.jpg,.jpeg,image/png,image/jpeg"
                  className="hidden"
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (f) handleUploadLogo(f, false);
                    e.target.value = "";
                  }}
                />
                {form.logo_url ? (
                  <div className="flex items-center gap-3.5 p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-900/50">
                    <div className="w-16 h-16 rounded-lg border border-slate-200 dark:border-slate-700 bg-white p-1 flex items-center justify-center overflow-hidden flex-shrink-0">
                      <img
                        src={getLogoDisplayUrl(form.logo_url)}
                        alt="Logotipo da Edição"
                        className="w-full h-full object-contain"
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                        Logotipo Carregado com Sucesso
                      </p>
                      <p className="text-[11px] text-slate-400 font-mono truncate mt-0.5">
                        {form.logo_url}
                      </p>
                      <div className="flex items-center gap-2 mt-2">
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => createLogoInputRef.current?.click()}
                          disabled={isUploadingCreateLogo}
                          className="text-[11px] h-7 px-2.5"
                        >
                          {isUploadingCreateLogo ? (
                            <Loader2 size={12} className="animate-spin mr-1 text-blue-600" />
                          ) : (
                            <Upload size={12} className="mr-1" />
                          )}
                          Substituir Imagem
                        </Button>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => setForm({ ...form, logo_url: "" })}
                          className="text-[11px] h-7 px-2 text-rose-600 hover:text-rose-700 hover:bg-rose-50 dark:hover:bg-rose-950/40"
                        >
                          <Trash2 size={12} className="mr-1" />
                          Remover
                        </Button>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div
                    onClick={() => !isUploadingCreateLogo && createLogoInputRef.current?.click()}
                    className="border-2 border-dashed border-slate-200 dark:border-slate-800 hover:border-blue-500 dark:hover:border-blue-500 rounded-xl p-4 text-center cursor-pointer transition-colors bg-white dark:bg-slate-900/30 group"
                  >
                    {isUploadingCreateLogo ? (
                      <div className="flex flex-col items-center justify-center py-2">
                        <Loader2 size={24} className="animate-spin text-blue-600 mb-1.5" />
                        <span className="text-xs font-medium text-slate-600 dark:text-slate-400">
                          Enviando imagem para o servidor...
                        </span>
                      </div>
                    ) : (
                      <div className="flex flex-col items-center justify-center py-1">
                        <div className="w-10 h-10 rounded-full bg-blue-50 dark:bg-blue-950/50 text-blue-600 dark:text-blue-400 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
                          <Upload size={18} />
                        </div>
                        <p className="text-xs font-semibold text-slate-700 dark:text-slate-200">
                          Clique para selecionar o logotipo da feira
                        </p>
                        <p className="text-[11px] text-slate-400 mt-0.5">
                          Formatos suportados: <strong>PNG</strong> ou <strong>JPG/JPEG</strong> (tamanho máx. 5MB)
                        </p>
                      </div>
                    )}
                  </div>
                )}
              </div>

              <div className="space-y-1">
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Descrição Detalhada do Evento (Opcional)
                </label>
                <textarea
                  rows={3}
                  value={form.description}
                  onChange={(e) => setForm({ ...form, description: e.target.value })}
                  placeholder="Informações adicionais, objetivos da edição e regulamento da feira..."
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
          )}

          {/* Aba 3: Parâmetros & Anexos */}
          {createTab === "parametros" && (
            <div className="space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <Input
                  label="Extensão do Resumo *"
                  value={form.summary_extension}
                  onChange={(e) => setForm({ ...form, summary_extension: e.target.value })}
                  helperText="Padrão: pdf"
                />
                <Input
                  label="Extensão do Banner *"
                  value={form.banner_extension}
                  onChange={(e) => setForm({ ...form, banner_extension: e.target.value })}
                  helperText="Padrão: pdf"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <Input
                  label="Limite de Tamanho do Arquivo (MB) *"
                  type="number"
                  value={form.max_file_size_mb.toString()}
                  onChange={(e) => setForm({ ...form, max_file_size_mb: Number(e.target.value) })}
                  helperText="Tamanho máximo por anexo (padrão: 20MB)"
                />
                <Input
                  label="Teto por Avaliador *"
                  type="number"
                  value={form.max_projects_per_evaluator.toString()}
                  onChange={(e) => setForm({ ...form, max_projects_per_evaluator: Number(e.target.value) })}
                  helperText="Carga de projetos por avaliador (padrão: 4)"
                />
              </div>
            </div>
          )}

          {/* Aba 4: Níveis de Ensino & Cotas */}
          {createTab === "niveis" && (
            <div className="space-y-3">
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Selecione os níveis de ensino aceitos nesta feira e configure as cotas máximas de estudantes por projeto e mínimo de avaliadores exigidos.
              </p>

              {/* Nível Fundamental I */}
              <div className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 space-y-2">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={form.education_levels.JUNIOR.enabled}
                    onChange={(e) =>
                      setForm({
                        ...form,
                        education_levels: {
                          ...form.education_levels,
                          JUNIOR: { ...form.education_levels.JUNIOR, enabled: e.target.checked },
                        },
                      })
                    }
                    className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 border-slate-300 dark:border-slate-700"
                  />
                  <span className="text-xs font-bold text-slate-900 dark:text-white">
                    Ensino Fundamental I (1º ao 5º ano)
                  </span>
                </label>

                {form.education_levels.JUNIOR.enabled && (
                  <div className="grid grid-cols-2 gap-3 pt-2">
                    <Input
                      label="Máximo de Alunos por Projeto"
                      type="number"
                      value={form.education_levels.JUNIOR.max_students.toString()}
                      onChange={(e) =>
                        setForm({
                          ...form,
                          education_levels: {
                            ...form.education_levels,
                            JUNIOR: { ...form.education_levels.JUNIOR, max_students: Number(e.target.value) },
                          },
                        })
                      }
                      helperText="Padrão: 5 alunos"
                    />
                    <Input
                      label="Mínimo de Avaliadores"
                      type="number"
                      value={form.education_levels.JUNIOR.min_evaluators.toString()}
                      onChange={(e) =>
                        setForm({
                          ...form,
                          education_levels: {
                            ...form.education_levels,
                            JUNIOR: { ...form.education_levels.JUNIOR, min_evaluators: Number(e.target.value) },
                          },
                        })
                      }
                      helperText="Padrão: 2 avaliadores"
                    />
                  </div>
                )}
              </div>

              {/* Nível Fundamental II */}
              <div className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 space-y-2">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={form.education_levels.FUNDAMENTAL.enabled}
                    onChange={(e) =>
                      setForm({
                        ...form,
                        education_levels: {
                          ...form.education_levels,
                          FUNDAMENTAL: { ...form.education_levels.FUNDAMENTAL, enabled: e.target.checked },
                        },
                      })
                    }
                    className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 border-slate-300 dark:border-slate-700"
                  />
                  <span className="text-xs font-bold text-slate-900 dark:text-white">
                    Ensino Fundamental II (6º ao 9º ano)
                  </span>
                </label>

                {form.education_levels.FUNDAMENTAL.enabled && (
                  <div className="grid grid-cols-2 gap-3 pt-2">
                    <Input
                      label="Máximo de Alunos por Projeto"
                      type="number"
                      value={form.education_levels.FUNDAMENTAL.max_students.toString()}
                      onChange={(e) =>
                        setForm({
                          ...form,
                          education_levels: {
                            ...form.education_levels,
                            FUNDAMENTAL: { ...form.education_levels.FUNDAMENTAL, max_students: Number(e.target.value) },
                          },
                        })
                      }
                      helperText="Padrão: 5 alunos"
                    />
                    <Input
                      label="Mínimo de Avaliadores"
                      type="number"
                      value={form.education_levels.FUNDAMENTAL.min_evaluators.toString()}
                      onChange={(e) =>
                        setForm({
                          ...form,
                          education_levels: {
                            ...form.education_levels,
                            FUNDAMENTAL: { ...form.education_levels.FUNDAMENTAL, min_evaluators: Number(e.target.value) },
                          },
                        })
                      }
                      helperText="Padrão: 2 avaliadores"
                    />
                  </div>
                )}
              </div>

              {/* Nível Médio / Técnico */}
              <div className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 space-y-2">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={form.education_levels.MEDIO.enabled}
                    onChange={(e) =>
                      setForm({
                        ...form,
                        education_levels: {
                          ...form.education_levels,
                          MEDIO: { ...form.education_levels.MEDIO, enabled: e.target.checked },
                        },
                      })
                    }
                    className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 border-slate-300 dark:border-slate-700"
                  />
                  <span className="text-xs font-bold text-slate-900 dark:text-white">
                    Ensino Médio / Técnico
                  </span>
                </label>

                {form.education_levels.MEDIO.enabled && (
                  <div className="grid grid-cols-2 gap-3 pt-2">
                    <Input
                      label="Máximo de Alunos por Projeto"
                      type="number"
                      value={form.education_levels.MEDIO.max_students.toString()}
                      onChange={(e) =>
                        setForm({
                          ...form,
                          education_levels: {
                            ...form.education_levels,
                            MEDIO: { ...form.education_levels.MEDIO, max_students: Number(e.target.value) },
                          },
                        })
                      }
                      helperText="Padrão: 4 alunos"
                    />
                    <Input
                      label="Mínimo de Avaliadores"
                      type="number"
                      value={form.education_levels.MEDIO.min_evaluators.toString()}
                      onChange={(e) =>
                        setForm({
                          ...form,
                          education_levels: {
                            ...form.education_levels,
                            MEDIO: { ...form.education_levels.MEDIO, min_evaluators: Number(e.target.value) },
                          },
                        })
                      }
                      helperText="Padrão: 2 avaliadores"
                    />
                  </div>
                )}
              </div>

              {/* Nível Graduação */}
              <div className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 space-y-2">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={form.education_levels.GRADUACAO.enabled}
                    onChange={(e) =>
                      setForm({
                        ...form,
                        education_levels: {
                          ...form.education_levels,
                          GRADUACAO: { ...form.education_levels.GRADUACAO, enabled: e.target.checked },
                        },
                      })
                    }
                    className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 border-slate-300 dark:border-slate-700"
                  />
                  <span className="text-xs font-bold text-slate-900 dark:text-white">
                    Graduação / Ensino Superior
                  </span>
                </label>

                {form.education_levels.GRADUACAO.enabled && (
                  <div className="grid grid-cols-2 gap-3 pt-2">
                    <Input
                      label="Máximo de Alunos por Projeto"
                      type="number"
                      value={form.education_levels.GRADUACAO.max_students.toString()}
                      onChange={(e) =>
                        setForm({
                          ...form,
                          education_levels: {
                            ...form.education_levels,
                            GRADUACAO: { ...form.education_levels.GRADUACAO, max_students: Number(e.target.value) },
                          },
                        })
                      }
                      helperText="Padrão: 5 alunos"
                    />
                    <Input
                      label="Mínimo de Avaliadores"
                      type="number"
                      value={form.education_levels.GRADUACAO.min_evaluators.toString()}
                      onChange={(e) =>
                        setForm({
                          ...form,
                          education_levels: {
                            ...form.education_levels,
                            GRADUACAO: { ...form.education_levels.GRADUACAO, min_evaluators: Number(e.target.value) },
                          },
                        })
                      }
                      helperText="Padrão: 2 avaliadores"
                    />
                  </div>
                )}
              </div>

              {/* Nível Pós-Graduação */}
              <div className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 space-y-2">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={form.education_levels.POS_GRADUACAO.enabled}
                    onChange={(e) =>
                      setForm({
                        ...form,
                        education_levels: {
                          ...form.education_levels,
                          POS_GRADUACAO: { ...form.education_levels.POS_GRADUACAO, enabled: e.target.checked },
                        },
                      })
                    }
                    className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 border-slate-300 dark:border-slate-700"
                  />
                  <span className="text-xs font-bold text-slate-900 dark:text-white">
                    Pós-Graduação (Especialização, Mestrado, Doutorado)
                  </span>
                </label>

                {form.education_levels.POS_GRADUACAO.enabled && (
                  <div className="grid grid-cols-2 gap-3 pt-2">
                    <Input
                      label="Máximo de Alunos por Projeto"
                      type="number"
                      value={form.education_levels.POS_GRADUACAO.max_students.toString()}
                      onChange={(e) =>
                        setForm({
                          ...form,
                          education_levels: {
                            ...form.education_levels,
                            POS_GRADUACAO: { ...form.education_levels.POS_GRADUACAO, max_students: Number(e.target.value) },
                          },
                        })
                      }
                      helperText="Padrão: 4 alunos"
                    />
                    <Input
                      label="Mínimo de Avaliadores"
                      type="number"
                      value={form.education_levels.POS_GRADUACAO.min_evaluators.toString()}
                      onChange={(e) =>
                        setForm({
                          ...form,
                          education_levels: {
                            ...form.education_levels,
                            POS_GRADUACAO: { ...form.education_levels.POS_GRADUACAO, min_evaluators: Number(e.target.value) },
                          },
                        })
                      }
                      helperText="Padrão: 2 avaliadores"
                    />
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Aba 5: Equipe Gestora (Regra BR-23) */}
          {createTab === "equipe" && (
            <div className="space-y-3">
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Convide gestores adicionais para a comissão da feira. Você será registrado automaticamente como Coordenador Geral soberano.
              </p>

              <div className="flex flex-col sm:flex-row gap-2 items-end">
                <div className="flex-1 w-full">
                  <Input
                    label="E-mail do Gestor"
                    type="email"
                    value={createAdminEmail}
                    onChange={(e) => setCreateAdminEmail(e.target.value)}
                    placeholder="gestor@ifms.edu.br"
                  />
                </div>
                <div className="w-full sm:w-48">
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Nível de Acesso
                  </label>
                  <select
                    value={createAdminRole}
                    onChange={(e) => setCreateAdminRole(e.target.value as EventAdminRole)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="ORGANIZER">Comissão Organizadora</option>
                    <option value="OPERATOR">Apoio Operacional</option>
                  </select>
                </div>
                <Button
                  type="button"
                  variant="secondary"
                  size="sm"
                  onClick={() => addAdminToForm(false)}
                  className="w-full sm:w-auto h-[38px]"
                >
                  <Plus size={14} />
                  <span>Adicionar</span>
                </Button>
              </div>

              {form.administrators.length > 0 ? (
                <div className="space-y-1.5 pt-2">
                  <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                    Gestores Pré-vinculados ({form.administrators.length})
                  </span>
                  <div className="divide-y divide-slate-100 dark:divide-slate-800 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
                    {form.administrators.map((admin) => (
                      <div
                        key={admin.email}
                        className="px-3.5 py-2.5 bg-white dark:bg-slate-900 flex items-center justify-between text-xs"
                      >
                        <div className="flex items-center gap-2">
                          <Mail size={13} className="text-slate-400" />
                          <span className="font-medium text-slate-900 dark:text-slate-100">{admin.email}</span>
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-50 dark:bg-blue-950 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800">
                            {admin.role === "ORGANIZER" ? "Comissão Organizadora" : "Apoio Operacional"}
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={() => removeAdminFromForm(admin.email, false)}
                          className="p-1 text-slate-400 hover:text-rose-600 transition-colors"
                          title="Remover gestor"
                        >
                          <Trash2 size={13} />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="p-3 text-center rounded-xl bg-slate-50 dark:bg-slate-800/30 text-xs text-slate-400">
                  Nenhum gestor adicional adicionado até o momento. (Opcional)
                </div>
              )}
            </div>
          )}

          {/* Footer */}
          <div className="flex justify-end gap-3 pt-4 border-t border-slate-100 dark:border-slate-800">
            <Button
              type="button"
              variant="outline"
              onClick={closeModal}
            >
              Cancelar
            </Button>
            <Button type="submit" variant="primary" isLoading={isSubmitting}>
              Salvar Edição Completa
            </Button>
          </div>
        </form>
      </Modal>

      {/* Modal de Edição */}
      <Modal
        isOpen={isEditModalOpen}
        onClose={closeEditModal}
        error={editModalError}
        maxWidth="max-w-3xl"
        title={`Editar Parâmetros da Edição: ${targetEditEvent?.name || ""}`}
      >
        <form onSubmit={handleUpdate} className="space-y-4">
          {/* Tabs Navigation */}
          <div className="flex border-b border-slate-200 dark:border-slate-800 pb-1 mb-4 overflow-x-auto gap-1">
            {[
              { id: "geral", label: "Geral & Período", icon: Calendar },
              { id: "identidade", label: "Identidade & Contato", icon: Building2 },
              { id: "parametros", label: "Parâmetros & Anexos", icon: Sliders },
              { id: "niveis", label: "Níveis de Ensino & Cotas", icon: GraduationCap },
              { id: "equipe", label: "Equipe Gestora", icon: Users },
            ].map((tab) => {
              const Icon = tab.icon;
              const isActive = editTab === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setEditTab(tab.id as ModalTab)}
                  className={clsx(
                    "px-3 py-2 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap",
                    isActive
                      ? "bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300"
                      : "text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
                  )}
                >
                  <Icon size={14} />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

          {/* Aba 1: Geral & Período */}
          {editTab === "geral" && (
            <div className="space-y-3">
              <Input
                label="Nome da Edição *"
                required
                value={editForm.name}
                onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
              />

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <Input
                  label="Início *"
                  type="date"
                  required
                  value={editForm.start_date}
                  onChange={(e) => setEditForm({ ...editForm, start_date: e.target.value })}
                />
                <Input
                  label="Término *"
                  type="date"
                  required
                  value={editForm.end_date}
                  onChange={(e) => setEditForm({ ...editForm, end_date: e.target.value })}
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <Input
                  label="Local do Evento *"
                  required
                  value={editForm.location}
                  onChange={(e) => setEditForm({ ...editForm, location: e.target.value })}
                />
                <Input
                  label="Carga Horária (horas) *"
                  type="number"
                  required
                  value={editForm.workload_hours.toString()}
                  onChange={(e) => setEditForm({ ...editForm, workload_hours: Number(e.target.value) })}
                />
                <Input
                  label="Limite de Projetos *"
                  type="number"
                  required
                  value={editForm.max_projects.toString()}
                  onChange={(e) => setEditForm({ ...editForm, max_projects: Number(e.target.value) })}
                />
              </div>
            </div>
          )}

          {/* Aba 2: Identidade & Contato */}
          {editTab === "identidade" && (
            <div className="space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <Input
                  label="Instituição Organizadora"
                  value={editForm.organizing_institution}
                  onChange={(e) => setEditForm({ ...editForm, organizing_institution: e.target.value })}
                />
                <Input
                  label="Tema Oficial da Edição"
                  value={editForm.theme}
                  onChange={(e) => setEditForm({ ...editForm, theme: e.target.value })}
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <Input
                  label="E-mail de Contato"
                  type="email"
                  value={editForm.contact_email}
                  onChange={(e) => setEditForm({ ...editForm, contact_email: e.target.value })}
                />
                <Input
                  label="Website Oficial"
                  type="url"
                  value={editForm.website_url}
                  onChange={(e) => setEditForm({ ...editForm, website_url: e.target.value })}
                />
              </div>

              {/* Upload de Logotipo do Evento (PNG ou JPG) */}
              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Logotipo Oficial da Edição (PNG ou JPG/JPEG)
                </label>
                <input
                  type="file"
                  ref={editLogoInputRef}
                  accept=".png,.jpg,.jpeg,image/png,image/jpeg"
                  className="hidden"
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (f) handleUploadLogo(f, true);
                    e.target.value = "";
                  }}
                />
                {editForm.logo_url ? (
                  <div className="flex items-center gap-3.5 p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-900/50">
                    <div className="w-16 h-16 rounded-lg border border-slate-200 dark:border-slate-700 bg-white p-1 flex items-center justify-center overflow-hidden flex-shrink-0">
                      <img
                        src={getLogoDisplayUrl(editForm.logo_url)}
                        alt="Logotipo da Edição"
                        className="w-full h-full object-contain"
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                        Logotipo Atual do Evento
                      </p>
                      <p className="text-[11px] text-slate-400 font-mono truncate mt-0.5">
                        {editForm.logo_url}
                      </p>
                      <div className="flex items-center gap-2 mt-2">
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => editLogoInputRef.current?.click()}
                          disabled={isUploadingEditLogo}
                          className="text-[11px] h-7 px-2.5"
                        >
                          {isUploadingEditLogo ? (
                            <Loader2 size={12} className="animate-spin mr-1 text-blue-600" />
                          ) : (
                            <Upload size={12} className="mr-1" />
                          )}
                          Substituir Imagem
                        </Button>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => setEditForm({ ...editForm, logo_url: "" })}
                          className="text-[11px] h-7 px-2 text-rose-600 hover:text-rose-700 hover:bg-rose-50 dark:hover:bg-rose-950/40"
                        >
                          <Trash2 size={12} className="mr-1" />
                          Remover
                        </Button>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div
                    onClick={() => !isUploadingEditLogo && editLogoInputRef.current?.click()}
                    className="border-2 border-dashed border-slate-200 dark:border-slate-800 hover:border-blue-500 dark:hover:border-blue-500 rounded-xl p-4 text-center cursor-pointer transition-colors bg-white dark:bg-slate-900/30 group"
                  >
                    {isUploadingEditLogo ? (
                      <div className="flex flex-col items-center justify-center py-2">
                        <Loader2 size={24} className="animate-spin text-blue-600 mb-1.5" />
                        <span className="text-xs font-medium text-slate-600 dark:text-slate-400">
                          Enviando imagem para o servidor...
                        </span>
                      </div>
                    ) : (
                      <div className="flex flex-col items-center justify-center py-1">
                        <div className="w-10 h-10 rounded-full bg-blue-50 dark:bg-blue-950/50 text-blue-600 dark:text-blue-400 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
                          <Upload size={18} />
                        </div>
                        <p className="text-xs font-semibold text-slate-700 dark:text-slate-200">
                          Clique para selecionar o logotipo da feira
                        </p>
                        <p className="text-[11px] text-slate-400 mt-0.5">
                          Formatos suportados: <strong>PNG</strong> ou <strong>JPG/JPEG</strong> (tamanho máx. 5MB)
                        </p>
                      </div>
                    )}
                  </div>
                )}
              </div>

              <div className="space-y-1">
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Descrição Detalhada do Evento
                </label>
                <textarea
                  rows={3}
                  value={editForm.description}
                  onChange={(e) => setEditForm({ ...editForm, description: e.target.value })}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
          )}

          {/* Aba 3: Parâmetros & Anexos */}
          {editTab === "parametros" && (
            <div className="space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <Input
                  label="Extensão do Resumo *"
                  value={editForm.summary_extension}
                  onChange={(e) => setEditForm({ ...editForm, summary_extension: e.target.value })}
                />
                <Input
                  label="Extensão do Banner *"
                  value={editForm.banner_extension}
                  onChange={(e) => setEditForm({ ...editForm, banner_extension: e.target.value })}
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <Input
                  label="Limite de Tamanho do Arquivo (MB) *"
                  type="number"
                  value={editForm.max_file_size_mb.toString()}
                  onChange={(e) => setEditForm({ ...editForm, max_file_size_mb: Number(e.target.value) })}
                />
                <Input
                  label="Teto por Avaliador *"
                  type="number"
                  value={editForm.max_projects_per_evaluator.toString()}
                  onChange={(e) => setEditForm({ ...editForm, max_projects_per_evaluator: Number(e.target.value) })}
                />
              </div>
            </div>
          )}

          {/* Aba 4: Níveis de Ensino & Cotas */}
          {editTab === "niveis" && (
            <div className="space-y-3">
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Ajuste os níveis de ensino aceitos nesta feira e suas cotas.
              </p>

              {/* Nível Fundamental I */}
              <div className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 space-y-2">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={editForm.education_levels.JUNIOR.enabled}
                    onChange={(e) =>
                      setEditForm({
                        ...editForm,
                        education_levels: {
                          ...editForm.education_levels,
                          JUNIOR: { ...editForm.education_levels.JUNIOR, enabled: e.target.checked },
                        },
                      })
                    }
                    className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 border-slate-300 dark:border-slate-700"
                  />
                  <span className="text-xs font-bold text-slate-900 dark:text-white">
                    Ensino Fundamental I (1º ao 5º ano)
                  </span>
                </label>

                {editForm.education_levels.JUNIOR.enabled && (
                  <div className="grid grid-cols-2 gap-3 pt-2">
                    <Input
                      label="Máximo de Alunos por Projeto"
                      type="number"
                      value={editForm.education_levels.JUNIOR.max_students.toString()}
                      onChange={(e) =>
                        setEditForm({
                          ...editForm,
                          education_levels: {
                            ...editForm.education_levels,
                            JUNIOR: { ...editForm.education_levels.JUNIOR, max_students: Number(e.target.value) },
                          },
                        })
                      }
                      helperText="Padrão: 5 alunos"
                    />
                    <Input
                      label="Mínimo de Avaliadores"
                      type="number"
                      value={editForm.education_levels.JUNIOR.min_evaluators.toString()}
                      onChange={(e) =>
                        setEditForm({
                          ...editForm,
                          education_levels: {
                            ...editForm.education_levels,
                            JUNIOR: { ...editForm.education_levels.JUNIOR, min_evaluators: Number(e.target.value) },
                          },
                        })
                      }
                      helperText="Padrão: 2 avaliadores"
                    />
                  </div>
                )}
              </div>

              {/* Nível Fundamental II */}
              <div className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 space-y-2">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={editForm.education_levels.FUNDAMENTAL.enabled}
                    onChange={(e) =>
                      setEditForm({
                        ...editForm,
                        education_levels: {
                          ...editForm.education_levels,
                          FUNDAMENTAL: { ...editForm.education_levels.FUNDAMENTAL, enabled: e.target.checked },
                        },
                      })
                    }
                    className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 border-slate-300 dark:border-slate-700"
                  />
                  <span className="text-xs font-bold text-slate-900 dark:text-white">
                    Ensino Fundamental II (6º ao 9º ano)
                  </span>
                </label>

                {editForm.education_levels.FUNDAMENTAL.enabled && (
                  <div className="grid grid-cols-2 gap-3 pt-2">
                    <Input
                      label="Máximo de Alunos por Projeto"
                      type="number"
                      value={editForm.education_levels.FUNDAMENTAL.max_students.toString()}
                      onChange={(e) =>
                        setEditForm({
                          ...editForm,
                          education_levels: {
                            ...editForm.education_levels,
                            FUNDAMENTAL: { ...editForm.education_levels.FUNDAMENTAL, max_students: Number(e.target.value) },
                          },
                        })
                      }
                      helperText="Padrão: 5 alunos"
                    />
                    <Input
                      label="Mínimo de Avaliadores"
                      type="number"
                      value={editForm.education_levels.FUNDAMENTAL.min_evaluators.toString()}
                      onChange={(e) =>
                        setEditForm({
                          ...editForm,
                          education_levels: {
                            ...editForm.education_levels,
                            FUNDAMENTAL: { ...editForm.education_levels.FUNDAMENTAL, min_evaluators: Number(e.target.value) },
                          },
                        })
                      }
                      helperText="Padrão: 2 avaliadores"
                    />
                  </div>
                )}
              </div>

              {/* Nível Médio / Técnico */}
              <div className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 space-y-2">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={editForm.education_levels.MEDIO.enabled}
                    onChange={(e) =>
                      setEditForm({
                        ...editForm,
                        education_levels: {
                          ...editForm.education_levels,
                          MEDIO: { ...editForm.education_levels.MEDIO, enabled: e.target.checked },
                        },
                      })
                    }
                    className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 border-slate-300 dark:border-slate-700"
                  />
                  <span className="text-xs font-bold text-slate-900 dark:text-white">
                    Ensino Médio / Técnico
                  </span>
                </label>

                {editForm.education_levels.MEDIO.enabled && (
                  <div className="grid grid-cols-2 gap-3 pt-2">
                    <Input
                      label="Máximo de Alunos por Projeto"
                      type="number"
                      value={editForm.education_levels.MEDIO.max_students.toString()}
                      onChange={(e) =>
                        setEditForm({
                          ...editForm,
                          education_levels: {
                            ...editForm.education_levels,
                            MEDIO: { ...editForm.education_levels.MEDIO, max_students: Number(e.target.value) },
                          },
                        })
                      }
                      helperText="Padrão: 4 alunos"
                    />
                    <Input
                      label="Mínimo de Avaliadores"
                      type="number"
                      value={editForm.education_levels.MEDIO.min_evaluators.toString()}
                      onChange={(e) =>
                        setEditForm({
                          ...editForm,
                          education_levels: {
                            ...editForm.education_levels,
                            MEDIO: { ...editForm.education_levels.MEDIO, min_evaluators: Number(e.target.value) },
                          },
                        })
                      }
                      helperText="Padrão: 2 avaliadores"
                    />
                  </div>
                )}
              </div>

              {/* Nível Graduação */}
              <div className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 space-y-2">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={editForm.education_levels.GRADUACAO.enabled}
                    onChange={(e) =>
                      setEditForm({
                        ...editForm,
                        education_levels: {
                          ...editForm.education_levels,
                          GRADUACAO: { ...editForm.education_levels.GRADUACAO, enabled: e.target.checked },
                        },
                      })
                    }
                    className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 border-slate-300 dark:border-slate-700"
                  />
                  <span className="text-xs font-bold text-slate-900 dark:text-white">
                    Graduação / Ensino Superior
                  </span>
                </label>

                {editForm.education_levels.GRADUACAO.enabled && (
                  <div className="grid grid-cols-2 gap-3 pt-2">
                    <Input
                      label="Máximo de Alunos por Projeto"
                      type="number"
                      value={editForm.education_levels.GRADUACAO.max_students.toString()}
                      onChange={(e) =>
                        setEditForm({
                          ...editForm,
                          education_levels: {
                            ...editForm.education_levels,
                            GRADUACAO: { ...editForm.education_levels.GRADUACAO, max_students: Number(e.target.value) },
                          },
                        })
                      }
                      helperText="Padrão: 5 alunos"
                    />
                    <Input
                      label="Mínimo de Avaliadores"
                      type="number"
                      value={editForm.education_levels.GRADUACAO.min_evaluators.toString()}
                      onChange={(e) =>
                        setEditForm({
                          ...editForm,
                          education_levels: {
                            ...editForm.education_levels,
                            GRADUACAO: { ...editForm.education_levels.GRADUACAO, min_evaluators: Number(e.target.value) },
                          },
                        })
                      }
                      helperText="Padrão: 2 avaliadores"
                    />
                  </div>
                )}
              </div>

              {/* Nível Pós-Graduação */}
              <div className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 space-y-2">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={editForm.education_levels.POS_GRADUACAO.enabled}
                    onChange={(e) =>
                      setEditForm({
                        ...editForm,
                        education_levels: {
                          ...editForm.education_levels,
                          POS_GRADUACAO: { ...editForm.education_levels.POS_GRADUACAO, enabled: e.target.checked },
                        },
                      })
                    }
                    className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 border-slate-300 dark:border-slate-700"
                  />
                  <span className="text-xs font-bold text-slate-900 dark:text-white">
                    Pós-Graduação (Especialização, Mestrado, Doutorado)
                  </span>
                </label>

                {editForm.education_levels.POS_GRADUACAO.enabled && (
                  <div className="grid grid-cols-2 gap-3 pt-2">
                    <Input
                      label="Máximo de Alunos por Projeto"
                      type="number"
                      value={editForm.education_levels.POS_GRADUACAO.max_students.toString()}
                      onChange={(e) =>
                        setEditForm({
                          ...editForm,
                          education_levels: {
                            ...editForm.education_levels,
                            POS_GRADUACAO: { ...editForm.education_levels.POS_GRADUACAO, max_students: Number(e.target.value) },
                          },
                        })
                      }
                      helperText="Padrão: 4 alunos"
                    />
                    <Input
                      label="Mínimo de Avaliadores"
                      type="number"
                      value={editForm.education_levels.POS_GRADUACAO.min_evaluators.toString()}
                      onChange={(e) =>
                        setEditForm({
                          ...editForm,
                          education_levels: {
                            ...editForm.education_levels,
                            POS_GRADUACAO: { ...editForm.education_levels.POS_GRADUACAO, min_evaluators: Number(e.target.value) },
                          },
                        })
                      }
                      helperText="Padrão: 2 avaliadores"
                    />
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Aba 5: Equipe Gestora */}
          {editTab === "equipe" && (
            <div className="space-y-3">
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Sincronize a equipe de gestores da feira. O Coordenador Geral soberano não pode ser removido aqui.
              </p>

              <div className="flex flex-col sm:flex-row gap-2 items-end">
                <div className="flex-1 w-full">
                  <Input
                    label="E-mail do Gestor"
                    type="email"
                    value={editAdminEmail}
                    onChange={(e) => setEditAdminEmail(e.target.value)}
                    placeholder="gestor@ifms.edu.br"
                  />
                </div>
                <div className="w-full sm:w-48">
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Nível de Acesso
                  </label>
                  <select
                    value={editAdminRole}
                    onChange={(e) => setEditAdminRole(e.target.value as EventAdminRole)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="ORGANIZER">Comissão Organizadora</option>
                    <option value="OPERATOR">Apoio Operacional</option>
                  </select>
                </div>
                <Button
                  type="button"
                  variant="secondary"
                  size="sm"
                  onClick={() => addAdminToForm(true)}
                  className="w-full sm:w-auto h-[38px]"
                >
                  <Plus size={14} />
                  <span>Adicionar</span>
                </Button>
              </div>

              {editForm.administrators.length > 0 ? (
                <div className="space-y-1.5 pt-2">
                  <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                    Gestores Vinculados ({editForm.administrators.length})
                  </span>
                  <div className="divide-y divide-slate-100 dark:divide-slate-800 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
                    {editForm.administrators.map((admin) => (
                      <div
                        key={admin.email}
                        className="px-3.5 py-2.5 bg-white dark:bg-slate-900 flex items-center justify-between text-xs"
                      >
                        <div className="flex items-center gap-2">
                          <Mail size={13} className="text-slate-400" />
                          <span className="font-medium text-slate-900 dark:text-slate-100">{admin.email}</span>
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-50 dark:bg-blue-950 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800">
                            {admin.role === "ORGANIZER" ? "Comissão Organizadora" : "Apoio Operacional"}
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={() => removeAdminFromForm(admin.email, true)}
                          className="p-1 text-slate-400 hover:text-rose-600 transition-colors"
                          title="Remover gestor"
                        >
                          <Trash2 size={13} />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="p-3 text-center rounded-xl bg-slate-50 dark:bg-slate-800/30 text-xs text-slate-400">
                  Nenhum gestor adicional cadastrado nesta edição.
                </div>
              )}
            </div>
          )}

          {/* Footer */}
          <div className="flex justify-end gap-3 pt-4 border-t border-slate-100 dark:border-slate-800">
            <Button
              type="button"
              variant="outline"
              onClick={closeEditModal}
            >
              Cancelar
            </Button>
            <Button type="submit" variant="primary" isLoading={isSubmitting}>
              Salvar Alterações
            </Button>
          </div>
        </form>
      </Modal>

      {selectedTeamEvent && (
        <EventAdminsModal
          isOpen={!!selectedTeamEvent}
          event={selectedTeamEvent}
          onClose={() => {
            setSelectedTeamEvent(null);
            loadEvents(currentPage, searchQuery);
          }}
        />
      )}
    </div>
  );
}
