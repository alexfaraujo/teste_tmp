"use client";

import React, { useEffect, useState, useMemo } from "react";
import Link from "next/link";
import {
  Plus,
  Award,
  CheckSquare,
  Square,
  Trophy,
  CheckCircle2,
  AlertCircle,
  Pencil,
  Trash2,
  Search,
  ExternalLink,
  HelpCircle,
  Sparkles,
  ListChecks,
} from "lucide-react";
import { useActiveEvent } from "../../../context/EventContext";
import { RequireActiveEvent } from "../../../components/common/RequireActiveEvent";
import { awardService } from "../../../services/award.service";
import {
  AwardItem,
  EvaluationCriterion,
  AwardCriterionLinkInput,
} from "../../../types";
import { Button } from "../../../components/ui/Button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "../../../components/ui/Card";
import { Modal } from "../../../components/ui/Modal";
import { Input } from "../../../components/ui/Input";
import { Pagination } from "../../../components/ui/Pagination";

export default function AwardsPage() {
  const { activeEvent } = useActiveEvent();

  const [awards, setAwards] = useState<AwardItem[]>([]);
  const [criteriaList, setCriteriaList] = useState<EvaluationCriterion[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [notification, setNotification] = useState<{
    type: "success" | "error";
    text: string;
  } | null>(null);

  // Filtro de busca e paginação (BR-18)
  const [searchTerm, setSearchTerm] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 6; // Cards elegantes em grid 2 colunas

  // Estado do Modal de Cadastro / Edição
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingAwardId, setEditingAwardId] = useState<number | null>(null);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [sponsor, setSponsor] = useState("");
  const [selectedCriteria, setSelectedCriteria] = useState<
    Record<number, { selected: boolean; weight: number }>
  >({});
  const [modalError, setModalError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Estado do Modal de Exclusão
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [deletingAward, setDeletingAward] = useState<AwardItem | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [deleteModalError, setDeleteModalError] = useState<string | null>(null);

  async function loadData() {
    if (!activeEvent) return;
    setIsLoading(true);
    try {
      const [awardData, criteriaData] = await Promise.all([
        awardService.getAwards(activeEvent.id),
        awardService.getEventCriteria(activeEvent.id),
      ]);
      setAwards(awardData);
      setCriteriaList(criteriaData);
    } catch (err: any) {
      setNotification({
        type: "error",
        text: "Erro ao carregar dados de premiações e critérios do evento.",
      });
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    loadData();
  }, [activeEvent?.id]);

  // Filtragem e Paginação
  const filteredAwards = useMemo(() => {
    if (!searchTerm.trim()) return awards;
    const term = searchTerm.toLowerCase();
    return awards.filter(
      (a) =>
        a.name.toLowerCase().includes(term) ||
        (a.sponsor && a.sponsor.toLowerCase().includes(term)) ||
        (a.description && a.description.toLowerCase().includes(term))
    );
  }, [awards, searchTerm]);

  const totalPages = Math.ceil(filteredAwards.length / itemsPerPage) || 1;
  const paginatedAwards = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    return filteredAwards.slice(start, start + itemsPerPage);
  }, [filteredAwards, currentPage, itemsPerPage]);

  // Abertura do Modal de Cadastro
  const handleOpenCreateModal = () => {
    setEditingAwardId(null);
    setName("");
    setDescription("");
    setSponsor("");
    setModalError(null);

    const initialMap: Record<number, { selected: boolean; weight: number }> = {};
    criteriaList.forEach((c) => {
      initialMap[c.id] = { selected: false, weight: 1.0 };
    });
    setSelectedCriteria(initialMap);
    setIsModalOpen(true);
  };

  // Abertura do Modal de Edição
  const handleOpenEditModal = (award: AwardItem) => {
    setEditingAwardId(award.id);
    setName(award.name);
    setDescription(award.description || "");
    setSponsor(award.sponsor || "");
    setModalError(null);

    const initialMap: Record<number, { selected: boolean; weight: number }> = {};
    criteriaList.forEach((c) => {
      const linked = award.criteria_links?.find((l) => l.criterion_id === c.id);
      if (linked) {
        initialMap[c.id] = { selected: true, weight: Number(linked.weight) || 1.0 };
      } else {
        initialMap[c.id] = { selected: false, weight: 1.0 };
      }
    });
    setSelectedCriteria(initialMap);
    setIsModalOpen(true);
  };

  const handleToggleCriterion = (id: number) => {
    setSelectedCriteria((prev) => ({
      ...prev,
      [id]: {
        selected: !prev[id]?.selected,
        weight: prev[id]?.weight || 1.0,
      },
    }));
  };

  const handleWeightChange = (id: number, weight: number) => {
    setSelectedCriteria((prev) => ({
      ...prev,
      [id]: {
        selected: prev[id]?.selected ?? true,
        weight: Math.max(0.1, Math.min(10.0, weight)),
      },
    }));
  };

  // Submissão do Formulário de Criação/Edição
  const handleSubmitAward = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeEvent) return;
    if (!name.trim()) {
      setModalError("O nome da premiação é obrigatório.");
      return;
    }

    setIsSubmitting(true);
    setModalError(null);

    const activeLinks: AwardCriterionLinkInput[] = Object.entries(selectedCriteria)
      .filter(([_, val]) => val.selected)
      .map(([idStr, val]) => ({
        criterion_id: parseInt(idStr),
        weight: val.weight,
      }));

    if (activeLinks.length === 0) {
      setModalError(
        "Selecione ao menos um critério de avaliação para vincular à premiação específica."
      );
      setIsSubmitting(false);
      return;
    }

    try {
      if (editingAwardId) {
        await awardService.updateAward(editingAwardId, {
          name: name.trim(),
          description: description.trim() || undefined,
          sponsor: sponsor.trim() || undefined,
          criteria_links: activeLinks,
        });
        setNotification({
          type: "success",
          text: `Premiação "${name.trim()}" atualizada com sucesso!`,
        });
      } else {
        await awardService.createAward(activeEvent.id, {
          name: name.trim(),
          description: description.trim() || undefined,
          sponsor: sponsor.trim() || undefined,
          criteria_links: activeLinks,
        });
        setNotification({
          type: "success",
          text: `Premiação "${name.trim()}" cadastrada com sucesso!`,
        });
      }

      setIsModalOpen(false);
      await loadData();
    } catch (err: any) {
      setModalError(
        err.response?.data?.detail || "Erro ao salvar os dados da premiação."
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  // Exclusão de Premiação
  const handleOpenDeleteModal = (award: AwardItem) => {
    setDeletingAward(award);
    setDeleteModalError(null);
    setIsDeleteModalOpen(true);
  };

  const handleConfirmDelete = async () => {
    if (!deletingAward) return;
    setIsDeleting(true);
    setDeleteModalError(null);
    try {
      await awardService.deleteAward(deletingAward.id);
      setNotification({
        type: "success",
        text: `Premiação "${deletingAward.name}" desativada com sucesso!`,
      });
      setIsDeleteModalOpen(false);
      setDeletingAward(null);
      await loadData();
    } catch (err: any) {
      setDeleteModalError(
        err.response?.data?.detail || "Erro ao excluir a premiação."
      );
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <RequireActiveEvent minRole="ORGANIZER" featureName="o gerenciamento de Premiações">
      <div className="space-y-6 max-w-7xl mx-auto">
        {/* Page Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white flex items-center gap-2.5">
              <Trophy className="text-amber-500" size={26} />
              Premiações e Critérios Específicos
            </h1>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
              Cadastro de troféus especiais, prêmios temáticos e parametrização dos pesos de avaliação para o <strong>Ranking 2 (Premiações Específicas)</strong>.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <Link href="/criteria">
              <Button variant="outline">
                <ListChecks size={16} className="mr-1.5" />
                Critérios de Avaliação
              </Button>
            </Link>
            <Button
              variant="primary"
              onClick={handleOpenCreateModal}
            >
              <Plus size={16} className="mr-1.5" />
              Nova Premiação
            </Button>
          </div>
        </div>

        {/* Notificação Externa */}
        {notification && (
          <div
            className={`p-4 rounded-xl text-sm flex items-start justify-between gap-2.5 border ${
              notification.type === "success"
                ? "bg-emerald-50 text-emerald-800 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-800"
                : "bg-rose-50 text-rose-800 border-rose-200 dark:bg-rose-950/40 dark:text-rose-300 dark:border-rose-800"
            }`}
          >
            <div className="flex items-start gap-2.5">
              {notification.type === "success" ? (
                <CheckCircle2 size={18} className="flex-shrink-0 mt-0.5" />
              ) : (
                <AlertCircle size={18} className="flex-shrink-0 mt-0.5" />
              )}
              <span>{notification.text}</span>
            </div>
            <button
              onClick={() => setNotification(null)}
              className="text-xs font-semibold hover:underline opacity-80"
            >
              Fechar
            </button>
          </div>
        )}

        {/* Barra de Busca e Filtros */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800">
          <div className="relative flex-1 max-w-md">
            <Search
              size={16}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
            />
            <input
              type="text"
              placeholder="Buscar por nome do prêmio ou patrocinador..."
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full pl-9 pr-4 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/20"
            />
          </div>

          <div className="text-xs text-slate-500 dark:text-slate-400">
            Total: <strong>{filteredAwards.length}</strong> premiação(ões) cadastrada(s)
          </div>
        </div>

        {/* Lista de Premiações */}
        {isLoading ? (
          <div className="py-16 text-center text-slate-500 text-sm animate-pulse">
            Carregando premiações da edição ativa...
          </div>
        ) : filteredAwards.length === 0 ? (
          <Card className="p-12 text-center text-slate-500">
            <Award size={40} className="mx-auto mb-3 text-slate-400 opacity-60" />
            <p className="font-semibold text-slate-700 dark:text-slate-300">
              Nenhuma premiação encontrada.
            </p>
            <p className="text-xs text-slate-400 mt-1">
              Clique em &quot;Nova Premiação&quot; para cadastrar prêmios temáticos e vincular critérios da avaliação.
            </p>
          </Card>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            {paginatedAwards.map((award) => {
              const links = award.criteria_links || [];
              return (
                <Card
                  key={award.id}
                  className="flex flex-col justify-between hover:shadow-md transition-shadow border-slate-200 dark:border-slate-800"
                >
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-start gap-3">
                        <div className="p-2.5 rounded-xl bg-amber-50 dark:bg-amber-950/50 text-amber-600 dark:text-amber-400 border border-amber-200 dark:border-amber-900/60 flex-shrink-0">
                          <Trophy size={20} />
                        </div>
                        <div>
                          <CardTitle className="text-base font-bold text-slate-900 dark:text-white leading-tight">
                            {award.name}
                          </CardTitle>
                          {award.sponsor ? (
                            <span className="inline-flex items-center gap-1 mt-1 text-xs font-semibold px-2 py-0.5 rounded-full bg-purple-50 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-800/80">
                              Patrocínio: {award.sponsor}
                            </span>
                          ) : (
                            <span className="text-[11px] text-slate-400 block mt-0.5">
                              Premiação Geral da Instituição
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Botões de Ação */}
                      <div className="flex items-center gap-1.5 flex-shrink-0">
                        <Link href={`/results?tab=awards&award_id=${award.id}`}>
                          <Button
                            variant="outline"
                            size="sm"
                            title="Ver Classificação Oficial deste Prêmio"
                          >
                            <ExternalLink size={13} className="mr-1" />
                            Apuração
                          </Button>
                        </Link>
                        <button
                          onClick={() => handleOpenEditModal(award)}
                          className="p-1.5 text-slate-500 hover:text-blue-600 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
                          title="Editar premiação"
                        >
                          <Pencil size={15} />
                        </button>
                        <button
                          onClick={() => handleOpenDeleteModal(award)}
                          className="p-1.5 text-slate-500 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition-colors"
                          title="Excluir premiação"
                        >
                          <Trash2 size={15} />
                        </button>
                      </div>
                    </div>

                    {award.description && (
                      <p className="text-xs text-slate-600 dark:text-slate-400 mt-2.5 leading-relaxed bg-slate-50 dark:bg-slate-800/40 p-2.5 rounded-lg border border-slate-100 dark:border-slate-800/60">
                        {award.description}
                      </p>
                    )}
                  </CardHeader>

                  <CardContent className="p-4 bg-slate-50/60 dark:bg-slate-800/30 border-t border-slate-100 dark:border-slate-800">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                        Critérios Ponderados ({links.length}):
                      </span>
                      {links.length > 0 && (
                        <span className="text-[10px] text-slate-400">
                          Premiação Específica
                        </span>
                      )}
                    </div>

                    {links.length === 0 ? (
                      <div className="text-xs text-slate-400 italic p-2 rounded-lg bg-white dark:bg-slate-900 border border-dashed border-slate-200 dark:border-slate-800">
                        Nenhum critério específico vinculado. O prêmio utilizará a média global das fichas.
                      </div>
                    ) : (
                      <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
                        {links.map((c) => {
                          const critRef = criteriaList.find(
                            (cl) => cl.id === c.criterion_id
                          );
                          const displayName =
                            c.criterion_name ||
                            critRef?.name ||
                            `Critério #${c.criterion_id}`;
                          return (
                            <div
                              key={c.criterion_id}
                              className="flex items-center justify-between text-xs text-slate-700 dark:text-slate-300 p-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-2xs"
                            >
                              <span className="font-medium truncate mr-2">
                                {displayName}
                              </span>
                              <span className="px-2 py-0.5 rounded-md bg-blue-50 dark:bg-blue-950 text-blue-700 dark:text-blue-300 font-bold text-[11px] flex-shrink-0 border border-blue-200 dark:border-blue-900">
                                Peso: {Number(c.weight).toFixed(1)}x
                              </span>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}

        {/* Paginação */}
        {filteredAwards.length > itemsPerPage && (
          <div className="pt-2">
            <Pagination
              currentPage={currentPage}
              totalPages={totalPages}
              totalItems={filteredAwards.length}
              limit={itemsPerPage}
              onPageChange={setCurrentPage}
            />
          </div>
        )}

        {/* MODAL: Cadastrar / Editar Premiação (UX-01) */}
        <Modal
          isOpen={isModalOpen}
          onClose={() => !isSubmitting && setIsModalOpen(false)}
          title={
            editingAwardId
              ? "Editar Premiação Específica"
              : "Cadastrar Nova Premiação Específica"
          }
          error={modalError}
        >
          <form onSubmit={handleSubmitAward} className="space-y-4">

            <Input
              label="Nome do Prêmio / Troféu *"
              placeholder="Ex: Prêmio Inovação e Sustentabilidade 2026"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <Input
                label="Patrocinador / Apoiador"
                placeholder="Ex: Empresa Parceira / CNPq"
                value={sponsor}
                onChange={(e) => setSponsor(e.target.value)}
              />
              <Input
                label="Descrição Resumida"
                placeholder="Ex: Homenageia projetos com foco ecológico"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
              />
            </div>

            {/* Seleção de Critérios e Pesos */}
            <div className="pt-2">
              <div className="flex items-center justify-between mb-1.5">
                <label className="block text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider">
                  Critérios da Ficha de Avaliação:
                </label>
                <span className="text-[11px] text-slate-500">
                  {Object.values(selectedCriteria).filter((v) => v.selected).length} selecionado(s)
                </span>
              </div>

              <p className="text-xs text-slate-500 dark:text-slate-400 mb-2.5 leading-relaxed">
                Marque apenas as perguntas da ficha que comporão a nota deste prêmio especial. O sistema ponderará a nota final usando os pesos definidos abaixo.
              </p>

              {criteriaList.length === 0 ? (
                <div className="p-4 text-center text-xs text-amber-800 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/40 rounded-xl border border-amber-200 dark:border-amber-900/60">
                  <p className="font-semibold">Nenhum critério de avaliação cadastrado na edição ativa.</p>
                  <p className="text-[11px] text-amber-700 dark:text-amber-400 mt-1 mb-3">
                    Para cadastrar premiações específicas, é necessário previamente cadastrar os itens avaliados da feira.
                  </p>
                  <Link
                    href="/criteria"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-semibold text-xs transition-colors"
                  >
                    <ListChecks size={14} />
                    Cadastrar Critérios de Avaliação
                  </Link>
                </div>
              ) : (
                <div className="space-y-2 max-h-60 overflow-y-auto pr-1 border border-slate-200 dark:border-slate-800 p-2 rounded-xl bg-slate-50/40 dark:bg-slate-900/40">
                  {criteriaList.map((crit) => {
                    const state = selectedCriteria[crit.id] || {
                      selected: false,
                      weight: 1.0,
                    };
                    return (
                      <div
                        key={crit.id}
                        className={`p-3 rounded-xl border text-xs transition-colors flex items-center justify-between gap-3 ${
                          state.selected
                            ? "bg-blue-50/80 border-blue-300 dark:bg-blue-950/50 dark:border-blue-800 shadow-2xs"
                            : "bg-white border-slate-200 dark:bg-slate-900 dark:border-slate-800 hover:border-slate-300"
                        }`}
                      >
                        <button
                          type="button"
                          onClick={() => handleToggleCriterion(crit.id)}
                          className="flex items-start gap-2.5 text-left flex-1 cursor-pointer"
                        >
                          {state.selected ? (
                            <CheckSquare
                              size={18}
                              className="text-blue-600 dark:text-blue-400 flex-shrink-0 mt-0.5"
                            />
                          ) : (
                            <Square
                              size={18}
                              className="text-slate-400 flex-shrink-0 mt-0.5"
                            />
                          )}
                          <div>
                            <span className="font-bold text-slate-900 dark:text-white block leading-tight">
                              {crit.name}
                            </span>
                            {(crit.scientific_description ||
                              crit.technological_description) && (
                              <span className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-1 mt-0.5">
                                {crit.scientific_description ||
                                  crit.technological_description}
                              </span>
                            )}
                          </div>
                        </button>

                        {state.selected && (
                          <div className="flex items-center gap-1.5 flex-shrink-0 bg-white dark:bg-slate-800 px-2 py-1 rounded-lg border border-slate-200 dark:border-slate-700">
                            <span className="text-slate-500 text-[11px] font-medium">
                              Peso:
                            </span>
                            <input
                              type="number"
                              step="0.1"
                              min="0.1"
                              max="10.0"
                              value={state.weight}
                              onChange={(e) =>
                                handleWeightChange(
                                  crit.id,
                                  parseFloat(e.target.value) || 1.0
                                )
                              }
                              className="w-14 px-1 py-0.5 text-xs text-center font-bold bg-transparent text-slate-900 dark:text-white focus:outline-none"
                            />
                            <span className="text-slate-400 text-[10px]">x</span>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Ações do Modal */}
            <div className="flex justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
              <Button
                type="button"
                variant="outline"
                onClick={() => setIsModalOpen(false)}
                disabled={isSubmitting}
              >
                Cancelar
              </Button>
              <Button type="submit" variant="primary" isLoading={isSubmitting}>
                {editingAwardId ? "Atualizar Premiação" : "Salvar Premiação"}
              </Button>
            </div>
          </form>
        </Modal>

        {/* MODAL: Confirmação de Exclusão (UX-01) */}
        <Modal
          isOpen={isDeleteModalOpen}
          onClose={() => !isDeleting && setIsDeleteModalOpen(false)}
          title="Desativar Premiação Especial"
          error={deleteModalError}
        >
          <div className="space-y-4">
            <div className="p-3.5 bg-amber-50 dark:bg-amber-950/40 rounded-xl border border-amber-200 dark:border-amber-900/60 text-xs text-amber-800 dark:text-amber-300 leading-relaxed">
              Você tem certeza de que deseja desativar a premiação{" "}
              <strong>&quot;{deletingAward?.name}&quot;</strong>? O prêmio e os vínculos com critérios serão desativados (soft-delete).
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
              <Button
                type="button"
                variant="outline"
                onClick={() => setIsDeleteModalOpen(false)}
                disabled={isDeleting}
              >
                Cancelar
              </Button>
              <Button
                type="button"
                variant="danger"
                isLoading={isDeleting}
                onClick={handleConfirmDelete}
              >
                Sim, Desativar
              </Button>
            </div>
          </div>
        </Modal>
      </div>
    </RequireActiveEvent>
  );
}
