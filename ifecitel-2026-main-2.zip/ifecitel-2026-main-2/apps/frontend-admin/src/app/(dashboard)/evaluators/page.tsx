"use client";

import React, { useEffect, useState, useMemo } from "react";
import Link from "next/link";
import {
  Users,
  Scale,
  Plus,
  Trash2,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  Search,
  Filter,
  RefreshCw,
  MapPin,
  QrCode,
  Building2,
  Calendar,
  Layers,
  ShieldAlert,
} from "lucide-react";
import { useActiveEvent } from "../../../context/EventContext";
import { RequireActiveEvent } from "../../../components/common/RequireActiveEvent";
import {
  allocationService,
  AutoBalanceSummaryResponse,
} from "../../../services/allocation.service";
import { projectService } from "../../../services/project.service";
import {
  AllocationResponse,
  ProjectItem,
  EvaluatorListItem,
} from "../../../types";
import { Button } from "../../../components/ui/Button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "../../../components/ui/Card";
import { Modal } from "../../../components/ui/Modal";
import { Input } from "../../../components/ui/Input";
import { Pagination } from "../../../components/ui/Pagination";

export default function EvaluatorsPage() {
  return (
    <RequireActiveEvent minRole="ORGANIZER" featureName="a Alocação de Avaliadores">
      <EvaluatorsContent />
    </RequireActiveEvent>
  );
}

function EvaluatorsContent() {
  const { activeEvent } = useActiveEvent();

  // Data States
  const [allocations, setAllocations] = useState<AllocationResponse[]>([]);
  const [projects, setProjects] = useState<ProjectItem[]>([]);
  const [evaluators, setEvaluators] = useState<EvaluatorListItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Search, Filter & Pagination (BR-18: 15 itens por página)
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("ALL");
  const [typeFilter, setTypeFilter] = useState<string>("ALL");
  const [currentPage, setCurrentPage] = useState(1);
  const PAGE_SIZE = 15;

  // Auto-Balance Modal State
  const [isAutoBalancing, setIsAutoBalancing] = useState(false);
  const [balanceSummary, setBalanceSummary] =
    useState<AutoBalanceSummaryResponse | null>(null);
  const [isBalanceModalOpen, setIsBalanceModalOpen] = useState(false);

  // Manual Allocation Modal State
  const [isManualModalOpen, setIsManualModalOpen] = useState(false);
  const [manualProjectId, setManualProjectId] = useState<number | "">("");
  const [manualEvaluatorId, setManualEvaluatorId] = useState<number | "">("");
  const [isSubmittingManual, setIsSubmittingManual] = useState(false);
  const [manualModalError, setManualModalError] = useState<string | null>(null);
  const [manualCategoryWarning, setManualCategoryWarning] = useState<string | null>(null);
  const [manualOverrideConflict, setManualOverrideConflict] = useState(false);

  // Load Allocations & Projects for Active Event
  async function loadData() {
    if (!activeEvent) return;

    setIsLoading(true);
    setError(null);
    try {
      const [allocData, projData, evalsData] = await Promise.all([
        allocationService.listAllocations(activeEvent.id),
        projectService.getProjects({ event_id: activeEvent.id }),
        allocationService.getEvaluators(activeEvent.id),
      ]);
      setAllocations(allocData);
      setProjects(projData);
      setEvaluators(evalsData);
    } catch (err: any) {
      setError(
        err.response?.data?.detail || "Erro ao carregar dados de alocação de avaliadores."
      );
    } finally {
      setIsLoading(false);
    }
  }

  const selectedEvaluator = useMemo(() => {
    return evaluators.find((e) => e.id === Number(manualEvaluatorId)) || null;
  }, [evaluators, manualEvaluatorId]);

  const selectedEvaluatorSubareaIds = useMemo(() => {
    return selectedEvaluator?.subareas.map((s) => s.subarea_id) || [];
  }, [selectedEvaluator]);

  const availableManualProjects = useMemo(() => {
    if (!manualEvaluatorId || selectedEvaluatorSubareaIds.length === 0) return [];
    return projects.filter((p) => {
      const matchSubarea = selectedEvaluatorSubareaIds.includes(p.subarea_id);
      const evalLevels = selectedEvaluator?.education_levels;
      const matchLevel =
        !evalLevels ||
        evalLevels.length === 0 ||
        evalLevels.includes(p.education_level);
      return matchSubarea && matchLevel;
    });
  }, [projects, manualEvaluatorId, selectedEvaluatorSubareaIds, selectedEvaluator]);

  const handleEvaluatorChange = (eId: number | "") => {
    setManualEvaluatorId(eId);
    setManualProjectId("");
    setManualModalError(null);
    setManualCategoryWarning(null);
    setManualOverrideConflict(false);
  };

  const handleManualProjectChange = (pId: number | "") => {
    setManualProjectId(pId);
    setManualModalError(null);
    setManualCategoryWarning(null);
    setManualOverrideConflict(false);
  };

  useEffect(() => {
    loadData();
  }, [activeEvent?.id]);

  // Reset page when filters change
  useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm, statusFilter, typeFilter]);

  // Handle Auto-Balance
  const handleAutoBalance = async () => {
    if (!activeEvent) return;
    setIsAutoBalancing(true);
    setError(null);
    setSuccessMessage(null);
    try {
      const result = await allocationService.autoBalance(activeEvent.id);
      setBalanceSummary(result);
      setIsBalanceModalOpen(true);
      await loadData();
    } catch (err: any) {
      setError(
        err.response?.data?.detail || "Erro ao executar reequilíbrio automático."
      );
    } finally {
      setIsAutoBalancing(false);
    }
  };

  // Handle Manual Allocation
  const handleManualSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeEvent || !manualProjectId || !manualEvaluatorId) return;

    setIsSubmittingManual(true);
    setManualModalError(null);
    try {
      await allocationService.manualAllocate({
        event_id: activeEvent.id,
        project_id: Number(manualProjectId),
        evaluator_id: Number(manualEvaluatorId),
        override_conflict: manualOverrideConflict,
      });
      setIsManualModalOpen(false);
      setManualProjectId("");
      setManualEvaluatorId("");
      setManualCategoryWarning(null);
      setManualOverrideConflict(false);
      setSuccessMessage(
        manualOverrideConflict
          ? "Alocação manual realizada com autorização excepcional (override) registrada!"
          : "Alocação manual realizada com sucesso!"
      );
      await loadData();
    } catch (err: any) {
      if (err.response?.status === 409) {
        setManualCategoryWarning(
          err.response?.data?.detail ||
            "Conflito de interesses por categoria detectado. O avaliador orienta projeto concorrente nesta categoria."
        );
        setManualModalError(null);
      } else {
        setManualModalError(
          err.response?.data?.detail ||
            "Erro ao alocar manualmente. Verifique conflitos de interesse, subárea ou carga máxima."
        );
        setManualCategoryWarning(null);
      }
    } finally {
      setIsSubmittingManual(false);
    }
  };

  // Handle Cancel Allocation
  const handleCancel = async (allocationId: number) => {
    if (!confirm("Tem certeza que deseja cancelar esta alocação de avaliação?")) return;
    try {
      await allocationService.cancelAllocation(allocationId);
      setSuccessMessage("Alocação cancelada com sucesso.");
      await loadData();
    } catch (err: any) {
      setError(err.response?.data?.detail || "Erro ao cancelar alocação.");
    }
  };

  // Filtered Allocations
  const filteredAllocations = useMemo(() => {
    return allocations.filter((a) => {
      const q = searchTerm.toLowerCase();
      const matchesSearch =
        !searchTerm ||
        a.project_title.toLowerCase().includes(q) ||
        a.evaluator_name.toLowerCase().includes(q) ||
        a.subarea_name.toLowerCase().includes(q) ||
        (a.booth_number && a.booth_number.toLowerCase().includes(q));

      // Se statusFilter for "ALL", exibe apenas alocações ativas (desconsiderando canceladas).
      // Se statusFilter for "CANCELLED", exibe apenas as alocações canceladas.
      const matchesStatus =
        statusFilter === "ALL"
          ? a.status !== "CANCELLED"
          : a.status === statusFilter;

      const matchesType =
        typeFilter === "ALL" || a.allocation_type === typeFilter;

      return matchesSearch && matchesStatus && matchesType;
    });
  }, [allocations, searchTerm, statusFilter, typeFilter]);

  // Paginated Allocations
  const totalPages = Math.max(1, Math.ceil(filteredAllocations.length / PAGE_SIZE));
  const paginatedAllocations = useMemo(() => {
    const from = (currentPage - 1) * PAGE_SIZE;
    return filteredAllocations.slice(from, from + PAGE_SIZE);
  }, [filteredAllocations, currentPage]);

  // Stats calculation
  const presentProjectsCount = useMemo(() => {
    return projects.filter((p) => p.status === "PRESENT").length;
  }, [projects]);

  const activeAllocations = useMemo(() => {
    return allocations.filter((a) => a.status !== "CANCELLED");
  }, [allocations]);

  const completedAllocationsCount = useMemo(() => {
    return allocations.filter((a) => a.status === "COMPLETED").length;
  }, [allocations]);

  const cancelledAllocationsCount = useMemo(() => {
    return allocations.filter((a) => a.status === "CANCELLED").length;
  }, [allocations]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white flex items-center gap-2.5">
            <Users className="text-blue-600 dark:text-blue-400" size={26} />
            Alocação de Avaliadores
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            Alocação dinâmica contínua no check-in, algoritmo balanceado de carga (Δ ≤ 1) e remanejamento manual.
          </p>
        </div>

        {/* Header Controls */}
        <div className="flex flex-wrap items-center gap-2.5">
          <Link href="/evaluators/checkin">
            <Button
              variant="outline"
              size="md"
              className="bg-emerald-50 hover:bg-emerald-100 text-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-800 font-medium"
            >
              <QrCode size={16} className="mr-1.5 text-emerald-600 dark:text-emerald-400" />
              Check-in de Avaliadores (CPF / Crachá)
            </Button>
          </Link>

          <Button
            variant="outline"
            size="md"
            onClick={() => {
              setManualModalError(null);
              setIsManualModalOpen(true);
            }}
          >
            <Plus size={16} className="mr-1.5" />
            Alocar Manualmente
          </Button>

          <Button
            variant="primary"
            size="md"
            onClick={handleAutoBalance}
            isLoading={isAutoBalancing}
          >
            <Scale size={16} className="mr-1.5" />
            Rebalancear Sistema
          </Button>

          <Button
            variant="outline"
            size="md"
            onClick={loadData}
            title="Recarregar dados"
          >
            <RefreshCw size={15} />
          </Button>
        </div>
      </div>

      {/* Alerts */}
      {error && (
        <div className="p-4 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 text-red-700 dark:text-red-300 text-sm flex items-center gap-3">
          <AlertCircle size={18} className="flex-shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {successMessage && (
        <div className="p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900 text-emerald-700 dark:text-emerald-300 text-sm flex items-center gap-3">
          <CheckCircle2 size={18} className="flex-shrink-0" />
          <span>{successMessage}</span>
        </div>
      )}

      {/* Quick Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-5 flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                Total de Alocações
              </p>
              <h3 className="text-2xl font-black text-slate-900 dark:text-white mt-1">
                {activeAllocations.length}
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                {completedAllocationsCount} avaliações concluídas
                {cancelledAllocationsCount > 0 && (
                  <span className="text-slate-400 ml-1">
                    · {cancelledAllocationsCount} cancelada{cancelledAllocationsCount > 1 ? "s" : ""}
                  </span>
                )}
              </p>
            </div>
            <div className="w-10 h-10 rounded-xl bg-blue-50 dark:bg-blue-950 text-blue-600 flex items-center justify-center">
              <Users size={20} />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-5 flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                Trabalhos Homologados
              </p>
              <h3 className="text-2xl font-black text-slate-900 dark:text-white mt-1">
                {projects.length}
              </h3>
              <p className="text-xs text-emerald-600 dark:text-emerald-400 font-semibold mt-1">
                {presentProjectsCount} com presença confirmada
              </p>
            </div>
            <div className="w-10 h-10 rounded-xl bg-teal-50 dark:bg-teal-950 text-teal-600 flex items-center justify-center">
              <MapPin size={20} />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-5 flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                Regra de Ouro (Δ ≤ 1)
              </p>
              <h3 className="text-sm font-bold text-emerald-600 dark:text-emerald-400 mt-2 flex items-center gap-1.5">
                <CheckCircle2 size={16} />
                Ativa e Monitorada
              </h3>
              <p className="text-[11px] text-slate-400 mt-1">
                Equilíbrio de carga por subárea
              </p>
            </div>
            <div className="w-10 h-10 rounded-xl bg-emerald-50 dark:bg-emerald-950 text-emerald-600 flex items-center justify-center">
              <Scale size={20} />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-5 flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                Evento Ativo
              </p>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white mt-1 truncate max-w-[140px]" title={activeEvent?.name}>
                {activeEvent?.name}
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Ano {activeEvent?.year} · ID #{activeEvent?.id}
              </p>
            </div>
            <div className="w-10 h-10 rounded-xl bg-purple-50 dark:bg-purple-950 text-purple-600 flex items-center justify-center">
              <Calendar size={20} />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Allocations Table Card */}
      <Card>
        <CardHeader className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3">
          <div>
            <CardTitle>Quadro de Alocações de Avaliação</CardTitle>
            <CardDescription>
              {statusFilter === "CANCELLED"
                ? `Mostrando ${filteredAllocations.length} de ${cancelledAllocationsCount} alocações canceladas no evento.`
                : `Mostrando ${filteredAllocations.length} de ${activeAllocations.length} alocações ativas no evento.`}
            </CardDescription>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            {/* Search */}
            <div className="relative">
              <Search
                size={14}
                className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400"
              />
              <input
                type="text"
                placeholder="Buscar projeto, avaliador, estande..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-8 pr-3 py-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg text-xs text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 w-48 sm:w-64"
              />
            </div>

            {/* Status Filter */}
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-2.5 py-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/20"
            >
              <option value="ALL">Todas as Ativas</option>
              <option value="PENDING">Pendente</option>
              <option value="COMPLETED">Avaliado (Concluída)</option>
              <option value="CANCELLED">Cancelada</option>
            </select>

            {/* Type Filter */}
            <select
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value)}
              className="px-2.5 py-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/20"
            >
              <option value="ALL">Todas as Origens</option>
              <option value="AUTOMATIC_CHECKIN">Check-in Dinâmico</option>
              <option value="MANUAL">Manual</option>
            </select>
          </div>
        </CardHeader>

        <CardContent className="p-0">
          {isLoading ? (
            <div className="py-12 text-center text-sm text-slate-500">
              Carregando alocações...
            </div>
          ) : filteredAllocations.length === 0 ? (
            <div className="py-12 text-center text-sm text-slate-500">
              Nenhuma alocação encontrada para os critérios selecionados.
            </div>
          ) : (
            <>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead className="bg-slate-50 dark:bg-slate-800/50 border-y border-slate-200 dark:border-slate-800 text-xs font-semibold text-slate-500 uppercase tracking-wider">
                    <tr>
                      <th className="py-3 px-4">Estande</th>
                      <th className="py-3 px-4">Trabalho Científico</th>
                      <th className="py-3 px-4">Subárea</th>
                      <th className="py-3 px-4">Avaliador</th>
                      <th className="py-3 px-4">Origem</th>
                      <th className="py-3 px-4">Status</th>
                      <th className="py-3 px-4 text-right">Ação</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 dark:divide-slate-800 text-xs">
                    {paginatedAllocations.map((alloc) => (
                      <tr
                        key={alloc.id}
                        className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors"
                      >
                        <td className="py-3 px-4 font-mono font-bold text-blue-600 dark:text-blue-400 whitespace-nowrap">
                          {alloc.booth_number ? (
                            <span className="bg-blue-50 dark:bg-blue-950 px-2 py-0.5 rounded border border-blue-200 dark:border-blue-900">
                              {alloc.booth_number}
                            </span>
                          ) : (
                            <span className="text-slate-400">—</span>
                          )}
                        </td>

                        <td className="py-3 px-4">
                          <div className="font-semibold text-slate-900 dark:text-white line-clamp-1 max-w-sm" title={alloc.project_title}>
                            {alloc.project_title}
                          </div>
                          <div className="text-[11px] text-slate-400 font-mono">
                            ID: #{alloc.project_id}
                          </div>
                        </td>

                        <td className="py-3 px-4 whitespace-nowrap">
                          <div className="font-medium text-slate-900 dark:text-white">
                            {alloc.subarea_name}
                          </div>
                          {alloc.area_name && (
                            <div className="text-[11px] text-slate-400">
                              {alloc.area_name}
                            </div>
                          )}
                        </td>

                        <td className="py-3 px-4 whitespace-nowrap">
                          <div className="font-medium text-slate-900 dark:text-white">
                            {alloc.evaluator_name}
                          </div>
                          <div className="text-[11px] text-slate-400 font-mono">
                            ID: #{alloc.evaluator_id}
                          </div>
                        </td>

                        <td className="py-3 px-4 whitespace-nowrap">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[11px] font-medium ${
                              alloc.allocation_type === "AUTOMATIC_CHECKIN"
                                ? "bg-teal-50 dark:bg-teal-950 text-teal-700 dark:text-teal-300 border border-teal-200 dark:border-teal-800"
                                : "bg-indigo-50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800"
                            }`}
                          >
                            {alloc.allocation_type === "AUTOMATIC_CHECKIN"
                              ? "Check-in Dinâmico"
                              : "Manual"}
                          </span>
                        </td>

                        <td className="py-3 px-4 whitespace-nowrap">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[11px] font-medium ${
                              alloc.status === "COMPLETED"
                                ? "bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800"
                                : alloc.status === "CANCELLED"
                                ? "bg-red-50 dark:bg-red-950 text-red-700 dark:text-red-300 border border-red-200 dark:border-red-800"
                                : "bg-amber-50 dark:bg-amber-950 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800"
                            }`}
                          >
                            {alloc.status === "COMPLETED"
                              ? "Avaliado"
                              : alloc.status === "CANCELLED"
                              ? "Cancelada"
                              : "Pendente"}
                          </span>
                        </td>

                        <td className="py-3 px-4 text-right whitespace-nowrap">
                          {alloc.status === "PENDING" && (
                            <button
                              title="Cancelar Alocação"
                              onClick={() => handleCancel(alloc.id)}
                              className="p-1.5 text-red-500 hover:bg-red-50 dark:hover:bg-red-950/40 rounded-lg transition-colors"
                            >
                              <Trash2 size={15} />
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Paginação Real (BR-18: 15 itens por página) */}
              <div className="p-4 border-t border-slate-200 dark:border-slate-800">
                <Pagination
                  currentPage={currentPage}
                  totalPages={totalPages}
                  totalItems={filteredAllocations.length}
                  limit={PAGE_SIZE}
                  onPageChange={setCurrentPage}
                  isLoading={isLoading}
                />
              </div>
            </>
          )}
        </CardContent>
      </Card>

      {/* Auto-Balance Outcome Modal */}
      <Modal
        isOpen={isBalanceModalOpen}
        onClose={() => setIsBalanceModalOpen(false)}
        title="Resultado do Rebalanceamento Global"
      >
        {balanceSummary && (
          <div className="space-y-4 text-sm">
            <div className="p-3.5 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-xl text-emerald-800 dark:text-emerald-200 text-xs flex items-center gap-2">
              <CheckCircle2 size={18} className="text-emerald-600 flex-shrink-0" />
              <span className="font-medium">{balanceSummary.message}</span>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-3 bg-slate-50 dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-800">
                <span className="text-slate-400 uppercase font-semibold text-[10px]">
                  Trabalhos Presentes
                </span>
                <p className="text-lg font-bold text-slate-900 dark:text-white mt-0.5">
                  {balanceSummary.present_projects_count}
                </p>
              </div>

              <div className="p-3 bg-slate-50 dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-800">
                <span className="text-slate-400 uppercase font-semibold text-[10px]">
                  Avaliadores Presentes
                </span>
                <p className="text-lg font-bold text-slate-900 dark:text-white mt-0.5">
                  {balanceSummary.evaluators_count}
                </p>
              </div>

              <div className="p-3 bg-slate-50 dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-800">
                <span className="text-slate-400 uppercase font-semibold text-[10px]">
                  Novas Alocações
                </span>
                <p className="text-lg font-bold text-blue-600 mt-0.5">
                  +{balanceSummary.total_allocations_created}
                </p>
              </div>

              <div className="p-3 bg-slate-50 dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-800">
                <span className="text-slate-400 uppercase font-semibold text-[10px]">
                  Regra de Ouro (Δ ≤ 1)
                </span>
                <p className="text-base font-bold text-emerald-600 mt-0.5">
                  {balanceSummary.golden_rule_satisfied ? "Satisfeita ✅" : "Pendente ⚠️"}
                </p>
              </div>
            </div>

            <div className="flex justify-end pt-3">
              <Button
                type="button"
                variant="primary"
                onClick={() => setIsBalanceModalOpen(false)}
              >
                Concluir
              </Button>
            </div>
          </div>
        )}
      </Modal>

      {/* Manual Allocation Modal (UX-01 Compliant) */}
      <Modal
        isOpen={isManualModalOpen}
        onClose={() => setIsManualModalOpen(false)}
        title="Alocação / Remanejamento Manual"
        error={manualModalError}
      >
        <form onSubmit={handleManualSubmit} className="space-y-4">
          <p className="text-xs text-slate-500">
            Selecione o avaliador para visualizar suas subáreas qualificadas e os trabalhos científicos compatíveis.
            O sistema valida bloqueio estrito de subárea e ausência de conflito de interesses.
          </p>

          {/* 1. Seleção do Avaliador */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              Avaliador *
            </label>
            <select
              required
              value={manualEvaluatorId}
              onChange={(e) => handleEvaluatorChange(e.target.value ? Number(e.target.value) : "")}
              className="w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/20"
            >
              <option value="">Selecione o avaliador...</option>
              {evaluators.map((ev) => (
                <option key={ev.id} value={ev.id}>
                  {ev.name} ({ev.email}) — {ev.subareas.length} subárea(s)
                  {ev.education_levels && ev.education_levels.length > 0
                    ? ` [${ev.education_levels
                        .map((l) =>
                          l === "MEDIO"
                            ? "Médio"
                            : l === "FUNDAMENTAL"
                            ? "Fund. II"
                            : l === "JUNIOR"
                            ? "Fund. I"
                            : l === "GRADUACAO"
                            ? "Graduação"
                            : "Pós-Grad."
                        )
                        .join(", ")}]`
                    : " [Todos os Níveis]"}
                  {ev.evaluator_presence_confirmed ? " ✅ Presente" : " ⏳ Pendente"}
                </option>
              ))}
            </select>
          </div>

          {/* 2. Feedback de Subáreas e Níveis do Avaliador */}
          {selectedEvaluator && (
            <div className="p-3 bg-slate-50 dark:bg-slate-900/60 rounded-xl border border-slate-200 dark:border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-slate-700 dark:text-slate-300">
                  Subáreas Habilitadas ({selectedEvaluator.subareas.length}):
                </span>
                <span className="text-[11px] text-slate-500">
                  {selectedEvaluator.allocated_projects_count} trabalho(s) já alocado(s)
                </span>
              </div>

              {selectedEvaluator.subareas.length === 0 ? (
                <div className="p-2.5 rounded-lg bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-xs text-amber-800 dark:text-amber-300 flex items-start gap-2">
                  <AlertCircle size={15} className="flex-shrink-0 mt-0.5" />
                  <span>
                    Este avaliador não possui nenhuma subárea vinculada neste evento.
                    Vincule subáreas na tela de{" "}
                    <Link href="/participants" className="underline font-bold">
                      Participantes
                    </Link>{" "}
                    antes de atribuir trabalhos.
                  </span>
                </div>
              ) : (
                <div className="flex flex-wrap gap-1.5">
                  {selectedEvaluator.subareas.map((s) => (
                    <span
                      key={s.subarea_id}
                      className="px-2.5 py-1 rounded-md text-[11px] font-medium bg-blue-50 dark:bg-blue-950/70 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800"
                    >
                      <strong className="font-semibold">{s.area_name}</strong> &gt; {s.subarea_name}
                    </span>
                  ))}
                </div>
              )}

              {/* Níveis de ensino habilitados */}
              <div className="pt-2 border-t border-slate-200/60 dark:border-slate-800/60 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-1 text-xs">
                <span className="font-semibold text-slate-700 dark:text-slate-300">
                  Níveis de Ensino:
                </span>
                <div className="flex flex-wrap gap-1">
                  {!selectedEvaluator.education_levels || selectedEvaluator.education_levels.length === 0 ? (
                    <span className="px-2 py-0.5 rounded text-[10px] font-medium bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                      Universal (Qualquer nível)
                    </span>
                  ) : (
                    selectedEvaluator.education_levels.map((lvl) => (
                      <span
                        key={lvl}
                        className="px-2 py-0.5 rounded text-[10px] font-medium bg-indigo-50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800"
                      >
                        {lvl === "MEDIO"
                          ? "Ensino Médio / Técnico"
                          : lvl === "FUNDAMENTAL"
                          ? "Ensino Fundamental II"
                          : lvl === "JUNIOR"
                          ? "Ensino Fundamental I"
                          : lvl === "GRADUACAO"
                          ? "Graduação / Superior"
                          : "Pós-Graduação"}
                      </span>
                    ))
                  )}
                </div>
              </div>
            </div>
          )}

          {/* 3. Seleção do Trabalho (Filtrado por Subáreas do Avaliador) */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              Trabalho Científico Compatível *
            </label>
            {!manualEvaluatorId ? (
              <div className="p-3 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg text-xs text-slate-400 italic">
                Selecione um avaliador acima para carregar apenas os trabalhos de suas subáreas.
              </div>
            ) : selectedEvaluator && selectedEvaluator.subareas.length === 0 ? (
              <div className="p-3 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg text-xs text-slate-400 italic">
                Avaliador sem subáreas cadastradas.
              </div>
            ) : availableManualProjects.length === 0 ? (
              <div className="p-3 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg text-xs text-slate-500 italic">
                Nenhum trabalho encontrado para as subáreas deste avaliador.
              </div>
            ) : (
              <select
                required
                value={manualProjectId}
                onChange={(e) => handleManualProjectChange(e.target.value ? Number(e.target.value) : "")}
                className="w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/20"
              >
                <option value="">Selecione o trabalho ({availableManualProjects.length} disponíveis)...</option>
                {availableManualProjects.map((p) => (
                  <option key={p.id} value={p.id}>
                    #{p.id} — {p.title} ({p.area_name ? `${p.area_name} > ` : ""}{p.subarea_name}) {p.booth_number ? `[Estande ${p.booth_number}]` : ""} {p.status === "PRESENT" ? "✅ Presente" : "⏳ Pendente"}
                  </option>
                ))}
              </select>
            )}
          </div>

          {manualCategoryWarning && (
            <div className="p-3.5 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-800 text-amber-900 dark:text-amber-200 text-xs space-y-2.5">
              <div className="flex items-start gap-2">
                <ShieldAlert size={16} className="text-amber-600 dark:text-amber-400 flex-shrink-0 mt-0.5" />
                <div>
                  <strong className="block text-amber-800 dark:text-amber-300 font-bold mb-0.5">
                    Conflito de Interesses por Categoria Detectado
                  </strong>
                  <p className="text-[11px] leading-relaxed text-amber-700 dark:text-amber-300/90">
                    {manualCategoryWarning}
                  </p>
                </div>
              </div>

              <label className="flex items-start gap-2 pt-2 border-t border-amber-200/60 dark:border-amber-900/60 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={manualOverrideConflict}
                  onChange={(e) => setManualOverrideConflict(e.target.checked)}
                  className="mt-0.5 rounded border-amber-400 text-amber-600 focus:ring-amber-500"
                />
                <span className="text-[11px] text-amber-900 dark:text-amber-200 font-semibold">
                  Autorizo excepcionalmente esta alocação (Override Administrativo). Estou ciente de que o avaliador orienta trabalho concorrente nesta categoria.
                </span>
              </label>
            </div>
          )}

          <div className="flex justify-end gap-3 pt-3">
            <Button
              type="button"
              variant="outline"
              onClick={() => setIsManualModalOpen(false)}
            >
              Cancelar
            </Button>
            <Button
              type="submit"
              variant="primary"
              disabled={
                !manualProjectId ||
                !manualEvaluatorId ||
                selectedEvaluator?.subareas.length === 0 ||
                (Boolean(manualCategoryWarning) && !manualOverrideConflict)
              }
              isLoading={isSubmittingManual}
              className={manualOverrideConflict ? "bg-amber-600 hover:bg-amber-700 focus:ring-amber-500 text-white" : ""}
            >
              {manualOverrideConflict ? "Confirmar com Override" : "Confirmar Alocação"}
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
