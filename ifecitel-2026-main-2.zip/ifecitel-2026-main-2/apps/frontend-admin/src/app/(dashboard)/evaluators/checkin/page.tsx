"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import {
  ScanBarcode,
  Users,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  MapPin,
  Clock,
  ArrowLeft,
  BookOpen,
  Info,
} from "lucide-react";
import { useActiveEvent } from "../../../../context/EventContext";
import { RequireActiveEvent } from "../../../../components/common/RequireActiveEvent";
import { allocationService } from "../../../../services/allocation.service";
import { participantService } from "../../../../services/participant.service";
import {
  EvaluatorCheckinAllocationResponse,
  EvaluatorListItem,
} from "../../../../types";
import { Button } from "../../../../components/ui/Button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "../../../../components/ui/Card";
import { BarcodeScannerInput } from "../../../../components/ui/BarcodeScannerInput";

export default function EvaluatorCheckinPage() {
  const { activeEvent } = useActiveEvent();

  const [isScanning, setIsScanning] = useState(false);
  const [currentResult, setCurrentResult] =
    useState<EvaluatorCheckinAllocationResponse | null>(null);
  const [lastScannedBarcode, setLastScannedBarcode] = useState<string>("");
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Quick Manual Selection
  const [evaluatorsList, setEvaluatorsList] = useState<EvaluatorListItem[]>([]);
  const [selectedEvaluatorId, setSelectedEvaluatorId] = useState<number | "">("");
  const [isLoadingEvaluators, setIsLoadingEvaluators] = useState(false);

  // Load evaluators for quick selection
  async function loadEvaluators() {
    if (!activeEvent) return;
    setIsLoadingEvaluators(true);
    try {
      const items = await allocationService.getEvaluators(activeEvent.id);
      setEvaluatorsList(items || []);
    } catch (err) {
      console.error("Erro ao carregar lista de avaliadores:", err);
    } finally {
      setIsLoadingEvaluators(false);
    }
  }

  useEffect(() => {
    loadEvaluators();
  }, [activeEvent?.id]);

  const handleScan = async (code: string) => {
    if (!activeEvent) return;

    setIsScanning(true);
    setError(null);
    setSuccessMessage(null);

    try {
      const response = await allocationService.scanCheckinEvaluator(
        code,
        activeEvent.id
      );
      setCurrentResult(response);
      setLastScannedBarcode(code);
      setSuccessMessage(response.message);

      // Refresh evaluators list
      loadEvaluators();
    } catch (err: any) {
      setError(
        err.response?.data?.detail ||
          "Código ou CPF não encontrado ou participante não cadastrado como Avaliador."
      );
      setCurrentResult(null);
    } finally {
      setIsScanning(false);
    }
  };

  const handleManualCheckin = async () => {
    if (!activeEvent || !selectedEvaluatorId) return;

    setIsScanning(true);
    setError(null);
    setSuccessMessage(null);

    try {
      const response = await allocationService.checkinEvaluator(
        Number(selectedEvaluatorId),
        activeEvent.id
      );
      setCurrentResult(response);
      setLastScannedBarcode(
        evaluatorsList.find((e) => e.id === Number(selectedEvaluatorId))?.barcode || ""
      );
      setSuccessMessage(response.message);

      setSelectedEvaluatorId("");
      loadEvaluators();
    } catch (err: any) {
      setError(
        err.response?.data?.detail || "Erro ao realizar check-in do avaliador."
      );
      setCurrentResult(null);
    } finally {
      setIsScanning(false);
    }
  };

  return (
    <RequireActiveEvent>
      <div className="space-y-6 pb-12">
        {/* Top Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-5">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                Posto Exclusivo: Sala da Comissão Científica
              </span>
              <span className="text-xs text-slate-400 dark:text-slate-500">
                Credenciamento & Alocação
              </span>
            </div>
            <h1 className="text-2xl font-black tracking-tight text-slate-900 dark:text-white flex items-center gap-3">
              <Users className="text-emerald-600 dark:text-emerald-400" size={28} />
              Check-in da Sala dos Avaliadores
            </h1>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
              Digite o CPF do avaliador ou utilize o leitor de crachá para confirmar a presença na comissão científica e disparar a alocação dinâmica imediata de trabalhos.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <Link href="/evaluators">
              <Button variant="outline" className="flex items-center gap-2">
                <ArrowLeft size={16} />
                Mapa de Alocações
              </Button>
            </Link>
          </div>
        </div>

        {/* Warning Banner / Instructions */}
        <div className="p-4 bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/50 rounded-xl flex items-start gap-3">
          <Sparkles className="text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" size={20} />
          <div className="text-xs text-emerald-900 dark:text-emerald-200 space-y-1">
            <p className="font-semibold text-sm">
              Controle Isolado da Comissão Julgadora (Avaliadores):
            </p>
            <p>
              • <strong>Separação de equipes e postos:</strong> Esta tela controla exclusivamente a presença dos avaliadores na reunião de alinhamento e a distribuição automática de trabalhos. O credenciamento geral e a entrega de kits/camisetas são gerenciados pela equipe da recepção/logística.
            </p>
            <p>
              • <strong>Avaliadores com múltiplos papéis (ex: Orientador + Avaliador):</strong> Podem realizar seu credenciamento como participante na recepção geral, mas seus trabalhos só são atribuídos quando se apresentarem <strong>aqui nesta sala via CPF ou crachá</strong>.
            </p>
          </div>
        </div>

        {/* Scanner & Manual Selection Row */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Barcode / CPF Scanner */}
          <Card className="lg:col-span-2 border-slate-200 dark:border-slate-800 shadow-sm">
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <ScanBarcode size={20} className="text-emerald-600" />
                Identificação do Avaliador (CPF ou Leitor de Crachá)
              </CardTitle>
              <CardDescription>
                Digite o CPF do avaliador (com ou sem pontuação) ou aproxime o leitor óptico do crachá/QR Code:
              </CardDescription>
            </CardHeader>
            <CardContent>
              <BarcodeScannerInput
                onScan={handleScan}
                disabled={isScanning}
                placeholder="Digite o CPF do avaliador ou aproxime o leitor do crachá..."
                buttonText="Confirmar Check-in"
              />

              {isScanning && (
                <p className="text-xs text-emerald-600 font-medium animate-pulse mt-2 flex items-center gap-1.5">
                  <Clock size={14} /> Processando validação e alocação dinâmica com a Regra de Ouro...
                </p>
              )}
            </CardContent>
          </Card>

          {/* Quick Dropdown Fallback */}
          <Card className="border-slate-200 dark:border-slate-800 shadow-sm">
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <Users size={18} className="text-slate-600 dark:text-slate-400" />
                Seleção Manual Rápida
              </CardTitle>
              <CardDescription>
                Caso não possua o CPF ou crachá em mãos:
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <select
                value={selectedEvaluatorId}
                onChange={(e) => setSelectedEvaluatorId(e.target.value ? Number(e.target.value) : "")}
                disabled={isLoadingEvaluators || isScanning}
                className="w-full text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 rounded-lg p-2.5 focus:ring-2 focus:ring-emerald-500"
              >
                <option value="">Selecione um avaliador...</option>
                {evaluatorsList.map((ev) => (
                  <option key={ev.id} value={ev.id}>
                    {ev.name} {ev.cpf ? `• CPF: ${ev.cpf}` : ""} {ev.evaluator_presence_confirmed ? "(Já Presente)" : "(Pendente)"}
                  </option>
                ))}
              </select>

              <Button
                onClick={handleManualCheckin}
                disabled={!selectedEvaluatorId || isScanning}
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
              >
                Confirmar e Alocar Trabalhos
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Error Feedback */}
        {error && (
          <div className="p-4 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/60 rounded-xl flex items-start gap-3">
            <AlertCircle className="text-rose-600 dark:text-rose-400 shrink-0 mt-0.5" size={20} />
            <div>
              <h4 className="font-semibold text-rose-900 dark:text-rose-200 text-sm">
                Não foi possível realizar o check-in do avaliador
              </h4>
              <p className="text-xs text-rose-700 dark:text-rose-300 mt-0.5">
                {error}
              </p>
            </div>
          </div>
        )}

        {/* Status Message / Notification */}
        {successMessage && currentResult && (
          <div
            className={`p-4 rounded-xl border flex items-start gap-3 shadow-sm ${
              currentResult.already_checked_in
                ? "bg-blue-50 dark:bg-blue-950/40 border-blue-200 dark:border-blue-800 text-blue-950 dark:text-blue-200"
                : "bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-emerald-950 dark:text-emerald-200"
            }`}
          >
            {currentResult.already_checked_in ? (
              <Info className="text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" size={20} />
            ) : (
              <CheckCircle2 className="text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" size={20} />
            )}
            <div>
              <h4 className="font-bold text-sm">
                {currentResult.already_checked_in
                  ? "Avaliador Já Possui Check-in Registrado"
                  : "Check-in Confirmado com Sucesso"}
              </h4>
              <p className="text-xs mt-0.5 opacity-90 leading-relaxed">
                {successMessage}
              </p>
            </div>
          </div>
        )}

        {/* Current Result Card */}
        {currentResult && (
          <Card
            className={`shadow-md transition-all ${
              currentResult.already_checked_in
                ? "border-blue-200 dark:border-blue-800/80 bg-blue-50/15 dark:bg-blue-950/10"
                : "border-emerald-200 dark:border-emerald-800/80 bg-emerald-50/20 dark:bg-emerald-950/10"
            }`}
          >
            <CardHeader
              className={`pb-3 border-b ${
                currentResult.already_checked_in
                  ? "border-blue-100 dark:border-blue-900/50"
                  : "border-emerald-100 dark:border-emerald-900/50"
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center ${
                      currentResult.already_checked_in
                        ? "bg-blue-100 dark:bg-blue-900/50 text-blue-600 dark:text-blue-400"
                        : "bg-emerald-100 dark:bg-emerald-900/50 text-emerald-600 dark:text-emerald-400"
                    }`}
                  >
                    {currentResult.already_checked_in ? <Info size={24} /> : <CheckCircle2 size={24} />}
                  </div>
                  <div>
                    <CardTitle className="text-lg font-bold text-slate-900 dark:text-white">
                      {currentResult.evaluator_name}
                    </CardTitle>
                    <CardDescription className="text-xs">
                      ID Avaliador #{currentResult.evaluator_id} •{" "}
                      {currentResult.already_checked_in
                        ? "Check-in já realizado anteriormente nesta edição"
                        : "Presença na Sala dos Avaliadores Confirmada Agora"}
                    </CardDescription>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  {currentResult.already_checked_in ? (
                    <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300 flex items-center gap-1">
                      <CheckCircle2 size={13} /> Já Credenciado na Sala
                    </span>
                  ) : (
                    <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 dark:bg-emerald-900/60 dark:text-emerald-200 flex items-center gap-1">
                      <CheckCircle2 size={13} /> Check-in Efetuado
                    </span>
                  )}
                  <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-200">
                    {currentResult.allocated_projects_count} trabalho(s) atribuído(s)
                  </span>
                </div>
              </div>
            </CardHeader>

            <CardContent className="pt-4 space-y-4">
              {/* Allocated Projects Section */}
              <div>
                <div className="flex items-center justify-between mb-2.5">
                  <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200 flex items-center gap-2">
                    <BookOpen
                      size={16}
                      className={currentResult.already_checked_in ? "text-blue-600" : "text-emerald-600"}
                    />
                    Trabalhos Atribuídos a este Avaliador ({currentResult.allocated_projects_count})
                  </h3>
                  <span className="text-xs text-slate-400">
                    {currentResult.already_checked_in
                      ? "Trabalhos atualmente sob responsabilidade do avaliador"
                      : "Alocados dinamicamente com base na especialidade e Regra de Ouro"}
                  </span>
                </div>

                {currentResult.allocated_projects.length === 0 ? (
                  <div className="p-4 rounded-lg bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800 text-center text-xs text-slate-500">
                    Nenhum trabalho alocado no momento para as subáreas deste avaliador. Novos trabalhos poderão ser atribuídos via <strong>Rebalancear Sistema</strong> ou atribuição manual quando novos estandes chegarem.
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {currentResult.allocated_projects.map((proj) => (
                      <div
                        key={proj.project_id}
                        className="p-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg shadow-sm flex flex-col justify-between gap-2"
                      >
                        <div>
                          <div className="flex items-start justify-between gap-2">
                            <span className="text-[11px] font-bold px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                              Projeto #{proj.project_id}
                            </span>
                            <span className="text-[11px] font-bold px-2 py-0.5 rounded bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300 flex items-center gap-1">
                              <MapPin size={11} /> {proj.booth_number || "Estande Pendente"}
                            </span>
                          </div>
                          <h4 className="font-semibold text-sm text-slate-900 dark:text-white mt-1.5 line-clamp-2">
                            {proj.project_title}
                          </h4>
                          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                            Subárea: <strong>{proj.area_name ? `${proj.area_name} > ` : ""}{proj.subarea_name}</strong>
                          </p>
                        </div>
                        <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
                          <span>Cobertura: {proj.current_evaluators_count} avaliador(es)</span>
                          <span className="text-emerald-600 dark:text-emerald-400 font-medium">
                            Status: PENDENTE
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </RequireActiveEvent>
  );
}
