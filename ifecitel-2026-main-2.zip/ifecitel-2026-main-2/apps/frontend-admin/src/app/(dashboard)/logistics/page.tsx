"use client";

import React, { useState } from "react";
import Link from "next/link";
import {
  ScanBarcode,
  PackageCheck,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  Users,
  MapPin,
  Shirt,
  Info,
  Calendar,
  Layers,
} from "lucide-react";
import { useActiveEvent } from "../../../context/EventContext";
import { RequireActiveEvent } from "../../../components/common/RequireActiveEvent";
import { logisticsService } from "../../../services/logistics.service";
import {
  BarcodeScanResponse,
  KitCheckoutResponse,
  ProjectKitsSummaryResponse,
  ScanProjectItem,
} from "../../../types";
import { Button } from "../../../components/ui/Button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "../../../components/ui/Card";
import { BarcodeScannerInput } from "../../../components/ui/BarcodeScannerInput";
import { Modal } from "../../../components/ui/Modal";

const getRoleLabel = (role?: string | null) => {
  if (!role) return "Participante";
  switch (role.toUpperCase()) {
    case "ADVISOR":
      return "Orientador";
    case "COADVISOR":
      return "Coorientador";
    case "STUDENT_LEADER":
      return "Estudante (Líder)";
    case "STUDENT_MEMBER":
    case "STUDENT":
      return "Estudante";
    case "EVALUATOR":
      return "Avaliador";
    case "ADMIN":
      return "Organizador";
    default:
      return role;
  }
};

export default function LogisticsPage() {
  const { activeEvent } = useActiveEvent();

  const [isScanning, setIsScanning] = useState(false);
  const [currentScan, setCurrentScan] = useState<BarcodeScanResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Kit Checkout State
  const [isCheckingOutKit, setIsCheckingOutKit] = useState(false);

  // Project Kits Modal State
  const [isProjectKitsModalOpen, setIsProjectKitsModalOpen] = useState(false);
  const [projectKitsSummary, setProjectKitsSummary] =
    useState<ProjectKitsSummaryResponse | null>(null);
  const [isLoadingProjectKits, setIsLoadingProjectKits] = useState(false);
  const [isCheckingOutProjectKits, setIsCheckingOutProjectKits] = useState(false);
  const [projectKitsModalError, setProjectKitsModalError] = useState<string | null>(null);

  const handleBarcodeScan = async (barcode: string) => {
    if (!activeEvent) return;

    setIsScanning(true);
    setError(null);
    setSuccessMessage(null);

    try {
      const response = await logisticsService.scanBarcode(barcode, activeEvent.id);
      setCurrentScan(response);
      setSuccessMessage(response.message);

      if (response.is_project_scan && response.project_id) {
        handleOpenProjectKits(response.project_id);
      }
    } catch (err: any) {
      setError(
        err.response?.data?.detail || "Código de barras ou CPF não encontrado no sistema."
      );
      setCurrentScan(null);
    } finally {
      setIsScanning(false);
    }
  };

  const handleCheckoutProjectKits = async (projectId: number) => {
    setIsCheckingOutProjectKits(true);
    setProjectKitsModalError(null);

    try {
      const summary = await logisticsService.checkoutProjectKits(projectId);
      setProjectKitsSummary(summary);
      const boothText = summary.booth_number ? ` (Estande ${summary.booth_number})` : "";
      setSuccessMessage(`Pacote do projeto${boothText} entregue com sucesso! Todos os kits da equipe foram baixados.`);

      setCurrentScan((prev) => {
        if (!prev) return null;
        const updatedProjects = (prev.projects || []).map((p) =>
          p.id === projectId ? { ...p, all_kits_delivered: true } : p
        );
        const isPersonInProject = summary.members.some(
          (m) => m.person_id === prev.person_id
        );
        return {
          ...prev,
          kit_delivered: isPersonInProject ? true : prev.kit_delivered,
          projects: updatedProjects,
        };
      });
    } catch (err: any) {
      setProjectKitsModalError(
        err.response?.data?.detail || "Erro ao registrar a entrega coletiva dos kits do projeto."
      );
    } finally {
      setIsCheckingOutProjectKits(false);
    }
  };

  const handleCheckoutKit = async () => {
    if (!currentScan || !activeEvent) return;

    setIsCheckingOutKit(true);
    setError(null);

    try {
      const response: KitCheckoutResponse = await logisticsService.checkoutKit(
        currentScan.barcode,
        activeEvent.id
      );
      setCurrentScan((prev) =>
        prev
          ? {
              ...prev,
              kit_delivered: true,
            }
          : null
      );
      setSuccessMessage(`Kit entregue com sucesso para ${response.person_name}!`);
    } catch (err: any) {
      setError(err.response?.data?.detail || "Erro ao registrar a entrega do kit.");
    } finally {
      setIsCheckingOutKit(false);
    }
  };

  const handleOpenProjectKits = async (projectId: number) => {
    setIsLoadingProjectKits(true);
    setProjectKitsModalError(null);
    setIsProjectKitsModalOpen(true);
    try {
      const summary = await logisticsService.getProjectKits(projectId);
      setProjectKitsSummary(summary);
    } catch (err: any) {
      setProjectKitsModalError(
        err.response?.data?.detail || "Erro ao consultar kits da equipe do trabalho."
      );
    } finally {
      setIsLoadingProjectKits(false);
    }
  };

  return (
    <RequireActiveEvent featureName="a Mesa de Credenciamento e Logística">
      <div className="space-y-6">
        {/* Page Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white flex items-center gap-2.5">
              <ScanBarcode className="text-teal-600 dark:text-teal-400" size={26} />
              Credenciamento Geral de Participantes
            </h1>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
              Posto 1 (Portaria/Recepção): Leitura óptica de estudantes e orientadores, ativação de estandes e entrega de kits aos participantes.
            </p>
          </div>

          {activeEvent && (
            <div className="flex flex-wrap items-center gap-2.5">
              <div className="flex items-center gap-2 px-3.5 py-1.5 rounded-xl border border-blue-200 dark:border-blue-900/60 bg-blue-50/50 dark:bg-blue-950/30">
                <Calendar size={15} className="text-blue-600 dark:text-blue-400" />
                <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                  {activeEvent.name}
                </span>
                <span className="text-xs text-blue-600 dark:text-blue-400 font-semibold">
                  ({activeEvent.year})
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Main Scanner Section */}
        <Card className="border-teal-500/30 dark:border-teal-500/20 shadow-lg shadow-teal-500/5">
          <CardContent className="p-6">
            <div className="max-w-xl mx-auto space-y-4 text-center">
              <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-teal-50 dark:bg-teal-950/50 text-teal-600 dark:text-teal-400 mb-1">
                <ScanBarcode size={24} />
              </div>
              <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                Leitor Contínuo de Credenciais
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Aponte o leitor óptico USB/Bluetooth para o crachá ou digite o código de barras / CPF do participante.
              </p>

              <div className="pt-2">
                <BarcodeScannerInput
                  onScan={handleBarcodeScan}
                  placeholder="Bipe o código de barras do crachá ou digite o CPF..."
                  disabled={isScanning}
                  autoFocus={true}
                />
              </div>

              {isScanning && (
                <p className="text-xs text-teal-600 font-medium animate-pulse">
                  Processando credencial e registrando presença...
                </p>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Global Page Alerts */}
        {error && (
          <div className="p-4 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 text-red-700 dark:text-red-300 text-sm flex items-center gap-3">
            <AlertCircle size={18} className="flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {successMessage && (
          <div className="p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900 text-emerald-700 dark:text-emerald-300 text-sm flex items-center gap-3">
            <CheckCircle2 size={18} className="flex-shrink-0" />
            <span>{successMessage}</span>
          </div>
        )}

        {/* Result Card: Scanned Participant */}
        {currentScan && (
          <Card className="border-2 border-blue-500/20 bg-gradient-to-br from-white to-blue-50/30 dark:from-slate-900 dark:to-blue-950/20">
            <CardHeader className="pb-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <span className="text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
                    {currentScan.is_project_scan ? "Pacote do Estande Identificado" : "Credencial Identificada"}
                  </span>
                  <CardTitle className="text-xl mt-0.5">
                    {currentScan.is_project_scan ? currentScan.project_title : currentScan.person_name}
                  </CardTitle>
                  <CardDescription className="flex items-center gap-2 mt-1">
                    {currentScan.is_project_scan ? (
                      <>
                        <span className="font-semibold text-slate-700 dark:text-slate-300">
                          Estande: {currentScan.booth_number || "A definir"}
                        </span>
                        <span>•</span>
                        <span className="font-mono text-xs text-slate-500">
                          Código do Estande: {currentScan.barcode}
                        </span>
                      </>
                    ) : (
                      <>
                        <span className="font-semibold text-slate-700 dark:text-slate-300">
                          Função: {currentScan.person_role}
                        </span>
                        <span>•</span>
                        <span className="font-mono text-xs text-slate-500">
                          Código: {currentScan.barcode}
                        </span>
                      </>
                    )}
                  </CardDescription>
                </div>

                <div className="flex items-center gap-2">
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-200 border border-emerald-200 dark:border-emerald-800">
                    <CheckCircle2 size={14} />
                    {currentScan.is_project_scan ? "Estande Ativo / Presente" : "Presença Confirmada"}
                  </span>

                  {!currentScan.is_project_scan && (
                    currentScan.kit_delivered ? (
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-blue-100 dark:bg-blue-950 text-blue-800 dark:text-blue-200 border border-blue-200 dark:border-blue-800">
                        <PackageCheck size={14} />
                        Kit Já Entregue
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-200 border border-amber-200 dark:border-amber-800">
                        <Shirt size={14} />
                        Kit Pendente
                      </span>
                    )
                  )}
                </div>
              </div>
            </CardHeader>

            <CardContent className="space-y-4 pt-2">
              {currentScan.message && currentScan.message.includes("Avaliador") && (
                <div className="p-3.5 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/60 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-emerald-900 dark:text-emerald-200 shadow-sm">
                  <div>
                    <strong>Participante com Papel de Avaliador:</strong> A presença no evento e no projeto foi registrada. Para receber instruções da comissão e trabalhos para avaliação, compareça à <strong>Sala dos Avaliadores</strong>.
                  </div>
                  <Link href="/evaluators/checkin">
                    <Button size="sm" variant="outline" className="text-xs shrink-0 bg-white dark:bg-slate-900 border-emerald-300 dark:border-emerald-700 hover:bg-emerald-100">
                      Ir para Sala dos Avaliadores →
                    </Button>
                  </Link>
                </div>
              )}

              {/* Computar lista de projetos vinculados */}
              {(() => {
                const projectsList: ScanProjectItem[] =
                  currentScan.projects && currentScan.projects.length > 0
                    ? currentScan.projects
                    : currentScan.project_title
                    ? [
                        {
                          id: currentScan.project_id!,
                          title: currentScan.project_title,
                          booth_number: currentScan.booth_number,
                          status: currentScan.project_status || "PRESENT",
                          subarea_name: null,
                          area_name: null,
                          role_in_project: currentScan.person_role,
                          all_kits_delivered: false,
                        },
                      ]
                    : [];

                return (
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {/* Logistics Details */}
                      {currentScan.is_project_scan ? (
                        <div className="p-4 bg-white dark:bg-slate-800/80 rounded-xl border border-teal-200 dark:border-teal-700/60 space-y-2 flex flex-col justify-between">
                          <div className="space-y-2">
                            <h3 className="text-xs font-bold uppercase tracking-wider text-teal-600 flex items-center gap-1.5">
                              <PackageCheck size={14} className="text-teal-600" />
                              Entrega do Pacote de Kits do Estande
                            </h3>
                            <p className="text-xs text-slate-600 dark:text-slate-400">
                              Qualquer integrante da equipe (orientador ou estudantes) pode retirar o pacote completo de kits na portaria.
                            </p>
                          </div>
                          <div className="pt-2">
                            <Button
                              variant="primary"
                              onClick={() => handleOpenProjectKits(currentScan.project_id!)}
                              className="w-full bg-teal-600 hover:bg-teal-700 text-white font-semibold py-2.5 shadow-sm text-xs"
                            >
                              <Users size={16} className="mr-2" />
                              Ver e Entregar Kits da Equipe
                            </Button>
                          </div>
                        </div>
                      ) : (
                        <div className="p-4 bg-white dark:bg-slate-800/80 rounded-xl border border-slate-200 dark:border-slate-700/60 space-y-2 flex flex-col justify-between">
                          <div className="space-y-2">
                            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                              <Shirt size={14} className="text-teal-600" />
                              Camiseta e Logística do Participante
                            </h3>
                            <div className="flex items-baseline gap-2">
                              <span className="text-sm text-slate-600 dark:text-slate-400">
                                Tamanho da Camiseta:
                              </span>
                              <span className="text-lg font-black text-teal-600 dark:text-teal-400 font-mono">
                                {currentScan.tshirt_size || "M"}
                              </span>
                            </div>
                          </div>

                          <div className="pt-2">
                            {!currentScan.kit_delivered ? (
                              <Button
                                variant="primary"
                                onClick={handleCheckoutKit}
                                disabled={isCheckingOutKit}
                                className="w-full bg-teal-600 hover:bg-teal-700 text-white font-semibold py-2.5 shadow-sm text-xs"
                              >
                                <PackageCheck size={16} className="mr-2" />
                                {isCheckingOutKit
                                  ? "Registrando entrega..."
                                  : "Entregar Camiseta / Dar Baixa no Kit"}
                              </Button>
                            ) : (
                              <div className="text-center py-2 text-xs font-semibold text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/50 rounded-lg border border-emerald-200 dark:border-emerald-800 flex items-center justify-center gap-1.5">
                                <CheckCircle2 size={14} /> Kit entregue com sucesso para este participante.
                              </div>
                            )}
                          </div>
                        </div>
                      )}

                      {/* Project Details */}
                      {currentScan.is_project_scan ? (
                        <div className="p-4 bg-white dark:bg-slate-800/80 rounded-xl border border-slate-200 dark:border-slate-700/60 space-y-2.5 flex flex-col justify-between">
                          <div className="space-y-2">
                            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                              <MapPin size={14} className="text-blue-600" />
                              Trabalho Científico do Estande
                            </h3>
                            <p className="text-sm font-bold text-slate-900 dark:text-white line-clamp-2">
                              {currentScan.project_title}
                            </p>
                            <div className="flex flex-wrap items-center gap-2 text-xs">
                              <span className="font-bold text-slate-800 dark:text-slate-200 bg-slate-100 dark:bg-slate-700/60 px-2 py-0.5 rounded">
                                Estande: {currentScan.booth_number || "A definir"}
                              </span>
                              <span className="font-semibold text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950 px-2 py-0.5 rounded border border-emerald-200 dark:border-emerald-800">
                                {currentScan.project_status}
                              </span>
                            </div>
                          </div>
                          <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
                            <span className="text-slate-500">Status dos Kits do Estande:</span>
                            {projectsList[0]?.all_kits_delivered ? (
                              <span className="inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-semibold">
                                <CheckCircle2 size={13} /> Todos os kits entregues
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 text-amber-600 dark:text-amber-400 font-semibold">
                                <Shirt size={13} /> Kits pendentes
                              </span>
                            )}
                          </div>
                        </div>
                      ) : projectsList.length === 0 ? (
                        <div className="p-4 bg-white dark:bg-slate-800/80 rounded-xl border border-slate-200 dark:border-slate-700/60 flex items-center justify-center text-center">
                          <p className="text-xs text-slate-400">
                            Participante sem trabalho científico diretamente vinculado (ou avaliador/comissão).
                          </p>
                        </div>
                      ) : projectsList.length === 1 ? (
                        /* Single Project Linked */
                        <div className="p-4 bg-white dark:bg-slate-800/80 rounded-xl border border-slate-200 dark:border-slate-700/60 space-y-2.5 flex flex-col justify-between">
                          <div className="space-y-2">
                            <div className="flex items-center justify-between">
                              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                                <MapPin size={14} className="text-blue-600" />
                                Trabalho Científico Vinculado
                              </h3>
                              <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-blue-50 dark:bg-blue-950 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800">
                                {getRoleLabel(projectsList[0].role_in_project || currentScan.person_role)}
                              </span>
                            </div>
                            <p className="text-sm font-bold text-slate-900 dark:text-white line-clamp-2">
                              {projectsList[0].title}
                            </p>
                            <div className="flex flex-wrap items-center gap-2 text-xs">
                              <span className="font-bold text-slate-800 dark:text-slate-200 bg-slate-100 dark:bg-slate-700/60 px-2 py-0.5 rounded">
                                Estande: {projectsList[0].booth_number || "A definir"}
                              </span>
                              <span className="font-semibold text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950 px-2 py-0.5 rounded border border-emerald-200 dark:border-emerald-800">
                                {projectsList[0].status}
                              </span>
                            </div>
                            {projectsList[0].subarea_name && (
                              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                                Área: <span className="font-medium text-slate-700 dark:text-slate-300">{projectsList[0].area_name ? `${projectsList[0].area_name} > ` : ""}{projectsList[0].subarea_name}</span>
                              </p>
                            )}

                            {currentScan.collective_presence_triggered && (
                              <div className="p-2 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200 text-xs flex items-start gap-2">
                                <Sparkles size={14} className="text-emerald-600 flex-shrink-0 mt-0.5" />
                                <span>
                                  <strong>Presença Coletiva Confirmada:</strong> O trabalho foi promovido para <strong>Presente</strong> e está liberado para avaliação!
                                </span>
                              </div>
                            )}
                          </div>

                          <div className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-2">
                            <div className="flex items-center justify-between text-xs">
                              <span className="text-slate-500">Status dos Kits:</span>
                              {projectsList[0].all_kits_delivered ? (
                                <span className="inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-semibold">
                                  <CheckCircle2 size={13} /> Todos os kits entregues
                                </span>
                              ) : (
                                <span className="inline-flex items-center gap-1 text-amber-600 dark:text-amber-400 font-semibold">
                                  <Shirt size={13} /> Kits pendentes
                                </span>
                              )}
                            </div>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleOpenProjectKits(projectsList[0].id)}
                              className="w-full text-xs font-semibold hover:bg-teal-50 dark:hover:bg-teal-950/40 hover:text-teal-700 dark:hover:text-teal-300 hover:border-teal-300 dark:hover:border-teal-700"
                            >
                              <Users size={14} className="mr-1.5 text-teal-600" />
                              Ver e Entregar Kits da Equipe (Estande {projectsList[0].booth_number || projectsList[0].id})
                            </Button>
                          </div>
                        </div>
                      ) : (
                        /* Multiple Projects Summary in Right Column */
                        <div className="p-4 bg-white dark:bg-slate-800/80 rounded-xl border border-blue-200 dark:border-blue-900/60 space-y-2.5 flex flex-col justify-between">
                          <div className="space-y-2">
                            <h3 className="text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400 flex items-center gap-1.5">
                              <Layers size={14} />
                              Múltiplos Trabalhos Vinculados ({projectsList.length})
                            </h3>
                            <p className="text-xs text-slate-600 dark:text-slate-400">
                              Este participante faz parte de <strong>{projectsList.length} trabalhos científicos</strong> nesta edição. A presença em todos os estandes foi confirmada simultaneamente.
                            </p>
                            <div className="flex flex-wrap gap-1.5 pt-1">
                              {projectsList.map((p) => (
                                <span
                                  key={p.id}
                                  className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-bold bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800"
                                >
                                  <MapPin size={11} /> Estande {p.booth_number || "A definir"}
                                </span>
                              ))}
                            </div>
                            {currentScan.collective_presence_triggered && (
                              <div className="p-2 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200 text-xs flex items-start gap-1.5 mt-2">
                                <Sparkles size={14} className="text-emerald-600 flex-shrink-0 mt-0.5" />
                                <span>
                                  <strong>Presença Coletiva Confirmada:</strong> Todos os trabalhos foram promovidos para <strong>Presente</strong>!
                                </span>
                              </div>
                            )}
                          </div>
                          <div className="text-[11px] text-slate-500 font-medium pt-2 border-t border-slate-100 dark:border-slate-800">
                            ↓ Veja abaixo a lista de estandes para triagem e entrega dos kits individuais de cada equipe.
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Dedicated Section for Multiple Projects */}
                    {projectsList.length > 1 && !currentScan.is_project_scan && (
                      <div className="pt-3 border-t border-slate-200 dark:border-slate-800 space-y-3">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                          <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                            <Layers size={16} className="text-blue-600 dark:text-blue-400" />
                            Trabalhos Científicos do Participante e Entrega dos Kits ({projectsList.length})
                          </h3>
                          <span className="text-xs text-slate-500">
                            Consulte os integrantes e retire os kits da equipe de cada bancada individualmente:
                          </span>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                          {projectsList.map((proj) => (
                            <div
                              key={proj.id}
                              className="p-4 bg-white dark:bg-slate-800/90 rounded-xl border border-slate-200 dark:border-slate-700/80 shadow-sm space-y-2.5 flex flex-col justify-between"
                            >
                              <div className="space-y-2">
                                <div className="flex flex-wrap items-center justify-between gap-1.5">
                                  <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md text-xs font-bold bg-blue-100 dark:bg-blue-950 text-blue-800 dark:text-blue-300 border border-blue-200 dark:border-blue-800">
                                    <MapPin size={12} /> Estande {proj.booth_number || "A definir"}
                                  </span>
                                  <div className="flex items-center gap-1.5">
                                    {proj.role_in_project && (
                                      <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300">
                                        {getRoleLabel(proj.role_in_project)}
                                      </span>
                                    )}
                                    <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                                      {proj.status}
                                    </span>
                                  </div>
                                </div>
                                <p className="text-sm font-bold text-slate-900 dark:text-white line-clamp-2">
                                  {proj.title}
                                </p>
                                {proj.subarea_name && (
                                  <p className="text-xs text-slate-500 dark:text-slate-400">
                                    Área:{" "}
                                    <span className="font-medium text-slate-700 dark:text-slate-300">
                                      {proj.area_name ? `${proj.area_name} > ` : ""}
                                      {proj.subarea_name}
                                    </span>
                                  </p>
                                )}
                              </div>

                              <div className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-2">
                                <div className="flex items-center justify-between text-xs">
                                  <span className="text-slate-500">Status dos Kits:</span>
                                  {proj.all_kits_delivered ? (
                                    <span className="inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-semibold">
                                      <CheckCircle2 size={13} /> Todos os kits entregues
                                    </span>
                                  ) : (
                                    <span className="inline-flex items-center gap-1 text-amber-600 dark:text-amber-400 font-semibold">
                                      <Shirt size={13} /> Kits pendentes
                                    </span>
                                  )}
                                </div>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleOpenProjectKits(proj.id)}
                                  className="w-full text-xs font-semibold hover:bg-teal-50 dark:hover:bg-teal-950/40 hover:text-teal-700 dark:hover:text-teal-300 hover:border-teal-300 dark:hover:border-teal-700"
                                >
                                  <Users size={14} className="mr-1.5 text-teal-600" />
                                  Ver e Entregar Kits da Equipe (Estande {proj.booth_number || proj.id})
                                </Button>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })()}
            </CardContent>
          </Card>
        )}

        {/* Modal: Project Kits Summary (Conforme UX-01: Alertas e erros renderizados dentro do modal) */}
        <Modal
          isOpen={isProjectKitsModalOpen}
          onClose={() => {
            setIsProjectKitsModalOpen(false);
            setProjectKitsModalError(null);
          }}
          title="Kits e Camisetas da Equipe do Trabalho"
          error={projectKitsModalError}
        >
          <div className="space-y-4">

            {isLoadingProjectKits ? (
              <div className="py-8 text-center text-sm text-slate-500 animate-pulse">
                Carregando integrantes e kits da equipe...
              </div>
            ) : projectKitsSummary ? (
              <div className="space-y-4">
                <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-slate-200 dark:border-slate-800">
                  <p className="text-xs font-bold text-slate-800 dark:text-slate-200">
                    {projectKitsSummary.title}
                  </p>
                  <p className="text-[11px] text-slate-500 mt-1">
                    Estande: <strong>{projectKitsSummary.booth_number || "A definir"}</strong> • Total de Integrantes: {projectKitsSummary.members.length}
                  </p>
                  <p className="text-[11px] text-teal-600 dark:text-teal-400 font-medium mt-1">
                    📦 Regra de Logística: Qualquer integrante da equipe pode retirar o pacote completo de kits do projeto na portaria.
                  </p>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500 font-semibold bg-slate-50 dark:bg-slate-800/40">
                        <th className="p-2.5">Nome</th>
                        <th className="p-2.5">Função</th>
                        <th className="p-2.5 text-center">Camiseta</th>
                        <th className="p-2.5 text-center">Presença</th>
                        <th className="p-2.5 text-center">Kit</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 font-medium">
                      {projectKitsSummary.members.map((m) => (
                        <tr key={m.person_id} className="hover:bg-slate-50/50">
                          <td className="p-2.5 font-bold text-slate-900 dark:text-white">
                            {m.name}
                          </td>
                          <td className="p-2.5 text-slate-600 dark:text-slate-400">
                            {m.role === "ADVISOR"
                              ? "Orientador"
                              : m.role === "COADVISOR"
                              ? "Coorientador"
                              : "Estudante"}
                          </td>
                          <td className="p-2.5 text-center font-bold text-teal-600 dark:text-teal-400 font-mono">
                            {m.tshirt_size || "M"}
                          </td>
                          <td className="p-2.5 text-center">
                            {m.presence_confirmed ? (
                              <span className="text-emerald-600 font-semibold">Presente</span>
                            ) : (
                              <span className="text-slate-400">Não chegou</span>
                            )}
                          </td>
                          <td className="p-2.5 text-center">
                            {m.kit_delivered ? (
                              <span className="inline-flex items-center gap-1 text-emerald-600 font-semibold">
                                <CheckCircle2 size={13} /> Entregue
                              </span>
                            ) : (
                              <span className="text-amber-600 font-semibold">Pendente</span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row sm:justify-between sm:items-center gap-3">
                  <div>
                    {projectKitsSummary.members.some((m) => !m.kit_delivered) ? (
                      <Button
                        variant="primary"
                        size="sm"
                        onClick={() => handleCheckoutProjectKits(projectKitsSummary.project_id)}
                        disabled={isCheckingOutProjectKits}
                        className="bg-teal-600 hover:bg-teal-700 text-white font-semibold shadow-sm text-xs"
                      >
                        <PackageCheck size={15} className="mr-1.5" />
                        {isCheckingOutProjectKits
                          ? "Registrando entrega do pacote..."
                          : "Entregar Pacote Completo (Todos os Kits)"}
                      </Button>
                    ) : (
                      <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 flex items-center gap-1.5">
                        <CheckCircle2 size={16} /> Todos os kits da equipe já foram entregues
                      </span>
                    )}
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setIsProjectKitsModalOpen(false);
                      setProjectKitsModalError(null);
                    }}
                  >
                    Fechar
                  </Button>
                </div>
              </div>
            ) : null}
          </div>
        </Modal>
      </div>
    </RequireActiveEvent>
  );
}
