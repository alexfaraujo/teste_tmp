"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  AlertCircle,
  CheckCircle2,
  Mail,
  KeyRound,
  User,
  Building2,
  ShieldCheck,
  ArrowRight,
  ArrowLeft,
  RotateCw,
  Sparkles,
} from "lucide-react";
import { authService } from "../../../services/auth.service";
import { Button } from "../../../components/ui/Button";
import { Input } from "../../../components/ui/Input";
import { ThemeToggle } from "../../../components/layout/ThemeToggle";

export default function RegisterPage() {
  const router = useRouter();

  // Etapa 1: Envio do código | Etapa 2: Confirmação e dados
  const [step, setStep] = useState<1 | 2>(1);

  // Campos do formulário
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [code, setCode] = useState("");
  const [cpf, setCpf] = useState("");
  const [affiliation, setAffiliation] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  // Estados de controle
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [devCode, setDevCode] = useState<string | null>(null);

  // Timer regressivo de 60s para reenvio
  const [resendCooldown, setResendCooldown] = useState(0);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (resendCooldown > 0) {
      timer = setTimeout(() => setResendCooldown((prev) => prev - 1), 1000);
    }
    return () => clearTimeout(timer);
  }, [resendCooldown]);

  // Passo 1: Solicitar código OTP
  const handleRequestCode = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsLoading(true);

    try {
      const res = await authService.requestRegistrationCode(email.trim().toLowerCase(), name.trim());
      setSuccessMessage(`Código de verificação enviado para ${email.trim().toLowerCase()}.`);
      if (res.dev_code) {
        setDevCode(res.dev_code);
        setCode(res.dev_code); // Preenche automaticamente em dev
      }
      setResendCooldown(60);
      setStep(2);
    } catch (err: any) {
      if (err.response?.status === 400 && err.response?.data?.detail) {
        setError(err.response.data.detail);
      } else if (err.response?.status === 429) {
        setError("Um código já foi solicitado recentemente. Aguarde alguns segundos.");
        setStep(2);
      } else {
        setError("Erro ao conectar com o servidor. Verifique se o backend está ativo.");
      }
    } finally {
      setIsLoading(false);
    }
  };

  // Reenviar código
  const handleResendCode = async () => {
    if (resendCooldown > 0) return;
    setError(null);
    setIsLoading(true);

    try {
      const res = await authService.requestRegistrationCode(email.trim().toLowerCase(), name.trim());
      setSuccessMessage("Novo código de verificação enviado!");
      if (res.dev_code) {
        setDevCode(res.dev_code);
        setCode(res.dev_code);
      }
      setResendCooldown(60);
    } catch (err: any) {
      setError(err.response?.data?.detail || "Não foi possível reenviar o código no momento.");
    } finally {
      setIsLoading(false);
    }
  };

  // Passo 2: Validar código e concluir cadastro
  const handleCompleteRegistration = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (password.length < 6) {
      setError("A senha deve possuir pelo menos 6 caracteres.");
      return;
    }

    if (password !== confirmPassword) {
      setError("A confirmação da senha não coincide com a senha digitada.");
      return;
    }

    if (code.trim().length < 8) {
      setError("O código de verificação deve conter 8 caracteres.");
      return;
    }

    setIsLoading(true);

    try {
      await authService.completeRegistration({
        email: email.trim().toLowerCase(),
        code: code.trim().toUpperCase(),
        name: name.trim(),
        password,
        cpf: cpf.trim() || undefined,
        affiliation: affiliation.trim() || undefined,
      });

      // Redireciona imediatamente para a tela de eventos
      router.push("/events");
    } catch (err: any) {
      if (err.response?.data?.detail) {
        setError(err.response.data.detail);
      } else {
        setError("Falha ao concluir o cadastro. Verifique os dados informados.");
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-slate-50 dark:bg-slate-950 transition-colors relative">
      <div className="absolute top-4 right-4">
        <ThemeToggle />
      </div>

      <div className="w-full max-w-lg">
        {/* Brand Header */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-gradient-to-br from-blue-600 to-teal-600 text-white font-black text-2xl shadow-lg shadow-blue-500/20 mb-3">
            E
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
            EasyEvent
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            Plataforma Aberta de Gestão de Feiras e Eventos Científicos
          </p>
        </div>

        {/* Card Principal */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm p-6 sm:p-8 transition-colors">
          {/* Indicador de Passos */}
          <div className="flex items-center justify-between mb-6 pb-4 border-b border-slate-100 dark:border-slate-800">
            <div className="flex items-center gap-2">
              <div
                className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                  step === 1
                    ? "bg-blue-600 text-white shadow-sm shadow-blue-500/30"
                    : "bg-emerald-500 text-white"
                }`}
              >
                {step === 2 ? "✓" : "1"}
              </div>
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                E-mail & Identificação
              </span>
            </div>

            <div className="h-0.5 w-8 bg-slate-200 dark:bg-slate-700 mx-2" />

            <div className="flex items-center gap-2">
              <div
                className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                  step === 2
                    ? "bg-blue-600 text-white shadow-sm shadow-blue-500/30"
                    : "bg-slate-200 dark:bg-slate-800 text-slate-500"
                }`}
              >
                2
              </div>
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                Código & Senha
              </span>
            </div>
          </div>

          {/* Mensagens de Erro / Sucesso */}
          {error && (
            <div className="mb-5 p-3.5 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 text-red-700 dark:text-red-300 text-xs flex items-start gap-2">
              <AlertCircle size={16} className="flex-shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {successMessage && step === 2 && (
            <div className="mb-5 p-3.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900 text-emerald-800 dark:text-emerald-300 text-xs flex items-start gap-2">
              <CheckCircle2 size={16} className="flex-shrink-0 mt-0.5 text-emerald-600 dark:text-emerald-400" />
              <div>
                <p className="font-semibold">{successMessage}</p>
                <p className="text-[11px] mt-0.5 opacity-90">
                  Informe o código de 8 caracteres recebido para confirmar a autenticidade da sua caixa postal.
                </p>
              </div>
            </div>
          )}

          {/* Dica de Desenvolvimento (Dev Code) */}
          {devCode && step === 2 && (
            <div className="mb-5 p-3 rounded-xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900 text-blue-800 dark:text-blue-300 text-xs flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShieldCheck size={16} className="text-blue-600 dark:text-blue-400" />
                <span>
                  Ambiente de Testes: Código OTP é <strong className="font-mono">{devCode}</strong>
                </span>
              </div>
            </div>
          )}

          {/* ETAPA 1: Nome e E-mail */}
          {step === 1 && (
            <form onSubmit={handleRequestCode} className="space-y-4">
              <div>
                <h2 className="text-base font-semibold text-slate-900 dark:text-white">
                  Cadastro de Novo Organizador
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  Informe seu e-mail institucional ou corporativo. Enviaremos um código de verificação com 8 caracteres para confirmar seu acesso com segurança.
                </p>
              </div>

              <Input
                label="Nome Completo"
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Ex: Prof. Carlos Eduardo"
                autoComplete="name"
              />

              <Input
                label="E-mail"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="seu.email@instituicao.edu.br"
                autoComplete="email"
              />

              <Button
                type="submit"
                variant="primary"
                size="lg"
                className="w-full mt-2"
                isLoading={isLoading}
              >
                <span>Enviar Código de Verificação</span>
                <ArrowRight size={16} />
              </Button>
            </form>
          )}

          {/* ETAPA 2: Código OTP, Dados e Senha */}
          {step === 2 && (
            <form onSubmit={handleCompleteRegistration} className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-base font-semibold text-slate-900 dark:text-white">
                    Verificação e Definição de Senha
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                    Digite o código de 8 caracteres enviado para <strong>{email}</strong>.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setStep(1);
                    setError(null);
                  }}
                  className="text-xs text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1"
                >
                  <ArrowLeft size={13} />
                  <span>Trocar</span>
                </button>
              </div>

              {/* Campo de Código OTP em Destaque */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Código de Verificação (8 dígitos) *
                </label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    maxLength={8}
                    value={code}
                    onChange={(e) => setCode(e.target.value.toUpperCase())}
                    placeholder="26ABCD12"
                    className="w-full px-4 py-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-mono text-center text-lg tracking-[0.25em] uppercase font-bold focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div className="flex items-center justify-between mt-1.5">
                  <span className="text-[11px] text-slate-400">
                    Válido por 15 minutos (máx. 5 tentativas)
                  </span>
                  <button
                    type="button"
                    onClick={handleResendCode}
                    disabled={resendCooldown > 0 || isLoading}
                    className="text-[11px] font-medium text-blue-600 dark:text-blue-400 hover:underline disabled:opacity-50 disabled:no-underline flex items-center gap-1"
                  >
                    <RotateCw size={11} className={isLoading ? "animate-spin" : ""} />
                    {resendCooldown > 0 ? `Reenviar em ${resendCooldown}s` : "Reenviar código"}
                  </button>
                </div>
              </div>

              <Input
                label="Nome Completo *"
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Ex: Prof. Carlos Eduardo"
              />

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <Input
                  label="CPF (opcional)"
                  type="text"
                  value={cpf}
                  onChange={(e) => setCpf(e.target.value)}
                  placeholder="000.000.000-00"
                />

                <Input
                  label="Instituição / Campus (opcional)"
                  type="text"
                  value={affiliation}
                  onChange={(e) => setAffiliation(e.target.value)}
                  placeholder="Ex: IFMS Três Lagoas"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <Input
                  label="Senha de Acesso *"
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Mínimo 6 caracteres"
                  autoComplete="new-password"
                />

                <Input
                  label="Confirmar Senha *"
                  type="password"
                  required
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Repita a senha"
                  autoComplete="new-password"
                />
              </div>

              <Button
                type="submit"
                variant="primary"
                size="lg"
                className="w-full mt-2"
                isLoading={isLoading}
              >
                <span>Concluir Cadastro e Acessar Painel</span>
                <CheckCircle2 size={16} />
              </Button>
            </form>
          )}

          {/* Link para Login */}
          <div className="mt-6 pt-4 border-t border-slate-100 dark:border-slate-800 text-center">
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Já possui conta cadastrada?{" "}
              <Link
                href="/login"
                className="font-semibold text-blue-600 dark:text-blue-400 hover:underline"
              >
                Fazer login
              </Link>
            </p>
          </div>
        </div>

        {/* Rodapé Institucional */}
        <div className="mt-6 text-center text-xs text-slate-400 dark:text-slate-500 flex items-center justify-center gap-1.5">
          <Sparkles size={13} className="text-teal-500" />
          <span>Instituto Federal de Mato Grosso do Sul — Campus Três Lagoas</span>
        </div>
      </div>
    </div>
  );
}
