"use client";

import React, { useEffect, useState, useRef, useCallback, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import { Layers, AlertTriangle, Users, CheckCircle2, ShieldAlert } from "lucide-react";
import { dashboardService } from "../../../services/dashboard.service";
import { AdminOverviewResponse } from "../../../types";
import { useActiveEvent } from "../../../context/EventContext";
import { MonitorHeader } from "../../../components/monitor/MonitorHeader";
import { AreaRiskGrid } from "../../../components/dashboard/AreaRiskGrid";

const POLL_INTERVAL = 30; // Segundos

function AreasRiskMonitorContent() {
  const searchParams = useSearchParams();
  const { activeEvent } = useActiveEvent();

  // Event ID prioritariamente da URL paramétrica (?event_id=X), com fallback para o contexto ativo
  const eventIdParam = searchParams.get("event_id");
  const eventId = eventIdParam ? Number(eventIdParam) : activeEvent?.id || null;

  const [data, setData] = useState<AdminOverviewResponse | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [secondsRemaining, setSecondsRemaining] = useState(POLL_INTERVAL);

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Carregamento de dados unificado
  const loadData = useCallback(async (evId: number, isSilent = false) => {
    if (!isSilent) setIsLoading(true);
    else setIsRefreshing(true);

    try {
      const overview = await dashboardService.getAdminOverview(evId);
      setData(overview);
    } catch (err) {
      console.error("Erro ao carregar métricas no monitor de áreas e avaliadores:", err);
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  }, []);

  // Efeito de inicialização com base no eventId
  useEffect(() => {
    if (eventId) {
      loadData(eventId, false);
      setSecondsRemaining(POLL_INTERVAL);
    } else {
      setIsLoading(false);
    }
  }, [eventId, loadData]);

  // Ciclo regressivo de 30 segundos com suporte a pause/retomada e pausa em segundo plano
  useEffect(() => {
    if (!eventId || isPaused) {
      if (timerRef.current) clearInterval(timerRef.current);
      return;
    }

    const handleVisibilityChange = () => {
      if (typeof document !== "undefined" && !document.hidden) {
        setSecondsRemaining(POLL_INTERVAL);
        loadData(eventId, true);
      }
    };

    if (typeof document !== "undefined") {
      document.addEventListener("visibilitychange", handleVisibilityChange);
    }

    timerRef.current = setInterval(() => {
      if (typeof document !== "undefined" && document.hidden) {
        return; // Não desconta nem dispara requisições enquanto a aba estiver em segundo plano
      }

      setSecondsRemaining((prev) => {
        if (prev <= 1) {
          loadData(eventId, true);
          return POLL_INTERVAL;
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
      if (typeof document !== "undefined") {
        document.removeEventListener("visibilitychange", handleVisibilityChange);
      }
    };
  }, [eventId, isPaused, loadData]);

  const handleManualRefresh = () => {
    if (!eventId) return;
    setSecondsRemaining(POLL_INTERVAL);
    loadData(eventId, true);
  };

  if (!eventId) {
    return (
      <div className="flex-1 flex items-center justify-center p-8">
        <div className="max-w-md p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-center space-y-3">
          <AlertTriangle size={32} className="text-amber-500 mx-auto" />
          <h2 className="text-base font-bold text-slate-900 dark:text-white">
            Nenhuma Edição Selecionada
          </h2>
          <p className="text-xs text-slate-500">
            Informe um ID de evento válido na URL (ex: <code className="font-mono font-bold text-blue-600">?event_id=391</code>) ou selecione um evento no painel principal.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col">
      {/* Cabeçalho do Monitor Dedicado */}
      <MonitorHeader
        title="Monitor de Grandes Áreas & Termômetro de Cobertura"
        icon={<Layers size={20} className="text-teal-500" />}
        eventId={eventId}
        eventName={data?.event_name || activeEvent?.name || "Carregando..."}
        secondsRemaining={secondsRemaining}
        totalInterval={POLL_INTERVAL}
        isPaused={isPaused}
        onTogglePause={() => setIsPaused(!isPaused)}
        onRefresh={handleManualRefresh}
        isRefreshing={isRefreshing}
      />

      {/* Conteúdo Principal Full-Width */}
      <main className="flex-1 px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {isLoading ? (
          <div className="p-16 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-center space-y-3">
            <div className="w-10 h-10 border-4 border-teal-500 border-t-transparent rounded-full animate-spin mx-auto" />
            <p className="text-sm font-bold text-slate-700 dark:text-slate-300">
              Sincronizando Diagnóstico de Áreas e Termômetro de Avaliadores...
            </p>
          </div>
        ) : data ? (
          <>
            {/* Banner de Sumário de Capacidade Operacional */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex items-center justify-between">
                <div>
                  <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                    Demanda Total da Feira
                  </span>
                  <span className="text-2xl font-black text-slate-900 dark:text-white font-mono mt-0.5 block">
                    {data.kpis.evaluators.expected_evaluations}
                  </span>
                  <span className="text-[10px] text-slate-400">avaliações regulamentares necessárias</span>
                </div>
                <div className="w-10 h-10 rounded-xl bg-blue-50 dark:bg-blue-950/50 text-blue-600 flex items-center justify-center">
                  <Layers size={20} />
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex items-center justify-between">
                <div>
                  <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                    Capacidade dos Avaliadores Presentes
                  </span>
                  <span className="text-2xl font-black text-emerald-600 dark:text-emerald-400 font-mono mt-0.5 block">
                    {data.kpis.evaluators.total_capacity}
                  </span>
                  <span className="text-[10px] text-slate-400">avaliações que os presentes suportam</span>
                </div>
                <div className="w-10 h-10 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 flex items-center justify-center">
                  <Users size={20} />
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex items-center justify-between">
                <div>
                  <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                    Déficit Global Estimado
                  </span>
                  <span className={`text-2xl font-black font-mono mt-0.5 block ${
                    data.kpis.evaluators.global_deficit_evaluators > 0 ? "text-red-600 dark:text-red-400" : "text-emerald-600"
                  }`}>
                    {data.kpis.evaluators.global_deficit_evaluators > 0
                      ? `-${data.kpis.evaluators.global_deficit_evaluators} avaliadores`
                      : "Sem Déficit"}
                  </span>
                  <span className="text-[10px] text-slate-400">para equilibrar todos os estandes</span>
                </div>
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                  data.kpis.evaluators.global_deficit_evaluators > 0
                    ? "bg-red-50 dark:bg-red-950/50 text-red-600"
                    : "bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600"
                }`}>
                  <ShieldAlert size={20} />
                </div>
              </div>
            </div>

            {/* Grid de Grandes Áreas com Termômetro */}
            <AreaRiskGrid areas={data.areas_diagnostic} />
          </>
        ) : null}
      </main>
    </div>
  );
}

export default function AreasRiskMonitorPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen flex items-center justify-center bg-slate-50 dark:bg-slate-950 text-slate-500 text-sm">
          Carregando Monitor de Grandes Áreas...
        </div>
      }
    >
      <AreasRiskMonitorContent />
    </Suspense>
  );
}
