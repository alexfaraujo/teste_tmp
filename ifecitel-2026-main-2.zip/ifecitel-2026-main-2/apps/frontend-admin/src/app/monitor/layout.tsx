"use client";

import React, { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { authService } from "../../services/auth.service";
import { EventProvider } from "../../context/EventContext";

export default function MonitorLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const router = useRouter();
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);

  useEffect(() => {
    const auth = authService.isAuthenticated();
    if (!auth) {
      router.push("/login");
    } else {
      setIsAuthenticated(true);
    }
  }, [router]);

  if (isAuthenticated === null) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 dark:bg-slate-950 text-slate-500 text-sm">
        Verificando credenciais de monitoramento...
      </div>
    );
  }

  return (
    <EventProvider>
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 transition-colors flex flex-col">
        {children}
      </div>
    </EventProvider>
  );
}
