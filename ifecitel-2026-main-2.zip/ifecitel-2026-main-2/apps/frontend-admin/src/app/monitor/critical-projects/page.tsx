"use client";

import React, { useEffect, useState, useRef, useCallback, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import { AlertTriangle, Sparkles } from "lucide-react";
import { dashboardService } from "../../../services/dashboard.service";
import { AdminOverviewResponse, CriticalProjectItem } from "../../../types";
import { useActiveEvent } from "../../../context/EventContext";
import { MonitorHeader } from "../../../components/monitor/MonitorHeader";
import { AdminKpiCards } from "../../../components/dashboard/AdminKpiCards";
import { CriticalProjectsWidget } from "../../../components/dashboard/CriticalProjectsWidget";
import { ManualAllocationModal } from "../../../components/dashboard/ManualAllocationModal";

const POLL_INTERVAL = 30; // Segundos

function CriticalProjectsMonitorContent() {
  const searchParams = useSearchParams();
  const { activeEvent } = useActiveEvent();

  // Event ID prioritariamente da URL paramétrica (?event_id=X), com fallback para o contexto ativo
  const eventIdParam = searchParams.get("event_id");
  const eventId = eventIdParam ? Number(eventIdParam) : activeEvent?.id || null;

  const [data, setData] = useState<AdminOverviewResponse | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [secondsRemaining, setSecondsRemaining] = useState(POLL_INTERVAL);

  // Controle do Modal de Alocação Manual Ágil
  const [isManualModalOpen, setIsManualModalOpen] = useState(false);
  const [manualInitialProject, setManualInitialProject] = useState<CriticalProjectItem | null>(null);

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Carregamento de dados unificado
  const loadData = useCallback(async (evId: number, isSilent = false) => {
    if (!isSilent) setIsLoading(true);
    else setIsRefreshing(true);

    try {
      const overview = await dashboardService.getAdminOverview(evId);
      setData(overview);
    } catch (err) {
      console.error("Erro ao carregar métricas no monitor de projetos críticos:", err);
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  }, []);

  // Efeito de inicialização com base no eventId
  useEffect(() => {
    if (eventId) {
      loadData(eventId, false);
      setSecondsRemaining(POLL_INTERVAL);
    } else {
      setIsLoading(false);
    }
  }, [eventId, loadData]);

  // Ciclo regressivo de 30 segundos com suporte a pause/retomada e pausa em segundo plano
  useEffect(() => {
    if (!eventId || isPaused) {
      if (timerRef.current) clearInterval(timerRef.current);
      return;
    }

    const handleVisibilityChange = () => {
      if (typeof document !== "undefined" && !document.hidden) {
        setSecondsRemaining(POLL_INTERVAL);
        loadData(eventId, true);
      }
    };

    if (typeof document !== "undefined") {
      document.addEventListener("visibilitychange", handleVisibilityChange);
    }

    timerRef.current = setInterval(() => {
      if (typeof document !== "undefined" && document.hidden) {
        return; // Não desconta nem dispara requisições enquanto a aba estiver em segundo plano
      }

      setSecondsRemaining((prev) => {
        if (prev <= 1) {
          loadData(eventId, true);
          return POLL_INTERVAL;
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
      if (typeof document !== "undefined") {
        document.removeEventListener("visibilitychange", handleVisibilityChange);
      }
    };
  }, [eventId, isPaused, loadData]);

  const handleManualRefresh = () => {
    if (!eventId) return;
    setSecondsRemaining(POLL_INTERVAL);
    loadData(eventId, true);
  };

  const handleAllocateProject = (project: CriticalProjectItem) => {
    setManualInitialProject(project);
    setIsManualModalOpen(true);
  };

  if (!eventId) {
    return (
      <div className="flex-1 flex items-center justify-center p-8">
        <div className="max-w-md p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-center space-y-3">
          <AlertTriangle size={32} className="text-amber-500 mx-auto" />
          <h2 className="text-base font-bold text-slate-900 dark:text-white">
            Nenhuma Edição Selecionada
          </h2>
          <p className="text-xs text-slate-500">
            Informe um ID de evento válido na URL (ex: <code className="font-mono font-bold text-blue-600">?event_id=391</code>) ou selecione um evento no painel principal.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col">
      {/* Cabeçalho do Monitor Dedicado */}
      <MonitorHeader
        title="Monitor de Trabalhos Críticos & Gaps de Avaliação"
        icon={<AlertTriangle size={20} className="text-red-500" />}
        eventId={eventId}
        eventName={data?.event_name || activeEvent?.name || "Carregando..."}
        secondsRemaining={secondsRemaining}
        totalInterval={POLL_INTERVAL}
        isPaused={isPaused}
        onTogglePause={() => setIsPaused(!isPaused)}
        onRefresh={handleManualRefresh}
        isRefreshing={isRefreshing}
      />

      {/* Conteúdo Principal Full-Width */}
      <main className="flex-1 px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {isLoading ? (
          <div className="p-16 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-center space-y-3">
            <div className="w-10 h-10 border-4 border-red-500 border-t-transparent rounded-full animate-spin mx-auto" />
            <p className="text-sm font-bold text-slate-700 dark:text-slate-300">
              Sincronizando Trabalhos Críticos e Gaps de Avaliação...
            </p>
          </div>
        ) : data ? (
          <>
            {/* Os 4 Cards de Topo */}
            <AdminKpiCards kpis={data.kpis} />

            {/* Tabela de Trabalhos Críticos Expandida */}
            <CriticalProjectsWidget
              criticalProjects={data.critical_projects}
              onAllocateProject={handleAllocateProject}
            />
          </>
        ) : null}
      </main>

      {/* Modal de Alocação Manual */}
      {eventId && (
        <ManualAllocationModal
          isOpen={isManualModalOpen}
          onClose={() => setIsManualModalOpen(false)}
          eventId={eventId}
          initialProject={manualInitialProject}
          projects={data?.critical_projects || []}
          onSuccess={() => {
            loadData(eventId, true);
          }}
        />
      )}
    </div>
  );
}

export default function CriticalProjectsMonitorPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen flex items-center justify-center bg-slate-50 dark:bg-slate-950 text-slate-500 text-sm">
          Carregando Monitor de Trabalhos Críticos...
        </div>
      }
    >
      <CriticalProjectsMonitorContent />
    </Suspense>
  );
}
