export type UserRole = "ADMIN" | "STUDENT" | "ADVISOR" | "COADVISOR" | "EVALUATOR";
export type EventAdminRole = "COORDINATOR" | "ORGANIZER" | "OPERATOR";
export type AllocationStatus = "PENDING" | "COMPLETED" | "CANCELLED";
export type AllocationType = "AUTOMATIC_CHECKIN" | "MANUAL_ADMIN";

export interface User {
  id: number;
  name: string;
  email: string;
  role: UserRole;
  barcode?: string;
}

export interface EducationLevelItem {
  id?: number;
  event_id?: number;
  level_name: EducationLevel;
  max_students: number;
  min_evaluators: number;
}

export interface EventAdminInput {
  email: string;
  role: EventAdminRole;
}

export interface EventItem {
  id: number;
  name: string;
  year: number;
  description?: string | null;
  workload_hours?: number;
  max_projects?: number;
  location?: string;
  start_date: string;
  end_date: string;
  status?: string;
  summary_extension?: string;
  banner_extension?: string;
  max_file_size_mb: number;
  max_projects_per_evaluator: number;
  organizing_institution?: string | null;
  theme?: string | null;
  contact_email?: string | null;
  website_url?: string | null;
  logo_url?: string | null;
  owner_id?: number;
  owner_name?: string | null;
  owner_email?: string | null;
  user_role?: EventAdminRole;
  is_owner?: boolean;
  education_levels?: EducationLevelItem[];
  administrators?: EventAdminItem[];
  deleted_at?: string | null;
  created_at?: string;
  updated_at?: string;
}

export interface EventAdminItem {
  id: number;
  event_id: number;
  person_id: number;
  name: string;
  email: string;
  role: EventAdminRole;
  is_owner: boolean;
  created_at: string;
}

export interface AreaEvaluationProgress {
  area_id: number;
  area_name: string;
  total_projects: number;
  present_projects?: number;
  evaluations_completed: number;
  expected_evaluations?: number;
  progress_percent?: number;
}

export interface Subarea {
  id: number;
  area_id: number;
  name: string;
  area_name?: string | null;
  created_at?: string;
  updated_at?: string;
  deleted_at?: string | null;
}

export interface KnowledgeArea {
  id: number;
  event_id: number;
  name: string;
  created_at?: string;
  updated_at?: string;
  deleted_at?: string | null;
  subareas: Subarea[];
}

export interface KnowledgeAreaBatchItem {
  area: string;
  subarea?: string | null;
}

export interface KnowledgeAreaBatchImport {
  items: KnowledgeAreaBatchItem[];
}

export interface KnowledgeAreaBatchResponse {
  total_rows_processed: number;
  total_areas_processed: number;
  total_subareas_processed: number;
  created_areas_count: number;
  created_subareas_count: number;
  reused_areas_count: number;
  reused_subareas_count: number;
  items: KnowledgeArea[];
}

export interface ParsedAreaRow {
  line_number: number;
  area: string;
  subarea?: string | null;
  status: "NEW" | "EXISTING" | "INVALID";
  errors: string[];
}

export interface GroupedAreaPreview {
  area: string;
  isNewArea: boolean;
  subareas: {
    name: string;
    isNewSubarea: boolean;
    rowNumber: number;
  }[];
  rowNumbers: number[];
}

export interface ParseAreasCsvResult {
  totalRows: number;
  validRows: number;
  invalidRows: number;
  newAreasCount: number;
  existingAreasCount: number;
  newSubareasCount: number;
  existingSubareasCount: number;
  groupedAreas: GroupedAreaPreview[];
  parsedRows: ParsedAreaRow[];
  batchPayload: KnowledgeAreaBatchItem[];
  errors: string[];
  warnings: string[];
}


export interface PublicTvMetricsResponse {
  event_id: number;
  event_name: string;
  total_registered_participants: number;
  total_present_participants: number;
  total_registered_students_advisors?: number;
  total_present_students_advisors?: number;
  total_registered_evaluators?: number;
  total_present_evaluators?: number;
  total_registered_projects: number;
  total_present_projects: number;
  total_evaluations_completed: number;
  areas_progress: AreaEvaluationProgress[];
  updated_at: string;
  min_evaluators_default?: number;
  total_expected_evaluations?: number;
  evaluation_progress_percent?: number;
}

export type ProjectStatus =
  | "DRAFT"
  | "WAITING_CONSENT"
  | "SUBMITTED"
  | "HOMOLOGATED"
  | "REJECTED"
  | "PRESENT"
  | "ABSENT";

export type EducationLevel =
  | "MEDIO"
  | "FUNDAMENTAL"
  | "JUNIOR"
  | "GRADUACAO"
  | "POS_GRADUACAO";

export type ProjectType = "SCIENTIFIC" | "TECHNOLOGICAL";

export type ProjectMemberRole =
  | "STUDENT_LEADER"
  | "STUDENT_MEMBER"
  | "ADVISOR"
  | "COADVISOR";

export interface ProjectMember {
  id: number;
  person_id: number;
  role: ProjectMemberRole;
  created_at: string;
  person_name?: string | null;
  person_email?: string | null;
  person_cpf?: string | null;
  tshirt_size?: string | null;
}

export interface ProjectMemberInput {
  person_id: number;
  role: ProjectMemberRole;
}

export interface ProjectItem {
  id: number;
  event_id: number;
  subarea_id: number;
  subarea_name?: string | null;
  area_name?: string | null;
  title: string;
  project_type: ProjectType;
  education_level: EducationLevel;
  abstract?: string | null;
  needs_electricity?: boolean;
  needs_table?: boolean;
  summary_file_url?: string | null;
  banner_file_url?: string | null;
  logbook_file_url?: string | null;
  booth_number?: string | null;
  rejection_reason?: string | null;
  qrcode_token: string;
  status: ProjectStatus;
  advisor_consent: boolean;
  advisor_consent_at?: string | null;
  created_at: string;
  updated_at: string;
  members?: ProjectMember[];
}

export interface ProjectCreatePayload {
  event_id: number;
  subarea_id: number;
  education_level: EducationLevel;
  title: string;
  project_type?: ProjectType;
  abstract?: string | null;
  needs_electricity?: boolean;
  needs_table?: boolean;
  booth_number?: string | null;
  auto_homologate?: boolean;
  members: ProjectMemberInput[];
}

export interface ProjectUpdatePayload {
  title?: string;
  project_type?: ProjectType;
  education_level?: EducationLevel;
  abstract?: string | null;
  subarea_id?: number;
  booth_number?: string | null;
  needs_electricity?: boolean;
  needs_table?: boolean;
  members?: ProjectMemberInput[];
}

export interface ProjectBatchMemberInput {
  name: string;
  email: string;
  role: ProjectMemberRole;
  cpf?: string;
  affiliation?: string;
  tshirt_size?: string;
}

export interface ProjectBatchItem {
  title: string;
  project_type: ProjectType;
  education_level: EducationLevel;
  subarea_name: string;
  booth_number?: string | null;
  abstract?: string | null;
  needs_electricity?: boolean;
  needs_table?: boolean;
  members: ProjectBatchMemberInput[];
  auto_homologate?: boolean;
}

export interface ProjectBatchImportPayload {
  items: ProjectBatchItem[];
  auto_homologate?: boolean;
}

export interface ProjectBatchResponse {
  total: number;
  created_count: number;
  updated_count: number;
  participants_created_count: number;
  items: ProjectItem[];
}

export interface ParsedProjectRow extends ProjectBatchItem {
  line_number: number;
  status: "NEW" | "UPDATE" | "INVALID";
  errors: string[];
  existing_project?: ProjectItem;
}

export interface PaginatedResponse<T> {
  items: T[];
  total: number;
  page: number;
  limit: number;
  total_pages: number;
}

export interface ScanProjectItem {
  id: number;
  title: string;
  booth_number?: string | null;
  status: string;
  subarea_name?: string | null;
  area_name?: string | null;
  role_in_project?: string | null;
  all_kits_delivered: boolean;
}

export interface BarcodeScanResponse {
  person_id?: number | null;
  person_name?: string | null;
  person_role?: string | null;
  barcode: string;
  presence_confirmed: boolean;
  presence_confirmed_at?: string | null;
  tshirt_size?: string | null;
  kit_delivered: boolean;
  project_id?: number | null;
  project_title?: string | null;
  booth_number?: string | null;
  project_status?: string | null;
  collective_presence_triggered: boolean;
  allocated_projects_count?: number | null;
  is_project_scan?: boolean;
  projects?: ScanProjectItem[];
  message: string;
}

export interface KitCheckoutResponse {
  person_id: number;
  person_name: string;
  tshirt_size: string;
  kit_delivered: boolean;
  kit_delivered_at: string;
  message: string;
}

export interface ProjectKitMemberStatus {
  person_id: number;
  name: string;
  role: string;
  tshirt_size: string;
  presence_confirmed: boolean;
  kit_delivered: boolean;
  kit_delivered_at?: string | null;
}

export interface ProjectKitsSummaryResponse {
  project_id: number;
  title: string;
  booth_number?: string | null;
  members: ProjectKitMemberStatus[];
}

export interface AllocationResponse {
  id: number;
  event_id: number;
  project_id: number;
  project_title: string;
  booth_number?: string | null;
  subarea_name: string;
  area_name?: string | null;
  evaluator_id: number;
  evaluator_name: string;
  allocation_type: AllocationType;
  status: AllocationStatus;
  allocated_at: string;
}

export interface AllocatedProjectItem {
  project_id: number;
  project_title: string;
  booth_number?: string | null;
  subarea_name: string;
  area_name?: string | null;
  current_evaluators_count: number;
}

export interface EvaluatorSubareaItem {
  subarea_id: number;
  subarea_name: string;
  area_id: number;
  area_name: string;
}

export interface EvaluatorListItem {
  id: number;
  name: string;
  email: string;
  cpf?: string | null;
  barcode?: string | null;
  presence_confirmed: boolean;
  evaluator_presence_confirmed: boolean;
  allocated_projects_count: number;
  education_levels?: EducationLevel[];
  subareas: EvaluatorSubareaItem[];
}

export interface EvaluatorCheckinAllocationResponse {
  evaluator_id: number;
  evaluator_name: string;
  event_id: number;
  presence_confirmed: boolean;
  evaluator_presence_confirmed: boolean;
  already_checked_in?: boolean;
  kit_delivered?: boolean;
  tshirt_size?: string;
  allocated_projects_count: number;
  allocated_projects: AllocatedProjectItem[];
  message: string;
}

export interface ParticipantProjectItem {
  project_id: number;
  title: string;
  member_role: string;
  booth_number?: string | null;
}

export interface ParticipantSubareaItem {
  subarea_id: number;
  subarea_name: string;
  area_name: string;
}

export interface ParticipantItem {
  participant_id: number;
  person_id: number;
  event_id: number;
  name: string;
  email: string;
  cpf?: string | null;
  affiliation?: string | null;
  role: UserRole;
  roles: UserRole[];
  barcode?: string | null;
  tshirt_size: string;
  kit_delivered: boolean;
  kit_delivered_at?: string | null;
  presence_confirmed: boolean;
  presence_confirmed_at?: string | null;
  evaluator_presence_confirmed: boolean;
  evaluator_presence_confirmed_at?: string | null;
  education_levels?: EducationLevel[];
  projects_count: number;
  created_at: string;
}

export interface ParticipantDetail extends ParticipantItem {
  projects: ParticipantProjectItem[];
  subareas: ParticipantSubareaItem[];
}

export interface ParticipantCreatePayload {
  name: string;
  email: string;
  cpf?: string;
  affiliation?: string;
  role?: UserRole;
  roles?: UserRole[];
  tshirt_size?: string;
  barcode?: string;
  subarea_ids?: number[];
  education_levels?: EducationLevel[];
}

export interface ParticipantUpdatePayload {
  name?: string;
  email?: string;
  cpf?: string;
  affiliation?: string;
  role?: UserRole;
  roles?: UserRole[];
  tshirt_size?: string;
  barcode?: string;
  kit_delivered?: boolean;
  presence_confirmed?: boolean;
  subarea_ids?: number[];
  education_levels?: EducationLevel[];
}


export interface PaginatedParticipantsResponse {
  items: ParticipantItem[];
  total: number;
  page: number;
  limit: number;
  total_pages: number;
}

export interface ParticipantBatchItem {
  name: string;
  email: string;
  roles: UserRole[];
  cpf?: string;
  affiliation?: string;
  tshirt_size?: string;
  subareas: string[];
  education_levels: EducationLevel[];
  barcode?: string;
}

export interface ParticipantBatchImport {
  items: ParticipantBatchItem[];
}

export interface ParticipantBatchResponse {
  total_processed: number;
  created_count: number;
  updated_count: number;
  roles_assigned_count: number;
  evaluators_count: number;
  items: ParticipantItem[];
}

export interface ParsedParticipantRow {
  rowNumber: number;
  name: string;
  email: string;
  roles: UserRole[];
  cpf?: string;
  affiliation?: string;
  tshirt_size: string;
  subareas: string[];
  education_levels: EducationLevel[];
  barcode?: string;
  isValid: boolean;
  errors: string[];
  warnings: string[];
  isExisting: boolean;
}

export interface ParseParticipantsCsvResult {
  rows: ParsedParticipantRow[];
  totalRows: number;
  newCount: number;
  updateCount: number;
  evaluatorsCount: number;
  invalidCount: number;
  hasErrors: boolean;
}


// -------------------------------------------------------------
// FASE 6: Premiações e Classificação Oficial (Rankings 1 e 2)
// -------------------------------------------------------------

export interface EvaluationCriterion {
  id: number;
  event_id: number;
  name: string;
  scientific_description?: string | null;
  technological_description?: string | null;
  max_score: number;
  weight: number;
}

export interface EvaluationCriterionCreatePayload {
  name: string;
  scientific_description?: string;
  technological_description?: string;
  max_score?: number;
  weight?: number;
}

export interface EvaluationCriterionUpdatePayload {
  name?: string;
  scientific_description?: string;
  technological_description?: string;
  max_score?: number;
  weight?: number;
}

export interface EvaluationCriterionBatchItem {
  name: string;
  pergunta_unica?: string | null;
  scientific_description?: string | null;
  technological_description?: string | null;
  max_score: number;
  weight: number;
}

export interface EvaluationCriterionBatchResponse {
  total: number;
  created_count: number;
  updated_count: number;
  items: EvaluationCriterion[];
}

export interface ParsedCriterionRow extends EvaluationCriterionBatchItem {
  line_number: number;
  status: "NEW" | "UPDATE" | "INVALID";
  errors: string[];
  existing_criterion?: EvaluationCriterion;
}

export interface AwardCriterionItem {
  id?: number;
  award_id?: number;
  criterion_id: number;
  criterion_name?: string | null;
  weight: number;
  created_at?: string;
}

export interface AwardItem {
  id: number;
  event_id: number;
  name: string;
  description?: string | null;
  sponsor?: string | null;
  created_at: string;
  updated_at: string;
  criteria_links?: AwardCriterionItem[];
}

export interface AwardCriterionLinkInput {
  criterion_id: number;
  weight: number;
}

export interface AwardCreatePayload {
  name: string;
  description?: string;
  sponsor?: string;
  criteria_links?: AwardCriterionLinkInput[];
}

export interface AwardUpdatePayload {
  name?: string;
  description?: string;
  sponsor?: string;
  criteria_links?: AwardCriterionLinkInput[];
}

export interface ProjectRankingItem {
  project_id: number;
  title: string;
  booth_number: string;
  subarea_name: string;
  area_name: string;
  education_level: string;
  evaluations_count: number;
  final_score: number;
  rank_position: number;
}

export interface AreaLevelLeaderboardGroup {
  area_id: number;
  area_name: string;
  education_level: string;
  total_projects: number;
  standings: ProjectRankingItem[];
}

export interface LevelLeaderboardGroup {
  education_level: string;
  education_level_label: string;
  total_projects: number;
  standings: ProjectRankingItem[];
}

export interface OverallLeaderboardResponse {
  event_id: number;
  event_name: string;
  total_evaluated_projects: number;
  standings: ProjectRankingItem[];
  by_education_level?: LevelLeaderboardGroup[];
}

export interface AwardStandingItem {
  project_id: number;
  title: string;
  booth_number: string;
  subarea_name: string;
  education_level: string;
  evaluations_count: number;
  award_score: number;
  rank_position: number;
}

export interface AwardStandingsResponse {
  award_id: number;
  award_name: string;
  sponsor?: string | null;
  criteria_considered: string[];
  total_competing_projects: number;
  standings: AwardStandingItem[];
}

// ==============================================================================
// Tipos do Centro de Comando do Administrador (War Room - BR-10, BR-14, BR-18)
// ==============================================================================

export interface AdminProjectsKpi {
  registered: number;
  present: number;
  present_percent: number;
  in_evaluation: number;
  evaluated: number;
  absent: number;
  zero_evaluators_count: number;
  under_quota_count: number;
}

export interface AdminParticipantsKpi {
  registered_students: number;
  present_students: number;
  students_presence_percent: number;
  registered_advisors: number;
  present_advisors: number;
  advisors_presence_percent: number;
  total_registered: number;
  total_present: number;
  overall_presence_percent: number;
  kits_delivered: number;
  kits_delivered_percent: number;
}

export interface AdminEvaluatorsKpi {
  registered: number;
  present: number;
  present_percent: number;
  evaluating_now: number;
  available: number;
  total_capacity: number;
  expected_evaluations: number;
  global_deficit_evaluations: number;
  global_deficit_evaluators: number;
  fundamental_evaluators_count: number;
  medio_evaluators_count: number;
}

export interface AdminProgressKpi {
  evaluations_completed: number;
  evaluations_in_progress: number;
  evaluations_pending: number;
  progress_percent: number;
  evaluations_per_hour: number;
  estimated_completion_time?: string | null;
}

export interface AdminKpiCollection {
  projects: AdminProjectsKpi;
  participants: AdminParticipantsKpi;
  evaluators: AdminEvaluatorsKpi;
  progress: AdminProgressKpi;
}

export interface AdminAreaDiagnostic {
  area_id: number;
  area_name: string;
  total_projects: number;
  present_projects: number;
  evaluations_completed: number;
  expected_evaluations: number;
  progress_percent: number;
  registered_evaluators: number;
  present_evaluators: number;
  area_capacity: number;
  deficit_evaluations: number;
  deficit_evaluators_needed: number;
  health_status: "GREEN" | "YELLOW" | "RED";
  projects_at_risk_count: number;
}

export interface AllocatedEvaluatorSimple {
  id: number;
  name: string;
}

export interface CriticalProjectItem {
  project_id: number;
  title: string;
  stand_number?: string | null;
  area_id: number;
  area_name: string;
  education_level: string;
  min_evaluators: number;
  allocated_evaluators_count: number;
  allocated_evaluators: AllocatedEvaluatorSimple[];
  gap_status: "ZERO_EVALUATORS" | "BELOW_QUOTA";
}

export interface AdminOverviewResponse {
  event_id: number;
  event_name: string;
  event_year: number;
  event_status: string;
  max_projects_per_evaluator: number;
  updated_at: string;
  kpis: AdminKpiCollection;
  areas_diagnostic: AdminAreaDiagnostic[];
  critical_projects: CriticalProjectItem[];
  golden_rule_satisfied: boolean;
  total_active_allocations: number;
}

export interface KitCardsPdfOptions {
  format?: "project" | "individual";
  include_tshirt_students?: boolean;
  include_tshirt_advisors?: boolean;
  include_tshirt_coadvisors?: boolean;
  include_tshirt_evaluators?: boolean;
  sort_by?: "booth" | "school" | "title";
  status_filter?: "homologated" | "all";
}

export interface BoothStickersPdfOptions {
  status_filter?: "homologated" | "all";
  area_id?: number | null;
  sort_by?: "id" | "booth" | "area" | "title";
  layout?: "a5_double" | "a6_quad";
}

export interface SnackMoment {
  id: number;
  event_id: number;
  name: string;
  date: string;
  start_time?: string | null;
  end_time?: string | null;
  is_active: boolean;
  target_roles?: string | null;
  total_budgeted?: number | null;
  notes?: string | null;
  created_at: string;
  total_delivered: number;
  percentage_consumed: number;
}

export interface SnackMomentCreateInput {
  name: string;
  date: string;
  start_time?: string | null;
  end_time?: string | null;
  is_active?: boolean;
  target_roles?: string;
  total_budgeted?: number;
  notes?: string | null;
}

export interface SnackMomentUpdateInput {
  name?: string;
  date?: string;
  start_time?: string | null;
  end_time?: string | null;
  is_active?: boolean;
  target_roles?: string;
  total_budgeted?: number;
  notes?: string | null;
}

export interface SnackDeliverScanRequest {
  scan_query: string;
  notes?: string | null;
}

export interface SnackDeliverScanResponse {
  status: "SUCCESS" | "ALREADY_DELIVERED" | "ROLE_NOT_ALLOWED" | "NOT_FOUND" | "MOMENT_INACTIVE";
  message: string;
  moment_id: number;
  moment_name: string;
  participant_id?: number | null;
  participant_name?: string | null;
  participant_role?: string | null;
  participant_barcode?: string | null;
  affiliation?: string | null;
  project_title?: string | null;
  booth_number?: string | null;
  delivered_at?: string | null;
  delivered_by_name?: string | null;
  total_delivered: number;
  total_budgeted: number;
  percentage_consumed: number;
}

export interface SnackDeliveryItem {
  id: number;
  participant_id: number;
  participant_name: string;
  participant_role: string;
  participant_barcode?: string | null;
  affiliation?: string | null;
  project_title?: string | null;
  booth_number?: string | null;
  delivered_at: string;
  delivered_by_name?: string | null;
  notes?: string | null;
}

export interface SnackMomentReport {
  moment: SnackMoment;
  delivered_count: number;
  total_eligible: number;
  deliveries: SnackDeliveryItem[];
}



