"use client";

import React, { useState, useRef } from "react";
import {
  Upload,
  FileSpreadsheet,
  Download,
  CheckCircle2,
  AlertTriangle,
  X,
  Layers,
  Tag,
  BookOpen,
  Info,
  Check,
  Plus,
} from "lucide-react";
import { Modal } from "../ui/Modal";
import { Button } from "../ui/Button";
import { KnowledgeArea } from "../../types";
import {
  downloadAreasCsvTemplate,
  parseAreasCsv,
} from "../../utils/areaCsv";
import { ParseAreasCsvResult } from "../../types";
import { areaService } from "../../services/area.service";

interface AreasCsvImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  eventId: number;
  existingAreas: KnowledgeArea[];
  onSuccess: (summary: {
    totalRows: number;
    totalAreas: number;
    totalSubareas: number;
    createdAreas: number;
    createdSubareas: number;
    reusedAreas: number;
    reusedSubareas: number;
  }) => void;
}

export function AreasCsvImportModal({
  isOpen,
  onClose,
  eventId,
  existingAreas,
  onSuccess,
}: AreasCsvImportModalProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [fileName, setFileName] = useState<string | null>(null);
  const [fileSize, setFileSize] = useState<string | null>(null);
  const [parseResult, setParseResult] = useState<ParseAreasCsvResult | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [modalError, setModalError] = useState<string | null>(null);
  const [isDragOver, setIsDragOver] = useState(false);

  const handleReset = () => {
    setFileName(null);
    setFileSize(null);
    setParseResult(null);
    setModalError(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleClose = () => {
    if (isSubmitting) return;
    handleReset();
    onClose();
  };

  const processFile = (file: File) => {
    if (!file.name.toLowerCase().endsWith(".csv")) {
      setModalError("Por favor, selecione um arquivo no formato CSV (.csv).");
      return;
    }

    setModalError(null);
    setFileName(file.name);
    setFileSize((file.size / 1024).toFixed(1) + " KB");

    const reader = new FileReader();
    reader.onload = (e) => {
      const content = e.target?.result as string;
      if (!content) {
        setModalError("O arquivo CSV selecionado está vazio.");
        return;
      }
      try {
        const result = parseAreasCsv(content, existingAreas);
        if (result.totalRows === 0) {
          setModalError(
            "Nenhuma linha de dados foi encontrada. Verifique se o arquivo possui um cabeçalho válido com a coluna 'area'."
          );
        }
        setParseResult(result);
      } catch (err: any) {
        setModalError("Erro ao processar o arquivo CSV: " + (err.message || "Formato inválido"));
      }
    };
    reader.onerror = () => {
      setModalError("Erro ao ler o arquivo CSV do seu computador.");
    };
    reader.readAsText(file, "UTF-8");
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) processFile(file);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) processFile(file);
  };

  const handleConfirmImport = async () => {
    if (!parseResult || parseResult.batchPayload.length === 0) return;

    try {
      setIsSubmitting(true);
      setModalError(null);

      const res = await areaService.importAreasBatch(eventId, {
        items: parseResult.batchPayload,
      });

      onSuccess({
        totalRows: res.total_rows_processed,
        totalAreas: res.total_areas_processed,
        totalSubareas: res.total_subareas_processed,
        createdAreas: res.created_areas_count,
        createdSubareas: res.created_subareas_count,
        reusedAreas: res.reused_areas_count,
        reusedSubareas: res.reused_subareas_count,
      });

      handleClose();
    } catch (err: any) {
      setModalError(
        err.response?.data?.detail || "Erro inesperado ao salvar áreas e subáreas no servidor."
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={handleClose}
      title="Importar Áreas e Subáreas em Lote"
      maxWidth="max-w-4xl"
    >
      <div className="space-y-5">
        {/* Banner Didático de Instruções */}
        <div className="p-3.5 rounded-xl bg-blue-50/80 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900 text-xs text-blue-900 dark:text-blue-200 flex items-start gap-3">
          <Info className="w-5 h-5 text-blue-600 dark:text-blue-400 flex-shrink-0 mt-0.5" />
          <div className="space-y-1">
            <p className="font-semibold text-blue-950 dark:text-blue-100">
              Formato Tabular Suportado: <code className="font-mono bg-blue-100 dark:bg-blue-900 px-1 py-0.5 rounded">area;subarea</code>
            </p>
            <p className="text-slate-600 dark:text-slate-300">
              Cada linha associa uma grande área à sua respectiva subárea. Linhas com a mesma área são agrupadas automaticamente. 
              Áreas e subáreas que já estiverem cadastradas no evento serão preservadas sem duplicação (idempotente).
            </p>
          </div>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => downloadAreasCsvTemplate(eventId)}
            className="flex-shrink-0 text-xs gap-1.5 ml-auto border-blue-300 dark:border-blue-800 text-blue-700 dark:text-blue-300 hover:bg-blue-100 dark:hover:bg-blue-900/50"
          >
            <Download size={13} />
            <span>Baixar Modelo CSV</span>
          </Button>
        </div>

        {/* Zona de Upload / Drag and Drop */}
        {!parseResult ? (
          <div
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`border-2 border-dashed rounded-2xl p-8 text-center cursor-pointer transition-all ${
              isDragOver
                ? "border-blue-500 bg-blue-50/50 dark:bg-blue-950/20 scale-[0.99]"
                : "border-slate-300 dark:border-slate-700 hover:border-blue-400 hover:bg-slate-50 dark:hover:bg-slate-850"
            }`}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept=".csv"
              className="hidden"
              onChange={handleFileChange}
            />
            <div className="w-12 h-12 rounded-2xl bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-blue-400 flex items-center justify-center mx-auto mb-3">
              <Upload size={24} />
            </div>
            <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">
              Clique para selecionar ou arraste seu arquivo <span className="text-blue-600 dark:text-blue-400">.CSV</span> aqui
            </p>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Separador recomendado: ponto e vírgula (;) com codificação UTF-8
            </p>
          </div>
        ) : (
          /* Arquivo Carregado + Painel de Resumo */
          <div className="space-y-4">
            {/* Header do Arquivo */}
            <div className="flex items-center justify-between p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-blue-100 dark:bg-blue-900/50 text-blue-700 dark:text-blue-300">
                  <FileSpreadsheet size={20} />
                </div>
                <div>
                  <p className="text-sm font-bold text-slate-900 dark:text-white truncate max-w-sm">
                    {fileName}
                  </p>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Tamanho: {fileSize} • {parseResult.totalRows} linha(s) processada(s)
                  </p>
                </div>
              </div>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={handleReset}
                className="text-xs gap-1 text-red-600 hover:bg-red-50 dark:hover:bg-red-950/40 border-red-200 dark:border-red-900"
              >
                <X size={13} />
                <span>Trocar Arquivo</span>
              </Button>
            </div>

            {/* KPI Cards de Detecção */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
                <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
                  Linhas do CSV
                </span>
                <span className="text-xl font-black text-slate-900 dark:text-white mt-0.5 block">
                  {parseResult.validRows}
                </span>
                <span className="text-[10px] text-slate-400">válidas para importação</span>
              </div>

              <div className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
                <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
                  Grandes Áreas
                </span>
                <span className="text-xl font-black text-blue-600 dark:text-blue-400 mt-0.5 block">
                  {parseResult.groupedAreas.length}
                </span>
                <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-medium">
                  {parseResult.newAreasCount} nova(s) • {parseResult.existingAreasCount} já cadastrada(s)
                </span>
              </div>

              <div className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
                <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
                  Subáreas
                </span>
                <span className="text-xl font-black text-teal-600 dark:text-teal-400 mt-0.5 block">
                  {parseResult.newSubareasCount + parseResult.existingSubareasCount}
                </span>
                <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-medium">
                  {parseResult.newSubareasCount} nova(s) • {parseResult.existingSubareasCount} já cadastrada(s)
                </span>
              </div>

              <div className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
                <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
                  Status
                </span>
                <div className="mt-1 flex items-center gap-1.5">
                  {parseResult.invalidRows === 0 ? (
                    <>
                      <CheckCircle2 size={16} className="text-emerald-600 dark:text-emerald-400" />
                      <span className="text-xs font-bold text-emerald-700 dark:text-emerald-300">
                        100% Válido
                      </span>
                    </>
                  ) : (
                    <>
                      <AlertTriangle size={16} className="text-amber-600 dark:text-amber-400" />
                      <span className="text-xs font-bold text-amber-700 dark:text-amber-300">
                        {parseResult.invalidRows} com erro
                      </span>
                    </>
                  )}
                </div>
                <span className="text-[10px] text-slate-400">pronto para gravar</span>
              </div>
            </div>

            {/* Avisos e Erros */}
            {parseResult.errors.length > 0 && (
              <div className="p-3.5 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 text-xs text-red-700 dark:text-red-300 space-y-1">
                <div className="font-bold flex items-center gap-1.5 text-red-800 dark:text-red-200">
                  <AlertTriangle size={14} />
                  <span>Erros encontrados no arquivo CSV:</span>
                </div>
                <ul className="list-disc pl-5 space-y-0.5">
                  {parseResult.errors.slice(0, 5).map((err, idx) => (
                    <li key={idx}>{err}</li>
                  ))}
                  {parseResult.errors.length > 5 && (
                    <li>... e mais {parseResult.errors.length - 5} erros ocultos.</li>
                  )}
                </ul>
              </div>
            )}

            {parseResult.warnings.length > 0 && (
              <div className="p-3.5 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900 text-xs text-amber-700 dark:text-amber-300 space-y-1">
                <div className="font-bold flex items-center gap-1.5 text-amber-800 dark:text-amber-200">
                  <AlertTriangle size={14} />
                  <span>Avisos de formatação:</span>
                </div>
                <ul className="list-disc pl-5 space-y-0.5">
                  {parseResult.warnings.slice(0, 3).map((w, idx) => (
                    <li key={idx}>{w}</li>
                  ))}
                </ul>
              </div>
            )}

            {/* Pré-visualização Hierárquica por Grande Área */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-slate-700 dark:text-slate-300 px-1">
                <span className="flex items-center gap-1.5">
                  <Layers size={14} className="text-blue-600" />
                  <span>Estrutura Hierárquica a ser Criada/Atualizada ({parseResult.groupedAreas.length} áreas)</span>
                </span>
                <span className="text-slate-400 font-normal text-[11px]">
                  Verifique a distribuição de subáreas antes de confirmar
                </span>
              </div>

              <div className="max-h-72 overflow-y-auto rounded-xl border border-slate-200 dark:border-slate-800 divide-y divide-slate-100 dark:divide-slate-800 bg-white dark:bg-slate-900">
                {parseResult.groupedAreas.map((group, idx) => (
                  <div key={idx} className="p-3.5 hover:bg-slate-50/50 dark:hover:bg-slate-850/50 transition-colors">
                    <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                      <div className="flex items-center gap-2">
                        <span className="w-6 h-6 rounded-lg bg-blue-100 dark:bg-blue-950/80 text-blue-700 dark:text-blue-300 font-bold text-xs flex items-center justify-center">
                          {idx + 1}
                        </span>
                        <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                          {group.area}
                        </h4>
                      </div>

                      <div className="flex items-center gap-2">
                        {group.isNewArea ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800">
                            <Plus size={10} />
                            Nova Área
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
                            <Check size={10} />
                            Já Cadastrada
                          </span>
                        )}
                        <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
                          {group.subareas.length} subárea(s)
                        </span>
                      </div>
                    </div>

                    {/* Chips de Subáreas */}
                    {group.subareas.length > 0 ? (
                      <div className="flex flex-wrap gap-1.5 pl-8">
                        {group.subareas.map((sub, sIdx) => (
                          <span
                            key={sIdx}
                            className={`inline-flex items-center gap-1 px-2 py-1 rounded-lg text-xs font-medium border ${
                              sub.isNewSubarea
                                ? "bg-teal-50 dark:bg-teal-950/40 text-teal-800 dark:text-teal-200 border-teal-200 dark:border-teal-800/80"
                                : "bg-slate-50 dark:bg-slate-850 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-750"
                            }`}
                          >
                            <Tag size={11} className={sub.isNewSubarea ? "text-teal-600" : "text-slate-400"} />
                            <span>{sub.name}</span>
                            {sub.isNewSubarea ? (
                              <span className="text-[9px] font-bold px-1 rounded bg-teal-200/60 dark:bg-teal-900/80 text-teal-800 dark:text-teal-200 ml-0.5">
                                nova
                              </span>
                            ) : (
                              <span className="text-[9px] text-slate-400 ml-0.5">
                                existente
                              </span>
                            )}
                          </span>
                        ))}
                      </div>
                    ) : (
                      <p className="text-xs text-slate-400 italic pl-8">
                        (Esta grande área será cadastrada sem subáreas iniciais)
                      </p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Mensagem Geral de Erro do Modal */}
        {modalError && (
          <div className="p-3 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 text-xs text-red-700 dark:text-red-300 flex items-center gap-2">
            <AlertTriangle size={15} className="flex-shrink-0" />
            <span>{modalError}</span>
          </div>
        )}

        {/* Botões de Ação */}
        <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100 dark:border-slate-800">
          <Button
            type="button"
            variant="outline"
            onClick={handleClose}
            disabled={isSubmitting}
          >
            Cancelar
          </Button>
          <Button
            type="button"
            variant="primary"
            disabled={!parseResult || parseResult.validRows === 0 || isSubmitting}
            isLoading={isSubmitting}
            onClick={handleConfirmImport}
            className="gap-1.5"
          >
            <CheckCircle2 size={15} />
            <span>Confirmar e Importar Áreas</span>
          </Button>
        </div>
      </div>
    </Modal>
  );
}
