"use client";

import React from "react";
import Link from "next/link";
import { Calendar, ArrowRight, AlertTriangle, ShieldAlert } from "lucide-react";
import { useActiveEvent } from "../../context/EventContext";
import { EventAdminRole } from "../../types";
import { Button } from "../ui/Button";
import { Card } from "../ui/Card";

interface RequireActiveEventProps {
  children: React.ReactNode;
  featureName?: string;
  minRole?: EventAdminRole;
}

const ROLE_RANKS: Record<EventAdminRole, number> = {
  COORDINATOR: 3,
  ORGANIZER: 2,
  OPERATOR: 1,
};

export const RequireActiveEvent: React.FC<RequireActiveEventProps> = ({
  children,
  featureName = "este módulo",
  minRole,
}) => {
  const { activeEvent, isLoadingActiveEvent } = useActiveEvent();

  if (isLoadingActiveEvent) {
    return (
      <div className="py-20 text-center text-sm text-slate-400 animate-pulse">
        Carregando contexto da edição do evento...
      </div>
    );
  }

  if (!activeEvent) {
    return (
      <div className="py-12 px-4 max-w-lg mx-auto">
        <Card className="p-8 text-center border-amber-200/80 dark:border-amber-900/50 bg-gradient-to-b from-amber-50/50 to-transparent dark:from-amber-950/20 shadow-sm">
          <div className="w-14 h-14 rounded-2xl bg-amber-100 dark:bg-amber-900/60 text-amber-600 dark:text-amber-400 flex items-center justify-center mx-auto mb-4 border border-amber-200 dark:border-amber-800 shadow-sm">
            <AlertTriangle size={28} />
          </div>

          <h2 className="text-lg font-bold text-slate-900 dark:text-white">
            Nenhuma Edição Selecionada
          </h2>

          <p className="text-xs text-slate-600 dark:text-slate-400 mt-2 mb-6 leading-relaxed">
            Para gerenciar <strong>{featureName}</strong>, é necessário selecionar previamente qual edição da feira você deseja gerenciar na tela de <strong>Edições do Evento</strong>.
          </p>

          <Link href="/events" className="inline-block">
            <Button variant="primary">
              <Calendar size={15} className="mr-2" />
              Selecionar Edição em Edições do Evento
              <ArrowRight size={14} className="ml-2" />
            </Button>
          </Link>
        </Card>
      </div>
    );
  }

  if (minRole) {
    const userRole: EventAdminRole = activeEvent.is_owner
      ? "COORDINATOR"
      : activeEvent.user_role || "OPERATOR";
    if (ROLE_RANKS[userRole] < ROLE_RANKS[minRole]) {
      const minRoleLabel =
        minRole === "COORDINATOR"
          ? "Coordenador Geral"
          : minRole === "ORGANIZER"
          ? "Comissão Organizadora"
          : "Apoio / Recepção";

      const userRoleLabel =
        userRole === "COORDINATOR"
          ? "Coordenador Geral"
          : userRole === "ORGANIZER"
          ? "Comissão Organizadora"
          : "Apoio / Recepção";

      return (
        <div className="py-12 px-4 max-w-lg mx-auto">
          <Card className="p-8 text-center border-rose-200/80 dark:border-rose-900/50 bg-gradient-to-b from-rose-50/50 to-transparent dark:from-rose-950/20 shadow-sm">
            <div className="w-14 h-14 rounded-2xl bg-rose-100 dark:bg-rose-900/60 text-rose-600 dark:text-rose-400 flex items-center justify-center mx-auto mb-4 border border-rose-200 dark:border-rose-800 shadow-sm">
              <ShieldAlert size={28} />
            </div>

            <h2 className="text-lg font-bold text-slate-900 dark:text-white">
              Acesso Restrito ao Módulo
            </h2>

            <p className="text-xs text-slate-600 dark:text-slate-400 mt-2 mb-1 leading-relaxed">
              O seu nível de acesso nesta feira é <strong>{userRoleLabel}</strong>.
            </p>
            <p className="text-xs text-slate-600 dark:text-slate-400 mb-6 leading-relaxed">
              A funcionalidade de <strong>{featureName}</strong> está restrita a membros com permissão mínima de <strong>{minRoleLabel}</strong>.
            </p>

            <Link href="/" className="inline-block">
              <Button variant="outline">
                <ArrowRight size={14} className="mr-2 rotate-180" />
                Voltar para a Visão Geral
              </Button>
            </Link>
          </Card>
        </div>
      );
    }
  }

  return <>{children}</>;
};
