import React from "react";
import { clsx } from "clsx";
import { twMerge } from "tailwind-merge";

interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  variant?: "success" | "warning" | "danger" | "info" | "neutral";
  size?: "sm" | "md";
}

export const Badge: React.FC<BadgeProps> = ({
  className,
  variant = "neutral",
  size = "md",
  children,
  ...props
}) => {
  const baseStyles = "inline-flex items-center font-medium rounded-full";

  const sizeStyles = {
    sm: "px-2 py-0.5 text-xs",
    md: "px-2.5 py-1 text-xs",
  };

  const variantStyles = {
    success:
      "bg-emerald-50 text-emerald-700 border border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-800",
    warning:
      "bg-amber-50 text-amber-700 border border-amber-200 dark:bg-amber-950/40 dark:text-amber-300 dark:border-amber-800",
    danger:
      "bg-rose-50 text-rose-700 border border-rose-200 dark:bg-rose-950/40 dark:text-rose-300 dark:border-rose-800",
    info:
      "bg-blue-50 text-blue-700 border border-blue-200 dark:bg-blue-950/40 dark:text-blue-300 dark:border-blue-800",
    neutral:
      "bg-slate-100 text-slate-700 border border-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700",
  };

  return (
    <span
      className={twMerge(clsx(baseStyles, sizeStyles[size], variantStyles[variant], className))}
      {...props}
    >
      {children}
    </span>
  );
};

export const StatusBadge: React.FC<{ status: string }> = ({ status }) => {
  switch (status) {
    case "HOMOLOGATED":
      return <Badge variant="success">Homologado</Badge>;
    case "PRESENT":
      return <Badge variant="success">Presente no Estande</Badge>;
    case "EVALUATED":
      return <Badge variant="success">Avaliação Concluída</Badge>;
    case "SUBMITTED":
      return <Badge variant="info">Submetido</Badge>;
    case "WAITING_CONSENT":
      return <Badge variant="warning">Aguardando Orientador</Badge>;
    case "UNDER_EVALUATION":
      return <Badge variant="warning">Em Avaliação</Badge>;
    case "REJECTED":
      return <Badge variant="danger">Indeferido / Rejeitado</Badge>;
    case "ABSENT":
      return <Badge variant="danger">Ausente</Badge>;
    case "DRAFT":
      return <Badge variant="neutral">Rascunho</Badge>;
    default:
      return <Badge variant="neutral">{status}</Badge>;
  }
};

export default Badge;
