import React from "react";
import { clsx } from "clsx";

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  helperText?: string;
}

export const Input = React.forwardRef<HTMLInputElement, InputProps>(
  ({ label, error, helperText, className, id, ...props }, ref) => {
    const inputId = id || (label ? label.toLowerCase().replace(/\s+/g, "-") : undefined);

    return (
      <div className="w-full space-y-1.5">
        {label && (
          <label
            htmlFor={inputId}
            className="block text-xs font-semibold text-slate-700 dark:text-slate-300"
          >
            {label}
          </label>
        )}
        <input
          ref={ref}
          id={inputId}
          className={clsx(
            "w-full px-3.5 py-2.5 bg-white dark:bg-slate-900 border rounded-xl text-sm transition-all shadow-sm",
            "text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500",
            "focus:outline-none focus:ring-2 focus:border-blue-500",
            error
              ? "border-red-500 focus:ring-red-500/20"
              : "border-slate-200 dark:border-slate-800 focus:ring-blue-500/20",
            "disabled:opacity-50 disabled:bg-slate-50 dark:disabled:bg-slate-800/50",
            className
          )}
          {...props}
        />
        {error && <p className="text-xs text-red-500 font-medium">{error}</p>}
        {helperText && !error && (
          <p className="text-xs text-slate-500 dark:text-slate-400">{helperText}</p>
        )}
      </div>
    );
  }
);

Input.displayName = "Input";
