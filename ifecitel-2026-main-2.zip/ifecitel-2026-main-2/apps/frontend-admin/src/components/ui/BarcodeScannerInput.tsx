"use client";

import React, { useState, useRef, useEffect } from "react";
import { ScanBarcode, ArrowRight, X } from "lucide-react";
import { Button } from "./Button";

interface BarcodeScannerInputProps {
  onScan: (barcode: string) => void;
  placeholder?: string;
  disabled?: boolean;
  autoFocus?: boolean;
  buttonText?: string;
}

export function BarcodeScannerInput({
  onScan,
  placeholder = "Aguardando leitura óptica ou digite o código de barras ou CPF...",
  disabled = false,
  autoFocus = true,
  buttonText = "Bipar",
}: BarcodeScannerInputProps) {
  const [value, setValue] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (autoFocus && inputRef.current && !disabled) {
      inputRef.current.focus();
    }
  }, [autoFocus, disabled]);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      e.preventDefault();
      const trimmed = value.trim();
      if (trimmed) {
        onScan(trimmed);
        setValue("");
      }
    }
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = value.trim();
    if (trimmed) {
      onScan(trimmed);
      setValue("");
    }
  };

  return (
    <form onSubmit={handleManualSubmit} className="relative flex items-center gap-2">
      <div className="relative flex-1">
        <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-teal-600 dark:text-teal-400">
          <ScanBarcode size={20} />
        </div>

        <input
          ref={inputRef}
          type="text"
          value={value}
          disabled={disabled}
          onChange={(e) => setValue(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder={placeholder}
          className="w-full pl-11 pr-10 py-3 bg-white dark:bg-slate-900 border-2 border-teal-500/40 dark:border-teal-500/30 rounded-xl text-base font-mono text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-4 focus:ring-teal-500/15 focus:border-teal-500 transition-all shadow-sm disabled:opacity-50"
        />

        {value && (
          <button
            type="button"
            onClick={() => {
              setValue("");
              inputRef.current?.focus();
            }}
            className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
          >
            <X size={18} />
          </button>
        )}
      </div>

      <Button
        type="submit"
        variant="primary"
        size="lg"
        disabled={disabled || !value.trim()}
        className="px-5 bg-teal-600 hover:bg-teal-700 active:bg-teal-800 text-white font-semibold"
      >
        <span>{buttonText}</span>
        <ArrowRight size={16} className="ml-1.5" />
      </Button>
    </form>
  );
}
