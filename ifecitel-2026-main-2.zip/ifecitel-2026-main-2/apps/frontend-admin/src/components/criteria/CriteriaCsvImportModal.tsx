"use client";

import React, { useState, useRef } from "react";
import {
  Upload,
  FileSpreadsheet,
  Download,
  CheckCircle2,
  RefreshCw,
  AlertTriangle,
  X,
  Scale,
  FlaskConical,
  Cpu,
  HelpCircle,
} from "lucide-react";
import { Modal } from "../ui/Modal";
import { Button } from "../ui/Button";
import { EvaluationCriterion } from "../../types";
import {
  downloadCriteriaCsvTemplate,
  parseCriteriaCsv,
  ParseCriteriaCsvResult,
} from "../../utils/criteriaCsv";
import { criterionService } from "../../services/criterion.service";

interface CriteriaCsvImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  eventId: number;
  existingCriteria: EvaluationCriterion[];
  onSuccess: (summary: { total: number; created: number; updated: number }) => void;
}

export function CriteriaCsvImportModal({
  isOpen,
  onClose,
  eventId,
  existingCriteria,
  onSuccess,
}: CriteriaCsvImportModalProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [fileName, setFileName] = useState<string | null>(null);
  const [fileSize, setFileSize] = useState<string | null>(null);
  const [parseResult, setParseResult] = useState<ParseCriteriaCsvResult | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [modalError, setModalError] = useState<string | null>(null);
  const [isDragOver, setIsDragOver] = useState(false);

  const handleReset = () => {
    setFileName(null);
    setFileSize(null);
    setParseResult(null);
    setModalError(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleClose = () => {
    if (isSubmitting) return;
    handleReset();
    onClose();
  };

  const processFile = (file: File) => {
    if (!file.name.toLowerCase().endsWith(".csv")) {
      setModalError("Por favor, selecione um arquivo no formato CSV (.csv).");
      return;
    }

    setModalError(null);
    setFileName(file.name);
    setFileSize((file.size / 1024).toFixed(1) + " KB");

    const reader = new FileReader();
    reader.onload = (e) => {
      const content = e.target?.result as string;
      if (!content) {
        setModalError("O arquivo CSV selecionado está vazio.");
        return;
      }
      try {
        const result = parseCriteriaCsv(content, existingCriteria);
        if (result.totalRows === 0) {
          setModalError(
            "Nenhum critério foi encontrado. Verifique se o arquivo possui um cabeçalho válido na primeira linha."
          );
        }
        setParseResult(result);
      } catch (err: any) {
        setModalError("Erro ao processar o arquivo CSV: " + (err.message || "Formato inválido"));
      }
    };
    reader.onerror = () => {
      setModalError("Erro ao ler o arquivo CSV do seu computador.");
    };
    reader.readAsText(file, "UTF-8");
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const handleConfirmImport = async () => {
    if (!parseResult || parseResult.rows.length === 0) return;

    const validRows = parseResult.rows.filter((r) => r.status !== "INVALID");
    if (validRows.length === 0) {
      setModalError("Não há critérios válidos para importar. Corrija os erros indicados.");
      return;
    }

    setIsSubmitting(true);
    setModalError(null);

    try {
      const payloadItems = validRows.map((r) => ({
        name: r.name,
        pergunta_unica: r.pergunta_unica,
        scientific_description: r.scientific_description,
        technological_description: r.technological_description,
        max_score: r.max_score,
        weight: r.weight,
      }));

      const res = await criterionService.importBatch(eventId, payloadItems);
      onSuccess({
        total: res.total,
        created: res.created_count,
        updated: res.updated_count,
      });
      handleClose();
    } catch (err: any) {
      setModalError(
        err.response?.data?.detail ||
          "Ocorreu um erro ao importar os critérios no banco de dados."
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  const validCount = parseResult
    ? parseResult.rows.filter((r) => r.status !== "INVALID").length
    : 0;

  return (
    <Modal
      isOpen={isOpen}
      onClose={handleClose}
      title="Importar Critérios de Avaliação via Planilha CSV"
      maxWidth="max-w-4xl"
      error={modalError}
    >
      <div className="space-y-5">
        {/* Upload Zone */}
        {!fileName ? (
          <div
            onDragOver={(e) => {
              e.preventDefault();
              setIsDragOver(true);
            }}
            onDragLeave={() => setIsDragOver(false)}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`border-2 border-dashed rounded-2xl p-8 text-center cursor-pointer transition-all ${
              isDragOver
                ? "border-blue-500 bg-blue-50/70 dark:bg-blue-950/30 shadow-inner"
                : "border-slate-300 dark:border-slate-700 hover:border-blue-400 bg-slate-50/50 dark:bg-slate-800/40 hover:bg-blue-50/20"
            }`}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept=".csv"
              className="hidden"
              onChange={handleFileChange}
            />

            <div className="mx-auto w-12 h-12 rounded-2xl bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-blue-400 flex items-center justify-center mb-3">
              <Upload size={24} />
            </div>

            <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">
              Clique para selecionar ou arraste o arquivo CSV aqui
            </p>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Compatível com arquivos exportados do Microsoft Excel ou Google Planilhas (delimitador ponto e vírgula ou vírgula).
            </p>

            <div className="mt-4 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700">
              <FileSpreadsheet size={15} className="text-emerald-600" />
              <span>Apenas arquivos .csv (UTF-8)</span>
            </div>
          </div>
        ) : (
          <div className="p-4 rounded-xl bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-400">
                <FileSpreadsheet size={22} />
              </div>
              <div>
                <p className="text-xs font-bold text-slate-900 dark:text-white">
                  {fileName}
                </p>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  Tamanho: {fileSize}
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={handleReset}
              disabled={isSubmitting}
              className="px-2.5 py-1 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:text-slate-900 bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 rounded-lg transition-colors flex items-center gap-1"
            >
              <X size={14} />
              Trocar Arquivo
            </button>
          </div>
        )}

        {/* Resumo da Análise / Preview Cards */}
        {parseResult && parseResult.totalRows > 0 && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
                  Total Lidos
                </span>
                <span className="text-lg font-bold text-slate-900 dark:text-white">
                  {parseResult.totalRows}
                </span>
              </div>

              <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/60">
                <span className="text-[11px] font-semibold text-emerald-700 dark:text-emerald-400 uppercase tracking-wider block flex items-center gap-1">
                  <CheckCircle2 size={13} />
                  Novos
                </span>
                <span className="text-lg font-bold text-emerald-700 dark:text-emerald-300">
                  +{parseResult.newCount}
                </span>
              </div>

              <div className="p-3 rounded-xl bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800/60">
                <span className="text-[11px] font-semibold text-blue-700 dark:text-blue-400 uppercase tracking-wider block flex items-center gap-1">
                  <RefreshCw size={13} />
                  Atualizações
                </span>
                <span className="text-lg font-bold text-blue-700 dark:text-blue-300">
                  {parseResult.updateCount}
                </span>
              </div>

              <div
                className={`p-3 rounded-xl border ${
                  parseResult.invalidCount > 0
                    ? "bg-rose-50 dark:bg-rose-950/30 border-rose-200 dark:border-rose-800/60"
                    : "bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700"
                }`}
              >
                <span
                  className={`text-[11px] font-semibold uppercase tracking-wider block flex items-center gap-1 ${
                    parseResult.invalidCount > 0
                      ? "text-rose-700 dark:text-rose-400"
                      : "text-slate-500"
                  }`}
                >
                  <AlertTriangle size={13} />
                  Inválidos
                </span>
                <span
                  className={`text-lg font-bold ${
                    parseResult.invalidCount > 0
                      ? "text-rose-700 dark:text-rose-300"
                      : "text-slate-400"
                  }`}
                >
                  {parseResult.invalidCount}
                </span>
              </div>
            </div>

            {/* Banner de Orientações da Mesclagem */}
            <div className="p-3 rounded-xl bg-blue-50/70 dark:bg-blue-950/40 border border-blue-200/80 dark:border-blue-900/60 text-xs text-blue-900 dark:text-blue-200 leading-relaxed">
              <strong>Regra de Sincronização Inteligente:</strong> Os critérios com badge{" "}
              <span className="font-bold text-emerald-700 dark:text-emerald-300">NOVO</span>{" "}
              serão adicionados à edição. Critérios com badge{" "}
              <span className="font-bold text-blue-700 dark:text-blue-300">ATUALIZAÇÃO</span>{" "}
              terão suas perguntas, nota máxima e peso sincronizados mantendo o histórico de notas.
              Critérios existentes na feira que não estiverem na planilha serão preservados intactos.
            </div>

            {/* Tabela de Pré-visualização */}
            <div className="border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
              <div className="max-h-72 overflow-y-auto divide-y divide-slate-200 dark:divide-slate-800">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 sticky top-0 z-10">
                    <tr>
                      <th className="px-3 py-2 font-bold w-28">Status</th>
                      <th className="px-3 py-2 font-bold">Critério / Perguntas</th>
                      <th className="px-3 py-2 font-bold w-24 text-right">Nota Máx</th>
                      <th className="px-3 py-2 font-bold w-20 text-right">Peso</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 bg-white dark:bg-slate-900">
                    {parseResult.rows.map((row, idx) => (
                      <tr
                        key={idx}
                        className={`hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition-colors ${
                          row.status === "INVALID"
                            ? "bg-rose-50/40 dark:bg-rose-950/20"
                            : ""
                        }`}
                      >
                        <td className="px-3 py-2.5 align-top">
                          <div className="flex flex-col gap-1">
                            {row.status === "NEW" && (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300">
                                <CheckCircle2 size={11} />
                                NOVO
                              </span>
                            )}
                            {row.status === "UPDATE" && (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-blue-100 dark:bg-blue-950 text-blue-800 dark:text-blue-300">
                                <RefreshCw size={11} />
                                ATUALIZAR
                              </span>
                            )}
                            {row.status === "INVALID" && (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-rose-100 dark:bg-rose-950 text-rose-800 dark:text-rose-300">
                                <AlertTriangle size={11} />
                                ERRO
                              </span>
                            )}
                            <span className="text-[10px] text-slate-400">
                              Linha {row.line_number}
                            </span>
                          </div>
                        </td>

                        <td className="px-3 py-2.5 align-top space-y-1.5">
                          <div className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                            <Scale size={14} className="text-slate-400" />
                            {row.name || (
                              <span className="italic text-rose-500">
                                (Sem identificador)
                              </span>
                            )}
                          </div>

                          {row.pergunta_unica ? (
                            <div className="text-[11px] text-indigo-700 dark:text-indigo-300 flex items-start gap-1">
                              <HelpCircle size={13} className="flex-shrink-0 mt-0.5" />
                              <span>{row.pergunta_unica}</span>
                            </div>
                          ) : (
                            <div className="space-y-1 text-[11px]">
                              {row.scientific_description && (
                                <div className="text-blue-700 dark:text-blue-300 flex items-start gap-1">
                                  <FlaskConical size={12} className="flex-shrink-0 mt-0.5" />
                                  <span>{row.scientific_description}</span>
                                </div>
                              )}
                              {row.technological_description && (
                                <div className="text-teal-700 dark:text-teal-300 flex items-start gap-1">
                                  <Cpu size={12} className="flex-shrink-0 mt-0.5" />
                                  <span>{row.technological_description}</span>
                                </div>
                              )}
                            </div>
                          )}

                          {row.errors.length > 0 && (
                            <div className="pt-1 text-[11px] text-rose-600 dark:text-rose-400 font-semibold space-y-0.5">
                              {row.errors.map((err, errIdx) => (
                                <p key={errIdx}>⚠️ {err}</p>
                              ))}
                            </div>
                          )}
                        </td>

                        <td className="px-3 py-2.5 align-top text-right font-bold text-slate-700 dark:text-slate-300">
                          {row.max_score.toFixed(1)} pts
                        </td>

                        <td className="px-3 py-2.5 align-top text-right font-bold text-blue-700 dark:text-blue-400">
                          {row.weight.toFixed(1)}x
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Rodapé e Ações */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-3 border-t border-slate-100 dark:border-slate-800">
          <button
            type="button"
            onClick={() => downloadCriteriaCsvTemplate(eventId)}
            className="text-xs text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1.5 font-medium"
          >
            <Download size={14} />
            Baixar Modelo Esqueleto CSV (.csv)
          </button>

          <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
            <Button
              type="button"
              variant="outline"
              onClick={handleClose}
              disabled={isSubmitting}
            >
              Cancelar
            </Button>

            <Button
              type="button"
              variant="primary"
              disabled={!parseResult || validCount === 0 || isSubmitting}
              isLoading={isSubmitting}
              onClick={handleConfirmImport}
            >
              Confirmar e Importar ({validCount} Critérios)
            </Button>
          </div>
        </div>
      </div>
    </Modal>
  );
}
