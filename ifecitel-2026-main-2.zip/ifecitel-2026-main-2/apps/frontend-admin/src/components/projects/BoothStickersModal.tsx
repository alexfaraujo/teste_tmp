"use client";

import React, { useState } from "react";
import {
  QrCode,
  Layers,
  LayoutGrid,
  CheckCircle2,
  FileDown,
  Info,
  ArrowUpDown,
  Filter,
  Sparkles,
} from "lucide-react";
import { Modal } from "../ui/Modal";
import { Button } from "../ui/Button";
import { projectService } from "../../services/project.service";
import { BoothStickersPdfOptions } from "../../types";

interface KnowledgeAreaOption {
  id: number;
  name: string;
}

interface BoothStickersModalProps {
  isOpen: boolean;
  onClose: () => void;
  eventId: number;
  eventName: string;
  areas?: KnowledgeAreaOption[];
  onSuccess?: (message: string) => void;
}

export function BoothStickersModal({
  isOpen,
  onClose,
  eventId,
  eventName,
  areas = [],
  onSuccess,
}: BoothStickersModalProps) {
  const [layout, setLayout] = useState<"a5_double" | "a6_quad">("a5_double");
  const [statusFilter, setStatusFilter] = useState<"homologated" | "all">("homologated");
  const [selectedAreaId, setSelectedAreaId] = useState<string>("ALL");
  const [sortBy, setSortBy] = useState<"id" | "booth" | "area" | "title">("booth");

  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleGeneratePdf = async () => {
    setIsGenerating(true);
    setError(null);

    const options: BoothStickersPdfOptions = {
      layout,
      status_filter: statusFilter,
      area_id: selectedAreaId !== "ALL" ? Number(selectedAreaId) : null,
      sort_by: sortBy,
    };

    try {
      await projectService.downloadEventBoothStickersPdf(eventId, options);
      const successMsg =
        layout === "a5_double"
          ? "PDF de Adesivos de Bancada (2 por folha A4) gerado com sucesso!"
          : "PDF de Adesivos de Bancada (4 por folha A4) gerado com sucesso!";
      if (onSuccess) {
        onSuccess(successMsg);
      }
      onClose();
    } catch (err: any) {
      setError(
        err.response?.data?.detail ||
          err.message ||
          "Erro ao gerar os adesivos de bancada em PDF. Verifique se existem trabalhos para os filtros selecionados."
      );
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Emissão de Adesivos de Bancada com QR Code (PDF)"
      error={error}
      maxWidth="max-w-2xl"
    >
      <div className="space-y-5 text-slate-800 dark:text-slate-200">
        {/* Banner de Contexto */}
        <div className="p-3.5 rounded-xl bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-900/60 flex items-start gap-3">
          <div className="p-2 rounded-lg bg-indigo-600 text-white shrink-0 mt-0.5">
            <QrCode size={18} />
          </div>
          <div className="text-xs space-y-1">
            <div className="font-bold text-indigo-950 dark:text-indigo-200">
              Identificação Oficial de Bancada e Avaliação Rápida
            </div>
            <div className="text-indigo-800/80 dark:text-indigo-300/80">
              Edição Ativa: <span className="font-semibold">{eventName}</span>. O adesivo contém o{" "}
              <span className="font-semibold">ID do Trabalho</span> em grande destaque, área de conhecimento,
              badges de infraestrutura (tomada e mesa) e o <span className="font-semibold">QR Code vetorial gigante</span>{" "}
              para que os avaliadores façam a leitura instantânea pela câmera do smartphone.
            </div>
          </div>
        </div>

        {/* 1. Escolha do Formato de Impressão */}
        <div>
          <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-2">
            1. Modelo de Impressão (Layout da Folha A4)
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Opção A5 - 2 por folha */}
            <button
              type="button"
              onClick={() => setLayout("a5_double")}
              className={`p-3.5 rounded-xl border text-left transition-all relative ${
                layout === "a5_double"
                  ? "border-indigo-600 bg-indigo-50/50 dark:bg-indigo-950/30 ring-2 ring-indigo-500/20 shadow-sm"
                  : "border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 bg-white dark:bg-slate-900"
              }`}
            >
              <div className="flex items-start gap-3">
                <div
                  className={`p-2 rounded-lg ${
                    layout === "a5_double"
                      ? "bg-indigo-600 text-white"
                      : "bg-slate-100 dark:bg-slate-800 text-slate-500"
                  }`}
                >
                  <Layers size={18} />
                </div>
                <div className="space-y-1 flex-1">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-bold text-slate-900 dark:text-white">
                      2 por Folha A4 (A5)
                    </span>
                    <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-indigo-100 dark:bg-indigo-900 text-indigo-700 dark:text-indigo-300">
                      Recomendado
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Grade 1x2 horizontal. <strong className="text-indigo-700 dark:text-indigo-300">QR Code Gigante (~180pt)</strong>{" "}
                    com leitura rápida e precisa nos corredores da feira.
                  </p>
                </div>
              </div>
            </button>

            {/* Opção A6 - 4 por folha */}
            <button
              type="button"
              onClick={() => setLayout("a6_quad")}
              className={`p-3.5 rounded-xl border text-left transition-all relative ${
                layout === "a6_quad"
                  ? "border-indigo-600 bg-indigo-50/50 dark:bg-indigo-950/30 ring-2 ring-indigo-500/20 shadow-sm"
                  : "border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 bg-white dark:bg-slate-900"
              }`}
            >
              <div className="flex items-start gap-3">
                <div
                  className={`p-2 rounded-lg ${
                    layout === "a6_quad"
                      ? "bg-indigo-600 text-white"
                      : "bg-slate-100 dark:bg-slate-800 text-slate-500"
                  }`}
                >
                  <LayoutGrid size={18} />
                </div>
                <div className="space-y-1 flex-1">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-bold text-slate-900 dark:text-white">
                      4 por Folha A4 (A6)
                    </span>
                    <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-emerald-100 dark:bg-emerald-900 text-emerald-700 dark:text-emerald-300">
                      Econômico
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Grade 2x2 em folha paisagem. <strong className="text-emerald-700 dark:text-emerald-300">QR Code Amplo (~135pt)</strong>{" "}
                    com alta economia (25 folhas para 100 trabalhos).
                  </p>
                </div>
              </div>
            </button>
          </div>
        </div>

        {/* 2. Filtros e Agrupamento */}
        <div className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50 space-y-3.5">
          <div className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
            <Filter size={14} className="text-indigo-600" />
            2. Filtros e Seleção de Trabalhos
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            {/* Filtro por Status */}
            <div>
              <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">
                Status dos Trabalhos
              </label>
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value as "homologated" | "all")}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="homologated">Apenas Trabalhos Homologados (Recomendado)</option>
                <option value="all">Todos os Trabalhos Cadastrados (Inclusive Rascunhos)</option>
              </select>
            </div>

            {/* Filtro por Grande Área Temática */}
            <div>
              <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">
                Filtrar por Grande Área
              </label>
              <select
                value={selectedAreaId}
                onChange={(e) => setSelectedAreaId(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="ALL">Todas as Grandes Áreas (Sem filtro)</option>
                {areas.map((area) => (
                  <option key={area.id} value={area.id}>
                    {area.name}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* 3. Ordenação das Folhas */}
        <div className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50 space-y-2">
          <div className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
            <ArrowUpDown size={14} className="text-indigo-600" />
            3. Sequência de Impressão
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
            <button
              type="button"
              onClick={() => setSortBy("booth")}
              className={`p-2.5 rounded-lg border text-center transition-all ${
                sortBy === "booth"
                  ? "border-indigo-600 bg-indigo-50 dark:bg-indigo-950/40 font-bold text-indigo-700 dark:text-indigo-300"
                  : "border-slate-200 dark:border-slate-800 hover:border-slate-300 text-slate-600 dark:text-slate-400"
              }`}
            >
              Por Estande
            </button>
            <button
              type="button"
              onClick={() => setSortBy("id")}
              className={`p-2.5 rounded-lg border text-center transition-all ${
                sortBy === "id"
                  ? "border-indigo-600 bg-indigo-50 dark:bg-indigo-950/40 font-bold text-indigo-700 dark:text-indigo-300"
                  : "border-slate-200 dark:border-slate-800 hover:border-slate-300 text-slate-600 dark:text-slate-400"
              }`}
            >
              Por ID do Trabalho
            </button>
            <button
              type="button"
              onClick={() => setSortBy("area")}
              className={`p-2.5 rounded-lg border text-center transition-all ${
                sortBy === "area"
                  ? "border-indigo-600 bg-indigo-50 dark:bg-indigo-950/40 font-bold text-indigo-700 dark:text-indigo-300"
                  : "border-slate-200 dark:border-slate-800 hover:border-slate-300 text-slate-600 dark:text-slate-400"
              }`}
            >
              Por Área & Subárea
            </button>
            <button
              type="button"
              onClick={() => setSortBy("title")}
              className={`p-2.5 rounded-lg border text-center transition-all ${
                sortBy === "title"
                  ? "border-indigo-600 bg-indigo-50 dark:bg-indigo-950/40 font-bold text-indigo-700 dark:text-indigo-300"
                  : "border-slate-200 dark:border-slate-800 hover:border-slate-300 text-slate-600 dark:text-slate-400"
              }`}
            >
              Por Título
            </button>
          </div>
        </div>

        {/* Informações Técnicas de Impressão */}
        <div className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-2 px-1">
          <Info size={14} className="shrink-0 text-slate-400" />
          <span>
            As páginas são geradas em PDF vetorial de alta definição com linhas de corte discretas tracejadas.
            Recomenda-se imprimir em papel cartão ou papel adesivo A4 para colagem na bancada física.
          </span>
        </div>

        {/* Ações do Modal */}
        <div className="flex items-center justify-end gap-3 pt-2 border-t border-slate-100 dark:border-slate-800">
          <Button variant="outline" onClick={onClose} disabled={isGenerating}>
            Cancelar
          </Button>
          <Button
            variant="primary"
            onClick={handleGeneratePdf}
            disabled={isGenerating}
            className="bg-indigo-600 hover:bg-indigo-700 text-white gap-2"
          >
            {isGenerating ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                <span>Gerando PDF...</span>
              </>
            ) : (
              <>
                <FileDown size={16} />
                <span>Gerar e Baixar Adesivos (PDF)</span>
              </>
            )}
          </Button>
        </div>
      </div>
    </Modal>
  );
}
