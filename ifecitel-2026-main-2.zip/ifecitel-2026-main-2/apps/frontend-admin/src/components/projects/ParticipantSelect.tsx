"use client";

import React, { useState, useMemo, useRef, useEffect } from "react";
import {
  Search,
  Award,
  GraduationCap,
  Check,
  X,
  UserPlus,
  AlertCircle,
  ExternalLink,
  Loader2,
  ChevronDown,
} from "lucide-react";
import Link from "next/link";
import { ParticipantItem, ProjectMemberRole } from "../../types";
import { participantService } from "../../services/participant.service";

export interface ParticipantSelectProps {
  label: string;
  role: ProjectMemberRole;
  eventId?: number;
  required?: boolean;
  selectedPersonId: number | null;
  onSelect: (person: ParticipantItem | null) => void;
  participants: ParticipantItem[];
  disabledPersonIds?: number[];
  fallbackInfo?: {
    name?: string | null;
    email?: string | null;
    cpf?: string | null;
  } | null;
  onRemove?: () => void;
}

/**
 * Remove acentos e caracteres diacríticos para busca insensível a acentos em português.
 */
function normalizeStr(text: string | null | undefined): string {
  if (!text) return "";
  return text
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .trim();
}

export function ParticipantSelect({
  label,
  role,
  eventId,
  required = false,
  selectedPersonId,
  onSelect,
  participants,
  disabledPersonIds = [],
  fallbackInfo,
  onRemove,
}: ParticipantSelectProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [apiResults, setApiResults] = useState<ParticipantItem[]>([]);
  const [isSearchingApi, setIsSearchingApi] = useState(false);

  const containerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Fecha o dropdown caso clique fora do container
  useEffect(() => {
    function handleClickOutside(event: MouseEvent | TouchEvent) {
      if (
        containerRef.current &&
        !containerRef.current.contains(event.target as Node)
      ) {
        setIsOpen(false);
        if (selectedPersonId) {
          setIsEditing(false);
        }
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    document.addEventListener("touchstart", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
      document.removeEventListener("touchstart", handleClickOutside);
    };
  }, [selectedPersonId]);

  // Busca assíncrona no backend como complemento (debounce 250ms)
  useEffect(() => {
    if (!eventId || !searchQuery.trim() || searchQuery.trim().length < 2) {
      setApiResults([]);
      return;
    }
    const timer = setTimeout(async () => {
      try {
        setIsSearchingApi(true);
        const res = await participantService.getParticipants({
          event_id: eventId,
          search: searchQuery.trim(),
          limit: 30,
        });
        setApiResults(res.items || []);
      } catch (e) {
        console.error("Erro na busca de participantes:", e);
      } finally {
        setIsSearchingApi(false);
      }
    }, 250);
    return () => clearTimeout(timer);
  }, [eventId, searchQuery]);

  // Combina lista pré-carregada e resultados da API
  const allAvailable = useMemo(() => {
    const map = new Map<number, ParticipantItem>();
    for (const p of participants) {
      map.set(p.person_id, p);
    }
    for (const p of apiResults) {
      map.set(p.person_id, p);
    }
    return Array.from(map.values());
  }, [participants, apiResults]);

  // Identifica o participante atualmente selecionado
  const selectedParticipant = useMemo(() => {
    if (!selectedPersonId) return null;
    return allAvailable.find((p) => p.person_id === selectedPersonId) || null;
  }, [selectedPersonId, allAvailable]);

  // Filtro inteligente: insensível a maiúsculas/minúsculas e acentos
  const filteredParticipants = useMemo(() => {
    const qNorm = normalizeStr(searchQuery);
    const qDigits = searchQuery.replace(/\D/g, "");

    // Se a busca estiver vazia, exibe os primeiros 30 participantes como sugestão
    if (!qNorm && !qDigits) {
      return allAvailable.slice(0, 30);
    }

    return allAvailable
      .filter((p) => {
        // 1. Busca por Nome (insensível a acento e maiúsculas)
        const nameNorm = normalizeStr(p.name);
        const nameMatch = qNorm ? nameNorm.includes(qNorm) : false;

        // 2. Busca por CPF: CRÍTICO! Só valida se o usuário digitou números (evita que includes("") seja true para todos)
        const pCpfDigits = p.cpf ? p.cpf.replace(/\D/g, "") : "";
        const cpfMatch =
          qDigits.length > 0 && pCpfDigits ? pCpfDigits.includes(qDigits) : false;

        // 3. Busca por E-mail
        const emailNorm = normalizeStr(p.email);
        const emailMatch = qNorm ? emailNorm.includes(qNorm) : false;

        // 4. Busca por Afiliação / Instituição
        const affNorm = normalizeStr(p.affiliation);
        const affMatch = qNorm && affNorm ? affNorm.includes(qNorm) : false;

        return nameMatch || cpfMatch || emailMatch || affMatch;
      })
      .slice(0, 30);
  }, [allAvailable, searchQuery]);

  const roleLabel = useMemo(() => {
    switch (role) {
      case "ADVISOR":
        return "Orientador";
      case "COADVISOR":
        return "Coorientador";
      case "STUDENT_LEADER":
        return "Estudante Líder";
      case "STUDENT_MEMBER":
        return "Estudante";
      default:
        return "Autor";
    }
  }, [role]);

  const displayName = selectedParticipant?.name || fallbackInfo?.name;
  const displayEmail = selectedParticipant?.email || fallbackInfo?.email;
  const displayCpf = selectedParticipant?.cpf || fallbackInfo?.cpf;

  const hasSelection = Boolean(selectedPersonId && (displayName || displayEmail));

  // Handler para selecionar um participante
  const handleSelect = (participant: ParticipantItem) => {
    onSelect(participant);
    setIsOpen(false);
    setIsEditing(false);
    setSearchQuery("");
  };

  // Handler para iniciar o modo de alteração com foco garantido no Safari
  const handleStartEditing = () => {
    setIsEditing(true);
    setIsOpen(true);
    setSearchQuery("");
    requestAnimationFrame(() => {
      setTimeout(() => {
        inputRef.current?.focus();
      }, 50);
    });
  };

  return (
    <div className="space-y-1.5" ref={containerRef}>
      {/* Header com Label e botão Remover */}
      <div className="flex items-center justify-between">
        <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
          {label} {required && <span className="text-red-500">*</span>}
        </label>
        {onRemove && (
          <button
            type="button"
            onClick={onRemove}
            className="text-[11px] font-medium text-red-500 hover:text-red-700 dark:hover:text-red-400 transition-colors flex items-center gap-1 cursor-pointer"
          >
            <X size={12} />
            Remover
          </button>
        )}
      </div>

      {/* CASO 1: Participante selecionado e NÃO está em modo de alteração */}
      {hasSelection && !isEditing ? (
        <div className="p-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xs flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <div
              className={`p-2 rounded-lg shrink-0 ${
                role.includes("ADVISOR")
                  ? "bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300"
                  : "bg-blue-100 text-blue-800 dark:bg-blue-950/60 dark:text-blue-300"
              }`}
            >
              {role.includes("ADVISOR") ? (
                <Award size={16} />
              ) : (
                <GraduationCap size={16} />
              )}
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="font-semibold text-xs text-slate-900 dark:text-white truncate">
                  {displayName}
                </span>
                <span className="text-[10px] uppercase font-bold px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 shrink-0">
                  {roleLabel}
                </span>
              </div>
              <div className="text-[11px] text-slate-500 dark:text-slate-400 truncate flex flex-wrap items-center gap-x-2 mt-0.5">
                {displayCpf && <span>CPF: {displayCpf}</span>}
                {displayEmail && <span>• {displayEmail}</span>}
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={handleStartEditing}
            className="px-2.5 py-1 text-xs font-medium text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 rounded-lg transition-colors shrink-0 cursor-pointer"
          >
            Alterar
          </button>
        </div>
      ) : (
        /* CASO 2: Sem participante selecionado OU em modo de alteração (Combobox Nativo) */
        <div className="relative">
          <div className="relative flex items-center">
            <div className="absolute left-3 pointer-events-none text-slate-400 flex items-center">
              {isSearchingApi ? (
                <Loader2 size={14} className="animate-spin text-blue-500" />
              ) : (
                <Search size={14} />
              )}
            </div>

            <input
              ref={inputRef}
              type="text"
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                if (!isOpen) setIsOpen(true);
              }}
              onFocus={() => setIsOpen(true)}
              onClick={() => setIsOpen(true)}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  e.preventDefault(); // Impede a submissão do formulário do modal!
                  const firstEligible = filteredParticipants.find(
                    (p) =>
                      !disabledPersonIds.includes(p.person_id) ||
                      p.person_id === selectedPersonId
                  );
                  if (firstEligible) {
                    handleSelect(firstEligible);
                  }
                } else if (e.key === "Escape") {
                  setIsOpen(false);
                  if (hasSelection) setIsEditing(false);
                }
              }}
              placeholder={
                hasSelection
                  ? `Digite novo nome ou CPF (Atual: ${displayName})...`
                  : "Digite o nome ou CPF para buscar participante cadastrado..."
              }
              className="w-full pl-9 pr-16 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-900 dark:text-white placeholder:text-slate-400 hover:border-slate-300 dark:hover:border-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors"
            />

            <div className="absolute right-2.5 flex items-center gap-1">
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => {
                    setSearchQuery("");
                    inputRef.current?.focus();
                  }}
                  className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors cursor-pointer"
                  title="Limpar busca"
                >
                  <X size={13} />
                </button>
              )}

              {hasSelection && (
                <button
                  type="button"
                  onClick={() => {
                    setIsEditing(false);
                    setIsOpen(false);
                    setSearchQuery("");
                  }}
                  className="px-1.5 py-0.5 text-[10px] font-semibold text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200 bg-slate-100 dark:bg-slate-800 rounded transition-colors cursor-pointer"
                  title="Cancelar alteração"
                >
                  Cancelar
                </button>
              )}

              <button
                type="button"
                onClick={() => setIsOpen(!isOpen)}
                className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors cursor-pointer"
              >
                <ChevronDown size={14} className={`transition-transform duration-200 ${isOpen ? "rotate-180" : ""}`} />
              </button>
            </div>
          </div>

          {/* Dropdown de Resultados */}
          {isOpen && (
            <div className="absolute left-0 right-0 top-full mt-1 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-2xl p-2 z-50 space-y-1.5 max-h-64 overflow-hidden flex flex-col">
              <div className="overflow-y-auto flex-1 divide-y divide-slate-100 dark:divide-slate-800/60 pr-1">
                {filteredParticipants.length === 0 ? (
                  <div className="p-4 text-center space-y-2">
                    <AlertCircle size={20} className="mx-auto text-amber-500" />
                    <p className="text-xs text-slate-600 dark:text-slate-400">
                      Nenhum participante encontrado com &quot;{searchQuery}&quot;.
                    </p>
                    <div className="pt-1">
                      <Link
                        href="/participants"
                        target="_blank"
                        className="inline-flex items-center gap-1 text-[11px] font-semibold text-blue-600 dark:text-blue-400 hover:underline"
                      >
                        <UserPlus size={12} />
                        Cadastrar novo participante na feira
                        <ExternalLink size={10} />
                      </Link>
                    </div>
                  </div>
                ) : (
                  filteredParticipants.map((participant) => {
                    const isDisabled =
                      disabledPersonIds.includes(participant.person_id) &&
                      participant.person_id !== selectedPersonId;
                    const isCurrent =
                      participant.person_id === selectedPersonId;

                    return (
                      <button
                        key={participant.participant_id || participant.person_id}
                        type="button"
                        disabled={isDisabled}
                        onClick={() => handleSelect(participant)}
                        className={`w-full text-left p-2 rounded-lg flex items-center justify-between gap-2 transition-colors ${
                          isDisabled
                            ? "opacity-40 cursor-not-allowed bg-slate-50/50 dark:bg-slate-800/30"
                            : isCurrent
                            ? "bg-blue-50 dark:bg-blue-950/40 text-blue-900 dark:text-blue-200"
                            : "hover:bg-slate-100 dark:hover:bg-slate-800/70 cursor-pointer"
                        }`}
                      >
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2">
                            <span className="font-semibold text-xs text-slate-900 dark:text-white truncate">
                              {participant.name}
                            </span>
                            {isCurrent && (
                              <span className="text-[10px] text-blue-600 dark:text-blue-400 font-bold flex items-center gap-0.5">
                                <Check size={10} /> Selecionado
                              </span>
                            )}
                            {isDisabled && (
                              <span className="text-[10px] text-amber-600 dark:text-amber-400 font-medium">
                                (Já selecionado neste trabalho)
                              </span>
                            )}
                          </div>
                          <div className="text-[11px] text-slate-500 dark:text-slate-400 truncate flex flex-wrap gap-x-2 mt-0.5">
                            {participant.cpf && <span>CPF: {participant.cpf}</span>}
                            <span>• {participant.email}</span>
                            {participant.affiliation && (
                              <span>• {participant.affiliation}</span>
                            )}
                          </div>
                        </div>

                        <span className="text-[10px] uppercase font-bold px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 shrink-0">
                          {participant.role}
                        </span>
                      </button>
                    );
                  })
                )}
              </div>

              {/* Rodapé informativo do dropdown */}
              <div className="pt-1.5 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 px-1">
                <span>
                  {filteredParticipants.length} participante(s) exibido(s)
                </span>
                <Link
                  href="/participants"
                  target="_blank"
                  className="font-medium text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1"
                >
                  Novo Participante
                  <ExternalLink size={10} />
                </Link>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
