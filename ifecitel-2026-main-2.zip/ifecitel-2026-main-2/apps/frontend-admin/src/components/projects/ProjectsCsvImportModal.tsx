"use client";

import React, { useState, useRef } from "react";
import {
  Upload,
  FileSpreadsheet,
  Download,
  CheckCircle2,
  RefreshCw,
  AlertTriangle,
  X,
  FileText,
  Users,
  MapPin,
  GraduationCap,
  Sparkles,
} from "lucide-react";
import { Modal } from "../ui/Modal";
import { Button } from "../ui/Button";
import { ProjectItem } from "../../types";
import {
  downloadProjectsCsvTemplate,
  parseProjectsCsv,
  ParseProjectsCsvResult,
  SubareaSimple,
} from "../../utils/projectsCsv";
import { projectService } from "../../services/project.service";

interface ProjectsCsvImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  eventId: number;
  subareas: SubareaSimple[];
  existingProjects: ProjectItem[];
  maxStudents?: number;
  onSuccess: (summary: { total: number; created: number; updated: number }) => void;
}

export function ProjectsCsvImportModal({
  isOpen,
  onClose,
  eventId,
  subareas,
  existingProjects,
  maxStudents = 5,
  onSuccess,
}: ProjectsCsvImportModalProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [fileName, setFileName] = useState<string | null>(null);
  const [fileSize, setFileSize] = useState<string | null>(null);
  const [parseResult, setParseResult] = useState<ParseProjectsCsvResult | null>(null);
  const [autoHomologate, setAutoHomologate] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [modalError, setModalError] = useState<string | null>(null);
  const [isDragOver, setIsDragOver] = useState(false);

  const [isDownloadingTemplate, setIsDownloadingTemplate] = useState(false);

  const handleDownloadTemplate = async () => {
    try {
      setIsDownloadingTemplate(true);
      const blob = await projectService.downloadTemplateCsv(eventId);
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", `modelo_trabalhos_easyevent_evento_${eventId}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (err) {
      downloadProjectsCsvTemplate(eventId, subareas, maxStudents);
    } finally {
      setIsDownloadingTemplate(false);
    }
  };

  const handleReset = () => {
    setFileName(null);
    setFileSize(null);
    setParseResult(null);
    setModalError(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleClose = () => {
    if (isSubmitting) return;
    handleReset();
    onClose();
  };

  const processFile = (file: File) => {
    if (!file.name.toLowerCase().endsWith(".csv")) {
      setModalError("Por favor, selecione um arquivo no formato CSV (.csv).");
      return;
    }

    setModalError(null);
    setFileName(file.name);
    setFileSize((file.size / 1024).toFixed(1) + " KB");

    const reader = new FileReader();
    reader.onload = (e) => {
      const content = e.target?.result as string;
      if (!content) {
        setModalError("O arquivo CSV selecionado está vazio.");
        return;
      }
      try {
        const result = parseProjectsCsv(content, subareas, existingProjects);
        if (result.totalRows === 0) {
          setModalError(
            "Nenhum trabalho científico foi encontrado. Verifique se o arquivo possui a linha de cabeçalho válida."
          );
        }
        setParseResult(result);
      } catch (err: any) {
        setModalError("Erro ao processar o arquivo CSV: " + (err.message || "Formato inválido"));
      }
    };
    reader.onerror = () => {
      setModalError("Erro ao ler o arquivo CSV do seu computador.");
    };
    reader.readAsText(file, "UTF-8");
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const handleConfirmImport = async () => {
    if (!parseResult || parseResult.rows.length === 0) return;

    const validRows = parseResult.rows.filter((r) => r.status !== "INVALID");
    if (validRows.length === 0) {
      setModalError("Não há trabalhos válidos para importar. Corrija os erros indicados.");
      return;
    }

    setIsSubmitting(true);
    setModalError(null);

    try {
      const payload = {
        auto_homologate: autoHomologate,
        items: validRows.map((r) => ({
          title: r.title,
          project_type: r.project_type,
          education_level: r.education_level,
          subarea_name: r.subarea_name,
          booth_number: r.booth_number || undefined,
          abstract: r.abstract || undefined,
          needs_electricity: r.needs_electricity,
          needs_table: r.needs_table,
          members: r.members,
        })),
      };

      const res = await projectService.importBatch(eventId, payload);
      onSuccess({
        total: res.total,
        created: res.created_count,
        updated: res.updated_count,
      });
      handleClose();
    } catch (err: any) {
      setModalError(
        err.response?.data?.detail ||
          "Ocorreu um erro ao importar os trabalhos no banco de dados."
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  const validCount = parseResult
    ? parseResult.rows.filter((r) => r.status !== "INVALID").length
    : 0;

  return (
    <Modal
      isOpen={isOpen}
      onClose={handleClose}
      title="Importar Trabalhos Científicos via Planilha CSV"
      maxWidth="max-w-5xl"
      error={modalError}
    >
      <div className="space-y-5">
        {/* Upload Zone */}
        {!fileName ? (
          <div
            onDragOver={(e) => {
              e.preventDefault();
              setIsDragOver(true);
            }}
            onDragLeave={() => setIsDragOver(false)}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`border-2 border-dashed rounded-2xl p-8 text-center cursor-pointer transition-all ${
              isDragOver
                ? "border-blue-500 bg-blue-50/70 dark:bg-blue-950/30 shadow-inner"
                : "border-slate-300 dark:border-slate-700 hover:border-blue-400 bg-slate-50/50 dark:bg-slate-800/40 hover:bg-blue-50/20"
            }`}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept=".csv"
              className="hidden"
              onChange={handleFileChange}
            />

            <div className="mx-auto w-12 h-12 rounded-2xl bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-blue-400 flex items-center justify-center mb-3">
              <Upload size={24} />
            </div>

            <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">
              Clique para selecionar ou arraste o arquivo CSV aqui
            </p>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Compatível com arquivos exportados do Microsoft Excel ou Google Planilhas (delimitador ponto e vírgula ou vírgula).
            </p>

            <div className="mt-4 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700">
              <FileSpreadsheet size={15} className="text-emerald-600" />
              <span>Apenas arquivos .csv (UTF-8)</span>
            </div>
          </div>
        ) : (
          <div className="p-4 rounded-xl bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-400">
                <FileSpreadsheet size={22} />
              </div>
              <div>
                <p className="text-xs font-bold text-slate-900 dark:text-white">
                  {fileName}
                </p>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  Tamanho: {fileSize}
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={handleReset}
              disabled={isSubmitting}
              className="px-2.5 py-1 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:text-slate-900 bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 rounded-lg transition-colors flex items-center gap-1"
            >
              <X size={14} />
              Trocar Arquivo
            </button>
          </div>
        )}

        {/* Resumo e Configurações */}
        {parseResult && parseResult.totalRows > 0 && (
          <div className="space-y-4">
            {/* Stat Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
                  Total Lidos
                </span>
                <span className="text-lg font-bold text-slate-900 dark:text-white">
                  {parseResult.totalRows}
                </span>
              </div>

              <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/60">
                <span className="text-[11px] font-semibold text-emerald-700 dark:text-emerald-400 uppercase tracking-wider block flex items-center gap-1">
                  <CheckCircle2 size={13} />
                  Novos
                </span>
                <span className="text-lg font-bold text-emerald-700 dark:text-emerald-300">
                  +{parseResult.newCount}
                </span>
              </div>

              <div className="p-3 rounded-xl bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800/60">
                <span className="text-[11px] font-semibold text-blue-700 dark:text-blue-400 uppercase tracking-wider block flex items-center gap-1">
                  <RefreshCw size={13} />
                  Atualizações
                </span>
                <span className="text-lg font-bold text-blue-700 dark:text-blue-300">
                  {parseResult.updateCount}
                </span>
              </div>

              <div
                className={`p-3 rounded-xl border ${
                  parseResult.invalidCount > 0
                    ? "bg-rose-50 dark:bg-rose-950/30 border-rose-200 dark:border-rose-800/60"
                    : "bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700"
                }`}
              >
                <span
                  className={`text-[11px] font-semibold uppercase tracking-wider block flex items-center gap-1 ${
                    parseResult.invalidCount > 0
                      ? "text-rose-700 dark:text-rose-400"
                      : "text-slate-500"
                  }`}
                >
                  <AlertTriangle size={13} />
                  Inválidos
                </span>
                <span
                  className={`text-lg font-bold ${
                    parseResult.invalidCount > 0
                      ? "text-rose-700 dark:text-rose-300"
                      : "text-slate-400"
                  }`}
                >
                  {parseResult.invalidCount}
                </span>
              </div>
            </div>

            {/* Configuração de Auto-Homologação */}
            <div className="p-3.5 rounded-xl bg-indigo-50/60 dark:bg-indigo-950/40 border border-indigo-200/80 dark:border-indigo-900/60 flex items-start justify-between gap-3">
              <div className="flex items-start gap-3">
                <div className="p-2 rounded-lg bg-indigo-100 dark:bg-indigo-900 text-indigo-700 dark:text-indigo-300 flex-shrink-0 mt-0.5">
                  <Sparkles size={18} />
                </div>
                <div>
                  <label
                    htmlFor="auto-homologate"
                    className="text-xs font-bold text-slate-900 dark:text-white cursor-pointer select-none"
                  >
                    Homologar trabalhos e alocar estandes automaticamente
                  </label>
                  <p className="text-[11px] text-slate-600 dark:text-slate-300 mt-0.5 leading-relaxed">
                    Quando ativado, os trabalhos importados são deferidos automaticamente (com status{" "}
                    <strong>HOMOLOGATED</strong>) e seus números de estande são confirmados. Desmarque caso queira mantê-los pendentes para homologação manual posterior.
                  </p>
                </div>
              </div>

              <input
                id="auto-homologate"
                type="checkbox"
                checked={autoHomologate}
                onChange={(e) => setAutoHomologate(e.target.checked)}
                className="w-4 h-4 mt-1 text-blue-600 bg-white dark:bg-slate-900 border-slate-300 dark:border-slate-700 rounded focus:ring-blue-500 cursor-pointer"
              />
            </div>

            {/* Informações da Sincronização Inteligente */}
            <div className="p-3 rounded-xl bg-blue-50/70 dark:bg-blue-950/40 border border-blue-200/80 dark:border-blue-900/60 text-xs text-blue-900 dark:text-blue-200 leading-relaxed">
              <strong>Sincronização Integrada:</strong> Participantes (orientadores e autores) que ainda não existirem serão cadastrados na base de pessoas com credenciais de acesso e código de barras gerados automaticamente. Subáreas são vinculadas por aproximação de nome.
            </div>

            {/* Tabela de Pré-visualização */}
            <div className="border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
              <div className="max-h-80 overflow-y-auto divide-y divide-slate-200 dark:divide-slate-800">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 sticky top-0 z-10">
                    <tr>
                      <th className="px-3 py-2 font-bold w-28">Status</th>
                      <th className="px-3 py-2 font-bold">Título / Detalhes</th>
                      <th className="px-3 py-2 font-bold w-36">Subárea</th>
                      <th className="px-3 py-2 font-bold w-20 text-center">Estande</th>
                      <th className="px-3 py-2 font-bold w-52">Orientador & Autores</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 bg-white dark:bg-slate-900">
                    {parseResult.rows.map((row, idx) => {
                      const advisor = row.members.find((m) => m.role === "ADVISOR");
                      const coadvisor = row.members.find((m) => m.role === "COADVISOR");
                      const students = row.members.filter(
                        (m) => m.role === "STUDENT_LEADER" || m.role === "STUDENT_MEMBER"
                      );

                      return (
                        <tr
                          key={idx}
                          className={`hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition-colors ${
                            row.status === "INVALID"
                              ? "bg-rose-50/40 dark:bg-rose-950/20"
                              : ""
                          }`}
                        >
                          <td className="px-3 py-2.5 align-top">
                            <div className="flex flex-col gap-1">
                              {row.status === "NEW" && (
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300">
                                  <CheckCircle2 size={11} />
                                  NOVO
                                </span>
                              )}
                              {row.status === "UPDATE" && (
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-blue-100 dark:bg-blue-950 text-blue-800 dark:text-blue-300">
                                  <RefreshCw size={11} />
                                  ATUALIZAR
                                </span>
                              )}
                              {row.status === "INVALID" && (
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-rose-100 dark:bg-rose-950 text-rose-800 dark:text-rose-300">
                                  <AlertTriangle size={11} />
                                  ERRO
                                </span>
                              )}
                              <span className="text-[10px] text-slate-400">
                                Linha {row.line_number}
                              </span>
                            </div>
                          </td>

                          <td className="px-3 py-2.5 align-top space-y-1">
                            <div className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                              <FileText size={14} className="text-slate-400 flex-shrink-0" />
                              <span>
                                {row.title || (
                                  <span className="italic text-rose-500">
                                    (Sem título informado)
                                  </span>
                                )}
                              </span>
                            </div>

                            <div className="flex items-center gap-2 text-[11px] text-slate-500 dark:text-slate-400">
                              <span className="inline-flex items-center gap-1 px-1.5 py-0.2 rounded bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-medium">
                                {row.project_type === "TECHNOLOGICAL"
                                  ? "⚙️ Tecnológico"
                                  : "🔬 Científico"}
                              </span>
                              <span>•</span>
                              <span className="inline-flex items-center gap-1">
                                <GraduationCap size={12} />
                                {row.education_level}
                              </span>
                              {row.needs_electricity && (
                                <span className="inline-flex items-center gap-0.5 text-[9px] px-1.5 py-0.5 rounded bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-400 border border-amber-200 dark:border-amber-800 font-medium">
                                  ⚡ Energia
                                </span>
                              )}
                              {row.needs_table && (
                                <span className="inline-flex items-center gap-0.5 text-[9px] px-1.5 py-0.5 rounded bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-400 border border-blue-200 dark:border-blue-800 font-medium">
                                  🪑 Mesa
                                </span>
                              )}
                            </div>

                            {row.errors.length > 0 && (
                              <div className="pt-1 text-[11px] text-rose-600 dark:text-rose-400 font-semibold space-y-0.5">
                                {row.errors.map((err, errIdx) => (
                                  <p key={errIdx}>⚠️ {err}</p>
                                ))}
                              </div>
                            )}
                          </td>

                          <td className="px-3 py-2.5 align-top text-slate-700 dark:text-slate-300">
                            {row.subarea_name.includes(" -> ") ? (
                              <div className="inline-flex flex-col text-[11px] leading-tight">
                                <span className="font-bold text-slate-500 dark:text-slate-400 text-[10px]">
                                  {row.subarea_name.split(" -> ")[0]}
                                </span>
                                <span className="font-semibold text-teal-700 dark:text-teal-400">
                                  {row.subarea_name.split(" -> ")[1]}
                                </span>
                              </div>
                            ) : (
                              <span className="inline-block px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 font-medium text-[11px]">
                                {row.subarea_name}
                              </span>
                            )}
                          </td>

                          <td className="px-3 py-2.5 align-top text-center">
                            {row.booth_number ? (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded font-mono font-bold bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-900 text-[11px]">
                                <MapPin size={11} />
                                {row.booth_number}
                              </span>
                            ) : (
                              <span className="text-slate-400 text-[11px] italic">
                                —
                              </span>
                            )}
                          </td>

                          <td className="px-3 py-2.5 align-top text-[11px] space-y-1">
                            {advisor && (
                              <div className="text-slate-800 dark:text-slate-200">
                                <span className="font-semibold text-blue-700 dark:text-blue-400">
                                  Orientador:
                                </span>{" "}
                                {advisor.name}
                                {advisor.cpf && (
                                  <span className="text-[10px] text-slate-500 dark:text-slate-400 font-mono ml-1">
                                    ({advisor.cpf})
                                  </span>
                                )}
                                {advisor.affiliation && (
                                  <span className="text-[10px] text-slate-500 dark:text-slate-400 block truncate">
                                    🏫 {advisor.affiliation}
                                  </span>
                                )}
                                {advisor.tshirt_size && (
                                  <span className="ml-1 px-1 py-0.2 rounded bg-slate-100 dark:bg-slate-800 text-[10px] font-bold text-slate-700 dark:text-slate-300">
                                    👕 {advisor.tshirt_size}
                                  </span>
                                )}
                              </div>
                            )}
                            {coadvisor && (
                              <div className="text-slate-600 dark:text-slate-400">
                                <span className="font-semibold text-purple-700 dark:text-purple-400">
                                  Coorientador:
                                </span>{" "}
                                {coadvisor.name}
                                {coadvisor.cpf && (
                                  <span className="text-[10px] text-slate-500 dark:text-slate-400 font-mono ml-1">
                                    ({coadvisor.cpf})
                                  </span>
                                )}
                                {coadvisor.affiliation && (
                                  <span className="text-[10px] text-slate-500 dark:text-slate-400 block truncate">
                                    🏫 {coadvisor.affiliation}
                                  </span>
                                )}
                                {coadvisor.tshirt_size && (
                                  <span className="ml-1 px-1 py-0.2 rounded bg-slate-100 dark:bg-slate-800 text-[10px] font-bold text-slate-700 dark:text-slate-300">
                                    👕 {coadvisor.tshirt_size}
                                  </span>
                                )}
                              </div>
                            )}
                            <div className="flex items-center gap-1 text-slate-600 dark:text-slate-400 pt-0.5">
                              <Users size={12} className="text-emerald-600 dark:text-emerald-400" />
                              <span className="font-semibold text-emerald-700 dark:text-emerald-400">
                                {students.length} autor(es):
                              </span>{" "}
                              <span
                                className="truncate max-w-[170px]"
                                title={students
                                  .map(
                                    (s) =>
                                      `${s.name}${s.cpf ? ` (CPF: ${s.cpf})` : ""}${s.affiliation ? ` [${s.affiliation}]` : ""} (${s.tshirt_size || "M"})`
                                  )
                                  .join(", ")}
                              >
                                {students
                                  .map(
                                    (s) =>
                                      `${s.name}${s.cpf ? ` (${s.cpf})` : ""}${s.affiliation ? ` [${s.affiliation}]` : ""} (${s.tshirt_size || "M"})`
                                  )
                                  .join(", ")}
                              </span>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Rodapé e Ações */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-3 border-t border-slate-100 dark:border-slate-800">
          <button
            type="button"
            onClick={handleDownloadTemplate}
            disabled={isDownloadingTemplate}
            className="text-xs text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1.5 font-medium disabled:opacity-50"
          >
            {isDownloadingTemplate ? (
              <RefreshCw size={14} className="animate-spin" />
            ) : (
              <Download size={14} />
            )}
            Baixar Modelo Esqueleto CSV (.csv)
          </button>

          <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
            <Button
              type="button"
              variant="outline"
              onClick={handleClose}
              disabled={isSubmitting}
            >
              Cancelar
            </Button>

            <Button
              type="button"
              variant="primary"
              disabled={!parseResult || validCount === 0 || isSubmitting}
              isLoading={isSubmitting}
              onClick={handleConfirmImport}
            >
              Confirmar e Importar ({validCount} Trabalhos)
            </Button>
          </div>
        </div>
      </div>
    </Modal>
  );
}
