"use client";

import React, { useState, useMemo } from "react";
import {
  AlertTriangle,
  CheckCircle2,
  Search,
  Filter,
  UserCheck,
  ChevronDown,
  ChevronUp,
  MapPin,
  Sparkles,
} from "lucide-react";
import { CriticalProjectItem } from "../../types";
import { Button } from "../ui/Button";

interface CriticalProjectsWidgetProps {
  criticalProjects: CriticalProjectItem[];
  onAllocateProject: (project: CriticalProjectItem) => void;
  headerAction?: React.ReactNode;
  canAllocate?: boolean;
}

export const CriticalProjectsWidget: React.FC<CriticalProjectsWidgetProps> = ({
  criticalProjects,
  onAllocateProject,
  headerAction,
  canAllocate = true,
}) => {
  const [isExpanded, setIsExpanded] = useState(true);
  const [filterType, setFilterType] = useState<"ALL" | "ZERO" | "BELOW">("ALL");
  const [searchTerm, setSearchTerm] = useState("");

  const zeroCount = useMemo(
    () => criticalProjects.filter((p) => p.gap_status === "ZERO_EVALUATORS").length,
    [criticalProjects]
  );
  const belowCount = useMemo(
    () => criticalProjects.filter((p) => p.gap_status === "BELOW_QUOTA").length,
    [criticalProjects]
  );

  const filteredProjects = useMemo(() => {
    return criticalProjects.filter((p) => {
      if (filterType === "ZERO" && p.gap_status !== "ZERO_EVALUATORS") return false;
      if (filterType === "BELOW" && p.gap_status !== "BELOW_QUOTA") return false;
      if (searchTerm.trim()) {
        const query = searchTerm.toLowerCase();
        const matchTitle = p.title.toLowerCase().includes(query);
        const matchStand = (p.stand_number || "").toLowerCase().includes(query);
        const matchArea = p.area_name.toLowerCase().includes(query);
        return matchTitle || matchStand || matchArea;
      }
      return true;
    });
  }, [criticalProjects, filterType, searchTerm]);

  return (
    <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
      {/* Cabeçalho do Widget */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-base font-bold tracking-tight text-slate-900 dark:text-white flex items-center gap-2">
            <AlertTriangle size={18} className="text-red-500" />
            Diagnóstico de Trabalhos Críticos & Gaps de Avaliação (4A)
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Trabalhos presentes nos estandes que requerem atenção imediata por falta de avaliadores suficientes.
          </p>
        </div>

        <div className="flex items-center gap-3">
          {headerAction}

          {/* Botão de Expandir / Recolher */}
          <button
            type="button"
            onClick={() => setIsExpanded(!isExpanded)}
            className="inline-flex items-center gap-1 text-xs font-semibold text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
          >
            <span>{isExpanded ? "Recolher Lista" : "Expandir Lista"}</span>
            {isExpanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
          </button>
        </div>
      </div>

      {/* Contadores de Emergência (4A) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {/* Contador 1: Zero Avaliadores */}
        <div
          onClick={() => setFilterType(filterType === "ZERO" ? "ALL" : "ZERO")}
          className={`p-3.5 rounded-xl border cursor-pointer transition-all flex items-center justify-between ${
            filterType === "ZERO"
              ? "bg-red-100/70 dark:bg-red-950/70 border-red-400 ring-2 ring-red-400/40"
              : zeroCount > 0
              ? "bg-red-50 dark:bg-red-950/30 border-red-200 dark:border-red-900/60 hover:border-red-300"
              : "bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800"
          }`}
        >
          <div className="flex items-center gap-3">
            <div className={`w-9 h-9 rounded-lg flex items-center justify-center font-black ${
              zeroCount > 0 ? "bg-red-600 text-white animate-pulse" : "bg-slate-200 text-slate-600"
            }`}>
              {zeroCount}
            </div>
            <div>
              <p className="text-xs font-bold text-slate-900 dark:text-white">
                Trabalhos com ZERO avaliadores
              </p>
              <p className="text-[11px] text-slate-500">
                {zeroCount > 0 ? "Nenhum avaliador atribuído até o momento" : "Nenhum trabalho desatendido"}
              </p>
            </div>
          </div>
          <span className="text-[11px] font-semibold text-red-600 dark:text-red-400 uppercase tracking-wider">
            {filterType === "ZERO" ? "Filtro Ativo" : "Filtrar"}
          </span>
        </div>

        {/* Contador 2: Cota Incompleta */}
        <div
          onClick={() => setFilterType(filterType === "BELOW" ? "ALL" : "BELOW")}
          className={`p-3.5 rounded-xl border cursor-pointer transition-all flex items-center justify-between ${
            filterType === "BELOW"
              ? "bg-amber-100/70 dark:bg-amber-950/70 border-amber-400 ring-2 ring-amber-400/40"
              : belowCount > 0
              ? "bg-amber-50 dark:bg-amber-950/30 border-amber-200 dark:border-amber-900/60 hover:border-amber-300"
              : "bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800"
          }`}
        >
          <div className="flex items-center gap-3">
            <div className={`w-9 h-9 rounded-lg flex items-center justify-center font-black ${
              belowCount > 0 ? "bg-amber-600 text-white" : "bg-slate-200 text-slate-600"
            }`}>
              {belowCount}
            </div>
            <div>
              <p className="text-xs font-bold text-slate-900 dark:text-white">
                Trabalhos com cota incompleta
              </p>
              <p className="text-[11px] text-slate-500">
                Possuem 1 ou mais avaliadores, mas abaixo do mínimo exigido
              </p>
            </div>
          </div>
          <span className="text-[11px] font-semibold text-amber-600 dark:text-amber-400 uppercase tracking-wider">
            {filterType === "BELOW" ? "Filtro Ativo" : "Filtrar"}
          </span>
        </div>
      </div>

      {/* Tabela / Gaveta Expansível de Ação Imediata */}
      {isExpanded && (
        <div className="space-y-3 pt-2">
          {/* Barra de Busca e Filtros Rápidos */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-2.5 text-slate-400" size={14} />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Buscar por estande, título ou área..."
                className="w-full pl-8 pr-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-blue-500"
              />
            </div>

            <div className="flex items-center gap-1.5 text-xs">
              <span className="text-slate-400 font-medium">Exibindo:</span>
              <button
                type="button"
                onClick={() => setFilterType("ALL")}
                className={`px-2 py-1 rounded-lg font-semibold ${
                  filterType === "ALL"
                    ? "bg-slate-900 text-white dark:bg-white dark:text-slate-900"
                    : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300"
                }`}
              >
                Todos ({criticalProjects.length})
              </button>
              <button
                type="button"
                onClick={() => setFilterType("ZERO")}
                className={`px-2 py-1 rounded-lg font-semibold ${
                  filterType === "ZERO"
                    ? "bg-red-600 text-white"
                    : "bg-red-50 dark:bg-red-950/40 text-red-700 dark:text-red-300"
                }`}
              >
                Sem Avaliador ({zeroCount})
              </button>
              <button
                type="button"
                onClick={() => setFilterType("BELOW")}
                className={`px-2 py-1 rounded-lg font-semibold ${
                  filterType === "BELOW"
                    ? "bg-amber-600 text-white"
                    : "bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-300"
                }`}
              >
                Cota Incompleta ({belowCount})
              </button>
            </div>
          </div>

          {/* Estado Vazio */}
          {criticalProjects.length === 0 ? (
            <div className="p-8 rounded-xl bg-emerald-50/60 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-800 text-center space-y-2">
              <div className="w-12 h-12 rounded-full bg-emerald-100 dark:bg-emerald-900/60 text-emerald-600 mx-auto flex items-center justify-center">
                <CheckCircle2 size={24} />
              </div>
              <h3 className="text-sm font-bold text-emerald-900 dark:text-emerald-200">
                Parabéns! Nenhum estande vulnerável no momento
              </h3>
              <p className="text-xs text-emerald-700 dark:text-emerald-400 max-w-md mx-auto">
                Todos os trabalhos presentes possuem cobertura completa de avaliadores de acordo com as cotas mínimas da feira.
              </p>
            </div>
          ) : filteredProjects.length === 0 ? (
            <div className="p-6 text-center text-xs text-slate-400">
              Nenhum trabalho encontrado com os filtros informados.
            </div>
          ) : (
            <div className="border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
              <div className="overflow-x-auto max-h-[380px] overflow-y-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead className="bg-slate-50 dark:bg-slate-800/80 sticky top-0 border-b border-slate-200 dark:border-slate-700 z-10">
                    <tr>
                      <th className="py-2.5 px-3 font-bold text-slate-600 dark:text-slate-300">Estande</th>
                      <th className="py-2.5 px-3 font-bold text-slate-600 dark:text-slate-300">Trabalho</th>
                      <th className="py-2.5 px-3 font-bold text-slate-600 dark:text-slate-300">Grande Área</th>
                      <th className="py-2.5 px-3 font-bold text-slate-600 dark:text-slate-300">Avaliadores Alocados</th>
                      <th className="py-2.5 px-3 font-bold text-slate-600 dark:text-slate-300">Status</th>
                      {canAllocate && (
                        <th className="py-2.5 px-3 font-bold text-slate-600 dark:text-slate-300 text-right">Ação</th>
                      )}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {filteredProjects.map((proj) => {
                      const isZero = proj.gap_status === "ZERO_EVALUATORS";

                      return (
                        <tr
                          key={proj.project_id}
                          className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors"
                        >
                          {/* Estande */}
                          <td className="py-2.5 px-3 whitespace-nowrap">
                            <span className="font-mono font-bold text-slate-900 dark:text-white flex items-center gap-1">
                              <MapPin size={12} className={isZero ? "text-red-500" : "text-amber-500"} />
                              {proj.stand_number || `ESTANDE #${proj.project_id}`}
                            </span>
                            <span className="text-[10px] text-slate-400 block">{proj.education_level}</span>
                          </td>

                          {/* Título */}
                          <td className="py-2.5 px-3 min-w-[220px] max-w-[320px]">
                            <p className="font-semibold text-slate-900 dark:text-white line-clamp-1" title={proj.title}>
                              {proj.title}
                            </p>
                            <span className="text-[10px] text-slate-400">ID #{proj.project_id}</span>
                          </td>

                          {/* Área */}
                          <td className="py-2.5 px-3 whitespace-nowrap text-slate-600 dark:text-slate-300">
                            <span className="line-clamp-1 max-w-[180px]" title={proj.area_name}>
                              {proj.area_name}
                            </span>
                          </td>

                          {/* Avaliadores Alocados */}
                          <td className="py-2.5 px-3">
                            {proj.allocated_evaluators.length === 0 ? (
                              <span className="text-[11px] font-bold text-red-600 dark:text-red-400">
                                Nenhum avaliador
                              </span>
                            ) : (
                              <div className="flex flex-wrap gap-1">
                                {proj.allocated_evaluators.map((evaluator) => (
                                  <span
                                    key={evaluator.id}
                                    className="px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-[10px] font-medium text-slate-700 dark:text-slate-300"
                                    title={evaluator.name}
                                  >
                                    {evaluator.name.split(" ")[0]}
                                  </span>
                                ))}
                              </div>
                            )}
                          </td>

                          {/* Status */}
                          <td className="py-2.5 px-3 whitespace-nowrap">
                            {isZero ? (
                              <span className="px-2 py-0.5 rounded-full bg-red-100 dark:bg-red-950/60 text-red-800 dark:text-red-300 font-bold text-[10px]">
                                0 de {proj.min_evaluators} avaliadores
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 rounded-full bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 font-bold text-[10px]">
                                {proj.allocated_evaluators_count} de {proj.min_evaluators} avaliadores
                              </span>
                            )}
                          </td>

                          {/* Ação Direta na Linha */}
                          {canAllocate && (
                            <td className="py-2.5 px-3 text-right whitespace-nowrap">
                              <Button
                                type="button"
                                onClick={() => onAllocateProject(proj)}
                                variant="outline"
                                size="sm"
                                className="h-7 px-2 text-xs font-semibold text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950/50 border-blue-200 dark:border-blue-900 gap-1"
                              >
                                <UserCheck size={12} />
                                <span>Alocar</span>
                              </Button>
                            </td>
                          )}
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
