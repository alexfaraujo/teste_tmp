"use client";

import React from "react";
import Link from "next/link";
import {
  Layers,
  AlertTriangle,
  CheckCircle2,
  Users,
  UserPlus,
  ExternalLink,
  Cpu,
  FlaskConical,
  Binary,
  BookOpen,
  Sparkles,
} from "lucide-react";
import { AdminAreaDiagnostic } from "../../types";

interface AreaRiskGridProps {
  areas: AdminAreaDiagnostic[];
  headerAction?: React.ReactNode;
  canRegisterEvaluator?: boolean;
}

const getAreaIcon = (name: string) => {
  const lower = name.toLowerCase();
  if (lower.includes("agr") || lower.includes("eng")) return <Cpu size={18} className="text-amber-500" />;
  if (lower.includes("bio") || lower.includes("saúd") || lower.includes("saud")) return <FlaskConical size={18} className="text-emerald-500" />;
  if (lower.includes("exat") || lower.includes("terr")) return <Binary size={18} className="text-blue-500" />;
  if (lower.includes("hum") || lower.includes("soc") || lower.includes("art")) return <BookOpen size={18} className="text-purple-500" />;
  return <Sparkles size={18} className="text-teal-500" />;
};

export const AreaRiskGrid: React.FC<AreaRiskGridProps> = ({
  areas,
  headerAction,
  canRegisterEvaluator = true,
}) => {
  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-base font-bold tracking-tight text-slate-900 dark:text-white flex items-center gap-2">
            <Layers size={18} className="text-teal-600 dark:text-teal-400" />
            Grandes Áreas & Termômetro de Cobertura de Avaliadores (3A)
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Aderência e balanço entre demanda de estandes e avaliadores presentes por Grande Área do Conhecimento.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-4">
          {/* Legenda Semafórica */}
          <div className="flex items-center gap-3 text-xs">
            <span className="inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-medium">
              <span className="w-2 h-2 rounded-full bg-emerald-500" /> Suficiente
            </span>
            <span className="inline-flex items-center gap-1 text-amber-600 dark:text-amber-400 font-medium">
              <span className="w-2 h-2 rounded-full bg-amber-500" /> Atenção
            </span>
            <span className="inline-flex items-center gap-1 text-red-600 dark:text-red-400 font-medium">
              <span className="w-2 h-2 rounded-full bg-red-500" /> Crítico (Déficit)
            </span>
          </div>

          {headerAction}
        </div>
      </div>

      {/* Grid de Áreas */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {areas.map((area) => {
          const isCritical = area.health_status === "RED";
          const isWarning = area.health_status === "YELLOW";

          return (
            <div
              key={area.area_id}
              className={`p-5 rounded-2xl bg-white dark:bg-slate-900 border transition-all flex flex-col justify-between ${
                isCritical
                  ? "border-red-300 dark:border-red-900/80 shadow-[0_0_15px_rgba(239,68,68,0.08)]"
                  : isWarning
                  ? "border-amber-300 dark:border-amber-800/80"
                  : "border-slate-200 dark:border-slate-800 hover:border-teal-500/40"
              }`}
            >
              <div>
                {/* Cabeçalho do Card da Área */}
                <div className="flex items-start justify-between gap-2.5">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center flex-shrink-0">
                      {getAreaIcon(area.area_name)}
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-slate-900 dark:text-white line-clamp-1" title={area.area_name}>
                        {area.area_name}
                      </h3>
                      <p className="text-[11px] text-slate-400">ID #{area.area_id}</p>
                    </div>
                  </div>

                  {/* Badge Semafórico de Saúde */}
                  {isCritical ? (
                    <span className="px-2 py-0.5 rounded-full bg-red-50 dark:bg-red-950/60 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-300 text-[11px] font-bold flex-shrink-0 flex items-center gap-1 animate-pulse">
                      <AlertTriangle size={11} />
                      Crítico
                    </span>
                  ) : isWarning ? (
                    <span className="px-2 py-0.5 rounded-full bg-amber-50 dark:bg-amber-950/60 border border-amber-200 dark:border-amber-800 text-amber-700 dark:text-amber-300 text-[11px] font-bold flex-shrink-0 flex items-center gap-1">
                      <AlertTriangle size={11} />
                      Atenção
                    </span>
                  ) : (
                    <span className="px-2 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300 text-[11px] font-semibold flex-shrink-0 flex items-center gap-1">
                      <CheckCircle2 size={11} />
                      Suficiente
                    </span>
                  )}
                </div>

                {/* Barra de Progresso de Avaliações */}
                <div className="mt-4">
                  <div className="flex justify-between items-center text-xs mb-1.5">
                    <span className="font-semibold text-slate-700 dark:text-slate-300">
                      Progresso de Avaliação:
                    </span>
                    <span className="font-bold font-mono text-slate-900 dark:text-white">
                      {area.progress_percent}%
                    </span>
                  </div>
                  <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-2 overflow-hidden">
                    <div
                      className={`h-2 rounded-full transition-all duration-700 ${
                        isCritical
                          ? "bg-red-500"
                          : isWarning
                          ? "bg-amber-500"
                          : "bg-teal-500"
                      }`}
                      style={{ width: `${area.progress_percent}%` }}
                    />
                  </div>
                </div>

                {/* Métricas Duplas Integradas (Opção 1C no Admin) */}
                <div className="mt-4 grid grid-cols-2 gap-2 text-xs">
                  <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
                    <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
                      Estandes Presentes
                    </span>
                    <span className="text-sm font-black text-slate-900 dark:text-white mt-0.5 block">
                      {area.present_projects} <span className="text-xs font-normal text-slate-400">/ {area.total_projects}</span>
                    </span>
                  </div>

                  <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
                    <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
                      Fichas Concluídas
                    </span>
                    <span className="text-sm font-black text-slate-900 dark:text-white mt-0.5 block">
                      {area.evaluations_completed} <span className="text-xs font-normal text-slate-400">/ {area.expected_evaluations}</span>
                    </span>
                  </div>
                </div>

                {/* Linha de Avaliadores na Área */}
                <div className="mt-3 p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800/60 flex items-center justify-between text-xs">
                  <span className="flex items-center gap-1.5 text-slate-500 dark:text-slate-400">
                    <Users size={13} className="text-purple-500" />
                    Avaliadores da Área:
                  </span>
                  <span className="font-bold font-mono text-slate-800 dark:text-slate-200">
                    {area.present_evaluators} presentes <span className="font-normal text-slate-400">({area.registered_evaluators} cad.)</span>
                  </span>
                </div>

                {/* Alerta de Déficit Necessário */}
                {area.deficit_evaluators_needed > 0 && (
                  <div className="mt-3 p-2.5 rounded-xl bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-900 text-red-700 dark:text-red-300 text-xs font-bold flex items-center gap-2">
                    <AlertTriangle size={14} className="flex-shrink-0 text-red-600" />
                    <span>
                      Déficit: Necessário conseguir +{area.deficit_evaluators_needed} avaliador(es) para esta área!
                    </span>
                  </div>
                )}
              </div>

              {/* Botão de Ação Rápida no Rodapé do Card */}
              <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                <span className="text-[11px] text-slate-400">
                  {area.projects_at_risk_count > 0 ? (
                    <strong className="text-amber-600 dark:text-amber-400">
                      {area.projects_at_risk_count} trabalhos vulneráveis
                    </strong>
                  ) : (
                    "Área regularizada"
                  )}
                </span>

                {canRegisterEvaluator && (
                  <Link href={`/participants?role=EVALUATOR`}>
                    <button
                      type="button"
                      className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-semibold text-purple-600 dark:text-purple-400 hover:bg-purple-50 dark:hover:bg-purple-950/50 transition-colors"
                    >
                      <UserPlus size={13} />
                      <span>+ Cadastrar Avaliador</span>
                    </button>
                  </Link>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
