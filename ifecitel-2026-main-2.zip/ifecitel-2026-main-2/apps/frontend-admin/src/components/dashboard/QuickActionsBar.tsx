"use client";

import React from "react";
import Link from "next/link";
import {
  Scale,
  UserPlus,
  RefreshCw,
  Pause,
  Play,
  Clock,
  ExternalLink,
} from "lucide-react";
import { Button } from "../ui/Button";

interface QuickActionsBarProps {
  onAutoBalance: () => void;
  onRefresh: () => void;
  isPaused: boolean;
  onTogglePause: () => void;
  secondsRemaining: number;
  totalInterval?: number;
  isRefreshing: boolean;
  lastUpdated: Date | null;
  isOperator?: boolean;
}

export const QuickActionsBar: React.FC<QuickActionsBarProps> = ({
  onAutoBalance,
  onRefresh,
  isPaused,
  onTogglePause,
  secondsRemaining,
  totalInterval = 30,
  isRefreshing,
  lastUpdated,
  isOperator = false,
}) => {
  // Cálculo do raio e progresso do timer circular
  const radius = 13;
  const circumference = 2 * Math.PI * radius;
  const progressRatio = totalInterval > 0 ? secondsRemaining / totalInterval : 0;
  const strokeDashoffset = circumference - progressRatio * circumference;

  return (
    <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col xl:flex-row xl:items-center justify-between gap-4">
      {/* Bloco 1: Ações Rápidas de Intervenção */}
      <div className="flex flex-wrap items-center gap-2.5">
        <span className="text-xs font-black uppercase tracking-wider text-slate-400 dark:text-slate-500 mr-1 flex items-center gap-1.5">
          <Scale size={14} className="text-purple-600 dark:text-purple-400" />
          {isOperator ? "Modo Consulta (Apoio)" : "Ações Rápidas:"}
        </span>

        {!isOperator && (
          <>
            {/* Botão 1: Auto-Balance */}
            <Button
              type="button"
              onClick={onAutoBalance}
              variant="primary"
              size="sm"
              className="bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold gap-1.5 shadow-sm active:scale-95 transition-all"
            >
              <Scale size={14} />
              <span>Rebalancear Sistema (Δ ≤ 1)</span>
            </Button>

            {/* Botão 2: Cadastrar Novo Avaliador (Leva para Gestão de Participantes com fluxo completo) */}
            <Link href="/participants?role=EVALUATOR">
              <Button
                type="button"
                variant="outline"
                size="sm"
                className="border-amber-300 dark:border-amber-800/80 bg-amber-50 dark:bg-amber-950/40 text-amber-800 dark:text-amber-300 hover:bg-amber-100 dark:hover:bg-amber-900/60 text-xs font-semibold gap-1.5"
              >
                <UserPlus size={14} />
                <span>+ Cadastrar Novo Avaliador</span>
                <ExternalLink size={12} className="opacity-70" />
              </Button>
            </Link>
          </>
        )}
      </div>

      {/* Bloco 2: Monitoramento em Tempo Real (6A + 6B) */}
      <div className="flex flex-wrap items-center justify-between sm:justify-end gap-3 pt-3 xl:pt-0 border-t xl:border-t-0 border-slate-100 dark:border-slate-800">
        {/* Status Ao Vivo com Pulso */}
        <div className="flex items-center gap-2 px-2.5 py-1 rounded-full bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700">
          <span className="relative flex h-2.5 w-2.5">
            {!isPaused && (
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
            )}
            <span
              className={`relative inline-flex rounded-full h-2.5 w-2.5 ${
                isPaused ? "bg-amber-500" : "bg-emerald-500"
              }`}
            />
          </span>
          <span className="text-[11px] font-bold text-slate-700 dark:text-slate-200 uppercase tracking-wider">
            {isPaused ? "Pausado" : "Ao Vivo"}
          </span>
        </div>

        {/* Anel SVG Regressivo de 30 Segundos */}
        <div className="flex items-center gap-1.5" title={`Próxima sincronização em ${secondsRemaining}s`}>
          <div className="relative w-8 h-8 flex items-center justify-center">
            <svg className="w-8 h-8 -rotate-90" viewBox="0 0 32 32">
              <circle
                cx="16"
                cy="16"
                r={radius}
                className="stroke-slate-200 dark:stroke-slate-800 fill-none"
                strokeWidth="2.5"
              />
              <circle
                cx="16"
                cy="16"
                r={radius}
                className={`fill-none transition-all duration-1000 ease-linear ${
                  isPaused
                    ? "stroke-amber-500"
                    : secondsRemaining <= 5
                    ? "stroke-red-500"
                    : "stroke-teal-500"
                }`}
                strokeWidth="2.5"
                strokeDasharray={circumference}
                strokeDashoffset={isPaused ? 0 : strokeDashoffset}
                strokeLinecap="round"
              />
            </svg>
            <span className="absolute text-[10px] font-black font-mono text-slate-700 dark:text-slate-300">
              {secondsRemaining}s
            </span>
          </div>
        </div>

        {/* Botão Pausar / Retomar */}
        <Button
          type="button"
          onClick={onTogglePause}
          variant="outline"
          size="sm"
          className="h-8 px-2.5 text-xs text-slate-600 dark:text-slate-300 gap-1"
          title={isPaused ? "Retomar atualização automática" : "Pausar atualização automática"}
        >
          {isPaused ? <Play size={13} className="text-emerald-500" /> : <Pause size={13} />}
          <span>{isPaused ? "Retomar" : "Pausar"}</span>
        </Button>

        {/* Botão Atualizar Agora */}
        <Button
          type="button"
          onClick={onRefresh}
          disabled={isRefreshing}
          variant="outline"
          size="sm"
          className="h-8 px-2.5 text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 gap-1.5"
          title="Forçar requisição única agora"
        >
          <RefreshCw size={13} className={isRefreshing ? "animate-spin text-blue-600" : ""} />
          <span>{isRefreshing ? "Atualizando..." : "Atualizar"}</span>
        </Button>

        {/* Timestamp da última atualização */}
        {lastUpdated && (
          <span className="text-[11px] text-slate-400 dark:text-slate-500 hidden sm:inline-flex items-center gap-1">
            <Clock size={11} />
            {lastUpdated.toLocaleTimeString()}
          </span>
        )}
      </div>
    </div>
  );
};
