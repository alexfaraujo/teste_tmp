"use client";

import React, { useEffect, useState } from "react";
import {
  UserCheck,
  AlertCircle,
  CheckCircle2,
  MapPin,
  Users,
  Search,
  ShieldAlert,
} from "lucide-react";
import { CriticalProjectItem, EvaluatorListItem } from "../../types";
import { allocationService } from "../../services/allocation.service";
import { Modal } from "../ui/Modal";
import { Button } from "../ui/Button";

interface ManualAllocationModalProps {
  isOpen: boolean;
  onClose: () => void;
  eventId: number;
  initialProject?: CriticalProjectItem | null;
  projects?: CriticalProjectItem[];
  onSuccess: () => void;
}

export const ManualAllocationModal: React.FC<ManualAllocationModalProps> = ({
  isOpen,
  onClose,
  eventId,
  initialProject,
  projects = [],
  onSuccess,
}) => {
  const [selectedProjectId, setSelectedProjectId] = useState<number | "">("");
  const [selectedEvaluatorId, setSelectedEvaluatorId] = useState<number | "">("");
  const [evaluators, setEvaluators] = useState<EvaluatorListItem[]>([]);
  const [isLoadingEvaluators, setIsLoadingEvaluators] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [categoryConflictWarning, setCategoryConflictWarning] = useState<string | null>(null);
  const [overrideConflict, setOverrideConflict] = useState(false);
  const [success, setSuccess] = useState<string | null>(null);

  // Sincroniza projeto selecionado inicial
  useEffect(() => {
    if (initialProject) {
      setSelectedProjectId(initialProject.project_id);
    } else if (projects.length > 0) {
      setSelectedProjectId(projects[0].project_id);
    }
  }, [initialProject, projects]);

  const handleProjectChange = (val: number) => {
    setSelectedProjectId(val);
    setCategoryConflictWarning(null);
    setOverrideConflict(false);
    setError(null);
  };

  const handleEvaluatorChange = (val: number) => {
    setSelectedEvaluatorId(val);
    setCategoryConflictWarning(null);
    setOverrideConflict(false);
    setError(null);
  };

  // Carrega lista de avaliadores ao abrir o modal
  useEffect(() => {
    if (!isOpen || !eventId) return;

    async function loadEvaluators() {
      setIsLoadingEvaluators(true);
      setError(null);
      setCategoryConflictWarning(null);
      setOverrideConflict(false);
      try {
        const list = await allocationService.getEvaluators(eventId);
        setEvaluators(list);
        if (list.length > 0) {
          setSelectedEvaluatorId(list[0].id);
        }
      } catch (err: any) {
        setError(err.response?.data?.detail || "Erro ao carregar avaliadores do evento.");
      } finally {
        setIsLoadingEvaluators(false);
      }
    }

    loadEvaluators();
  }, [isOpen, eventId]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProjectId || !selectedEvaluatorId) {
      setError("Selecione um projeto e um avaliador para realizar a alocação.");
      return;
    }

    setIsSubmitting(true);
    setError(null);
    setSuccess(null);

    try {
      await allocationService.manualAllocate({
        event_id: eventId,
        project_id: Number(selectedProjectId),
        evaluator_id: Number(selectedEvaluatorId),
        override_conflict: overrideConflict,
      });

      setSuccess(
        overrideConflict
          ? "Avaliador alocado com autorização excepcional (override) registrada!"
          : "Avaliador alocado com sucesso ao trabalho!"
      );
      setCategoryConflictWarning(null);
      setTimeout(() => {
        onSuccess();
        onClose();
      }, 1200);
    } catch (err: any) {
      if (err.response?.status === 409) {
        setCategoryConflictWarning(
          err.response?.data?.detail ||
            "Conflito de interesses de categoria detectado. O avaliador orienta projeto concorrente nesta categoria."
        );
        setError(null);
      } else {
        setError(
          err.response?.data?.detail ||
            "Erro ao alocar avaliador. Verifique conflitos de interesse ou cota do avaliador."
        );
        setCategoryConflictWarning(null);
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const selectedProjObj = projects.find((p) => p.project_id === Number(selectedProjectId)) || initialProject;

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Alocação Manual Ágil de Avaliador"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        <p className="text-xs text-slate-500 dark:text-slate-400">
          Atribua manualmente um avaliador compatível a um estande da feira. O sistema valida conflitos de interesse institucionais.
        </p>

        {error && (
          <div className="p-3 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 text-red-700 dark:text-red-300 text-xs flex items-center gap-2">
            <AlertCircle size={14} className="flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {categoryConflictWarning && (
          <div className="p-3.5 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-800 text-amber-900 dark:text-amber-200 text-xs space-y-2.5">
            <div className="flex items-start gap-2">
              <ShieldAlert size={16} className="text-amber-600 dark:text-amber-400 flex-shrink-0 mt-0.5" />
              <div>
                <strong className="block text-amber-800 dark:text-amber-300 font-bold mb-0.5">
                  Conflito de Interesses por Categoria Detectado
                </strong>
                <p className="text-[11px] leading-relaxed text-amber-700 dark:text-amber-300/90">
                  {categoryConflictWarning}
                </p>
              </div>
            </div>

            <label className="flex items-start gap-2 pt-2 border-t border-amber-200/60 dark:border-amber-900/60 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={overrideConflict}
                onChange={(e) => setOverrideConflict(e.target.checked)}
                className="mt-0.5 rounded border-amber-400 text-amber-600 focus:ring-amber-500"
              />
              <span className="text-[11px] text-amber-900 dark:text-amber-200 font-semibold">
                Autorizo excepcionalmente esta alocação (Override Administrativo). Estou ciente de que o avaliador orienta trabalho concorrente nesta categoria.
              </span>
            </label>
          </div>
        )}

        {success && (
          <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900 text-emerald-700 dark:text-emerald-300 text-xs flex items-center gap-2">
            <CheckCircle2 size={14} className="flex-shrink-0" />
            <span>{success}</span>
          </div>
        )}

        {/* 1. Seleção de Projeto */}
        <div>
          <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
            Trabalho / Estande:
          </label>
          <select
            value={selectedProjectId}
            onChange={(e) => handleProjectChange(Number(e.target.value))}
            className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-blue-500"
          >
            {projects.map((p) => (
              <option key={p.project_id} value={p.project_id}>
                {p.stand_number || `Estande #${p.project_id}`} — {p.title.slice(0, 50)}... ({p.allocated_evaluators_count}/{p.min_evaluators} avaliadores)
              </option>
            ))}
          </select>

          {selectedProjObj && (
            <div className="mt-1.5 p-2 rounded-lg bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/50 text-[11px] flex justify-between items-center text-slate-600 dark:text-slate-300">
              <span>Área: <strong className="text-slate-900 dark:text-white">{selectedProjObj.area_name}</strong></span>
              <span className="font-mono">{selectedProjObj.education_level}</span>
            </div>
          )}
        </div>

        {/* 2. Seleção de Avaliador */}
        <div>
          <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
            Avaliador para Atribuição:
          </label>
          {isLoadingEvaluators ? (
            <div className="py-3 text-center text-xs text-slate-400">Carregando avaliadores do evento...</div>
          ) : evaluators.length === 0 ? (
            <div className="p-3 text-center text-xs text-amber-600 bg-amber-50 rounded-xl">
              Nenhum avaliador cadastrado neste evento.
            </div>
          ) : (
            <select
              value={selectedEvaluatorId}
              onChange={(e) => handleEvaluatorChange(Number(e.target.value))}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-blue-500"
            >
              {evaluators.map((ev) => (
                <option key={ev.id} value={ev.id}>
                  {ev.name} {ev.evaluator_presence_confirmed || ev.presence_confirmed ? "🟢 [Presente]" : "⚪ [Ausente]"} — {ev.allocated_projects_count} trabalho(s) alocado(s)
                </option>
              ))}
            </select>
          )}
        </div>

        {/* Botões de Ação */}
        <div className="flex justify-end gap-2.5 pt-3 border-t border-slate-100 dark:border-slate-800">
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={onClose}
            disabled={isSubmitting}
            className="text-xs"
          >
            Cancelar
          </Button>
          <Button
            type="submit"
            variant="primary"
            size="sm"
            disabled={
              isSubmitting ||
              !selectedProjectId ||
              !selectedEvaluatorId ||
              (Boolean(categoryConflictWarning) && !overrideConflict)
            }
            className={`text-white text-xs font-bold gap-1.5 ${
              overrideConflict
                ? "bg-amber-600 hover:bg-amber-700 focus:ring-amber-500"
                : "bg-blue-600 hover:bg-blue-700"
            }`}
          >
            <UserCheck size={14} />
            <span>
              {isSubmitting
                ? "Alocando..."
                : overrideConflict
                ? "Confirmar com Override"
                : "Confirmar Alocação"}
            </span>
          </Button>
        </div>
      </form>
    </Modal>
  );
};
