"use client";

import React from "react";
import {
  Presentation,
  Users,
  UserCheck,
  Activity,
  AlertTriangle,
  CheckCircle2,
  Package,
  TrendingUp,
  Clock,
  ShieldCheck,
} from "lucide-react";
import { AdminKpiCollection } from "../../types";

interface AdminKpiCardsProps {
  kpis: AdminKpiCollection;
}

interface CircularProgressProps {
  percentage: number;
  color: "blue" | "teal" | "amber" | "purple";
}

const CircularProgress: React.FC<CircularProgressProps> = ({ percentage, color }) => {
  const radius = 35;
  const circumference = 2 * Math.PI * radius;
  const safePercent = Math.min(100, Math.max(0, percentage));
  const strokeDashoffset = circumference - (safePercent / 100) * circumference;

  const colorStyles = {
    blue: {
      track: "stroke-blue-950/60 dark:stroke-blue-950/80",
      stroke: "stroke-blue-600 dark:stroke-blue-400",
      glow: "drop-shadow-[0_0_8px_rgba(37,99,235,0.4)]",
    },
    teal: {
      track: "stroke-teal-950/60 dark:stroke-teal-950/80",
      stroke: "stroke-teal-600 dark:stroke-teal-400",
      glow: "drop-shadow-[0_0_8px_rgba(13,148,136,0.4)]",
    },
    amber: {
      track: "stroke-amber-950/60 dark:stroke-amber-950/80",
      stroke: "stroke-amber-600 dark:stroke-amber-400",
      glow: "drop-shadow-[0_0_8px_rgba(217,119,6,0.4)]",
    },
    purple: {
      track: "stroke-purple-950/60 dark:stroke-purple-950/80",
      stroke: "stroke-purple-600 dark:stroke-purple-400",
      glow: "drop-shadow-[0_0_8px_rgba(147,51,234,0.4)]",
    },
  }[color];

  return (
    <div className="relative w-[84px] h-[84px] flex-shrink-0 flex items-center justify-center">
      <svg className="w-full h-full -rotate-90" viewBox="0 0 88 88">
        <circle
          cx="44"
          cy="44"
          r={radius}
          className={`${colorStyles.track} fill-none`}
          strokeWidth="6"
        />
        <circle
          cx="44"
          cy="44"
          r={radius}
          className={`${colorStyles.stroke} ${colorStyles.glow} fill-none transition-all duration-1000 ease-out`}
          strokeWidth="6.5"
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
          strokeLinecap="round"
        />
      </svg>
      <div className="absolute inset-0 flex items-center justify-center">
        <span className="text-sm font-black font-mono text-slate-900 dark:text-white tracking-tight">
          {safePercent.toFixed(safePercent % 1 === 0 ? 0 : 1)}%
        </span>
      </div>
    </div>
  );
};

export const AdminKpiCards: React.FC<AdminKpiCardsProps> = ({ kpis }) => {
  const { projects, participants, evaluators, progress } = kpis;

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
      {/* =========================================================================
          CARD 1: Projetos em Estande (2A.3: Presença + Vulnerabilidade)
         ========================================================================= */}
      <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between hover:border-blue-500/40 transition-all">
        <div>
          {/* Cabeçalho */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-xs font-black uppercase tracking-wider text-slate-500 dark:text-slate-400">
                Projetos em Estande
              </span>
              <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800">
                Em Estande
              </span>
            </div>
            <div className="w-8 h-8 rounded-xl bg-blue-50 dark:bg-blue-950/50 text-blue-600 dark:text-blue-400 flex items-center justify-center">
              <Presentation size={16} />
            </div>
          </div>

          {/* Corpo: Valor Gigante + Medidor Circular SVG */}
          <div className="mt-4 flex items-center justify-between gap-3">
            <div>
              <div className="text-3xl sm:text-4xl font-black font-mono tracking-tight text-slate-900 dark:text-white">
                {projects.present}
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-medium mt-0.5">
                de <strong className="text-slate-700 dark:text-slate-200">{projects.registered}</strong> inscritos
              </p>
            </div>
            <CircularProgress percentage={projects.present_percent} color="blue" />
          </div>

          {/* Microdetalhe 2A.3: Detalhamento de Status */}
          <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-wrap gap-1.5 text-[11px]">
            <span className="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-medium">
              {projects.in_evaluation} em avaliação
            </span>
            <span className="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-medium">
              {projects.evaluated} avaliados
            </span>
            <span className="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 font-medium">
              {projects.absent} ausentes
            </span>
          </div>
        </div>

        {/* Microdetalhe 2A.3: Alerta de Vulnerabilidade de Trabalhos */}
        <div className="mt-3 pt-2">
          {projects.zero_evaluators_count > 0 ? (
            <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900/60 text-red-700 dark:text-red-300 text-xs font-bold animate-pulse">
              <AlertTriangle size={13} className="flex-shrink-0" />
              <span>{projects.zero_evaluators_count} projetos SEM avaliadores!</span>
            </div>
          ) : projects.under_quota_count > 0 ? (
            <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/60 text-amber-700 dark:text-amber-300 text-xs font-semibold">
              <AlertTriangle size={13} className="flex-shrink-0" />
              <span>{projects.under_quota_count} projetos abaixo da cota</span>
            </div>
          ) : (
            <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900/60 text-emerald-700 dark:text-emerald-300 text-xs font-medium">
              <CheckCircle2 size={13} className="flex-shrink-0" />
              <span>Estandes com cobertura inicial</span>
            </div>
          )}
        </div>
      </div>

      {/* =========================================================================
          CARD 2: Participantes Presentes (2B.1 + 2B.2: Papéis + Baixa de Kits)
         ========================================================================= */}
      <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between hover:border-teal-500/40 transition-all">
        <div>
          {/* Cabeçalho */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-xs font-black uppercase tracking-wider text-slate-500 dark:text-slate-400">
                Participantes
              </span>
              <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300 border border-teal-200 dark:border-teal-800">
                Alunos & Orientadores
              </span>
            </div>
            <div className="w-8 h-8 rounded-xl bg-teal-50 dark:bg-teal-950/50 text-teal-600 dark:text-teal-400 flex items-center justify-center">
              <Users size={16} />
            </div>
          </div>

          {/* Corpo: Valor Gigante + Medidor Circular SVG */}
          <div className="mt-4 flex items-center justify-between gap-3">
            <div>
              <div className="text-3xl sm:text-4xl font-black font-mono tracking-tight text-slate-900 dark:text-white">
                {participants.total_present}
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-medium mt-0.5">
                de <strong className="text-slate-700 dark:text-slate-200">{participants.total_registered}</strong> inscritos
              </p>
            </div>
            <CircularProgress percentage={participants.overall_presence_percent} color="teal" />
          </div>

          {/* Microdetalhe 2B.1: Segmentação de Papéis */}
          <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 space-y-1 text-xs">
            <div className="flex justify-between items-center text-slate-600 dark:text-slate-300">
              <span>Alunos:</span>
              <span className="font-semibold font-mono">
                {participants.present_students} / {participants.registered_students} ({participants.students_presence_percent}%)
              </span>
            </div>
            <div className="flex justify-between items-center text-slate-600 dark:text-slate-300">
              <span>Orientadores:</span>
              <span className="font-semibold font-mono">
                {participants.present_advisors} / {participants.registered_advisors} ({participants.advisors_presence_percent}%)
              </span>
            </div>
          </div>
        </div>

        {/* Microdetalhe 2B.2: Controle de Entrega de Kits */}
        <div className="mt-3 pt-2">
          <div className="flex items-center justify-between px-2.5 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 text-xs">
            <span className="flex items-center gap-1.5 text-slate-500 dark:text-slate-400 font-medium">
              <Package size={13} className="text-teal-600" />
              Kits entregues:
            </span>
            <span className="font-bold font-mono text-slate-900 dark:text-white">
              {participants.kits_delivered} ({participants.kits_delivered_percent}%)
            </span>
          </div>
        </div>
      </div>

      {/* =========================================================================
          CARD 3: Avaliadores Presentes & Capacidade (2C.3 + 2C.1)
         ========================================================================= */}
      <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between hover:border-amber-500/40 transition-all">
        <div>
          {/* Cabeçalho */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-xs font-black uppercase tracking-wider text-slate-500 dark:text-slate-400">
                Avaliadores
              </span>
              <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800">
                Corpo de Avaliadores
              </span>
            </div>
            <div className="w-8 h-8 rounded-xl bg-amber-50 dark:bg-amber-950/50 text-amber-600 dark:text-amber-400 flex items-center justify-center">
              <UserCheck size={16} />
            </div>
          </div>

          {/* Corpo: Valor Gigante + Medidor Circular SVG */}
          <div className="mt-4 flex items-center justify-between gap-3">
            <div>
              <div className="text-3xl sm:text-4xl font-black font-mono tracking-tight text-slate-900 dark:text-white">
                {evaluators.present}
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-medium mt-0.5">
                de <strong className="text-slate-700 dark:text-slate-200">{evaluators.registered}</strong> credenciados
              </p>
            </div>
            <CircularProgress percentage={evaluators.present_percent} color="amber" />
          </div>

          {/* Microdetalhe 2C.1: Capacidade da Feira */}
          <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 space-y-1 text-xs">
            <div className="flex justify-between items-center text-slate-600 dark:text-slate-300">
              <span>Capacidade Total:</span>
              <span className="font-semibold font-mono">
                {evaluators.total_capacity} de {evaluators.expected_evaluations} fichas
              </span>
            </div>
            {/* Microdetalhe 2C.3: Segmentação Fundamental vs Médio */}
            <div className="flex justify-between items-center text-slate-500 dark:text-slate-400 text-[11px]">
              <span>Alocados Fund. / Médio:</span>
              <span className="font-mono">
                {evaluators.fundamental_evaluators_count} / {evaluators.medio_evaluators_count}
              </span>
            </div>
          </div>
        </div>

        {/* Indicador de Déficit / Superávit de Avaliadores */}
        <div className="mt-3 pt-2">
          {evaluators.global_deficit_evaluators > 0 ? (
            <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900/60 text-red-700 dark:text-red-300 text-xs font-bold">
              <AlertTriangle size={13} className="flex-shrink-0" />
              <span>Déficit: +{evaluators.global_deficit_evaluators} avaliadores necessários</span>
            </div>
          ) : (
            <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900/60 text-emerald-700 dark:text-emerald-300 text-xs font-semibold">
              <ShieldCheck size={13} className="flex-shrink-0" />
              <span>Capacidade suficiente para a feira</span>
            </div>
          )}
        </div>
      </div>

      {/* =========================================================================
          CARD 4: Progresso Consolidado da Feira (2D.1 + 2D.2: Fichas + Ritmo)
         ========================================================================= */}
      <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between hover:border-purple-500/40 transition-all">
        <div>
          {/* Cabeçalho */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-xs font-black uppercase tracking-wider text-slate-500 dark:text-slate-400">
                Progresso Geral
              </span>
              <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-purple-50 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-800">
                Apuração Oficial
              </span>
            </div>
            <div className="w-8 h-8 rounded-xl bg-purple-50 dark:bg-purple-950/50 text-purple-600 dark:text-purple-400 flex items-center justify-center">
              <Activity size={16} />
            </div>
          </div>

          {/* Corpo: Valor Gigante + Medidor Circular SVG */}
          <div className="mt-4 flex items-center justify-between gap-3">
            <div>
              <div className="text-3xl sm:text-4xl font-black font-mono tracking-tight text-slate-900 dark:text-white">
                {progress.progress_percent}%
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-medium mt-0.5">
                <strong className="text-slate-700 dark:text-slate-200">{progress.evaluations_completed}</strong> de {progress.evaluations_completed + progress.evaluations_pending} esperadas
              </p>
            </div>
            <CircularProgress percentage={progress.progress_percent} color="purple" />
          </div>

          {/* Microdetalhe 2D.1: Estado das Fichas */}
          <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-wrap gap-1.5 text-[11px]">
            <span className="px-2 py-0.5 rounded bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 font-medium border border-emerald-200 dark:border-emerald-800/60">
              {progress.evaluations_completed} concluídas
            </span>
            <span className="px-2 py-0.5 rounded bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-300 font-medium border border-amber-200 dark:border-amber-800/60">
              {progress.evaluations_in_progress} em andamento
            </span>
            <span className="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-500 font-medium">
              {progress.evaluations_pending} pendentes
            </span>
          </div>
        </div>

        {/* Microdetalhe 2D.2: Ritmo e Previsão de Encerramento */}
        <div className="mt-3 pt-2">
          <div className="flex items-center justify-between px-2.5 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 text-xs">
            <span className="flex items-center gap-1.5 text-slate-500 dark:text-slate-400 font-medium">
              <TrendingUp size={13} className="text-purple-600" />
              {progress.evaluations_per_hour} fichas/h
            </span>
            <span className="flex items-center gap-1 text-slate-700 dark:text-slate-300 font-medium">
              <Clock size={11} className="text-slate-400" />
              {progress.estimated_completion_time ? `Previsão: ${progress.estimated_completion_time}` : "Ritmo inicial"}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
