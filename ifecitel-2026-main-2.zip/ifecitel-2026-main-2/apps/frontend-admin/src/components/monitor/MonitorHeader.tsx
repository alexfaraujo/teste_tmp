"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import {
  Maximize2,
  Minimize2,
  RefreshCw,
  Pause,
  Play,
  ArrowLeft,
  Calendar,
  Layers,
  Sparkles,
} from "lucide-react";
import { ThemeToggle } from "../layout/ThemeToggle";
import { Button } from "../ui/Button";

interface MonitorHeaderProps {
  title: string;
  subtitle?: string;
  icon?: React.ReactNode;
  eventId: number;
  eventName: string;
  secondsRemaining: number;
  totalInterval?: number;
  isPaused: boolean;
  onTogglePause: () => void;
  onRefresh: () => void;
  isRefreshing: boolean;
}

export const MonitorHeader: React.FC<MonitorHeaderProps> = ({
  title,
  subtitle,
  icon,
  eventId,
  eventName,
  secondsRemaining,
  totalInterval = 30,
  isPaused,
  onTogglePause,
  onRefresh,
  isRefreshing,
}) => {
  const [isFullscreen, setIsFullscreen] = useState(false);

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener("fullscreenchange", handleFullscreenChange);
    return () => {
      document.removeEventListener("fullscreenchange", handleFullscreenChange);
    };
  }, []);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch((err) => {
        console.error("Erro ao ativar tela cheia:", err);
      });
    } else {
      document.exitFullscreen().catch((err) => {
        console.error("Erro ao sair de tela cheia:", err);
      });
    }
  };

  // Cálculo do raio e progresso do timer circular
  const radius = 13;
  const circumference = 2 * Math.PI * radius;
  const progressRatio = totalInterval > 0 ? secondsRemaining / totalInterval : 0;
  const strokeDashoffset = circumference - progressRatio * circumference;

  return (
    <header className="sticky top-0 z-30 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 px-4 sm:px-6 py-3 transition-colors shadow-sm">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
        {/* Lado Esquerdo: Identificação & Título da Tela */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-600 to-teal-600 flex items-center justify-center text-white font-black text-lg shadow-sm shadow-blue-500/20 flex-shrink-0">
            F
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-bold text-teal-600 dark:text-teal-400 uppercase tracking-wider flex items-center gap-1">
                <Sparkles size={13} />
                Centro de Comando • Monitor Dedicado
              </span>
              <span className="text-slate-300 dark:text-slate-700">•</span>
              <span className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-900 text-blue-700 dark:text-blue-300 font-bold">
                ID #{eventId}
              </span>
            </div>
            <h1 className="text-base sm:text-lg font-black tracking-tight text-slate-900 dark:text-white flex items-center gap-2 leading-tight mt-0.5">
              {icon}
              <span>{title}</span>
              <span className="text-xs font-medium text-slate-400 dark:text-slate-500 font-sans hidden lg:inline">
                ({eventName})
              </span>
            </h1>
          </div>
        </div>

        {/* Lado Direito: Controles de Tempo Real e Ações */}
        <div className="flex flex-wrap items-center justify-end gap-2.5">
          {/* Status Ao Vivo com Pulso */}
          <div className="flex items-center gap-2 px-2.5 py-1.5 rounded-full bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700">
            <span className="relative flex h-2.5 w-2.5">
              {!isPaused && (
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
              )}
              <span
                className={`relative inline-flex rounded-full h-2.5 w-2.5 ${
                  isPaused ? "bg-amber-500" : "bg-emerald-500"
                }`}
              />
            </span>
            <span className="text-[11px] font-bold text-slate-700 dark:text-slate-200 uppercase tracking-wider">
              {isPaused ? "Pausado" : "Ao Vivo"}
            </span>
          </div>

          {/* Anel SVG Regressivo de 30 Segundos */}
          <div className="flex items-center gap-1.5" title={`Próxima sincronização em ${secondsRemaining}s`}>
            <div className="relative w-8 h-8 flex items-center justify-center">
              <svg className="w-8 h-8 -rotate-90" viewBox="0 0 32 32">
                <circle
                  cx="16"
                  cy="16"
                  r={radius}
                  className="stroke-slate-200 dark:stroke-slate-800 fill-none"
                  strokeWidth="2.5"
                />
                <circle
                  cx="16"
                  cy="16"
                  r={radius}
                  className={`fill-none transition-all duration-1000 ease-linear ${
                    isPaused
                      ? "stroke-amber-500"
                      : secondsRemaining <= 5
                      ? "stroke-red-500"
                      : "stroke-teal-500"
                  }`}
                  strokeWidth="2.5"
                  strokeDasharray={circumference}
                  strokeDashoffset={isPaused ? 0 : strokeDashoffset}
                  strokeLinecap="round"
                />
              </svg>
              <span className="absolute text-[10px] font-black font-mono text-slate-700 dark:text-slate-300">
                {secondsRemaining}s
              </span>
            </div>
          </div>

          {/* Botão Pausar / Retomar */}
          <Button
            type="button"
            onClick={onTogglePause}
            variant="outline"
            size="sm"
            className="border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs px-2.5"
            title={isPaused ? "Retomar atualização automática" : "Pausar atualização automática"}
          >
            {isPaused ? <Play size={13} className="text-emerald-600" /> : <Pause size={13} />}
          </Button>

          {/* Botão Atualizar Agora */}
          <Button
            type="button"
            onClick={onRefresh}
            variant="outline"
            size="sm"
            disabled={isRefreshing}
            className="border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs px-2.5"
            title="Atualizar dados agora"
          >
            <RefreshCw size={13} className={isRefreshing ? "animate-spin text-blue-600" : ""} />
          </Button>

          <div className="w-[1px] h-6 bg-slate-200 dark:bg-slate-800 mx-0.5 hidden sm:block" />

          {/* Botão Tela Cheia (Fullscreen) */}
          <Button
            type="button"
            onClick={toggleFullscreen}
            variant="outline"
            size="sm"
            className="border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs gap-1.5"
            title={isFullscreen ? "Sair de Tela Cheia (Esc)" : "Exibir em Tela Cheia (F11)"}
          >
            {isFullscreen ? <Minimize2 size={14} /> : <Maximize2 size={14} />}
            <span className="hidden sm:inline">{isFullscreen ? "Restaurar" : "Tela Cheia"}</span>
          </Button>

          {/* Theme Toggle */}
          <ThemeToggle />

          {/* Botão Voltar ao Painel */}
          <Link href="/">
            <Button
              type="button"
              variant="outline"
              size="sm"
              className="border-blue-200 dark:border-blue-900 bg-blue-50/50 dark:bg-blue-950/30 text-blue-700 dark:text-blue-300 hover:bg-blue-100 dark:hover:bg-blue-900/50 text-xs gap-1.5"
              title="Voltar ao Painel de Visão Geral principal"
            >
              <ArrowLeft size={14} />
              <span className="hidden md:inline">Painel Geral</span>
            </Button>
          </Link>
        </div>
      </div>
    </header>
  );
};
