"use client";

import React, { useState } from "react";
import {
  Package,
  Layers,
  Users,
  Shirt,
  Download,
  AlertCircle,
  CheckCircle2,
  FileDown,
  Info,
  ArrowUpDown,
  Filter,
} from "lucide-react";
import { Modal } from "../ui/Modal";
import { Button } from "../ui/Button";
import { logisticsService } from "../../services/logistics.service";
import { KitCardsPdfOptions } from "../../types";

interface KitCardsModalProps {
  isOpen: boolean;
  onClose: () => void;
  eventId: number;
  eventName: string;
  onSuccess?: (message: string) => void;
}

export function KitCardsModal({
  isOpen,
  onClose,
  eventId,
  eventName,
  onSuccess,
}: KitCardsModalProps) {
  const [format, setFormat] = useState<"project" | "individual">("project");

  // Concessão de Camisetas por categoria
  const [includeStudents, setIncludeStudents] = useState<boolean>(true);
  const [includeAdvisors, setIncludeAdvisors] = useState<boolean>(false);
  const [includeCoadvisors, setIncludeCoadvisors] = useState<boolean>(false);
  const [includeEvaluators, setIncludeEvaluators] = useState<boolean>(false);

  // Ordenação e Status
  const [sortBy, setSortBy] = useState<"booth" | "school" | "title">("booth");
  const [statusFilter, setStatusFilter] = useState<"homologated" | "all">("homologated");

  // Estado de geração
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleGeneratePdf = async () => {
    setIsGenerating(true);
    setError(null);

    const options: KitCardsPdfOptions = {
      format,
      include_tshirt_students: includeStudents,
      include_tshirt_advisors: includeAdvisors,
      include_tshirt_coadvisors: includeCoadvisors,
      include_tshirt_evaluators: format === "individual" ? includeEvaluators : false,
      sort_by: sortBy,
      status_filter: statusFilter,
    };

    try {
      await logisticsService.downloadKitCardsPdf(eventId, options);
      const successMsg =
        format === "project"
          ? "PDF de Cards Coletivos por Projeto gerado com sucesso!"
          : "PDF de Cards Individuais de Participantes gerado com sucesso!";
      if (onSuccess) {
        onSuccess(successMsg);
      }
      onClose();
    } catch (err: any) {
      setError(
        err.response?.data?.detail ||
          err.message ||
          "Erro ao gerar o PDF de cards para kits. Verifique se existem trabalhos com os filtros selecionados."
      );
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Emissão de Cards para Kits (PDF)"
      error={error}
      maxWidth="max-w-2xl"
    >
      <div className="space-y-5 text-slate-800 dark:text-slate-200">
        {/* Banner de Contexto */}
        <div className="p-3.5 rounded-xl bg-teal-50 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-900/60 flex items-start gap-3">
          <div className="p-2 rounded-lg bg-teal-600 text-white shrink-0 mt-0.5">
            <Package size={18} />
          </div>
          <div className="text-xs space-y-1">
            <p className="font-semibold text-teal-950 dark:text-teal-200">
              Geração de Cards / Etiquetas de Kits • {eventName}
            </p>
            <p className="text-teal-800/80 dark:text-teal-300/80 leading-relaxed">
              Gere documentos prontos para impressão em folha A4 com guias de corte pontilhadas e códigos de barras para conferência ágil no credenciamento.
            </p>
          </div>
        </div>

        {/* 1. Escolha do Formato de Impressão */}
        <div className="space-y-2.5">
          <label className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
            <Layers size={14} className="text-teal-600" />
            1. Formato de Impressão (Folha A4)
          </label>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Opção A: Coletivo por Projeto */}
            <div
              onClick={() => setFormat("project")}
              className={`cursor-pointer p-4 rounded-xl border-2 transition-all flex flex-col justify-between ${
                format === "project"
                  ? "border-teal-600 bg-teal-50/40 dark:bg-teal-950/30 shadow-sm"
                  : "border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 bg-white dark:bg-slate-900"
              }`}
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                    <Layers size={16} className={format === "project" ? "text-teal-600" : "text-slate-400"} />
                    Coletivo por Projeto
                  </span>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-teal-100 dark:bg-teal-950 text-teal-800 dark:text-teal-200">
                    2 por folha
                  </span>
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                  Ideal para sacolas e caixas dos estandes. Inclui <strong>identificação gigante do estande</strong>, resumo de montagem (Packing List) e checklist nominal da equipe.
                </p>
              </div>

              <div className="mt-3 pt-2 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-[11px] font-medium text-teal-700 dark:text-teal-400">
                <span>Padrão mais ágil na recepção</span>
                <input
                  type="radio"
                  name="kit_format"
                  checked={format === "project"}
                  onChange={() => setFormat("project")}
                  className="text-teal-600 focus:ring-teal-500"
                />
              </div>
            </div>

            {/* Opção B: Individual por Participante */}
            <div
              onClick={() => setFormat("individual")}
              className={`cursor-pointer p-4 rounded-xl border-2 transition-all flex flex-col justify-between ${
                format === "individual"
                  ? "border-teal-600 bg-teal-50/40 dark:bg-teal-950/30 shadow-sm"
                  : "border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 bg-white dark:bg-slate-900"
              }`}
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                    <Users size={16} className={format === "individual" ? "text-teal-600" : "text-slate-400"} />
                    Individual por Pessoa
                  </span>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 dark:bg-blue-950 text-blue-800 dark:text-blue-200">
                    6 por folha
                  </span>
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                  Etiquetas individuais com <strong>código de barras Code128</strong> para cada participante retirar seu próprio kit na bancada de recepção.
                </p>
              </div>

              <div className="mt-3 pt-2 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-[11px] font-medium text-blue-700 dark:text-blue-400">
                <span>Controle unitário</span>
                <input
                  type="radio"
                  name="kit_format"
                  checked={format === "individual"}
                  onChange={() => setFormat("individual")}
                  className="text-teal-600 focus:ring-teal-500"
                />
              </div>
            </div>
          </div>
        </div>

        {/* 2. Concessão de Camisetas por Categoria */}
        <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-900/60 space-y-3">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
              <Shirt size={15} className="text-blue-600" />
              2. Concessão de Camisetas (O que incluir nos kits)
            </label>
            <span className="text-[11px] text-slate-500">
              Controle de estoque/orçamento
            </span>
          </div>

          <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
            Selecione quais grupos de participantes devem ter o tamanho de camiseta impresso no kit. Grupos desmarcados terão a camiseta suprimida para evitar cobranças indevidas na recepção.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
            <label className="flex items-center gap-2.5 p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:bg-slate-50 cursor-pointer transition-colors text-xs font-semibold">
              <input
                type="checkbox"
                checked={includeStudents}
                onChange={(e) => setIncludeStudents(e.target.checked)}
                className="w-4 h-4 rounded text-teal-600 focus:ring-teal-500"
              />
              <span>Estudantes / Autores dos Trabalhos</span>
            </label>

            <label className="flex items-center gap-2.5 p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:bg-slate-50 cursor-pointer transition-colors text-xs font-semibold">
              <input
                type="checkbox"
                checked={includeAdvisors}
                onChange={(e) => setIncludeAdvisors(e.target.checked)}
                className="w-4 h-4 rounded text-teal-600 focus:ring-teal-500"
              />
              <span>Professores Orientadores</span>
            </label>

            <label className="flex items-center gap-2.5 p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:bg-slate-50 cursor-pointer transition-colors text-xs font-semibold">
              <input
                type="checkbox"
                checked={includeCoadvisors}
                onChange={(e) => setIncludeCoadvisors(e.target.checked)}
                className="w-4 h-4 rounded text-teal-600 focus:ring-teal-500"
              />
              <span>Coorientadores</span>
            </label>

            {format === "individual" && (
              <label className="flex items-center gap-2.5 p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:bg-slate-50 cursor-pointer transition-colors text-xs font-semibold">
                <input
                  type="checkbox"
                  checked={includeEvaluators}
                  onChange={(e) => setIncludeEvaluators(e.target.checked)}
                  className="w-4 h-4 rounded text-teal-600 focus:ring-teal-500"
                />
                <span>Avaliadores da Comissão Científica</span>
              </label>
            )}
          </div>
        </div>

        {/* 3. Ordenação e Filtros de Status */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {/* Ordenação */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
              <ArrowUpDown size={13} className="text-slate-500" />
              Ordenação das Folhas:
            </label>
            <select
              value={sortBy}
              onChange={(e: any) => setSortBy(e.target.value)}
              className="w-full px-3 py-2 rounded-xl text-xs border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 focus:ring-2 focus:ring-teal-500 focus:outline-none"
            >
              <option value="booth">Por Número de Estande (A-01, A-02...) [Recomendado]</option>
              <option value="school">Por Escola / Instituição (Agrupado por caravana)</option>
              <option value="title">Alfabética por Título / Nome</option>
            </select>
          </div>

          {/* Filtro de Status */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
              <Filter size={13} className="text-slate-500" />
              Filtro de Trabalhos:
            </label>
            <select
              value={statusFilter}
              onChange={(e: any) => setStatusFilter(e.target.value)}
              className="w-full px-3 py-2 rounded-xl text-xs border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 focus:ring-2 focus:ring-teal-500 focus:outline-none"
            >
              <option value="homologated">Apenas Homologados / Aprovados [Recomendado]</option>
              <option value="all">Todos os Trabalhos Ativos</option>
            </select>
          </div>
        </div>

        {/* Botões de Ação */}
        <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end gap-2.5">
          <Button
            variant="outline"
            onClick={onClose}
            disabled={isGenerating}
            type="button"
          >
            Cancelar
          </Button>

          <Button
            onClick={handleGeneratePdf}
            disabled={isGenerating}
            className="bg-teal-600 hover:bg-teal-700 text-white min-w-[180px]"
          >
            {isGenerating ? (
              <span className="flex items-center gap-2">
                <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Gerando PDF...
              </span>
            ) : (
              <span className="flex items-center gap-2">
                <FileDown size={16} />
                Gerar PDF de Kits
              </span>
            )}
          </Button>
        </div>
      </div>
    </Modal>
  );
}
