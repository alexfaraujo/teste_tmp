"use client";

import React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard,
  Calendar,
  BookOpen,
  FileText,
  ScanBarcode,
  Users,
  UserCheck,
  QrCode,
  Award,
  Trophy,
  ListChecks,
  UtensilsCrossed,
} from "lucide-react";
import { clsx } from "clsx";
import { useActiveEvent } from "../../context/EventContext";
import { getLogoDisplayUrl } from "../../utils/url";

interface NavItem {
  label: string;
  href: string;
  icon: React.ReactNode;
}

const operatorRestrictedRoutes = [
  "/areas",
  "/criteria",
  "/projects",
  "/participants",
  "/evaluators",
  "/awards",
  "/results",
];

const navItems: NavItem[] = [
  {
    label: "Visão Geral",
    href: "/",
    icon: <LayoutDashboard size={18} />,
  },
  {
    label: "Edições do Evento",
    href: "/events",
    icon: <Calendar size={18} />,
  },
  {
    label: "Áreas e Subáreas",
    href: "/areas",
    icon: <BookOpen size={18} />,
  },
  {
    label: "Critérios de Avaliação",
    href: "/criteria",
    icon: <ListChecks size={18} />,
  },
  {
    label: "Projetos e Homologação",
    href: "/projects",
    icon: <FileText size={18} />,
  },
  {
    label: "Participantes",
    href: "/participants",
    icon: <UserCheck size={18} />,
  },
  {
    label: "Credenciamento Geral",
    href: "/logistics",
    icon: <ScanBarcode size={18} />,
  },
  {
    label: "Lanches & Coffee Break",
    href: "/snacks",
    icon: <UtensilsCrossed size={18} />,
  },
  {
    label: "Check-in dos Avaliadores",
    href: "/evaluators/checkin",
    icon: <QrCode size={18} />,
  },
  {
    label: "Alocação de Avaliadores",
    href: "/evaluators",
    icon: <Users size={18} />,
  },
  {
    label: "Premiações",
    href: "/awards",
    icon: <Award size={18} />,
  },
  {
    label: "Classificação Oficial",
    href: "/results",
    icon: <Trophy size={18} />,
  },
];

export function Sidebar() {
  const pathname = usePathname();
  const { activeEvent } = useActiveEvent();

  const isOperator = activeEvent?.user_role === "OPERATOR";
  const filteredNavItems = isOperator
    ? navItems.filter((item) => !operatorRestrictedRoutes.includes(item.href))
    : navItems;

  return (
    <aside className="w-64 border-r border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex flex-col h-screen sticky top-0 transition-colors">
      {/* Brand Header */}
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center gap-3">
        {activeEvent ? (
          <>
            {activeEvent.logo_url ? (
              <div className="w-10 h-10 rounded-xl bg-white dark:bg-slate-800 p-1 border border-slate-200 dark:border-slate-700 flex items-center justify-center overflow-hidden flex-shrink-0 shadow-xs">
                <img
                  src={getLogoDisplayUrl(activeEvent.logo_url)}
                  alt={activeEvent.name}
                  className="w-full h-full object-contain"
                />
              </div>
            ) : (
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-600 to-teal-600 flex items-center justify-center text-white font-black text-base shadow-xs shadow-blue-500/20 flex-shrink-0">
                {(activeEvent.name.trim()[0] || "E").toUpperCase()}
              </div>
            )}
            <div className="min-w-0 flex-1">
              <h1
                className="font-black tracking-tight text-slate-900 dark:text-white text-sm leading-tight truncate"
                title={activeEvent.name}
              >
                {activeEvent.name}
              </h1>
              <p className="text-[11px] font-semibold text-blue-600 dark:text-blue-400 leading-none mt-1 truncate">
                Edição {activeEvent.year}
              </p>
            </div>
          </>
        ) : (
          <>
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-blue-600 to-teal-600 flex items-center justify-center text-white font-black text-lg shadow-xs shadow-blue-500/20 flex-shrink-0">
              E
            </div>
            <div>
              <h1 className="font-black tracking-tight text-slate-900 dark:text-white text-base leading-none">
                EasyEvent
              </h1>
              <p className="text-[11px] font-medium text-slate-400 dark:text-slate-500 leading-none mt-1">
                Painel do Administrador
              </p>
            </div>
          </>
        )}
      </div>

      {/* Navigation List */}
      <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
        {filteredNavItems.map((item) => {
          const isActive = pathname === item.href;
          return (
            <Link
              key={item.href}
              href={item.href}
              className={clsx(
                "flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all group",
                isActive
                  ? "bg-blue-600 text-white shadow-sm shadow-blue-500/20"
                  : "text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800/60 hover:text-slate-900 dark:hover:text-white"
              )}
            >
              <div className="flex items-center gap-3">
                <span
                  className={clsx(
                    "transition-colors",
                    isActive
                      ? "text-white"
                      : "text-slate-400 group-hover:text-slate-700 dark:group-hover:text-slate-300"
                  )}
                >
                  {item.icon}
                </span>
                <span>{item.label}</span>
              </div>
            </Link>
          );
        })}
      </nav>

      {/* Footer Info */}
      <div className="p-4 border-t border-slate-200 dark:border-slate-800">
        <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200/60 dark:border-slate-800 flex flex-col items-center justify-center text-center">
          <p className="text-xs font-black text-slate-800 dark:text-slate-200 tracking-tight">
            EasyEvent
          </p>
          <p className="text-[10px] font-medium text-slate-400 dark:text-slate-500 mt-0.5">
            v1.1.0
          </p>
          <div className="mt-2.5 pt-2 border-t border-slate-200/70 dark:border-slate-700/60 w-full flex flex-col items-center justify-center gap-1">
            <span className="text-[9.5px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              Desenvolvido por:
            </span>
            <img
              src="/logos/magicitlab.png"
              alt="MagicITLab"
              className="h-8 w-auto max-w-[120px] object-contain rounded-md shadow-2xs hover:scale-105 transition-transform"
            />
          </div>
        </div>
      </div>
    </aside>
  );
}
