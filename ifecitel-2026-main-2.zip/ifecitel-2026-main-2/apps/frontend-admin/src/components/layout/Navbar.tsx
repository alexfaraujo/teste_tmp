"use client";

import React, { useEffect, useState } from "react";
import { LogOut, User, Sparkles, Calendar, AlertTriangle } from "lucide-react";
import Link from "next/link";
import { authService } from "../../services/auth.service";
import { useActiveEvent } from "../../context/EventContext";
import { User as UserType } from "../../types";
import { ThemeToggle } from "./ThemeToggle";

interface NavbarProps {
  onLogout?: () => void;
}

export function Navbar({ onLogout }: NavbarProps) {
  const [currentUser, setCurrentUser] = useState<UserType | null>(null);
  const { activeEvent } = useActiveEvent();

  useEffect(() => {
    setCurrentUser(authService.getCurrentUser());
  }, []);

  const handleLogout = () => {
    if (onLogout) {
      onLogout();
    } else {
      authService.logout();
    }
  };

  return (
    <header className="sticky top-0 z-30 flex h-16 w-full items-center justify-between border-b border-slate-200 dark:border-slate-800 bg-white/80 dark:bg-slate-900/80 px-6 backdrop-blur-md transition-colors">
      <div className="flex items-center gap-3">
        <div className="hidden lg:flex items-center gap-2 text-xs font-semibold text-teal-600 dark:text-teal-400 bg-teal-50 dark:bg-teal-950/50 px-2.5 py-1 rounded-lg border border-teal-200 dark:border-teal-900">
          <Sparkles size={14} />
          <span>Painel de Governança</span>
        </div>

        {/* Active Event Indicator */}
        {activeEvent ? (
          <div className="flex items-center gap-2 text-xs font-semibold px-3 py-1.5 rounded-xl border border-blue-200 dark:border-blue-900 bg-blue-50/70 dark:bg-blue-950/40 text-blue-800 dark:text-blue-300 shadow-sm">
            <Calendar size={13} className="text-blue-600 dark:text-blue-400 flex-shrink-0" />
            <span className="font-bold truncate max-w-[180px] sm:max-w-[280px]">
              {activeEvent.name}
            </span>
            <span className="text-[10px] bg-blue-200/80 dark:bg-blue-900 text-blue-800 dark:text-blue-200 px-1.5 py-0.5 rounded font-bold">
              {activeEvent.year}
            </span>
            <Link
              href="/events"
              className="text-[11px] font-bold text-blue-600 dark:text-blue-400 underline ml-1 hover:text-blue-700"
              title="Trocar edição ativa"
            >
              Trocar
            </Link>
          </div>
        ) : (
          <Link
            href="/events"
            className="flex items-center gap-2 text-xs font-semibold px-3 py-1.5 rounded-xl border border-amber-300 dark:border-amber-900 bg-amber-50 dark:bg-amber-950/50 text-amber-800 dark:text-amber-300 shadow-sm hover:bg-amber-100 dark:hover:bg-amber-900/60 transition-colors"
          >
            <AlertTriangle size={13} className="text-amber-600 dark:text-amber-400 flex-shrink-0" />
            <span>Nenhuma edição selecionada</span>
            <span className="text-[11px] underline font-bold ml-1">Selecionar</span>
          </Link>
        )}
      </div>

      <div className="flex items-center gap-4">
        <ThemeToggle />

        <div className="h-6 w-px bg-slate-200 dark:bg-slate-800" />

        {/* User Profile */}
        {(() => {
          const displayName = activeEvent?.owner_name || currentUser?.name || "Administrador";
          const displayEmail = activeEvent?.owner_email || currentUser?.email || "admin@easyevent.com";
          const initial = (displayName.trim()[0] || "A").toUpperCase();

          return (
            <div
              className="flex items-center gap-3"
              title={activeEvent?.owner_name ? `Proprietário do Evento: ${activeEvent.owner_name}` : "Perfil do Administrador"}
            >
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-600 to-teal-600 text-white flex items-center justify-center font-bold text-xs shadow-sm">
                {initial}
              </div>

              <div className="hidden sm:block text-left">
                <p className="text-xs font-bold text-slate-900 dark:text-white leading-none truncate max-w-[180px]">
                  {displayName}
                </p>
                <p className="text-[11px] text-slate-400 dark:text-slate-500 mt-0.5 leading-none truncate max-w-[180px]">
                  {displayEmail}
                </p>
              </div>

              <button
                onClick={handleLogout}
                title="Sair do Sistema"
                className="p-1.5 text-slate-400 hover:text-red-600 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/30 rounded-lg transition-colors ml-1"
              >
                <LogOut size={16} />
              </button>
            </div>
          );
        })()}
      </div>
    </header>
  );
}
