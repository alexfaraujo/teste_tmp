"use client";

import React, { useEffect, useState } from "react";
import {
  X,
  UserPlus,
  Shield,
  Crown,
  Ticket,
  Trash2,
  AlertCircle,
  CheckCircle2,
  Loader2,
  Mail,
} from "lucide-react";
import { EventAdminItem, EventAdminRole, EventItem } from "@/types";
import { eventService } from "@/services/event.service";

interface EventAdminsModalProps {
  isOpen: boolean;
  onClose: () => void;
  event: EventItem;
}

export const EventAdminsModal: React.FC<EventAdminsModalProps> = ({
  isOpen,
  onClose,
  event,
}) => {
  const [admins, setAdmins] = useState<EventAdminItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [adding, setAdding] = useState(false);
  const [actionLoadingId, setActionLoadingId] = useState<number | null>(null);

  // Formulário de convite
  const [email, setEmail] = useState("");
  const [selectedRole, setSelectedRole] = useState<EventAdminRole>("ORGANIZER");
  const [feedback, setFeedback] = useState<{
    type: "success" | "error";
    message: string;
  } | null>(null);

  const loadAdmins = async () => {
    try {
      setLoading(true);
      setFeedback(null);
      const res = await eventService.getAdmins(event.id);
      setAdmins(res.items || []);
    } catch (err: any) {
      setFeedback({
        type: "error",
        message: err.response?.data?.detail || "Erro ao carregar a equipe da feira.",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      setEmail("");
      setSelectedRole("ORGANIZER");
      loadAdmins();
    }
  }, [isOpen, event.id]);

  if (!isOpen) return null;

  const handleAddAdmin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;

    try {
      setAdding(true);
      setFeedback(null);
      await eventService.addAdmin(event.id, {
        email: email.trim().toLowerCase(),
        role: selectedRole,
      });
      setEmail("");
      setFeedback({
        type: "success",
        message: "Administrador adicionado à equipe com sucesso!",
      });
      await loadAdmins();
    } catch (err: any) {
      setFeedback({
        type: "error",
        message: err.response?.data?.detail || "Falha ao adicionar administrador.",
      });
    } finally {
      setAdding(false);
    }
  };

  const handleRoleChange = async (personId: number, newRole: EventAdminRole) => {
    try {
      setActionLoadingId(personId);
      setFeedback(null);
      await eventService.updateAdminRole(event.id, personId, newRole);
      setFeedback({
        type: "success",
        message: "Nível administrativo atualizado com sucesso!",
      });
      await loadAdmins();
    } catch (err: any) {
      setFeedback({
        type: "error",
        message: err.response?.data?.detail || "Falha ao atualizar nível.",
      });
    } finally {
      setActionLoadingId(null);
    }
  };

  const handleRemoveAdmin = async (personId: number, name: string) => {
    if (
      !window.confirm(
        `Tem certeza que deseja revogar o acesso de "${name}" a esta feira?`
      )
    ) {
      return;
    }

    try {
      setActionLoadingId(personId);
      setFeedback(null);
      await eventService.removeAdmin(event.id, personId);
      setFeedback({
        type: "success",
        message: "Acesso revogado com sucesso.",
      });
      await loadAdmins();
    } catch (err: any) {
      setFeedback({
        type: "error",
        message: err.response?.data?.detail || "Falha ao revogar acesso.",
      });
    } finally {
      setActionLoadingId(null);
    }
  };

  const getRoleBadge = (role: EventAdminRole, isOwner: boolean) => {
    if (isOwner || role === "COORDINATOR") {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-300 border border-amber-200 dark:border-amber-800">
          <Crown className="w-3.5 h-3.5 text-amber-500" />
          Coordenador Geral (Dono)
        </span>
      );
    }
    if (role === "ORGANIZER") {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-blue-50 text-blue-700 dark:bg-blue-950/40 dark:text-blue-300 border border-blue-200 dark:border-blue-800">
          <Shield className="w-3.5 h-3.5 text-blue-500" />
          Comissão Organizadora
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-teal-50 text-teal-700 dark:bg-teal-950/40 dark:text-teal-300 border border-teal-200 dark:border-teal-800">
        <Ticket className="w-3.5 h-3.5 text-teal-500" />
        Apoio / Recepção
      </span>
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Cabeçalho */}
        <div className="px-6 py-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50/50 dark:bg-slate-900/50">
          <div>
            <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Shield className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
              Equipe & Administradores da Feira
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Edição: <span className="font-semibold text-slate-700 dark:text-slate-300">{event.name}</span> ({event.year})
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 dark:hover:bg-slate-800 dark:hover:text-slate-300 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Feedback Alert */}
        {feedback && (
          <div
            className={`px-6 py-3 text-xs flex items-center gap-2 border-b ${
              feedback.type === "success"
                ? "bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border-emerald-100 dark:border-emerald-800"
                : "bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 border-rose-100 dark:border-rose-800"
            }`}
          >
            {feedback.type === "success" ? (
              <CheckCircle2 className="w-4 h-4 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 shrink-0" />
            )}
            <span>{feedback.message}</span>
          </div>
        )}

        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Formulário: Convidar novo membro */}
          <div className="bg-slate-50 dark:bg-slate-800/50 p-4 rounded-xl border border-slate-200 dark:border-slate-800">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300 mb-3 flex items-center gap-1.5">
              <UserPlus className="w-4 h-4 text-indigo-500" />
              Convidar Novo Administrador
            </h3>
            <form onSubmit={handleAddAdmin} className="space-y-3">
              <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
                <div className="md:col-span-7 relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-2.5 pointer-events-none" />
                  <input
                    type="email"
                    required
                    placeholder="E-mail institucional (ex: prof@ifms.edu.br)"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/30 focus:border-indigo-500 transition-colors"
                  />
                </div>
                <div className="md:col-span-5">
                  <select
                    value={selectedRole}
                    onChange={(e) => setSelectedRole(e.target.value as EventAdminRole)}
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500/30 focus:border-indigo-500 transition-colors"
                  >
                    <option value="ORGANIZER">🛡️ Comissão Organizadora</option>
                    <option value="OPERATOR">🎫 Apoio / Recepção</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center justify-between pt-1">
                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  {selectedRole === "ORGANIZER"
                    ? "Comissão Organizadora: homologa trabalhos, gerencia áreas, critérios, prêmios e apuração."
                    : "Apoio / Recepção: acesso restrito a credenciamento, entrega de kits e check-in de avaliadores."}
                </p>
                <button
                  type="submit"
                  disabled={adding || !email.trim()}
                  className="px-4 py-2 text-xs font-semibold rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white shadow-sm hover:shadow transition-all disabled:opacity-50 flex items-center gap-1.5 shrink-0"
                >
                  {adding ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      Adicionando...
                    </>
                  ) : (
                    <>
                      <UserPlus className="w-3.5 h-3.5" />
                      Convidar
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>

          {/* Lista de Membros Atuais */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300">
                Membros da Equipe ({admins.length})
              </h3>
              <span className="text-[11px] text-slate-400">
                Somente o Coordenador Geral pode gerenciar permissões
              </span>
            </div>

            {loading ? (
              <div className="py-8 flex flex-col items-center justify-center gap-2 text-slate-400">
                <Loader2 className="w-6 h-6 animate-spin text-indigo-500" />
                <span className="text-xs">Carregando membros...</span>
              </div>
            ) : admins.length === 0 ? (
              <div className="py-8 text-center text-slate-400 text-xs bg-slate-50 dark:bg-slate-800/30 rounded-xl border border-dashed border-slate-200 dark:border-slate-800">
                Nenhum administrador cadastrado.
              </div>
            ) : (
              <div className="divide-y divide-slate-100 dark:divide-slate-800 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden bg-white dark:bg-slate-900">
                {admins.map((adm) => (
                  <div
                    key={adm.person_id}
                    className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition-colors"
                  >
                    <div className="flex items-start gap-3">
                      <div className="w-9 h-9 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center font-bold text-xs text-slate-700 dark:text-slate-300 shrink-0 mt-0.5">
                        {adm.name
                          ? adm.name
                              .split(" ")
                              .map((n) => n[0])
                              .slice(0, 2)
                              .join("")
                              .toUpperCase()
                          : "AD"}
                      </div>
                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-semibold text-sm text-slate-900 dark:text-white">
                            {adm.name}
                          </span>
                          {getRoleBadge(adm.role, adm.is_owner)}
                        </div>
                        <p className="text-xs text-slate-500 dark:text-slate-400 font-mono mt-0.5">
                          {adm.email}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 self-end sm:self-center">
                      {adm.is_owner ? (
                        <span className="text-[11px] text-amber-600 dark:text-amber-400 italic px-2">
                          Dono soberano
                        </span>
                      ) : (
                        <>
                          <select
                            value={adm.role}
                            disabled={actionLoadingId === adm.person_id}
                            onChange={(e) =>
                              handleRoleChange(
                                adm.person_id,
                                e.target.value as EventAdminRole
                              )
                            }
                            className="px-2.5 py-1 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                          >
                            <option value="ORGANIZER">Comissão Organizadora</option>
                            <option value="OPERATOR">Apoio / Recepção</option>
                          </select>

                          <button
                            title="Revogar Acesso"
                            disabled={actionLoadingId === adm.person_id}
                            onClick={() =>
                              handleRemoveAdmin(adm.person_id, adm.name)
                            }
                            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/30 transition-colors disabled:opacity-50"
                          >
                            {actionLoadingId === adm.person_id ? (
                              <Loader2 className="w-4 h-4 animate-spin text-rose-500" />
                            ) : (
                              <Trash2 className="w-4 h-4" />
                            )}
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Rodapé */}
        <div className="px-6 py-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end bg-slate-50/50 dark:bg-slate-900/50">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold rounded-lg bg-slate-200 hover:bg-slate-300 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 transition-colors"
          >
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
};

export default EventAdminsModal;
