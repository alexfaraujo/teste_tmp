"use client";

import React, { useState, useRef } from "react";
import {
  Upload,
  FileSpreadsheet,
  Download,
  CheckCircle2,
  AlertTriangle,
  X,
  Users,
  UserCheck,
  Sparkles,
  Search,
  Check,
  AlertCircle,
} from "lucide-react";
import { Modal } from "../ui/Modal";
import { Button } from "../ui/Button";
import { ParticipantItem, UserRole, EducationLevel } from "../../types";
import {
  downloadParticipantsCsvTemplate,
  parseParticipantsCsv,
  SubareaSimple,
} from "../../utils/participantCsv";
import { ParseParticipantsCsvResult } from "../../types";
import { participantService } from "../../services/participant.service";

interface ParticipantsCsvImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  eventId: number;
  subareas: SubareaSimple[];
  existingParticipants: ParticipantItem[];
  onSuccess: (summary: {
    total: number;
    created: number;
    updated: number;
    evaluators: number;
  }) => void;
}

export function ParticipantsCsvImportModal({
  isOpen,
  onClose,
  eventId,
  subareas,
  existingParticipants,
  onSuccess,
}: ParticipantsCsvImportModalProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [fileName, setFileName] = useState<string | null>(null);
  const [fileSize, setFileSize] = useState<string | null>(null);
  const [parseResult, setParseResult] = useState<ParseParticipantsCsvResult | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [modalError, setModalError] = useState<string | null>(null);
  const [isDragOver, setIsDragOver] = useState(false);
  const [filterQuery, setFilterQuery] = useState("");
  const [onlyErrorsFilter, setOnlyErrorsFilter] = useState(false);

  const handleReset = () => {
    setFileName(null);
    setFileSize(null);
    setParseResult(null);
    setModalError(null);
    setFilterQuery("");
    setOnlyErrorsFilter(false);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleClose = () => {
    if (isSubmitting) return;
    handleReset();
    onClose();
  };

  const processFile = (file: File) => {
    if (!file.name.toLowerCase().endsWith(".csv")) {
      setModalError("Por favor, selecione um arquivo no formato CSV (.csv).");
      return;
    }

    setModalError(null);
    setFileName(file.name);
    setFileSize((file.size / 1024).toFixed(1) + " KB");

    const reader = new FileReader();
    reader.onload = (e) => {
      const content = e.target?.result as string;
      if (!content) {
        setModalError("O arquivo CSV selecionado está vazio.");
        return;
      }
      try {
        const result = parseParticipantsCsv(content, subareas, existingParticipants);
        if (result.totalRows === 0) {
          setModalError(
            "Nenhum participante foi encontrado no arquivo. Verifique se o arquivo possui um cabeçalho válido com as colunas 'nome' e 'email'."
          );
        }
        setParseResult(result);
      } catch (err: any) {
        setModalError("Erro ao processar o arquivo CSV: " + (err.message || "Formato inválido"));
      }
    };
    reader.onerror = () => {
      setModalError("Erro ao ler o arquivo CSV do seu computador.");
    };
    reader.readAsText(file, "UTF-8");
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) processFile(file);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = () => {
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) processFile(file);
  };

  const handleSubmit = async () => {
    if (!parseResult || parseResult.totalRows === 0) return;
    if (parseResult.hasErrors) {
      setModalError("Corrija os erros destacados no arquivo antes de continuar.");
      return;
    }

    setIsSubmitting(true);
    setModalError(null);

    try {
      const payloadItems = parseResult.rows.map((row) => ({
        name: row.name,
        email: row.email,
        roles: row.roles,
        cpf: row.cpf,
        affiliation: row.affiliation,
        tshirt_size: row.tshirt_size,
        subareas: row.subareas,
        education_levels: row.education_levels,
        barcode: row.barcode,
      }));

      const res = await participantService.importParticipantsBatch(eventId, {
        items: payloadItems,
      });

      onSuccess({
        total: res.total_processed,
        created: res.created_count,
        updated: res.updated_count,
        evaluators: res.evaluators_count,
      });

      handleClose();
    } catch (err: any) {
      const detail = err.response?.data?.detail || err.message || "Falha ao importar participantes.";
      setModalError(detail);
    } finally {
      setIsSubmitting(false);
    }
  };

  const renderRoleBadge = (role: UserRole) => {
    switch (role) {
      case "STUDENT":
        return (
          <span
            key={role}
            className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-semibold bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300"
          >
            Estudante
          </span>
        );
      case "ADVISOR":
        return (
          <span
            key={role}
            className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-semibold bg-teal-100 text-teal-700 dark:bg-teal-900/40 dark:text-teal-300"
          >
            Orientador
          </span>
        );
      case "COADVISOR":
        return (
          <span
            key={role}
            className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-semibold bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300"
          >
            Coorientador
          </span>
        );
      case "EVALUATOR":
        return (
          <span
            key={role}
            className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-semibold bg-purple-100 text-purple-700 dark:bg-purple-900/40 dark:text-purple-300"
          >
            Avaliador
          </span>
        );
      default:
        return (
          <span
            key={role}
            className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-semibold bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300"
          >
            {role}
          </span>
        );
    }
  };

  const renderLevelBadge = (level: EducationLevel) => {
    switch (level) {
      case "JUNIOR":
        return (
          <span
            key={level}
            className="inline-flex items-center px-1.5 py-0.5 rounded text-[9px] font-semibold bg-amber-50 text-amber-700 border border-amber-200 dark:bg-amber-950/40 dark:text-amber-300 dark:border-amber-800"
          >
            Fundamental I
          </span>
        );
      case "FUNDAMENTAL":
        return (
          <span
            key={level}
            className="inline-flex items-center px-1.5 py-0.5 rounded text-[9px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-800"
          >
            Fundamental II
          </span>
        );
      case "MEDIO":
        return (
          <span
            key={level}
            className="inline-flex items-center px-1.5 py-0.5 rounded text-[9px] font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200 dark:bg-indigo-950/40 dark:text-indigo-300 dark:border-indigo-800"
          >
            Médio
          </span>
        );
      case "GRADUACAO":
        return (
          <span
            key={level}
            className="inline-flex items-center px-1.5 py-0.5 rounded text-[9px] font-semibold bg-purple-50 text-purple-700 border border-purple-200 dark:bg-purple-950/40 dark:text-purple-300 dark:border-purple-800"
          >
            Graduação
          </span>
        );
      case "POS_GRADUACAO":
        return (
          <span
            key={level}
            className="inline-flex items-center px-1.5 py-0.5 rounded text-[9px] font-semibold bg-rose-50 text-rose-700 border border-rose-200 dark:bg-rose-950/40 dark:text-rose-300 dark:border-rose-800"
          >
            Pós-Graduação
          </span>
        );
    }
  };

  const filteredRows = (parseResult?.rows || []).filter((row) => {
    if (onlyErrorsFilter && row.isValid) return false;
    if (!filterQuery) return true;
    const q = filterQuery.toLowerCase();
    return (
      row.name.toLowerCase().includes(q) ||
      row.email.toLowerCase().includes(q) ||
      (row.cpf && row.cpf.includes(q)) ||
      (row.affiliation && row.affiliation.toLowerCase().includes(q)) ||
      row.roles.some((r) => r.toLowerCase().includes(q))
    );
  });

  return (
    <Modal
      isOpen={isOpen}
      onClose={handleClose}
      title="Importação em Lote de Participantes via CSV"
    >
      <div className="space-y-4 max-w-4xl w-full">
        {/* Banner de Orientações com Botão de Download */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 p-3.5 bg-blue-50/80 dark:bg-blue-950/30 rounded-xl border border-blue-200/80 dark:border-blue-800/50">
          <div className="space-y-1">
            <h4 className="text-xs font-bold text-blue-900 dark:text-blue-200 flex items-center gap-1.5">
              <FileSpreadsheet size={15} className="text-blue-600 dark:text-blue-400" />
              Modelo Oficial de Planilha de Participantes
            </h4>
            <p className="text-[11px] text-blue-700/90 dark:text-blue-300/80 leading-relaxed">
              Baixe o modelo pré-formatado contendo as colunas corretas e exemplos práticos com as subáreas ativas da feira.
            </p>
          </div>
          <Button
            type="button"
            variant="outline"
            onClick={() => downloadParticipantsCsvTemplate(eventId, subareas)}
            className="shrink-0 text-xs border-blue-300 dark:border-blue-700 text-blue-700 dark:text-blue-300 hover:bg-blue-100/50 dark:hover:bg-blue-900/40"
          >
            <Download size={14} className="mr-1.5" />
            Baixar Modelo CSV
          </Button>
        </div>

        {/* Zona de Upload / Drag & Drop */}
        {!parseResult ? (
          <div
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`flex flex-col items-center justify-center p-8 border-2 border-dashed rounded-2xl cursor-pointer transition-all ${
              isDragOver
                ? "border-teal-500 bg-teal-50/50 dark:bg-teal-950/30 scale-[0.99]"
                : "border-slate-300 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-900/40 hover:bg-slate-100/50 dark:hover:bg-slate-900/70"
            }`}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept=".csv"
              onChange={handleFileChange}
              className="hidden"
            />
            <div className="p-3 bg-teal-100 dark:bg-teal-950/60 text-teal-600 dark:text-teal-400 rounded-2xl mb-3 shadow-sm">
              <Upload size={24} />
            </div>
            <p className="text-sm font-semibold text-slate-800 dark:text-slate-200 text-center">
              Arraste e solte seu arquivo CSV aqui, ou{" "}
              <span className="text-teal-600 dark:text-teal-400 underline underline-offset-2">
                clique para navegar
              </span>
            </p>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Formato aceito: .csv (codificação UTF-8 ou Excel, delimitador ponto-e-vírgula ou vírgula)
            </p>
          </div>
        ) : (
          <div className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 text-xs">
            <div className="flex items-center gap-2.5 overflow-hidden">
              <div className="p-2 bg-teal-100 dark:bg-teal-950/60 text-teal-600 dark:text-teal-400 rounded-lg shrink-0">
                <FileSpreadsheet size={18} />
              </div>
              <div className="truncate">
                <p className="font-semibold text-slate-900 dark:text-white truncate">{fileName}</p>
                <p className="text-[11px] text-slate-500">{fileSize}</p>
              </div>
            </div>
            <button
              type="button"
              onClick={handleReset}
              className="p-1.5 text-slate-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/30 rounded-lg transition-colors ml-2 shrink-0"
              title="Remover arquivo e escolher outro"
            >
              <X size={16} />
            </button>
          </div>
        )}

        {/* Mensagem de Erro Geral */}
        {modalError && (
          <div className="flex items-start gap-2.5 p-3 bg-rose-50 dark:bg-rose-950/30 text-rose-700 dark:text-rose-300 rounded-xl border border-rose-200 dark:border-rose-800 text-xs">
            <AlertCircle size={16} className="shrink-0 mt-0.5 text-rose-600 dark:text-rose-400" />
            <div className="flex-1">{modalError}</div>
          </div>
        )}

        {/* Pré-visualização e Estatísticas */}
        {parseResult && parseResult.totalRows > 0 && (
          <div className="space-y-3">
            {/* 4 Cards de KPI */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
              <div className="p-2.5 bg-slate-50 dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800">
                <div className="flex items-center gap-1.5 text-slate-500 mb-1">
                  <Users size={14} className="text-blue-500" />
                  <span>Total Linhas</span>
                </div>
                <p className="text-lg font-bold text-slate-900 dark:text-white">
                  {parseResult.totalRows}
                </p>
              </div>

              <div className="p-2.5 bg-slate-50 dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800">
                <div className="flex items-center gap-1.5 text-slate-500 mb-1">
                  <Sparkles size={14} className="text-emerald-500" />
                  <span>Novos / Atualizar</span>
                </div>
                <p className="text-lg font-bold text-slate-900 dark:text-white">
                  <span className="text-emerald-600 dark:text-emerald-400">{parseResult.newCount}</span>
                  <span className="text-slate-400 text-xs font-normal"> novos / </span>
                  <span className="text-blue-600 dark:text-blue-400">{parseResult.updateCount}</span>
                </p>
              </div>

              <div className="p-2.5 bg-slate-50 dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800">
                <div className="flex items-center gap-1.5 text-slate-500 mb-1">
                  <UserCheck size={14} className="text-purple-500" />
                  <span>Avaliadores</span>
                </div>
                <p className="text-lg font-bold text-purple-600 dark:text-purple-400">
                  {parseResult.evaluatorsCount}
                </p>
              </div>

              <div className="p-2.5 bg-slate-50 dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800">
                <div className="flex items-center gap-1.5 text-slate-500 mb-1">
                  {parseResult.hasErrors ? (
                    <AlertTriangle size={14} className="text-rose-500" />
                  ) : (
                    <CheckCircle2 size={14} className="text-teal-500" />
                  )}
                  <span>Status do Lote</span>
                </div>
                <p
                  className={`text-xs font-bold ${
                    parseResult.hasErrors
                      ? "text-rose-600 dark:text-rose-400"
                      : "text-teal-600 dark:text-teal-400"
                  }`}
                >
                  {parseResult.hasErrors
                    ? `${parseResult.invalidCount} linha(s) com erro`
                    : "100% Válido para Envio"}
                </p>
              </div>
            </div>

            {/* Barra de Filtro na Pré-visualização */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-2 pt-1">
              <div className="relative w-full sm:w-64">
                <Search
                  size={14}
                  className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400"
                />
                <input
                  type="text"
                  value={filterQuery}
                  onChange={(e) => setFilterQuery(e.target.value)}
                  placeholder="Filtrar participante na prévia..."
                  className="w-full pl-8 pr-3 py-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-teal-500/20"
                />
              </div>

              {parseResult.hasErrors && (
                <label className="flex items-center gap-1.5 text-xs text-rose-600 dark:text-rose-400 cursor-pointer self-start sm:self-center">
                  <input
                    type="checkbox"
                    checked={onlyErrorsFilter}
                    onChange={(e) => setOnlyErrorsFilter(e.target.checked)}
                    className="rounded border-rose-300 text-rose-600 focus:ring-rose-500"
                  />
                  <span>Exibir apenas linhas com erros ({parseResult.invalidCount})</span>
                </label>
              )}
            </div>

            {/* Tabela de Pré-visualização com Scroll */}
            <div className="max-h-72 overflow-y-auto border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-sm">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="sticky top-0 bg-slate-100 dark:bg-slate-950 text-slate-700 dark:text-slate-300 font-semibold border-b border-slate-200 dark:border-slate-800 z-10">
                  <tr>
                    <th className="py-2 px-2.5 w-10">#</th>
                    <th className="py-2 px-2.5">Participante</th>
                    <th className="py-2 px-2.5">Papéis</th>
                    <th className="py-2 px-2.5 w-16 text-center">Tam.</th>
                    <th className="py-2 px-2.5">Subáreas / Níveis</th>
                    <th className="py-2 px-2.5 w-24 text-right">Ação</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 dark:divide-slate-800 bg-white dark:bg-slate-900">
                  {filteredRows.map((row) => {
                    const isEvaluator = row.roles.includes("EVALUATOR");
                    return (
                      <tr
                        key={row.rowNumber}
                        className={`transition-colors ${
                          !row.isValid
                            ? "bg-rose-50/60 dark:bg-rose-950/20"
                            : row.isExisting
                            ? "hover:bg-blue-50/40 dark:hover:bg-blue-950/20"
                            : "hover:bg-slate-50 dark:hover:bg-slate-800/40"
                        }`}
                      >
                        <td className="py-2 px-2.5 font-mono text-[10px] text-slate-400">
                          {row.rowNumber}
                        </td>
                        <td className="py-2 px-2.5">
                          <p className="font-semibold text-slate-900 dark:text-white truncate">
                            {row.name || <span className="text-rose-500 italic">Vazio</span>}
                          </p>
                          <p className="text-[11px] text-slate-500 truncate">{row.email}</p>
                          {(row.cpf || row.affiliation) && (
                            <p className="text-[10px] text-slate-400 truncate">
                              {row.cpf ? `CPF: ${row.cpf}` : ""}
                              {row.cpf && row.affiliation ? " • " : ""}
                              {row.affiliation || ""}
                            </p>
                          )}
                          {row.errors.length > 0 && (
                            <div className="mt-1 space-y-0.5">
                              {row.errors.map((err, idx) => (
                                <p key={idx} className="text-[10px] text-rose-600 font-medium">
                                  ⚠️ {err}
                                </p>
                              ))}
                            </div>
                          )}
                          {row.warnings.length > 0 && (
                            <div className="mt-0.5 space-y-0.5">
                              {row.warnings.map((warn, idx) => (
                                <p key={idx} className="text-[10px] text-amber-600">
                                  ℹ️ {warn}
                                </p>
                              ))}
                            </div>
                          )}
                        </td>
                        <td className="py-2 px-2.5">
                          <div className="flex flex-wrap gap-1">
                            {row.roles.map((r) => renderRoleBadge(r))}
                          </div>
                        </td>
                        <td className="py-2 px-2.5 text-center font-mono font-bold text-slate-600 dark:text-slate-400">
                          {row.tshirt_size}
                        </td>
                        <td className="py-2 px-2.5">
                          {isEvaluator ? (
                            <div className="space-y-1">
                              {row.subareas.length > 0 ? (
                                <div className="flex flex-wrap gap-1">
                                  {row.subareas.map((s, idx) => {
                                    const parts = s.split(" -> ");
                                    return (
                                      <span
                                        key={idx}
                                        className="inline-flex items-center px-1.5 py-0.5 rounded text-[9px] bg-teal-50 text-teal-700 border border-teal-200 dark:bg-teal-950/40 dark:text-teal-300 dark:border-teal-800"
                                      >
                                        {parts.length === 2 ? (
                                          <span>
                                            <span className="font-semibold text-teal-800 dark:text-teal-200">{parts[0]}</span>
                                            <span className="mx-0.5 text-teal-400">&gt;</span>
                                            <span>{parts[1]}</span>
                                          </span>
                                        ) : (
                                          s
                                        )}
                                      </span>
                                    );
                                  })}
                                </div>
                              ) : (
                                <span className="text-[10px] text-slate-400 italic">
                                  Sem subáreas
                                </span>
                              )}

                              <div className="flex flex-wrap gap-1 pt-0.5">
                                {row.education_levels.length > 0 ? (
                                  row.education_levels.map((lvl) => renderLevelBadge(lvl))
                                ) : (
                                  <span className="text-[9px] text-slate-400">
                                    Todos os níveis
                                  </span>
                                )}
                              </div>
                            </div>
                          ) : (
                            <span className="text-slate-300 dark:text-slate-700">—</span>
                          )}
                        </td>
                        <td className="py-2 px-2.5 text-right whitespace-nowrap">
                          {row.isExisting ? (
                            <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/40 px-2 py-0.5 rounded-full border border-blue-200 dark:border-blue-800">
                              Atualizar
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 px-2 py-0.5 rounded-full border border-emerald-200 dark:border-emerald-800">
                              Novo
                            </span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Botões de Ação do Rodapé */}
        <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100 dark:border-slate-800">
          <Button
            type="button"
            variant="outline"
            onClick={handleClose}
            disabled={isSubmitting}
          >
            Cancelar
          </Button>

          {parseResult && parseResult.totalRows > 0 && (
            <Button
              type="button"
              variant="primary"
              onClick={handleSubmit}
              isLoading={isSubmitting}
              disabled={parseResult.hasErrors || isSubmitting}
              className="bg-teal-600 hover:bg-teal-700 text-white"
            >
              <Check size={14} className="mr-1.5" />
              Confirmar e Importar {parseResult.totalRows} Participante(s)
            </Button>
          )}
        </div>
      </div>
    </Modal>
  );
}
