"use client";

import React, { createContext, useContext, useEffect, useState, useCallback } from "react";
import { EventItem } from "../types";
import { authService } from "../services/auth.service";
import { eventService } from "../services/event.service";

interface EventContextType {
  activeEvent: EventItem | null;
  setActiveEvent: (event: EventItem | null) => void;
  clearActiveEvent: () => void;
  isLoadingActiveEvent: boolean;
  refreshActiveEvent: () => Promise<void>;
}

const EventContext = createContext<EventContextType | undefined>(undefined);

function getUserStorageKey(userId?: number | null): string {
  return userId ? `easyevent_active_event_user_${userId}` : "easyevent_active_event";
}

function getLegacyUserStorageKey(userId?: number | null): string {
  return userId ? `fecitel_active_event_user_${userId}` : "fecitel_active_event";
}

export const EventProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activeEvent, setActiveEventState] = useState<EventItem | null>(null);
  const [isLoadingActiveEvent, setIsLoadingActiveEvent] = useState(true);

  // Sincroniza e valida o evento ativo com os eventos permitidos para o usuário logado
  const validateAndSyncActiveEvent = useCallback(async () => {
    setIsLoadingActiveEvent(true);
    try {
      const currentUser = authService.getCurrentUser();

      // Limpeza de chave legada não-escopada
      if (typeof window !== "undefined") {
        localStorage.removeItem("easyevent_active_event");
        localStorage.removeItem("fecitel_active_event");
      }

      if (!currentUser || !authService.isAuthenticated()) {
        setActiveEventState(null);
        setIsLoadingActiveEvent(false);
        return;
      }

      const storageKey = getUserStorageKey(currentUser.id);
      const legacyKey = getLegacyUserStorageKey(currentUser.id);
      let storedEvent: EventItem | null = null;

      try {
        const raw = localStorage.getItem(storageKey) || localStorage.getItem(legacyKey);
        if (raw) {
          storedEvent = JSON.parse(raw);
        }
      } catch {
        storedEvent = null;
      }

      // Busca a lista oficial de feiras que o usuário atual realmente possui permissão
      try {
        const allowedEvents = await eventService.getEvents();

        if (allowedEvents.length === 0) {
          // Usuário novo sem feiras: limpa contexto
          setActiveEventState(null);
          localStorage.removeItem(storageKey);
        } else if (storedEvent) {
          // Valida se a feira previamente salva ainda está na lista de permissões do usuário
          const matched = allowedEvents.find((e) => e.id === storedEvent?.id);
          if (matched) {
            // Atualiza com os dados oficiais frescos do backend
            setActiveEventState(matched);
            localStorage.setItem(storageKey, JSON.stringify(matched));
          } else {
            // Feira pertencia a outro usuário ou foi revogada: limpa imediatamente
            console.warn("Evento ativo anterior não pertence ao usuário autenticado. Contexto redefinido.");
            setActiveEventState(null);
            localStorage.removeItem(storageKey);
          }
        } else if (allowedEvents.length === 1) {
          // Se o usuário possui apenas 1 feira e nenhuma selecionada, seleciona automaticamente
          setActiveEventState(allowedEvents[0]);
          localStorage.setItem(storageKey, JSON.stringify(allowedEvents[0]));
        } else {
          setActiveEventState(null);
        }
      } catch (err) {
        console.error("Erro ao validar feiras do usuário:", err);
        // Em caso de falha na API, se houver evento salvo, não assume posse indevida
        setActiveEventState(null);
      }
    } finally {
      setIsLoadingActiveEvent(false);
    }
  }, []);

  useEffect(() => {
    validateAndSyncActiveEvent();
  }, [validateAndSyncActiveEvent]);

  const setActiveEvent = (event: EventItem | null) => {
    const currentUser = authService.getCurrentUser();
    const storageKey = getUserStorageKey(currentUser?.id);

    setActiveEventState(event);

    if (typeof window !== "undefined") {
      if (event && currentUser) {
        try {
          localStorage.setItem(storageKey, JSON.stringify(event));
          // Limpa chave legada se existir
          const legacyKey = getLegacyUserStorageKey(currentUser.id);
          localStorage.removeItem(legacyKey);
        } catch (e) {
          console.error("Erro ao salvar evento ativo:", e);
        }
      } else {
        localStorage.removeItem(storageKey);
        if (currentUser) {
          localStorage.removeItem(getLegacyUserStorageKey(currentUser.id));
        }
        localStorage.removeItem("easyevent_active_event");
        localStorage.removeItem("fecitel_active_event");
      }
    }
  };

  const clearActiveEvent = () => {
    setActiveEvent(null);
  };

  return (
    <EventContext.Provider
      value={{
        activeEvent,
        setActiveEvent,
        clearActiveEvent,
        isLoadingActiveEvent,
        refreshActiveEvent: validateAndSyncActiveEvent,
      }}
    >
      {children}
    </EventContext.Provider>
  );
};

export const useActiveEvent = () => {
  const context = useContext(EventContext);
  if (!context) {
    throw new Error("useActiveEvent deve ser usado dentro de um EventProvider");
  }
  return context;
};
