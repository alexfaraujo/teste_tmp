import api from "./api";
import {
  PaginatedParticipantsResponse,
  ParticipantBatchImport,
  ParticipantBatchResponse,
  ParticipantCreatePayload,
  ParticipantDetail,
  ParticipantItem,
  ParticipantUpdatePayload,
} from "../types";

export interface ParticipantFilterParams {
  event_id: number;
  page?: number;
  limit?: number;
  search?: string;
  role?: string;
  presence?: boolean;
  kit_delivered?: boolean;
}

export const participantService = {
  async getParticipants(params: ParticipantFilterParams): Promise<PaginatedParticipantsResponse> {
    const searchParams = new URLSearchParams();
    searchParams.append("event_id", params.event_id.toString());
    if (params.page) searchParams.append("page", params.page.toString());
    if (params.limit) searchParams.append("limit", params.limit.toString());
    if (params.search && params.search.trim()) searchParams.append("search", params.search.trim());
    if (params.role && params.role !== "ALL") searchParams.append("role", params.role);
    if (params.presence !== undefined) searchParams.append("presence", params.presence.toString());
    if (params.kit_delivered !== undefined) searchParams.append("kit_delivered", params.kit_delivered.toString());

    const response = await api.get<PaginatedParticipantsResponse>(
      `/participants?${searchParams.toString()}`
    );
    return response.data;
  },

  async getParticipant(personId: number, eventId: number): Promise<ParticipantDetail> {
    const response = await api.get<ParticipantDetail>(
      `/participants/${personId}?event_id=${eventId}`
    );
    return response.data;
  },

  async createParticipant(
    eventId: number,
    payload: ParticipantCreatePayload
  ): Promise<ParticipantItem> {
    const response = await api.post<ParticipantItem>(
      `/participants?event_id=${eventId}`,
      payload
    );
    return response.data;
  },

  async updateParticipant(
    personId: number,
    eventId: number,
    payload: ParticipantUpdatePayload
  ): Promise<ParticipantItem> {
    const response = await api.patch<ParticipantItem>(
      `/participants/${personId}?event_id=${eventId}`,
      payload
    );
    return response.data;
  },

  async deleteParticipant(personId: number, eventId: number): Promise<{ message: string }> {
    const response = await api.delete<{ message: string }>(
      `/participants/${personId}?event_id=${eventId}`
    );
    return response.data;
  },

  async importParticipantsBatch(
    eventId: number,
    payload: ParticipantBatchImport
  ): Promise<ParticipantBatchResponse> {
    const response = await api.post<ParticipantBatchResponse>(
      `/participants/batch?event_id=${eventId}`,
      payload
    );
    return response.data;
  },

  async downloadParticipantBadgePdf(
    participantId: number,
    eventId: number,
    participantName?: string
  ): Promise<void> {
    try {
      const response = await api.get(
        `/participants/${participantId}/badge/pdf?event_id=${eventId}`,
        { responseType: "blob" }
      );
      const blob = new Blob([response.data], { type: "application/pdf" });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      const safeName = participantName
        ? participantName.toLowerCase().replace(/[^a-z0-9_-]/g, "_")
        : `participante_${participantId}`;
      link.setAttribute("download", `cracha_${safeName}.pdf`);
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);
    } catch (err: any) {
      if (err.response?.data instanceof Blob) {
        const text = await err.response.data.text();
        try {
          const json = JSON.parse(text);
          if (json.detail) {
            err.response.data = json;
          }
        } catch {
          // manter original se não for JSON
        }
      }
      throw err;
    }
  },
};
