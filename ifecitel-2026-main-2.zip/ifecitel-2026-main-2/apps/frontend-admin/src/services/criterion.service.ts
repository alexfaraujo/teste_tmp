import api from "./api";
import {
  EvaluationCriterion,
  EvaluationCriterionBatchItem,
  EvaluationCriterionBatchResponse,
  EvaluationCriterionCreatePayload,
  EvaluationCriterionUpdatePayload,
} from "../types";

export const criterionService = {
  async getCriteria(eventId: number): Promise<EvaluationCriterion[]> {
    const response = await api.get<EvaluationCriterion[]>(`/events/${eventId}/criteria`);
    return response.data;
  },

  async createCriterion(
    eventId: number,
    payload: EvaluationCriterionCreatePayload
  ): Promise<EvaluationCriterion> {
    const response = await api.post<EvaluationCriterion>(
      `/events/${eventId}/criteria`,
      payload
    );
    return response.data;
  },

  async updateCriterion(
    eventId: number,
    criterionId: number,
    payload: EvaluationCriterionUpdatePayload
  ): Promise<EvaluationCriterion> {
    const response = await api.put<EvaluationCriterion>(
      `/events/${eventId}/criteria/${criterionId}`,
      payload
    );
    return response.data;
  },

  async deleteCriterion(eventId: number, criterionId: number): Promise<void> {
    await api.delete(`/events/${eventId}/criteria/${criterionId}`);
  },

  async importBatch(
    eventId: number,
    items: EvaluationCriterionBatchItem[]
  ): Promise<EvaluationCriterionBatchResponse> {
    const response = await api.post<EvaluationCriterionBatchResponse>(
      `/events/${eventId}/criteria/batch`,
      { items }
    );
    return response.data;
  },

  async uploadCsv(
    eventId: number,
    file: File
  ): Promise<EvaluationCriterionBatchResponse> {
    const formData = new FormData();
    formData.append("file", file);
    const response = await api.post<EvaluationCriterionBatchResponse>(
      `/events/${eventId}/criteria/upload-csv`,
      formData,
      {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      }
    );
    return response.data;
  },

  async downloadTemplateCsv(eventId: number): Promise<Blob> {
    const response = await api.get(`/events/${eventId}/criteria/template-csv`, {
      responseType: "blob",
    });
    return response.data;
  },
};
