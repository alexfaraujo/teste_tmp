import api from "./api";
import {
  AwardItem,
  AwardCreatePayload,
  AwardUpdatePayload,
  AwardStandingsResponse,
  EvaluationCriterion,
  AwardCriterionLinkInput,
} from "../types";

export const awardService = {
  async getAwards(eventId: number): Promise<AwardItem[]> {
    const response = await api.get<AwardItem[]>(`/events/${eventId}/awards`);
    return response.data;
  },

  async createAward(eventId: number, payload: AwardCreatePayload): Promise<AwardItem> {
    const response = await api.post<AwardItem>(`/events/${eventId}/awards`, payload);
    return response.data;
  },

  async updateAward(awardId: number, payload: AwardUpdatePayload): Promise<AwardItem> {
    const response = await api.put<AwardItem>(`/awards/${awardId}`, payload);
    return response.data;
  },

  async deleteAward(awardId: number): Promise<void> {
    await api.delete(`/awards/${awardId}`);
  },

  async linkCriteria(
    awardId: number,
    criteria: AwardCriterionLinkInput[]
  ): Promise<AwardItem> {
    const response = await api.post<AwardItem>(`/awards/${awardId}/criteria`, criteria);
    return response.data;
  },

  async getAwardStandings(awardId: number): Promise<AwardStandingsResponse> {
    const response = await api.get<AwardStandingsResponse>(`/awards/${awardId}/standings`);
    return response.data;
  },

  async getEventCriteria(eventId: number): Promise<EvaluationCriterion[]> {
    const response = await api.get<EvaluationCriterion[]>(`/events/${eventId}/criteria`);
    return response.data;
  },
};
