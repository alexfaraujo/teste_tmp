import api from "./api";
import {
  BarcodeScanResponse,
  KitCheckoutResponse,
  ProjectKitsSummaryResponse,
  KitCardsPdfOptions,
} from "../types";

export const logisticsService = {
  async scanBarcode(barcode: string, eventId: number): Promise<BarcodeScanResponse> {
    const response = await api.post<BarcodeScanResponse>("/logistics/scan-barcode", {
      barcode,
      event_id: eventId,
    });
    return response.data;
  },

  async checkoutKit(barcode: string, eventId: number): Promise<KitCheckoutResponse> {
    const response = await api.post<KitCheckoutResponse>("/logistics/checkout-kit", {
      barcode,
      event_id: eventId,
    });
    return response.data;
  },

  async getProjectKits(projectId: number): Promise<ProjectKitsSummaryResponse> {
    const response = await api.get<ProjectKitsSummaryResponse>(`/logistics/project-kits/${projectId}`);
    return response.data;
  },

  async checkoutProjectKits(projectId: number): Promise<ProjectKitsSummaryResponse> {
    const response = await api.post<ProjectKitsSummaryResponse>(`/logistics/project-kits/${projectId}/checkout`);
    return response.data;
  },

  async downloadKitCardsPdf(eventId: number, options: KitCardsPdfOptions = {}): Promise<void> {
    const params = new URLSearchParams();
    if (options.format) params.append("format", options.format);
    if (options.include_tshirt_students !== undefined)
      params.append("include_tshirt_students", String(options.include_tshirt_students));
    if (options.include_tshirt_advisors !== undefined)
      params.append("include_tshirt_advisors", String(options.include_tshirt_advisors));
    if (options.include_tshirt_coadvisors !== undefined)
      params.append("include_tshirt_coadvisors", String(options.include_tshirt_coadvisors));
    if (options.include_tshirt_evaluators !== undefined)
      params.append("include_tshirt_evaluators", String(options.include_tshirt_evaluators));
    if (options.sort_by) params.append("sort_by", options.sort_by);
    if (options.status_filter) params.append("status_filter", options.status_filter);

    try {
      const response = await api.get(`/events/${eventId}/kit-cards/pdf?${params.toString()}`, {
        responseType: "blob",
      });
      const blob = new Blob([response.data], { type: "application/pdf" });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute(
        "download",
        `cards_kits_evento_${eventId}_${options.format || "project"}.pdf`
      );
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);
    } catch (err: any) {
      if (err.response?.data instanceof Blob) {
        const text = await err.response.data.text();
        try {
          const json = JSON.parse(text);
          if (json.detail) {
            err.response.data = json;
          }
        } catch {
          // manter original
        }
      }
      throw err;
    }
  },
};

