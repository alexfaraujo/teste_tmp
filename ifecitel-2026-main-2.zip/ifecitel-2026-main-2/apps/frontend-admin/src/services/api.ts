import axios from "axios";

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000/api/v1";
const API_KEY = process.env.NEXT_PUBLIC_API_KEY || "fecitel_secret_api_key_2026";

export const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    "Content-Type": "application/json",
    "X-API-Key": API_KEY,
  },
});

// Interceptor de Requisição: Anexa API Key universal (SEC-03) e JWT Bearer Token
api.interceptors.request.use(
  (config) => {
    config.headers["X-API-Key"] = API_KEY;

    if (typeof window !== "undefined") {
      const token = localStorage.getItem("easyevent_token") || localStorage.getItem("fecitel_token");
      if (token && !config.headers.Authorization) {
        config.headers.Authorization = `Bearer ${token}`;
      }
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Interceptor de Resposta: Trata expiração de sessão (401)
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (typeof window !== "undefined" && error.response?.status === 401) {
      const isLoginUrl = error.config?.url?.includes("/auth/");
      if (!isLoginUrl) {
        localStorage.removeItem("easyevent_token");
        localStorage.removeItem("easyevent_user");
        localStorage.removeItem("fecitel_token");
        localStorage.removeItem("fecitel_user");
        if (!window.location.pathname.includes("/login")) {
          window.location.href = "/login?expired=1";
        }
      }
    }
    return Promise.reject(error);
  }
);

export default api;
