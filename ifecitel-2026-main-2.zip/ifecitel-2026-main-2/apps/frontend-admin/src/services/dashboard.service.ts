import api from "./api";
import {
  AdminOverviewResponse,
  PublicTvMetricsResponse,
  AreaLevelLeaderboardGroup,
  OverallLeaderboardResponse,
} from "../types";

export const dashboardService = {
  async getPublicTvMetrics(eventId: number): Promise<PublicTvMetricsResponse> {
    const response = await api.get<PublicTvMetricsResponse>(
      `/dashboard/public-tv?event_id=${eventId}`
    );
    return response.data;
  },

  async getAdminOverview(eventId: number): Promise<AdminOverviewResponse> {
    const response = await api.get<AdminOverviewResponse>(
      `/dashboard/admin-overview?event_id=${eventId}`
    );
    return response.data;
  },

  async getAreaLevelLeaderboard(
    eventId: number,
    areaId?: number,
    educationLevel?: string
  ): Promise<AreaLevelLeaderboardGroup[]> {
    const params = new URLSearchParams();
    params.append("event_id", String(eventId));
    if (areaId) params.append("area_id", String(areaId));
    if (educationLevel) params.append("education_level", educationLevel);

    const response = await api.get<AreaLevelLeaderboardGroup[]>(
      `/dashboard/leaderboard/area-level?${params.toString()}`
    );
    return response.data;
  },

  async getOverallLeaderboard(eventId: number): Promise<OverallLeaderboardResponse> {
    const response = await api.get<OverallLeaderboardResponse>(
      `/dashboard/leaderboard/overall?event_id=${eventId}`
    );
    return response.data;
  },
};
