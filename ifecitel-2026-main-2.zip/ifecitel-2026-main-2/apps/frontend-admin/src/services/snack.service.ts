import api from "./api";
import {
  SnackMoment,
  SnackMomentCreateInput,
  SnackMomentUpdateInput,
  SnackDeliverScanRequest,
  SnackDeliverScanResponse,
  SnackMomentReport,
} from "../types";

export const snackService = {
  async getMoments(eventId: number): Promise<SnackMoment[]> {
    const response = await api.get<SnackMoment[]>(`/snacks/events/${eventId}/moments`);
    return response.data;
  },

  async createMoment(eventId: number, payload: SnackMomentCreateInput): Promise<SnackMoment> {
    const response = await api.post<SnackMoment>(`/snacks/events/${eventId}/moments`, payload);
    return response.data;
  },

  async getMoment(momentId: number): Promise<SnackMoment> {
    const response = await api.get<SnackMoment>(`/snacks/moments/${momentId}`);
    return response.data;
  },

  async updateMoment(momentId: number, payload: SnackMomentUpdateInput): Promise<SnackMoment> {
    const response = await api.put<SnackMoment>(`/snacks/moments/${momentId}`, payload);
    return response.data;
  },

  async toggleMomentActive(momentId: number, isActive: boolean): Promise<SnackMoment> {
    const response = await api.patch<SnackMoment>(
      `/snacks/moments/${momentId}/toggle?is_active=${isActive}`
    );
    return response.data;
  },

  async deleteMoment(momentId: number): Promise<void> {
    await api.delete(`/snacks/moments/${momentId}`);
  },

  async deliverSnack(
    momentId: number,
    payload: SnackDeliverScanRequest,
    operatorId?: number
  ): Promise<SnackDeliverScanResponse> {
    const url = operatorId
      ? `/snacks/moments/${momentId}/deliver?operator_id=${operatorId}`
      : `/snacks/moments/${momentId}/deliver`;
    const response = await api.post<SnackDeliverScanResponse>(url, payload);
    return response.data;
  },

  async getMomentReport(momentId: number): Promise<SnackMomentReport> {
    const response = await api.get<SnackMomentReport>(`/snacks/moments/${momentId}/report`);
    return response.data;
  },

  async getEligibleCount(eventId: number, targetRoles: string = "ALL"): Promise<number> {
    const response = await api.get<{ count: number }>(
      `/snacks/events/${eventId}/eligible-count?target_roles=${encodeURIComponent(targetRoles)}`
    );
    return response.data.count;
  },
};
