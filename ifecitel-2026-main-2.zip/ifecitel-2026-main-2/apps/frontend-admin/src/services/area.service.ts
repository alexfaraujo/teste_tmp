import api from "./api";
import { KnowledgeArea, Subarea, KnowledgeAreaBatchImport, KnowledgeAreaBatchResponse } from "../types";

export interface CreateAreaPayload {
  name: string;
}

export interface CreateSubareaPayload {
  name: string;
}

export const areaService = {
  async getAreas(eventId: number): Promise<KnowledgeArea[]> {
    const response = await api.get<KnowledgeArea[]>(`/events/${eventId}/areas`);
    return response.data;
  },

  async createArea(eventId: number, payload: CreateAreaPayload): Promise<KnowledgeArea> {
    const response = await api.post<KnowledgeArea>(`/events/${eventId}/areas`, payload);
    return response.data;
  },

  async deleteArea(areaId: number): Promise<void> {
    await api.delete(`/areas/${areaId}`);
  },

  async createSubarea(areaId: number, payload: CreateSubareaPayload): Promise<Subarea> {
    const response = await api.post<Subarea>(`/areas/${areaId}/subareas`, payload);
    return response.data;
  },

  async deleteSubarea(subareaId: number): Promise<void> {
    await api.delete(`/subareas/${subareaId}`);
  },

  async importAreasBatch(eventId: number, payload: KnowledgeAreaBatchImport): Promise<KnowledgeAreaBatchResponse> {
    const response = await api.post<KnowledgeAreaBatchResponse>(`/events/${eventId}/areas/batch`, payload);
    return response.data;
  },
};

