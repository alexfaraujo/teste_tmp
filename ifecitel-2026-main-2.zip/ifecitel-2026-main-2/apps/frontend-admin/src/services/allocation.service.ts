import api from "./api";
import { AllocationResponse, EvaluatorCheckinAllocationResponse, EvaluatorListItem } from "../types";

export interface AutoBalanceSummaryResponse {
  event_id: number;
  present_projects_count: number;
  evaluators_count: number;
  total_allocations_created: number;
  golden_rule_satisfied: boolean;
  allocations_per_subarea: Record<string, number>;
  message: string;
}

export interface ManualAllocationPayload {
  event_id: number;
  project_id: number;
  evaluator_id: number;
  override_conflict?: boolean;
  override_reason?: string;
}

export const allocationService = {
  async getEvaluators(eventId: number): Promise<EvaluatorListItem[]> {
    const response = await api.get<EvaluatorListItem[]>("/allocations/evaluators", {
      params: { event_id: eventId },
    });
    return response.data;
  },

  async checkinEvaluator(evaluatorId: number, eventId: number): Promise<EvaluatorCheckinAllocationResponse> {
    const response = await api.post<EvaluatorCheckinAllocationResponse>(
      `/allocations/evaluators/${evaluatorId}/checkin?event_id=${eventId}`
    );
    return response.data;
  },

  async scanCheckinEvaluator(barcode: string, eventId: number): Promise<EvaluatorCheckinAllocationResponse> {
    const response = await api.post<EvaluatorCheckinAllocationResponse>(
      "/allocations/evaluators/scan-checkin",
      { barcode, event_id: eventId }
    );
    return response.data;
  },

  async autoBalance(eventId: number): Promise<AutoBalanceSummaryResponse> {
    const response = await api.post<AutoBalanceSummaryResponse>("/allocations/auto-balance", {
      event_id: eventId,
    });
    return response.data;
  },

  async manualAllocate(payload: ManualAllocationPayload): Promise<AllocationResponse> {
    const response = await api.post<AllocationResponse>("/allocations/manual", payload);
    return response.data;
  },

  async cancelAllocation(allocationId: number): Promise<AllocationResponse> {
    const response = await api.delete<AllocationResponse>(`/allocations/${allocationId}`);
    return response.data;
  },

  async listAllocations(
    eventId: number,
    projectId?: number,
    evaluatorId?: number,
    status?: string
  ): Promise<AllocationResponse[]> {
    const params = new URLSearchParams();
    params.append("event_id", eventId.toString());
    if (projectId) params.append("project_id", projectId.toString());
    if (evaluatorId) params.append("evaluator_id", evaluatorId.toString());
    if (status) params.append("status", status);

    const response = await api.get<AllocationResponse[]>(`/allocations?${params.toString()}`);
    return response.data;
  },

  async qualifyEvaluator(personId: number, eventId: number, subareaIds: number[]): Promise<any> {
    const response = await api.post("/allocations/qualify", {
      person_id: personId,
      event_id: eventId,
      subarea_ids: subareaIds,
    });
    return response.data;
  },
};
