import api from "./api";
import {
  EventItem,
  EventAdminItem,
  EventAdminRole,
  EventAdminInput,
  EducationLevel,
  KitCardsPdfOptions,
} from "../types";

export interface CreateEventPayload {
  name: string;
  year: number;
  description?: string;
  workload_hours?: number;
  max_projects?: number;
  location?: string;
  start_date: string;
  end_date: string;
  summary_extension?: string;
  banner_extension?: string;
  max_file_size_mb?: number;
  max_projects_per_evaluator?: number;
  organizing_institution?: string;
  theme?: string;
  contact_email?: string;
  website_url?: string;
  logo_url?: string;
  education_levels?: {
    level_name: EducationLevel;
    max_students: number;
    min_evaluators: number;
  }[];
  administrators?: EventAdminInput[];
}

export type UpdateEventPayload = Partial<CreateEventPayload>;

export interface PaginatedResponse<T> {
  items: T[];
  total: number;
  page: number;
  limit: number;
  total_pages: number;
}

export interface EventAdminsResponse {
  items: EventAdminItem[];
  total: number;
}

export const eventService = {
  async getEvents(search?: string): Promise<EventItem[]> {
    const response = await api.get<EventItem[]>("/events", {
      params: search ? { search } : undefined,
    });
    return response.data;
  },

  async getPaginatedEvents(page = 1, limit = 15, search?: string): Promise<PaginatedResponse<EventItem>> {
    const response = await api.get<PaginatedResponse<EventItem>>("/events", {
      params: {
        page,
        limit,
        ...(search?.trim() ? { search: search.trim() } : {}),
      },
    });
    return response.data;
  },

  async getEvent(id: number): Promise<EventItem> {
    const response = await api.get<EventItem>(`/events/${id}`);
    return response.data;
  },

  async createEvent(payload: CreateEventPayload): Promise<EventItem> {
    const response = await api.post<EventItem>("/events", payload);
    return response.data;
  },

  async updateEvent(id: number, payload: UpdateEventPayload): Promise<EventItem> {
    const response = await api.put<EventItem>(`/events/${id}`, payload);
    return response.data;
  },

  // Gestão de Equipe e Administradores da Feira (Regra BR-23)
  async getAdmins(eventId: number): Promise<EventAdminsResponse> {
    const response = await api.get<EventAdminsResponse>(`/events/${eventId}/admins`);
    return response.data;
  },

  async addAdmin(eventId: number, payload: { email: string; role: EventAdminRole }): Promise<EventAdminItem> {
    const response = await api.post<EventAdminItem>(`/events/${eventId}/admins`, payload);
    return response.data;
  },

  async updateAdminRole(eventId: number, personId: number, role: EventAdminRole): Promise<EventAdminItem> {
    const response = await api.put<EventAdminItem>(`/events/${eventId}/admins/${personId}`, { role });
    return response.data;
  },

  async removeAdmin(eventId: number, personId: number): Promise<void> {
    await api.delete(`/events/${eventId}/admins/${personId}`);
  },

  // Upload de Logotipo PNG ou JPG
  async uploadLogo(eventId: number, file: File): Promise<{ logo_url: string; message: string }> {
    const formData = new FormData();
    formData.append("file", file);
    const response = await api.post<{ logo_url: string; message: string }>(
      `/events/${eventId}/logo`,
      formData,
      {
        headers: { "Content-Type": "multipart/form-data" },
      }
    );
    return response.data;
  },

  async uploadTempLogo(file: File): Promise<{ logo_url: string }> {
    const formData = new FormData();
    formData.append("file", file);
    const response = await api.post<{ logo_url: string }>(
      "/events/upload-logo",
      formData,
      {
        headers: { "Content-Type": "multipart/form-data" },
      }
    );
    return response.data;
  },

  // Exportar Crachás em Lote em formato PDF
  async downloadBadgesPdf(eventId: number, filter: string = "all"): Promise<void> {
    try {
      const response = await api.get(`/events/${eventId}/badges/pdf?filter=${filter}`, {
        responseType: "blob",
      });
      const blob = new Blob([response.data], { type: "application/pdf" });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", `crachas_evento_${eventId}_${filter}.pdf`);
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);
    } catch (err: any) {
      if (err.response?.data instanceof Blob) {
        const text = await err.response.data.text();
        try {
          const json = JSON.parse(text);
          if (json.detail) {
            err.response.data = json;
          }
        } catch {
          // manter original
        }
      }
      throw err;
    }
  },

  // Exportar Cards de Kits em formato PDF (Individual ou por Projeto)
  async downloadKitCardsPdf(eventId: number, options: KitCardsPdfOptions = {}): Promise<void> {
    const params = new URLSearchParams();
    if (options.format) params.append("format", options.format);
    if (options.include_tshirt_students !== undefined)
      params.append("include_tshirt_students", String(options.include_tshirt_students));
    if (options.include_tshirt_advisors !== undefined)
      params.append("include_tshirt_advisors", String(options.include_tshirt_advisors));
    if (options.include_tshirt_coadvisors !== undefined)
      params.append("include_tshirt_coadvisors", String(options.include_tshirt_coadvisors));
    if (options.include_tshirt_evaluators !== undefined)
      params.append("include_tshirt_evaluators", String(options.include_tshirt_evaluators));
    if (options.sort_by) params.append("sort_by", options.sort_by);
    if (options.status_filter) params.append("status_filter", options.status_filter);

    try {
      const response = await api.get(`/events/${eventId}/kit-cards/pdf?${params.toString()}`, {
        responseType: "blob",
      });
      const blob = new Blob([response.data], { type: "application/pdf" });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute(
        "download",
        `cards_kits_evento_${eventId}_${options.format || "project"}.pdf`
      );
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);
    } catch (err: any) {
      if (err.response?.data instanceof Blob) {
        const text = await err.response.data.text();
        try {
          const json = JSON.parse(text);
          if (json.detail) {
            err.response.data = json;
          }
        } catch {
          // manter original
        }
      }
      throw err;
    }
  },
};


