import api from "./api";
import {
  BoothStickersPdfOptions,
  EducationLevel,
  PaginatedResponse,
  ProjectBatchImportPayload,
  ProjectBatchResponse,
  ProjectCreatePayload,
  ProjectItem,
  ProjectStatus,
  ProjectUpdatePayload,
} from "../types";

export interface GetProjectsParams {
  event_id: number;
  page?: number;
  limit?: number;
  status?: ProjectStatus | string;
  subarea_id?: number;
  education_level?: EducationLevel | string;
  search?: string;
}

export interface HomologatePayload {
  homologated: boolean;
  booth_number?: string;
  rejection_reason?: string;
}

export const projectService = {
  /**
   * Lista projetos de forma paginada para o evento ativo (Regra BR-18: 15 itens por página).
   */
  async getPaginatedProjects(
    params: GetProjectsParams
  ): Promise<PaginatedResponse<ProjectItem>> {
    const searchParams = new URLSearchParams();
    searchParams.append("event_id", params.event_id.toString());
    searchParams.append("page", (params.page || 1).toString());
    searchParams.append("limit", (params.limit || 15).toString());

    if (params.status && params.status !== "ALL") {
      searchParams.append("status", params.status);
    }
    if (params.education_level && params.education_level !== "ALL") {
      searchParams.append("education_level", params.education_level);
    }
    if (params.subarea_id) {
      searchParams.append("subarea_id", params.subarea_id.toString());
    }
    if (params.search && params.search.trim()) {
      searchParams.append("search", params.search.trim());
    }

    const response = await api.get<PaginatedResponse<ProjectItem>>(
      `/projects?${searchParams.toString()}`
    );
    return response.data;
  },

  /**
   * Lista projetos sem paginação (se necessário para relatórios ou seletores).
   */
  async getProjects(params: GetProjectsParams): Promise<ProjectItem[]> {
    const searchParams = new URLSearchParams();
    searchParams.append("event_id", params.event_id.toString());
    if (params.status && params.status !== "ALL") {
      searchParams.append("status", params.status);
    }
    if (params.education_level && params.education_level !== "ALL") {
      searchParams.append("education_level", params.education_level);
    }
    if (params.subarea_id) {
      searchParams.append("subarea_id", params.subarea_id.toString());
    }
    if (params.search && params.search.trim()) {
      searchParams.append("search", params.search.trim());
    }

    const response = await api.get<ProjectItem[]>(
      `/projects?${searchParams.toString()}`
    );
    return response.data;
  },

  async getProject(id: number): Promise<ProjectItem> {
    const response = await api.get<ProjectItem>(`/projects/${id}`);
    return response.data;
  },

  /**
   * Cria um novo trabalho científico individual com validação de cotas (BR-04, BR-05).
   */
  async createProject(payload: ProjectCreatePayload): Promise<ProjectItem> {
    const response = await api.post<ProjectItem>("/projects", payload);
    return response.data;
  },

  /**
   * Atualiza dados cadastrais do projeto (título, área, estande, resumo, tomada, mesa).
   */
  async updateProject(
    id: number,
    payload: ProjectUpdatePayload
  ): Promise<ProjectItem> {
    const response = await api.put<ProjectItem>(`/projects/${id}`, payload);
    return response.data;
  },

  /**
   * Homologa ou indefere um trabalho científico (Regra BR-06).
   */
  async homologateProject(
    id: number,
    payload: HomologatePayload
  ): Promise<ProjectItem> {
    const response = await api.patch<ProjectItem>(
      `/projects/${id}/homologate`,
      payload
    );
    return response.data;
  },

  /**
   * Aloca ou altera número de estande do trabalho (ex: A-12).
   */
  async assignBooth(id: number, boothNumber: string): Promise<ProjectItem> {
    const response = await api.patch<ProjectItem>(`/projects/${id}/booth`, {
      booth_number: boothNumber.trim(),
    });
    return response.data;
  },

  async downloadTemplateCsv(eventId: number): Promise<Blob> {
    const response = await api.get(`/projects/template-csv?event_id=${eventId}`, {
      responseType: "blob",
    });
    return response.data;
  },

  async importBatch(
    eventId: number,
    payload: ProjectBatchImportPayload
  ): Promise<ProjectBatchResponse> {
    const response = await api.post<ProjectBatchResponse>(
      `/projects/batch?event_id=${eventId}`,
      payload
    );
    return response.data;
  },

  async uploadCsv(
    eventId: number,
    file: File,
    autoHomologate: boolean = true
  ): Promise<ProjectBatchResponse> {
    const formData = new FormData();
    formData.append("file", file);
    const response = await api.post<ProjectBatchResponse>(
      `/projects/upload-csv?event_id=${eventId}&auto_homologate=${autoHomologate}`,
      formData,
      {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      }
    );
    return response.data;
  },

  async downloadEventBoothStickersPdf(
    eventId: number,
    options: BoothStickersPdfOptions = {}
  ): Promise<void> {
    const params = new URLSearchParams();
    if (options.status_filter) params.append("status_filter", options.status_filter);
    if (options.area_id) params.append("area_id", String(options.area_id));
    if (options.sort_by) params.append("sort_by", options.sort_by);
    if (options.layout) params.append("layout", options.layout);

    try {
      const response = await api.get(`/events/${eventId}/booth-stickers/pdf?${params.toString()}`, {
        responseType: "blob",
      });
      const blob = new Blob([response.data], { type: "application/pdf" });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute(
        "download",
        `adesivos_bancada_evento_${eventId}_${options.layout || "a5_double"}.pdf`
      );
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);
    } catch (err: any) {
      if (err.response?.data instanceof Blob) {
        const text = await err.response.data.text();
        try {
          const json = JSON.parse(text);
          if (json.detail) {
            err.response.data = json;
          }
        } catch {
          // manter original
        }
      }
      throw err;
    }
  },

  async downloadProjectBoothStickerPdf(
    projectId: number,
    layout: "a5_double" | "a6_quad" = "a5_double"
  ): Promise<void> {
    try {
      const response = await api.get(`/projects/${projectId}/booth-sticker/pdf?layout=${layout}`, {
        responseType: "blob",
      });
      const blob = new Blob([response.data], { type: "application/pdf" });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute(
        "download",
        `adesivo_bancada_projeto_${projectId}_${layout}.pdf`
      );
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);
    } catch (err: any) {
      if (err.response?.data instanceof Blob) {
        const text = await err.response.data.text();
        try {
          const json = JSON.parse(text);
          if (json.detail) {
            err.response.data = json;
          }
        } catch {
          // manter original
        }
      }
      throw err;
    }
  },
};

export default projectService;
