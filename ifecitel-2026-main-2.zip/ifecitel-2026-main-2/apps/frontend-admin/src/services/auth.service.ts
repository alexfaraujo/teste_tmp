import api from "./api";
import { User } from "../types";

export interface LoginResponse {
  access_token: string;
  token_type: string;
  expires_in_hours: number;
  id: number;
  name: string;
  email: string;
  role: string;
  barcode: string;
}

export interface RegisterRequestCodeResponse {
  message: string;
  email: string;
  expires_in_seconds: number;
  dev_code?: string;
}

export interface RegisterCompletePayload {
  email: string;
  code: string;
  name: string;
  password: string;
  cpf?: string;
  affiliation?: string;
}

export const authService = {
  async login(email: string, password: string): Promise<LoginResponse> {
    const response = await api.post<LoginResponse>("/auth/admin/login", {
      email,
      password,
    });

    if (response.data.access_token) {
      localStorage.removeItem("easyevent_active_event");
      localStorage.removeItem("fecitel_active_event");
      localStorage.setItem("easyevent_token", response.data.access_token);
      const user: User = {
        id: response.data.id,
        name: response.data.name || email.split("@")[0].toUpperCase(),
        email: response.data.email || email,
        role: (response.data.role as any) || "ADMIN",
        barcode: response.data.barcode,
      };
      localStorage.setItem("easyevent_user", JSON.stringify(user));
    }

    return response.data;
  },

  async requestRegistrationCode(email: string, name?: string): Promise<RegisterRequestCodeResponse> {
    const response = await api.post<RegisterRequestCodeResponse>("/auth/register/request-code", {
      email,
      name,
    });
    return response.data;
  },

  async completeRegistration(payload: RegisterCompletePayload): Promise<LoginResponse> {
    const response = await api.post<LoginResponse>("/auth/register/verify-and-complete", payload);

    if (response.data.access_token) {
      localStorage.removeItem("easyevent_active_event");
      localStorage.removeItem("fecitel_active_event");
      localStorage.setItem("easyevent_token", response.data.access_token);
      const user: User = {
        id: response.data.id,
        name: response.data.name || payload.email.split("@")[0].toUpperCase(),
        email: response.data.email || payload.email,
        role: (response.data.role as any) || "ADMIN",
        barcode: response.data.barcode,
      };
      localStorage.setItem("easyevent_user", JSON.stringify(user));
    }

    return response.data;
  },

  logout(): void {
    if (typeof window !== "undefined") {
      const user = this.getCurrentUser();
      if (user?.id) {
        localStorage.removeItem(`easyevent_active_event_user_${user.id}`);
        localStorage.removeItem(`fecitel_active_event_user_${user.id}`);
      }
      localStorage.removeItem("easyevent_active_event");
      localStorage.removeItem("easyevent_token");
      localStorage.removeItem("easyevent_user");
      localStorage.removeItem("fecitel_active_event");
      localStorage.removeItem("fecitel_token");
      localStorage.removeItem("fecitel_user");
      window.location.href = "/login";
    }
  },

  getCurrentUser(): User | null {
    if (typeof window === "undefined") return null;
    const stored = localStorage.getItem("easyevent_user") || localStorage.getItem("fecitel_user");
    if (!stored) return null;
    try {
      return JSON.parse(stored);
    } catch {
      return null;
    }
  },

  isAuthenticated(): boolean {
    if (typeof window === "undefined") return false;
    return !!(localStorage.getItem("easyevent_token") || localStorage.getItem("fecitel_token"));
  },
};

