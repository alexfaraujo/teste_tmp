import { KnowledgeArea, KnowledgeAreaBatchItem, ParseAreasCsvResult, ParsedAreaRow, GroupedAreaPreview } from "../types";

/**
 * Conteúdo esqueleto oficial de áreas e subáreas para o EasyEvent.
 * Formato tabular linha a linha (Opção 1) com BOM UTF-8 para compatibilidade total com Excel.
 */
export const AREAS_CSV_TEMPLATE = `\uFEFFarea;subarea
Ciências Exatas e da Terra;Matemática
Ciências Exatas e da Terra;Física
Ciências Exatas e da Terra;Química
Ciências Exatas e da Terra;Ciência da Computação
Ciências Biológicas;Botânica
Ciências Biológicas;Zoologia
Ciências Biológicas;Ecologia e Meio Ambiente
Engenharias;Engenharia Elétrica
Engenharias;Robótica e Automação
Ciências da Saúde;Medicina
Ciências da Saúde;Enfermagem
Ciências Agrárias;Agronomia
Ciências Sociais Aplicadas;Administração
Ciências Humanas;Educação
Linguística, Letras e Artes;Artes
Multidisciplinar;
`;

/**
 * Dispara o download client-side do arquivo modelo CSV com BOM UTF-8.
 */
export function downloadAreasCsvTemplate(eventId?: number): void {
  const blob = new Blob([AREAS_CSV_TEMPLATE], {
    type: "text/csv;charset=utf-8;",
  });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.setAttribute(
    "download",
    eventId ? `modelo_areas_subareas_easyevent_evento_${eventId}.csv` : "modelo_areas_subareas_easyevent.csv"
  );
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

/**
 * Divide uma linha de CSV em colunas respeitando aspas duplas.
 */
function parseCsvLine(text: string, delimiter: string): string[] {
  const result: string[] = [];
  let curVal = "";
  let insideQuotes = false;

  for (let i = 0; i < text.length; i++) {
    const char = text[i];
    const nextChar = text[i + 1];

    if (char === '"') {
      if (insideQuotes && nextChar === '"') {
        curVal += '"';
        i++;
      } else {
        insideQuotes = !insideQuotes;
      }
    } else if (char === delimiter && !insideQuotes) {
      result.push(curVal.trim());
      curVal = "";
    } else {
      curVal += char;
    }
  }
  result.push(curVal.trim());
  return result;
}

/**
 * Detecta o delimitador mais provável em uma linha de texto.
 */
function detectDelimiter(firstLine: string): string {
  const countSemicolon = (firstLine.match(/;/g) || []).length;
  const countComma = (firstLine.match(/,/g) || []).length;
  const countTab = (firstLine.match(/\t/g) || []).length;

  if (countSemicolon >= countComma && countSemicolon >= countTab && countSemicolon > 0) {
    return ";";
  }
  if (countTab > countComma && countTab > 0) {
    return "\t";
  }
  return ",";
}

/**
 * Normaliza string removendo acentos e convertendo para minúsculas.
 */
function normalizeHeader(str: string): string {
  return str
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]/g, "");
}

/**
 * Analisa o conteúdo de um arquivo CSV de áreas e subáreas,
 * valida colunas, detecta itens existentes no evento e agrupa para exibição hierárquica.
 */
export function parseAreasCsv(
  csvContent: string,
  existingAreas: KnowledgeArea[] = []
): ParseAreasCsvResult {
  // Limpar BOM UTF-8 se presente
  const cleanContent = csvContent.replace(/^\uFEFF/, "");
  const lines = cleanContent
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter((l) => l.length > 0);

  const errors: string[] = [];
  const warnings: string[] = [];
  const parsedRows: ParsedAreaRow[] = [];
  const batchPayload: KnowledgeAreaBatchItem[] = [];

  if (lines.length === 0) {
    return {
      totalRows: 0,
      validRows: 0,
      invalidRows: 0,
      newAreasCount: 0,
      existingAreasCount: 0,
      newSubareasCount: 0,
      existingSubareasCount: 0,
      groupedAreas: [],
      parsedRows: [],
      batchPayload: [],
      errors: ["O arquivo CSV está vazio."],
      warnings: [],
    };
  }

  // 1. Identificar Delimitador e Cabeçalho
  const firstLine = lines[0];
  const delimiter = detectDelimiter(firstLine);
  const headerCols = parseCsvLine(firstLine, delimiter).map(normalizeHeader);

  const areaIdx = headerCols.findIndex(
    (col) =>
      col === "area" ||
      col === "grandearea" ||
      col === "areadoconhecimento" ||
      col === "nomearea"
  );
  const subareaIdx = headerCols.findIndex(
    (col) =>
      col === "subarea" ||
      col === "subareadoconhecimento" ||
      col === "nomesubarea"
  );

  if (areaIdx === -1) {
    errors.push(
      "Coluna obrigatória 'area' não foi encontrada no cabeçalho do arquivo CSV."
    );
    return {
      totalRows: lines.length - 1,
      validRows: 0,
      invalidRows: lines.length - 1,
      newAreasCount: 0,
      existingAreasCount: 0,
      newSubareasCount: 0,
      existingSubareasCount: 0,
      groupedAreas: [],
      parsedRows: [],
      batchPayload: [],
      errors,
      warnings,
    };
  }

  // Mapas de busca para verificação com áreas e subáreas já existentes
  const existingAreaMap = new Map<string, KnowledgeArea>();
  const existingSubareaMap = new Map<string, Set<string>>();

  existingAreas.forEach((area) => {
    const normArea = area.name.trim().toLowerCase();
    existingAreaMap.set(normArea, area);
    const subSet = new Set<string>();
    (area.subareas || []).forEach((sub) => {
      subSet.add(sub.name.trim().toLowerCase());
    });
    existingSubareaMap.set(normArea, subSet);
  });

  // Estrutura para agrupamento hierárquico
  const groupedMap = new Map<string, GroupedAreaPreview>();

  // 2. Processar Linhas de Dados
  for (let i = 1; i < lines.length; i++) {
    const lineNumber = i + 1;
    const lineCols = parseCsvLine(lines[i], delimiter);

    const rawArea = lineCols[areaIdx] || "";
    const rawSubarea = subareaIdx !== -1 ? lineCols[subareaIdx] || "" : "";

    const areaName = rawArea.trim();
    const subareaName = rawSubarea.trim() || null;
    const rowErrors: string[] = [];

    if (!areaName) {
      rowErrors.push("O nome da grande área não pode ficar em branco.");
      parsedRows.push({
        line_number: lineNumber,
        area: rawArea,
        subarea: subareaName,
        status: "INVALID",
        errors: rowErrors,
      });
      continue;
    }

    if (areaName.length < 2 || areaName.length > 150) {
      rowErrors.push("O nome da área deve ter entre 2 e 150 caracteres.");
      parsedRows.push({
        line_number: lineNumber,
        area: areaName,
        subarea: subareaName,
        status: "INVALID",
        errors: rowErrors,
      });
      continue;
    }

    if (subareaName && (subareaName.length < 2 || subareaName.length > 150)) {
      rowErrors.push("O nome da subárea deve ter entre 2 e 150 caracteres.");
      parsedRows.push({
        line_number: lineNumber,
        area: areaName,
        subarea: subareaName,
        status: "INVALID",
        errors: rowErrors,
      });
      continue;
    }

    // Status da linha
    const normArea = areaName.toLowerCase();
    const areaExistsInDb = existingAreaMap.has(normArea);
    const normSubarea = subareaName ? subareaName.toLowerCase() : null;
    const subareaExistsInDb = normSubarea
      ? existingSubareaMap.get(normArea)?.has(normSubarea) ?? false
      : false;

    const rowStatus = areaExistsInDb && (normSubarea === null || subareaExistsInDb) ? "EXISTING" : "NEW";

    parsedRows.push({
      line_number: lineNumber,
      area: areaName,
      subarea: subareaName,
      status: rowStatus,
      errors: [],
    });

    batchPayload.push({
      area: areaName,
      subarea: subareaName,
    });

    // Agrupamento por área mãe
    if (!groupedMap.has(normArea)) {
      groupedMap.set(normArea, {
        area: areaName,
        isNewArea: !areaExistsInDb,
        subareas: [],
        rowNumbers: [lineNumber],
      });
    } else {
      groupedMap.get(normArea)!.rowNumbers.push(lineNumber);
    }

    if (subareaName) {
      const currentGroup = groupedMap.get(normArea)!;
      const alreadyInGroup = currentGroup.subareas.some(
        (s) => s.name.toLowerCase() === subareaName.toLowerCase()
      );
      if (alreadyInGroup) {
        warnings.push(
          `Linha ${lineNumber}: A subárea '${subareaName}' já foi informada anteriormente para a área '${areaName}' neste mesmo arquivo.`
        );
      } else {
        currentGroup.subareas.push({
          name: subareaName,
          isNewSubarea: !subareaExistsInDb,
          rowNumber: lineNumber,
        });
      }
    }
  }

  const groupedAreas = Array.from(groupedMap.values());

  let newAreasCount = 0;
  let existingAreasCount = 0;
  let newSubareasCount = 0;
  let existingSubareasCount = 0;

  groupedAreas.forEach((group) => {
    if (group.isNewArea) {
      newAreasCount++;
    } else {
      existingAreasCount++;
    }

    group.subareas.forEach((sub) => {
      if (sub.isNewSubarea) {
        newSubareasCount++;
      } else {
        existingSubareasCount++;
      }
    });
  });

  const validRows = parsedRows.filter((r) => r.status !== "INVALID").length;
  const invalidRows = parsedRows.filter((r) => r.status === "INVALID").length;

  return {
    totalRows: lines.length - 1,
    validRows,
    invalidRows,
    newAreasCount,
    existingAreasCount,
    newSubareasCount,
    existingSubareasCount,
    groupedAreas,
    parsedRows,
    batchPayload,
    errors,
    warnings,
  };
}
