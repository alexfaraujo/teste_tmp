import {
  EducationLevel,
  ParsedProjectRow,
  ProjectBatchMemberInput,
  ProjectItem,
  ProjectMemberRole,
  ProjectType,
} from "../types";

export interface SubareaSimple {
  id: number;
  name: string;
  area_name?: string;
}

export interface ParseProjectsCsvResult {
  rows: ParsedProjectRow[];
  totalRows: number;
  newCount: number;
  updateCount: number;
  invalidCount: number;
  hasErrors: boolean;
}

/**
 * Gera conteúdo CSV em UTF-8 com BOM e exemplos didáticos baseados nas subáreas da feira ativa.
 */
export function generateProjectsCsvTemplate(
  subareas: SubareaSimple[],
  maxStudents: number = 5
): string {
  const formatSub = (sub?: SubareaSimple, fallback?: string) => {
    if (!sub) return fallback || "Engenharias -> Robótica e Automação";
    return sub.area_name ? `${sub.area_name} -> ${sub.name}` : sub.name;
  };

  const sub1 = formatSub(subareas[0], "Engenharias -> Robótica e Automação");
  const sub2 = formatSub(subareas[1], "Ciências da Natureza -> Biologia");
  const sub3 = formatSub(subareas[2], "Ciências Humanas -> Educação e Sociedade");

  const numStudents = Math.max(1, maxStudents);
  const authorHeaders = Array.from(
    { length: numStudents },
    (_, idx) =>
      `autor${idx + 1}_nome;autor${idx + 1}_email;autor${idx + 1}_cpf;autor${idx + 1}_instituicao;autor${idx + 1}_camiseta`
  ).join(";");

  const header = `titulo;tipo;nivel;area_subarea;estande;ponto_energia;mesa_prototipo;resumo;orientador_nome;orientador_email;orientador_cpf;orientador_instituicao;orientador_camiseta;coorientador_nome;coorientador_email;coorientador_cpf;coorientador_instituicao;coorientador_camiseta;${authorHeaders}\r\n`;

  // Linhas de exemplo respeitando o total de colunas de autores (5 por autor: nome, email, cpf, instituicao, camiseta)
  const authorsRow1 = [
    "Lucas Almeida", "lucas.almeida@aluno.edu.br", "111.222.333-01", "IFMS Campus Três Lagoas", "M",
    "Beatriz Santos", "beatriz.santos@aluno.edu.br", "222.333.444-02", "IFMS Campus Três Lagoas", "P",
  ];
  while (authorsRow1.length < numStudents * 5) {
    authorsRow1.push("");
  }
  const row1 = `Desenvolvimento de Braço Robótico Sustentável;Tecnológico;Médio;${sub1};A-01;Sim;Sim;Protótipo robótico de baixo custo utilizando materiais recicláveis;Prof. Carlos Silva;carlos.silva@escola.edu.br;999.888.777-66;IFMS Campus Três Lagoas;G;Profa. Mariana Costa;mariana.costa@escola.edu.br;888.777.666-55;IFMS Campus Três Lagoas;M;${authorsRow1.join(";")}\r\n`;

  const authorsRow2 = [
    "Gabriel Rocha", "gabriel.rocha@aluno.edu.br", "333.444.555-03", "Escola Estadual Santos Dumont", "G",
    "Juliana Lima", "juliana.lima@aluno.edu.br", "444.555.666-04", "Escola Estadual Santos Dumont", "P",
    "Matheus Pereira", "matheus.pereira@aluno.edu.br", "555.666.777-05", "Escola Estadual Santos Dumont", "GG",
  ];
  while (authorsRow2.length < numStudents * 5) {
    authorsRow2.push("");
  }
  const row2 = `Análise da Qualidade da Água de Nascentes Urbanas;Científico;Médio;${sub2};A-02;Não;Não;Investigação físico-química e microbiológica de nascentes locais;Profa. Ana Paula Mendes;ana.mendes@escola.edu.br;777.666.555-44;Escola Estadual Santos Dumont;M;;;;;;${authorsRow2.join(";")}\r\n`;

  const authorsRow3 = [
    "Sophia Martins", "sophia.martins@aluno.edu.br", "666.777.888-06", "Colégio Objetivo", "PP",
  ];
  while (authorsRow3.length < numStudents * 5) {
    authorsRow3.push("");
  }
  const row3 = `Jogos Educativos no Ensino Fundamental;Científico;Fundamental;${sub3};B-01;Não;Sim;Uso de gamificação lúdica para ensino de matemática básica;Prof. Roberto Souza;roberto.souza@escola.edu.br;666.555.444-33;Colégio Objetivo;GG;;;;;;${authorsRow3.join(";")}\r\n`;

  return "\uFEFF" + header + row1 + row2 + row3;
}

/**
 * Dispara o download client-side do arquivo modelo CSV com BOM UTF-8.
 */
export function downloadProjectsCsvTemplate(
  eventId: number,
  subareas: SubareaSimple[],
  maxStudents: number = 5
): void {
  const content = generateProjectsCsvTemplate(subareas, maxStudents);
  const blob = new Blob([content], {
    type: "text/csv;charset=utf-8;",
  });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.setAttribute(
    "download",
    `modelo_trabalhos_easyevent_evento_${eventId}.csv`
  );
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

/**
 * Divide uma linha de CSV em colunas respeitando aspas duplas.
 */
function parseCsvLine(text: string, delimiter: string): string[] {
  const result: string[] = [];
  let curVal = "";
  let insideQuotes = false;

  for (let i = 0; i < text.length; i++) {
    const char = text[i];
    const nextChar = text[i + 1];

    if (char === '"') {
      if (insideQuotes && nextChar === '"') {
        curVal += '"';
        i++;
      } else {
        insideQuotes = !insideQuotes;
      }
    } else if (char === delimiter && !insideQuotes) {
      result.push(curVal.trim());
      curVal = "";
    } else {
      curVal += char;
    }
  }
  result.push(curVal.trim());
  return result;
}

/**
 * Detecta o delimitador mais provável em uma linha de texto.
 */
function detectDelimiter(firstLine: string): string {
  const countSemicolon = (firstLine.match(/;/g) || []).length;
  const countComma = (firstLine.match(/,/g) || []).length;
  const countTab = (firstLine.match(/\t/g) || []).length;

  if (countSemicolon >= countComma && countSemicolon >= countTab && countSemicolon > 0) {
    return ";";
  }
  if (countTab > countComma && countTab > 0) {
    return "\t";
  }
  return ",";
}

/**
 * Normaliza tipo do projeto.
 */
function parseProjectType(raw: string | undefined): ProjectType {
  const val = (raw || "").toLowerCase();
  return val.includes("tec") ? "TECHNOLOGICAL" : "SCIENTIFIC";
}

/**
 * Normaliza nível de ensino.
 */
function parseEducationLevel(raw: string | undefined): EducationLevel {
  const val = (raw || "")
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .trim();

  if (val.includes("gradua") || val.includes("superior")) return "GRADUACAO";
  if (
    val.includes("pos") ||
    val.includes("especializacao") ||
    val.includes("mestrado") ||
    val.includes("doutorado")
  ) {
    return "POS_GRADUACAO";
  }
  if (
    val.includes("jun") ||
    val.includes("fundamental 1") ||
    val.includes("fundamental i") ||
    val.includes("fund 1") ||
    val.includes("fund i")
  ) {
    return "JUNIOR";
  }
  if (
    val.includes("fundamental 2") ||
    val.includes("fundamental ii") ||
    val.includes("fund 2") ||
    val.includes("fund ii") ||
    val.includes("fund")
  ) {
    return "FUNDAMENTAL";
  }
  return "MEDIO";
}

/**
 * Normaliza texto para comparações insensíveis a maiúsculas, espaços e acentuação.
 */
function normalizeText(text: string): string {
  if (!text) return "";
  return text
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .trim();
}

/**
 * Separa a entrada em { areaName, subareaName } se contiver separadores hierárquicos ('->', '>', ':').
 */
function parseSubareaEntry(entry: string): { areaName?: string; subareaName: string } {
  for (const sep of ["->", ">", ":"]) {
    if (entry.includes(sep)) {
      const parts = entry.split(sep);
      return { areaName: parts[0].trim(), subareaName: parts[1].trim() };
    }
  }
  return { subareaName: entry.trim() };
}

/**
 * Analisa o arquivo CSV de trabalhos científicos e gera lista de pré-visualização.
 */
export function parseProjectsCsv(
  csvContent: string,
  subareas: SubareaSimple[],
  existingProjects: ProjectItem[] = []
): ParseProjectsCsvResult {
  const cleanContent = csvContent.replace(/^\uFEFF/, "");
  const lines = cleanContent
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter((l) => l.length > 0);

  if (lines.length < 2) {
    return {
      rows: [],
      totalRows: 0,
      newCount: 0,
      updateCount: 0,
      invalidCount: 0,
      hasErrors: false,
    };
  }

  const headerLine = lines[0];
  const delimiter = detectDelimiter(headerLine);
  const rawHeaders = parseCsvLine(headerLine, delimiter).map((h) =>
    h.toLowerCase().trim().replace(/[\s_-]+/g, "_")
  );

  const existingMap = new Map<string, ProjectItem>();
  for (const p of existingProjects) {
    existingMap.set(p.title.trim().toLowerCase(), p);
  }

  const compositeSubareaMap = new Map<string, SubareaSimple>();
  const subareaGroupMap = new Map<string, SubareaSimple[]>();

  for (const s of subareas) {
    const sNorm = normalizeText(s.name);
    const aNorm = normalizeText(s.area_name || "");
    if (aNorm) {
      compositeSubareaMap.set(`${aNorm}:::${sNorm}`, s);
    }
    const currentList = subareaGroupMap.get(sNorm) || [];
    currentList.push(s);
    subareaGroupMap.set(sNorm, currentList);
  }

  const rows: ParsedProjectRow[] = [];
  let newCount = 0;
  let updateCount = 0;
  let invalidCount = 0;

  for (let i = 1; i < lines.length; i++) {
    const rawCols = parseCsvLine(lines[i], delimiter);
    const lineNumber = i + 1;

    // Criar mapa chave-valor para a linha
    const rowMap: Record<string, string> = {};
    rawHeaders.forEach((header, idx) => {
      if (header) {
        rowMap[header] = rawCols[idx] || "";
      }
    });

    const title =
      rowMap["titulo"] ||
      rowMap["title"] ||
      rowMap["nome_do_trabalho"] ||
      rowMap["trabalho"] ||
      rawCols[0] ||
      "";

    const projectType = parseProjectType(
      rowMap["tipo"] || rowMap["project_type"] || rowMap["modalidade"]
    );
    const educationLevel = parseEducationLevel(
      rowMap["nivel"] || rowMap["education_level"] || rowMap["nivel_de_ensino"]
    );

    const subareaRaw =
      rowMap["area_subarea"] ||
      rowMap["area/subarea"] ||
      rowMap["area_e_subarea"] ||
      rowMap["subarea"] ||
      rowMap["sub_area"] ||
      rowMap["area"] ||
      rowMap["subarea_name"] ||
      rowMap["area_tematica"] ||
      "";

    const boothNumber =
      rowMap["estande"] ||
      rowMap["bancada"] ||
      rowMap["booth_number"] ||
      rowMap["codigo_estande"] ||
      null;

    const abstract =
      rowMap["resumo"] || rowMap["abstract"] || rowMap["descricao"] || null;

    const rawElec = (
      rowMap["ponto_energia"] ||
      rowMap["energia"] ||
      rowMap["needs_electricity"] ||
      rowMap["tomada"] ||
      ""
    )
      .toLowerCase()
      .trim();
    const needsElectricity = ["sim", "s", "true", "1", "yes", "y"].includes(rawElec);

    const rawTable = (
      rowMap["mesa_prototipo"] ||
      rowMap["mesa"] ||
      rowMap["needs_table"] ||
      rowMap["bancada"] ||
      ""
    )
      .toLowerCase()
      .trim();
    const needsTable = ["sim", "s", "true", "1", "yes", "y"].includes(rawTable);

    // Membros
    const members: ProjectBatchMemberInput[] = [];
    const errors: string[] = [];

    const VALID_TSHIRT_SIZES = ["PP", "P", "M", "G", "GG", "XG"];
    const normalizeTshirt = (val?: string) => {
      const clean = (val || "").trim().toUpperCase();
      return VALID_TSHIRT_SIZES.includes(clean) ? clean : "M";
    };

    // Orientador
    const advName =
      rowMap["orientador_nome"] ||
      rowMap["orientador"] ||
      rowMap["advisor_name"] ||
      "";
    let advEmail =
      rowMap["orientador_email"] ||
      rowMap["email_orientador"] ||
      rowMap["advisor_email"] ||
      "";
    const advCpf = (
      rowMap["orientador_cpf"] ||
      rowMap["cpf_orientador"] ||
      rowMap["advisor_cpf"] ||
      ""
    ).trim();
    const advInst = (
      rowMap["orientador_instituicao"] ||
      rowMap["orientador_afiliacao"] ||
      rowMap["instituicao_orientador"] ||
      rowMap["afiliacao_orientador"] ||
      rowMap["advisor_affiliation"] ||
      rowMap["advisor_institution"] ||
      ""
    ).trim();

    if (!advName.trim()) {
      errors.push("Nome do Orientador é obrigatório.");
    } else {
      if (!advEmail.trim()) {
        const slug = advName.toLowerCase().replace(/[^a-z0-9]/g, "");
        advEmail = `${slug}@orientador.easyevent.local`;
      }
      const advTshirt = normalizeTshirt(
        rowMap["orientador_camiseta"] ||
        rowMap["camiseta_orientador"] ||
        rowMap["orientador_tamanho"] ||
        rowMap["tamanho_orientador"]
      );
      members.push({
        name: advName.trim(),
        email: advEmail.trim(),
        cpf: advCpf || undefined,
        affiliation: advInst || undefined,
        role: "ADVISOR",
        tshirt_size: advTshirt,
      });
    }

    // Coorientador (opcional)
    const coadvName =
      rowMap["coorientador_nome"] ||
      rowMap["coorientador"] ||
      rowMap["coadvisor_name"] ||
      "";
    let coadvEmail =
      rowMap["coorientador_email"] ||
      rowMap["email_coorientador"] ||
      rowMap["coadvisor_email"] ||
      "";
    const coadvCpf = (
      rowMap["coorientador_cpf"] ||
      rowMap["cpf_coorientador"] ||
      rowMap["coadvisor_cpf"] ||
      ""
    ).trim();
    const coadvInst = (
      rowMap["coorientador_instituicao"] ||
      rowMap["coorientador_afiliacao"] ||
      rowMap["instituicao_coorientador"] ||
      rowMap["afiliacao_coorientador"] ||
      rowMap["coadvisor_affiliation"] ||
      rowMap["coadvisor_institution"] ||
      ""
    ).trim();

    if (coadvName.trim()) {
      if (!coadvEmail.trim()) {
        const slug = coadvName.toLowerCase().replace(/[^a-z0-9]/g, "");
        coadvEmail = `${slug}@coorientador.easyevent.local`;
      }
      const coadvTshirt = normalizeTshirt(
        rowMap["coorientador_camiseta"] ||
        rowMap["camiseta_coorientador"] ||
        rowMap["coorientador_tamanho"] ||
        rowMap["tamanho_coorientador"]
      );
      members.push({
        name: coadvName.trim(),
        email: coadvEmail.trim(),
        cpf: coadvCpf || undefined,
        affiliation: coadvInst || undefined,
        role: "COADVISOR",
        tshirt_size: coadvTshirt,
      });
    }

    // Autores dinâmicos (autor1 a autorN ou estudante1 a estudanteN)
    const authorHeaderKeys = rawHeaders.filter(
      (k) =>
        (k.includes("autor") || k.includes("estudante") || k.includes("aluno")) &&
        (k.includes("nome") ||
          k.endsWith("1") ||
          k.endsWith("2") ||
          k.endsWith("3") ||
          k.endsWith("4") ||
          k.endsWith("5")) &&
        !k.includes("email") &&
        !k.includes("cpf") &&
        !k.includes("instituicao") &&
        !k.includes("afiliacao") &&
        !k.includes("perfil") &&
        !k.includes("escola") &&
        !k.includes("camiseta") &&
        !k.includes("tshirt") &&
        !k.includes("tamanho") &&
        !k.includes("orientador")
    );

    // Se não encontrou colunas nomeadas, busca índices fixos autor1..autorN (até 20 autores)
    let studentCount = 0;
    for (let sIdx = 1; sIdx <= 20; sIdx++) {
      const nameKey =
        authorHeaderKeys.find(
          (k) =>
            k.includes(sIdx.toString()) ||
            k === `autor${sIdx}` ||
            k === `autor_${sIdx}` ||
            k === `estudante${sIdx}`
        ) || `autor${sIdx}_nome`;

      const sName = rowMap[nameKey] || rowMap[`autor${sIdx}`] || rowMap[`estudante${sIdx}`] || "";
      if (sName && sName.trim()) {
        const emailKey =
          rawHeaders.find(
            (k) =>
              (k.includes("email") &&
                (k.includes(sIdx.toString()) ||
                  k.includes(`autor${sIdx}`) ||
                  k.includes(`estudante${sIdx}`))) ||
              k === `autor${sIdx}_email` ||
              k === `email_autor${sIdx}`
          ) || `autor${sIdx}_email`;

        let sEmail = rowMap[emailKey] || "";
        if (!sEmail.trim()) {
          const slug = sName.toLowerCase().replace(/[^a-z0-9]/g, "");
          sEmail = `${slug}@aluno.easyevent.local`;
        }

        const cpfKey =
          rawHeaders.find(
            (k) =>
              k.includes("cpf") &&
              (k.includes(sIdx.toString()) ||
                k.includes(`autor${sIdx}`) ||
                k.includes(`estudante${sIdx}`) ||
                k.includes(`aluno${sIdx}`))
          ) || `autor${sIdx}_cpf`;

        const sCpf = (
          rowMap[cpfKey] ||
          rowMap[`autor${sIdx}_cpf`] ||
          rowMap[`aluno${sIdx}_cpf`] ||
          rowMap[`estudante${sIdx}_cpf`] ||
          rowMap[`cpf_autor${sIdx}`] ||
          rowMap[`cpf_aluno${sIdx}`] ||
          ""
        ).trim();

        const instKey =
          rawHeaders.find(
            (k) =>
              (k.includes("instituicao") ||
                k.includes("afiliacao") ||
                k.includes("perfil") ||
                k.includes("escola")) &&
              (k.includes(sIdx.toString()) ||
                k.includes(`autor${sIdx}`) ||
                k.includes(`estudante${sIdx}`) ||
                k.includes(`aluno${sIdx}`))
          ) || `autor${sIdx}_instituicao`;

        const sInst = (
          rowMap[instKey] ||
          rowMap[`autor${sIdx}_instituicao`] ||
          rowMap[`aluno${sIdx}_instituicao`] ||
          rowMap[`estudante${sIdx}_instituicao`] ||
          rowMap[`autor${sIdx}_afiliacao`] ||
          rowMap[`aluno${sIdx}_afiliacao`] ||
          rowMap[`autor${sIdx}_perfil`] ||
          rowMap[`aluno${sIdx}_perfil`] ||
          rowMap[`instituicao_autor${sIdx}`] ||
          rowMap[`instituicao_aluno${sIdx}`] ||
          ""
        ).trim();

        const tshirtKey =
          rawHeaders.find(
            (k) =>
              (k.includes("camiseta") || k.includes("tshirt") || k.includes("tamanho")) &&
              (k.includes(sIdx.toString()) ||
                k.includes(`autor${sIdx}`) ||
                k.includes(`estudante${sIdx}`) ||
                k.includes(`aluno${sIdx}`))
          ) || `autor${sIdx}_camiseta`;

        const sTshirt = normalizeTshirt(
          rowMap[tshirtKey] ||
          rowMap[`autor${sIdx}_camiseta`] ||
          rowMap[`aluno${sIdx}_camiseta`] ||
          rowMap[`estudante${sIdx}_camiseta`] ||
          rowMap[`camiseta_autor${sIdx}`] ||
          rowMap[`camiseta_aluno${sIdx}`]
        );

        const role: ProjectMemberRole =
          studentCount === 0 ? "STUDENT_LEADER" : "STUDENT_MEMBER";

        members.push({
          name: sName.trim(),
          email: sEmail.trim(),
          cpf: sCpf || undefined,
          affiliation: sInst || undefined,
          role,
          tshirt_size: sTshirt,
        });
        studentCount++;
      }
    }

    if (studentCount === 0) {
      errors.push("O trabalho deve conter pelo menos 1 autor / estudante cadastrado.");
    }

    // Validações
    if (!title.trim()) {
      errors.push("O título do trabalho é obrigatório.");
    } else if (title.trim().length < 3) {
      errors.push("O título deve ter pelo menos 3 caracteres.");
    }

    // Resolver subárea com suporte a 'Área -> Subárea' e detecção de ambiguidade
    let resolvedSubareaName = subareaRaw.trim();
    if (!resolvedSubareaName) {
      if (subareas.length > 0) {
        resolvedSubareaName = subareas[0].area_name
          ? `${subareas[0].area_name} -> ${subareas[0].name}`
          : subareas[0].name;
      } else {
        errors.push("Nenhuma subárea temática informada ou disponível.");
      }
    } else {
      const { areaName, subareaName } = parseSubareaEntry(resolvedSubareaName);
      const subNorm = normalizeText(subareaName);

      if (areaName) {
        const areaNorm = normalizeText(areaName);
        const match = compositeSubareaMap.get(`${areaNorm}:::${subNorm}`);
        if (match) {
          resolvedSubareaName = match.area_name
            ? `${match.area_name} -> ${match.name}`
            : match.name;
        } else {
          // Busca parcial de área
          const partial = subareas.find(
            (s) =>
              normalizeText(s.name) === subNorm &&
              s.area_name &&
              (normalizeText(s.area_name).includes(areaNorm) ||
                areaNorm.includes(normalizeText(s.area_name)))
          );
          if (partial) {
            resolvedSubareaName = partial.area_name
              ? `${partial.area_name} -> ${partial.name}`
              : partial.name;
          } else {
            errors.push(
              `A subárea '${subareaName}' não foi encontrada sob a grande área '${areaName}'.`
            );
          }
        }
      } else {
        // Nome simples de subárea
        const candidates = subareaGroupMap.get(subNorm) || [];
        if (candidates.length === 1) {
          const match = candidates[0];
          resolvedSubareaName = match.area_name
            ? `${match.area_name} -> ${match.name}`
            : match.name;
        } else if (candidates.length > 1) {
          const areasStr = candidates.map((c) => `'${c.area_name}'`).join(", ");
          errors.push(
            `A subárea '${subareaName}' é ambígua, pois pertence a mais de uma grande área (${areasStr}). Especifique no formato 'Área -> Subárea'.`
          );
        } else {
          // Busca parcial
          const partial = subareas.find(
            (s) =>
              normalizeText(s.name).includes(subNorm) ||
              subNorm.includes(normalizeText(s.name))
          );
          if (partial) {
            resolvedSubareaName = partial.area_name
              ? `${partial.area_name} -> ${partial.name}`
              : partial.name;
          } else {
            errors.push(
              `A subárea '${resolvedSubareaName}' não foi encontrada na feira ativa.`
            );
          }
        }
      }
    }

    const existing = existingMap.get(title.trim().toLowerCase());
    let status: "NEW" | "UPDATE" | "INVALID" = "NEW";

    if (errors.length > 0) {
      status = "INVALID";
      invalidCount++;
    } else if (existing) {
      status = "UPDATE";
      updateCount++;
    } else {
      status = "NEW";
      newCount++;
    }

    rows.push({
      line_number: lineNumber,
      title: title.trim(),
      project_type: projectType,
      education_level: educationLevel,
      subarea_name: resolvedSubareaName,
      booth_number: boothNumber ? boothNumber.trim() : null,
      abstract: abstract ? abstract.trim() : null,
      needs_electricity: needsElectricity,
      needs_table: needsTable,
      members,
      status,
      errors,
      existing_project: existing,
    });
  }

  return {
    rows,
    totalRows: rows.length,
    newCount,
    updateCount,
    invalidCount,
    hasErrors: invalidCount > 0,
  };
}
