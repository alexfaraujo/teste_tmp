import {
  EducationLevel,
  ParsedParticipantRow,
  ParseParticipantsCsvResult,
  ParticipantItem,
  UserRole,
} from "../types";

export interface SubareaSimple {
  id: number;
  name: string;
  area_name?: string;
}

/**
 * Gera conteúdo CSV em UTF-8 com BOM e exemplos didáticos baseados nas subáreas da feira ativa.
 */
export function generateParticipantsCsvTemplate(subareas: SubareaSimple[]): string {
  const sub1 = subareas[0]
    ? subareas[0].area_name
      ? `${subareas[0].area_name} -> ${subareas[0].name}`
      : subareas[0].name
    : "Ciências Exatas e da Terra -> Informática";
  const sub2 = subareas[1]
    ? subareas[1].area_name
      ? `${subareas[1].area_name} -> ${subareas[1].name}`
      : subareas[1].name
    : "Engenharias -> Robótica e Automação";

  const header =
    "nome;email;papeis;cpf;afiliacao;tamanho_camiseta;subareas;niveis_ensino\r\n";
  const row1 =
    "Mariana Silva Santos;mariana.santos@estudante.edu.br;Estudante;123.456.789-01;IFMS Campus Três Lagoas;P;;\r\n";
  const row2 =
    "Prof. Carlos Eduardo Lima;carlos.lima@escola.edu.br;Orientador;234.567.890-12;Escola Estadual Santos Dumont;G;;\r\n";
  const row3 = `Profa. Ana Paula Mendes;ana.mendes@escola.edu.br;"Orientador, Avaliador";345.678.901-23;IFMS Campus Três Lagoas;M;"${sub1}, ${sub2}";"Médio, Fundamental II"\r\n`;
  const row4 = `Dr. Roberto Souza;roberto.souza@universidade.br;Avaliador;456.789.012-34;UFMS;GG;${sub1};"Graduação, Pós-Graduação"\r\n`;
  const row5 = `Dra. Juliana Ferreira;juliana.ferreira@pesquisa.br;Avaliador;567.890.123-45;Embrapa;M;${sub2};"Fundamental I, Fundamental II, Médio"\r\n`;

  return "\uFEFF" + header + row1 + row2 + row3 + row4 + row5;
}

/**
 * Dispara o download client-side do arquivo modelo CSV com BOM UTF-8.
 */
export function downloadParticipantsCsvTemplate(
  eventId: number,
  subareas: SubareaSimple[] = []
): void {
  const content = generateParticipantsCsvTemplate(subareas);
  const blob = new Blob([content], {
    type: "text/csv;charset=utf-8;",
  });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.setAttribute(
    "download",
    `modelo_participantes_easyevent_evento_${eventId}.csv`
  );
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

/**
 * Divide uma linha de CSV em colunas respeitando aspas duplas.
 */
function parseCsvLine(text: string, delimiter: string): string[] {
  const result: string[] = [];
  let curVal = "";
  let insideQuotes = false;

  for (let i = 0; i < text.length; i++) {
    const char = text[i];
    const nextChar = text[i + 1];

    if (char === '"') {
      if (insideQuotes && nextChar === '"') {
        curVal += '"';
        i++;
      } else {
        insideQuotes = !insideQuotes;
      }
    } else if (char === delimiter && !insideQuotes) {
      result.push(curVal.trim());
      curVal = "";
    } else {
      curVal += char;
    }
  }
  result.push(curVal.trim());
  return result;
}

/**
 * Detecta o delimitador mais provável em uma linha de texto.
 */
function detectDelimiter(firstLine: string): string {
  const countSemicolon = (firstLine.match(/;/g) || []).length;
  const countComma = (firstLine.match(/,/g) || []).length;
  const countTab = (firstLine.match(/\t/g) || []).length;

  if (countTab > countSemicolon && countTab > countComma) return "\t";
  if (countComma > countSemicolon) return ",";
  return ";";
}

/**
 * Mapeia texto para papéis reconhecidos do sistema.
 */
function parseRoles(raw: string): UserRole[] {
  if (!raw || !raw.trim()) return ["STUDENT"];

  const parts = raw
    .split(/[,;/]/)
    .map((p) => p.trim())
    .filter(Boolean);

  const roles: UserRole[] = [];

  for (const p of parts) {
    const norm = p
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "");

    if (norm.includes("estudante") || norm.includes("aluno") || norm === "student") {
      if (!roles.includes("STUDENT")) roles.push("STUDENT");
    } else if (norm.includes("coorientador") || norm === "coadvisor") {
      if (!roles.includes("COADVISOR")) roles.push("COADVISOR");
    } else if (norm.includes("orientador") || norm === "advisor") {
      if (!roles.includes("ADVISOR")) roles.push("ADVISOR");
    } else if (norm.includes("avaliador") || norm === "evaluator") {
      if (!roles.includes("EVALUATOR")) roles.push("EVALUATOR");
    }
  }

  return roles.length > 0 ? roles : ["STUDENT"];
}

/**
 * Mapeia texto para níveis de ensino reconhecidos.
 */
function parseEducationLevels(raw: string): EducationLevel[] {
  if (!raw || !raw.trim()) return [];

  const parts = raw
    .split(/[,;/]/)
    .map((p) => p.trim())
    .filter(Boolean);

  const levels: EducationLevel[] = [];

  for (const p of parts) {
    const norm = p
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .trim();

    if (norm.includes("gradua") || norm.includes("superior")) {
      if (!levels.includes("GRADUACAO")) levels.push("GRADUACAO");
    } else if (
      norm.includes("pos") ||
      norm.includes("especializacao") ||
      norm.includes("mestrado") ||
      norm.includes("doutorado")
    ) {
      if (!levels.includes("POS_GRADUACAO")) levels.push("POS_GRADUACAO");
    } else if (
      norm.includes("junior") ||
      norm.includes("fundamental 1") ||
      norm.includes("fundamental i") ||
      norm.includes("fund 1") ||
      norm.includes("fund i")
    ) {
      if (!levels.includes("JUNIOR")) levels.push("JUNIOR");
    } else if (
      norm.includes("fundamental 2") ||
      norm.includes("fundamental ii") ||
      norm.includes("fund 2") ||
      norm.includes("fund ii") ||
      norm.includes("fundamental")
    ) {
      if (!levels.includes("FUNDAMENTAL")) levels.push("FUNDAMENTAL");
    } else if (norm.includes("medio") || norm.includes("tecnico")) {
      if (!levels.includes("MEDIO")) levels.push("MEDIO");
    }
  }

  return levels;
}

/**
 * Validação simplificada de e-mail.
 */
function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

/**
 * Normaliza texto para comparações insensíveis a maiúsculas, espaços e acentuação.
 */
function normalizeText(text: string): string {
  if (!text) return "";
  return text
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .trim();
}

/**
 * Separa a entrada em { areaName, subareaName } se contiver separadores hierárquicos ('->', '>', ':').
 */
function parseSubareaEntry(entry: string): { areaName?: string; subareaName: string } {
  for (const sep of ["->", ">", ":"]) {
    if (entry.includes(sep)) {
      const parts = entry.split(sep);
      return { areaName: parts[0].trim(), subareaName: parts[1].trim() };
    }
  }
  return { subareaName: entry.trim() };
}

/**
 * Processa e valida o conteúdo de um arquivo CSV de participantes.
 */
export function parseParticipantsCsv(
  csvContent: string,
  subareas: SubareaSimple[] = [],
  existingParticipants: ParticipantItem[] = []
): ParseParticipantsCsvResult {
  const cleanContent = csvContent.replace(/^\uFEFF/, "");
  const lines = cleanContent
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean);

  if (lines.length === 0) {
    return {
      rows: [],
      totalRows: 0,
      newCount: 0,
      updateCount: 0,
      evaluatorsCount: 0,
      invalidCount: 0,
      hasErrors: false,
    };
  }

  const delimiter = detectDelimiter(lines[0]);
  const headerCols = parseCsvLine(lines[0], delimiter).map((col) =>
    col
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-z0-9_]/g, "")
  );

  const getColIndex = (aliases: string[]) => {
    return headerCols.findIndex((col) =>
      aliases.some((alias) => col === alias || col.includes(alias))
    );
  };

  const nameIdx = getColIndex(["nome", "name", "participante"]);
  const emailIdx = getColIndex(["email", "e_mail", "correio"]);
  const rolesIdx = getColIndex(["papeis", "papel", "funcao", "funcoes", "roles", "role"]);
  const cpfIdx = getColIndex(["cpf", "documento"]);
  const affilIdx = getColIndex(["afiliacao", "instituicao", "escola", "campus", "affiliation"]);
  const tshirtIdx = getColIndex(["camiseta", "tamanho_camiseta", "tshirt", "tamanho"]);
  const subareasIdx = getColIndex(["subareas", "subarea", "areas", "especialidade"]);
  const levelsIdx = getColIndex(["niveis_ensino", "niveis", "nivel", "education_levels"]);

  const existingEmailMap = new Map<string, ParticipantItem>();
  for (const p of existingParticipants) {
    if (p.email) existingEmailMap.set(p.email.toLowerCase().trim(), p);
  }

  const compositeSubareaMap = new Map<string, SubareaSimple>();
  const subareaGroupMap = new Map<string, SubareaSimple[]>();

  for (const s of subareas) {
    const sNorm = normalizeText(s.name);
    const aNorm = normalizeText(s.area_name || "");
    if (aNorm) {
      compositeSubareaMap.set(`${aNorm}:::${sNorm}`, s);
    }
    const currentList = subareaGroupMap.get(sNorm) || [];
    currentList.push(s);
    subareaGroupMap.set(sNorm, currentList);
  }

  const parsedRows: ParsedParticipantRow[] = [];
  let newCount = 0;
  let updateCount = 0;
  let evaluatorsCount = 0;
  let invalidCount = 0;

  for (let i = 1; i < lines.length; i++) {
    const rawLine = lines[i];
    if (!rawLine) continue;

    const cols = parseCsvLine(rawLine, delimiter);
    const errors: string[] = [];
    const warnings: string[] = [];

    const name = nameIdx >= 0 && cols[nameIdx] ? cols[nameIdx].trim() : "";
    const email = emailIdx >= 0 && cols[emailIdx] ? cols[emailIdx].trim().toLowerCase() : "";
    const rolesRaw = rolesIdx >= 0 && cols[rolesIdx] ? cols[rolesIdx].trim() : "";
    const cpf = cpfIdx >= 0 && cols[cpfIdx] ? cols[cpfIdx].trim() : undefined;
    const affiliation = affilIdx >= 0 && cols[affilIdx] ? cols[affilIdx].trim() : undefined;
    const tshirtRaw = tshirtIdx >= 0 && cols[tshirtIdx] ? cols[tshirtIdx].trim().toUpperCase() : "M";
    const subareasRaw = subareasIdx >= 0 && cols[subareasIdx] ? cols[subareasIdx].trim() : "";
    const levelsRaw = levelsIdx >= 0 && cols[levelsIdx] ? cols[levelsIdx].trim() : "";

    // Validações
    if (!name || name.length < 2) {
      errors.push("Nome é obrigatório (mínimo 2 caracteres).");
    }

    if (!email) {
      errors.push("E-mail é obrigatório.");
    } else if (!isValidEmail(email)) {
      errors.push(`E-mail inválido: '${email}'.`);
    }

    const roles = parseRoles(rolesRaw);
    const isEvaluator = roles.includes("EVALUATOR");
    if (isEvaluator) evaluatorsCount++;

    // Validação de camiseta
    const validSizes = ["PP", "P", "M", "G", "GG", "XGG"];
    const tshirt_size = validSizes.includes(tshirtRaw) ? tshirtRaw : "M";

    // Validação e resolução de subáreas
    const matchedSubareas: string[] = [];
    if (subareasRaw) {
      const rawSubNames = subareasRaw
        .split(/[,;/]/)
        .map((s) => s.trim())
        .filter(Boolean);

      for (const sEntry of rawSubNames) {
        const { areaName, subareaName } = parseSubareaEntry(sEntry);
        const subNorm = normalizeText(subareaName);

        if (areaName) {
          const areaNorm = normalizeText(areaName);
          const compKey = `${areaNorm}:::${subNorm}`;
          const found = compositeSubareaMap.get(compKey);
          if (found) {
            const label = found.area_name ? `${found.area_name} -> ${found.name}` : found.name;
            if (!matchedSubareas.includes(label)) {
              matchedSubareas.push(label);
            }
          } else {
            // Tentar busca parcial de área
            const partial = subareas.find(
              (s) =>
                (normalizeText(s.area_name || "").includes(areaNorm) ||
                  areaNorm.includes(normalizeText(s.area_name || ""))) &&
                normalizeText(s.name) === subNorm
            );
            if (partial) {
              const label = partial.area_name ? `${partial.area_name} -> ${partial.name}` : partial.name;
              if (!matchedSubareas.includes(label)) {
                matchedSubareas.push(label);
              }
            } else {
              warnings.push(`Subárea '${subareaName}' da área '${areaName}' não encontrada na feira ativa.`);
            }
          }
        } else {
          // Busca simples por nome da subárea
          const matches = subareaGroupMap.get(subNorm) || [];
          if (matches.length === 1) {
            const found = matches[0];
            const label = found.area_name ? `${found.area_name} -> ${found.name}` : found.name;
            if (!matchedSubareas.includes(label)) {
              matchedSubareas.push(label);
            }
          } else if (matches.length > 1) {
            const areasList = matches.map((m) => `'${m.area_name}'`).join(", ");
            errors.push(
              `A subárea '${subareaName}' é ambígua, pois pertence a mais de uma grande área (${areasList}). Especifique no formato 'Área -> Subárea'.`
            );
          } else {
            warnings.push(`Subárea '${subareaName}' não encontrada na feira ativa.`);
          }
        }
      }
    }

    // Níveis de ensino
    const education_levels = parseEducationLevels(levelsRaw);

    const isExisting = existingEmailMap.has(email);
    if (isExisting) {
      updateCount++;
    } else {
      newCount++;
    }

    const isValid = errors.length === 0;
    if (!isValid) invalidCount++;

    parsedRows.push({
      rowNumber: i + 1,
      name,
      email,
      roles,
      cpf: cpf || undefined,
      affiliation: affiliation || undefined,
      tshirt_size,
      subareas: matchedSubareas,
      education_levels,
      isValid,
      errors,
      warnings,
      isExisting,
    });
  }

  return {
    rows: parsedRows,
    totalRows: parsedRows.length,
    newCount,
    updateCount,
    evaluatorsCount,
    invalidCount,
    hasErrors: invalidCount > 0,
  };
}
