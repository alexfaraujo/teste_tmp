import { EvaluationCriterion, EvaluationCriterionBatchItem, ParsedCriterionRow } from "../types";

/**
 * Conteúdo esqueleto oficial de critérios de avaliação para o EasyEvent.
 * Inclui cabeçalho e exemplos didáticos com formulações duais e unificadas.
 */
export const CRITERIA_CSV_TEMPLATE = `\uFEFFnome;pergunta_unica;descricao_cientifica;descricao_tecnologica;nota_maxima;peso
Critério 1: Rigor Metodológico e Condução da Pesquisa;;Como a equipe formulou a hipótese científica, conduziu os testes experimentais e controlou variáveis?;Como a equipe definiu a demanda técnica, concebeu a arquitetura do protótipo e testou o funcionamento?;10,0;1,5
Critério 2: Relevância, Criatividade e Impacto Social;;Qual o grau de originalidade, impacto social e aplicabilidade prática da pesquisa desenvolvida?;Qual o grau de inovação da tecnologia proposta e seu potencial de solução do problema real?;10,0;1,0
Critério 3: Postura, Clareza e Domínio na Apresentação;Como os estudantes apresentaram o trabalho no estande, demonstrando clareza, articulação técnica e domínio do assunto?;;;10,0;1,0
`;

/**
 * Dispara o download client-side do arquivo modelo CSV com BOM UTF-8.
 */
export function downloadCriteriaCsvTemplate(eventId?: number): void {
  const blob = new Blob([CRITERIA_CSV_TEMPLATE], {
    type: "text/csv;charset=utf-8;",
  });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.setAttribute(
    "download",
    eventId ? `modelo_criterios_easyevent_evento_${eventId}.csv` : "modelo_criterios_easyevent.csv"
  );
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

/**
 * Divide uma linha de CSV em colunas respeitando aspas duplas.
 */
function parseCsvLine(text: string, delimiter: string): string[] {
  const result: string[] = [];
  let curVal = "";
  let insideQuotes = false;

  for (let i = 0; i < text.length; i++) {
    const char = text[i];
    const nextChar = text[i + 1];

    if (char === '"') {
      if (insideQuotes && nextChar === '"') {
        curVal += '"';
        i++;
      } else {
        insideQuotes = !insideQuotes;
      }
    } else if (char === delimiter && !insideQuotes) {
      result.push(curVal.trim());
      curVal = "";
    } else {
      curVal += char;
    }
  }
  result.push(curVal.trim());
  return result;
}

/**
 * Detecta o delimitador mais provável em uma linha de texto.
 */
function detectDelimiter(firstLine: string): string {
  const countSemicolon = (firstLine.match(/;/g) || []).length;
  const countComma = (firstLine.match(/,/g) || []).length;
  const countTab = (firstLine.match(/\t/g) || []).length;

  if (countSemicolon >= countComma && countSemicolon >= countTab && countSemicolon > 0) {
    return ";";
  }
  if (countTab > countComma && countTab > 0) {
    return "\t";
  }
  return ",";
}

/**
 * Converte string com vírgula ou ponto para número float.
 */
function parseNumber(value: string | undefined, defaultValue: number): number {
  if (!value || !value.trim()) return defaultValue;
  const normalized = value.trim().replace(",", ".");
  const num = parseFloat(normalized);
  return isNaN(num) ? defaultValue : num;
}

export interface ParseCriteriaCsvResult {
  rows: ParsedCriterionRow[];
  totalRows: number;
  newCount: number;
  updateCount: number;
  invalidCount: number;
  hasErrors: boolean;
}

/**
 * Analisa o conteúdo CSV recebido, compara com critérios existentes e gera lista de pré-visualização.
 */
export function parseCriteriaCsv(
  csvContent: string,
  existingCriteria: EvaluationCriterion[] = []
): ParseCriteriaCsvResult {
  // Limpar BOM UTF-8 se presente
  const cleanContent = csvContent.replace(/^\uFEFF/, "");
  const lines = cleanContent
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter((l) => l.length > 0);

  if (lines.length < 2) {
    return {
      rows: [],
      totalRows: 0,
      newCount: 0,
      updateCount: 0,
      invalidCount: 0,
      hasErrors: false,
    };
  }

  const headerLine = lines[0];
  const delimiter = detectDelimiter(headerLine);
  const rawHeaders = parseCsvLine(headerLine, delimiter).map((h) =>
    h.toLowerCase().trim().replace(/[\s_-]+/g, "_")
  );

  // Mapeamento de índices das colunas
  const getColIndex = (aliases: string[]) => {
    return rawHeaders.findIndex((h) => aliases.some((a) => h === a || h.includes(a)));
  };

  const nameIdx = getColIndex(["nome", "name", "criterio", "titulo"]);
  const singleIdx = getColIndex(["pergunta_unica", "pergunta", "questao", "single"]);
  const sciIdx = getColIndex(["descricao_cientifica", "cientifico", "scientific", "cientifica"]);
  const techIdx = getColIndex(["descricao_tecnologica", "tecnologico", "technological", "tecnologica"]);
  const maxScoreIdx = getColIndex(["nota_maxima", "max_score", "nota_max", "pontuacao_maxima", "nota"]);
  const weightIdx = getColIndex(["peso", "weight"]);

  const existingMap = new Map<string, EvaluationCriterion>();
  for (const c of existingCriteria) {
    existingMap.set(c.name.trim().toLowerCase(), c);
  }

  const rows: ParsedCriterionRow[] = [];
  let newCount = 0;
  let updateCount = 0;
  let invalidCount = 0;

  for (let i = 1; i < lines.length; i++) {
    const rawCols = parseCsvLine(lines[i], delimiter);
    const lineNumber = i + 1;

    const name = (nameIdx >= 0 ? rawCols[nameIdx] : rawCols[0]) || "";
    const perguntaUnica = singleIdx >= 0 ? rawCols[singleIdx] : "";
    const sciDesc = sciIdx >= 0 ? rawCols[sciIdx] : "";
    const techDesc = techIdx >= 0 ? rawCols[techIdx] : "";
    const maxScore = parseNumber(maxScoreIdx >= 0 ? rawCols[maxScoreIdx] : undefined, 10.0);
    const weight = parseNumber(weightIdx >= 0 ? rawCols[weightIdx] : undefined, 1.0);

    const errors: string[] = [];

    if (!name.trim()) {
      errors.push("Nome do critério é obrigatório.");
    } else if (name.trim().length < 2) {
      errors.push("Nome deve ter ao menos 2 caracteres.");
    }

    const hasQuestion = Boolean(
      perguntaUnica.trim() || sciDesc.trim() || techDesc.trim()
    );
    if (!hasQuestion) {
      errors.push("É obrigatório informar ao menos uma pergunta/formulação para o critério.");
    }

    if (maxScore <= 0 || maxScore > 100) {
      errors.push("A nota máxima deve ser entre 1.0 e 100.0.");
    }

    if (weight <= 0 || weight > 10) {
      errors.push("O peso deve ser entre 0.1 e 10.0.");
    }

    const existing = existingMap.get(name.trim().toLowerCase());
    let status: "NEW" | "UPDATE" | "INVALID" = "NEW";

    if (errors.length > 0) {
      status = "INVALID";
      invalidCount++;
    } else if (existing) {
      status = "UPDATE";
      updateCount++;
    } else {
      status = "NEW";
      newCount++;
    }

    rows.push({
      line_number: lineNumber,
      name: name.trim(),
      pergunta_unica: perguntaUnica.trim() || null,
      scientific_description: sciDesc.trim() || null,
      technological_description: techDesc.trim() || null,
      max_score: maxScore,
      weight: weight,
      status,
      errors,
      existing_criterion: existing,
    });
  }

  return {
    rows,
    totalRows: rows.length,
    newCount,
    updateCount,
    invalidCount,
    hasErrors: invalidCount > 0,
  };
}
