#!/usr/bin/env bash
# ==============================================================================
# EasyEvent Frontend Admin — Script de Inicialização Individual
# ==============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "${SCRIPT_DIR}"

echo "============================================================"
echo "🚀 EasyEvent — Inicializando Frontend Admin (Next.js)"
echo "============================================================"

# 1. Garantir caminhos padrão do Homebrew no PATH (macOS Apple Silicon e Intel)
for brew_bin in "/opt/homebrew/bin" "/usr/local/bin"; do
    if [ -d "$brew_bin" ] && [[ ":$PATH:" != *":$brew_bin:"* ]]; then
        export PATH="$brew_bin:$PATH"
    fi
done

# 2. Checagem e Instalação Automatizada do Node.js
if ! command -v node &> /dev/null; then
    echo "⚠️  Node.js não encontrado no PATH. Tentando instalar via Homebrew..."
    if [ -x "/opt/homebrew/bin/brew" ]; then
        /opt/homebrew/bin/brew install node
        export PATH="/opt/homebrew/bin:$PATH"
    elif command -v brew &> /dev/null; then
        brew install node
    else
        echo "❌ Erro: Gerenciador de pacotes Homebrew não encontrado para instalar Node.js."
        echo "Instale o Node.js 18+ manualmente para prosseguir."
        exit 1
    fi
fi

NODE_VER=$(node -v)
echo "ℹ️  Node.js detectado: ${NODE_VER}"

# 3. Verificação do arquivo .env.local
if [ ! -f ".env.local" ]; then
    echo "⚠️  Arquivo .env.local não encontrado. Copiando de .env.example..."
    cp .env.example .env.local
    echo "✅ Arquivo .env.local criado com sucesso."
fi

# 4. Instalação de dependências npm caso necessário
if [ ! -d "node_modules" ]; then
    echo "📥 Instalando dependências npm do Frontend Admin..."
    npm install
fi

# 5. Execução do Servidor Next.js (Porta configurável: padrão 3001)
# Para alterar a porta, modifique o valor 3001 abaixo ou execute: PORT=8080 ./run.sh
PORT=${PORT:-3001}
echo "🌐 Iniciando servidor Next.js em http://localhost:${PORT}"
echo "🛑 Pressione Ctrl+C para encerrar o Frontend Admin."
echo "============================================================"

if [ "${1:-}" = "--prod" ] || [ "${NODE_ENV:-}" = "production" ]; then
    echo "🏗️  Iniciando em modo PRODUÇÃO (next build & next start)..."
    npm run build
    exec npm run start -- -p "${PORT}"
else
    exec npm run dev -- -p "${PORT}"
fi
