# FECITEL — Painel do Administrador do Evento

<p align="center">
  <img src="https://img.shields.io/badge/Next.js-14+-000000?style=for-the-badge&logo=nextdotjs&logoColor=white" alt="Next.js 14+" />
  <img src="https://img.shields.io/badge/React-18+-61DAFB?style=for-the-badge&logo=react&logoColor=black" alt="React 18+" />
  <img src="https://img.shields.io/badge/TypeScript-5+-3178C6?style=for-the-badge&logo=typescript&logoColor=white" alt="TypeScript 5+" />
  <img src="https://img.shields.io/badge/Tailwind_CSS-3.4+-06B6D4?style=for-the-badge&logo=tailwindcss&logoColor=white" alt="Tailwind CSS" />
  <img src="https://img.shields.io/badge/Lucide_Icons-Modern-F38020?style=for-the-badge&logo=feather&logoColor=white" alt="Lucide Icons" />
  <img src="https://img.shields.io/badge/Axios-HTTP%20Client-5A29E4?style=for-the-badge&logo=axios&logoColor=white" alt="Axios" />
</p>

---

## 1. Visão Geral do Módulo

O **`apps/frontend-admin`** é a aplicação web de controle e governança do ecossistema **FECITEL**, voltada para coordenadores da feira, comissão científica e equipe de recepção/credenciamento. 

Projetada com design responsivo otimizado para **Desktop e Tablets**, a aplicação oferece ferramentas completas para a gestão do ciclo de vida das feiras científicas com alta produtividade, suporte a leitores de código de barras USB/Bluetooth e interface limpa com tema claro/escuro.

### Principais Responsabilidades:
*   **Gestão de Edições do Evento e Seleção Ativa (Regra BR-19):** Configuração de datas de abertura, encerramento com trava temporal automática (BR-02), regras de submissão de arquivos e seleção mandatória da **edição ativa** que governa todo o painel e libera o acesso aos módulos dependentes via `<RequireActiveEvent>`. Inclui busca textual com debounce de 300ms.
*   **Paginação Real Obrigatória em Listagens (Regra BR-18):** Padrão universal de 15 itens por página com navegação server-side, faixas informativas (*"Exibindo X a Y de Z registros"*) e paginação por offset/limit no banco.
*   **Gestão de Trabalhos Científicos e Homologação (Fase 3):** Listagem paginada e filtrada por status, nível de ensino e subárea temática; homologação (deferimento) condicionada à anuência formal do orientador (BR-05/BR-06); indeferimento com registro obrigatório de justificativa (`rejection_reason`); alocação ou remanejamento ágil de bancadas/estandes (BR-08).
*   **CRUD de Áreas e Subáreas do Conhecimento (Regra BR-16):** Cadastro e manutenção da estrutura temática da feira vinculada à edição ativa, com proteção contra exclusão de subáreas com vínculos e reativação automática de registros em soft delete sem erro 400.
*   **Diretrizes de Interface e Qualidade (Regras UX-01 e DEV-01):** Mensagens de alerta e validação posicionadas diretamente **dentro** das janelas modais (evitando ficarem ocultas atrás da janela) e diretiva `"use client";` mandatória na primeira linha de componentes interativos para prevenção de telas em branco.
*   **CRUD de Premiações e Vínculo com Critérios:** Cadastro de prêmios especiais e associação direta a perguntas da ficha de avaliação para apuração automática.
*   **Mesa de Credenciamento e Logística:** Recepção ágil com foco contínuo para leitor de código de barras e controle de entrega de kits sem duplicidade.
*   **Alocação de Avaliadores e Apuração Final:** Gestão de avaliadores por subárea, supervisão da alocação balanceada (delta $\le 1$) e painel de resultados com sigilo de notas.

---

## 2. Tecnologias e Dependências Principais

| Tecnologia | Versão | Finalidade |
| :--- | :--- | :--- |
| **Next.js** | `14+ (App Router)` | Framework React moderno com Server Components e roteamento otimizado |
| **React** | `18+` | Biblioteca para construção da interface declarativa |
| **TypeScript** | `5+` | Tipagem estática rigorosa para componentes, contratos de API e modelos |
| **Tailwind CSS** | `3.4+` | Framework de estilização utilitária com Design System institucional |
| **Lucide React** | `0.350+` | Conjunto elegante e consistente de ícones vetoriais |
| **Axios** | `1.6+` | Cliente HTTP assíncrono com interceptors para envio de JWT Bearer |
| **clsx / tailwind-merge**| `2.0+` | Utilitários para concatenação dinâmica e segura de classes CSS |

---

## 3. Arquitetura e Organização de Diretórios

```
apps/frontend-admin/
├── src/
│   ├── app/                     # Next.js App Router
│   │   ├── (auth)/
│   │   │   └── login/           # Tela de autenticação administrativa com email/senha
│   │   ├── (dashboard)/
│   │   │   ├── page.tsx         # Dashboard geral (gated por RequireActiveEvent)
│   │   │   ├── events/          # Gestão de edições do evento (Seleção ativa BR-19, Paginação BR-18)
│   │   │   ├── areas/           # CRUD de áreas e subáreas do conhecimento (BR-16)
│   │   │   ├── awards/          # CRUD de premiações e vínculos de critérios (BR-17)
│   │   │   ├── projects/        # Homologação documental, bancadas e listagem de projetos (Fase 3)
│   │   │   ├── evaluators/      # Gestão e alocação de avaliadores presenciais
│   │   │   ├── logistics/       # Mesa de credenciamento (bipagem de crachá e kits)
│   │   │   ├── results/         # Apuração de notas, médias e classificação oficial
│   │   │   └── layout.tsx       # Layout com EventProvider, barra superior e menu lateral limpo
│   │   ├── globals.css          # Estilos globais e variáveis de tema claro/escuro
│   │   └── layout.tsx           # Root layout HTML com fontes e provedores
│   ├── components/
│   │   ├── common/              # Componentes de controle e guarda (RequireActiveEvent)
│   │   ├── ui/                  # Componentes reutilizáveis (Button, Input, Modal, Pagination, Badge)
│   │   ├── layout/              # Navbar, Sidebar, ThemeToggle com indicação da edição ativa
│   │   ├── forms/               # Formulários tipados de áreas, prêmios e eventos
│   │   └── logistics/           # Componente de leitura contínua de código de barras
│   ├── context/                 # Contextos globais (EventContext para edição ativa persistente)
│   ├── services/                # Chamadas HTTP tipadas (event, area, project, dashboard, auth)
│   └── types/                   # Definições TypeScript correspondentes aos schemas backend
├── public/                      # Imagens, logos do IFMS e assets visuais
├── .env.example                 # Modelo das variáveis de ambiente do frontend admin
├── package.json                 # Manifesto de dependências e scripts npm
├── tailwind.config.ts           # Configuração de paleta de cores (Azul Safira / Teal)
├── tsconfig.json                # Configurações do compilador TypeScript
└── README.md                    # Esta documentação
```

---

## 4. Variáveis de Ambiente (`.env.local`)

Copie o modelo para criar seu arquivo local:
```bash
cp .env.example .env.local
```

| Variável | Valor Padrão / Exemplo | Descrição |
| :--- | :--- | :--- |
| `NEXT_PUBLIC_API_URL` | `http://localhost:8000/api/v1` | URL base da API FastAPI central |
| `NEXT_PUBLIC_APP_NAME` | `FECITEL — Painel Administrativo` | Título oficial da aplicação |
| `PORT` | `3001` | Porta local de execução do servidor Next.js |

---

## 5. Como Executar

```bash
# 1. Instalar dependências
npm install

# 2. Iniciar em modo de desenvolvimento na porta 3001
npm run dev -- -p 3001
```

O painel estará disponível em: [`http://localhost:3001`](http://localhost:3001)

---

## 6. Rotas Principais da Aplicação

| Rota | Descrição da Tela | Público / Acesso |
| :--- | :--- | :--- |
| `/login` | Acesso com credenciais de Administrador | Público |
| `/events` | Painel de controle de edições e parâmetros do evento | `ADMIN` |
| `/areas` | CRUD completo de Áreas e Subáreas do Conhecimento | `ADMIN` |
| `/awards` | CRUD de Premiações e associação de perguntas da ficha | `ADMIN` |
| `/projects` | Homologação de trabalhos e consulta de anuências | `ADMIN` |
| `/logistics` | Mesa de credenciamento e baixa de kits de participantes | `ADMIN` / Recepção |
| `/evaluators` | Distribuição automática e remanejamento manual | `ADMIN` |
| `/results` | Apuração de notas, médias simples e vencedores por prêmio | `ADMIN` |
