# EasyEvent — Sistema de Gestão e Avaliação de Feiras e Eventos Científicos

<p align="center">
  <img src="https://img.shields.io/badge/FastAPI-0.110+-009688?style=for-the-badge&logo=fastapi&logoColor=white" alt="FastAPI" />
  <img src="https://img.shields.io/badge/Python-3.11+-3776AB?style=for-the-badge&logo=python&logoColor=white" alt="Python 3.11+" />
  <img src="https://img.shields.io/badge/PostgreSQL-15+-4169E1?style=for-the-badge&logo=postgresql&logoColor=white" alt="PostgreSQL 15+" />
  <img src="https://img.shields.io/badge/Next.js-14+-000000?style=for-the-badge&logo=nextdotjs&logoColor=white" alt="Next.js 14+" />
  <img src="https://img.shields.io/badge/TypeScript-5+-3178C6?style=for-the-badge&logo=typescript&logoColor=white" alt="TypeScript 5+" />
  <img src="https://img.shields.io/badge/Tailwind_CSS-3.4+-06B6D4?style=for-the-badge&logo=tailwindcss&logoColor=white" alt="Tailwind CSS" />
  <img src="https://img.shields.io/badge/PWA-Mobile--First-5A0FC8?style=for-the-badge&logo=pwa&logoColor=white" alt="PWA Ready" />
  <img src="https://img.shields.io/badge/Shell_Script-Automated-4EAA25?style=for-the-badge&logo=gnubash&logoColor=white" alt="Shell Automation" />
  <img src="https://img.shields.io/badge/Architecture-Bare--Metal%20Monorepo-FF6B6B?style=for-the-badge&logo=diagram-next&logoColor=white" alt="Bare Metal Monorepo" />
</p>

<p align="center">
  <strong>Sistema integrado e desacoplado para gestão de etapas, homologação, credenciamento com crachás de duplo código, avaliação presencial por QR Code e painel de telão público em tempo real.</strong>
</p>

---

## 1. Visão Geral da Arquitetura

O projeto adota uma arquitetura em **Monorepo Desacoplado** dividido em 4 blocos funcionais especializados:

*   **[`apps/backend/`](apps/backend/README.md)**: API Central em **Python 3.11+**, construída com **FastAPI**, **SQLAlchemy 2.0 (assíncrono)** e **Pydantic v2**, conectada diretamente a uma instância local nativa de **PostgreSQL 15+** via driver assíncrono `asyncpg`.
*   **[`apps/frontend-admin/`](apps/frontend-admin/README.md)**: Painel de Controle do Administrador do Evento (**Next.js 14+ / TypeScript / Tailwind CSS**) para seleção mandatória da edição ativa de gerenciamento (BR-19), paginação real server-side de 15 itens (BR-18), gestão de etapas, importação de alunos via SUAP, homologação, gestão de áreas/subáreas, cadastro de prêmios, mesa de credenciamento e apuração oficial.
*   **[`apps/frontend-evaluator/`](apps/frontend-evaluator/README.md)**: Aplicação Web **Mobile-First (PWA)** voltada a avaliadores presenciais, com leitor de QR Code de estande pela câmera do smartphone, ajuste tátil de notas por botões numéricos (`+`/`-`) e parecer consolidado único.
*   **[`apps/frontend-kiosk/`](apps/frontend-kiosk/README.md)**: Painel de exibição contínua para **Smart TVs e Telões** de auditórios/corredores (resoluções 1080p e 4K, dark mode nativo e métricas agregadas sob sigilo absoluto de notas parciais e ranqueamento).

```
easyevent-monorepo/
├── .agents/                         # Regras de governança, idiomas e negócios
├── docs/                            # Especificações, arquitetura, banco e histórico
├── scripts/                         # Scripts de automação shell (.sh)
│   ├── setup_env.sh                 # Configuração inicial do ambiente e banco
│   └── run_all.sh                   # Execução unificada dos 4 blocos locais
├── apps/
│   ├── backend/                     # API Central FastAPI + PostgreSQL bare-metal
│   ├── frontend-admin/              # Painel do Administrador (Desktop/Tablet)
│   ├── frontend-evaluator/          # Avaliação Mobile-First (Smartphones)
│   └── frontend-kiosk/              # Telão TV Kiosk (Smart TVs e Projetores)
└── README.md                        # Este guia de instalação e execução
```

---

## 2. Requisitos de Ambiente e Pré-Requisitos

Para execução nativa (*bare-metal* sem Docker), certifique-se de possuir instalado em sua máquina:

*   **Sistema Operacional:** Linux ou macOS (testado em ambientes POSIX).
*   **Python:** Versão **3.11** ou superior (`python3 --version`).
*   **Node.js:** Versão **18.17** ou superior (recomendado Node 20 LTS) (`node -v`).
*   **Gerenciador de Pacotes:** `npm` (versão 9+) ou `pnpm` (`npm -v`).
*   **Banco de Dados:** **PostgreSQL 15+** em execução local (`psql --version`).
*   **Ferramentas Auxiliares:** `curl`, `git`, `bash` / `zsh`.

---

## 3. Controle de Versão (Git & Conexão SSH)

Siga este passo a passo para conectar o projeto ao seu Git remoto (GitHub ou GitLab) via SSH e manter todo o ciclo de desenvolvimento ativo na branch `develop`, preservando a branch `main` intacta para automações de CI/CD futuras.

### Passo 3.1: Verificar Ferramentas de Desenvolvedor no macOS
Se estiver no macOS e ainda não tiver as ferramentas de linha de comando ativas:
```bash
xcode-select --install
```

### Passo 3.2: Gerar e Configurar Chave SSH
Se você ainda não possui uma chave SSH configurada na sua máquina:
1. Abra o terminal e gere uma nova chave SSH Ed25519:
   ```bash
   ssh-keygen -t ed25519 -C "seu_email@exemplo.com"
   ```
   *(Pressione Enter para confirmar o caminho padrão `~/.ssh/id_ed25519` e opcionalmente insira uma senha/passphrase).*

2. Ative o agente SSH e adicione sua chave privada:
   ```bash
   eval "$(ssh-agent -s)"
   ssh-add ~/.ssh/id_ed25519
   ```

3. Copie a sua chave pública diretamente para a área de transferência do Mac:
   ```bash
   pbcopy < ~/.ssh/id_ed25519.pub
   ```

4. Cadastre a chave pública no seu provedor Git:
   * **GitHub:** Acesse `Settings` > `SSH and GPG keys` > `New SSH key` > Cole a chave e salve.
   * **GitLab:** Acesse `Preferences` > `SSH Keys` > `Add new key` > Cole a chave e salve.

5. Teste a conexão SSH:
   ```bash
   ssh -T git@github.com
   # ou para GitLab:
   ssh -T git@gitlab.com
   ```
   *(Confirme com `yes` caso solicite a verificação de autenticidade do host).*

### Passo 3.3: Criar Repositório Remoto no Git (GitHub ou GitLab)
1. Acesse sua conta no GitHub (`https://github.com/new`) ou GitLab (`https://gitlab.com/projects/new`).
2. Defina o nome do repositório (ex: `fecitel-system` ou `fecitel-monorepo`).
3. Escolha a visibilidade (**Private** ou **Public**).
4. **IMPORTANTE:** Deixe desmarcadas as opções de inicialização ("Add a README file", "Add .gitignore" e "Choose a license"). O repositório remoto **DEVE ser criado totalmente vazio**, pois o projeto local já possui a estrutura completa e o `.gitignore` configurado.

### Passo 3.4: Inicializar o Repositório Local e Conectar ao Remoto
No diretório raiz do projeto (`/Users/alexaraujo/Documents/Fecitel-Alex-Rogerio`), execute:

```bash
# 1. Inicializar o repositório Git local
git init

# 2. Configurar a sua identidade no Git (caso ainda não tenha feito)
git config user.name "Seu Nome"
git config user.email "seu_email@exemplo.com"

# 3. Adicionar os arquivos ao stage (o .gitignore já protegerá diretórios pesados e segredos)
git add .

# 4. Criar o commit inicial da documentação e arquitetura
git commit -m "chore: initial project documentation, architecture and specifications"

# 5. Garantir que a branch principal chama-se main
git branch -M main

# 6. Conectar o repositório local ao repositório remoto via SSH
# (Substitua a URL abaixo pela URL SSH fornecida na criação do seu repositório)
git remote add origin git@github.com:seu-usuario/fecitel-system.git

# 7. Enviar o primeiro commit para a branch main
git push -u origin main
```

### Passo 3.5: Criar e Publicar a Branch `develop`
Para manter a branch `main` limpa e isolada para pipelines de CI/CD em produção, crie e publique imediatamente a branch `develop`:

```bash
# 1. Criar e mudar para a branch develop
git checkout -b develop

# 2. Enviar a branch develop para o repositório remoto
git push -u origin develop
```

### Passo 3.6: Rotina de Trabalho e Atualizações Contínuas
A partir deste momento, todo o trabalho diário, novas funcionalidades e correções devem permanecer na branch `develop`:

```bash
# Conferir em qual branch você está
git branch

# Visualizar arquivos alterados
git status

# Adicionar arquivos e comitar
git add .
git commit -m "feat(modulo): breve descrição da funcionalidade em português"

# Manter o projeto atualizado no Git remoto na branch develop
git push origin develop
```

> **Aviso de Segurança (Governança do Projeto - RULE-04):** Conforme definido nas regras do projeto, a IA não executa comandos `git push` de forma autônoma. O envio de código e commits para o repositório remoto deve sempre ser executado ou autorizado diretamente pelo Gerente de Projeto (Alex Araújo).

---

## 4. Configuração do Banco de Dados (PostgreSQL Bare-Metal)

O sistema exige uma instância nativa do PostgreSQL rodando localmente na porta padrão `5432`.

### Passo 4.1: Acesso ao Terminal do PostgreSQL (psql)

*   **No macOS (via Homebrew — Seu Ambiente):**  
    No macOS, o PostgreSQL é executado nativamente sob a sua própria conta de usuário. **Não existe usuário de sistema `postgres` no macOS**, logo **não utilize `sudo`**. Para acessar:
    ```bash
    psql postgres
    # Ou com o caminho completo caso ainda não tenha exportado ao PATH:
    /opt/homebrew/opt/postgresql@18/bin/psql postgres
    ```

*   **No Linux (Ubuntu / Debian / CentOS):**  
    ```bash
    sudo -u postgres psql
    ```

Execute os comandos SQL para criar a base de dados dedicada e o usuário do sistema:

```sql
-- Criação do usuário da aplicação
CREATE USER fecitel_user WITH PASSWORD 'fecitel_secret_2026';

-- Criação do banco de dados oficial
CREATE DATABASE fecitel_db OWNER fecitel_user;

-- Concessão de privilégios plenos
GRANT ALL PRIVILEGES ON DATABASE fecitel_db TO fecitel_user;

-- Conectar ao banco e garantir privilégios no schema public
\c fecitel_db
GRANT ALL ON SCHEMA public TO fecitel_user;
```

---

## 5. Configuração das Variáveis de Ambiente

Crie o arquivo de ambiente para o backend a partir do modelo padrão:

```bash
cp apps/backend/.env.example apps/backend/.env
```

Edite o arquivo `apps/backend/.env` ajustando as credenciais do seu banco local e chaves de segurança:

```ini
# Configuração da Aplicação
ENVIRONMENT=development
DEBUG=True
PORT=8000
HOST=127.0.0.1

# Conexão com Banco de Dados PostgreSQL (asyncpg nativo)
DATABASE_URL=postgresql+asyncpg://fecitel_user:fecitel_secret_2026@localhost:5432/fecitel_db

# Segurança e Criptografia
JWT_SECRET_KEY=sua_chave_secreta_super_segura_de_no_minimo_32_caracteres_fecitel
JWT_ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_HOURS=12
API_KEY=fecitel_secret_api_key_2026

# Servidor de E-mail (SMTP) para envio dos códigos OTP de 8 caracteres
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=notificacoes@fecitel.ifms.edu.br
SMTP_PASSWORD=sua_senha_de_app_smtp
SMTP_FROM=nao-responda@fecitel.ifms.edu.br

# Armazenamento Local de Arquivos
UPLOAD_DIR=/Users/alexaraujo/Documents/Fecitel-Alex-Rogerio/storage/uploads
MAX_FILE_SIZE_MB=20
```

> [!IMPORTANT]
> **Proteção Universal por API Key (Regra SEC-03):** Todas as rotas da API (`/api/v1/*`), **incluindo expressamente todas as consultas de leitura via método `GET`**, além de mutações (`POST`, `PUT`, `DELETE`), exigem a presença do cabeçalho `X-API-Key: fecitel_secret_api_key_2026` (ou parâmetro `api_key`). Requisições sem chave válida retornarão `HTTP 401 Unauthorized`. Rotas autenticadas por perfil exigem adicionalmente o token JWT no cabeçalho `Authorization: Bearer <token>`.

---

## 6. Instalação e Inicialização Automatizada com Scripts Shell (`.sh`)

O projeto dispõe de scripts shell para automatizar toda a rotina de setup e execução.

### Opção A: Setup Completo Automatizado
Para verificar dependências, criar o ambiente virtual Python (`venv`), instalar pacotes e rodar migrações:

```bash
chmod +x scripts/setup_env.sh
./scripts/setup_env.sh
```

### Opção B: Execução Unificada de Todos os Blocos
Para inicializar os 4 blocos concorrentemente com encerramento gracioso (*trap SIGINT* ao pressionar `Ctrl+C`):

```bash
chmod +x scripts/run_all.sh
./scripts/run_all.sh
```

---

## 7. Portas e URLs de Acesso Local

Ao iniciar o sistema, os serviços estarão acessíveis nos seguintes endereços:

| Bloco Funcional | Aplicação | Endereço Local | Finalidade / Público-Alvo |
| :--- | :--- | :--- | :--- |
| **Bloco 1** | **Backend API (FastAPI)** | `http://localhost:8000` | API RESTful e Documentação Swagger interativa em `/docs` |
| **Bloco 2** | **Frontend Admin** | `http://localhost:3001` | Painel da Coordenação, Homologação, Áreas, Prêmios e Recepção |
| **Bloco 3** | **Frontend Evaluator** | `http://localhost:3002` | Avaliação presencial Mobile-First para uso dos avaliadores na feira |
| **Bloco 4** | **Frontend Kiosk** | `http://localhost:3003` | Painel público em tempo real para Smart TVs e Telões (1080p / 4K) |

---

## 8. Execução Individual dos Blocos (Desenvolvimento Granular)

Caso deseje trabalhar em um bloco isoladamente:

### 1. Backend Central (`apps/backend/`)
```bash
cd apps/backend
chmod +x run.sh
./run.sh
```
*   Cria automaticamente o `.venv`, instala pacotes via `pip` e sobe o servidor Uvicorn com *hot-reload*.

### 2. Painel Administrativo (`apps/frontend-admin/`)
```bash
cd apps/frontend-admin
npm install
npm run dev -- -p 3001
```

### 3. Módulo do Avaliador Mobile-First (`apps/frontend-evaluator/`)
```bash
cd apps/frontend-evaluator
npm install
npm run dev -- -p 3002
```

### 4. Módulo Quiosque para Telões (`apps/frontend-kiosk/`)
```bash
cd apps/frontend-kiosk
npm install
npm run dev -- -p 3003
```

---

## 9. Execução de Testes Automatizados (Sem Mocks)

Em total conformidade com as regras do projeto, os testes automatizados são executados diretamente contra o **PostgreSQL real bare-metal**:

```bash
cd apps/backend
source .venv/bin/activate
pytest -v -s
```

---

## 10. Padrões de Idioma e Boas Práticas de Código

*   **Código e Banco de Dados (Estritamente em Inglês):** Nomes de arquivos de código, variáveis, funções, classes, modelos ORM, tabelas (`events`, `projects`, `awards`, `award_criteria`), colunas, rotas e payloads JSON são estritamente em **inglês**.
*   **Documentação, Interface e Mensagens (Estritamente em Português):** Todos os arquivos `.md`, telas de usuário, botões, modais, mensagens de validação e e-mails são estritamente em **português (pt-BR)**.
*   **Padrão Visual e Badges nos READMEs (Raiz e Módulos):** Tanto o `README.md` principal na raiz quanto cada módulo em `apps/` (`backend`, `frontend-admin`, `frontend-evaluator`, `frontend-kiosk`) dispõem de documentação moderna, profissional e colorida, contendo badges estilizados das tecnologias adotadas (FastAPI, Python, PostgreSQL, Next.js, Tailwind, etc.), mapa de pastas e instruções completas de uso.
*   **Segurança no Login:** Participantes utilizam código de 8 caracteres em caixa alta enviado por e-mail, digitado em campo mascarado como senha (`type="password"`).

---

## 11. Documentação Complementar

Para aprofundamento técnico e histórico de decisões:
*   [**Regras de Negócio e Governança**](file:///.agents/rules.md): `.agents/rules.md` (Incluindo BR-18, BR-19, UX-01, DEV-01)
*   [**Contexto e Escopo do Sistema**](file:///docs/context.md): `docs/context.md`
*   [**Dicionário de Dados e ERD**](file:///docs/database.md): `docs/database.md`
*   [**Arquitetura, Endpoints e Telas**](file:///docs/design.md): `docs/design.md`
*   [**Evolução da Tabela People (CPF/Afiliação) e Ingestão do Dataset**](file:///docs/021_adicao_campos_cpf_afiliacao_importacao_dataset_2026-09-11_14h15.md): `docs/021_adicao_campos_cpf_afiliacao_importacao_dataset_2026-09-11_14h15.md`
*   [**Novas Regras e Ajustes de Fases (Reativação, Modais, "use client", Fase 3)**](file:///docs/020_regras_ajustes_fases_e_correcoes_2026-09-11_13h50.md): `docs/020_regras_ajustes_fases_e_correcoes_2026-09-11_13h50.md`
*   [**Regra BR-18 — Paginação Real Obrigatória (15 itens/pág)**](file:///docs/018_regra_paginacao_real_obrigatoria_2026-09-11_12h35.md): `docs/018_regra_paginacao_real_obrigatoria_2026-09-11_12h35.md`
*   [**Regra BR-19 — Seleção Obrigatória de Evento Ativo e Contexto Global**](file:///docs/019_regra_selecao_evento_ativo_contexto_global_2026-09-11_12h45.md): `docs/019_regra_selecao_evento_ativo_contexto_global_2026-09-11_12h45.md`
*   [**Relatório Técnico Completo de Especificação**](file:///docs/003_full_system_specification_report_2026-09-09_10h51.md): `docs/003_full_system_specification_report_2026-09-09_10h51.md`
