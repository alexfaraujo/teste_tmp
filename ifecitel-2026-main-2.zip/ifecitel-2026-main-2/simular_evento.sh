#!/usr/bin/env bash
# EasyEvent - Launcher do Simulador de Ciclo de Vida e Teste de Stress
# Permite rodar de modo interativo (sem parâmetros) ou com parâmetros (ex: --projects 20 --evaluators-per-project 3)

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null 2>&1 && pwd)"
VENV_PYTHON="$DIR/apps/backend/.venv/bin/python"
SCRIPT="$DIR/scripts/simular_evento.py"

if [ -f "$VENV_PYTHON" ]; then
    exec "$VENV_PYTHON" "$SCRIPT" "$@"
else
    python3 "$SCRIPT" "$@"
fi
