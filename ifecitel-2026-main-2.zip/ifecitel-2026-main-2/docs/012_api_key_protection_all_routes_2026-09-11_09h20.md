# Registro Cronológico: Implementação da Proteção Universal por API Key (Regra SEC-03)

**Data:** 11/09/2026 — 09h20  
**Autor:** Engenheiro de Software Fullstack / Especialista em Sistemas de Alto Desempenho  
**Status:** CONCLUÍDO E DOCUMENTADO NAS REGRAS (.md) E NO BACKEND

---

## 1. Motivação e Instrução do Gestor do Projeto

Em auditoria técnica realizada pelo Gestor do Projeto (Alex Araújo), identificou-se que as rotas HTTP de leitura (`GET`), tais como listagem de eventos, consulta de grandes áreas, subáreas, prêmios e projetos, estavam desprovidas de barreira de proteção de entrada.

**Diretriz Soberana:**
> "Inserir descrição nas regras dos arquivos .md que todas as rotas precisam ser protegidas por API key. Nos testes que fiz as rotas get não estão protegidas e elas precisam estar protegidas. Ajustar."

---

## 2. Especificação da Regra SEC-03

Foi formalizada nos arquivos normativos (`.agents/rules.md`, `docs/context.md`, `docs/design.md`, `README.md` raiz e `apps/backend/README.md`) a regra **SEC-03**:

1. **Universalidade (100% das Rotas):** Toda e qualquer requisição direcionada aos endpoints da API (`/api/v1/*`), incluindo expressamente consultas de leitura (`GET`) e mutações (`POST`, `PUT`, `DELETE`, `PATCH`), exige a presença de uma API Key corporativa válida.
2. **Forma de Envio:**
   - Primária: Cabeçalho HTTP `X-API-Key: fecitel_secret_api_key_2026`.
   - Secundária: Parâmetro de query `?api_key=...`.
3. **Rejeição Estrita:** Requisições sem chave ou com valor incorreto são rejeitadas de imediato com `HTTP 401 Unauthorized` e mensagem descritiva em português:  
   `"Acesso não autorizado: API Key ausente ou inválida. Todas as rotas exigem a chave corporativa no cabeçalho 'X-API-Key'."`
4. **Segurança em Camadas (Defense-in-Depth):**
   - Para clientes da aplicação (Frontends, Kiosk, Leitores de QR Code): API Key bloqueia acessos de bots, scrapers e scanners não autorizados.
   - Para rotas autenticadas por perfil: Exigem API Key no cabeçalho `X-API-Key` **mais** o token JWT no cabeçalho `Authorization: Bearer <token>`.

---

## 3. Alterações Implementadas no Backend

1. **Configuração (`apps/backend/app/core/config.py` e `.env`):**
   - Adicionadas as chaves `API_KEY` (padrão `"fecitel_secret_api_key_2026"`) e `API_KEY_NAME` (`"X-API-Key"`).
2. **Dependência de Segurança (`apps/backend/app/api/deps.py`):**
   - Implementada a função assíncrona `verify_api_key(header_key, query_key)` com integração ao OpenAPI (`APIKeyHeader` e `APIKeyQuery`), gerando suporte nativo ao botão "Authorize" no Swagger UI (`/docs`).
3. **Inclusão no Roteador Central (`apps/backend/app/api/v1/router.py`):**
   - Configurado `api_router = APIRouter(dependencies=[Depends(verify_api_key)])`, aplicando a validação de forma mandatória e abrangente sobre todos os sub-roteadores (`auth`, `events`, `knowledge_areas`, `awards`, `projects`).
4. **Suporte nos Testes Automatizados (`apps/backend/tests/`):**
   - Fixture de teste HTTP atualizada com o cabeçalho `X-API-Key` automático.
   - Criação de suíte de testes dedicada atestando que requisições `GET` e `POST` sem a chave retornam `HTTP 401 Unauthorized`.

---

## 4. Métricas de Esforço da IA (`RULE-07`)

| Métrica | Percentual | Detalhamento |
| :--- | :--- | :--- |
| **IA Autônoma** | 30% | Implementação de dependências FastAPI, schemas OpenAPI e ajustes de testes. |
| **Híbrido (Pair Programming)** | 50% | Auditoria de segurança conjunta, refinamento de mensagens e integração de cabeçalhos. |
| **Humano (Alex Araújo)** | 20% | Auditoria dos testes, detecção de falha nas rotas GET e definição da regra de API Key. |
