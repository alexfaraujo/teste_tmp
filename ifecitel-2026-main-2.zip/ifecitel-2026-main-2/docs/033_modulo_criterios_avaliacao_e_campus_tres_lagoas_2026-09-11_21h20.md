# 033 — Atualização para Campus Três Lagoas, Bloqueio de Premiações sem Critérios e Módulo de Critérios de Avaliação

**Data:** 11/09/2026 21:20  
**Autor:** Antigravity (Pair Programming com Alex Araújo)  
**Status:** Concluído e Validado (100% de testes e TypeScript aprovados)  
**Fase:** Fase 2 / Fase 6 — Governança Institucional e Parametrização de Critérios

---

## 1. Contexto e Motivação

Durante a homologação das telas de Premiações (`/awards`) e Resultados (`/results`), foram identificadas três demandas essenciais pelo usuário (Alex Araújo):
1. **Identidade do Campus:** O campus de realização é o **IFMS Campus Três Lagoas** (e não Aquidauana). A barra lateral, tela de login e cabeçalhos de impressão da Ata Oficial de Resultados foram atualizados para refletir corretamente o campus.
2. **Bloqueio Rígido de Premiações sem Critérios (Regra BR-17):** Não pode ser permitido cadastrar ou salvar premiações específicas sem que haja ao menos um critério de avaliação selecionado e vinculado, pois o Ranking 2 baseia-se exclusivamente nesses itens.
3. **Módulo e CRUD de Critérios de Avaliação (`/criteria`):** O banco de dados PostgreSQL já contava com a modelagem relacional da tabela `evaluation_criteria` desde a Fase 2, porém ainda não havia uma interface dedicada no frontend para os administradores gerenciarem as perguntas da ficha de avaliação mobile, nem os endpoints de edição (`PUT`) e exclusão (`DELETE`) com trava de integridade.

---

## 2. Alterações Realizadas

### 2.1 Backend (`apps/backend`)

1. **Schema de Atualização de Critérios:**
   - Em `app/schemas/evaluation.py`, adicionado o schema `EvaluationCriterionUpdate` permitindo editar `name`, `scientific_description`, `technological_description`, `max_score` e `weight`.

2. **Endpoints de Atualização e Exclusão (`app/api/v1/endpoints/events.py`):**
   - `PUT /events/{event_id}/criteria/{criterion_id}`: Atualiza os dados do critério com validação de trava temporal do evento e API Key.
   - `DELETE /events/{event_id}/criteria/{criterion_id}`:
     - Valida trava temporal do evento.
     - **Trava de Integridade:** Impede a exclusão caso o critério já possua notas registradas em `evaluation_items` (`HTTP 400 Bad Request`).
     - Desativa logicamente quaisquer vínculos existentes em `award_criteria`.
     - Executa o soft-delete do critério.

3. **Testes Automatizados:**
   - Adicionado o teste `test_evaluation_criteria_crud_and_integrity_locks` em `apps/backend/tests/test_phase2.py`.
   - Suíte de testes do backend: **35 testes aprovados (100% de sucesso)**.

---

### 2.2 Frontend Admin (`apps/frontend-admin`)

1. **Atualização Institucional do Campus:**
   - `Sidebar.tsx`: Rodapé atualizado para **IFMS Campus Três Lagoas**.
   - `login/page.tsx`: Rodapé atualizado para **Instituto Federal de Mato Grosso do Sul — Campus Três Lagoas**.
   - `results/page.tsx`: Cabeçalho de impressão da Ata Oficial e campos de assinaturas atualizados para **IFMS Campus Três Lagoas** e **FECITEL IFMS Três Lagoas**.

2. **Navegação do Menu Lateral (`Sidebar.tsx`):**
   - Inserido o item de navegação **"Critérios de Avaliação"** (`/criteria`) com ícone `ListChecks` logo após "Áreas e Subáreas".

3. **Bloqueio Obrigatório de Critérios em Premiações (`/awards`):**
   - Na submissão do formulário de premiação, valida se `activeLinks.length === 0` e exibe erro interno (UX-01): *"Selecione ao menos um critério de avaliação para vincular à premiação específica (Regra BR-17)."*
   - Caso a edição ativa ainda não possua critérios cadastrados, o modal exibe aviso orientador com botão direto para a tela de critérios.
   - No cabeçalho de `/awards`, adicionado botão de atalho "Critérios de Avaliação".

4. **Novo Módulo de Critérios de Avaliação (`/criteria`):**
   - Tipagens: Adicionadas `EvaluationCriterionCreatePayload` e `EvaluationCriterionUpdatePayload` em `src/types/index.ts`.
   - Serviço HTTP: Criado `src/services/criterion.service.ts` com métodos `getCriteria`, `createCriterion`, `updateCriterion` e `deleteCriterion`.
   - Página `src/app/(dashboard)/criteria/page.tsx`:
     - Diretiva `"use client";` na primeira linha (DEV-01).
     - Proteção por contexto de evento ativo com `<RequireActiveEvent>` (BR-19).
     - Busca em tempo real e paginação de itens (BR-18).
     - Visualização dual em cards com orientações para **Projetos Científicos** e **Projetos Tecnológicos**, nota máxima e peso.
     - Modais de cadastro, edição e exclusão com mensagens internas (UX-01).

---

## 3. Validação e Testes

1. **Backend Tests (Pytest):**
   - 35 testes executados e aprovados com 100% de sucesso.
2. **Frontend TypeCheck (TypeScript):**
   - Comando `export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH" && npx tsc --noEmit`: **0 erros**.
3. **Rotas HTTP Validadas:**
   - `http://localhost:3001/criteria`: **200 OK**.
   - `http://localhost:3001/awards`: **200 OK**.
   - `http://localhost:3001/results`: **200 OK**.
