# 043 — Ampliação dos Parâmetros de Cadastro e Edição de Eventos (Metadados Ricos, Níveis de Ensino e Equipe Gestora)

**Data:** 13/09/2026  
**Status:** Especificado e Documentado  
**Módulos Impactados:** `apps/backend` (Model, Schemas, Services, Endpoints), `apps/frontend-admin` (Tipos, Serviços, Modais e Componentes de Eventos), `docs/database.md`, `docs/context.md`  
**Regras de Negócio Relacionadas:** BR-01 (Múltiplas Edições), BR-02 (Trava Temporal), BR-04 (Cotas de Estudantes por Nível), BR-23 (Isolamento Multi-Feiras e Equipe Gestora)

---

## 1. Contexto & Motivação

Com a consolidação do **EasyEvent** como plataforma aberta multi-feiras, os eventos cadastrados atendem a diferentes realidades: feiras escolares municipais, mostras estaduais, olimpíadas de robótica e feiras de institutos federais e universidades.

Anteriormente, o modal de cadastro/edição de feiras apresentava apenas 6 campos básicos (`name`, `year`, `start_date`, `end_date`, `max_projects_per_evaluator`, `max_file_size_mb`). Parâmetros essenciais já existentes na modelagem do banco (como local físico, descrição, carga horária e capacidade máxima) ficavam com valores estáticos ou vazios. Além disso, níveis de ensino atendidos e a equipe gestora da feira só podiam ser configurados após o evento já estar criado.

Esta especificação define a **ampliação completa do formulário de criação e edição de feiras**, integrando:
1. **Exibição e edição ativa de todos os parâmetros nativos da tabela `events`**.
2. **Criação de novos atributos estratégicos para identidade institucional da feira** (instituição promotora, tema oficial, e-mail de contato, site/regulamento oficial e logotipo).
3. **Parametrização integrada dos Níveis de Ensino e Cotas de Estudantes** (Regra **BR-04**).
4. **Indicação opcional da Equipe Gestora** (Regra **BR-23**) no momento da criação ou edição do evento.

---

## 2. Dicionário Completo de Campos do Formulário

Os parâmetros do evento são organizados de maneira ergonômica em seções temáticas no modal de criação e edição:

### Seção 1: Dados Gerais & Período
| Campo | Tipo / Formato | Obrigatório? | Padrão (*Default*) | Descrição de Negócio |
| :--- | :---: | :---: | :---: | :--- |
| `name` | Texto (255) | **Sim** | — | Nome oficial da edição (Ex: *EasyEvent 2026 - Feira de Ciência e Tecnologia*). |
| `year` | Número (2020-2050) | **Sim** | Ano atual | Ano de exercício da feira. Utilizado nos códigos QR e identificadores. |
| `start_date` | Data (`YYYY-MM-DD`) | **Sim** | — | Data oficial de abertura/início da feira. |
| `end_date` | Data (`YYYY-MM-DD`) | **Sim** | — | Data de término da feira. Ao expirar, ativa a **Trava Temporal BR-02**. |
| `description` | Texto Longo (*Textarea*) | Opcional | `null` | Resumo da edição, orientações aos expositores e avisos gerais. |

### Seção 2: Identidade Institucional & Contato (Novos Atributos)
| Campo | Tipo / Formato | Obrigatório? | Padrão (*Default*) | Descrição de Negócio |
| :--- | :---: | :---: | :---: | :--- |
| `organizing_institution` | Texto (255) | Opcional | `null` | Instituição promotora (Ex: *Instituto Federal de MS*, *Universidade Federal*, *Secretaria de Educação*). |
| `theme` | Texto (255) | Opcional | `null` | Tema oficial da edição (Ex: *Biomas do Brasil: diversidade, saberes e tecnologias sociais*). |
| `location` | Texto (255) | **Sim** | `"Campus do IFMS"` | Local físico onde ocorre a feira (Ex: *Ginásio Poliesportivo - Bloco B*). |
| `contact_email` | E-mail (255) | Opcional | `null` | E-mail oficial de contato da comissão organizadora. |
| `website_url` | URL (500) | Opcional | `null` | Link para o site oficial ou página externa do regulamento. |
| `logo_url` | URL / Imagem (500) | Opcional | `null` | Logotipo ou banner da identidade visual da feira. |

### Seção 3: Limites Operacionais & Arquivos
| Campo | Tipo / Formato | Obrigatório? | Padrão (*Default*) | Descrição de Negócio |
| :--- | :---: | :---: | :---: | :--- |
| `workload_hours` | Número inteiro | **Sim** | `40` | Carga horária total da edição para emissão de certificados (Ex: 20h, 40h, 60h). |
| `max_projects` | Número inteiro | **Sim** | `150` | Capacidade máxima global de trabalhos suportados pela infraestrutura física. |
| `max_projects_per_evaluator` | Número inteiro | **Sim** | `4` | Carga máxima de projetos atribuídos a cada avaliador para evitar sobrecarga. |
| `max_file_size_mb` | Número inteiro (1-100) | **Sim** | `20` | Tamanho máximo permitido em megabytes para upload de relatórios e banners. |
| `summary_extension` | Seleção (`pdf`, `docx`) | **Sim** | `"pdf"` | Extensão permitida para o resumo expandido/artigo do projeto. |
| `banner_extension` | Seleção (`pdf`, `pptx`) | **Sim** | `"pdf"` | Extensão permitida para o arquivo de banner virtual/pôster. |

---

## 3. Parametrização Integrada dos Níveis de Ensino e Cotas (Regra BR-04)

No próprio cadastro e edição da feira, o Coordenador Geral parametriza quais níveis de ensino participarão da edição, configurando:
- **Seleção Múltipla de Níveis:**
  - `MEDIO` (Ensino Médio e Técnico Integrado)
  - `FUNDAMENTAL` (Ensino Fundamental II)
  - `JUNIOR` (Iniciação Científica Júnior)
- **Cotas por Nível Ativado:**
  - `max_students`: Limite máximo de estudantes por projeto naquele nível (padrão: 4 no Médio, 5 no Fundamental, 3 no Júnior).
  - `min_evaluators`: Meta mínima de avaliações exigidas por projeto (padrão: 2 ou 3).

---

## 4. Indicação Opcional da Equipe Gestora (Regra BR-23)

O criador do evento é automaticamente o **Coordenador Geral (`COORDINATOR`)**. 

Tanto no momento do cadastro inicial quanto na edição, o formulário disponibiliza uma seção opcional para adicionar colaboradores à equipe gestora:
- **Campos do Colaborador:**
  - `email`: E-mail institucional ou pessoal do colaborador.
  - `role`: Nível de acesso delegado:
    - **`ORGANIZER` (Comissão Organizadora / Co-Administrador):** Gestão operacional plena (projetos, áreas, notas, alocação e apuração).
    - **`OPERATOR` (Apoio / Recepção):** Acesso tático restrito à Mesa de Credenciamento e Check-in de Avaliadores.
- O sistema valida a existência da pessoa ou gera o pré-cadastro com convite automático.

---

## 5. Modelagem no Banco de Dados (PostgreSQL)

### 5.1 Novas Colunas na Tabela `events`
```sql
ALTER TABLE events ADD COLUMN IF NOT EXISTS organizing_institution VARCHAR(255);
ALTER TABLE events ADD COLUMN IF NOT EXISTS theme VARCHAR(255);
ALTER TABLE events ADD COLUMN IF NOT EXISTS contact_email VARCHAR(255);
ALTER TABLE events ADD COLUMN IF NOT EXISTS website_url VARCHAR(500);
ALTER TABLE events ADD COLUMN IF NOT EXISTS logo_url VARCHAR(500);
```

### 5.2 Mapeamento SQLAlchemy (`app/models/event.py`)
```python
organizing_institution: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
theme: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
contact_email: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
website_url: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
logo_url: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
```

---

## 6. Schemas e Endpoints Backend

### 6.1 `EventCreate` e `EventUpdate` (`app/schemas/event.py`)
- `EventCreate`: recebe todos os campos escalares + `education_levels: Optional[List[EducationLevelCreate]]` + `administrators: Optional[List[EventAdminCreateInput]]`.
- `EventUpdate`: recebe campos opcionais para edição de metadados escalares + sincronização de `education_levels` e `administrators`.
- `EventResponse`: expõe todos os metadados ricos e as listas populadas de `education_levels` e `administrators`.

### 6.2 Serviços (`app/services/event_service.py`)
- `create_event`: persiste o evento, o criador como `COORDINATOR`, as etapas (`event_stages`), os níveis de ensino (`education_levels`) e a equipe adicional informada.
- `update_event`: atualiza campos escalares com verificação de trava temporal e sincroniza os níveis de ensino e equipe caso enviados.
