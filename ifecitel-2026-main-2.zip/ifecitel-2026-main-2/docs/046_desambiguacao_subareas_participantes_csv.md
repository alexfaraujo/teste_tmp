# Documentação Técnica: Desambiguação de Subáreas via Notação Hierárquica 'Área -> Subárea' na Importação de Participantes — EasyEvent

**Data:** 13 de Setembro de 2026  
**Status:** Implementado & Validado  
**Regras de Referência:** Regra BR-10 (Qualificação Temática de Avaliadores) e Regra BR-26 (Importação em Lote de Participantes via CSV)  
**Módulos Impactados:** `apps/backend` (Serviço de Participantes, Resolução Composta e Testes), `apps/frontend-admin` (Utilitário CSV, Geração de Modelo, Modal de Importação com Pré-visualização), `docs` (`context.md`, `database.md`).

---

## 1. Contexto e Motivação

Na modelagem relacional de eventos científicos, a tabela `subareas` possui a seguinte restrição de unicidade:
```sql
CONSTRAINT uq_subareas_area_name UNIQUE(area_id, name)
```

Essa modelagem permite que grandes áreas distintas do mesmo evento possuam subáreas com o mesmo nome (subáreas homônimas). Exemplos reais e recorrentes em feiras acadêmicas:
* **Ciências Exatas e da Terra** $\rightarrow$ subárea *"Informática"*
* **Ciências Sociais Aplicadas** $\rightarrow$ subárea *"Informática"*
* **Engenharias** $\rightarrow$ subárea *"Robótica"*
* **Ciências Exatas e da Terra** $\rightarrow$ subárea *"Robótica"*

### O Risco Técnico Anterior
Ao importar participantes via planilha CSV, a coluna `subareas` recebia apenas o nome simples da subárea (ex: `"Informática"`). O sistema montava um dicionário por nome simples (`s.name.lower(): s.id`). Caso existissem subáreas homônimas em áreas distintas, a chave sofria colisão de dicionário no backend, vinculando o avaliador de maneira arbitrária à última subárea carregada, sem qualquer aviso ao organizador.

---

## 2. A Solução Implementada: Notação Hierárquica Flexível

O EasyEvent adota agora a **notação hierárquica** para desambiguar a vinculação de subáreas de avaliadores.

### 2.1 Sintaxe Aceita na Coluna `subareas`
O usuário pode utilizar os seguintes separadores intuitivos:
* `Área -> Subárea` (recomendado e padrão do sistema)
* `Área > Subárea` (estilo trilha/breadcrumb)
* `Área: Subárea` (estilo escopo/dois pontos)

#### Exemplos no CSV:
```csv
nome;email;papeis;subareas
Dr. Carlos Lima;carlos@univ.br;Avaliador;"Engenharias -> Robótica, Ciências Exatas e da Terra -> Informática"
Dra. Ana Paula;ana@escola.br;Avaliador;"Ciências Sociais Aplicadas > Informática"
```

### 2.2 Resolução Inteligente por Omissão (Fallback Não-Ambíguo)
Se o usuário preencher apenas o nome da subárea (ex: `"Física Quântica"`):
1. **Subárea Única:** Se existir apenas uma subárea com esse nome em toda a feira ativa, o sistema associa o avaliador com sucesso e normaliza automaticamente o rótulo para `Área -> Subárea`.
2. **Subárea Ambígua:** Se a subárea existir sob mais de uma grande área, o sistema bloqueia preventivamente a importação e emite um erro explícito apontando as áreas em conflito.

---

## 3. Comportamento no Backend (`apps/backend`)

No método `import_participants_batch` ([`participant_service.py`](file:///Users/alexaraujo/Documents/Fecitel-Alex-Rogerio/apps/backend/app/services/participant_service.py)):
1. A consulta SQL carrega simultaneamente a subárea e o nome da sua grande área mãe:
   ```python
   select(Subarea, KnowledgeArea.name.label("area_name"))
   .join(KnowledgeArea, Subarea.area_id == KnowledgeArea.id)
   .where(KnowledgeArea.event_id == event_id, ...)
   ```
2. São geradas duas estruturas em memória:
   * **`composite_subarea_map`:** Chave `(normalize(area_name), normalize(subarea_name)) -> subarea_id`
   * **`simple_subarea_map`:** Chave `normalize(subarea_name) -> list of (subarea_id, area_name)`
3. Ao iterar pelas subáreas de cada avaliador:
   * Se contiver separador (`->`, `>`, `:`), realiza matching direto no mapa composto (com fallback para busca parcial caso haja ligeira variação no nome da área).
   * Se for nome simples:
     * Se `len(candidates) == 1`: vincula diretamente ao ID correspondente.
     * Se `len(candidates) > 1`: levanta `HTTP 400 Bad Request`:
       > *"A subárea '{sub}' informada para o participante '{nome}' é ambígua, pois pertence a mais de uma grande área: 'Área 1', 'Área 2'. Por favor, especifique no formato 'Área -> Subárea'."*

---

## 4. Comportamento no Frontend Admin (`apps/frontend-admin`)

### 4.1 Geração do Modelo CSV ([`participantCsv.ts`](file:///Users/alexaraujo/Documents/Fecitel-Alex-Rogerio/apps/frontend-admin/src/utils/participantCsv.ts))
* A função `generateParticipantsCsvTemplate` consome a lista de subáreas da feira ativa e já formata os exemplos didáticos do cabeçalho e das linhas de exemplo no padrão `Área -> Subárea` (ex: `"Ciências Exatas e da Terra -> Informática", "Engenharias -> Robótica e Automação"`).

### 4.2 Pré-visualização e Validação Client-Side
* O parser `parseParticipantsCsv` detecta a sintaxe e valida a existência das áreas e subáreas antes mesmo do envio à API.
* Em caso de subárea homônima sem a indicação da área, o modal marca a linha como inválida (`hasErrors = true`), exibe alerta vermelho:
  > ⚠️ *A subárea 'Informática' é ambígua, pois pertence a mais de uma grande área ('Ciências Exatas e da Terra', 'Ciências Sociais Aplicadas'). Especifique no formato 'Área -> Subárea'.*
* O botão de submissão do lote é desabilitado até a correção da planilha pelo usuário.

### 4.3 Exibição Visual dos Chips ([`ParticipantsCsvImportModal.tsx`](file:///Users/alexaraujo/Documents/Fecitel-Alex-Rogerio/apps/frontend-admin/src/components/participants/ParticipantsCsvImportModal.tsx))
* A coluna de subáreas da tabela de pré-visualização renderiza cada vínculo com destaque visual elegante: a grande área em negrito seguida do separador `>` e do nome da subárea (ex: **Engenharias** > Robótica).

---

## 5. Testes Automatizados e Qualidade

1. **Teste Automatizado no Backend:**
   * Arquivo [`test_participants_csv.py`](file:///Users/alexaraujo/Documents/Fecitel-Alex-Rogerio/apps/backend/tests/test_participants_csv.py):
     - `test_participants_batch_import_hierarchical_subareas_and_disambiguation`:
       - Cria feira com subáreas homônimas em áreas distintas.
       - Tenta importar com nome simples ambíguo $\rightarrow$ Valida rejeição com `HTTP 400` e mensagem explicativa.
       - Importa com notação hierárquica `->`, `>`, `:` $\rightarrow$ Valida criação com `HTTP 200` e assertiva nos IDs corretos no banco.
2. **Resultados dos Testes:**
   * **Backend:** 51 testes executados, **51 aprovados com 100% de sucesso** (`pytest`).
   * **Frontend:** Compilação estática com **0 erros de tipagem**, 18/18 páginas geradas com sucesso (`npm run build`).
