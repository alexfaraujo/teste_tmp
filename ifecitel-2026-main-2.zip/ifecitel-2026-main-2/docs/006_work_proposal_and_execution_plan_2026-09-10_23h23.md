# Proposta de Trabalho e Plano de Execução do Sistema FECITEL 2026

**Data e Hora:** 2026-09-10 23:23  
**Elaborado por:** Antigravity (Engenheiro de Software Fullstack Sênior / Arquiteto de Soluções)  
**Destinatário:** Alex Araújo (Gestor e Dono do Projeto FECITEL)  
**Status:** Proposta Submetida para Apreciação e Aprovação do Gestor  
**Documento Cronológico:** `docs/006_work_proposal_and_execution_plan_2026-09-10_23h23.md`

---

## 1. Apresentação e Diagnóstico Técnico da Solução

Como **Engenheiro e Programador de Software Fullstack Sênior**, especialista em arquiteturas de alto rendimento, código limpo e segurança em profundidade, apresento esta **Proposta de Trabalho e Plano de Execução** para o desenvolvimento integral do sistema **FECITEL (Feira de Ciência e Tecnologia)**.

### Diagnóstico de Desafios do Projeto:
1.  **Concorrência Extrema em Janelas Curtas:** No credenciamento presencial da feira (chegada de centenas de estudantes simultâneos), a entrega de kits e camisetas não pode sofrer duplicidade, exigindo operações de banco atômicas condicionais com latência inferior a 10ms.
2.  **Operabilidade Presencial em Ambiente Real:** Os avaliadores circulam pelo pavilhão com smartphones na mão, enfrentando instabilidade de rede e iluminação variável. A interface deve ser *Mobile-First*, com botões numéricos táteis (`+`/`-`) operáveis com uma mão e scanner veloz de QR Code de bancada.
3.  **Segurança e Sigilo Absoluto:** O painel público de TV Kiosk (`apps/frontend-kiosk/`) jamais pode expor notas individuais, pareceres ou ranqueamentos competitivos parciais, exigindo segregação estrita na camada de serviços do backend.
4.  **Autonomia do Gestor:** Módulos flexíveis para gerenciar etapas, múltiplos eventos, CRUD de áreas/subáreas do conhecimento e CRUD de premiações com amarração direta a perguntas da avaliação diretamente no painel do administrador do evento.

---

## 2. Pilares de Engenharia de Software Adotados

### 2.1. Arquitetura em Camadas com Serviços Diretos (Sem Boilerplate Inútil)
*   **Decisão de Engenharia:** Não utilizaremos camadas infladas de repositórios abstratos ou casos de uso que apenas repassam chamadas. 
*   **Estrutura:** A camada de controladores FastAPI (`routers/`) valida DTOs Pydantic v2 e delega a execução para módulos diretos em `services/`, que realizam regras de negócio e consultas assíncronas do SQLAlchemy 2.0 em transações atômicas.

### 2.2. Execução Bare-Metal e Performance Máxima
*   Sem sobrecarga de virtualização Docker ou overhead de Node.js no backend.
*   Python 3.11+ nativo com pool assíncrono `asyncpg` direto no PostgreSQL 15+ local.
*   Índices estratégicos compostos e parciais cobrindo todas as consultas críticas com filtro `WHERE deleted_at IS NULL`.
*   Eliminação de consultas N+1 por meio de consultas em lote (`WHERE email IN (...)`).

### 2.3. Segurança em Profundidade
*   **Autenticação Dual:**
    *   `ADMIN`: Senha mestre criptografada com **bcrypt** (fator de custo 12).
    *   Participantes (`STUDENT`, `ADVISOR`, `COADVISOR`, `EVALUATOR`): Autenticação sem senha estática via **código de 8 caracteres alfanuméricos único em caixa alta** (`YY` + 4 letras + 2 números), checado no banco e armazenado como hash (`access_code_hash`).
*   **Bloqueio de Duplicidade de Kits:** SQL atômico condicional com retorno instantâneo (`RETURNING tshirt_size`).
*   **RBAC Rígido:** Verificação de permissões em todas as rotas privadas via dependências injetáveis do FastAPI.

### 2.4. Padrão de Idiomas do Projeto
*   **Código-Fonte e Banco de Dados (Estritamente em Inglês):** Nomes de variáveis, funções, métodos, classes, arquivos de código, modelos ORM, tabelas, colunas e rotas RESTful.
*   **Documentação, Interface Gráfica e Mensagens (Estritamente em Português):** Todos os arquivos de documentação (`.md`), textos de telas, botões, modais, mensagens de erro e e-mails enviados aos participantes.

---

## 3. Estrutura do Monorepo em 4 Blocos Funcionais

```text
fecitel-monorepo/
├── .agents/
│   └── rules.md                     # Regras de governança, idiomas e negócios
├── docs/
│   ├── context.md                   # Contexto e escopo
│   ├── database.md                  # ERD Mermaid e Dicionário PostgreSQL
│   ├── design.md                    # Arquitetura, design system e rotas de API
│   ├── mockups/                     # Mockups aprovados e protótipo interativo
│   └── *.md                         # Registros cronológicos de decisões
├── scripts/
│   ├── setup_env.sh                 # Automação de setup inicial de banco e venv
│   └── run_all.sh                   # Orquestrador de execução dos 4 blocos locais
├── apps/
│   ├── backend/                     # BLOCO 1: FastAPI + asyncpg + PostgreSQL bare-metal
│   │   ├── run.sh                   # Script de execução local
│   │   ├── requirements.txt         # Dependências diretas Python
│   │   ├── .env.example             # Modelo de variáveis de ambiente
│   │   └── src/                     # Core, modelos, schemas, serviços, rotas
│   │
│   ├── frontend-admin/              # BLOCO 2: Next.js 14+ Painel do Administrador
│   │   ├── run.sh                   # Script de execução na porta 3001
│   │   ├── package.json             # Next.js 14+, TypeScript, Tailwind CSS
│   │   └── src/                     # Telas de Gestão, Homologação, Áreas, Prêmios e Recepção
│   │
│   ├── frontend-evaluator/          # BLOCO 3: Next.js 14+ Mobile-First Avaliadores
│   │   ├── run.sh                   # Script de execução na porta 3002
│   │   ├── package.json             # Next.js 14+ PWA Mobile-First
│   │   └── src/                     # Leitor QR de bancada, steppers de notas, parecer único
│   │
│   └── frontend-kiosk/              # BLOCO 4: Next.js 14+ Telão TV Kiosk (Smart TVs e Projetores)
│       ├── run.sh                   # Script de execução na porta 3003
│       ├── package.json             # Next.js 14+ 1080p e 4K (sem rolagem)
│       └── src/                     # Métricas agregadas, dark mode nativo, auto-refresh 30s
└── README.md                        # Guia completo de configuração e execução
```

---

## 4. Cronograma de Desenvolvimento Faseado (Roadmap de Execução)

O desenvolvimento será conduzido estritamente em **modo de programação em par (pair programming)** com o Gestor do Projeto, avançando etapa por etapa mediante autorização prévia:

```
[FASE 0] ────────► [FASE 1] ────────► [FASE 2] ────────► [FASE 3] ────────► [FASE 4] ────────► [FASE 5]
Fundação &         Backend Core &      Submissões,         Credenciamento,    Alocação &         Apuração &
Scripts .sh        Auth Dual           Áreas & Prêmios     Kits & Kiosk       Avaliação Mobile   Homologação
(2 dias)           (3 dias)            (4 dias)            (3 dias)           (4 dias)           (3 dias)
```

### Fase 0: Fundação, Infraestrutura Bare-Metal e Automação (.sh)
*   **Objetivo:** Criar a estrutura física do repositório monorepo e os scripts de automação.
*   **Entregáveis:**
    *   Criação das pastas de `apps/` e `scripts/`.
    *   Criação do script `scripts/setup_env.sh` (criação do banco `fecitel_db`, configuração de `venv` Python e checagem de Node.js).
    *   Criação do script `scripts/run_all.sh` para iniciar todos os blocos simultaneamente com captura de encerramento gracioso (*trap SIGINT*).
    *   Configuração dos arquivos base `package.json` e `requirements.txt`.
*   **Ponto de Parada (Checkpoint):** Apresentação ao Gestor dos scripts em funcionamento e ambiente pronto para receber código.

### Fase 1: Backend Core, Modelos ORM e Autenticação Dual
*   **Objetivo:** Estabelecer a persistência do banco relacional, segurança e fluxo de login.
*   **Entregáveis:**
    *   Configuração da sessão assíncrona SQLAlchemy 2.0 (`asyncpg`) e migrações Alembic.
    *   Modelos mapeados: `events`, `event_stages`, `education_levels`, `people`, `roles`, `user_roles`.
    *   Autenticação de Admin via bcrypt e geração de JWT.
    *   Gerador e validador do código OTP de 8 caracteres alfanuméricos em caixa alta (`YY` + 4 letras + 2 números), com verificação de unicidade no banco e armazenamento criptografado (`access_code_hash`).
    *   Serviço assíncrono de disparo de e-mails em português (SMTP) para envio dos códigos OTP.
    *   Testes unitários e de integração no PostgreSQL local real.
*   **Ponto de Parada (Checkpoint):** Validação dos fluxos de login no terminal e aprovação pelo Gestor.

### Fase 2: Gestão do Evento, Submissão, Áreas do Conhecimento e Premiações
*   **Objetivo:** Desenvolver o gerenciamento administrativo completo da feira e cadastro de trabalhos.
*   **Entregáveis:**
    *   Módulo de multi-evento e calendário de etapas com trava lógica automática após `end_date`.
    *   CRUD de Áreas e Subáreas do Conhecimento gerenciado no Painel do Evento (`/admin/knowledge-areas`) com travas impeditivas de exclusão.
    *   CRUD de Premiações (`/admin/awards`) com amarração a perguntas da ficha de avaliação (`award_criteria`).
    *   Endpoint de submissão de projetos em lote com validação estrita de cotas de alunos por nível de ensino e upload em streaming.
    *   Fluxo de anuência digital formal do orientador (*Advisor Consent*).
    *   Telas correspondentes no `apps/frontend-admin/`.
*   **Ponto de Parada (Checkpoint):** Demonstração da criação de um evento, áreas temáticas, prêmios e submissão com anuência digital.

### Fase 3: Credenciamento Presencial, Logística de Kits e Telão TV Kiosk
*   **Objetivo:** Entregar a automação da recepção física e o painel de engajamento público.
*   **Entregáveis:**
    *   Mesa de recepção (`/logistics`) com foco contínuo para bipagem via leitor de código de barras USB/Bluetooth.
    *   Lock atômico condicional contra entrega duplicada de kits com retorno do tamanho da camiseta.
    *   Transição em tempo real do projeto para `PRESENT` no primeiro credenciamento da equipe.
    *   Endpoint seguro `/api/v1/dashboard/public-tv` blindado contra vazamento de notas e nomes de avaliadores.
    *   Desenvolvimento do `apps/frontend-kiosk/` para Smart TVs e projetores (1080p e 4K, dark mode nativo, auto-refresh 30s).
*   **Ponto de Parada (Checkpoint):** Teste de bipagem de crachá, simulação de tentativa de retirada duplicada e inspeção do telão de TV.

### Fase 4: Algoritmo de Alocação Balanceada e Avaliação Presencial Mobile-First
*   **Objetivo:** Implementar a distribuição justa de avaliadores e a ficha de notas no celular.
*   **Entregáveis:**
    *   Algoritmo pós-checkin do Momento 1: distribuição automatizada por subárea com garantia matemática da Regra de Ouro (delta $\le 1$).
    *   Suporte a remanejamento manual (Momento 2) pela administração.
    *   Desenvolvimento do `apps/frontend-evaluator/`:
        *   Scanner de QR Code de bancada via câmera do celular.
        *   Ficha digital com renderização dinâmica de critérios científicos e tecnológicos.
        *   Ajuste tátil de notas por botões numéricos táteis `+` e `-` (0.0 a 10.0).
        *   Campo expansível de parecer/observação consolidada única ao final.
        *   Cache local de rascunhos para tolerância a quedas de conexão.
*   **Ponto de Parada (Checkpoint):** Avaliação presencial simulada completa com leitura de QR Code e envio de notas.

### Fase 5: Apuração Oficial, Classificação por Prêmios e Homologação Final
*   **Objetivo:** Totalização e consolidação das notas para a cerimônia de premiação.
*   **Entregáveis:**
    *   Cálculo da média aritmética simples de notas sem descarte.
    *   Cálculo automatizado da classificação por premiação baseando-se estritamente nas perguntas vinculadas a cada prêmio.
    *   Painel restrito de apuração da coordenação com exportação de relatórios.
    *   Testes de estresse e concorrência no PostgreSQL real.
    *   Validação final de todas as regras de negócio (BR-01 a BR-17).
*   **Ponto de Parada (Checkpoint):** Validação e homologação final do sistema completo pelo Gestor do Projeto.

---

## 5. Estratégia de Automação com Scripts Shell (`.sh`)

Para assegurar uma experiência de desenvolvimento simples, rápida e reproduzível, o sistema contará com os seguintes scripts na pasta `scripts/` e em cada aplicação:

1.  **`scripts/setup_env.sh`**:
    *   Valida se `python3.11`, `node`, `npm` e `psql` estão instalados.
    *   Verifica se o banco `fecitel_db` existe; se não, executa a criação automaticamente.
    *   Cria o ambiente virtual Python `.venv` em `apps/backend/`.
    *   Instala dependências do backend (`pip install -r requirements.txt`).
    *   Instala dependências de cada frontend (`npm install` em cada pasta).
    *   Executa as migrações iniciais do banco (`alembic upgrade head`).
2.  **`apps/backend/run.sh`**:
    *   Ativa o `.venv` local e executa a API FastAPI via Uvicorn na porta 8000 com *hot-reload*.
3.  **`apps/frontend-admin/run.sh`**, **`apps/frontend-evaluator/run.sh`**, **`apps/frontend-kiosk/run.sh`**:
    *   Scripts diretos para inicializar cada frontend Next.js em sua porta correspondente (3001, 3002 e 3003).
4.  **`scripts/run_all.sh`**:
    *   Inicia os 4 blocos em segundo plano de forma orquestrada, exibindo os links de acesso local.
    *   Possui manipulador de sinal (*trap SIGINT/SIGTERM*): ao pressionar `Ctrl+C`, encerra graciosamente todos os processos filhos, sem deixar portas presas no sistema operacional.

---

## 6. Métricas de Esforço da IA e Governança

Conforme preconizado na regra `RULE-06` e `RULE-07`, todas as interações e fases futuras seguirão a divisão de esforço transparente:

| Dimensão de Esforço | Percentual Estimado | Atividades Cobertas |
| :--- | :---: | :--- |
| **Esforço da IA (Automação)** | 40% | Criação de boilerplates limpos, esquemas de validação, migrações, scripts `.sh` e testes estruturais. |
| **Esforço Híbrido (Pair Programming)** | 40% | Refinamento colaborativo de código, testes interativos, calibração de UI e ajustes finos de regras de negócio em tempo real. |
| **Participação Humana Soberana (Alex Araújo)** | 20% | Decisões de arquitetura, aprovação soberana em cada checkpoint, validação de regras da feira e comando final de início de cada fase. |

---

## 7. Próximos Passos e Solicitação de Autorização

Com a documentação técnica consolidada, os arquivos `.md` traduzidos para o português e o arquivo `README.md` já criado na raiz do projeto com todas as instruções detalhadas de configuração, submeto esta **Proposta de Trabalho** à sua apreciação.

**Aguardando sua autorização expressa no chat para iniciarmos a execução da [FASE 0: Fundação, Infraestrutura e Automação (.sh)].**
