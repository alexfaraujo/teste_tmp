# Registro de Alterações: Centralização do Check-in de Avaliadores via CPF e Isolamento de Postos

**Data:** 11/09/2026 - 17h25  
**Autor:** Antigravity  
**Contexto:** Separação estrita de responsabilidades entre equipes (Recepção/Logística vs. Sala da Comissão Científica) e centralização do check-in de avaliadores.

---

## 1. Contexto e Motivação

No modelo operacional da feira, as equipes que atuam na recepção geral e as que coordenam a sala dos avaliadores são distintas e possuem atribuições independentes:
1. **Equipe da Recepção / Logística Geral:** Realiza o credenciamento de participantes (estudantes, orientadores, coorientadores), entrega crachás e kits/camisetas.
2. **Equipe da Comissão Científica / Sala dos Avaliadores:** Conduz a reunião de alinhamento com os avaliadores, confirma sua presença na comissão e realiza a alocação dinâmica imediata de trabalhos.

Para evitar confusão e sobreposição de tarefas:
- A tela de check-in dos avaliadores não deve permitir entrega de kits nem check-in geral de participante.
- A presença de avaliador na sala deve ser centralizada na tela `/evaluators/checkin` via digitação de CPF ou leitor óptico de crachá, removendo o botão de "Check-in Rápido" na tela principal de alocação `/evaluators`.

---

## 2. Alterações Realizadas

### 2.1 Backend (`allocation_service.py`)
- **Isolamento de Presença:** A função `allocate_evaluator_on_checkin` agora marca **exclusivamente** `evaluator_presence_confirmed = True` (e registra `evaluator_presence_confirmed_at`). Ela **não** altera o campo `presence_confirmed` (credenciamento geral), que é de controle soberano da equipe de recepção.
- **Respostas Consistentes:** Os retornos em `EvaluatorCheckinAllocationResponse` refletem fielmente o status real de `presence_confirmed` do participante (se ele passou ou não pela recepção) em vez de forçar `True`.

### 2.2 Frontend - Tela de Alocações (`/evaluators`)
- **Remoção do Botão "Check-in Rápido":** Eliminado o botão do header e o respectivo modal de check-in por ID numérico.
- **Centralização do Acesso:** Mantido e destacado o botão `Check-in de Avaliadores (CPF / Crachá)` com link direto para a tela especializada `/evaluators/checkin`.

### 2.3 Frontend - Tela de Check-in de Avaliadores (`/evaluators/checkin`)
- **Remoção Completa de Entrega de Kits:**
  - Removidos os badges de "Kit Entregue / Kit Pendente".
  - Removido o bloco de entrega direta de kit/camiseta na sala.
  - Removidas importações e chamadas ao `logisticsService`.
- **Foco Central no CPF e Leitor Óptico:**
  - Título e instruções destacando a busca prioritária por CPF ou leitor de crachá/QR Code.
  - Atualização do componente `BarcodeScannerInput` com placeholder orientado a CPF e botão customizado "Confirmar Check-in".
  - No fallback de seleção manual, os nomes dos avaliadores agora exibem seu respectivo CPF.
- **Avisos Informativos Claros:** Instruções em destaque informando que o credenciamento de participante e retirada de kits devem ser feitos no posto de recepção/logística.

---

## 3. Verificação e Testes

1. **Testes Automatizados (Pytest):**
   - Suíte completa com 33 testes executada via `.venv/bin/pytest tests/ -v`.
   - 100% de sucesso (`33 passed`).
2. **Compilação do Frontend (TypeScript):**
   - Executado `npx tsc --noEmit` no diretório `apps/frontend-admin`.
   - 0 erros de compilação.
3. **Serviços Ativos:**
   - Backend: `http://127.0.0.1:8000/docs` (200 OK)
   - Frontend: `http://localhost:3001/evaluators` (200 OK) e `/evaluators/checkin` (200 OK)
