# Registro Cronológico: Ajuste de Especificação — Definição dos Dois Rankings Oficiais de Premiação (Geral por Área/Nível vs Premiações Específicas)

**Data:** 11/09/2026 — 10h00  
**Autor:** Antigravity (Pair Programming com Alex Araújo — Gestor do Projeto)  
**Status:** APROVADO E INCORPORADO ÀS DIRETRIZES DE ARQUITETURA E REGRAS DE NEGÓCIO (BR-12 e BR-17)

---

## 1. Motivação e Diretriz do Gestor do Projeto

Em alinhamento direto com a determinação de Alex Araújo antes do início da implementação da Fase 5 (Apuração Oficial e Premiações), foi estabelecido o refinamento na descrição do sistema de ranqueamento da FECITEL:

> *"Existe dois rankings a serem construídos: um ranking por média das notas agrupando por área, níveis dos cursos do trabalho (Ensino Médio, Ensino Fundamental), melhor geral, ranking dos prêmios definidos pelas notas nos critérios (itens) de avaliação que forem indicadas no momento do cadastro dos itens de avaliação. Então para as premiações por área, considerar notas de todos os itens. Para premiações específicas considerar os itens que forem indicados para estas premiações específicas."*

---

## 2. Especificação Detalhada dos Dois Rankings

### 2.1. Ranking 1: Premiações Regulares / Gerais por Média Global (Todos os Itens de Avaliação)

*   **Critérios Considerados:** **100% de todos os critérios (itens) da ficha de avaliação** preenchidos pelos avaliadores que avaliaram o trabalho presencialmente.
*   **Fórmula da Nota do Trabalho ($S_{\text{global}}$):**
    Para um projeto avaliado por $M$ avaliadores em $K$ critérios (itens) da feira:
    $$\text{Nota do Avaliador}_m = \frac{\sum_{k=1}^K \text{score}_{m, k} \times \text{weight}_k}{\sum_{k=1}^K \text{weight}_k}$$
    $$\text{Nota Final Global} = \frac{\sum_{m=1}^M \text{Nota do Avaliador}_m}{M}$$
    *(Média aritmética simples entre avaliadores, sem descarte de notas extremas, conforme a Regra BR-12).*

*   **Sub-rankings Oficiais de Premiação Geral:**
    1.  **Por Grande Área do Conhecimento e Nível de Ensino:**
        - **Agrupamento:** `(knowledge_area_id, education_level)`.
        - **Exemplos de Pódio Oficial:**
          - *1º, 2º e 3º Lugares em Ciências Exatas e da Terra — Ensino Médio*
          - *1º, 2º e 3º Lugares em Ciências Humanas — Ensino Fundamental*
          - *1º, 2º e 3º Lugares em Engenharias — Ensino Médio*
        - **Classificação:** Ordenada decrescentemente pela `Nota Final Global`.
    2.  **Melhor Geral da Feira (*Overall Best Project*):**
        - **Agrupamento:** Unificado entre todos os projetos homologados e avaliados da edição do evento, independentemente da área ou nível.
        - **Finalidade:** Identificar os grandes campeões gerais da feira de ciência e tecnologia.

---

### 2.2. Ranking 2: Premiações Específicas / Prêmios Temáticos (Apenas Itens Indicados)

*   **Conceito:** Premiações especiais institucionais, menções honrosas e troféus de patrocinadores/parceiros (ex.: *"Prêmio Inovação Tecnológica"*, *"Destaque em Sustentabilidade Ambiental"*, *"Prêmio Empresa Parceira X"*).
*   **Critérios Considerados:** **Exclusivamente os critérios (itens) de avaliação expressamente indicados e vinculados àquele prêmio** no momento do cadastro do prêmio ou da parametrização de critérios (`award_criteria`).
*   **Fórmula da Nota no Prêmio Específico ($S_{\text{award}}$):**
    Sendo $C_{\text{award}}$ o subconjunto de critérios vinculados ao prêmio e $w_k^{\text{award}}$ os pesos específicos atribuídos no prêmio:
    $$\text{Nota do Avaliador no Prêmio}_m = \frac{\sum_{k \in C_{\text{award}}} \text{score}_{m, k} \times w_k^{\text{award}}}{\sum_{k \in C_{\text{award}}} w_k^{\text{award}}}$$
    $$\text{Nota Final no Prêmio} = \frac{\sum_{m=1}^M \text{Nota do Avaliador no Prêmio}_m}{M}$$
*   **Elegibilidade:** Trabalhos que concorrem à premiação têm suas notas filtradas estritamente pelos itens associados, permitindo que um trabalho com média geral moderada possa se consagrar vencedor no quesito específico (ex.: nota máxima em criatividade e inovação, mesmo que rigor metodológico tradicional tenha tido pontuação padrão).

---

## 3. Matriz de Endpoints RESTful para Apuração

| Ranking | Rota Endpoint | Parâmetros de Filtro | Descrição |
| :--- | :--- | :--- | :--- |
| **Ranking 1** | `GET /api/v1/dashboard/leaderboard/area-level` | `event_id`, `area_id` (opcional), `education_level` (opcional) | Lista os projetos classificados por Área do Conhecimento e Nível de Ensino, considerando **todos os itens** da ficha. |
| **Ranking 1** | `GET /api/v1/dashboard/leaderboard/overall` | `event_id` | Lista a classificação de **Melhor Geral** da feira, considerando **todos os itens** da ficha. |
| **Ranking 2** | `GET /api/v1/awards/{award_id}/standings` | `award_id` | Lista os projetos concorrentes ao prêmio específico, calculando a classificação **apenas com os critérios vinculados**. |

---

## 4. Documentos Atualizados
1. [`.agents/rules.md`](file:///Users/alexaraujo/Documents/Fecitel-Alex-Rogerio/.agents/rules.md): Regras **BR-12** e **BR-17** atualizadas com a descrição e metodologia dos dois rankings.
2. [`docs/context.md`](file:///Users/alexaraujo/Documents/Fecitel-Alex-Rogerio/docs/context.md): Seções 8 e 11 atualizadas.
3. [`docs/design.md`](file:///Users/alexaraujo/Documents/Fecitel-Alex-Rogerio/docs/design.md): Telas 1 e 5.8 atualizadas com os endpoints de área/nível, geral e prêmios.
4. [`docs/003_full_system_specification_report_2026-09-09_10h51.md`](file:///Users/alexaraujo/Documents/Fecitel-Alex-Rogerio/docs/003_full_system_specification_report_2026-09-09_10h51.md): Seção 7.1 item 6 e tabela de endpoints.
