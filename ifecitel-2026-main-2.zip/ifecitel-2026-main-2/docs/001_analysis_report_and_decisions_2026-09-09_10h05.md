# [HIST-001] Initial Analysis Report and Project Manager Decisions

**Date & Time:** 2026-09-09 10:05:00 -04:00  
**Author:** Antigravity (AI / Pair Programming)  
**Approver & Project Manager:** Alex Araújo  
**Status:** Approved by Project Manager & Documentation Synchronized  

---

## 1. Context and Objective of this Record

This document establishes the chronological decision repository inside the `docs/` folder. It consolidates:
1. The preliminary technical assessment conducted by the AI regarding modeling fragilities, ambiguities, and architectural misalignments in the FECITEL system.
2. Every comment, complementary business rule, and strategic directive provided by the Project Manager across `context.md`, `rules.md`, `database.md`, and `design.md`.
3. The approved roadmap for updating and restructuring the technical documentation.

---

## 2. Complete Catalog of Manager Directives and Comments

### 2.1. Directives on `context.md`
*   **Directive 1 (Complete Multi-Event Independence):**
    > *"The events must be independent. Multiple simultaneous events can occur, with independent organizing committees, evaluators, managed projects, and participants. Adjust the description to meet this requirement clearly."*
*   **Directive 2 (Mandatory Advisor Consent Flow):**
    > *"In your initial analysis, you indicated that the advisor needs to give consent to the project. Adjust the descriptions in the .md files to meet this rule."*
*   **Directive 3 (Temporal Event Locking):**
    > *"Adjust the description in the .md files so that the system does not allow data editing for events that have already ended. Use the event end date as its closure date. After this date, no further changes to event data are allowed."*

---

### 2.2. Directives on `database.md` (Fragilities 1 to 7)
*   **Fragility 1 (Linking Subarea to Project):**
    > *"Add `subarea_id INT REFERENCES sub_areas(id)` to the `projects` table so that knowledge areas and subareas are properly linked and normalized for dashboards and balanced allocations."*
*   **Fragility 2 (Multi-Role Support):**
    > *"Replace the static single role column with the associative table `user_roles(person_id, role_id, event_id)` to allow participants (e.g. teachers) to act as both Advisor and Evaluator."*
*   **Fragility 3 (Dual Badge Code Architecture):**
    > *"Unify identification using two codes on each badge: 1 QR Code to identify the project (used by evaluators at the fair booth), and 1 unique Barcode per person to identify the participant and record on-site presence, meal kit delivery, and participant kits."*
*   **Fragility 4 (Event-Specific Kit and T-Shirt Logistics):**
    > *"Link kit delivery and t-shirt sizes to the event edition via `event_participants`, preserving the history of previous editions intact."*
*   **Fragility 5 (Evaluator Allocation in Two Moments):**
    > *"Create `evaluator_allocations` supporting two distinct allocation moments:
    > i) Main automated balanced allocation right after check-in, matching subareas, respecting quotas, and ensuring allocation differences between projects in the same subarea do not exceed 1.
    > ii) Manual allocation by event administrators under any circumstance."*
*   **Fragility 6 (Master-Detail Evaluation & Single General Feedback):**
    > *"Model evaluations in a master-detail structure with a single consolidated feedback field at the end of the evaluation. Maintain dual criteria descriptions (`scientific_description` and `technological_description`), where at least one must be populated."*
*   **Fragility 7 (Universal Soft Delete):**
    > *"Hard delete is strictly prohibited. Include `deleted_at: Optional[datetime] = None` in all database tables and adopt standardized soft delete filtering in all queries."*

---

### 2.3. Directives on `design.md`
*   **Architecture Realignment:**
    > *"Replace Node.js/Express/Prisma with Python 3.11+, FastAPI, SQLAlchemy 2.0 (async), and Pydantic v2. Adopt a simplified direct-service layered architecture without unnecessary folder sprawl."*
*   **Complete Frontend Specification:**
    > *"Add a clear, complete, and consistent frontend specification covering Next.js 14+, screen list, mobile-first design, and the 3-step visual quality workflow (Mockups -> Prototype -> Next.js)."*
*   **Performance & Scalability Solutions:**
    > *   *N+1 Elimination:* Batch email lookups (`WHERE email IN (...)`) in a single transaction.
    > *   *Kit Race Condition:* Conditional atomic update (`UPDATE ... SET kit_delivered = TRUE WHERE ... AND kit_delivered = FALSE RETURNING tshirt_size`).
    > *   *Real-Time Dashboard Indexing:* Composite indexes `(project_id, evaluator_id)`.
    > *   *Heavy File Uploads:* Middleware file size limits (`max_body_size`), MIME validation, and streaming.
*   **Development Optimizations:**
    > *   *Project States:* Complete lifecycle machine (`DRAFT` to `EVALUATED`).
    > *   *Final Score Calculation:* Simple arithmetic average of all completed reviews, without discarding scores.
    > *   *File Settings:* Pre-configured during event registration.
    > *   *HTTP Status Standardization:* Standard codes (`200`, `201`, `204`, `409`, `422`).
    > *   *RBAC:* Strict least-privilege scoping per role.

---

### 2.4. Supplementary Directives (English Standards & Participant Login)
*   **English Language Standard:** All file names, variable names, folders, database tables, and code artifacts must strictly follow the English language.
*   **Participant 8-Character Login Code:** Regular participants authenticate via an 8-character unique uppercase code (`YY` + 4 letters + 2 numbers) sent by email, stored hashed in `people.access_code_hash`, and rendered as a masked password field in the login UI.
*   **File Organization:** Move `.md` files into designated project folders (e.g., `.agents/rules.md`, `docs/context.md`, `docs/database.md`, `docs/design.md`).
