# Documentação Técnica: Expansão dos Níveis de Ensino (Graduação, Pós-Graduação e Reestruturação Fundamental I e II) — EasyEvent

**Data:** 13 de Setembro de 2026  
**Status:** Implementado & Validado  
**Regras de Referência:** Regra BR-04 (Configuração de Níveis de Ensino por Edição), Regra BR-25 (Distinção de Níveis para Avaliadores) e Regra BR-26 (Importação em Lote via CSV)  
**Módulos Impactados:** `apps/backend` (Enums, Validação de Cotas, Mapeamento CSV, Testes), `apps/frontend-admin` (Tipagem, Utilitários CSV, Páginas de Eventos, Participantes, Projetos, Avaliadores e Resultados), `docs` (`database.md`, `context.md`).

---

## 1. Contexto e Motivação

Historicamente, feiras e mostras científicas atendiam primordialmente à Educação Básica (Ensino Fundamental e Médio/Técnico). Com a expansão do EasyEvent para instituições federais e universidades (ex: IFMS, UFMS, UEMS), eventos acadêmicos integrados passaram a receber também trabalhos de:
- **Graduação / Ensino Superior** (Iniciação Científica - PIBIC/PIBITI, Trabalhos de Conclusão de Curso);
- **Pós-Graduação** (Especialização, Mestrado e Doutorado).

Adicionalmente, no âmbito da Educação Básica, a divisão tradicional entre "Júnior" e "Fundamental" gerava ambiguidades operacionais. A nomenclatura foi harmonizada para **Ensino Fundamental I** (anos iniciais, 1º ao 5º ano) e **Ensino Fundamental II** (anos finais, 6º ao 9º ano).

---

## 2. Estrutura dos 5 Níveis de Ensino

O sistema consolida 5 categorias padronizadas de nível de ensino:

| Chave Enum / DB | Nomenclatura Oficial no Sistema | Descrição e Abrangência Escolar/Acadêmica | Cota Máx. Alunos | Orientador Titular |
| :--- | :--- | :--- | :---: | :---: |
| **`JUNIOR`** | **Ensino Fundamental I** | Anos iniciais do Ensino Fundamental (1º ao 5º ano) | 5 alunos | Obrigatório (min 1) |
| **`FUNDAMENTAL`** | **Ensino Fundamental II** | Anos finais do Ensino Fundamental (6º ao 9º ano) | 5 alunos | Obrigatório (min 1) |
| **`MEDIO`** | **Ensino Médio / Técnico** | Ensino Médio Propedêutico e Técnico Integrado/Subsequente | 4 alunos | Obrigatório (min 1) |
| **`GRADUACAO`** | **Graduação / Superior** | Bacharelados, Licenciaturas e Tecnólogos | 5 alunos | Obrigatório (min 1) |
| **`POS_GRADUACAO`** | **Pós-Graduação** | Lato Sensu (Especialização) e Stricto Sensu (Mestrado/Doutorado) | 4 alunos | Obrigatório (min 1) |

> [!NOTE]
> **Preservação de Retrocompatibilidade:**  
> Os valores do enum no banco de dados para os níveis fundamentais foram mantidos como `JUNIOR` e `FUNDAMENTAL`. Dessa forma, todos os registros históricos de eventos, projetos e avaliações permanecem 100% íntegros, sem necessidade de migrações destrutivas de dados. A camada de apresentação (Frontend e CSVs) cuida da rotulagem amigável para "Ensino Fundamental I" e "Ensino Fundamental II".

---

## 3. Alterações no Backend (`apps/backend`)

### 3.1 Definição do Enum (`app/models/enums.py`)
```python
class EducationLevelEnum(str, enum.Enum):
    MEDIO = "MEDIO"
    FUNDAMENTAL = "FUNDAMENTAL"
    JUNIOR = "JUNIOR"
    GRADUACAO = "GRADUACAO"
    POS_GRADUACAO = "POS_GRADUACAO"
```

### 3.2 Validação de Cotas e Regras Regimentais (`app/services/project_service.py`)
A função `validate_quotas_and_advisors` agora contempla os limites regimentais estipulados para os 5 níveis:
- **`JUNIOR` (Fundamental I):** até 5 estudantes;
- **`FUNDAMENTAL` (Fundamental II):** até 5 estudantes;
- **`MEDIO`:** até 4 estudantes;
- **`GRADUACAO`:** até 5 estudantes;
- **`POS_GRADUACAO`:** até 4 estudantes;
- Todos os níveis exigem pelo menos 1 orientador com papel `ADVISOR` na equipe.

### 3.3 Normalização Resiliente na Ingestão de Trabalhos (`app/api/v1/endpoints/projects.py`)
Ao importar projetos via CSV, o backend processa o campo textual `raw_level` mapeando variações comuns:
- `"graduacao"`, `"superior"`, `"graduação"` $\rightarrow$ `EducationLevelEnum.GRADUACAO`
- `"pos"`, `"pos-graduacao"`, `"pos_graduacao"`, `"pós"`, `"pós-graduação"` $\rightarrow$ `EducationLevelEnum.POS_GRADUACAO`
- `"junior"`, `"júnior"`, `"fundamental 1"`, `"fundamental i"`, `"fundamental_1"` $\rightarrow$ `EducationLevelEnum.JUNIOR`
- `"fundamental"`, `"fundamental 2"`, `"fundamental ii"`, `"fundamental_2"` $\rightarrow$ `EducationLevelEnum.FUNDAMENTAL`
- `"medio"`, `"médio"`, `"tecnico"`, `"técnico"` $\rightarrow$ `EducationLevelEnum.MEDIO`

---

## 4. Alterações no Frontend Admin (`apps/frontend-admin`)

### 4.1 Tipagem TypeScript (`src/types/index.ts`)
```typescript
export type EducationLevel = "MEDIO" | "FUNDAMENTAL" | "JUNIOR" | "GRADUACAO" | "POS_GRADUACAO";
```

### 4.2 Utilitários e Modelos CSV
1. **`src/utils/participantCsv.ts`:**
   - Atualizado o arquivo de exemplo para download com linhas demonstrando os 5 níveis de ensino na coluna `niveis_ensino`.
   - Normalização em `parseEducationLevels` para reconhecer `"Fundamental I"`, `"Fundamental II"`, `"Graduação"`, `"Pós-Graduação"`, `"Superior"`, `"Médio"` e correlatos.
2. **`src/utils/projectsCsv.ts`:**
   - Função `parseEducationLevel` atualizada para retornar `EducationLevel` compatível com os 5 níveis.

### 4.3 Módulos e Telas Atualizadas
- **Edições do Evento (`/events`):** Formulários de cadastro e edição de feiras agora incluem os checkboxes de ativação dos 5 níveis, bem como a parametrização de cotas de alunos e mínimo de avaliadores por nível. Cards de feira exibem badges com rótulos amigáveis.
- **Participantes (`/participants` e Modal CSV):** Gestão de níveis habilitados para avaliadores, com cores e badges distintas para cada um dos 5 níveis.
- **Trabalhos (`/projects`):** Filtros rápidos e colunas de listagem com labels atualizadas ("Ensino Fundamental I", "Ensino Fundamental II", "Ensino Médio / Técnico", "Graduação / Superior", "Pós-Graduação").
- **Avaliadores (`/evaluators`):** Seleção de filtro por nível e visualização de chips de restrição em detalhes de avaliador.
- **Resultados e Premiações (`/results`):** Filtro de apuração e agrupamento do Ranking Geral 1 suportando todas as 5 categorias.

---

## 5. Validação e Qualidade

1. **Testes Automatizados do Backend:**
   - Adicionado teste específico em `apps/backend/tests/test_evaluator_education_levels.py`:
     - `test_evaluator_graduacao_and_pos_graduacao_levels`: valida a restrição estrita de alocação de avaliadores habilitados exclusivamente para `GRADUACAO` e `POS_GRADUACAO`, bem como a recusa de alocações cruzadas.
   - Execução da suíte completa de testes: **50 testes executados, 50 aprovados com 100% de sucesso**.
2. **Build e Análise Estática do Frontend:**
   - Executados `npx tsc --noEmit` e `npm run build`: **0 erros de tipagem**, 18 páginas estáticas compiladas com sucesso.
