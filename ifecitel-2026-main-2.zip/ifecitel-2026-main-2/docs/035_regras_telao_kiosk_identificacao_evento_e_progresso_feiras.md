# 035 — Regras do Telão TV Kiosk: Identificação Soberana de Eventos (BR-20) e Cálculo Oficial de Progresso por Cota de Avaliadores (BR-21)

**Data:** 12/09/2026 10:00  
**Autor:** Antigravity (Pair Programming com Alex Araújo)  
**Status:** Implementado, Documentado e Validado  
**Módulos Impactados:** `apps/backend`, `apps/frontend-admin`, `apps/frontend-kiosk`, `docs/context.md`, `walkthrough.md`  
**Regras de Negócio:** BR-14 (Sigilo de Notas no Telão), BR-19 (Seleção de Evento Ativo), BR-20 (Identificação de Evento no Admin e URL do Kiosk) e BR-21 (Cálculo de Progresso por Cota Mínima de Avaliadores)

---

## 1. Visão Geral e Contexto

No ambiente de realização da feira científica (FECITEL), a comissão organizadora e o público utilizam telas e painéis com propósitos distintos:
1. **Coordenação no Painel Administrativo (`apps/frontend-admin`):** Precisa ter clareza absoluta sobre qual edição está gerenciando, qual é o identificador numérico único (`ID`) daquele evento e dispor de atalhos rápidos para enviar a URL de exibição para os operadores de Smart TVs e projetores do pavilhão.
2. **Telão Público TV Kiosk (`apps/frontend-kiosk`):** Exibição em alta visibilidade (1080p / 4K) voltada a estudantes, orientadores e visitantes, acompanhando em tempo real o andamento das avaliações das bancadas por Grande Área do Conhecimento, com garantia estrita de sigilo regulamentar (Regra BR-14).

Com a evolução da feira e a diversidade de áreas temáticas (Ciências Exatas, Biológicas, Engenharias, Humanas, Linguística, Multidisciplinar, etc.), tornou-se imperativo:
- **Maximizar o espaço visual:** Remover caixas de texto explicativas estáticas da área central da TV para permitir que todas as Grandes Áreas caibam simultaneamente na tela sem rolagem.
- **Fidelidade regulamentar no progresso:** Substituir multiplicadores genéricos ou hardcoded (`* 2`) pela cota mínima real de avaliadores (`min_evaluators`) parametrizada para cada nível de ensino nas configurações do evento.

---

## 2. Regra BR-20: Identificação Soberana de Evento no Admin e URL Paramétrica do Kiosk

### 2.1 Identificação do ID do Evento no Painel Admin
A partir desta especificação, toda tela de gerenciamento de evento no Painel Administrativo deve exibir de forma inequívoca o identificador numérico oficial do evento:
1. **Tela de Visão Geral (`/`):**
   - No banner superior de edição ativa, exibe o selo em destaque: `ID: #{activeEvent.id}`.
   - Card dedicado de integração com o Telão TV Kiosk contendo:
     - URL paramétrica completa gerada dinamicamente: `http://<host>:3003/?event_id=${activeEvent.id}`.
     - Botão de **Copiar Link** com feedback tátil e visual para envio via WhatsApp ou e-mail à equipe técnica do pavilhão.
     - Botão **Abrir Telão** para visualização imediata em nova aba (`target="_blank"`).
2. **Tela de Edições de Eventos (`/events`):**
   - O banner de edição ativa exibe o selo `ID: #{activeEvent.id}` e atalho direto *"Ver no Telão TV"*.
   - Em cada card ou linha de evento cadastrado na lista paginada, exibe o selo `ID: #{event.id}` ao lado do ano da edição e um botão de ação com ícone de TV para abrir a exibição daquele evento diretamente no Kiosk.

### 2.2 Suporte a Múltiplos Telões por URL Paramétrica
- O Telão TV Kiosk suporta nativamente a parametrização de evento via query string: `/?event_id=X` ou `/tv?event_id=X`.
- Isso permite a operação de múltiplos telões ou projetores no pavilhão de forma independente:
  - Telão do Ginásio Central: `http://192.168.1.13:3003/?event_id=1` (FECITEL Principal)
  - Telão do Hall da Feira Júnior: `http://192.168.1.13:3003/?event_id=2` (FECITEC Júnior)
- Se nenhuma URL paramétrica for informada, o sistema mantém o fallback inteligente para o primeiro evento ativo (ou mais recente cadastrado).

---

## 3. Regra BR-21: Cálculo Oficial de Progresso por Cota Mínima de Avaliadores (`min_evaluators` / `max_projects_per_evaluator`)

### 3.1 Fundamentação Regulamentar
Nas diretrizes acadêmicas da FECITEL, o regulamento define cotas de pareceres por trabalho conforme configurado no evento e por Nível de Ensino (`EducationLevel`):
- O limite e cota de avaliadores por projeto é parametrizado no cadastro do evento (`events.max_projects_per_evaluator` — ex.: 3 avaliadores na edição ativa) ou nas diretrizes por nível (`education_levels.min_evaluators`).
- O sistema nunca deve utilizar valores fixos ou hardcoded (como 2) no código. Ele obtém a cota configurada dinamicamente no banco de dados para a respectiva edição.

### 3.2 Fórmula Oficial de Apuração Server-Side
O backend (`apps/backend/app/services/dashboard_service.py`) calcula as metas e percentuais reais consultando a configuração do evento:

1. **Cota de Avaliações por Trabalho:**
   $$\text{Cota}(p) = \text{EducationLevel}(p.\text{education\_level}).\text{min\_evaluators} \quad \text{ou} \quad \text{event.max\_projects\_per\_evaluator}$$
   *(Puxada dinamicamente do banco de dados para o `event_id` correspondente).*

2. **Universo de Projetos Alvo:**
   - Durante a feira (com credenciamento em andamento), o cálculo baseia-se nos **projetos presentes nas bancadas** (`PRESENT`, `UNDER_EVALUATION`, `EVALUATED`).
   - Caso o credenciamento presencial ainda não tenha sido iniciado no início da manhã (`total_present_projects == 0`), utiliza provisoriamente os projetos inscritos como estimativa de planejamento.

3. **Meta Consolidada da Feira:**
   $$\text{Meta Global de Avaliações} = \sum_{p \in \text{Projetos Alvo}} \text{Cota}(p)$$

4. **Percentual de Progresso Consolidado:**
   $$\text{Progresso Global (\%)} = \min\left(100.0, \text{round}\left(\frac{\text{Avaliações Concluídas}}{\text{Meta Global de Avaliações}} \times 100, 1\right)\right)$$

5. **Meta e Progresso Individual por Grande Área (Opção 1C):**
   Para cada Grande Área do Conhecimento:
   $$\text{Meta da Área} = \sum_{p \in \text{Projetos da Área Presentes}} \text{Cota}(p)$$
   $$\text{Progresso da Área (\%)} = \min\left(100.0, \text{round}\left(\frac{\text{Avaliações Concluídas na Área}}{\text{Meta da Área}} \times 100, 1\right)\right)$$
   Cada card de área exibe simultaneamente:
   - Quantidade de projetos: *"X presentes de Y inscritos"*
   - Quantidade de pareceres: *"W de Z avaliações esperadas"*

### 3.3 Apuração Fidedigna de Avaliadores Credenciados e Presentes (Múltiplos Papéis - Doc 024)
Na FECITEL, um professor/pesquisador pode atuar como orientador ou coorientador em projetos e simultaneamente ser credenciado como avaliador na edição (Regra BR-24 / Doc 024).
- O papel base da pessoa na tabela `people` pode estar configurado como `ADVISOR` ou `COADVISOR`.
- A habilitação como avaliador na edição é registrada na tabela `event_participant_roles` (`role = 'EVALUATOR'`).
- O check-in específico de avaliador na recepção/sala de jurados grava `EventParticipant.evaluator_presence_confirmed = True` e seu respectivo timestamp `evaluator_presence_confirmed_at`.

Para garantir que nenhum avaliador credenciado ou presente seja omitido no telão da TV:
1. **Avaliadores Credenciados (`total_registered_evaluators`):**
   Considera qualquer participante do evento que cumpra ao menos uma das condições:
   - `Person.role == UserRole.EVALUATOR`
   - Registro ativo em `event_participant_roles` com `role == UserRole.EVALUATOR` para o evento
   - Check-in de avaliador confirmado (`EventParticipant.evaluator_presence_confirmed == True`)
2. **Avaliadores Presentes (`total_present_evaluators`):**
   Conta os participantes com check-in de avaliador homologado no evento (`EventParticipant.evaluator_presence_confirmed == True`).
3. **Alunos e Orientadores (`registered_students_advisors` e `present_students_advisors`):**
   Segmenta com precisão quem atua como discente ou docente/orientador, vinculando a presença geral da bancada (`EventParticipant.presence_confirmed == True`).

### 3.4 Schema Atualizado do Endpoint `GET /api/v1/dashboard/public-tv`
```json
{
  "event_id": 391,
  "event_name": "Fecitel do Alex",
  "total_registered_participants": 450,
  "total_present_participants": 320,
  "total_registered_students_advisors": 410,
  "total_present_students_advisors": 295,
  "total_registered_evaluators": 40,
  "total_present_evaluators": 25,
  "total_registered_projects": 45,
  "total_present_projects": 40,
  "total_evaluations_completed": 36,
  "min_evaluators_default": 3,
  "total_expected_evaluations": 120,
  "evaluation_progress_percent": 30.0,
  "areas_progress": [
    {
      "area_id": 1,
      "area_name": "Ciências Exatas e da Terra",
      "total_projects": 12,
      "present_projects": 10,
      "evaluations_completed": 18,
      "expected_evaluations": 30,
      "progress_percent": 60.0
    }
  ],
  "updated_at": "2026-09-12T10:00:00Z"
}
```

---

## 4. Expansão de Espaço Visual e Reestruturação do Telão TV Kiosk

### 4.1 Reestruturação dos 4 Cards Superiores (Opção 4B)
Os cartões métricos superiores foram reformulados para foco estrito nas informações essenciais de dia de feira:
1. **Card 1: Projetos em Bancada:**
   - Cabeçalho: Título *"Projetos em Bancada"* à esquerda e ícone institucional à direita.
   - Corpo: Valor principal `total_present_projects` em destaque ao lado do **Medidor Circular SVG Ampliado** com percentual de presença dos projetos.
   - Subtexto: `de {total_registered_projects} inscritos`.
   - Badge: `Em Bancada` (Accent Azul).
2. **Card 2: Participantes Presentes:**
   - Cabeçalho: Título *"Participantes Presentes"* à esquerda e ícone institucional à direita.
   - Corpo: Valor principal `total_present_students_advisors` (apenas estudantes e orientadores com presença confirmada) ao lado do **Medidor Circular SVG Ampliado** com percentual de presença de alunos e orientadores.
   - Subtexto: `de {total} alunos e orientadores`.
   - Badge: `Alunos & Orientadores` (Accent Verde Água/Teal).
3. **Card 3: Avaliadores Presentes (Substitui "Pareceres"):**
   - Cabeçalho: Título *"Avaliadores Presentes"* à esquerda e ícone institucional à direita.
   - Corpo: Valor principal `total_present_evaluators` (presença confirmada na Sala dos Avaliadores) ao lado do **Medidor Circular SVG Ampliado** com percentual de presença dos jurados.
   - Subtexto: `de {total} credenciados`.
   - Badge: `Corpo de Jurados` (Accent Âmbar).
4. **Card 4: Progresso da Feira:**
   - Cabeçalho: Título *"Progresso da Feira"* à esquerda e ícone institucional à direita.
   - Corpo: Percentual consolidado oficial (`${progressPercent}%`) ao lado do **Medidor Circular SVG Ampliado** com o percentual de andamento geral da feira.
   - Subtexto: `{concluídas} de {esperadas} avaliações esperadas`.
   - Badge: `Geral` (Accent Roxo/Índigo).

### 4.2 Medidores Circulares SVG Ampliados de Alta Visibilidade (Opção 4B)
Para garantir nitidez e legibilidade mesmo a longas distâncias no pavilhão da feira (Smart TVs e projetores 1080p e 4K):
- **Deslocamento do Topo para o Corpo:** Os medidores circulares foram retirados do cabeçalho dos cartões (onde competiam por espaço com o título) e alocados no **corpo central do card**, posicionados harmoniosamente ao lado dos números gigantes de quantidade.
- **Dimensões Ampliadas:** Dimensões substancialmente maiores (`88x88px`, viewBox `"0 0 88 88"`, raio $r=35$), com trilha de fundo translúcida (`strokeWidth=6`) e anel de progresso preenchido proporcionalmente (`strokeWidth=6.5`).
- **Valor Percentual Central Nítido:** O percentual numérico (`text-sm sm:text-base xl:text-lg font-black font-mono text-white`) é exibido com alto contraste no centro do círculo.
- **Brilho Temático (Glow Effect):** Cada medidor possui filtro de sombra/brilho suave (`drop-shadow`) na cor de destaque do cartão (`blue`, `teal`, `amber`, `purple`), oferecendo visual de painel de controle aeroespacial/cockpit de alto impacto.

### 4.3 Grid Responsivo Dinâmico de 2 a 4 Colunas com Opção 1C
O componente `AreaProgressGrid` ocupa 100% da largura útil da tela (`w-full`):
- **Smart TVs Full HD (1080p):** 3 colunas (`lg:grid-cols-3`).
- **Projetores de Grande Porte e Smart TVs 4K:** 4 colunas (`xl:grid-cols-4`).
- Cada cartão exibe:
  - Ícone temático da área e nome completo.
  - Badge percentual de progresso.
  - Barra de progresso horizontal em gradiente suave.
  - Linha de métricas duplas (Opção 1C):
    - Esquerda: `X presentes de Y inscritos`
    - Direita: `W de Z avaliações esperadas`

---

## 5. Roteiro de Verificação e Testes

1. **Testes Automatizados de Backend:**
   ```bash
   cd apps/backend && .venv/bin/pytest tests/test_phase3.py -v
   ```
   Valida que `total_registered_evaluators`, `total_present_evaluators`, `present_projects`, `min_evaluators_default` e campos de área são apurados com integridade e sem violação de sigilo (Regra BR-14).

2. **Testes de Compilação Estrita TypeScript:**
   ```bash
   cd apps/frontend-admin && npx tsc --noEmit
   cd apps/frontend-kiosk && npx tsc --noEmit
   ```
   Zero erros de tipagem em ambos os frontends.

3. **Validação Visual no Navegador:**
   - **Admin:** `http://localhost:3001` -> Verificar selo `ID: #{activeEvent.id}` e botões de atalho para a TV.
   - **Kiosk:** `http://localhost:3003/?event_id=391` -> Verificar os 4 cards com medidores circulares SVG (Opção 4B) e as áreas com presentes/inscritos e avaliações esperadas (Opção 1C).
