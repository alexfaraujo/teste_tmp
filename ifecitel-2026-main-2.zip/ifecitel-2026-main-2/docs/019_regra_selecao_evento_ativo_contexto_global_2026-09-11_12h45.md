# Registro Cronológico: Regra BR-19 — Seleção Obrigatória de Evento Ativo e Contexto Global de Gerenciamento

**Data e Hora:** 2026-09-11 12:45:00 -04:00  
**Autor:** Antigravity (AI / Pair Programming)  
**Revisor & Gestor:** Alex Araújo  
**Status:** Decisão Soberana do Gestor Aprovada e Integrada às Regras do Projeto

---

## 1. Contexto e Motivação Operacional

Durante os testes de validação da **Fase 2 (Gestão Estrutural)** no Painel Administrativo, o Gestor do Projeto (Alex Araújo) deliberou sobre a experiência de uso quando o sistema possui múltiplos eventos ou edições anuais:

> *"quando o usuario possui varios eventos (ou edições do evento) ele tem que selecionar um evento para gerenciar por vez. na tela de Edições de evento ele tem que ter opção de escolher qual evento deseja editar e gerenciar naquele momento, e as demais paginas so ficam ativas após ele selecionar o evento. Enquanto o usuario nao ir na tela Edições do Evento e escolher outro evento, o evento escolhido anteriormente deve ficar ativo em todas as paginas."*

---

## 2. Especificação da Regra BR-19

### 2.1 Princípios Obrigatórios:
1. **Seleção Prévia Obrigatória na Tela de Edições (`/events`):**
   - O administrador deve escolher expressamente qual edição deseja gerenciar clicando no botão **"Gerenciar este Evento"** em seu respectivo card na tela `/events`.
   - O card da edição ativa ganha destaque visual imediato (borda e anel azuis, fundo realçado e botão indicativo "Edição Selecionada").
   - Um banner superior na tela `/events` exibe de forma destacada a edição atualmente em operação.

2. **Contexto Global Persistente:**
   - A edição selecionada é gravada no armazenamento local seguro do navegador (`localStorage` sob a chave `fecitel_active_event`).
   - Todas as páginas e requisições subsequentes assumem automaticamente essa edição ativa como contexto operacional.
   - O contexto sobrevive a recarregamentos de página (F5), fechamento de abas e navegação entre módulos.
   - A edição escolhida **permanece ativa em todas as páginas** até que o usuário retorne explicitamente à tela `/events` e clique em "Gerenciar este Evento" em outra edição.

3. **Bloqueio de Páginas Dependentes (Gating / Trava de Proteção):**
   - As demais páginas operacionais que dependem de um evento (Painel de Visão Geral `/`, Áreas do Conhecimento `/areas`, e futuramente `/projects`, `/evaluators`, `/allocations`, `/results`) **permanecem inativas** se nenhuma edição tiver sido selecionada.
   - O componente de guarda `<RequireActiveEvent>` intercepta o acesso e apresenta um card explicativo amigável informando a necessidade de seleção prévia e oferecendo um atalho direto para a tela de Edições.

4. **Identificação Visual Contínua no Layout:**
   - O Navbar e a Sidebar exibem continuamente a badge com o nome e o ano da edição ativa.
   - Um atalho claro ("Trocar Edição") permite ao administrador voltar à tela de seleção a qualquer momento com um único clique.

5. **Ações Independentes na Tela de Edições (`/events`):**
   - **Gerenciar Edição:** Torna a edição ativa globalmente no painel.
   - **Editar Parâmetros:** Abre modal para ajuste de nome, datas e tetos da feira (desabilitado com ícone de cadeado e aviso caso a edição esteja encerrada por trava temporal, em obediência à Regra BR-02).

---

## 3. Aplicação Imediata
- **Frontend Admin (`apps/frontend-admin/`):**
  - Criação do contexto React `EventContext.tsx` e hook `useActiveEvent()`.
  - Criação do componente reutilizável `RequireActiveEvent.tsx`.
  - Inclusão do `<EventProvider>` no layout raiz do dashboard (`apps/frontend-admin/src/app/(dashboard)/layout.tsx`).
  - Atualização do Navbar e Sidebar com identificação da edição ativa.
  - Atualização da tela de Edições (`/events`) com banner superior, botões de ação e modal de edição.
  - Proteção da tela de Áreas (`/areas`) e Dashboard (`/`) com o componente de guarda.

---

## 4. Métricas de Esforço
- `% Feito por IA:` 25% (desenvolvimento dos componentes React, context provider, modal de edição e integração com localStorage)
- `% Híbrido:` 15% (arquitetura de gating de rotas e consistência de feedback visual)
- `% Participação Humana:` 60% (concepção da regra de usabilidade pelo Gestor Alex Araújo)
