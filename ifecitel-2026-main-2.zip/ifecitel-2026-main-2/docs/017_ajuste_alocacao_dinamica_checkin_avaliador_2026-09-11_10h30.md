# Registro Cronológico: Ajuste da Alocação de Avaliadores — Credenciamento Paralelo Contínuo e Alocação Dinâmica no Check-in (Regra BR-10)

**Data e Hora:** 2026-09-11 10:30:00 -04:00  
**Autor:** Antigravity (AI / Pair Programming)  
**Revisor & Gestor:** Alex Araújo  
**Status:** Especificação Aprovada e Integrada ao Backend

---

## 1. Contexto e Motivação Operacional

Nas diretrizes originais, a distribuição balanceada de avaliadores (Momento 1) previa um ponto de corte temporal ("encerramento do credenciamento") para rodar o algoritmo em lote.

O Gestor do Projeto esclareceu o funcionamento real e prático das feiras científicas:
1. **Credenciamento Paralelo e Contínuo:**
   - Uma equipe de recepção realiza o check-in dos estudantes/autores de forma contínua durante todo o evento (promovendo projetos para `PRESENT` à medida que chegam).
   - Outra equipe de recepção realiza o check-in dos avaliadores também de forma contínua durante o evento.
   - Não há interrupção ou barreira temporal que force aguardar a chegada de todos os trabalhos para iniciar a distribuição de avaliadores.
2. **Momento Ideal da Alocação Automática:**
   - O instante ideal de distribuição é **no exato momento em que a organização realiza o check-in presencial do avaliador**.
   - Nesse milissegundo, o sistema avalia os trabalhos da subárea do avaliador que já estão presentes (`status = 'PRESENT'`), seleciona prioritariamente os trabalhos com menor número de avaliadores atribuídos, e realiza a alocação imediata até a capacidade máxima do evento (`max_projects_per_evaluator`), respeitando a Regra de Ouro ($\Delta \le 1$) e impedindo conflitos de interesse.

---

## 2. Especificação da Alocação Dinâmica por Check-in do Avaliador

### 2.1 Algoritmo de Alocação no Check-in (`allocate_evaluator_on_checkin`)
Quando o avaliador realiza seu check-in presencial (seja bipando o crachá no guichê `/api/v1/logistics/scan-barcode`, seja via endpoint administrativo `/api/v1/allocations/evaluators/{id}/checkin`):
1. **Confirmação de Presença:** Registra `presence_confirmed = True` e `presence_confirmed_at = now` em `event_participants`.
2. **Identificação de Competências:** Busca as subáreas temáticas cadastradas do avaliador no evento (`person_subareas`).
3. **Cálculo de Capacidade:**
   $$\text{Capacidade Restante} = \text{max\_projects\_per\_evaluator} - \text{Alocações Ativas do Avaliador}$$
   Se a capacidade for $\le 0$, encerra sem criar novas alocações.
4. **Mapeamento de Trabalhos Presentes Candidatos:**
   - Filtra projetos do evento com `status = 'PRESENT'` cuja `subarea_id` pertença às subáreas do avaliador.
   - Exclui projetos com **conflito de interesse** (onde o avaliador é orientador, coorientador ou aluno integrante).
   - Exclui projetos onde o avaliador **já possui alocação**.
5. **Critério Guloso de Equidade (Menor Carga Primeiro):**
   - Para cada projeto candidato, calcula a quantidade de avaliadores ativos já atribuídos a ele.
   - Ordena os trabalhos candidatos por:
     1. Quantidade de avaliadores já alocados (ordem crescente: quem tem menos avaliadores vem primeiro);
     2. `project.id` (desempate determinístico).
6. **Criação Atômica das Alocações:**
   - Seleciona os primeiros $K$ projetos (onde $K = \min(\text{Capacidade Restante}, \text{Candidatos Elegíveis})$).
   - Cria os registros em `evaluator_allocations` com:
     - `allocation_type = AllocationType.AUTOMATIC_CHECKIN`
     - `status = AllocationStatus.PENDING`
     - `allocated_at = datetime.now(timezone.utc)`
7. **Retorno Detalhado:**
   - Retorna o número de trabalhos alocados e os dados dos projetos vinculados para exibição imediata no painel da recepção.

---

## 3. Arquitetura em Três Vias de Operação
* **Via 1: Bipagem de Código de Barras (`POST /api/v1/logistics/scan-barcode`):**
  - Se o código lido for de um participante com papel `EVALUATOR` (ou possuir qualificações em `person_subareas`), o serviço automaticamente dispara a alocação dinâmica além de marcar a presença e liberar o kit.
* **Via 2: Ação Administrativa Direta (`POST /api/v1/allocations/evaluators/{evaluator_id}/checkin`):**
  - Permite aos organizadores no painel administrativo clicar em "Credenciar e Alocar" para qualquer avaliador da lista sem necessidade de leitor físico.
* **Via 3: Rebalanceamento Global Mantido (`POST /api/v1/allocations/auto-balance`):**
  - Permanece disponível para a coordenação disparar equalizações globais caso trabalhos tardios entrem no pavilhão.
