# 042 — Geração de Modelo Esqueleto CSV e Importação em Lote de Trabalhos Científicos

## 1. Contexto & Objetivo
No módulo de **Trabalhos Científicos e Homologação** (`/projects`) do **EasyEvent Admin**, os organizadores gerenciam a submissão, membros da equipe de projeto, validação de anuência do orientador (**BR-05**), homologação documental (**BR-06**) e alocação de estandes para a feira.

Para atender feiras de todos os portes — com diferentes regulamentos quanto ao número de estudantes/autores por projeto e oriundas de diferentes sistemas de inscrição (Google Forms, planilhas internas de escolas, etc.) —, foi implementada a **importação em lote com modelo esqueleto dinâmico CSV (Opção A - Colunas Horizontais Flexíveis)**:
1. **Download de Modelo Esqueleto CSV Dinâmico:** Geração do arquivo modelo `.csv` com as subáreas temáticas reais cadastradas na edição ativa do evento.
2. **Importação em Lote com Pré-visualização Interativa:** Leitor e parser tolerante a variações de cabeçalhos e delimitadores, com mapeamento automático de participantes (orientadores e até 10 autores), resolução inteligente de subáreas, alocação de estande e opção de auto-homologação direta.

---

## 2. Estrutura do Arquivo CSV Modelo

O modelo é codificado em **UTF-8 com BOM (`\uFEFF`)** e utiliza como delimitador padrão o ponto e vírgula (`;`), garantindo perfeita abertura direta em Microsoft Excel e Google Planilhas em qualquer sistema operacional (Windows, macOS, Linux).

### Cabeçalho Oficial:
```csv
titulo;tipo;nivel;subarea;estande;resumo;orientador_nome;orientador_email;coorientador_nome;coorientador_email;autor1_nome;autor1_email;autor2_nome;autor2_email;autor3_nome;autor3_email;autor4_nome;autor4_email
```

### Detalhamento das Colunas:
| Coluna | Obrigatória? | Descrição | Exemplo |
| :--- | :---: | :--- | :--- |
| `titulo` | **Sim** | Título do trabalho científico ou tecnológico (mínimo 3 caracteres) | `Desenvolvimento de Braço Robótico Sustentável` |
| `tipo` | Opcional | Modalidade do trabalho: `Científico` ou `Tecnológico` (padrão `Científico`) | `Tecnológico` |
| `nivel` | Opcional | Nível de ensino: `Médio`, `Fundamental` ou `Júnior` (padrão `Médio`) | `Médio` |
| `subarea` | Opcional | Nome da subárea temática do trabalho cadastrada no evento | `Robótica e Automação` |
| `estande` | Opcional | Código de identificação do estande/bancada na feira | `A-01` |
| `resumo` | Opcional | Resumo textual ou descrição do projeto | `Protótipo robótico de baixo custo...` |
| `orientador_nome` | **Sim** | Nome completo do Orientador formal do trabalho (Regra BR-05) | `Prof. Carlos Silva` |
| `orientador_email` | Opcional* | E-mail do orientador para login e anuência digital | `carlos.silva@escola.edu.br` |
| `coorientador_nome` | Opcional | Nome do coorientador do projeto (se houver) | `Profa. Mariana Costa` |
| `coorientador_email` | Opcional* | E-mail do coorientador | `mariana.costa@escola.edu.br` |
| `autor1_nome` | **Sim** | Nome do autor principal / líder estudantil (Regra BR-04) | `Lucas Almeida` |
| `autor1_email` | Opcional* | E-mail do autor 1 para credencial de acesso | `lucas.almeida@aluno.edu.br` |
| `autor2_nome` .. `autorN_nome` | Opcional | Nome dos demais estudantes coautores (suporta até 10 autores) | `Beatriz Santos` |
| `autor2_email` .. `autorN_email` | Opcional* | E-mail dos demais estudantes coautores | `beatriz.santos@aluno.edu.br` |

*\* Se o e-mail não for informado, o EasyEvent gera um endereço corporativo local único (`slug@aluno.easyevent.local` ou `slug@orientador.easyevent.local`), garantindo que nenhum participante fique sem credencial e código de barras para credenciamento.*

---

## 3. Arquitetura de Importação & Regras de Negócio

### 3.1 Parser Flexível & Mapeamento Inteligente (`utils/projectsCsv.ts`)
*   **Detecção de Delimitador:** Identifica automaticamente ponto e vírgula (`;`), vírgula (`,`) ou tabulação (`\t`).
*   **Identificação Flexível de Autores:** Reconhece colunas no padrão `autor1_nome`, `autor2_nome` ou colunas simplificadas `autor1`, `autor2`, `estudante1`, `aluno1`, permitindo que cada feira importe seus trabalhos independentemente de quantos alunos componham cada grupo (de 1 a 10 estudantes).
*   **Vínculo Inteligente de Subárea:** Busca a melhor correspondência de nome entre a coluna do CSV e as subáreas ativas da edição (correspondência exata ou por substring case-insensitive). Caso não encontre, adota a primeira subárea disponível da feira.
*   **Líder Estudantil Automático:** O primeiro autor da lista recebe o papel `STUDENT_LEADER`, e os autores seguintes recebem `STUDENT_MEMBER`.

### 3.2 Modal Interativo com Pré-visualização (`ProjectsCsvImportModal.tsx`)
*   **Dropzone com Arraste e Solte:** Suporte a arquivos `.csv`.
*   **Contadores Estatísticos:** Exibe quantidade de itens totais, novos, atualizações e registros com erros.
*   **Opção de Auto-Homologação:** Checkbox que permite importar os trabalhos já aprovados (`HOMOLOGATED`) com estandes confirmados para montagem imediata da feira, ou deixá-los pendentes (`PENDING_HOMOLOGATION`) para conferência manual.
*   **Tabela de Auditoria Linha a Linha:** Tabela com badges de status, identificação de orientadores, coorientadores e resumo da lista de autores.

### 3.3 Serviço e Transação Atômica no Backend (`POST /projects/batch`)
*   **Multi-tenant & Autorização:** Protegido por API Key e restrito aos administradores e organizadores da edição (`require_event_role(EventAdminRole.ORGANIZER)`).
*   **Criação/Recuperação de Participantes:** Para cada orientador ou estudante, o sistema verifica se a pessoa já existe pelo e-mail; se não existir, cria o registro em `Person` e gera o `EventParticipant` correspondente com código de barras único para crachá (`BC-XXXXX`).
*   **Idempotência / Upsert:** Se um trabalho com o mesmo título já existir no evento, seus dados básicos (tipo, nível de ensino, estande, resumo) e sua composição de membros são sincronizados.
*   **Atomicidade:** Executado em uma única transação assíncrona SQLAlchemy (`await db.commit()`). Em caso de erro imprevisto, sofre rollback integral.

---

## 4. Endpoints Disponibilizados

1. `GET /api/v1/projects/template-csv?event_id={id}`: Retorna arquivo `.csv` modelo preenchido com as subáreas reais do evento ativo.
2. `POST /api/v1/projects/batch?event_id={id}`: Processa a importação em lote a partir do payload estruturado enviado pelo frontend.
3. `POST /api/v1/projects/upload-csv?event_id={id}&auto_homologate={bool}`: Endpoint multipart para upload direto de arquivos `.csv` via automação ou scripts externos.

---

## 5. Garantia da Qualidade & Testes
*   **Testes Automatizados de Backend (`test_projects_csv.py`):**
    *   `test_projects_csv_template_and_batch_import`: valida download do esqueleto, criação atômica em lote com membros e auto-homologação.
    *   `test_projects_upload_csv_file`: valida upload direto de arquivo `.csv` multipart contendo caracteres especiais, acentuação e alocação de estandes.
*   **Resultados de Execução:**
    *   Testes Backend: **43/43 testes aprovados** (100% de sucesso).
    *   Tipagem TypeScript: `npx tsc --noEmit` aprovado sem qualquer erro.
    *   Build de Produção Next.js: `npm run build` gerado com sucesso para todas as 18 rotas.
