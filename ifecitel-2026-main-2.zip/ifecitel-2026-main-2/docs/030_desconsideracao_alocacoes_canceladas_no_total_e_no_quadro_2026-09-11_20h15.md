# Registro de Alterações: Desconsideração de Alocações Canceladas na Métrica Total e no Quadro de Alocações

**Data:** 11/09/2026 - 20h15  
**Autor:** Antigravity  
**Contexto:** Correção de métricas operacionais e aprimoramento de usabilidade no módulo de alocação de avaliadores.

---

## 1. Contexto e Motivação

Na tela de gerenciamento de avaliadores (`/evaluators`), o card indicador de **Total de Alocações** exibia o tamanho total do array de alocações retornado da API, incluindo alocações com status `CANCELLED`. Isso causava inconsistência visual: quando o administrador cancelava uma alocação, o número do card permanecia inalterado.

Além disso, no **Quadro de Alocações de Avaliação** (tabela geral), a listagem padrão (`statusFilter === "ALL"`) misturava alocações ativas e canceladas. O objetivo desta melhoria é garantir que:
1. O card **Total de Alocações** contabilize estritamente alocações ativas (`status !== "CANCELLED"`), com menção informativa ao número de canceladas quando houver.
2. O **Quadro de Alocações de Avaliação** oculte alocações canceladas por padrão, exibindo-as **exclusivamente** quando o usuário selecionar o filtro explícito `"Cancelada"`.
3. Alocações já canceladas não apresentem o botão de cancelamento (lixeira).
4. O backend valide tentativas de re-cancelamento e suporte filtro opcional por `status` na rota `GET /api/v1/allocations`.

---

## 2. Alterações Realizadas

### 2.1 Frontend Admin (`/evaluators`)
- **Arquivo:** [`apps/frontend-admin/src/app/(dashboard)/evaluators/page.tsx`](file:///Users/alexaraujo/Documents/Fecitel-Alex-Rogerio/apps/frontend-admin/src/app/(dashboard)/evaluators/page.tsx)
  - **Métricas:** Criados seletores reativos:
    - `activeAllocations`: filtra alocações onde `a.status !== "CANCELLED"`.
    - `cancelledAllocationsCount`: contagem de alocações com `a.status === "CANCELLED"`.
  - **Card "Total de Alocações":**
    - Exibe `activeAllocations.length`.
    - Subtítulo exibe `{completedAllocationsCount} avaliações concluídas` e, caso haja cancelamentos, adiciona `· {cancelledAllocationsCount} cancelada(s)`.
  - **Filtro de Status no Quadro:**
    - Opção padrão renomeada para `"Todas as Ativas"` (`ALL`).
    - Lógica de filtro:
      - `statusFilter === "ALL"`: exibe apenas `a.status !== "CANCELLED"`.
      - `statusFilter === "CANCELLED"`: exibe apenas `a.status === "CANCELLED"`.
      - `statusFilter === "PENDING" | "COMPLETED"`: exibe o status específico.
  - **Descrição do Quadro (`CardDescription`):**
    - Alterna dinamicamente entre `Mostrando X de Y alocações ativas no evento.` e `Mostrando X de Y alocações canceladas no evento.`
  - **Ações na Tabela:**
    - Botão de lixeira (cancelar) condicionado estritamente a `alloc.status === "PENDING"`.
- **Arquivo:** [`apps/frontend-admin/src/services/allocation.service.ts`](file:///Users/alexaraujo/Documents/Fecitel-Alex-Rogerio/apps/frontend-admin/src/services/allocation.service.ts)
  - Adicionado parâmetro opcional `status?: string` em `listAllocations`.

### 2.2 Backend API (`/allocations`)
- **Arquivo:** [`apps/backend/app/services/allocation_service.py`](file:///Users/alexaraujo/Documents/Fecitel-Alex-Rogerio/apps/backend/app/services/allocation_service.py)
  - `list_allocations`: adicionado parâmetro opcional `status: Optional[str] = None` com filtro na query `stmt.where(EvaluatorAllocation.status == status)`.
  - `cancel_allocation`: adicionada validação `if alloc.status == AllocationStatus.CANCELLED: raise HTTPException(400, "Esta alocação já se encontra cancelada.")`.
- **Arquivo:** [`apps/backend/app/api/v1/endpoints/allocations.py`](file:///Users/alexaraujo/Documents/Fecitel-Alex-Rogerio/apps/backend/app/api/v1/endpoints/allocations.py)
  - Adicionado `status: Optional[str] = Query(None)` no endpoint `GET /api/v1/allocations`.
- **Arquivo:** [`apps/backend/tests/test_phase4.py`](file:///Users/alexaraujo/Documents/Fecitel-Alex-Rogerio/apps/backend/tests/test_phase4.py)
  - Adicionados testes automatizados cobrindo rejeição de re-cancelamento e filtragem de listagem por `status=CANCELLED` e `status=PENDING`.

---

## 3. Verificação e Testes

1. **Testes do Backend (Pytest):**
   - Suíte de 33 testes executada com 100% de sucesso (`33 passed`).
2. **Typecheck do Frontend:**
   - `npx tsc --noEmit` executado com **0 erros**.
3. **Servidor Frontend:**
   - Rota `/evaluators` respondendo com **200 OK**.
