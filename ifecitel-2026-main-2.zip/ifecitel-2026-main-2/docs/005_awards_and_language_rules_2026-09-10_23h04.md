# Registro Cronológico de Decisão Técnica e Modelagem: CRUD de Prêmios, Vínculo de Critérios e Padronização de Idiomas

**Data e Hora:** 2026-09-10 23:04  
**Autor:** Antigravity (Pair Programming com Alex Araújo - Gestor do Projeto)  
**Status:** Aprovado e Incorporado à Documentação Oficial  
**Documento Sequencial:** `docs/005_awards_and_language_rules_2026-09-10_23h04.md`

---

## 1. Contexto e Diretrizes do Gestor do Projeto

Em alinhamento com as determinações do Gestor do Projeto (Alex Araújo), foram consolidadas três diretrizes mandatórias:

1.  **Gestão de Áreas e Subáreas no Painel do Administrador:** O cadastro e manutenção de áreas do conhecimento e suas respectivas subáreas devem ser realizados diretamente no **Painel de Controle do Administrador do Evento** (`apps/frontend-admin/`), com escopo atrelado à edição ativa (`knowledge_areas.event_id`).
2.  **CRUD de Prêmios e Amarração com Perguntas da Avaliação:** Inclusão do módulo de gerenciamento de premiações (prêmios especiais, troféus de patrocinadores, menções honrosas) com a funcionalidade de **vincular quais perguntas/critérios da ficha de avaliação (`evaluation_criteria`) compõem a nota do prêmio cadastrado**, permitindo a apuração e classificação automática dos concorrentes.
3.  **Ajuste e Clarificação da Regra de Idiomas (Código em Inglês; Documentação e Sistema em Português):**
    *   **Código-Fonte e Banco de Dados (Estritamente em Inglês):** Nomes de variáveis, constantes, funções, métodos, classes, arquivos de código (`.py`, `.ts`), modelos ORM, tabelas (`events`, `projects`, `awards`, `award_criteria`), colunas, chaves estrangeiras, endpoints RESTful e payloads JSON devem ser estritamente em **inglês**.
    *   **Documentação (.md), Interface Gráfica e Mensagens (Estritamente em Português):** Todos os arquivos de documentação markdown (`docs/`, `.agents/rules.md`), telas da aplicação web, botões, modais, mensagens de erro, notificações, e-mails enviados aos participantes e relatórios devem ser estritamente em **português (pt-BR)**.
    *   **Tradução Integral dos `.md`:** Todos os arquivos da documentação que continham seções ou redação em inglês foram traduzidos e reestruturados em português.

---

## 2. Invariantes e Novas Regras de Negócio (BR-16 e BR-17)

### BR-16: Áreas e Subáreas no Painel do Administrador do Evento
*   Módulo integrado ao menu `/admin/knowledge-areas` do painel administrativo.
*   Permite criação, edição e desativação lógica de áreas e subáreas por edição de evento.
*   Restrição `UNIQUE(event_id, name)` para áreas e `UNIQUE(area_id, name)` para subáreas.
*   Trava de integridade: exclusão bloqueada se houver projetos ou avaliadores vinculados.

### BR-17: CRUD de Prêmios e Associação de Questões da Avaliação
*   Módulo integrado ao menu `/admin/awards` do painel administrativo.
*   Criação de premiações com nome, descrição, patrocinador/parceiro e edição do evento (`UNIQUE(event_id, name)`).
*   Checklist interativo de perguntas da ficha (`evaluation_criteria`) associadas via tabela associativa `award_criteria`, com peso opcional (`weight`).
*   O sistema apura automaticamente a classificação por prêmio calculando a média dos projetos considerando exclusivamente os critérios designados.
*   Classificações e notas permanecem sob sigilo restrito à coordenação no painel administrativo até a cerimônia oficial.

---

## 3. Matriz de Arquivos Modificados e Traduzidos

| Arquivo | Idioma Anterior | Idioma Atual | Ajustes Realizados |
| :--- | :---: | :---: | :--- |
| [`.agents/rules.md`](file:///Users/alexaraujo/Documents/Fecitel-Alex-Rogerio/.agents/rules.md) | Inglês | **Português** | Tradução completa; clarificação da regra de idiomas (código em inglês, docs/UI em português); inclusão formal das regras `BR-16` e `BR-17`. |
| [`docs/context.md`](file:///Users/alexaraujo/Documents/Fecitel-Alex-Rogerio/docs/context.md) | Inglês | **Português** | Tradução completa; inclusão dos itens 10 (Áreas no Painel Admin) e 11 (Prêmios e Vínculo de Questões); remoção de áreas de "Fora de Escopo". |
| [`docs/database.md`](file:///Users/alexaraujo/Documents/Fecitel-Alex-Rogerio/docs/database.md) | Inglês | **Português** | Tradução completa da prosa e dicionários; manutenção de tabelas/colunas em inglês; adição de `event_id` em `knowledge_areas`, tabelas `awards` e `award_criteria`, novos relacionamentos no ERD e índices de alta performance. |
| [`docs/design.md`](file:///Users/alexaraujo/Documents/Fecitel-Alex-Rogerio/docs/design.md) | Inglês | **Português** | Tradução completa da prosa e telas; manutenção de endpoints e tokens em inglês; especificação das telas `/admin/knowledge-areas` e `/admin/awards` com checklist de critérios; adição de 8 rotas RESTful para premiações. |
| [`docs/003_full_system_specification_report_2026-09-09_10h51.md`](file:///Users/alexaraujo/Documents/Fecitel-Alex-Rogerio/docs/003_full_system_specification_report_2026-09-09_10h51.md) | Português | **Português** | Atualizado com a nova regra de idiomas na seção 2.2; adição de prêmios nas capacidades centrais, telas do admin, ERD, endpoints e checklist final. |

---

## 4. Novas Entidades do Banco de Dados (`PostgreSQL`)

```sql
-- Premiações vinculadas ao evento
CREATE TABLE awards (
    id SERIAL PRIMARY KEY,
    event_id INT NOT NULL REFERENCES events(id),
    name VARCHAR(150) NOT NULL,
    description TEXT NULL,
    sponsor VARCHAR(150) NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMP WITH TIME ZONE NULL,
    CONSTRAINT uq_awards_event_name UNIQUE (event_id, name)
);

-- Amarração de perguntas/critérios da avaliação ao prêmio
CREATE TABLE award_criteria (
    id SERIAL PRIMARY KEY,
    award_id INT NOT NULL REFERENCES awards(id),
    criterion_id INT NOT NULL REFERENCES evaluation_criteria(id),
    weight DECIMAL(5,2) NOT NULL DEFAULT 1.0,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMP WITH TIME ZONE NULL,
    CONSTRAINT uq_award_criteria UNIQUE (award_id, criterion_id)
);

-- Índices estratégicos
CREATE INDEX idx_awards_event ON awards(event_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_award_criteria_lookup ON award_criteria(award_id, criterion_id) WHERE deleted_at IS NULL;
```

---

## 5. Endpoints RESTful para Premiações (`/api/v1/awards`)

```http
GET    /api/v1/events/{id}/awards                    # Lista prêmios do evento com critérios associados
POST   /api/v1/events/{id}/awards                    # Cadastra premiação no evento
GET    /api/v1/awards/{id}                           # Detalhes do prêmio e perguntas de notas vinculadas
PUT    /api/v1/awards/{id}                           # Atualiza dados do prêmio
DELETE /api/v1/awards/{id}                           # Soft delete do prêmio
POST   /api/v1/awards/{id}/criteria                  # Associa pergunta/critério com peso
DELETE /api/v1/awards/{id}/criteria/{criterion_id}   # Desassocia pergunta/critério do prêmio
GET    /api/v1/awards/{id}/standings                 # Apuração dos projetos com base nas questões do prêmio
```
