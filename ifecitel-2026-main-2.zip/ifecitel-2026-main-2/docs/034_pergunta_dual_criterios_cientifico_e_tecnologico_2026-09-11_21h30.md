# 034 — Arquitetura de Pergunta Dual por Tipo de Trabalho nos Critérios de Avaliação

**Data:** 11/09/2026 21:30  
**Autor:** Antigravity (Pair Programming com Alex Araújo)  
**Status:** Implementado, Documentado e Validado  
**Módulos Impactados:** `apps/backend`, `apps/frontend-admin`, `docs/database.md`, `docs/context.md`, `docs/design.md`  
**Regras de Negócio:** BR-11 (Parecer Consolidado e Ficha de Notas), BR-12 (Apuração por Média Aritmética) e BR-17 (Premiações Específicas)

---

## 1. Visão Geral e Regra de Negócio

Nas feiras científicas e tecnológicas do IFMS (como a FECITEL), os trabalhos concorrentes são classificados em duas grandes modalidades metodológicas:
1. **Trabalhos Científicos (`SCIENTIFIC`):** Guiados pelo método científico tradicional (formulação de hipótese, experimentos laboratoriais/de campo, isolamento e controle de variáveis, tabulação e análise de dados quantitativos ou qualitativos).
2. **Trabalhos Tecnológicos (`TECHNOLOGICAL`):** Guiados pela engenharia e pelo desenvolvimento tecnológico (identificação de uma demanda/problema prático real, especificação de requisitos, projeto e prototipagem de soluções de software/hardware, testes de usabilidade e viabilidade técnica/econômica).

### A Regra da Pergunta Dual Unificada:
A fim de manter a equidade e a consistência na régua avaliativa da feira:
- Cada **Critério de Avaliação** cadastrado pelo administrador na edição ativa (`evaluation_criteria`) representa um **item avaliativo unificado** da ficha de notas.
- Cada critério possui **duas formulações de pergunta / enunciado**:
  - `scientific_description`: A pergunta a ser exibida quando o projeto avaliado for **Científico**.
  - `technological_description`: A pergunta a ser exibida quando o projeto avaliado for **Tecnológico**.
- **Equivalência Estrutural:**
  - **Mesma Pontuação Máxima (`max_score`):** Ex: 10.0 pontos.
  - **Mesmo Peso Padrão na Ficha (`weight`):** Ex: 1.0x ou 2.0x.
  - **Mesma Ordem / Posição na Ficha:** A posição ordinal de cada pergunta é idêntica para qualquer projeto.
- **Seleção Dinâmica em Tempo de Execução:** O aplicativo mobile do avaliador (`apps/frontend-evaluator`) consome a rota `GET /api/v1/evaluations/sheet/{project_id}`. O backend detecta automaticamente o `project.project_type` e entrega o enunciado correto para aquela pergunta.

### Flexibilidade para Eventos com Tipo Único de Trabalho:
- Na prática de feiras acadêmicas e mostras científicas, nem todas as edições separam os trabalhos em categorias científicas e tecnológicas distintas.
- Para eventos que não possuem essa divisão:
  - **Classificação Unificada:** Todos os trabalhos concorrentes são tratados pelo sistema sob o tipo `SCIENTIFIC` padrão.
  - **Opção de Tipo Único no Frontend:** Na tela de cadastro de critérios (`/criteria`), o administrador pode marcar o checkbox *"Evento com tipo único de trabalho (sem distinção entre Científico e Tecnológico)"*.
  - **Replicação Automática da Pergunta:** Ao marcar essa opção, a interface simplifica o formulário exibindo um único campo de pergunta, e o sistema preenche automaticamente tanto `scientific_description` quanto `technological_description` com o mesmo texto.
  - **Garantia de Coerência:** Independentemente de como um trabalho seja alocado ou consultado na API, a ficha mobile sempre entregará essa mesma pergunta unificada para o avaliador.

---

## 2. Modelagem no Banco de Dados (`evaluation_criteria`)

A tabela `evaluation_criteria` já possuía os campos necessários desde a concepção da Fase 2, e agora está formalmente documentada com a mecânica dual:

```sql
CREATE TABLE evaluation_criteria (
    id SERIAL PRIMARY KEY,
    event_id INT NOT NULL REFERENCES events(id),
    name VARCHAR(200) NOT NULL,                  -- Identificador do critério (ex: "Critério 1: Rigor Metodológico / Projeto")
    scientific_description TEXT NOT NULL,         -- Pergunta para trabalhos Científicos
    technological_description TEXT NOT NULL,       -- Pergunta para trabalhos Tecnológicos
    max_score DECIMAL(5,2) NOT NULL DEFAULT 10.0, -- Nota máxima compartilhada
    weight DECIMAL(5,2) NOT NULL DEFAULT 1.0,    -- Peso padrão compartilhado
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP WITH TIME ZONE NULL
);
```

---

## 3. Seleção Dinâmica no Backend (`evaluation_service.py`)

No método `get_evaluation_sheet`, o serviço da API seleciona a descrição com fallback simétrico:

```python
sheet_criteria: List[EvaluationCriterionSheetItem] = []
for c in criteria:
    # Descrição/pergunta adaptada dinamicamente ao tipo de projeto (científico vs tecnológico)
    desc = (
        (c.scientific_description or c.technological_description)
        if project.project_type == ProjectType.SCIENTIFIC
        else (c.technological_description or c.scientific_description)
    ) or ""

    sheet_criteria.append(
        EvaluationCriterionSheetItem(
            criterion_id=c.id,
            name=c.name,
            description=desc,
            max_score=float(c.max_score),
            weight=float(c.weight),
            current_score=existing_scores.get(c.id)
        )
    )
```

Assim, para o avaliador presencial, a ficha mobile apresenta uma experiência transparente, exibindo o enunciado perfeitamente contextualizado ao projeto que está na bancada.

---

## 4. Experiência e Validação no Frontend Admin (`/criteria`)

A tela de gestão de critérios (`apps/frontend-admin/src/app/(dashboard)/criteria/page.tsx`) foi aperfeiçoada com as seguintes diretrizes:

1. **Banner Didático no Topo da Página:**
   - Explica com clareza aos coordenadores da comissão julgadora as duas modalidades operacionais (distinção metodológica com pergunta dual vs. tipo único de trabalho com pergunta unificada).
2. **Cards de Critérios da Listagem:**
   - Se o critério possuir perguntas idênticas (`scientific_description === technological_description`), exibe um bloco destacado de **"Pergunta Unificada (Tipo Único de Trabalho)"**.
   - Se possuir formulações distintas, exibe as duas caixas visuais contrastantes:
     - 🔬 **Pergunta para Trabalhos Científicos** (`scientific_description` em tons de azul)
     - ⚙️ **Pergunta para Trabalhos Tecnológicos** (`technological_description` em tons de teal/esmeralda)
   - Selos com Nota Máxima (`10.0 pts`) e Peso (`1.0x`).
3. **Modal de Cadastro e Edição (UX-01):**
   - Callout orientador dinâmico.
   - Campo `Identificador / Título do Critério *`.
   - Campos numéricos unificados de `Pontuação Máxima *` e `Peso Padrão na Ficha *`.
   - **Checkbox de Tipo Único de Trabalho:** Alterna entre o modo de pergunta única e o modo de pergunta dual.
   - **Validação de Formulário:** No modo tipo único, valida a pergunta unificada; no modo dual, valida ambas as perguntas específicas.

---

## 5. Validação e Qualidade

- **Testes Backend:** 35 testes unitários e de integração aprovados com 100% de sucesso (`.venv/bin/pytest tests/ -v`).
- **Verificação de Tipos Frontend:** `npx tsc --noEmit` executado com 0 erros.
- **Documentação de Modelagem:** Atualizados `docs/database.md`, `docs/context.md`, `docs/design.md` e gerado o presente relatório.
