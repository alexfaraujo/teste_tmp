# Registro Cronológico: Validação Estrita de Subárea na Atribuição Manual e Exibição Hierárquica de Áreas (Regra BR-10)

* **Data:** 11 de setembro de 2026, 17h05
* **Branch:** `develop`
* **Regras de Negócio Envolvidas:** BR-10 (Alocação Dinâmica e Remanejamento de Avaliadores), BR-16 (Integridade de Áreas e Subáreas), UX-01 (Prevenção de Falhas de Usabilidade).

---

## 1. Contexto e Motivação

Durante a validação operacional do sistema em ambiente real, foram identificadas duas necessidades fundamentais para a integridade científica da feira:

1. **Ausência de validação de subárea na alocação manual:**
   * O algoritmo de alocação dinâmica contínua no check-in (Momento 1) já respeitava rigorosamente as subáreas cadastradas do avaliador (`PersonSubarea`).
   * No entanto, o endpoint de alocação manual/remanejamento (`POST /api/v1/allocations/manual` - Momento 2) validava apenas conflito de interesses (orientador/aluno) e duplicidade, permitindo que administradores vinculassem manualmente projetos a avaliadores de subáreas totalmente divergentes ou a pessoas sem nenhuma subárea cadastrada.

2. **Necessidade de filtragem proativa e exibição hierárquica na interface:**
   * No modal de alocação manual (`/evaluators`), o usuário precisava digitar manualmente o ID do avaliador no escuro e o seletor de trabalhos listava todos os projetos do evento indiscriminadamente.
   * Ademais, eventos científicos frequentemente possuem subáreas com o mesmo nome sob Grandes Áreas distintas (ex: *"Metodologia"*, *"Educação"*, *"Sistemas"*). A exibição isolada de `subarea_name` causava ambiguidade visual.

---

## 2. Regras de Negócio Implementadas

### 2.1 Bloqueio Rígido no Backend (BR-10 Momento 2)
No serviço [`allocation_service.py:manual_allocate`](file:///Users/alexaraujo/Documents/Fecitel-Alex-Rogerio/apps/backend/app/services/allocation_service.py):
1. **Validação de Papel:** Exige que o participante possua o papel `EVALUATOR` atribuído na edição do evento (`EventParticipantRole` ou `Person.role`).
2. **Exigência de Qualificação Prévia:** Verifica se o avaliador possui subáreas vinculadas na tabela `person_subareas` para o evento ativo. Se a lista estiver vazia, rejeita a alocação com `HTTP 400 Bad Request`.
3. **Correspondência Exata de Subárea:** Exige estritamente que `project.subarea_id` pertença ao conjunto de `subarea_id` do avaliador. Se houver divergência, rejeita com `HTTP 400 Bad Request`, informando a subárea e área mãe do projeto e o nome do avaliador incompatível.
4. **Preservação das Demais Travas:** Mantém a checagem de conflito de interesses (orientador/coorientador/autor) e bloqueio de alocações ativas duplicadas.

### 2.2 Endpoint Dedicado para Seleção de Avaliadores (`GET /api/v1/allocations/evaluators`)
Criado novo endpoint administrativo que retorna todos os avaliadores cadastrados na edição com:
* Dados cadastrais (ID, Nome, E-mail, CPF, Código de barras);
* Status de presença geral e presença confirmada na Sala dos Avaliadores;
* Contagem em tempo real de projetos já alocados;
* Lista completa de subáreas qualificadas, contendo `subarea_id`, `subarea_name`, `area_id` e `area_name`.

### 2.3 Interface Proativa de Alocação Manual no Frontend (`/evaluators`)
* **Seletor de Avaliadores:** Dropdown dinâmico alimentado pelo endpoint acima, exibindo nome, e-mail e quantidade de subáreas.
* **Tags de Subáreas Habilitadas:** Ao selecionar o avaliador, exibe badges no formato `{Área Geral} > {Subárea}`.
* **Filtragem Reativa de Trabalhos:** O dropdown de trabalhos é instantaneamente filtrado para exibir **apenas** os projetos pertencentes às subáreas daquele avaliador (`evaluatorSubareaIds.includes(project.subarea_id)`), informando no rótulo `#{p.id} — {p.title} ({p.area_name} > {p.subarea_name}) [Estande: X]`.
* **Mensagens de Orientação:** Exibe alertas claros caso o avaliador não possua subáreas vinculadas (com atalho para a tela de Participantes) ou se não houver trabalhos cadastrados nas suas subáreas.

### 2.4 Exibição Hierárquica (`Área Geral > Subárea`)
Em conformidade com a solicitação do usuário, a visualização foi estendida:
* **Tabela de Alocações (`/evaluators`):** Coluna de subárea exibe a Subárea em destaque e a Grande Área logo abaixo.
* **Check-in da Sala dos Avaliadores (`/evaluators/checkin`):** Cartões de trabalhos dinamicamente atribuídos exibem `Subárea: {Área} > {Subárea}`.
* **Listagem de Trabalhos (`/projects`):** Coluna de especialidade exibe a Subárea e a Área Mãe (propriedade `@property def area_name` adicionada ao modelo `Project`).
* **Detalhes do Participante (`/participants`):** Badges de subáreas qualificadas formatadas como `{Área} > {Subárea}`.

---

## 3. Arquivos Modificados e Criados

| Módulo | Arquivo | Modificação Realizada |
| :--- | :--- | :--- |
| **Backend Model** | `apps/backend/app/models/project.py` | Adicionada `@property def area_name(self)` |
| **Backend Model** | `apps/backend/app/models/knowledge_area.py` | Adicionada `@property def area_name(self)` no modelo `Subarea` |
| **Backend Schema** | `apps/backend/app/schemas/knowledge_area.py` | Campo `area_name` em `SubareaResponse` |
| **Backend Schema** | `apps/backend/app/schemas/allocation.py` | `area_name` em `AllocationResponse`/`AllocatedProjectItem`; criados `EvaluatorListItem` e `EvaluatorSubareaItem` |
| **Backend Service** | `apps/backend/app/services/allocation_service.py` | Validação estrita de subárea em `manual_allocate`, `area_name` em responses e implementação de `list_event_evaluators` |
| **Backend Endpoint** | `apps/backend/app/api/v1/endpoints/allocations.py` | Rota `GET /api/v1/allocations/evaluators` |
| **Backend Tests** | `apps/backend/tests/test_phase4.py` | Asserções de alocação com subárea divergente (400) e teste do endpoint de avaliadores |
| **Backend Tests** | `apps/backend/tests/test_phase5.py` | Vinculação correta de subáreas para avaliador de múltiplos projetos |
| **Frontend Types** | `apps/frontend-admin/src/types/index.ts` | Tipagens `EvaluatorListItem`, `EvaluatorSubareaItem`, `area_name` |
| **Frontend Service**| `apps/frontend-admin/src/services/allocation.service.ts` | Método `getEvaluators(eventId)` |
| **Frontend Page** | `apps/frontend-admin/src/app/(dashboard)/evaluators/page.tsx` | Seletor de avaliador, filtragem reativa de trabalhos e exibição hierárquica na tabela |
| **Frontend Page** | `apps/frontend-admin/src/app/(dashboard)/evaluators/checkin/page.tsx` | Formatação `Área > Subárea` nos cartões de projetos |
| **Frontend Page** | `apps/frontend-admin/src/app/(dashboard)/participants/page.tsx` | Formatação `Área > Subárea` nos detalhes do participante |
| **Documentação** | `docs/context.md` | Inclusão da Regra 18 de bloqueio de subárea e exibição hierárquica |
| **Documentação** | `docs/database.md` | Atualização da descrição e regras de negócio da tabela `person_subareas` |

---

## 4. Verificação e Testes Automatizados

* **Pytest Suite (`.venv/bin/pytest tests/ -v`):** 33 testes executados e **100% aprovados**.
* **Frontend TypeCheck (`npx tsc --noEmit`):** Executado com sucesso, **0 erros** de compilação ou tipagem.
* **Servidores Ativos:** Backend FastAPI (porta 8000) e Frontend Admin Next.js (porta 3001) saudáveis e operacionais.
