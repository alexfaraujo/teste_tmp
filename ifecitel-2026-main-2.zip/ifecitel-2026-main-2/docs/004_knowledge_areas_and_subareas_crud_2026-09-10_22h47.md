# Registro Cronológico de Decisão Técnica e Modelagem: CRUD de Áreas e Subáreas do Conhecimento

**Data e Hora:** 2026-09-10 22:47  
**Autor:** Antigravity (Pair Programming com Alex Araújo - Gestor do Projeto)  
**Status:** Aprovado e Incorporado à Documentação Oficial  
**Documento Sequencial:** `docs/004_knowledge_areas_and_subareas_crud_2026-09-10_22h47.md`

---

## 1. Contexto e Motivação da Mudança

Durante a revisão do relatório técnico completo de especificação (`docs/003_full_system_specification_report_2026-09-09_10h51.md`), o Gestor do Projeto (Alex Araújo) identificou a necessidade expressa de que o sistema possua um **módulo dinâmico de CRUD para Áreas do Conhecimento e suas respectivas Subáreas**.

Anteriormente, o sistema previa o preenchimento dessas entidades apenas via carga inicial estática (*seed* no banco). Contudo, considerando que:
1. Cada edição da FECITEL ou feiras associadas pode abrir novas trilhas temáticas, subáreas tecnológicas emergentes (ex: Inteligência Artificial, Robótica Sustentável, Biotecnologia Pantaneira) ou adequar a categorização oficial do CNPq/CAPES;
2. A alocação balanceada de avaliadores (Momento 1 pós-check-in) depende criticamente do vínculo correto entre projetos e avaliadores por subárea (`projects.subarea_id` == `person_subareas.subarea_id`);
3. Os dashboards (incluindo o telão público Kiosk) agrupam o progresso das avaliações por grande área do conhecimento;

Ficou estabelecido que a administração do evento deve ter autonomia completa para gerenciar o catálogo de áreas e subáreas através do painel administrativo (`apps/frontend-admin/`), com proteção de integridade referencial em banco de dados.

---

## 2. Invariantes e Regras de Negócio Estabelecidas (BR-16)

Foi formalizada a regra de negócio **BR-16** em `.agents/rules.md`:

1. **Autonomia Administrativa:** Usuários com perfil `ADMIN` possuem acesso ao menu `/admin/knowledge-areas` para criar, visualizar, editar e desativar logicamente áreas e subáreas.
2. **Unicidade de Subárea por Área:** O nome de uma subárea deve ser único dentro da sua área mãe (`UNIQUE(area_id, name)`).
3. **Proteção Referencial Impeditiva de Exclusão (Soft Delete Seguro):**
   * Uma **Área do Conhecimento** não pode ser desativada se possuir subáreas ativas associadas.
   * Uma **Subárea** não pode ser desativada se estiver vinculada a qualquer projeto ativo (`projects.subarea_id`) ou qualificação de avaliador ativa (`person_subareas.subarea_id`).
   * A tentativa de exclusão de uma entidade com vínculos retorna erro explicativo (`400 Bad Request` / `409 Conflict`), impedindo inconsistências e projetos órfãos.
4. **Soft Delete Obrigatório:** Exclusões físicas (`DELETE FROM`) são estritamente proibidas. O sistema aplica marcação lógica com `deleted_at = NOW()`.

---

## 3. Matriz de Alterações Realizadas nos Arquivos do Projeto

A solicitação foi integralmente refletida nos seguintes arquivos:

| Arquivo Modificado | Seção Afetada | Detalhe da Alteração Realizada |
| :--- | :--- | :--- |
| [`.agents/rules.md`](file:///Users/alexaraujo/Documents/Fecitel-Alex-Rogerio/.agents/rules.md) | Regras de Negócio | Adicionada a regra **BR-16: Knowledge Areas and Subareas CRUD & Referential Integrity**, documentando a obrigatoriedade do CRUD e as travas de integridade referencial. |
| [`docs/context.md`](file:///Users/alexaraujo/Documents/Fecitel-Alex-Rogerio/docs/context.md) | 2. System Objectives & Out of Scope | Adicionado o item **10. Knowledge Areas & Subareas Dynamic Management (CRUD)** como requisito funcional central; **removido** o item que excluía o CRUD do escopo. |
| [`docs/database.md`](file:///Users/alexaraujo/Documents/Fecitel-Alex-Rogerio/docs/database.md) | Dicionário de Dados & Índices | Atualizadas as tabelas `knowledge_areas` e `sub_areas` com colunas de auditoria (`created_at`, `updated_at`), restrição `UNIQUE(area_id, name)`, regras de validação e criação do índice `idx_subareas_area`. |
| [`docs/design.md`](file:///Users/alexaraujo/Documents/Fecitel-Alex-Rogerio/docs/design.md) | 4.2. Telas & 5. Endpoints RESTful | Adicionada a especificação da tela **Knowledge Areas & Subareas Hub (`/admin/knowledge-areas`)** no Bloco 2 (`apps/frontend-admin/`) e a seção **5.3 com 8 endpoints RESTful** para o CRUD de áreas e subáreas. |
| [`docs/003_full_system_specification_report_2026-09-09_10h51.md`](file:///Users/alexaraujo/Documents/Fecitel-Alex-Rogerio/docs/003_full_system_specification_report_2026-09-09_10h51.md) | 3.1, 3.2, 7.1, 10, 11 | Atualizado o relatório técnico completo: inclusão no escopo (item 10), remoção de "Fora de Escopo", especificação do módulo no Admin, matriz de rotas da API e inclusão no checklist final de prontidão. |

---

## 4. Endpoints RESTful Adicionados à Especificação (`apps/backend/`)

```http
### Áreas do Conhecimento (Knowledge Areas)
GET    /api/v1/knowledge-areas                # Lista áreas com opção ?include_subareas=true
POST   /api/v1/knowledge-areas                # Cadastra nova área (valida unicidade de nome)
GET    /api/v1/knowledge-areas/{id}           # Detalhes da área e suas subáreas
PUT    /api/v1/knowledge-areas/{id}           # Atualiza nome e descrição da área
DELETE /api/v1/knowledge-areas/{id}           # Exclusão lógica (bloqueia se houver subáreas ativas)

### Subáreas (Subareas)
GET    /api/v1/knowledge-areas/{id}/subareas  # Lista subáreas da área informada
POST   /api/v1/knowledge-areas/{id}/subareas  # Cadastra nova subárea vinculada à área (UNIQUE por área)
PUT    /api/v1/subareas/{id}                  # Atualiza dados da subárea
DELETE /api/v1/subareas/{id}                  # Exclusão lógica (bloqueia se vinculada a projetos ou avaliadores)
```

---

## 5. Interface Administrativa (`apps/frontend-admin/`)

No painel administrativo, o módulo `/admin/knowledge-areas` foi projetado com a seguinte ergonomia:
1. **Estrutura em Árvore/Acordeão:** Cards expansíveis para cada grande área (ex: Engenharias, Ciências Exatas e da Terra), exibindo o total de subáreas e o somatório de projetos cadastrados.
2. **Subtabelas Rápidas:** Ao expandir a área, listam-se as subáreas com contadores de projetos e avaliadores capacitados.
3. **Ações Rápidas com Feedback:**
   * Botão "+ Nova Grande Área" e "+ Nova Subárea".
   * Edição in-line ou modal simplificado.
   * Botão de exclusão com diálogo confirmatório que consulta previamente as dependências; caso existam projetos ou avaliadores atrelados, o botão é desabilitado ou o modal exibe aviso bloqueante com a lista das entidades dependentes.
