# 050. Emissão de Adesivos/Placas com QR Code para Bancadas de Projetos em PDF e Utilitário de Limpeza de Eventos

## 1. Contexto e Motivação
Na dinâmica presencial das feiras científicas e tecnológicas (como a FECITEL), os avaliadores circulam pelos estandes utilizando smartphones para escanear o QR Code de cada projeto e abrir a ficha de avaliação digital (Regra **BR-08**).

Como o pôster/banner físico impresso pelo grupo já contém os dados detalhados do trabalho (Título completo, Nome de todos os Estudantes e Orientadores, Escola, Nível de Ensino e Instituição Organizadora), colocar essas informações no adesivo impresso colado à bancada tornaria o layout poluído e diminuiria o tamanho útil do QR Code.

Além disso, foi deliberado que o **número do estande não precisa constar no adesivo** da bancada (pois o espaço físico do estande já possui numeração no pavilhão e o trabalho é identificado unicamente pelo seu ID no sistema). A eliminação do número do estande e dos dados redundantes do banner permitiu **maximizar a área reservada ao QR Code**, garantindo leitura óptica instantânea e sem falhas mesmo a distâncias superiores a 1 metro ou sob condições desfavoráveis de iluminação.

---

## 2. Modelos de Adesivos para Impressão em Folha A4

O sistema disponibiliza dois modelos de layout de alta resolução (gerados via ReportLab com elementos vetoriais e guias de corte):

### 2.1 Modelo A5 (`a5_double` — 2 por folha A4 Retrato)
* **Orientação da Folha:** A4 Retrato ($595.28\,	ext{pt} 	imes 841.89\,	ext{pt}$).
* **Disposição:** 2 adesivos horizontais divididos no meio da folha com linha de corte tracejada central.
* **Dimensões do Adesivo:** $pprox 195\,	ext{mm} 	imes 138\,	ext{mm}$ ($555\,	ext{pt} 	imes 392\,	ext{pt}$).
* **Tamanho do QR Code:** **Gigante ($pprox 63\,	ext{mm} 	imes 63\,	ext{mm}$ ou $180\,	ext{pt}$)**.
* **Uso Recomendado:** Apresentações com grande circulação de avaliadores e leitura rápida em corredores movimentados.

### 2.2 Modelo A6 (`a6_quad` — 4 por folha A4 Paisagem)
* **Orientação da Folha:** A4 Paisagem ($841.89\,	ext{pt} 	imes 595.28\,	ext{pt}$).
* **Disposição:** 4 adesivos (quadrantes $2 	imes 2$) com linhas de corte tracejadas em cruz (vertical e horizontal).
* **Dimensões do Adesivo:** $pprox 138\,	ext{mm} 	imes 95\,	ext{mm}$ ($394\,	ext{pt} 	imes 271\,	ext{pt}$).
* **Tamanho do QR Code:** **Amplo ($pprox 47\,	ext{mm} 	imes 47\,	ext{mm}$ ou $135\,	ext{pt}$)**.
* **Uso Recomendado:** Alta economia de recursos de impressão (100 projetos são impressos em apenas 25 folhas A4).

---

## 3. Elementos Visuais do Adesivo de Bancada

Em ambos os modelos, o adesivo apresenta layout refinado e moderno em duas colunas:
1. **Cabeçalho:** Nome oficial da edição do evento (`FECITEL 2026 • IDENTIFICAÇÃO DE BANCADA`), sem logotipo (para manter o layout limpo e maximizar o espaço útil).
2. **Identificador do Trabalho / Estande:** Caixa de alto contraste com cantos arredondados exibindo o **Número / Código do Estande** (ex: `ESTANDE A-12`, `ESTANDE 105`) com tipografia de destaque (fonte 26pt bold no modelo A5 e 18pt bold no modelo A6, com auto-ajuste de escala). Caso o estande não esteja alocado, exibe `TRABALHO #ID` como fallback seguro.
3. **Área Temática e Subárea:** Grande Área do Conhecimento (em caixa alta) e Subárea Científica / Temática.
4. **Código / Token Textual:** No modelo A6 (4 por folha), o código textual do token é posicionado na coluna esquerda, logo abaixo da subárea, evitando qualquer transbordo e garantindo leitura nítida.
5. **Badges de Infraestrutura e Tipo:**
   * **Tipo do Trabalho:** `TIPO: CIENTÍFICO` ou `TIPO: TECNOLÓGICO`
   * **Ponto de Energia:** `TOMADA: SIM` (destaque âmbar) ou `TOMADA: NÃO` (cinza suave)
   * **Mesa para Protótipo:** `MESA: SIM` (destaque azul índigo) ou `MESA: NÃO` (cinza suave)
6. **Container do QR Code:** Caixa com fundo branco puro (`#FFFFFF`) e cantos arredondados contendo:
   * Título `AVALIAÇÃO DO TRABALHO` / `AVALIAÇÃO`
   * Instrução `Aponte a câmera do celular`
   * **QR Code 2D vetorial em alta resolução** gerado a partir de `project.qrcode_token`
   * Nota informativa: `Exclusivo para avaliadores cadastrados` / `Apenas avaliadores cadastrados`

---

## 4. Endpoints e Métodos de Emissão

### 4.1 Backend (FastAPI + SQLAlchemy + ReportLab)
* **Emissão em Lote:** `GET /api/v1/events/{event_id}/booth-stickers/pdf`
  * Parâmetros de Query:
    * `layout`: `a5_double` (default) ou `a6_quad`
    * `status_filter`: `homologated` (default) ou `all`
    * `area_id`: ID opcional para filtrar por Grande Área Temática
    * `sort_by`: `booth` (ordenado por estande), `id` (default), `area` ou `title`
  * Permissão: Exige perfil administrativo de `ORGANIZER` ou superior no evento.
  * Retorno: Stream binário `application/pdf` com `Content-Disposition: attachment`.
* **Emissão Individual:** `GET /api/v1/projects/{project_id}/booth-sticker/pdf`
  * Parâmetros de Query:
    * `layout`: `a5_double` (default) ou `a6_quad`
  * Permissão: Exige permissão de `ORGANIZER` no evento ao qual o projeto pertence.

### 4.2 Frontend Admin (Next.js)
* **Cadastro Manual de Novo Trabalho:** Botão `Novo Trabalho` (ícone `Plus`) e modal completo de cadastro manual na tela `/projects`, permitindo inserir título, tipo, nível de ensino, subárea, número de estande, infraestrutura (tomada/mesa), resumo, integrantes opcionais e homologação automática.
* **Modal de Emissão em Lote:** `BoothStickersModal.tsx` integrado à barra superior de `/projects`. Permite alternar entre os modelos A5 e A6, filtrar por status, selecionar a Grande Área e definir a ordem de impressão (Por Estande, Por ID, Por Área & Subárea ou Por Título).
* **Ação Individual por Linha:** Botão com ícone `QrCode` em cada linha da tabela de trabalhos na página `/projects`, realizando o download instantâneo do PDF do adesivo correspondente.

---

## 5. Utilitário de Limpeza de Banco de Dados (`limpar_banco.py`)

Foi adicionada a **Opção 10** ao utilitário interativo `scripts/limpar_banco.py`:
* **Ação:** `"Remover TODOS os Eventos (Exceto o Evento Informado)"`.
* **Funcionamento:**
  1. Lista todos os eventos cadastrados no banco de dados com ID, Nome e Ano.
  2. Solicita ao usuário o ID do evento que deve ser **preservado/mantido**.
  3. Exibe um plano de exclusão detalhado listando os eventos que serão eliminados e o evento que será mantido intacto.
  4. Exige confirmação explícita no terminal (`s` ou `sim`).
  5. Remove em cascata estrita todas as tabelas dependentes dos eventos excluídos:
     * `evaluation_items` e `evaluations`
     * `evaluator_allocations`
     * `project_members` e `projects`
     * `person_subareas`, `person_education_levels`, `event_participant_roles` e `event_participants`
     * `award_criteria`, `awards` e `evaluation_criteria`
     * `subareas`, `knowledge_areas` e `education_levels`
     * `event_administrators` e `events`
     * Pessoas órfãs (que não sejam administradores mestre e não tenham vínculo com o evento preservado).
