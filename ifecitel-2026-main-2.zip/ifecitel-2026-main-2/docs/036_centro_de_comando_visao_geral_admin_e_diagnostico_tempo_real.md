# 036 — Centro de Comando (War Room) da Visão Geral do Administrador: Diagnóstico em Tempo Real e Gestão Ágil da Feira (BR-22)

**Data:** 12/09/2026 12:45  
**Autor:** Antigravity (Pair Programming com Alex Araújo)  
**Status:** Implementado, Documentado e Validado  
**Módulos Impactados:** `apps/backend`, `apps/frontend-admin`, `docs/context.md`, `walkthrough.md`  
**Regras de Negócio Relacionadas:** BR-14 (Sigilo de Notas), BR-19 (Contexto Global de Evento), BR-20 (Identificação de Evento), BR-21 (Cálculo Oficial de Progresso por Cota) e BR-22 (Centro de Comando e Termômetro de Risco do Administrador)

---

## 1. Visão Geral e Propósito

Enquanto o **Telão TV Kiosk (`apps/frontend-kiosk`)** atende ao público externo e participantes em formato de alta visibilidade visual e sem microdetalhes confidenciais, a **Visão Geral do Administrador (`apps/frontend-admin`)** atua como uma verdadeira **War Room (Centro de Comando Operacional)** para o gestor da FECITEL.

A tela fornece:
1. **Consistência Total com o Telão:** Mantém a mesma base metodológica e fórmulas de apuração apuradas no Kiosk da TV (Doc 035).
2. **Microdetalhes Operacionais para Tomada de Decisão Imediata:**
   - Detecção de áreas com déficit de avaliadores e cálculo exato de jurados faltantes.
   - Listagem em tempo real de projetos vulneráveis (com 0 avaliadores ou abaixo da cota regulamentar).
   - Acionamento imediato de rebalanceamento algorítmico ($\Delta \le 1$), alocação manual e cadastro ágil de avaliadores.
3. **Performance e Resiliência Operacional:**
   - Agrupamento de todas as métricas em **uma única requisição HTTP (`GET /api/v1/dashboard/admin-overview`)**, eliminando round-trips dispersos.
   - Atualização automática em ciclo de 30 segundos com anel visual regressivo SVG, controle de pausa/retomada e disparo de toasts flutuantes caso ocorram eventos operacionais críticos.

---

## 2. Seleção de Arquitetura e Componentes Integrados

Com base na aprovação do usuário, a tela adota a seguinte composição:

| Código | Dimensão | Implementação |
|---|---|---|
| **1A** | Layout Geral | Painel Unificado Single-Page de Comando Executivo com barra de controle, 4 cards de topo, termômetro de áreas e tabela de projetos críticos. |
| **2A.3** | Projetos nos Estandes | Estandes ocupados (presentes de inscritos), detalhamento por status (`Sob Avaliação`, `Avaliados`, `Ausentes`) e selos de vulnerabilidade (`0 jurados` / `< cota`). |
| **2B.1 + 2B.2** | Participantes Presentes | Estudantes (presentes/inscritos), Orientadores (presentes/inscritos), total de kits entregues e taxa percentual de entrega. |
| **2C.3 + 2C.1** | Avaliadores e Capacidade | Capacidade global em avaliações vs demanda necessária, cálculo do déficit exato de avaliadores necessários, divisão por Nível (Fundamental vs Médio) e status de sala. |
| **2D.1 + 2D.2** | Progresso da Feira | Pareceres concluídos, em andamento e pendentes, ritmo operacional (avaliações/hora) e estimativa de término com base na velocidade atual. |
| **3A** | Áreas do Conhecimento | Grade de diagnóstico com "Termômetro de Risco" (Semáforos VERDE, AMARELO, VERMELHO), cálculo de déficit por área e link direto para cadastro de jurados. |
| **4A** | Projetos Críticos | Card de emergência com contadores analíticos (0 e < cota), tabela colapsável pesquisável por título/estande e botão de ação direta "Alocar". |
| **5 (Ajustado)** | Ações Rápidas | Barra superior com: 1-clique Rebalancear (Auto-Balance $\Delta \le 1$), Alocação Manual Ágil com modal pré-selecionado, e atalho para a tela oficial de participantes (`/participants?role=EVALUATOR`). |
| **6A + 6B** | Polling e Alertas | Ciclo de 30 segundos sincronizado com SVG regressivo animado, botões de Pausar/Retomar e Atualizar Agora, acompanhado de notificações flutuantes (toasts) em tempo real. |

---

## 3. Modelo Matemático e Fórmulas de Apuração

### 3.1 Termômetro de Risco por Grande Área (3A)
Para cada Grande Área temática do evento:
1. **Demanda de Avaliações:**
   $$\text{Demanda da Área} = \sum_{p \in \text{Projetos Presentes da Área}} \text{Cota}(p)$$
2. **Capacidade dos Avaliadores Presentes:**
   $$\text{Capacidade da Área} = \sum_{a \in \text{Avaliadores Presentes Aptos na Área}} \min(\text{max\_load}, \text{limite\_do\_evento})$$
3. **Classificação de Risco (Semáforo):**
   - 🟢 **VERDE (Adequada):** $\text{Capacidade da Área} \ge \text{Demanda da Área}$ (Cobertura $\ge 100\%$)
   - 🟡 **AMARELO (Atenção):** $70\% \le \frac{\text{Capacidade da Área}}{\text{Demanda da Área}} < 100\%$
   - 🔴 **VERMELHO (Crítica):** $\frac{\text{Capacidade da Área}}{\text{Demanda da Área}} < 70\%$
4. **Déficit de Avaliadores da Área:**
   $$\text{Déficit de Jurados} = \max\left(0, \left\lceil \frac{\text{Demanda da Área} - \text{Capacidade da Área}}{\text{capacidade\_média\_por\_jurado}} \right\rceil\right)$$

### 3.2 Ritmo Operacional e Previsão de Conclusão (2D.2)
- **Ritmo de Avaliações por Hora:**
  Apurado a partir do delta de pareceres finalizados nas últimas horas de feira ativa.
- **Estimativa de Conclusão:**
  $$\text{Horas Restantes} = \frac{\text{Meta Global de Avaliações} - \text{Avaliações Concluídas}}{\max(1, \text{Ritmo (avaliações/hora)})}$$

---

## 4. Endpoint Unificado: `GET /api/v1/dashboard/admin-overview`

- **Rota:** `GET /api/v1/dashboard/admin-overview?event_id={event_id}`
- **Autenticação:** Bearer Token JWT de Administrador ou Coordenador.
- **Performance:** Executa consultas analíticas agregadas via SQLAlchemy em $O(1)$ sobre o banco PostgreSQL, retornando em $\approx 50$ms.

---

## 5. Fluxo de Ações Rápidas (Quick Actions)

1. **Auto-Balanceamento em 1-Clique:**
   - Dispara chamada POST para rebalancear todas as bancadas do evento garantindo variância de carga $\Delta \le 1$.
   - Ao concluir, força atualização imediata dos dados do Centro de Comando e exibe notificação toast de sucesso.
2. **Alocação Manual com Modal Integrado:**
   - Permite selecionar qualquer trabalho (com destaque e pré-seleção a partir da tabela de projetos críticos).
   - Apresenta a lista de avaliadores com indicação de presença (`🟢 [Presente]` ou `⚪ [Ausente]`) e contagem de trabalhos já alocados.
   - Faz a alocação e recarrega os dados instantaneamente.
3. **Novo Jurado / Voluntário de Última Hora:**
   - Conforme diretriz do usuário, direciona o coordenador para o cadastro oficial de participantes (`/participants?role=EVALUATOR`), mantendo total conformidade com o ciclo de vida de pessoas do sistema.

---

## 6. Suporte a Múltiplos Monitores e Modo Kiosk Dedicado (Opção A)

Para permitir a operação simultânea em computadores com 2 ou 3 telas no dia da feira científica, o sistema disponibiliza rotas dedicadas em **Modo Kiosk (Opção A)**:

1. **Abertura Descentralizada a partir da Visão Geral:**
   - No card de **Trabalhos Críticos & Gaps de Avaliação (4A)**: botão `[ ↗ Abrir em Nova Janela ]`, apontando para `/monitor/critical-projects?event_id={event_id}` (`target="_blank"`).
   - No card de **Grandes Áreas & Termômetro de Cobertura (3A)**: botão `[ ↗ Abrir em Nova Janela ]`, apontando para `/monitor/areas-risk?event_id={event_id}` (`target="_blank"`).

2. **Arquitetura Standalone (`apps/frontend-admin/src/app/monitor/`):**
   - **Sem Sidebar e sem Navbar:** O layout dedicado dispensa o menu lateral e o cabeçalho administrativo convencional, maximizando 100% da área útil do monitor secundário.
   - **Cabeçalho Dedicado (`MonitorHeader.tsx`):** Exibe identificação institucional, ID e nome do evento, título da tela com ícone, indicador "Ao Vivo", anel regressivo SVG de 30 segundos, botões de Pausa e Atualização Imediata, botão nativo de **Tela Cheia** (`requestFullscreen`), alternador de tema Claro/Escuro e atalho de retorno ao painel principal.
   - **Consumo Sincronizado do Endpoint Único:** Ambas as telas consomem `GET /api/v1/dashboard/admin-overview?event_id={event_id}` com ciclo de 30 segundos, mantendo fidelidade estrita e sincronização total com a tela principal.

