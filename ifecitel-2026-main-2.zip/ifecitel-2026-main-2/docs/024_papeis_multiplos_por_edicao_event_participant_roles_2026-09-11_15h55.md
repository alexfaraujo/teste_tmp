# 024 — Suporte a Múltiplos Papéis por Edição do Evento (`event_participant_roles`)
**Data / Hora:** 11/09/2026 — 15h55  
**Autor:** Equipe Técnica FECITEL (Alex Araújo & Antigravity)  
**Status:** Implementado, Testado e Concluído  

---

## 1. Contexto e Deliberação do Requisito

Após a implementação inicial do CRUD de Participantes (`docs/023_...`), o Gestor do Projeto (Alex Araújo) solicitou formalmente a evolução da regra de negócio para atribuição de papéis:

> *"o papel da pessoa precisa aceitar mais de uma opção. Por exemplo, uma pessoa pode ser orientador e avaliador no evento. ou pode ser co orientador e avaliador. ou pode ser orientador em um trabalho e co orientador em outro."*

### 1.1. Análise Arquitetural
Foram apresentadas 3 opções técnicas para análise:
- **Opção 1 (Recomendada):** Tabela relacional associativa `event_participant_roles` vinculando `(person_id, event_id, role)`. 100% normalizada, flexível e isolada por edição.
- **Opção 2:** Coluna de array/conjunto `roles: VARCHAR[]` nativa do PostgreSQL.
- **Opção 3:** Papéis inferidos dinamicamente apenas a partir das tabelas operacionais (`project_members`, `evaluations`).

O Gestor aprovou a **Opção 1**, autorizando a atualização imediata das documentações e a execução da implementação completa no banco de dados, backend e frontend.

---

## 2. Métricas de Esforço da Equipe

Em estrita conformidade com a Seção 1.3 de `.agents/rules.md`:

| Dimensão | Percentual | Descrição do Esforço |
| :--- | :---: | :--- |
| **Participação Humana** | **55%** | Deliberação do requisito de acúmulo de papéis simultâneos na feira, escolha e aprovação formal da Opção 1, validação das regras de negócio de compatibilidade entre Orientador e Avaliador. |
| **Trabalho Híbrido** | **30%** | Planejamento da modelagem relacional (`event_participant_roles`), garantia da retrocompatibilidade com rotas legadas e validação da ausência de conflitos de interesse no algoritmo de alocação. |
| **Atuação Autônoma da IA** | **15%** | Execução dos scripts DDL e migração de 974 registros existentes no PostgreSQL, implementação dos modelos SQLAlchemy, schemas Pydantic, serviços assíncronos, 33 testes automatizados e interface com checkboxes e múltiplas badges no Next.js. |

---

## 3. Especificação da Implementação Técnica

### 3.1. Modelagem Relacional (PostgreSQL)
Criação da tabela associativa e seus índices parciais de alta performance:

```sql
CREATE TABLE IF NOT EXISTS event_participant_roles (
    id SERIAL PRIMARY KEY,
    person_id INTEGER NOT NULL REFERENCES people(id) ON DELETE CASCADE,
    event_id INTEGER NOT NULL REFERENCES events(id) ON DELETE CASCADE,
    role VARCHAR(50) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
    deleted_at TIMESTAMP WITH TIME ZONE NULL,
    CONSTRAINT uq_event_participant_role UNIQUE (person_id, event_id, role)
);

CREATE INDEX IF NOT EXISTS idx_epr_person_event ON event_participant_roles(person_id, event_id) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_epr_event_role ON event_participant_roles(event_id, role) WHERE deleted_at IS NULL;
```

#### Migração Executada
- 974 registros de papéis foram consolidados a partir de `event_participants`, `people` e `project_members`.
- 846 pessoas únicas mapeadas com seus respectivos papéis em 271 edições de eventos.

### 3.2. Backend Central (`apps/backend`)
1. **Modelos (`app/models/person.py`):**
   - Classe `EventParticipantRole(BaseModel)`.
   - Relacionamento `event_roles: Mapped[List["EventParticipantRole"]]` em `Person`.
2. **Schemas (`app/schemas/person.py`):**
   - `ParticipantItemResponse`, `ParticipantDetailResponse`: suporte a `roles: List[UserRole]` e `role: UserRole` (mantido como principal para compatibilidade retroativa).
   - `ParticipantCreateRequest`, `ParticipantUpdateRequest`: suporte a `roles: Optional[List[UserRole]]` e `role: Optional[UserRole]`.
3. **Serviços (`app/services/participant_service.py`):**
   - `_sync_participant_roles`: sincroniza com soft-delete atômico os papéis ativos do participante na edição.
   - `list_participants`: carrega em lote os múltiplos papéis dos participantes exibidos na página (15/página — BR-18).
   - `list_participants` (Filtro por papel): filtra via subquery em `event_participant_roles`, garantindo que participantes com múltiplos papéis apareçam ao filtrar por qualquer um deles.
   - `delete_participant`: soft-delete integrado de `event_participant_roles`.

### 3.3. Frontend Admin (`apps/frontend-admin`)
1. **Tipagem (`src/types/index.ts`):**
   - Atualização de `ParticipantItem`, `ParticipantCreatePayload` e `ParticipantUpdatePayload` para suportar `roles: UserRole[]`.
2. **Listagem e Badges Múltiplas (`src/app/(dashboard)/participants/page.tsx`):**
   - A coluna "Papel" na tabela de participantes renderiza badges coloridas distintas para cada papel atribuído (ex: `[Orientador]` e `[Avaliador]`).
3. **Modais de Criação e Edição:**
   - Substituição do select único por checkboxes de múltipla seleção estilizados (`Estudante`, `Orientador`, `Coorientador`, `Avaliador`, `Administrador`).
   - Seção de subáreas temáticas é automaticamente exibida quando a opção `Avaliador` estiver marcada.
   - Validação obrigatória impedindo salvar sem selecionar ao menos 1 papel.

---

## 4. Garantia da Regra de Ouro e Conflitos de Interesse

Mesmo que um orientador ou coorientador receba também o papel de `Avaliador` na mesma edição da feira, o motor de alocação de avaliadores (`app/services/allocation_service.py`) valida diretamente a autoria através da tabela `project_members`:
- **Orientadores e coorientadores NUNCA são alocados para avaliar seus próprios projetos.**
- **Avaliadores NUNCA são alocados para projetos de seus colegas de equipe/coautores.**
- O acúmulo de papéis é 100% seguro contra fraudes e viés avaliativo.

---

## 5. Resultados e Validação

1. **Testes do Backend:**
   - Execução de `pytest apps/backend/tests/test_participants.py -v`: 5/5 testes aprovados (100%).
   - Execução de `pytest apps/backend/tests -v`: 33/33 testes aprovados (100% de sucesso da suíte).
2. **Build do Frontend:**
   - Execução de `npm run build` no `apps/frontend-admin`: compilação Next.js 14 estática concluída com código 0 e sem erros de TypeScript.
