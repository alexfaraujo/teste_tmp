# 021 — Adição de Campos CPF e Afiliação em People e Ingestão do Dataset de Projetos
**Data / Hora:** 11/09/2026 — 14h15  
**Autor:** Equipe Técnica FECITEL (Alex Araújo & Antigravity)  
**Status:** Aprovado e Aplicado  

---

## 1. Contexto e Motivação

Durante os preparativos para testes de carga e validação funcional com dados reais da feira, o Gestor do Projeto (Alex Araújo) disponibilizou na pasta `modelo_dataset_projetos/` o arquivo `dataset-fecitel.csv` contendo a relação de projetos e integrantes inscritos em edições da FECITEL.

A análise estrutural do dataset revelou dados fundamentais de participantes que não possuíam colunas dedicadas no modelo relacional original:
1. **CPF (`cpf_orientador`, `cpf_coorientador`, `aluno_cpf`):** Essencial para a identificação única e oficial dos envolvidos, cruzamento de dados institucionais e futura emissão de certificados oficiais.
2. **Perfil / Vínculo Institucional (`aluno_perfil`):** Registra a natureza da participação estudantil (`'Aluno IFMS'`, `'Aluno Externo'`, `'Público Externo'`).

Por determinação do Gestor, foi autorizada a execução da recomendação arquitetural de evoluir a tabela `people`, registrar formalmente a alteração nos documentos do projeto e proceder com a importação integral para a edição do evento **"Fecitel do Alex"** (ID: 391).

---

## 2. Métricas de Esforço da Equipe

Em estrita conformidade com a Seção 1.3 de `.agents/rules.md`:

| Dimensão | Percentual | Descrição do Esforço |
| :--- | :---: | :--- |
| **Participação Humana** | **50%** | Fornecimento do dataset real da feira, definição das regras de negócio dos campos, autorização soberana para alteração estrutural da tabela `people` e determinação do evento alvo ("Fecitel do Alex"). |
| **Trabalho Híbrido** | **35%** | Pair programming para diagnóstico e mapeamento das colunas do CSV para o modelo relacional do PostgreSQL, estratégia de deduplicação por e-mail e tratamento dos alunos sem e-mail cadastrado. |
| **Atuação Autônoma da IA** | **15%** | Geração e execução das instruções DDL no PostgreSQL, script assíncrono em Python com SQLAlchemy (`import_dataset.py`), execução de simulação prévia (`--dry-run`) e atualização da documentação técnica. |

---

## 3. Alterações Estruturais no Banco de Dados

### 3.1. DDL Aplicado na Tabela `people`
```sql
-- Adição de colunas para CPF e afiliação institucional
ALTER TABLE people ADD COLUMN IF NOT EXISTS cpf VARCHAR(20) NULL;
ALTER TABLE people ADD COLUMN IF NOT EXISTS affiliation VARCHAR(100) NULL;

-- Índice para busca rápida de participantes por CPF
CREATE INDEX IF NOT EXISTS idx_people_cpf ON people(cpf) WHERE deleted_at IS NULL;
```

### 3.2. Atualização dos Modelos e Schemas Backend
*   **Modelo SQLAlchemy (`apps/backend/app/models/person.py`):**
    ```python
    cpf: Mapped[Optional[str]] = mapped_column(String(20), nullable=True, index=True)
    affiliation: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    ```
*   **Schema Pydantic (`apps/backend/app/schemas/person.py`):**
    ```python
    class PersonBase(BaseModel):
        name: str
        email: EmailStr
        cpf: Optional[str] = None
        affiliation: Optional[str] = None
        role: UserRole = UserRole.STUDENT
    ```

---

## 4. Estratégia de Ingestão e Mapeamento (`import_dataset.py`)

O script `modelo_dataset_projetos/import_dataset.py` implementa um pipeline de ETL assíncrono, transacional e idempotente:

1. **Filtragem e Limpeza:**
   - Descarta linhas nulas e comentários de rodapé do Excel (linhas 127 a 129).
   - Processa os **125 projetos consistentes** presentes no arquivo.
2. **Áreas Temáticas e Subáreas:**
   - Para cada uma das 5 Grandes Áreas do CSV (*CHSAL*, *MDIS*, *CET*, *CAE*, *CBS*), localiza ou cria a `KnowledgeArea` na edição vinculada.
   - Cria uma `Subarea` padrão (`"Geral"`) para garantir a integridade da chave estrangeira `projects.subarea_id NOT NULL`.
3. **Pessoas e Deduplicação:**
   - Localiza pessoas já cadastradas através do e-mail (insensível a maiúsculas/minúsculas).
   - Se a pessoa existir, reaproveita seu registro e complementa `cpf` ou `affiliation` caso estejam vazios.
   - Para 11 alunos que não possuíam e-mail na planilha original, gera um e-mail temporário padronizado determinístico (`placeholder.<nome>.p<id>.<tipo>@fecitel.local`) evitando violação da restrição `UNIQUE NOT NULL` do PostgreSQL.
4. **Trabalhos (`projects`):**
   - Mapeia o `ID Trabalho` para `qrcode_token`.
   - Converte a modalidade textual para `EducationLevelEnum.MEDIO` ou `EducationLevelEnum.FUNDAMENTAL`.
   - Define status inicial `HOMOLOGATED` com anuência digital concedida (`advisor_consent = True`).
5. **Membros e Participação:**
   - Vincula integrantes em `project_members` (`ADVISOR`, `COADVISOR`, `STUDENT_LEADER`, `STUDENT_MEMBER`).
   - Inscreve todos os indivíduos em `event_participants` para o evento alvo.

---

## 5. Próximos Passos
1. Executar a importação real (`--apply`) apontando para o evento **"Fecitel do Alex"** (ID: 391).
2. Validar a presença e integridade dos projetos via API e frontend administrativo.
