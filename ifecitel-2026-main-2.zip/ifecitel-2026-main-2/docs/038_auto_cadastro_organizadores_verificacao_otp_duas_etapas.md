# 038 — Auto-Cadastro de Organizadores de Feiras com Verificação OTP em Duas Etapas (Regra BR-24)

**Data:** 12/09/2026 17:00  
**Autor:** Antigravity (Pair Programming com Alex Araújo)  
**Status:** Especificado e Modelado (Opção 2 Selecionada)  
**Módulos Impactados:** `apps/backend`, `apps/frontend-admin`, `docs/database.md`, `docs/context.md`  
**Regras de Negócio Relacionadas:** BR-01 (Múltiplas Edições), BR-23 (Isolamento Estrito e Ausência de Super Admin) e BR-24 (Onboarding Autônomo com OTP)

---

## 1. Visão Geral e Necessidade de Negócio

Com a evolução do sistema para uma **Plataforma Aberta Multi-Feiras** e a **ausência deliberada de um Super Administrador** (Regra BR-23), não existe uma figura central responsável por pré-cadastrar contas para outros professores, coordenadores de outros campi ou gestores de feiras parceiras.

Para viabilizar que qualquer professor ou comissão organizadora utilize a plataforma para seu próprio evento, institui-se a **Regra BR-24: Onboarding Autônomo com Verificação em Duas Etapas (Opção 2)**.

Este mecanismo garante:
1. **Autonomia Plena:** Novos organizadores criam suas contas administrativas sem intermediação humana.
2. **Autenticidade de E-mail:** Nenhuma conta de organizador é ativada sem a comprovação imediata da posse da caixa postal via código OTP de 8 caracteres.
3. **Imediatismo Operacional:** Imediatamente após a ativação, o organizador é conduzido ao painel para cadastrar seu primeiro evento, assumindo automaticamente o papel soberano de Coordenador Geral (`COORDINATOR`).
4. **Respeito Estrito ao Isolamento:** A nova conta nasce sem acesso a nenhum evento pré-existente no banco de dados.

---

## 2. Regra de Negócio BR-24: Auto-Cadastro de Organizadores com OTP em Duas Etapas

### 2.1 Fluxo Operacional

```mermaid
sequenceDiagram
    autonumber
    actor Org as Novo Organizador
    participant Web as Painel Web (/register)
    participant API as Backend FastAPI
    participant DB as PostgreSQL
    participant Mail as Servidor SMTP

    Note over Org, Web: Etapa 1: Solicitação e Envio do Código
    Org->>Web: Informa Nome e E-mail
    Web->>API: POST /api/v1/auth/register/request-code
    API->>DB: Verifica se e-mail já possui conta ativa com senha
    alt E-mail já ativo com senha
        API-->>Web: 400 Bad Request ("E-mail já cadastrado no sistema")
    else E-mail novo ou pendente
        API->>DB: Grava OTP (hash) com expiração de 15 minutos em registration_verifications
        API->>Mail: Dispara e-mail com código OTP de 8 caracteres
        API-->>Web: 200 OK ("Código enviado para o e-mail")
    end

    Note over Org, Web: Etapa 2: Verificação, Dados Pessoais e Senha
    Org->>Web: Digita OTP recebido, CPF, Instituição e Senha
    Web->>API: POST /api/v1/auth/register/verify-and-complete
    API->>DB: Valida OTP (código confere? não expirou? < 5 tentativas?)
    alt Código inválido ou expirado
        API-->>Web: 400 Bad Request ("Código inválido ou expirado")
    else Código válido
        API->>DB: Cria/Atualiza Person (name, email, cpf, affiliation, password_hash)
        API->>DB: Marca verificação como confirmada (verified = true)
        API-->>Web: 200 OK com JWT access_token de autenticação
        Web->>Org: Redireciona para /events (Tela de Edições de Feiras)
    end
```

---

## 3. Especificação dos Endpoints REST (`apps/backend`)

### 3.1 `POST /api/v1/auth/register/request-code`
- **Acesso:** Público.
- **Payload de Entrada:**
  ```json
  {
    "name": "Profª. Maria Silva",
    "email": "maria.silva@ifms.edu.br"
  }
  ```
- **Regras de Validação:**
  - Formato de e-mail válido.
  - Se já existir registro em `people` com o mesmo e-mail e `password_hash IS NOT NULL`, retorna `400 Bad Request`: *"Este e-mail já possui conta ativa no sistema. Efetue login ou utilize a recuperação de senha."*
  - Se houver solicitação anterior para o mesmo e-mail nos últimos 60 segundos (*anti-flood*), retorna `429 Too Many Requests`.
- **Ações:**
  - Gera um código OTP alfanumérico seguro de 8 caracteres em caixa alta (ex: `M8K2-9P4X`).
  - Calcula o hash criptográfico do código via `hash_access_code(code)`.
  - Registra na tabela `registration_verifications`:
    - `email`: e-mail informado.
    - `code_hash`: hash do OTP.
    - `expires_at`: `NOW() + INTERVAL '15 minutes'`.
    - `attempts`: 0.
    - `verified`: `false`.
  - Dispara o e-mail transacional com o código para o usuário. Em ambiente de desenvolvimento e testes locais, o código é exibido no log do backend com formatação destacada.
- **Resposta:** `200 OK`
  ```json
  {
    "message": "Código de verificação enviado com sucesso para o e-mail informado.",
    "email": "maria.silva@ifms.edu.br",
    "expires_in_seconds": 900
  }
  ```

---

### 3.2 `POST /api/v1/auth/register/verify-and-complete`
- **Acesso:** Público.
- **Payload de Entrada:**
  ```json
  {
    "email": "maria.silva@ifms.edu.br",
    "code": "M8K2-9P4X",
    "name": "Profª. Maria Silva",
    "cpf": "123.456.789-00",
    "affiliation": "IFMS Campus Campo Grande",
    "password": "SenhaSegura123!"
  }
  ```
- **Regras de Validação:**
  - Senha com no mínimo 6 caracteres.
  - Busca o registro mais recente em `registration_verifications` para o e-mail onde `verified = false`.
  - Valida se `NOW() <= expires_at`. Se expirado, retorna `400 Bad Request` (*"Código expirado. Solicite um novo código."*).
  - Valida tentativas (`attempts >= 5`). Se estourado, bloqueia o token.
  - Compara `code` fornecido com `code_hash`. Se incorreto, incrementa `attempts` e retorna `400 Bad Request` (*"Código de verificação incorreto."*).
- **Ações:**
  - Marca `verified = true`.
  - Cria ou atualiza o registro na tabela `people`:
    - `name = name`
    - `email = email`
    - `cpf = cpf`
    - `affiliation = affiliation`
    - `password_hash = hash_password(password)`
  - Gera o token JWT de autenticação (`create_access_token(sub=person.email)`).
- **Resposta:** `201 Created`
  ```json
  {
    "access_token": "eyJhbGciOiJIUzI1NiIs...",
    "token_type": "bearer",
    "person": {
      "id": 420,
      "name": "Profª. Maria Silva",
      "email": "maria.silva@ifms.edu.br",
      "affiliation": "IFMS Campus Campo Grande"
    }
  }
  ```

---

## 4. Modelagem no Banco de Dados (PostgreSQL)

### 4.1 Nova Tabela: `registration_verifications`
```sql
CREATE TABLE IF NOT EXISTS registration_verifications (
    id SERIAL PRIMARY KEY,
    email VARCHAR(100) NOT NULL,
    code_hash VARCHAR(255) NOT NULL,
    attempts INTEGER NOT NULL DEFAULT 0,
    verified BOOLEAN NOT NULL DEFAULT FALSE,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS ix_registration_verifications_email ON registration_verifications(email);
```

---

## 5. Interface do Usuário (`apps/frontend-admin`)

1. **Ponto de Entrada no Login (`/login`):**
   - Link abaixo do botão de entrar: *"Ainda não tem conta? Cadastre-se como Organizador de Feira"*.
2. **Tela de Cadastro do Organizador (`/register`):**
   - **Etapa 1 (Identificação Inicial):**
     - Campos: Nome Completo e E-mail.
     - Botão: *"Enviar Código de Verificação"*.
     - Indicador de carregamento e mensagem amigável de envio.
   - **Etapa 2 (Confirmação e Definição de Senha):**
     - Transição animada de passos.
     - Campo destacado com máscara para digitação do código de 8 caracteres.
     - Campos adicionais: CPF (opcional/formatado), Instituição de Origem (Afiliação), Senha e Confirmação de Senha.
     - Botão de reenvio de código com contador regressivo de 60 segundos.
     - Botão de ação: *"Concluir Cadastro e Acessar Painel"*.
3. **Primeiro Acesso ao Painel (`/events`):**
   - Como o organizador acabou de se cadastrar, não há feiras associadas a ele.
   - A interface exibe um card de boas-vindas:
     - 🎯 *"Bem-vindo(a) à Plataforma de Gestão de Feiras Científicas!"*
     - *"Você ainda não possui nenhum evento cadastrado sob sua coordenação."*
     - Botão de Ação Primária: **"Cadastrar Nova Feira"** (abre o modal de criação de evento).
   - Ao salvar a nova feira, o backend grava `events.owner_id = current_user.id`, promovendo o usuário imediatamente a Coordenador Geral soberano daquela edição.
