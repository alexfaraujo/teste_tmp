# 037 — Plataforma Multi-Feiras com Isolamento Estrito por Evento e Hierarquia Administrativa (Regra BR-23)

**Data:** 12/09/2026 16:45  
**Autor:** Antigravity (Pair Programming com Alex Araújo)  
**Status:** Especificado e Modelado (Pronto para Execução)  
**Módulos Impactados:** `apps/backend`, `apps/frontend-admin`, `docs/database.md`, `docs/context.md`, `walkthrough.md`  
**Regras de Negócio Relacionadas:** BR-01 (Múltiplas Edições), BR-02 (Trava Temporal), BR-19 (Contexto Global de Evento Ativo), BR-23 (Isolamento Multi-Feiras e Hierarquia Administrativa) e BR-24 (Auto-Cadastro com OTP - Especificado no Documento 038)

---

## 1. Visão Geral e Motivação

O sistema evolui de uma aplicação dedicada exclusivamente à **FECITEL (Feira de Ciência e Tecnologia de Três Lagoas)** para uma **Plataforma Aberta Multi-Feiras**. 

Diversos organizadores de eventos científicos, feiras tecnológicas, mostras de robótica e simpósios de nível fundamental, médio e superior (no âmbito do IFMS ou de outras instituições) poderão utilizar a mesma infraestrutura computacional para gerenciar seus próprios eventos com total independência.

Com essa expansão, torna-se indispensável assegurar:
1. **Privacidade e Isolamento Soberano:** O que acontece em uma feira pertence única e exclusivamente à equipe daquela feira. Projetos, bancadas, jurados, notas e premiações são estritamente confidenciais.
2. **Posse Real pelo Criador:** Quem cadastra um evento é seu proprietário e Coordenador Geral soberano (`events.owner_id = current_user.id`).
3. **Delegação Controlada:** O criador pode convidar outros administradores para atuar na sua feira, especificando o nível de poder de cada um.
4. **Ausência Deliberada de Super Administrador:** Para garantir conformidade com políticas de segurança da informação e privacidade institucional, não existe qualquer perfil de usuário mestre capaz de visualizar ou alterar dados de feiras de terceiros sem ter sido formalmente convidado.

---

## 2. Regra de Negócio BR-23: Isolamento Estrito Absoluto e Multi-Tenancy por Feira

### 2.1 Posse Soberana do Evento (`owner_id`)
- Toda nova feira cadastrada no sistema (`POST /api/v1/events`) vincula automaticamente o identificador numérico do usuário autenticado à coluna `events.owner_id`.
- O proprietário adquire automaticamente o papel institucional de **Coordenador Geral (`COORDINATOR`)** daquela edição.
- O Coordenador Geral soberano não pode ser desvinculado, rebaixado ou removido por nenhum outro usuário.

### 2.2 Ausência de Super Administrador Global
- O sistema opera sob o **Princípio do Menor Privilégio (*Least Privilege*)**.
- Mesmo usuários fundadores ou administradores de edições históricas não possuem visibilidade sobre eventos cadastrados por outros professores/organizadores.
- Se o administrador do servidor precisar prestar assessoria ou suporte técnico em uma feira específica, o Coordenador Geral daquela feira precisará cadastrá-lo formalmente como membro da comissão daquele evento.

### 2.3 Visibilidade na Listagem de Eventos (`GET /api/v1/events`)
A consulta de listagem de feiras no backend restringe o resultado com base no usuário logado:
$$\text{Eventos Visíveis}(u) = \{ e \in \text{Events} \mid e.\text{deleted\_at} = \text{null} \land (e.\text{owner\_id} = u.\text{id} \lor \exists a \in \text{event\_administrators}(a.\text{event\_id} = e.\text{id} \land a.\text{person\_id} = u.\text{id} \land a.\text{deleted\_at} = \text{null})) \}$$

---

## 3. Hierarquia Administrativa por Evento (Opção 2)

Dentro de cada feira, a equipe de gestão divide-se em **3 níveis de governança** registrados na tabela `event_administrators`:

```mermaid
graph TD
    subgraph Governança do Evento
        Coord["👑 COORDINATOR (Coordenador Geral / Dono)"]
        Org["🛡️ ORGANIZER (Comissão Organizadora / Co-Admin)"]
        Op["🎫 OPERATOR (Apoio / Mesa de Recepção)"]
    end

    Coord -->|Poder Total + Delegação de Equipe| Org
    Coord -->|Delegação de Operação| Op
    Org -->|Coordenação Operacional de Bancadas| Op
```

### 3.1 Definição dos Papéis e Escopos

| Papel (`EventAdminRole`) | Descrição | Responsabilidades e Escopo |
|---|---|---|
| **`COORDINATOR`** | Coordenador Geral / Criador Soberano | **Posse Total da Feira:**<br>• Edita dados cadastrais, local, datas, prazos e cotas do evento.<br>• Convida novos administradores por e-mail e define seus níveis.<br>• Altera níveis de permissão ou revoga acessos da equipe gestora.<br>• Exclui ou arquiva a edição da feira.<br>• Acesso a todas as operações dos níveis inferiores. |
| **`ORGANIZER`** | Comissão Organizadora / Co-Administrador | **Gestão Operacional Plena:**<br>• Homologação documental de trabalhos e alocação de bancadas (`/projects`).<br>• Gestão de Grandes Áreas, subáreas, critérios e prêmios (`/areas`, `/criteria`, `/awards`).<br>• Gestão de participantes e avaliadores (`/participants`, `/evaluators`).<br>• Rebalanceamento algorítmico ($\Delta \le 1$) e apuração de resultados (`/results`).<br>• Centro de Comando e Monitores Auxiliares (`/`, `/monitor/*`).<br>*(Bloqueado: excluir feira, alterar dono ou revogar Coordenador).* |
| **`OPERATOR`** | Apoio / Recepção & Credenciamento | **Operação de Linha de Frente:**<br>• Operação da Mesa de Credenciamento Geral e baixa de kits (`/logistics`).<br>• Leitura e confirmação de presença no Check-in dos Avaliadores (`/evaluators/checkin`).<br>• Visualização em modo leitura da Visão Geral (`/`).<br>*(Bloqueado: alterar projetos, notas, critérios, alocações ou configurações).* |

### 3.2 Matriz Detalhada de Acesso RBAC por Rota e Ação

| Funcionalidade / Rota | `COORDINATOR` | `ORGANIZER` | `OPERATOR` | Não Convidado |
|---|:---:|:---:|:---:|:---:|
| Visualizar Feira na Lista (`GET /events`) | ✅ Sim | ✅ Sim | ✅ Sim | ❌ Invisível |
| Acessar Centro de Comando / Visão Geral (`/`) | ✅ Sim | ✅ Sim | 👁️ Leitura | 🚫 403 Forbidden |
| Monitores Kiosk Dedicados (`/monitor/*`) | ✅ Sim | ✅ Sim | 👁️ Leitura | 🚫 403 Forbidden |
| Mesa de Credenciamento e Kits (`/logistics`) | ✅ Sim | ✅ Sim | ✅ Sim | 🚫 403 Forbidden |
| Check-in de Jurados (`/evaluators/checkin`) | ✅ Sim | ✅ Sim | ✅ Sim | 🚫 403 Forbidden |
| Homologação e Gestão de Projetos (`/projects`) | ✅ Sim | ✅ Sim | ❌ Bloqueado | 🚫 403 Forbidden |
| Áreas, Critérios e Premiações (`/areas`, `/criteria`, `/awards`) | ✅ Sim | ✅ Sim | ❌ Bloqueado | 🚫 403 Forbidden |
| Alocação e Balanceamento de Jurados (`/evaluators`) | ✅ Sim | ✅ Sim | ❌ Bloqueado | 🚫 403 Forbidden |
| Gestão de Participantes e Papéis (`/participants`) | ✅ Sim | ✅ Sim | ❌ Bloqueado | 🚫 403 Forbidden |
| Apuração e Classificação Oficial (`/results`) | ✅ Sim | ✅ Sim | ❌ Bloqueado | 🚫 403 Forbidden |
| Convidar e Gerenciar Equipe da Feira (Card e Visão Geral - Doc 039) | ✅ Sim | ❌ Bloqueado | ❌ Bloqueado | 🚫 403 Forbidden |
| Editar Parâmetros Gerais e Datas da Feira | ✅ Sim | ❌ Bloqueado | ❌ Bloqueado | 🚫 403 Forbidden |
| Excluir / Arquivar a Feira | ✅ Sim | ❌ Bloqueado | ❌ Bloqueado | 🚫 403 Forbidden |

---

## 4. Modelagem no Banco de Dados Relacional (PostgreSQL)

### 4.1 Alteração na Tabela `events`
Adição da chave estrangeira de propriedade soberana:
```sql
ALTER TABLE events 
ADD COLUMN IF NOT EXISTS owner_id INTEGER REFERENCES people(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS ix_events_owner_id ON events(owner_id);
```

### 4.2 Nova Tabela: `event_administrators`
```sql
CREATE TABLE IF NOT EXISTS event_administrators (
    id SERIAL PRIMARY KEY,
    event_id INTEGER NOT NULL REFERENCES events(id) ON DELETE CASCADE,
    person_id INTEGER NOT NULL REFERENCES people(id) ON DELETE CASCADE,
    role VARCHAR(20) NOT NULL DEFAULT 'ORGANIZER',
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMP WITH TIME ZONE NULL,
    CONSTRAINT uq_event_administrator UNIQUE (event_id, person_id)
);

CREATE INDEX IF NOT EXISTS ix_event_administrators_event_id ON event_administrators(event_id);
CREATE INDEX IF NOT EXISTS ix_event_administrators_person_id ON event_administrators(person_id);
```

### 4.3 Estratégia de Migração e Backfill (Compatibilidade com Dados Atuais)
Para garantir que o Evento ID 391 e as edições existentes permaneçam 100% operacionais:
1. Atualiza `events.owner_id = 411` para todos os eventos existentes sem proprietário.
2. Cria o registro correspondente em `event_administrators` com `person_id = 411` e `role = 'COORDINATOR'`.

---

## 5. Endpoints da API REST Central (`apps/backend`)

### 5.1 Dependência de Autorização por Evento (`deps.py`)
```python
async def get_event_admin_access(
    event_id: int,
    min_role: EventAdminRole = EventAdminRole.OPERATOR,
    db: AsyncSession = Depends(get_db),
    current_admin: Person = Depends(get_current_admin)
) -> Tuple[Event, EventAdminRole]:
    """
    Valida se o administrador autenticado tem acesso ao evento informado 
    com papel igual ou superior ao min_role.
    Retorna 403 Forbidden caso o usuário não pertença à equipe daquela feira.
    """
```

### 5.2 Endpoints de Gestão da Equipe do Evento (`/events/{event_id}/admins`)
1. **`GET /api/v1/events/{event_id}/admins`**
   - Retorna a lista de administradores da feira, indicando quem é o Dono (`is_owner`), nome, e-mail e papel ativo (`COORDINATOR`, `ORGANIZER`, `OPERATOR`).
   - Requer perfil mínimo: `ORGANIZER`.
2. **`POST /api/v1/events/{event_id}/admins`**
   - Convida/adiciona um novo administrador à feira pelo e-mail com o papel designado.
   - Requer perfil: `COORDINATOR`.
3. **`PUT /api/v1/events/{event_id}/admins/{person_id}`**
   - Atualiza o nível hierárquico do administrador (`ORGANIZER` <-> `OPERATOR`).
   - Requer perfil: `COORDINATOR`.
4. **`DELETE /api/v1/events/{event_id}/admins/{person_id}`**
   - Revoga o acesso do administrador à feira.
   - Requer perfil: `COORDINATOR`. (Proteção: não permite revogar o `owner_id`).

---

## 6. Experiência do Usuário no Frontend (`apps/frontend-admin`)

1. **Tela de Edições de Eventos (`/events`):**
   - Lista exclusivamente os eventos onde o usuário possui vínculo.
   - Cada card de evento apresenta o selo de papel do usuário:
     - 👑 `Coordenador Geral (Dono)`
     - 🛡️ `Comissão Organizadora`
     - 🎫 `Apoio / Recepção`
   - Para feiras onde o usuário é Coordenador Geral: exibe o botão **"Equipe & Administradores"** para abertura do modal de gestão.
2. **Modal "Gerenciar Equipe da Feira":**
   - Lista dos gestores atuais com seus respectivos selos e e-mails.
   - Campo para adicionar novo membro via e-mail + seletor de nível (`Comissão Organizadora` ou `Apoio`).
   - Ação de alterar papel e botão para revogar acesso.
3. **Navegação Dinâmica no Menu Lateral (`Sidebar.tsx`):**
   - Quando a edição ativa em gerenciamento for operada por um usuário com perfil `OPERATOR`, os menus de configuração e apuração (`Critérios`, `Projetos`, `Alocação`, `Premiações`, `Classificação`) são visualmente desativados/ocultados, deixando em evidência os módulos de linha de frente (`Visão Geral`, `Credenciamento Geral` e `Check-in dos Avaliadores`).
