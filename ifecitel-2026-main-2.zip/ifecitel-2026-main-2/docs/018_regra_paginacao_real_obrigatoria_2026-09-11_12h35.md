# Registro Cronológico: Regra BR-18 — Paginação Real Obrigatória em Listagens de Dados

**Data e Hora:** 2026-09-11 12:35:00 -04:00  
**Autor:** Antigravity (AI / Pair Programming)  
**Revisor & Gestor:** Alex Araújo  
**Status:** Decisão Soberana do Gestor Aprovada e Integrada às Regras do Projeto

---

## 1. Contexto e Motivação Operacional

Durante os testes práticos de validação da **Fase 2 (Gestão Estrutural)** no Painel Administrativo, o Gestor do Projeto (Alex Araújo) identificou a ausência de paginação na listagem de Edições do Evento e deliberou que **todas as telas com listagens de itens devem obrigatoriamente implementar paginação real (server-side)**, estabelecendo o padrão de **15 itens por página**.

---

## 2. Especificação da Regra BR-18

### 2.1 Princípios Obrigatórios:
1. **Paginação Real (Server-Side):**
   - É expressamente proibido trazer todo o conjunto de dados para a memória do navegador e aplicar cortes no frontend.
   - O backend deve receber parâmetros de paginação e aplicar `OFFSET` e `LIMIT` diretamente na query SQL do PostgreSQL.
2. **Padrão de Quantidade:**
   - O tamanho padrão de página para todas as listagens do ecossistema FECITEL é de **15 itens** (`limit = 15`).
3. **Contratos de Dados Padronizados (Backend):**
   - Os endpoints de listagem devem aceitar:
     - `page: int = Query(1, ge=1)` (1-indexed)
     - `limit: int = Query(15, ge=1, le=100)` (default 15)
   - A resposta deve conter o payload padronizado:
     ```json
     {
       "items": [...],
       "total": 45,
       "page": 1,
       "limit": 15,
       "total_pages": 3
     }
     ```
4. **Interface com o Usuário (Frontend):**
   - Barra de controle de paginação obrigatória abaixo de cada grade ou tabela de itens:
     - Botão "Anterior" (desabilitado na página 1).
     - Botões com os números das páginas, com destaque visual na página corrente.
     - Botão "Próximo" (desabilitado na última página).
     - Indicador informativo textual: *"Exibindo X a Y de Z registros"*.

---

## 3. Aplicação Imediata
- **Fase 2:** Implementação na tela de **Edições do Evento (`/events`)**, ajustando o backend FastAPI (`GET /api/v1/events?page=X&limit=15`) e criando o componente reutilizável `Pagination.tsx` no `apps/frontend-admin/`.
- **Fases Subsequentes (Fase 3, 4 e 5):** Adoção compulsória nas listagens de Projetos (`/projects`), Avaliadores (`/evaluators`), Premiações (`/awards`) e Credenciamento de Participantes.

---

## 4. Métricas de Esforço
- `% Feito por IA:` 20% (implementação de esquemas Pydantic, queries SQL com `count` e componente React de paginação)
- `% Híbrido:` 10% (alinhamento de usabilidade e responsividade dos botões)
- `% Participação Humana:` 70% (identificação da lacuna funcional e determinação soberana do Gestor Alex Araújo)
