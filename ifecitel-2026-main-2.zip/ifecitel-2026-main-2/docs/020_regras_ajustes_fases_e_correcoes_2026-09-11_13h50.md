# Relatório Técnico e Especificação de Novas Regras — Ajustes e Correções de Fases
**Data e Hora de Registro:** 2026-09-11 13h50  
**Autor:** Antigravity AI Assistant & Gestor Alex Araújo  
**Status:** Oficialmente Adotado e Implementado

---

## 1. Métricas de Esforço da IA
* **% Feito por IA:** 15% (Estruturação formal da documentação e contratos de interface)
* **% Híbrido:** 35% (Adequação técnica de endpoints, schemas Pydantic e componentes React)
* **% Participação Humana:** 50% (Deliberação soberana do Gestor Alex Araújo definindo regras de negócio, correções de fluxo e usabilidade)

---

## 2. Contexto e Motivação
Durante os testes práticos e validações incrementais realizados pelo Gestor Alex Araújo nas Fases 2 e 3 do projeto FECITEL, foram identificadas necessidades críticas de ajuste comportamental, integridade referencial, usabilidade visual e governança operacional.

Este documento consolida e formaliza todas essas novas regras, que passam a vigorar com caráter estrito e obrigatório em todo o ecossistema da aplicação.

---

## 3. Especificação Detalhada das Novas Regras

### 3.1. Regra BR-16 (Complemento): Soft Delete com Reativação Automática sem Erro 400
* **Problema Identificado:** Ao tentar cadastrar uma área ou subárea que havia sido desativada anteriormente (soft delete), o banco acusava violação de unicidade ou retornava erro `400 Bad Request`, impedindo o usuário de reaproveitar o nome.
* **Regra Estabelecida:**
  1. **Trava de Integridade Referencial na Exclusão:**
     - Uma Grande Área do Conhecimento só pode ser excluída (desativada) se **não possuir subáreas ativas**.
     - Uma Subárea só pode ser excluída (desativada) se **não possuir projetos vinculados** e **não possuir avaliadores vinculados**.
  2. **Reativação Automática de Registros Desativados:**
     - Caso o usuário cadastre uma nova área ou subárea com o mesmo nome de um registro que já existia no banco em estado desativado (`deleted_at IS NOT NULL`), o sistema **NÃO DEVE RETORNAR ERRO 400**.
     - Em vez de falhar, o sistema deve **reativar o registro existente**, restaurando `deleted_at = NULL` e atualizando `updated_at = NOW()`, retornando sucesso `HTTP 200/201`.

---

### 3.2. Regra UX-01: Posicionamento Obrigatório de Mensagens e Alertas em Janelas Modais
* **Problema Identificado:** Em operações com janelas modais abertas (ex: cadastro de subáreas, homologação, edição de dados), mensagens de alerta ou erros de validação eram renderizadas no fundo da tela principal, ficando ocultas atrás da janela modal e do backdrop.
* **Regra Estabelecida:**
  - Toda e qualquer mensagem de validação, erro retornado pelo backend ou alerta de integridade disparado durante uma interação em janela modal **deve ser exibida diretamente DENTRO do corpo da própria janela modal** (através da prop `error` ou de container interno de alerta).
  - É proibido manter mensagens de erro ocultas sob o overlay escurecido (`backdrop`). O usuário deve visualizar o erro imediatamente no formulário onde está atuando.

---

### 3.3. Regra DEV-01: Diretiva `"use client";` Obrigatória para Prevenção de Telas em Branco
* **Problema Identificado:** Páginas do Next.js App Router que utilizam hooks (`useState`, `useEffect`, `useContext`) ou APIs de cliente (`localStorage`, `window`) sem a marcação `"use client";` resultavam em tela em branco (*white screen of death*) e falha de compilação em componentes Server-Side.
* **Regra Estabelecida:**
  - Toda página ou componente React interativo no Next.js que manipule estado, efeitos colaterais ou contexto deve conter obrigatoriamente a diretiva `"use client";` como a **primeira linha absoluta** do arquivo.
  - O pipeline de build (`npm run build`) e a suíte de testes devem validar a ausência de componentes híbridos não declarados.

---

### 3.4. Regra BR-18 (Complemento): Busca Textual com Debounce Integrada à Paginação Real
* **Problema Identificado:** Com centenas de registros de edições ou projetos, a navegação exclusivamente por paginação tornava difícil localizar itens específicos.
* **Regra Estabelecida:**
  - Toda tela com listagem volumosa de dados (Edições do Evento, Trabalhos Científicos, Avaliadores, etc.) deve fornecer um campo de busca textual no topo.
  - A busca deve conter ícone indicador, botão para limpeza rápida do termo digitado e **debounce de 300ms** para não sobrecarregar o backend com requisições a cada tecla digitada.
  - A alteração do termo de pesquisa deve **resetar automaticamente a navegação para a página 1**.
  - O backend FastAPI deve receber o parâmetro `search: Optional[str]`, aplicando filtro SQL `ilike` que recalcula de forma atômica a contagem total de itens (`total`) e a quantidade de páginas (`total_pages`).

---

### 3.5. Regra BR-19: Seleção Obrigatória de Evento Ativo e Contexto Global de Gerenciamento
* **Regra Estabelecida:**
  - Em ambientes multi-evento, o administrador deve selecionar previamente qual evento deseja gerenciar por vez na tela de **Edições do Evento (`/events`)** através do botão *"Gerenciar este Evento"*.
  - O evento selecionado torna-se o **contexto operacional ativo global** em todo o painel, persistido no navegador do usuário (`localStorage`), governando telas dependentes como `/`, `/areas`, `/projects`, `/evaluators` e `/results`.
  - **Bloqueio de Páginas Dependentes (`RequireActiveEvent`):** Páginas que operam sob um evento não devem ser exibidas em branco caso nenhum evento tenha sido selecionado; devem renderizar um card orientador amigável convidando o usuário a selecionar uma edição em `/events`.
  - Cabeçalhos e barras de navegação exibem permanentemente o nome e ano da edição ativa com o atalho *"Trocar Edição"*.
  - A tela de Edições permite editar parâmetros da edição, respeitando a trava temporal da data limite (Regra BR-02).

---

### 3.6. Regras de Homologação Documental e Alocação de Bancadas (Fase 3 / BR-05, BR-06, BR-08)
* **Regras Estabelecidas:**
  1. **Gating de Anuência do Orientador (BR-05 / BR-06):**
     - O botão/ação de homologação (deferimento) no painel administrativo deve checar se o projeto possui a anuência digital formal do orientador (`advisor_consent == True`).
     - Tentativas de deferir projeto sem anuência do orientador devem ser bloqueadas pelo backend (`HTTP 400 Bad Request`) e alertadas previamente na interface visual com banner educativo sobre a regra BR-05.
  2. **Indeferimento com Justificativa Obrigatória (BR-06):**
     - A comissão organizadora pode indeferir (reprovar) submissões documentais inadequadas.
     - O indeferimento exige obrigatoriamente o preenchimento de uma justificativa formal (`rejection_reason`), que fica gravada no banco de dados e acessível para consulta na modal de detalhes do trabalho.
  3. **Alocação de Bancada / Estande (BR-08):**
     - O número de bancada de apresentação (ex: `A-12`, `B-05`) pode ser definido diretamente no ato do deferimento ou através de ação dedicada de alocação/remanejamento de bancada (`PATCH /api/v1/projects/{id}/booth`).
  4. **Filtros Múltiplos e Paginação (BR-18):**
     - A listagem de projetos opera sob a regra de paginação real (15 itens por página), dispondo de filtros combinados por Status, Nível de Ensino e Subárea Temática (agrupada por grande área).

---

## 4. Impacto nos Componentes e Arquivos do Sistema

| Componente / Arquivo | Regras Aplicadas | Status |
| :--- | :--- | :--- |
| `apps/backend/app/services/knowledge_area_service.py` | BR-16 (Reativação de soft-delete) | Implementado & Testado |
| `apps/backend/app/services/project_service.py` | BR-05, BR-06, BR-08, BR-18 (Listagem, Homologação, Bancadas) | Implementado & Testado |
| `apps/backend/app/api/v1/endpoints/projects.py` | BR-01, BR-18 (`GET /projects`, `PATCH /homologate`, `PATCH /booth`) | Implementado & Testado |
| `apps/frontend-admin/src/app/(dashboard)/events/page.tsx` | BR-18, BR-19, DEV-01, UX-01 (Busca, Edição ativa, Modais) | Implementado & Testado |
| `apps/frontend-admin/src/app/(dashboard)/areas/page.tsx` | BR-16, BR-19, UX-01 (Reativação, Alertas no modal, Evento ativo) | Implementado & Testado |
| `apps/frontend-admin/src/app/(dashboard)/projects/page.tsx` | BR-05, BR-06, BR-08, BR-18, BR-19, UX-01, DEV-01 | Implementado & Testado |
| `apps/frontend-admin/src/components/common/RequireActiveEvent.tsx` | BR-19 (Gating de rotas dependentes) | Implementado & Testado |
| `apps/frontend-admin/src/components/ui/Pagination.tsx` | BR-18 (Paginação universal de 15 itens) | Implementado & Testado |
