# 040 — Renomeação do Sistema para EasyEvent e Padronização Terminológica

## 1. Contexto & Motivação
Com a evolução da plataforma para um sistema genérico multi-feiras e multi-eventos acadêmicos e científicos (conforme deliberado a partir dos documentos `037`, `038` e `039`), a designação específica **FECITEL** e termos restritos deixaram de representar o escopo ampliado da aplicação.

Para tornar o sistema universal e aplicável a quaisquer congressos, mostras, simpósios e feiras científicas, foram definidas três diretrizes mandatórias:
1. **Nome do Sistema:** Substituição oficial de **FECITEL / iFecitel** por **EasyEvent**.
2. **Papel de Avaliação:** Substituição definitiva do termo **Jurado(s) / jurado(s)** por **Avaliador(es) / avaliador(es)** em todas as interfaces, alertas, botões, modais e diagnósticos.
3. **Local Físico de Apresentação:** Substituição do termo **Bancada(s) / bancada(s)** por **Estande(s) / estande(s)** em todas as telas operacionais, impressões de atas, QR Codes e leitores.

---

## 2. Decisões Arquiteturais & Estabilidade

### 2.1 Preservação de Identificadores Internos e Infraestrutura
Para preservar total compatibilidade com os serviços de banco de dados nativos, automações locais e integrações em execução:
*   **Credenciais de Conexão:** Usuário `fecitel_user`, banco `fecitel_db` e segredo universal de API `fecitel_secret_api_key_2026` permanecem inalterados no arquivo `.env` para evitar quebras de serviço ou migrações destrutivas de banco.
*   **Schema Relacional:** O identificador físico de coluna `booth_number` nas tabelas `projects` e payloads do backend é integralmente preservado. Apenas rótulos visuais, DTOs de documentação Swagger, validações e retornos em português refletem **Estande**.

### 2.2 Migração Transparente de Storage no Navegador
Para evitar desconexão forçada de usuários ativos ou perda de filas offline durante a transição:
*   As chaves de `localStorage` e `sessionStorage` passam a gravar preferencialmente no formato `easyevent_*` (`easyevent_token`, `easyevent_user`, `easyevent_active_event_user_<id>`, `easyevent_offline_evaluation_queue`).
*   Todos os métodos de leitura mantêm fallback transparente para chaves legadas `fecitel_*`.
*   O logout ou sincronização limpa simultaneamente tanto as chaves atuais quanto as legadas.

---

## 3. Matriz de Mudanças Implementadas

| Componente | Antes | Depois (EasyEvent) |
| :--- | :--- | :--- |
| **Backend (`apps/backend`)** | `FECITEL API`, `BANCADA #id`, `QR Code de bancada inválido` | `EasyEvent API`, `ESTANDE #id`, `QR Code de estande inválido` |
| **Frontend Admin (`apps/frontend-admin`)** | Marca `FECITEL`, `Bancada Pendente`, `Termômetro de Jurados`, `projetos SEM jurados`, `Ranking Geral da FECITEL` | Marca `EasyEvent`, `Estande Pendente`, `Termômetro de Avaliadores`, `projetos SEM avaliadores`, `Ranking Geral do Evento` |
| **Frontend Evaluator (`apps/frontend-evaluator`)** | Marca `FECITEL`, `BANCADA #`, `Regra de Bancada`, `Validar Código da Bancada`, `Inconsistência de Bancada` | Marca `EasyEvent`, `ESTANDE #`, `Regra de Estande`, `Validar Código do Estande`, `Inconsistência de Estande` |
| **Frontend TV Kiosk (`apps/frontend-kiosk`)** | `FECITEL — Telão TV`, `Projetos em Bancada`, `Corpo de Jurados`, `Andamento das Bancadas` | `EasyEvent — Telão TV`, `Projetos em Estande`, `Corpo de Avaliadores`, `Andamento dos Estandes` |
| **Scripts & Raiz** | `FECITEL — Inicializando Monorepo (4 Blocos Locais)` | `EasyEvent — Inicializando Monorepo (4 Blocos Locais)` |

---

## 4. Garantia de Qualidade
*   **Backend:** Suíte automatizada com 39 testes (`pytest`) cobrindo autenticação, multi-eventos, alocação balanceada, critérios de avaliação, apuração e notas, com 100% de aprovação.
*   **Frontend:** Checagem rigorosa de tipos TypeScript em todas as aplicações (`tsc --noEmit`).
