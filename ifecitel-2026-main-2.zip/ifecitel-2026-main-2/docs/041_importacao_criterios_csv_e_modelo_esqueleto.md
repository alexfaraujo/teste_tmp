# 041 — Geração de Modelo Esqueleto CSV e Importação em Lote de Critérios de Avaliação

## 1. Contexto & Objetivo
No módulo de governança de critérios de avaliação (`/criteria`) do **EasyEvent Admin**, os organizadores parametrizam as perguntas da ficha de avaliação mobile para trabalhos científicos e tecnológicos (Regras **BR-11** e **BR-12**).

Para agilizar o cadastramento em lote de eventos com muitos critérios e facilitar a preparação prévia por comissões científicas fora do sistema, foram implementadas duas capacidades centrais:
1. **Download de Modelo Esqueleto CSV:** Geração imediata de uma planilha modelo formatada especificamente para o EasyEvent, pronta para preenchimento no Microsoft Excel ou Google Planilhas.
2. **Importação em Lote com Pré-visualização Interativa (Preview):** Upload de planilha `.csv` com detecção automática de delimitadores, identificação em tempo real de critérios novos vs. atualizações e gravação atômica (*Upsert*) no banco de dados.

---

## 2. Estrutura do Arquivo CSV Modelo

O modelo gerado utiliza codificação **UTF-8 com BOM (`\uFEFF`)** e delimitador padrão ponto e vírgula (`;`), garantindo que o Microsoft Excel em computadores Windows e macOS abra o arquivo com acentuação perfeitamente legível no padrão brasileiro.

### Cabeçalho Oficial:
```csv
nome;pergunta_unica;descricao_cientifica;descricao_tecnologica;nota_maxima;peso
```

### Detalhamento das Colunas:
| Coluna | Obrigatória? | Descrição | Exemplo |
| :--- | :---: | :--- | :--- |
| `nome` | **Sim** | Título / identificador unívoco do critério na ficha | `Critério 1: Rigor Metodológico` |
| `pergunta_unica` | Opcional | Formulação única aplicada tanto para projetos científicos quanto tecnológicos (para eventos sem distinção de modalidade) | `Como a equipe apresentou a metodologia e resultados?` |
| `descricao_cientifica` | Opcional* | Formulação exibida no app mobile quando o projeto for do tipo Científico | `Como a equipe formulou a hipótese e controlou variáveis?` |
| `descricao_tecnologica` | Opcional* | Formulação exibida no app mobile quando o projeto for do tipo Tecnológico | `Como a equipe projetou o protótipo e testou o funcionamento?` |
| `nota_maxima` | Opcional | Pontuação máxima da pergunta (padrão `10,0`; suporta vírgula ou ponto) | `10,0` |
| `peso` | Opcional | Peso multiplicador padrão na média ponderada (padrão `1,0`) | `1,5` |

*\* Se `pergunta_unica` estiver preenchida, o sistema preenche automaticamente tanto a descrição científica quanto a tecnológica com o mesmo texto.*

---

## 3. Arquitetura de Importação & Regras de Negócio

### 3.1 Parser Inteligente e Tolerante a Falhas (`utils/criteriaCsv.ts`)
*   **Detecção de Delimitador:** Identifica automaticamente se a planilha foi exportada com ponto e vírgula (`;`), vírgula (`,`) ou tabulação (`\t`).
*   **Decimais Brasileiros:** Converte tanto `10,0` quanto `10.0` de forma segura.
*   **Normalização de Cabeçalhos:** Aceita variações comuns de títulos de coluna (`nome`, `name`, `criterio`, `titulo`, `peso`, `weight`, `nota_maxima`, `max_score`, `cientifico`, `tecnologico`).

### 3.2 Modal Interativo de Pré-visualização (`CriteriaCsvImportModal.tsx`)
Antes de qualquer alteração no banco de dados, o organizador visualiza uma tabela completa com a auditoria dos dados do arquivo:
*   🟢 **Badge NOVO:** Critério que não existe na edição atual e será criado.
*   🔵 **Badge ATUALIZAR:** Critério que já existe no evento (correspondência sem distinção de maiúsculas/minúsculas). O sistema atualizará textos, notas e pesos sem perder histórico.
*   🔴 **Badge ERRO:** Linhas com erros de validação (ex: nome em branco, nota máxima menor que zero), com detalhes destacados linha a linha.
*   **Resumo Estatístico:** Contadores de total, novos, atualizações e inválidos.

### 3.3 Transação Atômica no Backend (`POST /events/{event_id}/criteria/batch`)
*   Protegido pelo controle de acesso de evento (`require_event_role(EventAdminRole.ORGANIZER)`) e trava temporal de edição (`verify_event_temporal_lock`).
*   **Idempotência / Upsert:** Se o critério já existir, atualiza os campos e remove eventual marcação de `deleted_at` (reativação automática). Se for novo, executa o `INSERT`.
*   **Preservação de Dados:** Critérios já cadastrados no evento que **não constem no CSV são mantidos 100% intactos**.
*   **Atomicidade:** Toda a sincronização é executada em uma única transação SQL (`await db.commit()`). Caso ocorra qualquer falha, toda a operação sofre rollback.

---

## 4. Endpoints Disponibilizados

1. `GET /api/v1/events/{event_id}/criteria/template-csv`: Download do modelo esqueleto oficial em UTF-8 BOM via API.
2. `POST /api/v1/events/{event_id}/criteria/batch`: Sincronização em lote a partir do payload JSON validado pelo frontend.
3. `POST /api/v1/events/{event_id}/criteria/upload-csv`: Endpoint multipart para upload direto de arquivos CSV (útil para scripts de automação, cURL e integrações externas).

---

## 5. Garantia da Qualidade & Testes
*   **Testes de Integração (`test_criteria_csv.py`):**
    *   `test_criteria_csv_template_and_batch_import`: valida download do modelo, criação em lote, upsert atômico e preservação de critérios preexistentes.
    *   `test_criteria_upload_csv_file`: valida upload direto de arquivo `.csv` com delimitador `;`, UTF-8 BOM e pontuações decimais com vírgula (`10,0`).
*   **Checagem Estática:** 100% dos testes da suíte backend (`41 passed`) e tipagem TypeScript (`npx tsc --noEmit`) aprovados sem erros.
