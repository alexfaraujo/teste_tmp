# Documentação Técnica: Emissão de Cards de Kits em PDF (Individual e Coletivo por Projeto) com Concessão Flexível de Camisetas — EasyEvent

**Data:** 14 de Setembro de 2026  
**Status:** Implementado & Validado  
**Regras de Referência:** Regra BR-08 (Alocação de Estande e Credenciamento na Recepção), Regra BR-09 (Baixa Atômica de Kits e Camisetas) e Regra BR-29 (Emissão de Cards de Kits para Logística de Feira)  
**Módulos Impactados:** `apps/backend` (Service `kit_card_service.py`, Endpoints `events.py` e `logistics.py`, Testes `test_kit_cards_pdf.py`), `apps/frontend-admin` (Types, Services, Modal `KitCardsModal.tsx`, Telas `logistics/page.tsx` e `projects/page.tsx`), `docs` (`049_emissao_cards_kits_individuais_e_por_projeto.md`, `context.md`, `database.md`).

---

## 1. Contexto e Motivação Operacional

Nas edições anuais de feiras científicas e mostras tecnológicas (como a FECITEL), a etapa de entrega dos kits de boas-vindas e camisetas é um dos momentos de maior concentração e gargalo na portaria. Historicamente, os organizadores adotam duas abordagens logísticas distintas dependendo da infraestrutura e dos recursos disponíveis:

1. **Abordagem Coletiva por Projeto / Estande:**
   * Uma única sacola ou caixa kraft reúne os kits e crachás de todos os autores do trabalho.
   * O orientador ou um dos estudantes retira o pacote completo do estande na recepção.
   * **Vantagem:** Reduz o fluxo de retiradas na portaria em até $70\%$, eliminando filas e acelerando a entrada das caravanas escolares.
2. **Abordagem Individual por Participante:**
   * Cada participante (aluno, orientador ou avaliador) retira individualmente seu próprio kit na bancada de recepção mediante apresentação ou leitura óptica de sua credencial.
   * **Vantagem:** Controle individual absoluto de entrega.

Além disso, muitas edições enfrentam **restrições orçamentárias**: os recursos nem sempre comportam a aquisição de camisetas para todas as categorias de participantes (ex: a feira pode ter verba para camisetas apenas de estudantes, não fornecendo camisetas para orientadores, coorientadores ou avaliadores). Quando um participante visualiza um tamanho de camiseta impresso no crachá ou no kit em um evento que não oferece camiseta para sua categoria, geram-se constrangimentos e questionamentos desnecessários na recepção.

---

## 2. Solução Implementada (Regra BR-29)

O EasyEvent agora disponibiliza um motor de geração de PDFs vetoriais de alta resolução via **ReportLab**, permitindo que a comissão organizadora emita os cards de kits prontos para impressão em folha A4 com guias de corte pontilhadas e códigos de barras ópticos Code128.

### 2.1 Formato A: Coletivo por Projeto / Estande (Grade 1x2 — 2 por folha A4)
* **Diagramação:** Formato generoso de meia folha A4 ($\approx 192\,\text{mm} \times 136\,\text{mm}$ ou $545\,\text{pt} \times 385\,\text{pt}$), projetado para ser colado na lateral de sacolas grandes de papel kraft ou caixas organizadoras de estande.
* **Componentes Visuais do Card de Projeto:**
  1. **Cabeçalho com Logotipo ou Identificação do Evento (à esquerda do Estande):**
     * **Com Logotipo Cadastrado:** O logotipo oficial ocupa toda a extensão horizontal útil disponível no cabeçalho ($\approx 335\,\text{pt} \times 44\,\text{pt}$) à esquerda do badge de estande, com proporção preservada e alinhamento à esquerda. O nome do evento e o local de realização **não são impressos** para evitar redundância com a arte oficial. O texto estático `"EASYEVENT • LOGÍSTICA DE KITS POR ESTANDE"` foi removido.
     * **Sem Logotipo Cadastrado (Fallback):** São impressos em destaque o Nome do Evento e Ano ($12.5\,\text{pt}$ negrito) e o Local de Realização (`location` ou `institution`, $9.0\,\text{pt}$).
  2. **Badge Gigante de Estande:** No canto superior direito, em bloco escuro com texto destacado em ciano/branco de 16pt a 20pt (ex: `ESTANDE: 5141` ou `ESTANDE: A-04`), visível a metros de distância nas pilhas ou estantes de kits organizados por rua do pavilhão.
  3. **Identificação do Trabalho:** Título em caixa alta com quebra automática, Área Temática, Subárea, Nível de Ensino e Escola / Instituição.
  4. **Pills de Infraestrutura:** Badges visuais indicando se o projeto solicitou tomada (`ENERGIA: SIM`) e mesa de apoio (`MESA: SIM`), facilitando a conferência pelos voluntários antes de liberar a equipe para montagem do estande.
  5. **Resumo de Conteúdo do Pacote:**
     * Box de destaque em tom verde com a contagem exata do que o voluntário deve colocar na sacola:
       * `TOTAL DE KITS: 5 • TOTAL DE CAMISETAS NO PACOTE: 3`
       * `Camisetas a incluir na sacola: 3x M`
     * O cálculo contabiliza exclusivamente as categorias que foram autorizadas pelo administrador. Se os orientadores estiverem desmarcados, o total de camisetas reflete apenas os alunos.
  6. **Tabela / Checklist Nominal da Equipe:**
     * Lista linha a linha com caixas de marcação `[ ]` para conferência manual ou física:
       * `[ ] NOME DO INTEGRANTE` • `PAPEL NO PROJETO` • `CAMISETA CONCEDIDA`
       * Exemplo: `ALINE VILAR MACHADO NILS (ORIENTADOR) — Sem camiseta`
       * Exemplo: `THOMAS DARWIN RAPOSO (ESTUDANTE) — TAMANHO: M`
  7. **Código do Estande Code128:** Padronizado com o próprio código do estande (`projects.qrcode_token`). Qualquer integrante da equipe (orientador, coorientador ou estudantes) pode retirar o kit completo na recepção, disparando a baixa atômica de todos os kits (`POST /api/v1/logistics/project-kits/{id}/checkout`).
  8. **Guia de Corte:** Linha pontilhada no centro da folha A4.

### 2.2 Formato B: Individual por Participante (Grade 2x3 — 6 por folha A4)
* **Diagramação:** 6 etiquetas por folha A4 ($95\,\text{mm} \times 86\,\text{mm}$ ou $265\,\text{pt} \times 245\,\text{pt}$), com linhas de corte horizontal e vertical pontilhadas.
* **Componentes Visuais do Card Individual:**
  1. **Cabeçalho Superior:**
     * À direita: Tag visual do papel (`ESTUDANTE`, `ORIENTADOR`, `COORIENTADOR`, `AVALIADOR`).
     * À esquerda: Se houver logotipo cadastrado, renderiza o logotipo na área disponível ($18\,\text{pt}$ de altura) sem nome nem local. Se não houver logotipo, renderiza o Nome do Evento e Localidade/Ano.
  2. **Nome do Participante:** Destaque em negrito caixa alta com quebra automática de linha.
  3. **Vínculo do Estande & Trabalho:** Identificação do número de estande e título do trabalho científico vinculado (ou afiliação institucional).
  4. **Caixa de Concessão de Camiseta:**
     * **Se a categoria tiver camiseta habilitada:** Box azul em destaque exibindo com letras grandes: `CAMISETA NO KIT: [ M ]` e instrução de conferência de tamanho.
     * **Se a categoria estiver desmarcada:** Box neutro indicando `KIT BÁSICO (SEM CAMISETA)` e menção de categoria sem concessão nesta edição.
  5. **Código de Barras Code128:** Código individual de barras do participante para bipagem óptica e baixa atômica com trava de concorrência (`kit_delivered = True`).

---

## 3. Filtro de Concessão de Camisetas por Categoria (Regra de Negócio)

Para fornecer flexibilidade total aos organizadores frente às limitações orçamentárias:
* O sistema recebe parâmetros booleanos independentes:
  * `include_tshirt_students: bool` (padrão: `True`)
  * `include_tshirt_advisors: bool` (padrão: `False`)
  * `include_tshirt_coadvisors: bool` (padrão: `False`)
  * `include_tshirt_evaluators: bool` (padrão: `False`)
* **Impacto Visual e Operacional:**
  * No Card Coletivo do Projeto: apenas integrantes cujas categorias tenham recebido autorização de camiseta terão o tamanho discriminado no checklist e somado na contagem do box verde de *Packing List*.
  * No Card Individual: se a categoria do participante estiver autorizada, imprime-se o box azul com o tamanho real cadastrado (`PP`, `P`, `M`, `G`, `GG`, `XG`); caso desmarcada, imprime-se tarja informando que o kit é básico e sem camiseta.

### 3.1 Origem dos Tamanhos de Camiseta e Sincronização via CSV de Projetos
Durante a importação em lote de trabalhos científicos no painel de administração (`/projects`), o modelo CSV disponibiliza colunas nominais de tamanho de camiseta para cada integrante da equipe:
* `orientador_camiseta`
* `coorientador_camiseta`
* `autor{i}_camiseta` (para $i = 1 \dots N$)

**Regras de Persistência e Sincronização:**
1. **Normalização Automática:** Aceita `PP`, `P`, `M`, `G`, `GG`, `XG` (normalizados para caixa alta). Vazio ou inválido recebe `"M"` como fallback seguro.
2. **Upsert em `event_participants`:** O backend (`project_service.import_projects_batch`) cadastra ou atualiza o campo `tshirt_size` na tabela `event_participants` do participante para aquela edição específica do evento.
3. **Reflexão nos Cards de Kit:** Quando os cards individuais ou por projeto são gerados em PDF, o ReportLab extrai os tamanhos reais persistidos na participação daquele evento (`ep.tshirt_size`), eliminando qualquer distorção onde todos os participantes recebiam inadvertidamente tamanho `"M"`.

---

## 4. Endpoints da API REST (Backend FastAPI)

### 4.1 `GET /api/v1/events/{event_id}/kit-cards/pdf`
Rota principal para emissão dos cards sob o módulo de Eventos. Requer papel mínimo `ORGANIZER` no evento.

**Parâmetros de Consulta (Query Params):**
| Parâmetro | Tipo | Padrão | Descrição |
|---|---|---|---|
| `format` | `string` | `"project"` | Formato de impressão: `"project"` (2/folha) ou `"individual"` (6/folha). |
| `include_tshirt_students` | `boolean` | `true` | Se deve exibir tamanho de camiseta para estudantes/autores. |
| `include_tshirt_advisors` | `boolean` | `false` | Se deve exibir tamanho de camiseta para professores orientadores. |
| `include_tshirt_coadvisors` | `boolean` | `false` | Se deve exibir tamanho de camiseta para coorientadores. |
| `include_tshirt_evaluators` | `boolean` | `false` | Se deve exibir tamanho de camiseta para avaliadores (formato individual). |
| `sort_by` | `string` | `"booth"` | Ordenação das páginas: `"booth"` (por estande), `"school"` (por escola/instituição) ou `"title"` (alfabética). |
| `status_filter` | `string` | `"homologated"` | Filtro de trabalhos: `"homologated"` (homologados/presentes/avaliados) ou `"all"` (todos os ativos). |

**Resposta:** Arquivo binário em streaming `application/pdf` com cabeçalho `Content-Disposition: attachment; filename="cards_kits_evento_{id}_{format}.pdf"`.

### 4.2 `GET /api/v1/logistics/events/{event_id}/kit-cards/pdf`
Rota complementar disponibilizada sob o roteador de logística (`/logistics`) com os mesmos parâmetros e comportamento.

---

## 5. Interface do Usuário (Frontend Admin)

### 5.1 Componente `KitCardsModal.tsx`
Localizado em `apps/frontend-admin/src/components/logistics/KitCardsModal.tsx`, provê um diálogo moderno e intuitivo:
* **Cards Interativos de Seleção de Formato:** Opção visual entre "Coletivo por Projeto (2 por folha)" e "Individual por Pessoa (6 por folha)".
* **Seção de Concessão de Camisetas:** Checkboxes independentes para Estudantes, Orientadores, Coorientadores e Avaliadores.
* **Dropdowns de Configuração:** Seleção de ordenação da impressão e status dos projetos.
* **Feedback de Download:** Botão de ação com spinner animado durante a geração e download automático do arquivo no navegador.

### 5.2 Pontos de Acesso no Painel
O botão **`"Cards de Kits (PDF)"`** foi inserido de forma destacada em duas áreas estratégicas:
1. **Mesa de Credenciamento & Logística (`/logistics`):** No cabeçalho principal, permitindo à equipe de portaria e entrega de kits reemitir ou imprimir os cards a qualquer momento.
2. **Gestão de Trabalhos Científicos (`/projects`):** Na barra de ferramentas de topo, ao lado dos botões de importação e exportação de CSV.

---

## 6. Cobertura de Testes Automatizados

A suíte em `apps/backend/tests/test_kit_cards_pdf.py` valida 100% dos fluxos essenciais:
* `test_generate_project_kit_cards_service_direct`: Valida geração direta do PDF coletivo com resumo de pacote e discriminativo de camisetas.
* `test_generate_individual_kit_cards_service_direct`: Valida geração direta do PDF individual com grade 2x3.
* `test_kit_cards_pdf_endpoint_via_events`: Valida requisições HTTP na rota de eventos com variações de formato, filtros e ordenação.
* `test_kit_cards_pdf_endpoint_via_logistics`: Valida a rota complementar de logística.
* `test_stand_barcode_scan_and_project_package_checkout`: Valida a padronização do código do pacote com o estande (`qrcode_token`), o reconhecimento na portaria e a baixa coletiva de todos os kits da equipe (`checkout_project_kits`).

---

## 7. Mapeamento Geral de Códigos Ópticos e Rastreabilidade

| Elemento Óptico | Simbologia | Entidade & Coluna no Banco de Dados | Padrão / Formato do Valor | Onde Aparece no Sistema | Ação / O que Dispara ao Ser Lido |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Código de Barras do Participante** | Linear **Code128** | Tabela: `people`<br>Campo: `barcode`<br>`VARCHAR(100) UNIQUE NULL` | `BC-XXXXX`<br>*(ex: `BC-A8K2F` ou `BC-00042`)* | • **Crachás em PDF** (rodapé inferior central)<br>• **Cards Individuais de Kit em PDF** (rodapé inferior direito)<br>• Tela `/participants` (Admin - coluna Documento)<br>• Input óptico na tela `/logistics` (Portaria) | **Credenciamento & Retirada de Kit Individual:** Ao ser bipado com leitor óptico laser na recepção, registra a presença da pessoa física (`presence_confirmed = True`) e a baixa do kit/camiseta (`kit_delivered = True`). Se o participante for autor de trabalho científico, dispara a **Presença Coletiva (Regra BR-08)**, promovendo o status do projeto para `PRESENT`. |
| **QR Code do Perfil do Avaliador** | Bidimensional **QR Code (2D)** | Tabela: `people`<br>Campo: `barcode`<br>`VARCHAR(100) UNIQUE NULL` | `BC-XXXXX`<br>*(reutiliza o mesmo barcode pessoal)* | • App Mobile do Avaliador (tela **"Meu Perfil"**, exibido na tela do smartphone) | **Check-in de Avaliadores:** O avaliador apresenta a tela do celular na Sala dos Avaliadores. A recepção lê o QR Code em `/evaluators/checkin`, confirmando a presença do avaliador (`evaluator_presence_confirmed = True`) e disparando a **alocação automática e balanceada de projetos** ($\Delta \le 1$). |
| **QR Code da Bancada / Estande** | Bidimensional **QR Code (2D)** | Tabela: `projects`<br>Campo: `qrcode_token`<br>`VARCHAR(100) UNIQUE NOT NULL` | `FECITEL-2026-XXXXXXXXXXXXXXXX`<br>*(ou `ID Trabalho` numérico legado)* | • **Placa / Adesivo de Estande** (impresso e afixado na bancada física do projeto)<br>• Modal de Detalhes do Projeto em `/projects` (Admin) | **Abertura da Ficha Oficial de Avaliação:** O avaliador aponta a câmera do smartphone no app mobile (tela `/scan`) para a placa da bancada. O sistema valida se o avaliador está alocado para o trabalho, confere inexistência de conflito de interesses (escola/parentesco) e abre a **Ficha de Avaliação** (Científica ou Tecnológica) com notas de 0 a 10. |
| **Código do Pacote do Projeto (Card Coletivo)** | Linear **Code128** | Tabela: `projects`<br>Campo: `qrcode_token`<br>`VARCHAR(100) UNIQUE NOT NULL` | `FECITEL-2026-XXXXXXXXXXXXXXXX`<br>*(ou `PRJ-{id:05d}` em fallback)* | • Rodapé inferior esquerdo do **Card Coletivo de Kit por Projeto** (PDF impresso colado na sacola/caixa kraft) | **Retirada do Pacote do Estande por Qualquer Integrante:** O voluntário bipa a sacola kraft na tela `/logistics`. Como o código é padronizado com o estande (`projects.qrcode_token`), o sistema reconhece o projeto, promove o estande para `PRESENT` e permite com 1 clique (`POST /api/v1/logistics/project-kits/{id}/checkout`) a **baixa coletiva e atômica de todos os kits da equipe**. **Qualquer integrante do grupo (orientador, coorientador ou estudantes)** pode retirar o pacote completo na portaria. |
