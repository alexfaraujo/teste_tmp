# Registro Arquitetural: Separação dos Postos de Check-in (Geral vs. Sala dos Avaliadores)

* **Data:** 11 de Setembro de 2026, 16:35
* **Edição / Contexto:** FECITEL (Feira de Ciência e Tecnologia)
* **Regras de Negócio Envolvidas:** BR-08 (Presença e Logística), BR-09 (Baixa Atômica de Kits), BR-10 (Alocação Dinâmica e Rebalanceamento de Avaliadores).

---

## 1. Contexto e Motivação Operacional

Em feiras científicas de grande porte como a FECITEL, participantes que acumulam múltiplos papéis (especialmente professores que atuam como Orientadores de trabalhos de alunos e também como Avaliadores de outras subáreas) possuem jornadas físicas completamente distintas durante a manhã do evento:

1. **Momento 1 — Recepção Geral / Portaria:**
   - O professor orientador chega nos ônibus com a caravana de estudantes.
   - Sua urgência inicial é credenciar os alunos, retirar crachás, camisetas e kits, e ir ao pavilhão auxiliar os estudantes na colagem de banners, montagem de maquetes e ligação de computadores nos estandes.
   - **Problema anterior:** Se o sistema atribuísse trabalhos de avaliação no ato do credenciamento da portaria, o orientador ficaria com trabalhos alocados enquanto ainda estava ocupado com seus alunos, bloqueando a avaliação dos estandes alheios. Além disso, o avaliador ainda não havia participado da reunião de alinhamento metodológico com a comissão científica.

2. **Momento 2 — Sala dos Avaliadores (Comissão Científica):**
   - Mais tarde, os avaliadores reúnem-se na sala reservada da comissão para o *briefing* sobre critérios de pontuação, postura pedagógica com estudantes e prazos.
   - Somente após essa reunião e apresentação formal na mesa da sala dos avaliadores é que o avaliador está pronto para receber suas pautas e ir a campo avaliar.

3. **Caso de Avaliador Exclusivo (sem projetos no evento):**
   - Participantes cadastrados exclusivamente com o papel de Avaliador dirigem-se diretamente à Sala dos Avaliadores.
   - O check-in na sala dos avaliadores deve, portanto, suprir tanto a presença física no evento quanto a presença de avaliador, permitindo inclusive o controle de entrega de camiseta e kit ali mesmo.

---

## 2. Alterações de Modelagem e Banco de Dados (PostgreSQL)

Adicionou-se à tabela `event_participants` duas novas colunas para rastreamento inequívoco do status na Sala dos Avaliadores:

```sql
ALTER TABLE event_participants 
ADD COLUMN IF NOT EXISTS evaluator_presence_confirmed BOOLEAN NOT NULL DEFAULT FALSE,
ADD COLUMN IF NOT EXISTS evaluator_presence_confirmed_at TIMESTAMP WITH TIME ZONE;
```

* `presence_confirmed` / `presence_confirmed_at`: Registra que o participante chegou fisicamente ao evento (feito na Portaria Geral ou no Posto de Avaliadores).
* `evaluator_presence_confirmed` / `evaluator_presence_confirmed_at`: Registra que o avaliador apresentou-se especificamente na Sala dos Avaliadores e foi instruído para avaliar.

---

## 3. Comportamento Sistêmico dos Endpoints (FastAPI)

1. **`POST /api/v1/logistics/scan-barcode` (Credenciamento Geral / Recepção):**
   - Confirma `presence_confirmed = True`.
   - Permite baixa de kit e camiseta (`kit_delivered`).
   - Dispara a Presença Coletiva (BR-08) promovendo os projetos dos quais a pessoa é integrante para `PRESENT` (bancada montada).
   - **NÃO aloca trabalhos de avaliação.** Se a pessoa possuir o papel de Avaliador, emite aviso informando que a pauta e alocação ocorrem na Sala dos Avaliadores.

2. **`POST /api/v1/allocations/evaluators/scan-checkin` (Novo — Sala dos Avaliadores):**
   - Aceita código de barras, QR Code token ou CPF do avaliador.
   - Valida se a pessoa possui o papel `EVALUATOR` nesta edição do evento. Se não possuir, retorna erro `400 Bad Request`.
   - Confirma `evaluator_presence_confirmed = True` e `evaluator_presence_confirmed_at = now`.
   - Garante `presence_confirmed = True` caso a pessoa tenha ido diretamente à sala.
   - Executa a **Alocação Dinâmica Imediata** (`allocate_evaluator_on_checkin`), buscando trabalhos presentes na mesma subárea e garantindo a Regra de Ouro ($\Delta \le 1$) e teto máximo.
   - Retorna os dados do avaliador, subáreas, status do kit e os trabalhos alocados na hora.

3. **`POST /api/v1/allocations/auto-balance` (Rebalancear Sistema):**
   - O algoritmo de rebalanceamento agora filtra candidatos com:
     `EventParticipant.evaluator_presence_confirmed.is_(True)`.
   - Impede que orientadores ou avaliadores ausentes da sala recebam trabalhos automaticamente.

---

## 4. Frontend Admin (Next.js)

1. **Página de Credenciamento Geral (`/logistics`):** Focada na recepção, alunos e equipes.
2. **Nova Página: Check-in dos Avaliadores (`/evaluators/checkin`):** Focada na mesa da comissão julgadora, com leitor de código de barras/QR Code/CPF, busca rápida de avaliadores e exibição dos estandes alocados.
3. **Menu Lateral (`Sidebar.tsx`):** Exibe links distintos para "Credenciamento Geral" e "Check-in dos Avaliadores".
