# Registro Cronológico: Conclusão da Fase 4 — Alocação Balanceada de Avaliadores e Avaliação Presencial Mobile-First

**Data:** 11/09/2026 — 09h50  
**Autor:** Engenheiro de Software Fullstack / Especialista em Sistemas de Alto Desempenho  
**Status:** CONCLUÍDO COM 100% DE APROVAÇÃO NOS TESTES (24/24 testes aprovados em PostgreSQL Bare-Metal)

---

## 1. Escopo Entregue da Fase 4

A Fase 4 implementou o coração acadêmico e logístico da FECITEL: o algoritmo de distribuição balanceada de avaliadores e a ficha de avaliação presencial mobile-first via QR Code de bancada.

### 1.1 Algoritmo de Alocação Balanceada de Avaliadores (Regra BR-10)
- **Momento 1 (Alocação Dinâmica no Check-in do Avaliador e Balanceamento Contínuo):**
  - O check-in de autores (que confirma presença do projeto na bancada `PRESENT`) e o check-in de avaliadores ocorrem paralelamente e de forma contínua durante todo o evento.
  - No instante do check-in do avaliador (seja via leitura de crachá `POST /api/v1/logistics/scan-barcode`, seja via endpoint de check-in de avaliador `POST /api/v1/allocations/evaluators/{id}/checkin`):
    - O sistema filtra os projetos com presença física confirmada (`status = 'PRESENT'`) na mesma subárea do avaliador.
    - Ordena os trabalhos de forma ascendente pela quantidade atual de avaliadores atribuídos (prioriza quem tem menos avaliadores).
    - Exclui impedimentos e conflitos de interesse (orientador, coorientador ou membros da equipe).
    - Aloca o avaliador até a capacidade máxima (`max_projects_per_evaluator`), assegurando a Regra de Ouro ($\Delta \le 1$).
  - Mantido também o endpoint global `POST /api/v1/allocations/auto-balance` para rebalanceamento ou equalização global por demanda pela coordenação.
- **Momento 2 (Remanejamento Manual):**
  - Permite aos administradores vincular ou substituir avaliadores pontualmente (`POST /api/v1/allocations/manual` e `DELETE /api/v1/allocations/{id}`), com validação mandatória de conflito de interesses.

### 1.2 Avaliação Presencial Mobile-First (Regras BR-11 e BR-12)
- **Leitura do QR Code de Bancada (BR-08, BR-11):**
  - O avaliador aponta a câmera do smartphone para o QR Code afixado no estande/bancada.
  - Endpoint `GET /api/v1/evaluations/sheet?qrcode={token}` carrega a ficha mestre-detalhe adaptada dinamicamente:
    - Se o projeto for `SCIENTIFIC`: exibe as diretrizes do método científico e reprodutibilidade.
    - Se o projeto for `TECHNOLOGICAL`: exibe as diretrizes de arquitetura, prototipagem e viabilidade de mercado.
- **Parecer Geral Consolidado Único (BR-11):**
  - Campo de texto rico `general_feedback` exigido na submissão (`POST /api/v1/evaluations`), garantindo uma devolutiva pedagógica construtiva e humanizada para a equipe de estudantes.
- **Cálculo da Nota Final por Média Aritmética Simples (BR-12):**
  - Endpoint `GET /api/v1/evaluations/project/{id}/summary` calcula a nota oficial da feira por **média aritmética simples sem descarte de notas extremas**:
    $$\text{Nota Final} = \frac{\sum_{i=1}^N \text{Nota}_i}{N}$$
  - Sem descarte das notas maiores ou menores, preservando a integridade estatística da amostragem de avaliadores.
- **Transição da Máquina de Estados (BR-06):**
  - Projeto transiciona para `UNDER_EVALUATION` ao receber a primeira submissão de notas.
  - Projeto transiciona para `EVALUATED` quando todas as alocações ativas do trabalho são concluídas (`COMPLETED`).

### 1.3 Proteção Universal por API Key (Regra SEC-03)
- 100% das novas rotas (`/api/v1/allocations/*` e `/api/v1/evaluations/*`) herdam a proteção obrigatória de API Key corporativa do roteador central via cabeçalho `X-API-Key`.

---

## 2. Arquivos Implementados e Alterados

| Camada | Arquivo | Responsabilidade |
| :--- | :--- | :--- |
| **Modelos** | `apps/backend/app/models/person.py` | Modelo `PersonSubarea` para qualificação de avaliadores |
| **Modelos** | `apps/backend/app/models/evaluation.py` | Modelos `EvaluatorAllocation`, `Evaluation`, `EvaluationItem` |
| **Schemas** | `apps/backend/app/schemas/allocation.py` | DTOs de qualificação, auto-balanceamento e alocação manual |
| **Schemas** | `apps/backend/app/schemas/evaluation.py` | DTOs de ficha mobile, submissão de notas e parecer consolidado |
| **Services** | `apps/backend/app/services/allocation_service.py` | Algoritmo balanceado com Regra de Ouro ($\Delta \le 1$) e remanejamento |
| **Services** | `apps/backend/app/services/evaluation_service.py` | Ficha QR mobile, cálculo de notas e média aritmética simples BR-12 |
| **Endpoints** | `apps/backend/app/api/v1/endpoints/allocations.py` | Rotas REST `/api/v1/allocations/*` |
| **Endpoints** | `apps/backend/app/api/v1/endpoints/evaluations.py` | Rotas REST `/api/v1/evaluations/*` |
| **Roteador** | `apps/backend/app/api/v1/router.py` | Registro das novas rotas com dependência global de API Key |
| **Dependências** | `apps/backend/app/api/deps.py` | Dependência `get_current_evaluator` |
| **Testes** | `apps/backend/tests/test_phase4.py` | 6 novos testes automatizados cobrindo fluxos da Fase 4 |

---

## 3. Cobertura de Testes Automatizados (Zero Mocks — 24/24 Aprovados)

Execução realizada diretamente contra PostgreSQL 18 local bare-metal:

```bash
collected 24 items

tests/test_auth.py::test_access_code_generation_format PASSED            [  4%]
tests/test_auth.py::test_bcrypt_password_hashing PASSED                  [  8%]
tests/test_auth.py::test_admin_login_success PASSED                      [ 12%]
tests/test_auth.py::test_admin_login_invalid_credentials PASSED          [ 16%]
tests/test_auth.py::test_participant_otp_request_and_login_flow PASSED   [ 20%]
tests/test_auth.py::test_participant_otp_invalid_code PASSED             [ 25%]
tests/test_auth.py::test_soft_deleted_user_cannot_login PASSED           [ 29%]
tests/test_phase2.py::test_create_and_list_events_with_temporal_lock PASSED [ 33%]
tests/test_phase2.py::test_knowledge_areas_crud_and_integrity_lock PASSED [ 37%]
tests/test_phase2.py::test_awards_crud_and_criteria_linking PASSED       [ 41%]
tests/test_phase2.py::test_project_submission_quotas_and_advisor_consent PASSED [ 45%]
tests/test_phase2.py::test_universal_api_key_protection_on_get_and_mutations PASSED [ 50%]
tests/test_phase3.py::test_project_homologation_and_booth_assignment PASSED [ 54%]
tests/test_phase3.py::test_barcode_checkin_and_collective_presence_trigger PASSED [ 58%]
tests/test_phase3.py::test_atomic_kit_checkout_and_duplicate_prevention PASSED [ 62%]
tests/test_phase3.py::test_project_kits_summary_query PASSED             [ 66%]
tests/test_phase3.py::test_public_tv_dashboard_metrics_and_privacy_guarantee PASSED [ 70%]
tests/test_phase3.py::test_phase3_api_key_protection PASSED              [ 75%]
tests/test_phase4.py::test_qualify_evaluator_subareas PASSED             [ 79%]
tests/test_phase4.py::test_auto_balance_allocation_golden_rule_delta_le_1 PASSED [ 83%]
tests/test_phase4.py::test_manual_allocation_and_conflict_of_interest PASSED [ 87%]
tests/test_phase4.py::test_get_evaluation_sheet_via_qrcode_mobile PASSED [ 91%]
tests/test_phase4.py::test_submit_evaluation_and_simple_arithmetic_mean_br12 PASSED [ 95%]
tests/test_phase4.py::test_sec03_universal_api_key_protection_phase4 PASSED [100%]

======================== 24 passed, 1 warning in 3.02s =========================
```

---

## 4. Governança e Diretrizes de Commit
- Conforme a regra `RULE-04`, `git push` não é disparado automaticamente. A alteração está pronta para ser commitada e aguarda autorização explícita do usuário para o envio à branch `develop`.
