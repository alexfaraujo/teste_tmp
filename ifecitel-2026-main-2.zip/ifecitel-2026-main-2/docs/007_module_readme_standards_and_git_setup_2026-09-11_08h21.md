# Registro Técnico e Decisões de Governança #007: Padrão Visual dos READMEs dos Módulos e Conexão Git

**Data e Hora:** 11 de setembro de 2026, 08h21 (Horário Local)  
**Autor:** Antigravity (Pair Programming com Alex Araújo — Gestor do Projeto)  
**Status:** Validado e Integrado às Regras de Governança  

---

## 1. Contexto e Motivação

Durante a fase de alinhamento e preparação para o início da estruturação física do monorepo, o Gestor do Projeto (Alex Araújo) concluiu com sucesso a execução dos comandos manuais de inicialização do controle de versão Git, geração e cadastro da chave SSH Ed25519 e conexão com o repositório remoto, ativando a branch de desenvolvimento contínuo `develop` e preservando a branch `main` intacta para automações de CI/CD futuras.

Adicionalmente, foi estabelecida uma nova diretriz de qualidade visual e documentação: cada módulo funcional do monorepo (`apps/backend/`, `apps/frontend-admin/`, `apps/frontend-evaluator/`, `apps/frontend-kiosk/`) deverá dispor de um arquivo `README.md` concebido sob padrões visuais modernos, elegantes, coloridos e de alto rigor profissional, exibindo badges estilizados e ícones oficiais das tecnologias adotadas.

---

## 2. Nova Regra Integrada ao Projeto (`.agents/rules.md` — Item 1.6)

A seção **1.6 (Padrão Visual e Estrutural dos READMEs dos Módulos do Monorepo)** foi formalmente adicionada ao arquivo de governança [.agents/rules.md](file:///.agents/rules.md#L47-L62), com as seguintes especificações mandatórias:

### 2.1. Rigor Estético e Badges Oficiais
*   Cada README deve conter, logo após o título principal, uma galeria de badges coloridos e estilizados (via serviço Shields.io com formatação `for-the-badge` ou `flat-square` e ícones oficiais Simple Icons / FontAwesome).
*   **Módulo 1 (`apps/backend/`):**
    *   Badges: Python 3.11+, FastAPI, PostgreSQL, SQLAlchemy 2.0 Async, Pydantic v2, Pytest, Uvicorn, AsyncPG.
*   **Módulo 2 (`apps/frontend-admin/`):**
    *   Badges: Next.js 14+ (App Router), React, TypeScript, Tailwind CSS, Lucide Icons, Axios.
*   **Módulo 3 (`apps/frontend-evaluator/`):**
    *   Badges: Next.js 14+, PWA (Progressive Web App), TypeScript, Tailwind CSS, HTML5 QR Scanner, Mobile Touch UX.
*   **Módulo 4 (`apps/frontend-kiosk/`):**
    *   Badges: Next.js 14+, TypeScript, Tailwind CSS, Fullscreen API, SWR Auto-Refresh, 4K/1080p Ultra-Wide UI.

### 2.2. Estrutura Canônica Obrigatória em Cada README de Módulo
1.  **Cabeçalho Visual:** Título estilizado, subtítulo descritivo e galeria de badges das tecnologias.
2.  **Visão Geral & Responsabilidades:** Escopo do módulo, perfil de usuário atendido e papel no ecossistema FECITEL.
3.  **Tabela de Tecnologias & Versões:** Relação minuciosa das dependências principais e bibliotecas.
4.  **Mapa de Diretórios (`tree`):** Estrutura interna de pastas e organização de código.
5.  **Variáveis de Ambiente & Pré-requisitos:** Documentação detalhada dos parâmetros no arquivo `.env`.
6.  **Guia de Inicialização Rápida:** Comandos de terminal para subir o módulo individualmente ou via script shell.
7.  **Portas e Rotas Principais:** Tabela com URLs locais e principais rotas/páginas atendidas.
8.  **Padrão de Idioma:** Redação integralmente em **português (pt-BR)**, mantendo estritamente nomes de código, variáveis e tabelas em **inglês**.

---

## 3. Atualizações Realizadas na Documentação Raiz

*   [**.agents/rules.md**](file:///.agents/rules.md): Inserção da seção `1.6. Padrão Visual e Estrutural dos READMEs dos Módulos do Monorepo`.
*   [**README.md**](file:///Users/alexaraujo/Documents/Fecitel-Alex-Rogerio/README.md): Adicionado o direcionamento de READMEs modernos e com badges na Seção 10 (*Padrões de Idioma e Boas Práticas de Código*).

---

## 4. Métricas de Esforço e Participação (RULE-03)

| Dimensão | Percentual | Detalhamento |
| :--- | :--- | :--- |
| **Feito por IA** | **20%** | Elaboração da estrutura dos badges, redação das especificações estéticas e formatação markdown. |
| **Híbrido (Pair Programming)** | **30%** | Integração contínua da nova regra com as diretrizes anteriores e refinamento do monorepo. |
| **Participação Humana** | **50%** | Execução dos comandos manuais no Git/SSH, definição da exigência estética dos READMEs e aprovação soberana. |

---

*Documento homologado e registrado no histórico cronológico oficial do projeto.*
