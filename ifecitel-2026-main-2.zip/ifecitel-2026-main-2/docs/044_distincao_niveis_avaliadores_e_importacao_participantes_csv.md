# Documentação Técnica: Distinção de Níveis para Avaliadores e Importação em Lote de Participantes via CSV — EasyEvent

**Data:** 13 de Setembro de 2026  
**Status:** Implementado & Aprovado  
**Regras de Referência:** Regra BR-25 (Distinção de Níveis de Ensino para Avaliadores) e Regra BR-26 (Importação em Lote de Participantes)  
**Módulos Impactados:** `apps/backend` (Modelagem, Schemas, Serviços de Alocação e Participantes, Endpoints), `apps/frontend-admin` (Tipagem, Utilitários CSV, Modais e Páginas de Participantes e Avaliadores).

---

## 1. Contexto e Motivação

### 1.1 Distinção de Níveis de Ensino para Avaliadores
Em mostras e feiras científicas integradas (ex: FECITEL), concorrem trabalhos de diferentes níveis de formação:
- **Ensino Médio / Técnico (`MEDIO`)**
- **Ensino Fundamental (`FUNDAMENTAL`)**
- **Iniciação Científica Júnior (`JUNIOR`)**

Certos avaliadores voluntários ou convidados (ex: professores universitários ou pesquisadores especialistas) possuem restrições regimentais ou de competência pedagógica, não podendo avaliar projetos de nível fundamental, enquanto outros são especialistas dedicados exclusivamente ao ensino fundamental ou atuam de forma ampla em todos os níveis.

Anteriormente, o motor de alocação balanceada considerava apenas subáreas do conhecimento e conflito de interesse de autoria/orientação. Com a introdução da entidade `PersonEducationLevel`, o sistema passa a restringir as alocações com base na compatibilidade dos níveis de ensino.

### 1.2 Importação em Lote de Participantes
Feiras acadêmicas recebem centenas de inscrições de estudantes, professores orientadores e avaliadores externos. O cadastro individual torna-se moroso durante a fase pré-evento. A funcionalidade de importação em lote via arquivo CSV padronizado permite que a coordenação suba rapidamente a base completa de participantes, atribuindo múltiplos papéis, vinculando subáreas temáticas e parametrizando os níveis de ensino dos avaliadores em um único envio com validação prévia.

---

## 2. Especificação do Banco de Dados (`PostgreSQL`)

### 2.1 Tabela `person_education_levels`
```sql
CREATE TABLE person_education_levels (
    id SERIAL PRIMARY KEY,
    person_id INT NOT NULL REFERENCES people(id) ON DELETE CASCADE,
    event_id INT NOT NULL REFERENCES events(id) ON DELETE CASCADE,
    education_level VARCHAR(20) NOT NULL, -- 'MEDIO', 'FUNDAMENTAL', 'JUNIOR'
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMP WITH TIME ZONE NULL,
    CONSTRAINT uq_person_event_education_level UNIQUE(person_id, event_id, education_level)
);

CREATE INDEX idx_pel_person_event ON person_education_levels (person_id, event_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_pel_event_level ON person_education_levels (event_id, education_level) WHERE deleted_at IS NULL;
```

### 2.2 Regras de Compatibilidade
1. **Omissão / Universalidade:** Se o avaliador possuir 0 registros ativos em `person_education_levels` para a respectiva feira, ele é considerado apto para avaliar trabalhos de qualquer nível de ensino.
2. **Restrição Específica:** Se houver 1 ou mais registros ativos (ex: `['FUNDAMENTAL']`), o avaliador só poderá receber trabalhos cujo `project.education_level` pertença a essa coleção.
3. **Mecanismos Protegidos:**
   - **Check-in Dinâmico (`allocate_evaluator_on_checkin`):** Filtra projetos elegíveis via `Project.education_level.in_(evaluator_levels)`.
   - **Auto-Balanceamento (`run_auto_balance_allocation`):** Valida `not evaluator_levels or p.education_level in evaluator_levels`.
   - **Alocação Manual (`manual_allocate`):** Rejeita com `HTTP 400 Bad Request` qualquer tentativa de vinculação manual de projeto com nível incompatível.

---

## 3. Especificação da Importação em Lote de Participantes via CSV

### 3.1 Formato e Colunas do Arquivo CSV
Codificação UTF-8 com BOM (suporta acentuação nativa no Excel e LibreOffice), delimitador `;` ou `,`:

| Coluna | Obrigatória? | Descrição | Exemplos |
| :--- | :---: | :--- | :--- |
| `nome` | **Sim** | Nome completo do participante | `Mariana Silva Santos`, `Prof. Carlos Lima` |
| `email` | **Sim** | E-mail corporativo/pessoal (chave única) | `mariana@estudante.edu.br`, `carlos@escola.edu.br` |
| `papeis` | Não (def. `Estudante`) | Papéis no evento (separados por vírgula se múltiplos) | `Estudante`, `Orientador`, `Avaliador`, `"Orientador, Avaliador"` |
| `cpf` | Não | CPF com ou sem pontuação (até 14 caracteres) | `123.456.789-01`, `12345678901` |
| `afiliacao` | Não | Instituição de origem / escola / campus | `IFMS Campus Três Lagoas`, `UFMS` |
| `tamanho_camiseta`| Não (def. `M`) | Tamanho da camiseta oficial do evento | `PP`, `P`, `M`, `G`, `GG`, `XGG` |
| `subareas` | Não | Nomes das subáreas temáticas do avaliador | `"Robótica e Automação, Informática"`, `Ciências Biológicas` |
| `niveis_ensino` | Não (def. vazio = todos)| Níveis de ensino habilitados para o avaliador | `"Médio, Fundamental"`, `Fundamental`, `Médio` |

### 3.2 Contrato da API (`REST / JSON`)

#### Endpoint: `POST /api/v1/participants/batch?event_id={event_id}`
- **Permissão:** `ORGANIZER` ou `COORDINATOR` da feira ativa.
- **Payload (`ParticipantBatchImport`):**
```json
{
  "items": [
    {
      "name": "Prof. Carlos Eduardo Lima",
      "email": "carlos.lima@escola.edu.br",
      "roles": ["ADVISOR", "EVALUATOR"],
      "cpf": "123.456.789-00",
      "affiliation": "IFMS Campus Três Lagoas",
      "tshirt_size": "G",
      "subareas": ["Robótica e Automação", "Informática"],
      "education_levels": ["MEDIO", "FUNDAMENTAL"],
      "barcode": null
    }
  ]
}
```
- **Resposta (`ParticipantBatchResponse`):**
```json
{
  "total_processed": 1,
  "created_count": 0,
  "updated_count": 1,
  "roles_assigned_count": 2,
  "evaluators_count": 1,
  "items": [ ... ]
}
```

---

## 4. Experiência do Usuário no Frontend (`apps/frontend-admin`)

1. **Ações na Tela `/participants`:**
   - Botão **"Baixar Modelo CSV"**: faz o download imediato de planilha modelo preenchida com subáreas reais cadastradas na feira.
   - Botão **"Importar CSV"**: abre o modal interativo com suporte a arrastar e soltar (drag & drop).
2. **Pré-visualização Interativa:**
   - Cards de estatísticas: Total, Alunos, Orientadores e Avaliadores.
   - Tabela com paginação/scroll e badges coloridos para papéis, subáreas e níveis de ensino.
   - Indicador de status de cada linha: `Novo Participante` (verde) ou `Atualização de Cadastro` (azul).
   - Validação prévia impedindo envio de e-mails inválidos ou papéis não reconhecidos.
