# Documentação Técnica da FECITEL: Arquitetura, API e Design de Frontend

## 1. Padrão Arquitetural e Filosofia de Design

O sistema FECITEL adota uma **Arquitetura em Camadas Simplificada (Serviços Diretos)** implementada em **Python 3.11+**, utilizando **FastAPI**, **SQLAlchemy 2.0 (assíncrono com `asyncpg`)** e **Pydantic v2**, executando nativamente (*bare-metal*) com **PostgreSQL 15+** local.

### Benefícios da Arquitetura com Serviços Diretos:
1.  **Ciclo Rápido de Desenvolvimento e Zero Boilerplate:** Elimina camadas redundantes de repositórios vazios que apenas repassam chamadas. As regras de negócio e consultas SQL assíncronas são encapsuladas diretamente em módulos de serviço coesos.
2.  **Facilidade de Manutenção e Clareza Cognitiva:** Estrutura plana e previsível, onde qualquer desenvolvedor ou o Gestor do Projeto pode rastrear o fluxo completo de uma requisição em minutos.
3.  **Desempenho Bare-Metal Máximo:** Corrotinas assíncronas nativas conectadas ao PostgreSQL via `asyncpg` asseguram tempos de resposta inferiores a 10ms nos períodos de pico do credenciamento e da avaliação presencial.

```
┌────────────────────────────────────────────────────────┐
│                   HTTP Routers (FastAPI)               │
│        (Pydantic v2 DTOs, Route Guards, RBAC)          │
├────────────────────────────────────────────────────────┤
│                   Domain Services                      │
│       (Regras de Negócio, Transações SQL, Fluxos)      │
├────────────────────────────────────────────────────────┤
│                   ORM Models (SQLAlchemy 2.0)          │
│       (Mapeamento Declarativo, Soft Delete, Invariantes)│
├────────────────────────────────────────────────────────┤
│                   PostgreSQL 15+ Local                 │
│         (ACID Real, Streaming, Índices Parciais)       │
└────────────────────────────────────────────────────────┘
```

---

## 2. Estrutura do Monorepo: 4 Blocos Funcionais

O projeto adota uma arquitetura em **Monorepo** desacoplado, dividida em 4 blocos funcionais independentes:

```text
fecitel-monorepo/
├── .agents/
│   └── rules.md                     # Regras de governança, padrões de idioma e regras de negócio
├── docs/
│   ├── context.md                   # Contextos do sistema, atores e escopo
│   ├── database.md                  # ERD Mermaid e Dicionário PostgreSQL
│   ├── design.md                    # Arquitetura, endpoints da API e design system
│   ├── mockups/                     # Mockups de alta fidelidade e protótipo interativo
│   └── 003_full_system_specification_report_2026-09-09_10h51.md
└── apps/
    ├── backend/                     # BLOCO 1: API Central FastAPI + PostgreSQL bare-metal
    │   ├── run.sh                   # Script bare-metal de inicialização rápida
    │   ├── requirements.txt         # Dependências diretas (fastapi, sqlalchemy, asyncpg)
    │   ├── .env.example             # Modelo de variáveis de ambiente
    │   └── src/                     # Core, modelos, schemas, serviços diretos, rotas
    │
    ├── frontend-admin/              # BLOCO 2: Painel de Controle do Administrador do Evento
    │   ├── package.json             # Next.js 14+ (App Router), TypeScript, Tailwind CSS
    │   └── src/                     # Etapas, SUAP, Homologação, Áreas, Prêmios, Recepção, Apuração
    │
    ├── frontend-evaluator/          # BLOCO 3: Web App Mobile-First para Avaliadores Presenciais
    │   ├── package.json             # Next.js 14+ PWA Mobile-First
    │   └── src/                     # Scanner QR de bancada, steppers de notas, parecer consolidado
    │
    └── frontend-kiosk/              # BLOCO 4: Painel Público Quiosque para Telões e TVs
        ├── package.json             # Next.js 14+ otimizado para 1080p e 4K (sem scroll)
        └── src/                     # Métricas agregadas, dark mode nativo, auto-refresh silencioso
```

---

## 3. Design System Visual e Arquitetura Responsiva

O frontend da FECITEL é desenvolvido com **Next.js 14+ (App Router)**, **TypeScript**, **Tailwind CSS** e ícones **Lucide React**, projetado para visual limpo, discreto, moderna experiência do usuário e baixo esforço cognitivo.

### 3.1. Paleta de Cores Oficial: Azul Safira + Verde Teal/Esmeralda

A paleta de cores transmite confiabilidade acadêmica, inovação científica e tecnologia moderna:

*   **Cor Primária (Institucional e Confiabilidade Acadêmica):**
    *   **Azul Safira / Oceano (`#1E3A8A` / `#2563EB`)**: Cor mestre da identidade visual, aplicada em botões primários, cabeçalhos, navegação e logotipo.
*   **Cor Secundária (Inovação, Ciência e Sucesso):**
    *   **Verde Teal / Esmeralda (`#0D9488` / `#10B981` no Modo Claro; `#14B8A6` no Modo Escuro)**:
        *   *Justificativa:* Combina perfeitamente com o azul, simbolizando tecnologia, sustentabilidade e clareza visual.
        *   *Aplicação:* Barras de progresso das bancadas, badges de status "Presente", confirmação de credenciamento e indicadores de destaque.
*   **Neutros e Superfícies:**
    *   **Ardósia Fria (`#0F172A` a `#F8FAFC`)**: Proporciona contraste suave e elimina poluição visual.

### 3.2. Suporte a Tema Dia e Noite (Modo Claro e Modo Escuro)

A interface conta com alternador nativo de tema (Dia / Noite), persistindo a preferência no `localStorage`.

| Token de Design | Modo Dia (Light) | Amostra Visual (Dia) | Modo Noite (Dark) | Amostra Visual (Noite) | Função e Aplicação |
| :--- | :--- | :---: | :--- | :---: | :--- |
| **`primary-blue`** | `#2563EB` | <span style="display:inline-block;width:22px;height:22px;background-color:#2563EB;border-radius:4px;border:1px solid #999;vertical-align:middle;"></span> `#2563EB` | `#3B82F6` | <span style="display:inline-block;width:22px;height:22px;background-color:#3B82F6;border-radius:4px;border:1px solid #999;vertical-align:middle;"></span> `#3B82F6` | Botões primários, abas ativas de navegação |
| **`primary-dark`** | `#1E3A8A` | <span style="display:inline-block;width:22px;height:22px;background-color:#1E3A8A;border-radius:4px;border:1px solid #999;vertical-align:middle;"></span> `#1E3A8A` | `#1E3A8A` | <span style="display:inline-block;width:22px;height:22px;background-color:#1E3A8A;border-radius:4px;border:1px solid #999;vertical-align:middle;"></span> `#1E3A8A` | Logotipo institucional, estados ativos em hover |
| **`secondary-teal`**| `#0D9488` | <span style="display:inline-block;width:22px;height:22px;background-color:#0D9488;border-radius:4px;border:1px solid #999;vertical-align:middle;"></span> `#0D9488` | `#14B8A6` | <span style="display:inline-block;width:22px;height:22px;background-color:#14B8A6;border-radius:4px;border:1px solid #999;vertical-align:middle;"></span> `#14B8A6` | Barras de progresso das bancadas, badges 'Presente' |
| **`accent-emerald`**| `#10B981` | <span style="display:inline-block;width:22px;height:22px;background-color:#10B981;border-radius:4px;border:1px solid #999;vertical-align:middle;"></span> `#10B981` | `#22C55E` | <span style="display:inline-block;width:22px;height:22px;background-color:#22C55E;border-radius:4px;border:1px solid #999;vertical-align:middle;"></span> `#22C55E` | Confirmação de kit entregue, sucesso no credenciamento |
| **`background`** | `#F8FAFC` | <span style="display:inline-block;width:22px;height:22px;background-color:#F8FAFC;border-radius:4px;border:1px solid #ccc;vertical-align:middle;"></span> `#F8FAFC` | `#0B0F19` | <span style="display:inline-block;width:22px;height:22px;background-color:#0B0F19;border-radius:4px;border:1px solid #555;vertical-align:middle;"></span> `#0B0F19` | Fundo geral da página (Ardósia claro / Obsidiana) |
| **`surface`** | `#FFFFFF` | <span style="display:inline-block;width:22px;height:22px;background-color:#FFFFFF;border-radius:4px;border:1px solid #ccc;vertical-align:middle;"></span> `#FFFFFF` | `#1E293B` | <span style="display:inline-block;width:22px;height:22px;background-color:#1E293B;border-radius:4px;border:1px solid #555;vertical-align:middle;"></span> `#1E293B` | Superfície de cartões, modais, cabeçalho e barra lateral (arejado) |
| **`border`** | `#E2E8F0` | <span style="display:inline-block;width:22px;height:22px;background-color:#E2E8F0;border-radius:4px;border:1px solid #ccc;vertical-align:middle;"></span> `#E2E8F0` | `#334155` | <span style="display:inline-block;width:22px;height:22px;background-color:#334155;border-radius:4px;border:1px solid #555;vertical-align:middle;"></span> `#334155` | Bordas sutis de tabelas, cartões e separadores |
| **`text-primary`** | `#0F172A` | <span style="display:inline-block;width:22px;height:22px;background-color:#0F172A;border-radius:4px;border:1px solid #999;vertical-align:middle;"></span> `#0F172A` | `#F8FAFC` | <span style="display:inline-block;width:22px;height:22px;background-color:#F8FAFC;border-radius:4px;border:1px solid #ccc;vertical-align:middle;"></span> `#F8FAFC` | Tipografia principal, títulos e números de impacto |
| **`text-muted`** | `#64748B` | <span style="display:inline-block;width:22px;height:22px;background-color:#64748B;border-radius:4px;border:1px solid #999;vertical-align:middle;"></span> `#64748B` | `#94A3B8` | <span style="display:inline-block;width:22px;height:22px;background-color:#94A3B8;border-radius:4px;border:1px solid #999;vertical-align:middle;"></span> `#94A3B8` | Rótulos secundários, legendas e notas explicativas |
| **`warning-amber`**| `#F59E0B` | <span style="display:inline-block;width:22px;height:22px;background-color:#F59E0B;border-radius:4px;border:1px solid #999;vertical-align:middle;"></span> `#F59E0B` | `#FBBF24` | <span style="display:inline-block;width:22px;height:22px;background-color:#FBBF24;border-radius:4px;border:1px solid #999;vertical-align:middle;"></span> `#FBBF24` | Status 'Aguardando Anuência', avisos |
| **`error-red`** | `#EF4444` | <span style="display:inline-block;width:22px;height:22px;background-color:#EF4444;border-radius:4px;border:1px solid #999;vertical-align:middle;"></span> `#EF4444` | `#F87171` | <span style="display:inline-block;width:22px;height:22px;background-color:#F87171;border-radius:4px;border:1px solid #999;vertical-align:middle;"></span> `#F87171` | Alerta de kit já entregue, falhas de validação |

*   **Nota de Calibração:** No **Modo Claro**, a barra superior e a barra lateral utilizam fundo **branco puro arejado (`#FFFFFF`)** com borda em `#E2E8F0`, sem blocos escuros pesados.

#### 3.2.1. Mockups de Alta Fidelidade (Identidade Visual Aplicada)

##### Modo Claro (Light Mode) — Superfícies Brancas Arejadas e Acentos Safira/Teal
![FECITEL - Mockup em Modo Claro](mockups/002_fecitel_light_mode_adjusted.jpg)
*   **Cabeçalho e Menu Lateral:** Superfícies em branco puro (`#FFFFFF`) com divisores sutis em `#E2E8F0`.
*   **Ações Primárias:** Destaque em Azul Safira (`#2563EB`) no menu ativo e botões principais.
*   **Indicadores e Métricas:** Verde Teal (`#0D9488`) em gráficos de tendência e barras de progresso.

---

##### Modo Escuro (Dark Mode) — Fundo Obsidiana e Alto Contraste
![FECITEL - Mockup em Modo Escuro](mockups/001_fecitel_dark_mode.jpg)
*   **Fundo e Superfícies:** Fundo em Obsidiana profunda (`#0B0F19`) com cartões em Ardósia (`#1E293B`) e bordas em `#334155`.
*   **Acentos Luminosos:** Botões em azul elétrico (`#3B82F6`) e barras de progresso das áreas temáticas em Verde Teal vibrante (`#14B8A6`).

---

##### Protótipo Interativo em HTML/CSS Puro
Desenvolvedores podem inspecionar transições de tema abrindo [`docs/mockups/theme_preview.html`](mockups/theme_preview.html) diretamente no navegador.

---

### 3.3. Perfis de Dispositivo Responsivos e Distribuição dos 4 Blocos

```mermaid
flowchart TD
    subgraph Monorepo["Monorepo FECITEL (4 Blocos)"]
        B1["apps/backend<br/>(FastAPI + SQLAlchemy 2.0 + PostgreSQL bare-metal)"]
        F1["apps/frontend-admin<br/>(Desktops e Tablets 768px-1920px)<br/>• Painel do Administrador do Evento: Etapas, Homologação, Áreas, Prêmios, Recepção e Apuração"]
        F2["apps/frontend-evaluator<br/>(Smartphones 360px-430px Mobile-First)<br/>• Leitor QR Bancada, Ficha com Steppers (+/-), Parecer Único"]
        F3["apps/frontend-kiosk<br/>(Smart TVs e Telões 1080p e 4K)<br/>• Painel Público sem notas/ranking, Dark Mode nativo, Auto-refresh 30s"]
    end
    F1 -->|Consome API REST| B1
    F2 -->|Consome API REST| B1
    F3 -->|Consome API REST| B1
```

---

## 4. Módulos e Telas do Frontend

### 4.1. Fluxo de Autenticação Dual (`/login`)

```mermaid
sequenceDiagram
    autonumber
    actor User as Usuário / Participante / Admin
    participant UI as Tela de Login Next.js
    participant API as Backend FastAPI
    participant Mail as Servidor SMTP
    participant DB as PostgreSQL 15+

    User->>UI: Digita o e-mail cadastrado
    alt Perfil é ADMIN
        UI->>UI: Exibe campo "Senha" (senha mestre)
        User->>UI: Digita e-mail + senha mestre
        UI->>API: POST /api/v1/auth/login-admin
        API->>DB: Verifica bcrypt password_hash
        API-->>UI: Retorna JWT (role: ADMIN)
    else Perfil é PARTICIPANTE (Estudante, Orientador, Avaliador)
        UI->>UI: Exibe campo "Código de Acesso" (Mascarado como Senha)
        opt Primeiro acesso ou solicitar novo código
            User->>UI: Clica em "Enviar Meu Código de Acesso"
            UI->>API: POST /api/v1/auth/request-code {"email": "..."}
            API->>DB: Valida unicidade, gera código (ex: 26AB34CD)
            API->>DB: Salva hash na tabela people.access_code_hash
            API->>Mail: Envia e-mail em português com código de 8 caracteres
            API-->>UI: 200 OK ("Código enviado para seu e-mail")
        end
        User->>UI: Digita código de 8 caracteres em campo mascarado
        UI->>API: POST /api/v1/auth/login-participant {"email": "...", "code": "26AB34CD"}
        API->>DB: Valida access_code_hash
        API-->>UI: Retorna JWT (roles: [ADVISOR, EVALUATOR])
    end
    UI->>UI: Redireciona para o painel correspondente ao papel
```

---

### 4.2. Telas Operacionais Principais

#### Tela 1: Painel de Controle do Administrador do Evento (`apps/frontend-admin/`)
*   **Gestão de Edições e Seleção de Evento Ativo (`/events`) — Regra BR-19:**
    *   *Seleção Mandatória da Edição Ativa:* Quando existem eventos cadastrados, o administrador escolhe qual evento gerenciar via ação **"Gerenciar este Evento"**. Essa escolha define o contexto operacional global persistido em `localStorage` (`fecitel_active_event`).
    *   *Bloqueio de Telas Dependentes (`RequireActiveEvent`):* As páginas operacionais (Visão Geral `/`, Áreas `/areas`, Projetos `/projects`, Avaliadores `/evaluators`, etc.) permanecem inativas até que um evento seja selecionado, exibindo um card explicativo amigável que direciona o usuário para a tela `/events`.
    *   *Persistência Global:* O evento selecionado permanece ativo em todas as telas e rotas até que o administrador retorne a `/events` e escolha outro evento.
    *   *Edição de Parâmetros e Trava Temporal (BR-02):* Modal para ajuste de nome, datas e cotas da edição. Eventos com `end_date` expirada exibem a tag `"Encerrado"` e desabilitam os botões de edição com trava temporal ativa.
    *   *Paginação Real Server-Side (Regra BR-18):* A listagem de edições implementa paginação real com 15 itens por página (`GET /api/v1/events?page=1&limit=15`).
*   **Central de Submissões e Homologação:** Tabela com filtros de status (`SUBMITTED`, `WAITING_CONSENT`, `HOMOLOGATED`). Homologação habilitada somente para trabalhos com anuência confirmada pelo orientador.
*   **Módulo de Alocação de Avaliadores:**
    *   *Alocação Automática Balanceada:* Executa o algoritmo pós-checkin emparelhando subáreas (delta $\le 1$).
    *   *Remanejamento Manual:* Modal para atribuir ou substituir avaliadores individualmente.
*   **Gestão de Áreas e Subáreas do Conhecimento (`/areas` — Regra BR-16):**
    *   *Módulo no Painel do Administrador:* Gerenciado sob o escopo da edição ativa selecionada. Visão em árvore/cards das áreas do conhecimento com contadores de projetos e subáreas.
    *   *Cadastro/Edição de Áreas:* Modal para criar grandes áreas temáticas com persistência no evento ativo.
    *   *Cadastro/Edição de Subáreas:* Modal para criar subáreas vinculadas à área mãe, com garantia de nome único por área.
    *   *Exclusão Lógica Protegida:* Bloqueio com aviso explícito caso a área contenha subáreas ativas, ou caso a subárea esteja vinculada a projetos ou avaliadores. Subáreas e áreas desativadas podem ser recadastradas/reativadas sem erro de duplicidade.
*   **Gestão de Critérios de Avaliação (`/criteria` — Regras BR-11 e BR-12):**
    *   *Módulo no Painel do Administrador:* Gerenciamento unificado da rubrica e dos itens avaliativos da edição ativa (`RequireActiveEvent`).
    *   *Sistema de Pergunta Dual / Unificada:* Cada critério suporta dois modos de parametrização:
        *   *Modo Pergunta Dual (com distinção metodológica):* Campos dedicados `scientific_description` (foco em método científico e dados) e `technological_description` (foco em requisitos e protótipo).
        *   *Modo Tipo Único de Trabalho:* Checkbox no formulário indicando que o evento não separa projetos por modalidade. O formulário unifica a entrada de texto e salva a mesma pergunta em ambas as colunas, enquanto todos os projetos da feira concorrem sob o tipo científico padrão.
    *   *Equivalência e Unicidade:* Pontuação máxima (`max_score`), peso ponderado (`weight`) e ordem de exibição são rigorosamente iguais para ambos os formatos de pergunta.
    *   *Trava de Exclusão Histórica:* Impede a exclusão de critérios que já possuam notas atribuídas por avaliadores no evento.
*   **Gestão de Premiações e Vínculo de Critérios (`/awards` e `/results`):**
    *   *Cadastro de Prêmios Específicos:* Criação, edição e exclusão de premiações especiais, troféus de patrocinadores e menções honrosas para o evento.
    *   *Seleção Obrigatória de Critérios (BR-17):* Bloqueio estrito no cadastro de premiações sem critérios vinculados. O administrador seleciona quais perguntas compõem a nota daquele prêmio específico e define pesos ponderados (`0.1` a `10.0`).
    *   *Módulo de Apuração Oficial com Dois Rankings:*
        *   **Ranking 1 (Premiações Regulares por Área e Nível / Melhor Geral):** Classificação oficial calculada pela média simples de **todos os itens** de avaliação, agrupada por Área do Conhecimento e Nível de Ensino (`MEDIO`, `FUNDAMENTAL`, `JUNIOR`), além do ranking de **Melhor Geral** da feira.
        *   **Ranking 2 (Premiações Específicas):** Ranking individual de cada prêmio especial calculado **exclusivamente com base nas notas dos critérios indicados** para aquele prêmio.


#### Tela 2: Central de Submissões e Portal do Orientador (`/submissions`)
*   **Assistente de Submissão do Aluno:**
    1.  *Dados:* Título, tipo de projeto (`SCIENTIFIC` / `TECHNOLOGICAL`), nível de ensino e subárea temática.
    2.  *Composição da Equipe:* Inclusão de e-mails em lote com validação de cota por nível (Médio: máx 4; Fundamental: máx 5).
    3.  *Upload de Arquivos:* Drag-and-drop com validação estrita de formatos e streaming.
*   **Tela de Anuência do Orientador (`/submissions/:id/consent`):**
    *   Visão dedicada para o professor orientador analisar os dados e arquivos do projeto.
    *   Ação de destaque: "Conceder Anuência Digital", registrando data/hora e liberando o trabalho para homologação.

#### Tela 3: Mesa de Credenciamento e Logística de Kits (`/logistics`) — *Mobile/Tablet First*
*   **Bipagem Rápida de Crachá:** Foco automático contínuo no campo de leitura para leitores de código de barras USB/Bluetooth, com alternador rápido para câmera de tablet.
*   **Retorno Visual do Credenciamento:**
    *   *Sucesso:* Cartão verde com nome do participante, escola e tamanho da camiseta em destaque (ex: **"TAMANHO: G"**).
    *   *Alerta de Duplicidade:* Aviso sonoro e tarjeta vermelha de alto contraste: *"KIT JÁ RETIRADO EM 09/09/2026 ÀS 08:30"*.
    *   *Efeito Colateral:* Confirma a presença física individual e promove o trabalho na bancada para `PRESENT`.

#### Tela 4: Ficha Digital de Avaliação (`/evaluator`) — `apps/frontend-evaluator/`
*   **Scanner QR de Bancada:** Botão proeminente que aciona a câmera do celular para escanear o QR Code impresso na bancada do projeto.
*   **Lista de Trabalhos Alocados:** Cards contendo número do estande, título, subárea e status (`PENDING`, `COMPLETED`).
*   **Ficha de Avaliação com Seleção Dinâmica da Pergunta Dual:**
    *   A API seleciona automaticamente a formulação adequada ao trabalho em `GET /api/v1/evaluations/sheet/{project_id}`:
        *   Se `project.project_type == ProjectType.SCIENTIFIC`, injeta o enunciado científico (`scientific_description`).
        *   Se `project.project_type == ProjectType.TECHNOLOGICAL`, injeta o enunciado tecnológico (`technological_description`).
    *   A pontuação máxima, peso e ordem dos itens são idênticos em ambos os fluxos.
    *   Campos de nota (0.0 a 10.0) com botões numéricos táteis `+` e `-` para operação ágil com uma mão em ambiente presencial.
    *   Campo expansível de **parecer/observação consolidada única** ao término da avaliação (Regra BR-11).

#### Tela 5: Painel Público para Smart TVs e Telões (`/tv`) — `apps/frontend-kiosk/`
*   **Sem Autenticação e Sem Interação:** Roda em modo quiosque contínuo em navegadores de Smart TVs e projetores do pavilhão.
*   **Sigilo Rigoroso:** Totalmente blindado contra exibição de notas individuais, pareceres ou ranqueamento competitivo.
*   **Métricas Exibidas:** Participantes credenciados, projetos presentes nas bancadas, progresso percentual das avaliações por grande área do conhecimento e total de escolas participantes.
*   **Ergonomia para Telões:** Dark mode nativo padrão (`#0B0F19`), tipografia de grande porte e auto-refresh silencioso a cada 30 segundos.

---

## 5. Matriz de Endpoints da API RESTful (FastAPI)

Todas as rotas residem sob o prefixo `/api/v1` e utilizam payloads JSON padronizados em `snake_case` inglês.

> [!IMPORTANT]
> **Proteção Universal por API Key (Regra SEC-03):** 100% das rotas da API (incluindo expressamente todas as requisições `GET` de consulta, além de mutações `POST`, `PUT`, `DELETE` e `PATCH`) exigem a transmissão obrigatória do cabeçalho `X-API-Key: fecitel_secret_api_key_2026`. Requisições sem a chave corporativa válida são imediatamente rejeitadas com `HTTP 401 Unauthorized`. Rotas autenticadas por perfil exigem cumulativamente o token `Authorization: Bearer <token>` (segurança em camadas).

### 5.1. Autenticação (`/auth`)
| Método | Endpoint | Payload | Sucesso | Descrição |
| :--- | :--- | :--- | :--- | :--- |
| `POST` | `/api/v1/auth/login-admin` | `{"email": "...", "password": "..."}` | `200 OK` | Login de administrador com senha mestre bcrypt. |
| `POST` | `/api/v1/auth/request-code`| `{"email": "..."}` | `200 OK` | Gera OTP de 8 caracteres, salva hash e dispara e-mail. |
| `POST` | `/api/v1/auth/login-participant`| `{"email": "...", "access_code": "26AB34CD"}` | `200 OK` | Login de participante/avaliador com código OTP de 8 chars. |
| `GET`  | `/api/v1/auth/me` | Nenhum (Bearer) | `200 OK` | Retorna perfil, papéis e evento ativo do usuário logado. |

### 5.2. Eventos e Configuração (`/events`)
| Método | Endpoint | Payload / Query | Sucesso | Descrição |
| :--- | :--- | :--- | :--- | :--- |
| `GET`  | `/api/v1/events` | `?year=2026&status=OPEN` | `200 OK` | Lista eventos com suporte a filtros. |
| `POST` | `/api/v1/events` | Dados do evento, extensões, etapas | `201 Created` | Cria edição independente de evento. |
| `PUT`  | `/api/v1/events/{id}` | Parâmetros atualizados | `200 OK` | Atualiza configurações (bloqueado se expirada `end_date`). |
| `DELETE`| `/api/v1/events/{id}`| Nenhum | `204 No Content` | Soft delete do evento (`deleted_at`). |

### 5.3. Áreas e Subáreas do Conhecimento (`/knowledge-areas`)
| Método | Endpoint | Payload / Query | Sucesso | Descrição |
| :--- | :--- | :--- | :--- | :--- |
| `GET`  | `/api/v1/events/{id}/knowledge-areas` | `?include_subareas=true` | `200 OK` | Lista áreas do evento com subáreas aninhadas opcionais. |
| `POST` | `/api/v1/events/{id}/knowledge-areas` | `{"name": "...", "description": "..."}` | `201 Created` | Cria área do conhecimento para a edição do evento. |
| `GET`  | `/api/v1/knowledge-areas/{id}` | Nenhum | `200 OK` | Retorna detalhes da área com suas subáreas vinculadas. |
| `PUT`  | `/api/v1/knowledge-areas/{id}` | `{"name": "...", "description": "..."}` | `200 OK` | Atualiza metadados da área do conhecimento. |
| `DELETE`| `/api/v1/knowledge-areas/{id}`| Nenhum | `204 No Content` | Soft delete da área (bloqueado se houver subáreas ativas). |
| `GET`  | `/api/v1/knowledge-areas/{id}/subareas` | Nenhum | `200 OK` | Lista subáreas da área de conhecimento especificada. |
| `POST` | `/api/v1/knowledge-areas/{id}/subareas` | `{"name": "...", "description": "..."}` | `201 Created` | Cria subárea vinculada à área (`UNIQUE(area_id, name)`). |
| `PUT`  | `/api/v1/subareas/{id}` | `{"name": "...", "description": "..."}` | `200 OK` | Atualiza dados cadastrais da subárea. |
| `DELETE`| `/api/v1/subareas/{id}` | Nenhum | `204 No Content` | Soft delete da subárea (bloqueado se vinculada a projetos/avaliadores). |

### 5.4. Premiações e Vínculo com Questões da Avaliação (`/awards`)
| Método | Endpoint | Payload / Query | Sucesso | Descrição |
| :--- | :--- | :--- | :--- | :--- |
| `GET`  | `/api/v1/events/{id}/awards` | Nenhum | `200 OK` | Lista todas as premiações cadastradas com critérios vinculados. |
| `POST` | `/api/v1/events/{id}/awards` | `{"name": "...", "description": "...", "sponsor": "..."}` | `201 Created` | Cadastra prêmio na edição do evento (`UNIQUE(event_id, name)`). |
| `GET`  | `/api/v1/awards/{id}` | Nenhum | `200 OK` | Detalhes do prêmio e perguntas/critérios associados. |
| `PUT`  | `/api/v1/awards/{id}` | `{"name": "...", "description": "...", "sponsor": "..."}` | `200 OK` | Atualiza dados cadastrais do prêmio. |
| `DELETE`| `/api/v1/awards/{id}` | Nenhum | `204 No Content` | Soft delete do prêmio e desvinculação lógica de critérios. |
| `POST` | `/api/v1/awards/{id}/criteria` | `{"criterion_id": 3, "weight": 1.5}` | `201 Created` | Associa pergunta/critério de nota ao prêmio com peso. |
| `DELETE`| `/api/v1/awards/{id}/criteria/{criterion_id}` | Nenhum | `204 No Content` | Remove a associação do critério com o prêmio. |
| `GET`  | `/api/v1/awards/{id}/standings` | Nenhum | `200 OK` | Classificação dos projetos concorrentes baseada nas questões do prêmio. |

### 5.5. Projetos e Anuência (`/projects`)
| Método | Endpoint | Payload / Query | Sucesso | Descrição |
| :--- | :--- | :--- | :--- | :--- |
| `POST` | `/api/v1/projects` | Metadados do projeto, e-mails | `201 Created` | Submissão do trabalho (entra em `WAITING_CONSENT`). |
| `PUT`  | `/api/v1/projects/{id}/files` | `multipart/form-data` | `200 OK` | Upload de resumo, banner e diário de bordo via streaming. |
| `POST` | `/api/v1/projects/{id}/consent` | Nenhum (Bearer Orientador) | `200 OK` | Registro da anuência digital formal pelo orientador. |
| `PATCH`| `/api/v1/projects/{id}/homologate` | `{"homologated": true}` | `200 OK` | Homologação do projeto pela coordenação da feira. |

### 5.6. Credenciamento e Logística (`/logistics`)
| Método | Endpoint | Payload | Sucesso | Descrição |
| :--- | :--- | :--- | :--- | :--- |
| `POST` | `/api/v1/logistics/scan-barcode` | `{"barcode": "BAR_123"}` | `200 OK` | Bipagem individual de crachá; confirma presença e bancada. |
| `POST` | `/api/v1/logistics/checkout-kit` | `{"barcode": "BAR_123"}` | `200 OK` | Entrega atômica condicional de kit com bloqueio duplo. |
| `GET`  | `/api/v1/logistics/project-kits/{id}` | Nenhum | `200 OK` | Consulta tamanhos da equipe para triagem prévia de kits. |

### 5.7. Alocações e Avaliação Presencial (`/evaluations`)
| Método | Endpoint | Payload / Query | Sucesso | Descrição |
| :--- | :--- | :--- | :--- | :--- |
| `POST` | `/api/v1/allocations/auto-balance` | `{"event_id": 1}` | `200 OK` | Executa balanceamento pós-checkin (delta $\le 1$). |
| `POST` | `/api/v1/allocations/manual` | `{"project_id": 10, "evaluator_id": 4}` | `201 Created` | Alocação ou remanejamento manual pelo administrador. |
| `GET`  | `/api/v1/evaluations/my-allocations` | Nenhum (Bearer Avaliador) | `200 OK` | Lista trabalhos atribuídos ao avaliador autenticado. |
| `GET`  | `/api/v1/evaluations/sheet` | `?qrcode=PROJ_10_HASH` | `200 OK` | Retorna ficha com critérios após leitura do QR de bancada. |
| `POST` | `/api/v1/evaluations` | `{"project_id": 10, "general_feedback": "...", "items": [...]}` | `201 Created` | Envio da ficha com notas por critério e parecer consolidado. |

### 5.8. Classificação e Dashboards (`/dashboard` e `/awards`)
| Método | Endpoint | Query Params | Sucesso | Descrição |
| :--- | :--- | :--- | :--- | :--- |
| `GET`  | `/api/v1/dashboard/public-tv` | `?event_id=1` | `200 OK` | **Endpoint Público Kiosk:** Métricas agregadas sem notas/ranking. |
| `GET`  | `/api/v1/dashboard/kpis` | `?event_id=1` | `200 OK` | Estatísticas gerenciais (presentes, pendentes, concluídos). |
| `GET`  | `/api/v1/dashboard/allocations` | `?event_id=1&eval_count=0` | `200 OK` | Lista trabalhos por contagem exata de revisões (Admin). |
| `GET`  | `/api/v1/dashboard/leaderboard/area-level` | `?event_id=1&area_id=2&education_level=MEDIO` | `200 OK` | **Ranking 1:** Classificação por Área e Nível de Ensino (todos os itens de avaliação). |
| `GET`  | `/api/v1/dashboard/leaderboard/overall` | `?event_id=1` | `200 OK` | **Ranking 1:** Classificação Melhor Geral da Feira (todos os itens de avaliação). |
| `GET`  | `/api/v1/awards/{id}/standings` | Nenhum | `200 OK` | **Ranking 2:** Classificação de Prêmio Específico (apenas critérios indicados). |


---

## 6. Soluções de Performance, Concorrência e Escalabilidade

### 6.1. Verificação em Lote (Eliminação de N+1)
```python
stmt = select(People).where(People.email.in_(email_list), People.deleted_at.is_(None))
result = await db.execute(stmt)
existing_people = {p.email: p for p in result.scalars().all()}
```
Participantes não cadastrados são criados em lote dentro da mesma transação atômica.

### 6.2. Lock Atômico Condicional na Baixa de Kits
```sql
UPDATE event_participants
SET kit_delivered = TRUE, kit_delivered_at = CURRENT_TIMESTAMP
WHERE event_id = :event_id AND person_id = :person_id AND kit_delivered = FALSE
RETURNING tshirt_size;
```
Se a linha não for atualizada (`rowcount == 0`), a API retorna erro `409 Conflict`, bloqueando imediatamente retiradas simultâneas duplicadas.
