# [HIST-003] Relatório de Especificação Técnica, Arquitetural e Modelagem — Sistema FECITEL

**Documento:** Relatório Executivo e Técnico de Engenharia de Software  
**Projeto:** FECITEL (Feira de Ciência e Tecnologia)  
**Gestor e Dono do Projeto:** Alex Araújo  
**Autor Técnico:** Antigravity (IA / Pair Programming)  
**Data e Hora:** 2026-09-09 11:38:00 -04:00  
**Status:** Especificação Completa com Monorepo em 4 Blocos e Paleta com Amostras Visuais  

---

## 1. Sumário Executivo e Propósito do Documento

Este documento consolida a **especificação técnica, arquitetural, funcional e de modelagem de dados** do sistema FECITEL. Ele foi elaborado com base estrita nos artefatos aprovados pelo Gestor do Projeto ([.agents/rules.md](file:///Users/alexaraujo/Documents/Fecitel-Alex-Rogerio/.agents/rules.md), [docs/context.md](file:///Users/alexaraujo/Documents/Fecitel-Alex-Rogerio/docs/context.md), [docs/database.md](file:///Users/alexaraujo/Documents/Fecitel-Alex-Rogerio/docs/database.md) e [docs/design.md](file:///Users/alexaraujo/Documents/Fecitel-Alex-Rogerio/docs/design.md)) e serve como **fonte única da verdade (Single Source of Truth)** para a equipe de desenvolvimento.

A solução é estruturada sob o modelo de **Monorepo com 4 blocos funcionais e independentes**:
1.  **`apps/backend/`**: API RESTful central de alta performance em Python 3.11+, FastAPI, SQLAlchemy 2.0 assíncrono e PostgreSQL bare-metal.
2.  **`apps/frontend-admin/`**: Aplicação Web (Next.js 14+) para gestão geral da feira, etapas, credenciamento/logística, homologação, alocação de avaliadores e apuração.
3.  **`apps/frontend-evaluator/`**: Aplicação Web Mobile-First (Next.js 14+) dedicada aos avaliadores em campo (leitura de QR Code na bancada, notas com steppers e parecer único).
4.  **`apps/frontend-kiosk/`**: Aplicação Web Kiosk (Next.js 14+) para exibição pública em TVs e telões (1080p e 4K), com métricas em tempo real sem expor notas ou ranqueamentos.

---

## 2. Governança, Metodologia de Trabalho e Diretrizes de Engenharia

### 2.1. Autoridade Soberana do Gestor do Projeto
*   **Propriedade Exclusiva:** O usuário Alex Araújo é o único dono do projeto e o Gestor final responsável por definir, aprovar e autorizar todo e qualquer ajuste no sistema.
*   **Decisões Compartilhadas (Pair Programming):** Nenhuma alteração arquitetural, estrutural ou funcional deve ser executada sem a análise e aprovação expressa do Gestor.
*   **Desenvolvimento Incremental e Checkpoints:** Cada entrega física de código é modular, pequena e testável. Ao final de cada etapa, a execução pausa obrigatoriamente para validação antes de avançar.
*   **Proibição Absoluta de `git push` Autônomo:** Commits locais frequentes seguindo Conventional Commits; sincronização remota (`git push`) somente sob comando explícito por escrito no chat.
*   **Métricas de Esforço de IA:** Cada registro de conclusão no histórico `docs/` deve reportar: `% IA`, `% Híbrido` e `% Humano`.

### 2.2. Padrão de Idiomas do Projeto (Código em Inglês; Documentação e Interface em Português)
*   **Código-Fonte e Banco de Dados (Estritamente em Inglês):** 100% dos nomes de variáveis, funções, métodos, classes, modelos ORM, tabelas do PostgreSQL, colunas, chaves estrangeiras, arquivos de código e rotas RESTful devem seguir estritamente o idioma **Inglês** (`snake_case` para variáveis/tabelas/colunas, `PascalCase` para classes e modelos).
*   **Arquivos .md, Interface do Usuário e Mensagens (Estritamente em Português):** Todos os arquivos de documentação (`.md`), especificações, relatórios, textos de telas, botões, modais, mensagens de validação, avisos do sistema e e-mails para participantes devem ser estritamente em **Português (pt-BR)**.


### 2.3. Rastreabilidade Histórica na Pasta `docs/`
*   Todos os relatórios, análises e planos de implementação são versionados cronologicamente na pasta `docs/` sob a convenção:
    `docs/XXX_descriptive_name_YYYY-MM-DD_HHhMM.md`. Proibido sobrescrever ou deletar arquivos históricos.

---

## 3. Visão Geral e Escopo do Sistema

### 3.1. O que o Sistema FAZ (Escopo Delimitado)
1.  **Múltiplos Eventos Independentes (Multi-Evento Simultâneo):** Permite a realização de múltiplos eventos simultâneos por ano. Cada evento possui isolamento estrito de comissão organizadora (`ADMIN`), avaliadores, trabalhos e participantes.
2.  **Bloqueio Temporal por Término do Evento:** A `end_date` do evento funciona como data de corte definitiva. Após expirar, o evento entra automaticamente em modo somente-leitura (`status = 'CLOSED'`), congelando trabalhos, notas e cadastros.
3.  **Dual Authentication Model (Segurança & RBAC):**
    *   *Administradores (`ADMIN`):* E-mail e senha mestre criptografada com bcrypt (salt = 12) / Argon2id.
    *   *Participantes (`STUDENT`, `ADVISOR`, `COADVISOR`, `EVALUATOR`):* Autenticação sem senha estática via **código de 8 caracteres alfanuméricos único em caixa alta** (`YY` + 4 letras + 2 números), enviado por e-mail, armazenado como hash (`access_code_hash`) e renderizado como campo de senha mascarado (`type="password"`).
4.  **Submissão Inteligente e Anuência do Orientador (*Advisor Consent*):**
    *   Verificação em lote de participantes via e-mail (`WHERE email IN (...)`) em transação única.
    *   Fluxo mandatório de anuência: o projeto submetido entra em `WAITING_CONSENT` e exige aceite digital formal do orientador antes de ser homologado pela organização.
5.  **Logística com Duplo Código no Crachá:**
    *   *Código de Barras Individual:* Impresso no crachá do participante para credenciamento de presença individual e retirada única de alimentação/kits.
    *   *QR Code do Projeto:* Fixado na bancada de apresentação para acesso imediato dos avaliadores à ficha de notas.
    *   *Check-in Coletivo:* A confirmação de presença de qualquer integrante da equipe promove o projeto para `PRESENT`.
6.  **Entrega Atômica de Kits por Edição de Evento:** Controle de camisetas e kits vinculado a `event_participants`, utilizando lock atômico condicional contra duplicidades.
7.  **Alocação de Avaliadores em Dois Momentos (Credenciamento Contínuo e Paralelo):**
    *   *Credenciamento Contínuo e Paralelo:* Autores (que tornam os projetos `PRESENT`) e avaliadores chegam e realizam check-in de modo contínuo durante a feira, sem cortes de lotes.
    *   *Momento 1 (Alocação Dinâmica no Check-in do Avaliador):* Disparada de forma autônoma no momento em que o avaliador realiza seu check-in presencial no evento, emparelhando sua subárea (`subarea_id`) aos trabalhos já presentes (`PRESENT`), selecionando com prioridade máxima os trabalhos com menos avaliadores alocados, respeitando o limite máximo (`max_projects_per_evaluator`), impedindo conflito de interesse e mantendo a Regra de Ouro ($\Delta \le 1$).
    *   *Momento 2 (Manual):* Atribuição ou remanejamento pontual a qualquer instante por administradores.
    *   *Desvinculação Automática:* Projetos que permanecerem `ABSENT` ao final do evento têm eventuais alocações canceladas automaticamente.
8.  **Avaliação Digital Mestre-Detalhe:** Ficha com critérios dinâmicos (científicos e tecnológicos) e **parecer/observação consolidada única ao final**. Totalização por **média aritmética simples** sem descarte de notas.
9.  **Dashboard Exclusivo para Telões e TVs (`apps/frontend-kiosk/`):** Painel público em tempo real sem expor notas ou ranqueamentos (reserva e sigilo absoluto até a cerimônia oficial), exibindo métricas agregadas de credenciamento, projetos na bancada e avaliações por área.
10. **CRUD Dinâmico de Áreas e Subáreas do Conhecimento:** Módulo administrativo completo no painel do evento para cadastrar, listar, atualizar e desativar (soft-delete) grandes áreas do conhecimento e suas respectivas subáreas, com proteção de integridade referencial impeditiva (não permite excluir área com subáreas ativas, nem subárea com projetos ou avaliadores vinculados).
11. **CRUD de Prêmios e Associação com Perguntas da Avaliação:** Gestão de premiações e menções honrosas da feira diretamente no painel do administrador do evento, com opção de indicar quais perguntas/critérios da ficha de avaliação compõem a nota de cada prêmio, gerando apuração e classificação automatizada por premiação.

### 3.2. O que o Sistema NÃO FAZ (Fora de Escopo)
*   Não realiza cobranças financeiras (evento público e gratuito).
*   Não emite certificados físicos ou digitais nesta versão.


---

## 4. Arquitetura do Monorepo: 4 Blocos Funcionais

O repositório adota a estrutura de **Monorepo** com desacoplamento rigoroso entre os domínios:

```text
fecitel-monorepo/
├── .agents/
│   └── rules.md                     # Regras de governança, convenções em inglês e regras de negócio
├── docs/
│   ├── context.md                   # Contextos, escopo e atores do sistema
│   ├── database.md                  # ERD Mermaid e Dicionário de Dados PostgreSQL
│   ├── design.md                    # Arquitetura, design system, paleta e endpoints
│   ├── mockups/                     # Mockups de alta fidelidade e protótipo interativo
│   └── 003_full_system_specification_report_2026-09-09_10h51.md # Este relatório técnico
└── apps/
    ├── backend/                     # BLOCO 1: API Central FastAPI + PostgreSQL bare-metal
    │   ├── run.sh                   # Script shell bare-metal de inicialização rápida
    │   ├── requirements.txt         # Dependências diretas (fastapi, sqlalchemy, asyncpg)
    │   ├── .env.example             # Variáveis de ambiente sem segredos
    │   └── src/                     # Core, models, schemas, direct services e routers
    │
    ├── frontend-admin/              # BLOCO 2: Painel de Administração e Gestão Geral da Feira
    │   ├── package.json             # Next.js 14+ (App Router), TypeScript, Tailwind CSS
    │   └── src/                     # Multi-evento, SUAP, Homologação, Alocação, Credenciamento e Apuração
    │
    ├── frontend-evaluator/          # BLOCO 3: Módulo de Avaliação Presencial (Mobile-First)
    │   ├── package.json             # Next.js 14+ PWA / Mobile-First
    │   └── src/                     # Leitor QR da bancada, ficha com steppers (+/-) e parecer único
    │
    └── frontend-kiosk/              # BLOCO 4: Módulo Kiosk para Telões e TVs Públicas
        ├── package.json             # Next.js 14+ otimizado para 1080p e 4K landscape
        └── src/                     # Dashboard público sem notas, dark mode nativo e auto-refresh 30s
```

### 4.1. Vantagens Técnicas da Arquitetura em 4 Blocos
1.  **Isolamento de Segurança e Bundling:** O módulo do avaliador (`frontend-evaluator`) não carrega o bundle nem as rotas administrativas; o quiosque (`frontend-kiosk`) possui bundle minúsculo e focado em exibição 24/7 sem rotinas de formulários pesados.
2.  **Otimização por Dispositivo:** O `frontend-evaluator` é focado em conexões móveis e telas de 360px a 430px; o `frontend-admin` é otimizado para telas desktop e notebooks com alta densidade de dados; o `frontend-kiosk` opera estritamente em escala para monitores e telões de grande formato.
3.  **Backend Unificado:** Todos os 3 frontends consomem a mesma API FastAPI (`apps/backend/`) de forma autenticada e tipada via Pydantic v2.

---

## 5. Arquitetura de Backend e Regras de Infraestrutura (`apps/backend/`)

### 5.1. Stack Tecnológica
*   **Linguagem:** Python 3.11+
*   **Framework Web:** FastAPI (100% assíncrono com Uvicorn)
*   **ORM e Banco de Dados:** SQLAlchemy 2.0 (assíncrono) com driver `asyncpg` sobre PostgreSQL 15+ local nativo (*bare-metal*).
*   **Validação de Dados:** Pydantic v2 estritamente em `snake_case`.
*   **Proibições:** Proibido Docker/Docker Compose, proibido Node/NestJS no backend, proibido SQLite e mocks nos testes automatizados (`pytest`).

### 5.2. Estrutura Enxuta em Serviços Diretos
Elimina camadas artificiais de *Repositories* ou *Use Cases* vazios:
*   `src/core/`: Configurações (`config.py`), conexão assíncrona (`database.py`), segurança (`security.py`) e middlewares de streaming/rate-limit (`middlewares.py`).
*   `src/models.py`: Modelos ORM SQLAlchemy unificados com `deleted_at` (Soft Delete).
*   `src/schemas.py`: Schemas Pydantic v2 para requisições e respostas.
*   `src/services/`: Lógica de negócio pura e transações SQL diretas (`auth_service.py`, `events_service.py`, `projects_service.py`, `logistics_service.py`, `allocation_service.py`, `evaluation_service.py`).
*   `src/routers/`: Endpoints HTTP FastAPI organizados por domínio (`auth.py`, `events.py`, `submissions.py`, `logistics.py`, `evaluations.py`, `dashboard.py`).

---

## 6. Design System e Tabela de Cores com Amostras Visuais

A paleta de cores oficial foi aprovada pelo Gestor, baseada no **Azul Safira Acadêmico** como cor primária e no **Verde Teal/Esmeralda** como cor secundária de alta visibilidade e tecnologia.

### 6.1. Tabela Comparativa de Tokens com Amostras Visuais (Dia e Noite)

Abaixo está a especificação completa com retângulos visuais de cada cor aplicável:

| Token de Design | Modo Dia (Light) | Amostra (Dia) | Modo Noite (Dark) | Amostra (Noite) | Função e Aplicação |
| :--- | :--- | :---: | :--- | :---: | :--- |
| **`primary-blue`** | `#2563EB` | <span style="display:inline-block;width:24px;height:24px;background-color:#2563EB;border-radius:4px;border:1px solid #999;vertical-align:middle;"></span> `#2563EB` | `#3B82F6` | <span style="display:inline-block;width:24px;height:24px;background-color:#3B82F6;border-radius:4px;border:1px solid #999;vertical-align:middle;"></span> `#3B82F6` | Botões de ação primária, abas de navegação ativas, destaques principais |
| **`primary-dark-blue`** | `#1E3A8A` | <span style="display:inline-block;width:24px;height:24px;background-color:#1E3A8A;border-radius:4px;border:1px solid #999;vertical-align:middle;"></span> `#1E3A8A` | `#1E3A8A` | <span style="display:inline-block;width:24px;height:24px;background-color:#1E3A8A;border-radius:4px;border:1px solid #999;vertical-align:middle;"></span> `#1E3A8A` | Identidade visual do logotipo FECITEL, estados hover ativos |
| **`secondary-teal`** | `#0D9488` | <span style="display:inline-block;width:24px;height:24px;background-color:#0D9488;border-radius:4px;border:1px solid #999;vertical-align:middle;"></span> `#0D9488` | `#14B8A6` | <span style="display:inline-block;width:24px;height:24px;background-color:#14B8A6;border-radius:4px;border:1px solid #999;vertical-align:middle;"></span> `#14B8A6` | Barras de progresso das bancadas, badges de status 'Presente', taxas concluídas |
| **`accent-emerald`** | `#10B981` | <span style="display:inline-block;width:24px;height:24px;background-color:#10B981;border-radius:4px;border:1px solid #999;vertical-align:middle;"></span> `#10B981` | `#22C55E` | <span style="display:inline-block;width:24px;height:24px;background-color:#22C55E;border-radius:4px;border:1px solid #999;vertical-align:middle;"></span> `#22C55E` | Confirmações de entrega de kits, sucesso em check-ins, aprovação de anuência |
| **`background`** | `#F8FAFC` | <span style="display:inline-block;width:24px;height:24px;background-color:#F8FAFC;border-radius:4px;border:1px solid #ccc;vertical-align:middle;"></span> `#F8FAFC` | `#0B0F19` | <span style="display:inline-block;width:24px;height:24px;background-color:#0B0F19;border-radius:4px;border:1px solid #555;vertical-align:middle;"></span> `#0B0F19` | Fundo geral da página (Ardósia claríssimo no Dia; Obsidiana no Noite/TV) |
| **`surface`** | `#FFFFFF` | <span style="display:inline-block;width:24px;height:24px;background-color:#FFFFFF;border-radius:4px;border:1px solid #ccc;vertical-align:middle;"></span> `#FFFFFF` | `#1E293B` | <span style="display:inline-block;width:24px;height:24px;background-color:#1E293B;border-radius:4px;border:1px solid #555;vertical-align:middle;"></span> `#1E293B` | Superfície de cartões, modais, cabeçalho e barra lateral (arejado) |
| **`border`** | `#E2E8F0` | <span style="display:inline-block;width:24px;height:24px;background-color:#E2E8F0;border-radius:4px;border:1px solid #ccc;vertical-align:middle;"></span> `#E2E8F0` | `#334155` | <span style="display:inline-block;width:24px;height:24px;background-color:#334155;border-radius:4px;border:1px solid #555;vertical-align:middle;"></span> `#334155` | Contornos sutis de inputs, tabelas e separadores |
| **`text-primary`** | `#0F172A` | <span style="display:inline-block;width:24px;height:24px;background-color:#0F172A;border-radius:4px;border:1px solid #999;vertical-align:middle;"></span> `#0F172A` | `#F8FAFC` | <span style="display:inline-block;width:24px;height:24px;background-color:#F8FAFC;border-radius:4px;border:1px solid #ccc;vertical-align:middle;"></span> `#F8FAFC` | Tipografia principal, títulos, números de impacto |
| **`text-muted`** | `#64748B` | <span style="display:inline-block;width:24px;height:24px;background-color:#64748B;border-radius:4px;border:1px solid #999;vertical-align:middle;"></span> `#64748B` | `#94A3B8` | <span style="display:inline-block;width:24px;height:24px;background-color:#94A3B8;border-radius:4px;border:1px solid #999;vertical-align:middle;"></span> `#94A3B8` | Rótulos secundários, legendas de gráficos e notas explicativas |
| **`warning-amber`** | `#F59E0B` | <span style="display:inline-block;width:24px;height:24px;background-color:#F59E0B;border-radius:4px;border:1px solid #999;vertical-align:middle;"></span> `#F59E0B` | `#FBBF24` | <span style="display:inline-block;width:24px;height:24px;background-color:#FBBF24;border-radius:4px;border:1px solid #999;vertical-align:middle;"></span> `#FBBF24` | Status 'Aguardando Anuência', pendências cadastrais |
| **`error-red`** | `#EF4444` | <span style="display:inline-block;width:24px;height:24px;background-color:#EF4444;border-radius:4px;border:1px solid #999;vertical-align:middle;"></span> `#EF4444` | `#F87171` | <span style="display:inline-block;width:24px;height:24px;background-color:#F87171;border-radius:4px;border:1px solid #999;vertical-align:middle;"></span> `#F87171` | Alerta de kit já entregue, projeto ausente, falhas de validação |

> **Nota de Calibração Visual:** No **Modo Claro**, a barra superior e a barra lateral utilizam o fundo em **branco puro arejado (`#FFFFFF`)** com borda em `#E2E8F0`, sem nenhum bloco de azul escuro pesado, conforme ajustado e aprovado.

### 6.2. Mockups Conceituais de Alta Fidelidade (Identidade Visual Aplicada)

Para auxiliar a equipe de desenvolvimento na visualização concreta da identidade visual, a seguir estão os mockups parciais de interface aplicando rigorosamente os tokens da tabela acima:

#### 6.2.1. Modo Claro (Light Mode) — Superfícies Arejadas e Acentos Safira/Teal
Projetado para ambientes com luz natural e iluminação de feiras científicas. As barras superior e lateral utilizam fundo **branco puro (`#FFFFFF`)** com divisores suaves em `#E2E8F0`, eliminando qualquer sensação de peso visual escuro. Ações primárias utilizam **Azul Safira (`#2563EB`)**, enquanto métricas e taxas de progresso são realçadas com o **Verde Teal (`#0D9488`)**:

![FECITEL - Mockup Conceitual em Modo Claro (Light Mode)](mockups/002_fecitel_light_mode_adjusted.jpg)

*   **Barra Superior & Menu Lateral:** Fundo branco puro (`#FFFFFF`) arejado, ícones e tipografia em ardósia escura (`#0F172A`), com item ativo destacado em Azul Safira suave.
*   **Cartões de Indicadores (KPIs):** Fundo branco com bordas `#E2E8F0`. Destaque numérico dos participantes (450) com gráfico de tendência em Teal, total de projetos (120) e taxa de avaliações (78%) com barra de progresso em Teal (`#0D9488`).
*   **Tabelas Operacionais:** Linhas limpas, com badges arredondados em verde/teal para projetos confirmados.

---

#### 6.2.2. Modo Escuro (Dark Mode) — Obsidiana e Alto Contraste Científico
Projetado para telas em auditórios, salas de apuração da coordenação e para o módulo de Smart TVs (`apps/frontend-kiosk`). Apresenta fundo em **Obsidiana Profundo (`#0B0F19`)**, cartões elevados em **Ardósia Escuro (`#1E293B`)**, destaques interativos em **Azul Elétrico (`#3B82F6`)** e acentos em **Teal Tecnológico (`#14B8A6`)**:

![FECITEL - Mockup Conceitual em Modo Escuro (Dark Mode)](mockups/001_fecitel_dark_mode.jpg)

*   **Fundo e Profundidade:** Fundo geral em `#0B0F19` com cartões em `#1E293B` e contornos sutis em `#334155`, garantindo excelente separação visual sem ofuscamento.
*   **Acentos de Destaque:** Barras de progresso por grande área do conhecimento (Engenharias, Exatas, Humanas) renderizadas em Teal vibrante (`#14B8A6`).
*   **Tipografia e Badges:** Textos claros em `#F8FAFC`, rótulos secundários em `#94A3B8`, e badges de status com contornos luminescentes.

---

#### 6.2.3. Protótipo Interativo em HTML/CSS Puro (Navegador)
Para que os desenvolvedores possam inspecionar os componentes em tempo real, testar sombras, tipografia e alternar dinamicamente entre Dia e Noite, está disponível o arquivo de protótipo:
*   Arquivo: [`docs/mockups/theme_preview.html`](mockups/theme_preview.html)
*   Como visualizar: Abrir diretamente em qualquer navegador Web (Chrome, Edge, Safari, Firefox). Possui botão funcional no cabeçalho para alternar o tema instantaneamente.

---

## 7. Especificação dos 3 Frontends

### 7.1. `apps/frontend-admin/` (Gestão, Homologação e Credenciamento)
*   **Público-Alvo:** Equipe organizadora da feira e voluntários da recepção.
*   **Dispositivos:** Desktops, laptops e tablets de credenciamento (1024px a 1920px).
*   **Módulos Centrais:**
    1.  *Autenticação Admin:* Login via e-mail e senha mestre criptografada.
    2.  *Multi-evento & Calendário:* Alternância entre edições. Trava lógica automática após `end_date`.
    3.  *Central de Submissões:* Homologação de trabalhos após confirmação de anuência do orientador.
    4.  *Credenciamento e Kits:* Campo com foco permanente para bipagem de crachá individual via leitor USB/Bluetooth. Retorno instantâneo do tamanho da camiseta com lock atômico condicional.
    5.  *Alocação Balanceada:* Algoritmo de distribuição de avaliadores pós-check-in (delta $\le 1$) e remanejamento manual.
    6.  *Apuração e Dois Rankings Oficiais:* 
        *   **Ranking 1 (Premiações Regulares / Gerais):** Tabela de classificação por média simples considerando **todos os itens** de avaliação, com visões agrupadas por Área do Conhecimento e Nível de Ensino (`MEDIO`, `FUNDAMENTAL`, `JUNIOR`), e visão de Melhor Geral da feira.
        *   **Ranking 2 (Premiações Específicas):** Classificação oficial de prêmios específicos considerando **exclusivamente os itens** de avaliação indicados no cadastro de cada prêmio.
    7.  *CRUD de Áreas e Subáreas (`/admin/knowledge-areas`):* Integrado ao painel do administrador do evento para gestão hierárquica completa (cadastrar, editar e desativar áreas e subáreas por edição), com proteção referencial que impede exclusão se houver projetos ou avaliadores vinculados.
    8.  *CRUD de Prêmios e Associação de Questões (`/admin/awards`):* Painel para cadastro de premiações com seleção interativa das perguntas/critérios da ficha de avaliação (`evaluation_criteria`) que compõem a pontuação de cada prêmio, gerando apuração automática dos vencedores.


### 7.2. `apps/frontend-evaluator/` (Avaliação Presencial Mobile-First)
*   **Público-Alvo:** Professores e técnicos avaliadores durante a feira presencial.
*   **Dispositivos:** Smartphones (360px a 430px) com operação em uma única mão.
*   **Módulos Centrais:**
    1.  *Autenticação sem Senha Estática:* Login via código OTP de 8 caracteres alfanuméricos em caixa alta recebido por e-mail, digitado em campo mascarado como senha (`type="password"`).
    2.  *Leitor QR da Bancada:* Botão proeminente que aciona a câmera para ler o QR Code fixado na mesa do projeto.
    3.  *Ficha de Notas com Steppers:* Renderização automática dos critérios (científicos ou tecnológicos) com botões numéricos táteis `+` e `-` (0.0 a 10.0).
    4.  *Parecer Único Consolidado:* Textarea expansível para observações gerais ao término da avaliação.
    5.  *Cache Local e Tolerância Offline:* Gravação de rascunhos em cache no smartphone para prevenir perda de dados por oscilação de rede.

### 7.3. `apps/frontend-kiosk/` (Dashboard Público em Telões e TVs)
*   **Público-Alvo:** Visitantes, estudantes, professores e comunidade presentes no pátio do evento.
*   **Dispositivos:** Smart TVs, telões de LED e projetores (1080p e 4K landscape).
*   **Módulos Centrais:**
    1.  *Sem Autenticação e Sem Interação:* Roda em modo quiosque contínuo, consumindo o endpoint público `GET /api/v1/dashboard/public-tv`.
    2.  *Garantia de Sigilo e Fair Play:* Proibido exibir notas individuais, ranqueamentos ou pareceres de avaliadores.
    3.  *Métricas em Destaque:*
        *   Participantes inscritos vs. credenciados com percentual ao vivo.
        *   Projetos inscritos vs. presentes nas bancadas.
        *   Progresso geral das avaliações realizadas (barra de progresso).
        *   Total de avaliações concluídas por área do conhecimento (CBS, Exatas, Humanas, Agrárias, Engenharias).
        *   Total de escolas e municípios atendidos.
    4.  *Ergonomia Visual:* Dark mode padrão nativo (`#0B0F19`), tipografia legível a mais de 15 metros de distância e auto-refresh silencioso a cada 30 segundos.

---

## 8. Modelo Relacional e Diagrama ERD (PostgreSQL)

```mermaid
erDiagram
    events ||--o{ event_stages : "configures"
    events ||--o{ education_levels : "defines"
    events ||--o{ projects : "hosts"
    events ||--o{ evaluation_criteria : "uses"
    events ||--o{ event_participants : "enrolls"
    events ||--o{ evaluator_allocations : "manages"
    events ||--o{ knowledge_areas : "defines_areas"
    events ||--o{ awards : "grants"
    schools ||--o{ projects : "originates"
    education_levels ||--o{ projects : "classifies"
    knowledge_areas ||--o{ sub_areas : "contains"
    sub_areas ||--o{ projects : "categorizes"
    sub_areas ||--o{ person_subareas : "qualifies"
    awards ||--o{ award_criteria : "specifies"
    evaluation_criteria ||--o{ award_criteria : "qualifies_for"
    people ||--o{ user_roles : "holds_roles"
    roles ||--o{ user_roles : "designates"
    people ||--o{ event_participants : "participates_as"
    people ||--o{ person_subareas : "expert_in"
    people ||--o{ project_members : "joins"
    projects ||--o{ project_members : "composed_of"
    projects ||--o{ evaluator_allocations : "receives_allocation"
    people ||--o{ evaluator_allocations : "assigned_evaluator"
    evaluator_allocations ||--o{ evaluations : "yields"
    projects ||--o{ evaluations : "evaluated_in"
    evaluations ||--o{ evaluation_items : "contains_scores"
    evaluation_criteria ||--o{ evaluation_items : "scores"

    events {
        int id PK
        varchar name
        int year
        date start_date
        date end_date
        varchar status "OPEN, CLOSED"
        int max_projects_per_evaluator
        timestamp deleted_at
    }

    knowledge_areas {
        int id PK
        int event_id FK
        varchar name
        timestamp deleted_at
    }

    sub_areas {
        int id PK
        int area_id FK
        varchar name
        timestamp deleted_at
    }

    awards {
        int id PK
        int event_id FK
        varchar name
        varchar sponsor
        timestamp deleted_at
    }

    award_criteria {
        int id PK
        int award_id FK
        int criterion_id FK
        decimal weight
        timestamp deleted_at
    }


    people {
        int id PK
        varchar name
        varchar email UK
        varchar password_hash "For ADMIN"
        varchar access_code_hash "For PARTICIPANTS (8-char OTP)"
        varchar barcode UK
        timestamp deleted_at
    }

    projects {
        int id PK
        int event_id FK
        int school_id FK
        int level_id FK
        int subarea_id FK
        varchar title
        varchar project_type "SCIENTIFIC, TECHNOLOGICAL"
        varchar qrcode_token UK
        varchar status "DRAFT, SUBMITTED, WAITING_CONSENT, HOMOLOGATED, PRESENT, ABSENT, UNDER_EVALUATION, EVALUATED"
        boolean advisor_consent
        timestamp deleted_at
    }

    event_participants {
        int id PK
        int event_id FK
        int person_id FK
        varchar tshirt_size "PP, P, M, G, GG, XG"
        boolean kit_delivered
        boolean presence_confirmed
        timestamp deleted_at
    }

    evaluator_allocations {
        int id PK
        int event_id FK
        int project_id FK
        int evaluator_id FK
        varchar allocation_type "AUTOMATIC_CHECKIN, MANUAL_ADMIN"
        varchar status "PENDING, COMPLETED, CANCELLED"
        timestamp deleted_at
    }

    evaluations {
        int id PK
        int allocation_id FK
        int project_id FK
        int evaluator_id FK
        text general_feedback
        varchar status "DRAFT, COMPLETED"
        timestamp deleted_at
    }

    evaluation_items {
        int id PK
        int evaluation_id FK
        int criterion_id FK
        decimal score
        timestamp deleted_at
    }
```

---

## 9. Diagramas de Sequência dos Principais Fluxos

### 9.1. Submissão de Projetos e Anuência do Orientador
```mermaid
sequenceDiagram
    autonumber
    actor Student as Estudante Proponente
    actor Advisor as Professor Orientador
    participant API as Backend FastAPI (apps/backend)
    participant DB as PostgreSQL 15+

    Student->>API: POST /api/v1/projects (dados, alunos, orientador)
    activate API
    API->>DB: Bulk check de emails e inserção de novos participantes
    API->>DB: INSERT INTO projects (status='WAITING_CONSENT', advisor_consent=FALSE)
    API->>DB: INSERT INTO project_members
    DB-->>API: Confirmado
    API-->>Student: 201 Created (Aguardando anuência do orientador)
    deactivate API

    note over Advisor, API: --- Momento da Anuência Digital (frontend-evaluator / portal) ---
    Advisor->>API: POST /api/v1/projects/{id}/consent (Autenticado via OTP 8 caracteres)
    activate API
    API->>DB: UPDATE projects SET advisor_consent = TRUE, status = 'HOMOLOGATED'
    DB-->>API: Confirmado
    API-->>Advisor: 200 OK (Projeto homologado para a feira)
    deactivate API
```

### 9.2. Credenciamento e Entrega de Kits no `frontend-admin`
```mermaid
sequenceDiagram
    autonumber
    actor Admin as Operador de Recepção (frontend-admin)
    participant API as Backend FastAPI (apps/backend)
    participant DB as PostgreSQL 15+

    Admin->>API: POST /api/v1/logistics/scan-barcode {"barcode": "BAR_12345"}
    activate API
    API->>DB: Confirma presença da pessoa e promove projeto para 'PRESENT'
    DB-->>API: Confirmado
    API-->>Admin: 200 OK (Presença Confirmada • Projeto na Bancada)
    deactivate API

    Admin->>API: POST /api/v1/logistics/checkout-kit {"barcode": "BAR_12345"}
    activate API
    API->>DB: UPDATE event_participants SET kit_delivered = TRUE WHERE person_id = :id AND kit_delivered = FALSE RETURNING tshirt_size
    alt Sucesso (Primeira retirada)
        DB-->>API: tshirt_size = 'G'
        API-->>Admin: 200 OK {"tshirt_size": "G", "status": "ENTREGA_CONFIRMADA"}
    else Duplicidade (Já retirado)
        DB-->>API: 0 rows affected
        API-->>Admin: 409 Conflict {"error": "KIT_ALREADY_DELIVERED"}
    end
    deactivate API
```

### 9.3. Avaliação Presencial na Bancada no `frontend-evaluator`
```mermaid
sequenceDiagram
    autonumber
    actor Evaluator as Avaliador (frontend-evaluator)
    participant API as Backend FastAPI (apps/backend)
    participant DB as PostgreSQL 15+

    Evaluator->>API: GET /api/v1/evaluations/sheet?qrcode=PROJ_10_HASH (Câmera escaneia bancada)
    activate API
    API->>DB: Busca projeto, categoria e critérios aplicáveis
    DB-->>API: Retorna dados e critérios
    API-->>Evaluator: 200 OK (Ficha digital com steppers +/-)
    deactivate API

    Evaluator->>API: POST /api/v1/evaluations (notas por critério + parecer_geral único)
    activate API
    API->>DB: INSERT INTO evaluations (parecer_geral) + Bulk INSERT evaluation_items
    API->>DB: UPDATE evaluator_allocations SET status = 'COMPLETED'
    DB-->>API: Transação Confirmada
    API-->>Evaluator: 201 Created (Avaliação registrada com sucesso)
    deactivate API
```

---

## 10. Matriz de Endpoints RESTful (`/api/v1/`)

| Bloco Consumidor | Método | Endpoint | Sucesso | Descrição Funcional |
| :--- | :--- | :--- | :--- | :--- |
| **Todos** | `POST` | `/api/v1/auth/login-admin` | `200 OK` | Login administrativo com e-mail e senha mestre. |
| **Todos** | `POST` | `/api/v1/auth/request-code`| `200 OK` | Gera e envia código OTP de 8 caracteres em caixa alta por e-mail. |
| **Todos** | `POST` | `/api/v1/auth/login-participant`| `200 OK` | Login de participante/avaliador com código OTP de 8 caracteres. |
| **Admin** | `GET`  | `/api/v1/events` | `200 OK` | Listagem e filtros de eventos ativos e históricos. |
| **Admin** | `POST` | `/api/v1/events` | `201 Created` | Criação de evento com regras e extensões de arquivos. |
| **Admin** | `GET`  | `/api/v1/knowledge-areas` | `200 OK` | Lista áreas do conhecimento com subáreas aninhadas. |
| **Admin** | `POST` | `/api/v1/knowledge-areas` | `201 Created` | Cadastra nova área do conhecimento (nome único). |
| **Admin** | `PUT`  | `/api/v1/knowledge-areas/{id}` | `200 OK` | Atualiza metadados da área do conhecimento. |
| **Admin** | `DELETE`| `/api/v1/knowledge-areas/{id}`| `204 No Content` | Exclusão lógica da área (bloqueada se houver subáreas ativas). |
| **Admin** | `GET`  | `/api/v1/knowledge-areas/{id}/subareas` | `200 OK` | Lista subáreas da área de conhecimento especificada. |
| **Admin** | `POST` | `/api/v1/knowledge-areas/{id}/subareas` | `201 Created` | Cadastra subárea vinculada à área (`UNIQUE(area_id, name)`). |
| **Admin** | `PUT`  | `/api/v1/subareas/{id}` | `200 OK` | Atualiza dados cadastrais da subárea. |
| **Admin** | `DELETE`| `/api/v1/subareas/{id}` | `204 No Content` | Exclusão lógica (bloqueada se houver projetos ou avaliadores). |
| **Admin** | `GET`  | `/api/v1/events/{id}/awards` | `200 OK` | Lista prêmios do evento com perguntas associadas. |
| **Admin** | `POST` | `/api/v1/events/{id}/awards` | `201 Created` | Cria premiação no painel administrativo do evento. |
| **Admin** | `GET`  | `/api/v1/awards/{id}` | `200 OK` | Detalhes do prêmio e critérios de notas vinculados. |
| **Admin** | `PUT`  | `/api/v1/awards/{id}` | `200 OK` | Atualiza nome, descrição ou patrocinador do prêmio. |
| **Admin** | `DELETE`| `/api/v1/awards/{id}` | `204 No Content` | Exclusão lógica do prêmio. |
| **Admin** | `POST` | `/api/v1/awards/{id}/criteria` | `201 Created` | Vincula critério/pergunta da avaliação ao prêmio. |
| **Admin** | `DELETE`| `/api/v1/awards/{id}/criteria/{criterion_id}` | `204 No Content` | Desvincula critério/pergunta do prêmio. |
| **Admin** | `GET`  | `/api/v1/awards/{id}/standings` | `200 OK` | Classificação dos projetos com base nas questões do prêmio. |
| **Admin** | `POST` | `/api/v1/people/import-suap` | `200 OK` | Ingestão em lote de alunos e servidores via planilha SUAP. |
| **Admin** | `POST` | `/api/v1/allocations/auto-balance`| `200 OK` | Algoritmo de balanceamento pós-checkin (delta $\le 1$). |
| **Admin** | `POST` | `/api/v1/logistics/scan-barcode` | `200 OK` | Bipagem de crachá individual; check-in de presença e bancada. |
| **Admin** | `POST` | `/api/v1/logistics/checkout-kit` | `200 OK` | Entrega atômica condicional de camiseta/kit com bloqueio duplo. |
| **Admin** | `GET`  | `/api/v1/dashboard/leaderboard/area-level` | `200 OK` | **Ranking 1:** Classificação por Área e Nível de Ensino (todos os itens de notas). |
| **Admin** | `GET`  | `/api/v1/dashboard/leaderboard/overall` | `200 OK` | **Ranking 1:** Classificação Melhor Geral da Feira (todos os itens de notas). |
| **Admin** | `GET`  | `/api/v1/awards/{id}/standings` | `200 OK` | **Ranking 2:** Classificação de Prêmio Específico (apenas critérios indicados). |
| **Evaluator**| `GET`| `/api/v1/evaluations/my-allocations`| `200 OK`| Lista de trabalhos alocados para o avaliador logado. |
| **Evaluator**| `GET`| `/api/v1/evaluations/sheet` | `200 OK` | Carrega critérios da categoria após leitura do QR da bancada. |
| **Evaluator**| `POST`| `/api/v1/evaluations` | `201 Created` | Registro de notas numéricas e parecer geral consolidado. |
| **Kiosk** | `GET`  | `/api/v1/dashboard/public-tv` | `200 OK` | Estatísticas agregadas públicas em tempo real (sem notas/ranking). |


---

## 11. Checklist Final de Prontidão para a Equipe de Desenvolvimento

- [x] **Arquitetura Monorepo 4 Blocos:** Compreensão dos 4 módulos (`apps/backend/`, `apps/frontend-admin/`, `apps/frontend-evaluator/`, `apps/frontend-kiosk/`).
- [x] **Governança:** Alex Araújo como autoridade soberana; proibido iniciar código sem aprovação; proíbido `git push` autônomo.
- [x] **Stack:** Python 3.11+, FastAPI, SQLAlchemy 2.0 assíncrono, PostgreSQL nativo bare-metal (sem Docker).
- [x] **Padrão de Idiomas do Projeto:** Código-fonte e banco de dados em inglês; documentação (.md), interface (UI) e mensagens aos participantes em português.
- [x] **Autenticação Dual:** Admin com senha bcrypt; Participantes com OTP de 8 caracteres em caixa alta mascarado como senha.
- [x] **Design System Aprovado:** Paleta **Azul Safira (`#2563EB`) + Verde Teal (`#0D9488` / `#14B8A6`)**, com Modo Dia arejado (barras brancas) e Modo Noite obsidiana.
- [x] **CRUD de Áreas e Subáreas no Painel Admin:** Gestão dinâmica pelo Admin do evento com validação referencial impeditiva contra deleção acidental.
- [x] **CRUD de Prêmios e Vínculo de Questões da Avaliação:** Parametrização de premiações especiais e amarração com critérios/perguntas de notas.
- [x] **Sigilo no Kiosk:** Endpoint `/public-tv` blindado contra vazamento de notas individuais ou ranqueamentos parciais.
- [x] **Fluxo Visual de Frontend:** O código Next.js só se inicia após a aprovação formal dos Mockups de Imagem e Protótipo HTML/CSS puro.



---

*Fim da Especificação Técnica Oficial Atualizada — FECITEL 2026.*
