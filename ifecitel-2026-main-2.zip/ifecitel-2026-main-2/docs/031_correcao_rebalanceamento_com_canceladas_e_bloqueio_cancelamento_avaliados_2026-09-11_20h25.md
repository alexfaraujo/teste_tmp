# Registro de Alterações: Correção do Rebalanceamento com Alocações Canceladas e Bloqueio de Cancelamento de Trabalhos Avaliados

**Data:** 11/09/2026 - 20h25  
**Autor:** Antigravity  
**Contexto:** Resolução de erro no algoritmo de auto-balanceamento pós-cancelamento e reforço das travas de integridade contra cancelamento de trabalhos já avaliados.

---

## 1. Diagnóstico dos Problemas

### 1.1 Erro ao Clicar em "Rebalancear Sistema"
- **Sintoma:** O frontend exibia a mensagem de erro *"Erro ao executar reequilíbrio automático."*
- **Causa Raiz Identificada nos Logs (`task-4702.log`):**
  ```
  sqlalchemy.exc.IntegrityError: duplicate key value violates unique constraint "uq_evaluator_allocations_project_evaluator"
  DETAIL: Key (project_id, evaluator_id)=(948, 1700) already exists.
  ```
  Ao cancelar uma alocação, o registro permanece no banco de dados com `status = 'CANCELLED'` para preservar o histórico. O algoritmo de rebalanceamento automático (`run_auto_balance_allocation`) carregava apenas alocações com `status != 'CANCELLED'`. Quando o projeto necessitava de avaliadores e o avaliador cancelado pertencia à subárea elegível e possuía carga disponível, o algoritmo tentava criar uma nova linha via `INSERT` com o mesmo par `(project_id, evaluator_id)`, disparando a restrição de unicidade do PostgreSQL.

### 1.2 Regra de Cancelamento de Avaliação Concluída
- **Requisito:** Não pode ser permitido cancelar uma alocação quando o avaliador já tiver realizado a avaliação do trabalho.
- **Situação Verificada:**
  - No frontend (`/evaluators`), a coluna de ações já condicionava a renderização do botão de lixeira a `alloc.status === "PENDING"`. Quando avaliado (`COMPLETED`), o botão não é exibido.
  - No backend (`cancel_allocation`), havia checagem direta em `alloc.status == AllocationStatus.COMPLETED`. No entanto, foi necessário reforçar a validação verificando também se existe registro na tabela `evaluations` com status concluído ou data de avaliação registrada, garantindo que mesmo se a alocação estivesse desincronizada, o cancelamento fosse estritamente bloqueado.

---

## 2. Alterações Implementadas

### 2.1 Backend (`apps/backend/app/services/allocation_service.py`)
1. **Algoritmo de Rebalanceamento (`run_auto_balance_allocation`):**
   - Carrega todas as alocações da edição (`all_allocs`), separando:
     - `project_allocations`: alocações com `status != CANCELLED` (usadas para métrica de carga do avaliador e garantia da Regra de Ouro $\Delta \le 1$).
     - `project_all_evaluators`: conjunto com todos os avaliadores que possuem histórico de atribuição no projeto (ativas e canceladas).
   - Ao selecionar avaliadores disponíveis para o projeto, o algoritmo filtra `e not in project_all_evaluators[p.id]`.
   - Isso impede que o sistema tente reatribuir um avaliador para um projeto do qual ele foi cancelado, evitando a colisão na restrição única `uq_evaluator_allocations_project_evaluator` e respeitando a decisão administrativa do cancelamento.

2. **Check-in Dinâmico de Avaliador (`allocate_evaluator_on_checkin`):**
   - Adicionada a mesma salvaguarda: projetos dos quais o avaliador foi cancelado são mantidos em `already_allocated_project_ids` para não serem sugeridos no check-in dinâmico.

3. **Alocação Manual Resiliente (`manual_allocate`):**
   - Se o administrador decidir manualmente reatribuir o mesmo avaliador para o mesmo projeto após ter cancelado, o sistema detecta a alocação com `status == 'CANCELLED'` e a reativa (`status = 'PENDING'`, `allocation_type = 'MANUAL_ADMIN'`, `allocated_at = now()`), evitando violação de chave única. Se a alocação já foi `COMPLETED`, rejeita com erro 400.

4. **Bloqueio Estrito de Cancelamento de Trabalhos Avaliados (`cancel_allocation`):**
   - Valida `alloc.status == AllocationStatus.COMPLETED` -> Rejeita com HTTP 400.
   - Valida `alloc.evaluation` (se preenchida ou concluída) -> Rejeita com HTTP 400.
   - Realiza consulta preventiva na tabela `evaluations` para `(alloc.project_id, alloc.evaluator_id)`: se houver avaliação concluída ou avaliada, sincroniza a alocação para `COMPLETED` e rejeita a exclusão com HTTP 400 (*"Não é possível cancelar uma alocação cuja avaliação já foi realizada."*).

### 2.2 Testes Automatizados (`apps/backend/tests/test_phase4.py`)
- Adicionado teste de reativação de alocação cancelada via manual allocate.
- Adicionado teste de execução do `auto-balance` com alocações canceladas existentes, validando resposta HTTP 200 sem erro de chave duplicada.
- Adicionado teste garantindo que após a submissão da avaliação presencial, tentativas de cancelar alocação retornam HTTP 400.

---

## 3. Verificação e Resultados

1. **Pytest (Backend):**
   - Executado `.venv/bin/pytest tests/test_phase4.py` -> 6/6 testes aprovados.
   - Executado `.venv/bin/pytest` completo -> **33 testes aprovados (100% de sucesso)**.
2. **Typecheck (Frontend):**
   - Executado `npx tsc --noEmit` -> **0 erros**.
3. **Serviço Backend em Execução:**
   - Servidor FastAPI uvicorn ativo com reload automático sem exceções no console.
