# Documento Técnico 051: Gestão de Momentos de Lanche e Distribuição com Captura Óptica (Regra BR-30)

**Data:** 2026-09-15  
**Contexto:** Plataforma EasyEvent — Painel do Administrador & Operações de Campo  
**Status:** Aprovado e Implementado  

---

## 1. Visão Geral e Justificativa Operacional

Em feiras de ciências e mostras tecnológicas, o fornecimento de lanches (*coffee breaks*, almoços, kits de alimentação) é uma das operações logísticas mais críticas e sensíveis a fraudes, desperdícios e filas excessivas. 

Os desafios comuns identificados na prática incluem:
1. **Retiradas Duplicadas:** Estudantes ou visitantes entram na fila múltiplas vezes para pegar mais de uma unidade.
2. **Descontrole Quantitativo:** A comissão organizadora não sabe quantos lanches já foram entregues, quantos restam e quantos participantes ainda não retiraram.
3. **Restrições de Público-Alvo:** Determinados lanches são custeados especificamente para alunos autores e orientadores que estão em estande, enquanto outros podem ser abertos para avaliadores ou voluntários.
4. **Variabilidade de Programação:** Alguns eventos oferecem 1 lanche por dia; outros oferecem 2 ou mais lanches por dia (manhã/tarde/noite) distribuídos ao longo de vários dias de evento.
5. **Limitação de Hardware:** Nem sempre há computadores portáteis e mesas disponíveis nos pontos de entrega. A leitura precisa ser executada de forma rápida e móvel por voluntários utilizando smartphones comuns ou leitores de código de barras USB conectados via cabo OTG.

A **Regra BR-30** estabelece um sistema flexível de **Momentos de Lanche** e um fluxo de **Distribuição In Loco com Captura Óptica Híbrida** para resolver integralmente essas dores.

---

## 2. Regra de Negócio Formal: BR-30

### 2.1 Cadastro e Flexibilidade de Momentos de Lanche
* Cada edição de evento (`events`) pode possuir múltiplos momentos de lanche cadastrados (`snack_moments`).
* Cada momento possui:
  * **Nome descritivo:** Ex.: *"Lanche da Tarde — Dia 1"*, *"Café da Manhã dos Avaliadores"*, *"Coffee Break Encerramento"*.
  * **Data e Faixa de Horário:** Data do evento (`date`), horário de início (`start_time`) e horário de término (`end_time`).
  * **Status de Ativação:** Indicador booleano (`is_active`). Apenas momentos marcados como ativos aceitam registros de entrega na fila, permitindo à comissão abrir e fechar a distribuição com um único toque.
  * **Público-Alvo Autorizado (`target_roles`):** Permite configurar se o momento é destinado a `ALL` (todos os participantes credenciados) ou a papéis específicos (ex.: `STUDENT`, `ADVISOR`, `COADVISOR`, `EVALUATOR`, `ORGANIZER`, `VOLUNTEER`).
  * **Cota Prevista / Meta (`total_budgeted`):** Quantidade total estimada de lanches preparados/contratados, viabilizando métricas de consumo em tempo real (`X / Y entregues — Z%`).

### 2.2 Trava Antifraude de Unicidade Estrita
* Toda entrega registrada no sistema cria um registro na tabela associativa `snack_deliveries` vinculando o `snack_moment_id` e o `participant_id` (`event_participants.id`).
* O banco de dados impõe a restrição de integridade única:
  $$\text{UNIQUE}(\text{snack\_moment\_id}, \text{participant\_id}) \quad \text{onde } \text{deleted\_at IS NULL}$$
* Caso o mesmo crachá seja lido uma segunda vez no mesmo momento de lanche:
  * O sistema **rejeita imediatamente** a nova entrega com status `ALREADY_DELIVERED`.
  * A tela do operador exibe um alerta visual vermelho enfático informando o **horário exato** da retirada anterior e o nome do operador que entregou, impedindo o duplo consumo.

### 2.3 Resolução Polimórfica de Captura Óptica
O endpoint de entrega (`POST /api/v1/snacks/moments/{moment_id}/deliver`) aceita um termo de identificação polimórfico:
1. **Código de barras linear do crachá** (`people.barcode`, ex: `BC-00042`).
2. **CPF do participante** (`people.cpf`, formatado ou apenas dígitos).
3. **ID do participante** no evento (`event_participants.id` ou `people.id`).

---

## 3. Modelo de Dados e Diagrama Relacional

```mermaid
erDiagram
    events ||--o{ snack_moments : "possui"
    snack_moments ||--o{ snack_deliveries : "registra"
    event_participants ||--o{ snack_deliveries : "recebe"
    people ||--o{ snack_deliveries : "entrega (operador)"

    snack_moments {
        int id PK
        int event_id FK
        varchar name
        date date
        varchar start_time
        varchar end_time
        boolean is_active
        varchar target_roles
        int total_budgeted
        text notes
        timestamp created_at
        timestamp updated_at
        timestamp deleted_at
    }

    snack_deliveries {
        int id PK
        int snack_moment_id FK
        int participant_id FK
        int delivered_by_user_id FK
        timestamp delivered_at
        varchar notes
        timestamp created_at
        timestamp updated_at
        timestamp deleted_at
    }
```

---

## 4. Arquitetura da Interface Operacional In Loco (Scanner Mobile-First)

Para maximizar a eficiência dos operadores e voluntários na fila de entrega de lanches, a tela `/snacks/distribution` foi concebida com princípios de **UX de alta velocidade**:

1. **Modo Leitor Físico USB / OTG:**
   * Utiliza um adaptador USB OTG de baixo custo conectado à porta USB-C do celular, alimentando um leitor de código de barras comum.
   * O leitor emula teclado (HID). A tela mantém o foco automático contínuo em um campo de captura e processa a leitura instantaneamente no caractere `Enter`.
2. **Modo Câmera do Smartphone:**
   * Abre a câmera traseira do smartphone diretamente pelo navegador via biblioteca `html5-qrcode`.
   * Permite que qualquer membro da equipe realize leituras sem nenhum leitor físico.
3. **Feedback Audiovisual Imediato:**
   * **🟩 Verde (Sucesso):** A tela ilumina em verde, emite bip sonoro ascendente e sintetizado via `Web Audio API` (sem depender de conexões externas de áudio) e exibe os dados completos do participante (nome, papel, escola/instituição e título do projeto científico se for autor).
   * **🟥 Vermelho (Já Retirado):** A tela ilumina em vermelho, emite som grave de alerta e exibe o aviso claro: *"Lanche já retirado às HH:MM:SS"*.
   * **🟨 Amarelo (Não Autorizado / Inativo):** Informa restrição de público ou momento de lanche fechado pela coordenação.
4. **Contador em Tempo Real:**
   * Placar visual amplo exibindo a contagem progressiva de lanches entregues frente ao estoque orçado e percentual atingido.

---

## 5. Preenchimento Automático da Meta e Humanização das Mensagens

### 5.1 Estimativa Automática Baseada no Público-Alvo
* No cadastro de novos momentos de lanche, o campo **Quantidade Estimada (Meta)** é populado dinamicamente através do endpoint `GET /api/v1/snacks/events/{event_id}/eligible-count?target_roles=...`.
* O sistema calcula a quantidade exata de inscritos no evento de acordo com a seleção:
  * `ALL`: Todos os participantes inscritos na edição (`EventParticipant`).
  * `STUDENT,ADVISOR,COADVISOR`: Apenas alunos autores, orientadores e coorientadores.
  * `EVALUATOR`: Apenas avaliadores cadastrados e alocados.
  * `ORGANIZER,VOLUNTEER`: Membros da comissão organizadora e voluntários (`EventAdministrator`).
* **Valor Padrão de Contingência:** Se ainda não houver participantes inscritos para o público selecionado, o sistema adota automaticamente o valor padrão de **150 unidades**.
* Na edição de momentos já cadastrados, a interface fornece a opção de sincronizar e atualizar a meta com o número vigente de inscritos.

### 5.2 Humanização da Interface e Mensagens Acolhedoras
* **Remoção de Jargões e Códigos Internos:** Códigos técnicos (como menções a "Regra BR-30" e termos mecânicos como "Bloqueado" ou "Trava Antifraude") foram substituídos por termos claros e amigáveis ("Controle Individual", "1 Lanche por Pessoa", "Lanche Já Retirado").
* **Feedback Empático no Scanner:**
  * Sucesso: *"Lanche entregue com sucesso! Bom apetite, {nome}!"*
  * Já retirado: *"O lanche de {nome} já foi retirado hoje às {horário} (atendido por {operador}). Para que todos possam ser atendidos, cada participante tem direito a 1 lanche por momento."*
  * Restrição de público: *"Este lanche é reservado para {público}. O perfil de {nome} ({perfil}) não possui autorização para este momento."*
  * Não credenciado: *"{nome} não possui inscrição confirmada nesta edição do evento. Para receber o lanche, solicite o credenciamento na comissão organizadora."*

