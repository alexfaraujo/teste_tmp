# [HIST-002] Visual Design System, Theming, and Public TV Dashboard Specification

**Date & Time:** 2026-09-09 10:30:00 -04:00  
**Author:** Antigravity (AI / Pair Programming)  
**Approver & Project Manager:** Alex Araújo  
**Status:** Visual Architecture Defined and Documented  

---

## 1. Context and Purpose

This record establishes the visual design identity, responsive device profiles, and architectural specification for the newly requested **Public Big-Screen TV Dashboard** for the FECITEL system.

---

## 2. Manager Directives Addressed

1.  **Color Palette:** Base on blue and suggest a complementary secondary color that ensures a clean, modern, and discrete aesthetic.
2.  **Day & Night Theme (Light / Dark Mode):** Provide a user-selectable toggle between Light and Dark themes, optimized for efficiency and readability.
3.  **Responsive Device Profiles:**
    *   *Evaluators:* Mobile-First for smartphones.
    *   *Administrators & Logistics:* Desktops, laptops, and tablets.
4.  **Dedicated Public Big-Screen TV Dashboard:**
    *   Separate dashboard for public display on venue TVs, LED panels, and auditorium projectors.
    *   Strictly generic metrics: registered vs. present participants, registered vs. present projects, evaluations completed per area, participating schools.
    *   **Strict Privacy / Fair Play Rule:** Prohibited from exposing individual project scores, evaluator notes, or competitive rankings.

---

## 3. Approved Visual Design System

### 3.1. Color Palette: Academic Blue + Modern Teal/Emerald
*   **Primary Color (Trust, Academics, Authority):**
    *   `#1E3A8A` (Navy Blue) / `#2563EB` (Sapphire Blue 600).
*   **Suggested Secondary Color (Innovation, Science, Success):**
    *   `#0D9488` (Vibrant Teal) / `#10B981` (Emerald Green in Light Mode) / `#14B8A6` (Mint Teal in Dark Mode).
    *   *Rationale:* Teal harmonizes naturally with blue while introducing a high-tech scientific identity (biology, sustainability, engineering). It serves as an ideal non-aggressive highlight for progress bars, check-in badges, and active state indicators.
*   **Neutral Surfaces:**
    *   Cool Slate (`#0F172A` down to `#F8FAFC`).

### 3.2. Day & Night Themes (Light / Dark Mode)
*   **Light Mode ("Dia"):** Tailored for sunlight and brightly lit exhibition halls. Clean white cards (`#FFFFFF`), light slate background (`#F8FAFC`), deep slate text (`#0F172A`).
*   **Dark Mode ("Noite"):** Tailored for auditorium presentations and large screens. Obsidian background (`#0B0F19`), slate cards (`#1E293B`), light slate text (`#F8FAFC`). Reduces eye strain and prevents screen glare.

---

## 4. Public Big-Screen TV Dashboard Architecture

*   **Route:** `/tv` or `/public-dashboard`
*   **Endpoint:** `GET /api/v1/dashboard/public-tv?event_id=1` (unauthenticated, cached, rate-limited).
*   **Core Metrics Rendered:**
    1.  *Attendee Attendance:* Registered Participants vs. Present (`450 / 418 - 92.8%`).
    2.  *Project Attendance:* Registered Projects vs. Present on Booth (`120 / 115 - 95.8%`).
    3.  *Global Evaluation Progress:* Total Evaluations Completed (`280 / 360 - 77.8%`).
    4.  *Progress by Knowledge Area:* Completion gauges for CBS, Exact Sciences, Humanities, Agro, and Engineering.
    5.  *Institutional Reach:* Total participating schools and cities.
    6.  *Fair Schedule Ticker:* Live marquee with announcements and event timeline.
*   **Security & Fair Play:** No individual scores, rankings, or evaluator identities are transmitted to or rendered by this client.
