# 039 — Refinamento de Permissões (RBAC), Remoção de Admin em Participantes e Centralização da Equipe

**Data:** 2026-09-12  
**Contexto:** Fase 5 / Governança Multi-Feiras e Controle de Acesso (Regra BR-23 e BR-24)  
**Objetivo:** Eliminar o papel legado de "Administrador" no CRUD de participantes, centralizar a gestão de administradores do evento na Equipe da Feira e blindar o papel de Apoio (`OPERATOR`) contra acessos indevidos a cadastros e alocações manuais.

---

## 1. Contexto e Motivação

Com a implementação da governança administrativa descentralizada por evento (Regra BR-23 e BR-24), a indicação de membros da comissão organizadora e suporte passou a ser realizada na tabela `event_administrators`, com três níveis bem definidos:
1. **Coordenador Geral / Dono (`COORDINATOR`):** Posse plena do evento, configuração de regras, exclusão e delegação de equipe.
2. **Comissão Organizadora (`ORGANIZER`):** Homologação de projetos, gestão de áreas/subáreas, critérios de avaliação, premiações, notas e alocações de jurados.
3. **Apoio / Recepção (`OPERATOR`):** Operação de portaria/credenciamento geral, entrega de kits de camisetas e check-in presencial de avaliadores na sala de avaliação, além de leitura das métricas consolidadas na Visão Geral.

### Problemas Detectados na Versão Anterior:
* **Mistura de conceitos:** O formulário de cadastro/edição de participantes em `/participants` mantinha a opção de selecionar "Administrador". Isso gerava confusão entre quem é participante da feira e quem faz parte da equipe de governança.
* **Vazamento de privilégios para perfil de Apoio (`OPERATOR`):**
  * O operador conseguia clicar no botão "+ Cadastrar Jurado" (na Visão Geral) e acessar a tela de gestão de participantes (`/participants`), podendo alterar dados cadastrais.
  * O operador conseguia clicar em "Alocar" (no diagnóstico de trabalhos críticos 4A) e submeter alocações manuais de jurados.
  * Os endpoints `GET /participants`, `POST /allocations/manual` e `DELETE /allocations/{id}` no backend não bloqueavam requisições feitas por usuários com perfil `OPERATOR`.

---

## 2. Decisões Arquiteturais e Regras de Negócio

### Regra 1: Separação Estrita de Domínio (Participantes vs. Equipe)
1. **Participantes (`EventParticipant` / `EventParticipantRole`):**
   * Uma pessoa inscrita na feira pode desempenhar exclusivamente os papéis:
     * `STUDENT` (Estudante / Autor)
     * `ADVISOR` (Orientador)
     * `COADVISOR` (Coorientador)
     * `EVALUATOR` (Avaliador / Jurado Técnico)
   * O papel `ADMIN` foi **definitivamente removido** da interface de cadastro/edição e dos filtros de participantes.
   * Tentativas de enviar `role: "ADMIN"` na API de participantes (`POST /participants` ou `PATCH /participants/{id}`) resultam em **HTTP 400 Bad Request**.

2. **Equipe Administrativa da Feira (`event_administrators`):**
   * A indicação e delegação de administradores é centralizada **exclusivamente no modal de Equipe da Feira**, acessível:
     * No card da feira em **Edições do Evento** (`/events`).
     * No cabeçalho da **Visão Geral** (`/`), ao lado do identificador do evento ativo.
   * Apenas o **Coordenador Geral / Dono (`COORDINATOR`)** pode abrir o modal de equipe para convidar, alterar papéis ou revogar membros.

---

## 3. Matriz Estrita de Permissões (RBAC)

| Módulo / Funcionalidade | Endpoint Backend | Nível Mínimo Exigido | Comportamento para Apoio (`OPERATOR`) |
|---|---|---|---|
| **Visão Geral / KPIs** | `GET /dashboard/admin-overview` | `OPERATOR` | Acesso permitido (somente leitura). |
| **Credenciamento Geral & Kits** | `/logistics/*` | `OPERATOR` | Acesso permitido (leitura de código de barras e baixa de kit). |
| **Check-in Presencial de Avaliadores** | `/allocations/evaluators/scan-checkin`<br>`GET /allocations/evaluators` | `OPERATOR` | Acesso permitido (crachá de jurado e seleção manual de jurado). |
| **Gestão de Participantes** | `/participants` (todos) | `ORGANIZER` | **Bloqueado.** Frontend oculta links/botões e exibe tela de Acesso Restrito; API retorna **403 Forbidden**. |
| **Alocação Manual de Jurados** | `POST /allocations/manual`<br>`DELETE /allocations/{id}` | `ORGANIZER` | **Bloqueado.** Botão "Alocar" em Trabalhos Críticos (4A) fica oculto; API retorna **403 Forbidden**. |
| **Auto-Balanceamento de Jurados** | `POST /allocations/auto-balance` | `ORGANIZER` | **Bloqueado.** Botão "Rebalancear Sistema" fica oculto na barra rápida; API retorna **403 Forbidden**. |
| **Qualificação de Subáreas de Jurados** | `POST /allocations/qualify` | `ORGANIZER` | **Bloqueado.** API retorna **403 Forbidden**. |
| **Homologação de Projetos** | `/projects` (mutações) | `ORGANIZER` | **Bloqueado.** Menu e tela restritos; API retorna **403 Forbidden**. |
| **Critérios, Áreas e Prêmios** | `/criteria`, `/areas`, `/awards` | `ORGANIZER` | **Bloqueado.** Menu e telas restritos; API retorna **403 Forbidden**. |
| **Gestão da Equipe da Feira** | `/events/{id}/admins` | `COORDINATOR` | **Bloqueado.** Botão de equipe invisível; API retorna **403 Forbidden**. |

---

## 4. Impactos na Interface (Frontend)

1. **Visão Geral (`/`):**
   * Coordenadores Gerais visualizam o botão **"Equipe"** no cabeçalho da edição ativa.
   * Se o usuário logado for `OPERATOR`:
     * Os botões "+ Cadastrar Jurado" no rodapé dos cards de Grandes Áreas são omitidos.
     * O botão "Alocar" e a coluna de ação no widget de Trabalhos Críticos (4A) são omitidos.
     * Os botões "Rebalancear Sistema" e "+ Cadastrar Novo Avaliador" na barra de ações rápidas são omitidos.
2. **Guarda de Rotas (`RequireActiveEvent`):**
   * Aceita propriedade `minRole`. Caso um operador tente digitar a URL `/participants` ou `/evaluators`, é renderizada uma tela estilizada de **Acesso Restrito**, informando que a operação exige perfil de Comissão Organizadora ou Coordenação Geral.
3. **Check-in de Avaliadores (`/evaluators/checkin`):**
   * A lista para seleção manual passa a ser carregada via `allocationService.getEvaluators(eventId)` (que é acessível por operadores para fins de credenciamento na sala de jurados), desacoplando totalmente do módulo restrito de participantes.
