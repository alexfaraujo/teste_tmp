# Documentação Técnica: Infraestrutura de Projetos (Energia e Mesa de Protótipo), Edição Cadastral e Modelo CSV Dinâmico por Edição — EasyEvent

**Data:** 14 de Setembro de 2026  
**Status:** Implementado & Validado  
**Regras de Referência:** Regra BR-04 (Configuração de Níveis e Cotas de Estudantes), Regra BR-08 (Alocação de Estande e Apresentação Presencial) e Regra BR-28 (Infraestrutura de Projetos e CSV Dinâmico por Edição)  
**Módulos Impactados:** `apps/backend` (Modelo Project, DDL Lifespan, Schemas, Services, Endpoints de Projetos e CSV, Testes), `apps/frontend-admin` (Types, Services, Parser CSV, Modal de Importação, Tela de Projetos e Otimização da Tabela de Participantes), `docs` (`database.md`, `context.md`, `048_infraestrutura_projetos_energia_mesa_csv_dinamico.md`).

---

## 1. Contexto e Motivação

Durante a organização do pavilhão de exposições de uma feira científica ou mostra de inovação tecnológica, a distribuição espacial dos estandes exige um planejamento logístico prévio de infraestrutura física. Dois fatores são especialmente críticos:
1. **Ponto de Energia Elétrica (Tomada):** Projetos que envolvem robótica, eletrônica, computadores, motores, iluminação especial ou instrumentação requerem pontos de tomada próximos ao estande.
2. **Mesa/Bancada para Protótipo:** Trabalhos experimentais e tecnológicos que apresentam protótipos físicos, maquetes ou aparatos volumosos necessitam de mesas de apoio no estande, enquanto trabalhos puramente teóricos ou expositivos utilizam apenas painéis/pôsteres.

Anteriormente, o sistema EasyEvent não previa o registro nem a gestão dessas duas necessidades. Além disso:
* A edição dos dados de um trabalho científico já submetido (título, nível, subárea, estande e resumo) no painel do administrador era limitada.
* O arquivo modelo de importação em lote (`template.csv`) possuía um número estático e arbitrário de autores (3 alunos), desconsiderando que cada edição da feira pode configurar tetos distintos de estudantes por nível de ensino (`max_students` na tabela `education_levels`).
* Na tela de gerenciamento de participantes (`/participants`), a última coluna de ações apresentava estouro visual gerando barra de rolagem horizontal desnecessária.

---

## 2. Modelagem de Dados e Persistência (Regra BR-28)

### 2.1 Alterações na Tabela `projects`
Foram adicionados dois novos campos booleanos na tabela `projects`:
* `needs_electricity`: `BOOLEAN NOT NULL DEFAULT FALSE` — Indica se o trabalho necessita de tomada de energia elétrica no estande.
* `needs_table`: `BOOLEAN NOT NULL DEFAULT FALSE` — Indica se o trabalho necessita de mesa/bancada para protótipo.

### 2.2 Migração Idempotente no Lifespan da Aplicação
Em `apps/backend/app/main.py`, foi inserido DDL idempotente executado no arranque do backend:
```sql
ALTER TABLE projects 
  ADD COLUMN IF NOT EXISTS needs_electricity BOOLEAN NOT NULL DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS needs_table BOOLEAN NOT NULL DEFAULT FALSE;
```

---

## 3. Modelo CSV Dinâmico por Edição de Evento

### 3.1 Consulta de Cotas de Estudantes (`EducationLevel`)
O endpoint `GET /api/v1/projects/template-csv?event_id={id}` calcula dinamicamente o maior número de estudantes permitido entre os níveis de ensino configurados para a edição ativa:
$$\text{num\_students} = \max\limits_{l \in \text{EducationLevel}(event\_id)} (l.\text{max\_students})$$
*(com fallback para 5 caso o evento ainda não possua níveis cadastrados)*.

### 3.2 Estrutura do Cabeçalho CSV Gerado, Tamanho de Camisetas e Desambiguação de Subáreas
O cabeçalho do arquivo `.csv` codificado em UTF-8 com BOM (delimitador `;`) é construído com as colunas essenciais, tamanho de camiseta para cada integrante e as colunas dinâmicas de autores ($1 \dots N$):
```csv
titulo;tipo;nivel;area_subarea;estande;ponto_energia;mesa_prototipo;resumo;orientador_nome;orientador_email;orientador_camiseta;coorientador_nome;coorientador_email;coorientador_camiseta;autor1_nome;autor1_email;autor1_camiseta;...;autorN_nome;autorN_email;autorN_camiseta
```

#### Colunas de Tamanho de Camiseta (`orientador_camiseta`, `coorientador_camiseta`, `autor{i}_camiseta`):
* Permite cadastrar ou atualizar o tamanho da camiseta diretamente na importação do trabalho científico (`event_participants.tshirt_size`).
* Valores válidos aceitos: `PP`, `P`, `M`, `G`, `GG`, `XG` (normalizados automaticamente para maiúsculas).
* Caso a coluna seja omitida ou esteja vazia, adota-se o padrão seguro `"M"`.
* Se o participante já estiver cadastrado no evento, o seu tamanho de camiseta é atualizado atomicamente caso venha preenchido no CSV.

#### Desambiguação via Notação Hierárquica em Pares (`Área -> Subárea`):
Para eliminar qualquer conflito quando grandes áreas distintas possuírem subáreas homônimas (ex: *"Informática"* sob *"Ciências Exatas"* e *"Informática"* sob *"Ciências Sociais Aplicadas"*):
* A coluna `area_subarea` é gerada no modelo oficial e aceita na importação no formato `Área -> Subárea` (ou `Área > Subárea` / `Área: Subárea`).
* Tanto o backend quanto o frontend constroem mapas compostos `(norm(area_name), norm(subarea_name)) -> Subarea`, resolvendo com 100% de exatidão o ID da subárea.
* Se o usuário preencher apenas o nome simples da subárea e este nome existir em mais de uma grande área, o sistema emite um erro explícito impeditivo (`HTTP 400 Bad Request`):
  > *"A subárea '{subarea}' informada para o trabalho '{titulo}' é ambígua, pois pertence a mais de uma grande área: '{area1}', '{area2}'. Por favor, especifique no formato 'Área -> Subárea'."*

### 3.3 Parsing e Normalização de Respostas Booleanas
Tanto o backend Python quanto o utilitário frontend TypeScript foram atualizados para aceitar variações textuais comuns de usuários em `ponto_energia` e `mesa_prototipo`:
* **Afirmativo (`True`):** `"sim"`, `"s"`, `"1"`, `"true"`, `"yes"`, `"y"`.
* **Negativo (`False`):** `"não"`, `"nao"`, `"n"`, `"0"`, `"false"`, `""` (vazio).

A iteração sobre as colunas de autores ocorre em loop numérico estrito $i = 1 \dots 20$, garantindo que `"autor10_nome"` não seja processado antes de `"autor2_nome"`, preservando a ordem cronológica de autoria da equipe.

---

## 4. Atualizações na Interface do Usuário (Frontend Admin)

### 4.1 Tela de Gestão de Trabalhos Científicos (`/projects`)
1. **Coluna do Título com Badges de Infraestrutura:**
   * Abaixo do título do trabalho e ao lado da etiqueta de tipo (`Científico` ou `Tecnológico`), são exibidos badges informativos:
     * `⚡ Tomada: Sim` (âmbar com ícone Zap) ou `⚡ Tomada: Não` (cinza discreto).
     * `🪑 Mesa: Sim` (azul com ícone Box) ou `🪑 Mesa: Não` (cinza discreto).
2. **Edição Completa do Trabalho (Ação Rápida):**
   * Novo botão com ícone de lápis (`Edit2`) na coluna de ações.
   * Abre o **Modal de Edição de Dados do Trabalho Científico**, permitindo alterar:
     * Título do trabalho;
     * Tipo do projeto (`SCIENTIFIC` / `TECHNOLOGICAL`);
     * Nível de ensino (`JUNIOR`, `FUNDAMENTAL`, `MEDIO`, `GRADUACAO`, `POS_GRADUACAO`);
     * Subárea temática (agrupada por Grande Área);
     * Número/identificação do estande;
     * Checkboxes de necessidades de infraestrutura (energia e mesa);
     * Resumo/Abstract do trabalho.
3. **Modal de Detalhes do Projeto:**
   * Card dedicado de **"Infraestrutura para Apresentação"** apresentando o status detalhado dos pontos de energia e bancada de protótipo.
4. **Download Dinâmico do Modelo CSV:**
   * O botão "Baixar Modelo CSV" na listagem e dentro da modal de importação consome diretamente a rota do backend com fallback client-side seguro.
5. **Pré-visualização da Importação em Lote:**
   * A tabela de conferência do CSV exibe chips de `⚡ Energia` e `🪑 Mesa` para os projetos que assinalarem necessidade.

### 4.2 Ajuste na Tela de Gestão de Participantes (`/participants`)
Para sanar o problema de estouro de largura e barra de rolagem horizontal desnecessária:
* **Fusão de Colunas:** A coluna "Crachá" (que ocupava 120px apenas para exibir a string do código de barras) foi eliminada como coluna isolada. O código de barras (`BC-XXXXX`) foi incorporado com destaque visual monoespaçado na coluna "Documento & Vínculo", logo abaixo do CPF e afiliação.
* **Otimização de Espaçamento:** Ajustado o padding horizontal das células de `px-4` para `px-3`/`px-2` e o espaçamento dos botões de ação para `gap-1`, garantindo visualização 100% fluida em telas de 1280px e 1366px sem gerar scrollbar horizontal.

---

## 5. Endpoints Criados e Atualizados

| Método | Rota | Descrição |
| :--- | :--- | :--- |
| `PUT` | `/api/v1/projects/{project_id}` | Atualização cadastral soberana de um trabalho científico pelo administrador. |
| `GET` | `/api/v1/projects/template-csv?event_id={id}` | Geração e download do CSV dinâmico com $N$ colunas de autores e campos de infraestrutura. |
| `POST` | `/api/v1/projects/upload-csv` | Importação em lote com persistência de `needs_electricity` e `needs_table` na criação e upsert. |

---

## 6. Verificação e Testes Automatizados

1. **Testes Unitários e de Integração no Backend:**
   * `apps/backend/tests/test_projects_csv.py`:
     * `test_generate_template_csv_dynamic_students`: Validação da geração de $N$ colunas de autores conforme cota máxima de nível de ensino e presença das colunas `ponto_energia` e `mesa_prototipo`.
     * `test_upload_projects_csv_with_infrastructure_fields`: Validação da persistência no banco e na API dos campos de infraestrutura via upload CSV.
   * `pytest tests/test_projects_csv.py tests/test_phase2.py tests/test_phase3.py`: **15/15 testes aprovados com 100% de sucesso.**
2. **Compilação e Verificação do Frontend:**
   * `npm run build` em `apps/frontend-admin`: compilação executada com sucesso, zero erros de tipos TypeScript e 18 rotas estáticas pré-renderizadas.
