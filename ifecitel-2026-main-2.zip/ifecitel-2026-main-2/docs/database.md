# Documentação Técnica: Especificação do Banco de Dados Relacional (PostgreSQL) — EasyEvent

## 1. Mecanismo de Banco de Dados e Arquitetura

O sistema EasyEvent utiliza uma instância local nativa (*bare-metal*) do **PostgreSQL 15+**.

### Justificativas Arquiteturais:
1.  **Integridade Referencial Estrita (ACID):** Invariantes relacionais complexas: isolamento multi-evento, emparelhamento de subáreas entre avaliadores e projetos, dependência formal de anuência do orientador e regras atômicas de entrega de kits.
2.  **Consultas Analíticas em Tempo Real:** Alto desempenho durante os horários de pico da feira mediante o uso de índices compostos e parciais (`WHERE deleted_at IS NULL`).
3.  **Soft Delete Universal:** Todas as tabelas contêm a coluna `deleted_at: Optional[datetime] = None`, garantindo 100% de rastreabilidade e histórico, sendo proibida qualquer exclusão física (*hard delete*).

---

## 2. Diagrama Entidade-Relacionamento (ERD - Mermaid)

```mermaid
erDiagram
    events {
        int id PK
        int owner_id FK "Criador / Coordenador Geral (BR-23)"
        varchar name
        int year
        text description
        int max_projects
        int workload_hours
        varchar location
        date start_date
        date end_date
        varchar status "OPEN, CLOSED"
        varchar summary_extension "pdf, docx"
        varchar banner_extension "pdf, pptx"
        int max_file_size_mb
        int max_projects_per_evaluator
        varchar organizing_institution
        varchar theme
        varchar contact_email
        varchar website_url
        varchar logo_url
        timestamp deleted_at
    }

    event_administrators {
        int id PK
        int event_id FK
        int person_id FK
        varchar role "COORDINATOR, ORGANIZER, OPERATOR"
        timestamp created_at
        timestamp updated_at
        timestamp deleted_at
    }

    registration_verifications {
        int id PK
        varchar email
        varchar code_hash
        int attempts
        boolean verified
        timestamp expires_at
        timestamp created_at
        timestamp updated_at
    }

    event_stages {
        int id PK
        int event_id FK
        varchar name "submission, consent, homologation, checkin, evaluation"
        date start_date
        date end_date
        timestamp deleted_at
    }

    education_levels {
        int id PK
        int event_id FK
        varchar level_name "MEDIO, FUNDAMENTAL, JUNIOR, GRADUACAO, POS_GRADUACAO"
        int max_students
        int min_evaluators
        timestamp deleted_at
    }

    schools {
        int id PK
        varchar name
        varchar city
        varchar state
        timestamp deleted_at
    }

    knowledge_areas {
        int id PK
        int event_id FK
        varchar name "Exatas, Biológicas, Engenharias..."
        timestamp deleted_at
    }

    sub_areas {
        int id PK
        int area_id FK
        varchar name
        timestamp deleted_at
    }

    awards {
        int id PK
        int event_id FK
        varchar name
        text description
        varchar sponsor
        timestamp created_at
        timestamp updated_at
        timestamp deleted_at
    }

    award_criteria {
        int id PK
        int award_id FK
        int criterion_id FK
        decimal weight
        timestamp created_at
        timestamp deleted_at
    }

    people {
        int id PK
        varchar name
        varchar email UNIQUE
        varchar cpf "Opcional (14 chars)"
        varchar affiliation "Perfil institucional (ex: Aluno IFMS, Aluno Externo)"
        varchar password_hash "Para organizadores / administradores de feira"
        varchar access_code_hash "Para PARTICIPANTES (OTP 8 chars)"
        varchar barcode UNIQUE
        varchar role "STUDENT, ADVISOR, COADVISOR, EVALUATOR (Admin gerido exclusivamente via event_administrators)"
        timestamp deleted_at
    }

    event_participant_roles {
        int id PK
        int person_id FK
        int event_id FK
        varchar role "STUDENT, ADVISOR, COADVISOR, EVALUATOR (Papel ADMIN removido - Doc 039)"
        timestamp created_at
        timestamp updated_at
        timestamp deleted_at
    }


    event_participants {
        int id PK
        int event_id FK
        int person_id FK
        varchar tshirt_size "PP, P, M, G, GG, XG"
        boolean kit_delivered
        timestamp kit_delivered_at
        boolean presence_confirmed
        timestamp presence_confirmed_at
        boolean evaluator_presence_confirmed
        timestamp evaluator_presence_confirmed_at
        timestamp deleted_at
    }

    person_subareas {
        int id PK
        int person_id FK
        int subarea_id FK
        int event_id FK
        timestamp deleted_at
    }

    person_education_levels {
        int id PK
        int person_id FK
        int event_id FK
        varchar education_level "MEDIO, FUNDAMENTAL, JUNIOR, GRADUACAO, POS_GRADUACAO"
        timestamp created_at
        timestamp updated_at
        timestamp deleted_at
    }

    projects {
        int id PK
        int event_id FK
        int school_id FK
        int level_id FK
        int subarea_id FK
        varchar title
        varchar project_type "SCIENTIFIC, TECHNOLOGICAL"
        text abstract
        varchar booth_number
        varchar summary_file_url
        varchar banner_file_url
        varchar logbook_file_url
        varchar qrcode_token UNIQUE
        varchar status "DRAFT, SUBMITTED, WAITING_CONSENT, HOMOLOGATED, PRESENT, ABSENT, UNDER_EVALUATION, EVALUATED"
        boolean advisor_consent
        timestamp advisor_consent_at
        text rejection_reason
        boolean needs_electricity
        boolean needs_table
        timestamp deleted_at
    }

    project_members {
        int id PK
        int project_id FK
        int person_id FK
        varchar role "STUDENT_LEADER, STUDENT_MEMBER, ADVISOR, COADVISOR"
        timestamp deleted_at
    }

    evaluator_allocations {
        int id PK
        int event_id FK
        int project_id FK
        int evaluator_id FK
        varchar allocation_type "AUTOMATIC_CHECKIN, MANUAL_ADMIN"
        varchar status "PENDING, COMPLETED, CANCELLED"
        timestamp allocated_at
        timestamp deleted_at
    }

    evaluation_criteria {
        int id PK
        int event_id FK
        text scientific_description
        text technological_description
        decimal max_score
        decimal weight
        timestamp deleted_at
    }

    evaluations {
        int id PK
        int allocation_id FK
        int project_id FK
        int evaluator_id FK
        text general_feedback
        varchar status "DRAFT, COMPLETED"
        timestamp evaluated_at
        timestamp deleted_at
    }

    evaluation_items {
        int id PK
        int evaluation_id FK
        int criterion_id FK
        decimal score
        timestamp deleted_at
    }

    snack_moments {
        int id PK
        int event_id FK
        varchar name
        date date
        varchar start_time
        varchar end_time
        boolean is_active
        varchar target_roles "ALL, STUDENT, ADVISOR, EVALUATOR..."
        int total_budgeted
        text notes
        timestamp created_at
        timestamp updated_at
        timestamp deleted_at
    }

    snack_deliveries {
        int id PK
        int snack_moment_id FK
        int participant_id FK
        int delivered_by_user_id FK
        timestamp delivered_at
        varchar notes
        timestamp created_at
        timestamp updated_at
        timestamp deleted_at
    }

    events ||--o{ event_stages : "configura"
    events ||--o{ education_levels : "define"
    events ||--o{ projects : "hospeda"
    events ||--o{ evaluation_criteria : "utiliza"
    events ||--o{ event_participants : "inscreve"
    events ||--o{ evaluator_allocations : "gerencia"
    events ||--o{ knowledge_areas : "define_areas"
    events ||--o{ awards : "concede"
    events ||--o{ snack_moments : "oferece_lanches"
    schools ||--o{ projects : "origina"
    education_levels ||--o{ projects : "classifica"
    knowledge_areas ||--o{ sub_areas : "contem"
    sub_areas ||--o{ projects : "categoriza"
    sub_areas ||--o{ person_subareas : "qualifica"
    awards ||--o{ award_criteria : "especifica"
    evaluation_criteria ||--o{ award_criteria : "qualifica_para"
    people ||--o{ event_participant_roles : "possui_papeis"
    events ||--o{ event_participant_roles : "atribui_papeis"
    people ||--o{ events : "cria_e_coordena"
    events ||--o{ event_administrators : "equipe_gestora"
    people ||--o{ event_administrators : "atua_como_gestor"

    people ||--o{ event_participants : "participa_como"
    people ||--o{ person_subareas : "especialista_em"
    people ||--o{ person_education_levels : "habilita_niveis"
    events ||--o{ person_education_levels : "restringe_niveis"
    people ||--o{ project_members : "integra"
    projects ||--o{ project_members : "composto_por"
    projects ||--o{ evaluator_allocations : "recebe_alocacao"
    people ||--o{ evaluator_allocations : "avaliador_designado"
    evaluator_allocations ||--o{ evaluations : "gera"
    projects ||--o{ evaluations : "avaliado_em"
    evaluations ||--o{ evaluation_items : "contem_notas"
    evaluation_criteria ||--o{ evaluation_items : "avalia"
    snack_moments ||--o{ snack_deliveries : "registra_entregas"
    event_participants ||--o{ snack_deliveries : "recebe_lanche"
    people ||--o{ snack_deliveries : "entrega_lanche"
```

---

## 3. Dicionário de Dados

### Tabela: `events`
Gerencia os dados mestres e parâmetros de configuração de cada edição independente da feira.
*   `id`: `SERIAL PRIMARY KEY`
*   `owner_id`: `INT NULL REFERENCES people(id)` — *Criador soberano e Coordenador Geral da edição (Regra BR-23). Possui controle total sobre configurações e permissões da feira.*
*   `name`: `VARCHAR(150) NOT NULL` (ex: "XII FECITEL Três Lagoas")
*   `year`: `INT NOT NULL`
*   `description`: `TEXT NULL`
*   `max_projects`: `INT NULL`
*   `workload_hours`: `INT NOT NULL`
*   `location`: `VARCHAR(150) NULL`
*   `start_date`: `DATE NOT NULL`
*   `end_date`: `DATE NOT NULL` — *Data de término definitivo. Ao expirar, todas as modificações no evento são travadas em modo leitura.*
*   `status`: `VARCHAR(20) NOT NULL DEFAULT 'OPEN'` — `'OPEN'`, `'CLOSED'`
*   `summary_extension`: `VARCHAR(10) NOT NULL DEFAULT 'pdf'` — `'pdf'` ou `'docx'`
*   `banner_extension`: `VARCHAR(10) NOT NULL DEFAULT 'pdf'` — `'pdf'` ou `'pptx'`
*   `max_file_size_mb`: `INT NOT NULL DEFAULT 20`
*   `max_projects_per_evaluator`: `INT NOT NULL DEFAULT 5`
*   `organizing_institution`: `VARCHAR(255) NULL` — *Instituição promotora ou organizadora oficial da feira (Ex: IFMS, UFMS, Secretaria Municipal de Educação).*
*   `theme`: `VARCHAR(255) NULL` — *Tema oficial da edição da feira científica (Ex: "Biomas do Brasil: diversidade, saberes e tecnologias sociais").*
*   `contact_email`: `VARCHAR(255) NULL` — *E-mail de contato oficial da Comissão Organizadora para dúvidas de participantes e avaliadores.*
*   `website_url`: `VARCHAR(500) NULL` — *URL externa do site oficial ou regulamento completo da feira.*
*   `logo_url`: `VARCHAR(500) NULL` — *URL ou caminho relativo da imagem do logotipo oficial da edição (ex: `/static/uploads/logos/logo_abc123.png` ou URL externa). Suporta imagens PNG e JPG/JPEG (máx. 5MB) enviadas via upload em `POST /events/upload-logo` ou `POST /events/{id}/logo`, salvas localmente em `storage/uploads/logos/` e renderizadas tanto no painel web quanto vetorizadas nos crachás impressos em PDF (ReportLab).*
*   `deleted_at`: `TIMESTAMP WITH TIME ZONE NULL`

### Tabela: `event_administrators` (Regra BR-23)
Controla a delegação de permissões e os níveis de governança de cada administrador em uma edição específica da feira.
*   `id`: `SERIAL PRIMARY KEY`
*   `event_id`: `INT NOT NULL REFERENCES events(id) ON DELETE CASCADE`
*   `person_id`: `INT NOT NULL REFERENCES people(id) ON DELETE CASCADE`
*   `role`: `VARCHAR(20) NOT NULL DEFAULT 'ORGANIZER'` — Nível hierárquico administrativo:
    *   `'COORDINATOR'`: Coordenador Geral / Dono (gestão total de regras, exclusão e equipe).
    *   `'ORGANIZER'`: Comissão Organizadora (gestão operacional: projetos, áreas, notas, alocação e apuração).
    *   `'OPERATOR'`: Apoio / Recepção (acesso restrito à Mesa de Credenciamento e Check-in de Avaliadores).
*   `created_at`: `TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()`
*   `updated_at`: `TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()`
*   `deleted_at`: `TIMESTAMP WITH TIME ZONE NULL`
*   *Restrição:* `UNIQUE(event_id, person_id)` (Uma pessoa possui apenas um papel administrativo ativo por feira).

### Tabela: `registration_verifications` (Regra BR-24)
Controle temporário de tokens OTP para auto-cadastro de novos organizadores de feiras via e-mail em duas etapas.
*   `id`: `SERIAL PRIMARY KEY`
*   `email`: `VARCHAR(100) NOT NULL` — *E-mail institucional ou pessoal do organizador solicitante.*
*   `code_hash`: `VARCHAR(255) NOT NULL` — *Hash criptográfico do código OTP seguro de 8 caracteres.*
*   `attempts`: `INTEGER NOT NULL DEFAULT 0` — *Contador de tentativas incorretas de verificação (bloqueia ao atingir 5).*
*   `verified`: `BOOLEAN NOT NULL DEFAULT FALSE` — *Indica se o código foi validado com sucesso e a conta ativada.*
*   `expires_at`: `TIMESTAMP WITH TIME ZONE NOT NULL` — *Data e hora limite de validade do código (15 minutos).*
*   `created_at`: `TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()`
*   `updated_at`: `TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()`

### Tabela: `event_stages`
Controla o cronograma e os prazos de cada fase do evento.
*   `id`: `SERIAL PRIMARY KEY`
*   `event_id`: `INT NOT NULL REFERENCES events(id)`
*   `name`: `VARCHAR(50) NOT NULL` — `'submission'`, `'consent'`, `'homologation'`, `'checkin'`, `'evaluation'`
*   `start_date`: `DATE NOT NULL`
*   `end_date`: `DATE NOT NULL`
*   `deleted_at`: `TIMESTAMP WITH TIME ZONE NULL`

### Tabela: `education_levels`
Regras e parâmetros por categoria de ensino em cada evento.
*   `id`: `SERIAL PRIMARY KEY`
*   `event_id`: `INT NOT NULL REFERENCES events(id)`
*   `level_name`: `VARCHAR(30) NOT NULL` — `'MEDIO'`, `'FUNDAMENTAL'` (Fundamental II), `'JUNIOR'` (Fundamental I), `'GRADUACAO'`, `'POS_GRADUACAO'`
*   `max_students`: `INT NOT NULL` — Fundamental I (5), Fundamental II (5), Médio (4), Graduação (5), Pós-Graduação (4)
*   `min_evaluators`: `INT NOT NULL DEFAULT 2`
*   `deleted_at`: `TIMESTAMP WITH TIME ZONE NULL`

### Tabela: `schools`
Instituições de ensino participantes da feira.
*   `id`: `SERIAL PRIMARY KEY`
*   `name`: `VARCHAR(200) NOT NULL`
*   `city`: `VARCHAR(100) NOT NULL`
*   `state`: `VARCHAR(2) NOT NULL`
*   `deleted_at`: `TIMESTAMP WITH TIME ZONE NULL`

### Tabela: `knowledge_areas`
Áreas do conhecimento gerenciadas no Painel do Administrador do Evento (ex: "Ciências Exatas e da Terra", "Ciências Biológicas", "Engenharias", "Humanas").
*   `id`: `SERIAL PRIMARY KEY`
*   `event_id`: `INT NOT NULL REFERENCES events(id)`
*   `name`: `VARCHAR(100) NOT NULL`
*   `description`: `TEXT NULL`
*   `created_at`: `TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()`
*   `updated_at`: `TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()`
*   `deleted_at`: `TIMESTAMP WITH TIME ZONE NULL`
*   *Restrição:* `UNIQUE(event_id, name)`
*   *Regra de Validação:* Não pode ser excluída se houver `sub_areas` ativas associadas.

### Tabela: `sub_areas`
Subáreas específicas vinculadas a uma área do conhecimento, gerenciadas no Painel do Administrador do Evento.
*   `id`: `SERIAL PRIMARY KEY`
*   `area_id`: `INT NOT NULL REFERENCES knowledge_areas(id)`
*   `name`: `VARCHAR(150) NOT NULL`
*   `description`: `TEXT NULL`
*   `created_at`: `TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()`
*   `updated_at`: `TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()`
*   `deleted_at`: `TIMESTAMP WITH TIME ZONE NULL`
*   *Restrição:* `UNIQUE(area_id, name)` — Impede nomes duplicados na mesma área.
*   *Regra de Validação:* Não pode ser excluída se estiver vinculada a qualquer projeto (`projects.subarea_id`) ou avaliador (`person_subareas.subarea_id`).

### Tabela: `awards`
Premiações especiais, troféus de parceiros e menções honrosas gerenciadas no Painel do Administrador do Evento.
*   `id`: `SERIAL PRIMARY KEY`
*   `event_id`: `INT NOT NULL REFERENCES events(id)`
*   `name`: `VARCHAR(150) NOT NULL` (ex: "Prêmio Inovação Tecnológica", "Prêmio Mulheres na Ciência")
*   `description`: `TEXT NULL`
*   `sponsor`: `VARCHAR(150) NULL` (ex: "SEBRAE", "Fundect", "IFMS")
*   `created_at`: `TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()`
*   `updated_at`: `TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()`
*   `deleted_at`: `TIMESTAMP WITH TIME ZONE NULL`
*   *Restrição:* `UNIQUE(event_id, name)`

### Tabela: `award_criteria`
Tabela associativa que vincula perguntas/itens da ficha de avaliação (`evaluation_criteria`) a um prêmio cadastrado.
*   `id`: `SERIAL PRIMARY KEY`
*   `award_id`: `INT NOT NULL REFERENCES awards(id)`
*   `criterion_id`: `INT NOT NULL REFERENCES evaluation_criteria(id)`
*   `weight`: `DECIMAL(5,2) NOT NULL DEFAULT 1.0` — Fator de ponderação da pergunta para o prêmio
*   `created_at`: `TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()`
*   `deleted_at`: `TIMESTAMP WITH TIME ZONE NULL`
*   *Restrição:* `UNIQUE(award_id, criterion_id)`

### Tabela: `people`
Cadastro unificado de participantes e usuários do sistema.
*   `id`: `SERIAL PRIMARY KEY`
*   `name`: `VARCHAR(150) NOT NULL`
*   `email`: `VARCHAR(100) NOT NULL UNIQUE`
*   `cpf`: `VARCHAR(20) NULL` — *Cadastro de Pessoa Física (CPF) para identificação única oficial e emissão de certificados.*
*   `affiliation`: `VARCHAR(100) NULL` — *Vínculo institucional ou perfil do participante (ex: 'Aluno IFMS', 'Aluno Externo', 'Público Externo').*
*   `password_hash`: `VARCHAR(255) NULL` — *Senha mestre criptografada para usuários ADMIN.*
*   `access_code_hash`: `VARCHAR(255) NULL` — *Hash criptografado do código OTP único de 8 caracteres para participantes.*
*   `barcode`: `VARCHAR(100) UNIQUE NULL` — *Código de barras individual impresso no crachá para credenciamento e retirada de kits.*
*   `deleted_at`: `TIMESTAMP WITH TIME ZONE NULL`

### Tabela: `event_participant_roles`
Associação multi-papel de participantes por edição do evento (Opção 1 aprovada). Permite que uma mesma pessoa exerça múltiplos papéis simultaneamente na mesma edição (ex: Orientador em um trabalho e Avaliador de outros trabalhos na feira, ou Coorientador e Avaliador).
*   `id`: `SERIAL PRIMARY KEY`
*   `person_id`: `INT NOT NULL REFERENCES people(id) ON DELETE CASCADE`
*   `event_id`: `INT NOT NULL REFERENCES events(id) ON DELETE CASCADE`
*   `role`: `VARCHAR(50) NOT NULL` — `'ADMIN'`, `'STUDENT'`, `'ADVISOR'`, `'COADVISOR'`, `'EVALUATOR'`
*   `created_at`: `TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()`
*   `updated_at`: `TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()`
*   `deleted_at`: `TIMESTAMP WITH TIME ZONE NULL`
*   *Restrição:* `CONSTRAINT uq_event_participant_role UNIQUE(person_id, event_id, role)`
*   *Índices:* `idx_epr_person_event (person_id, event_id) WHERE deleted_at IS NULL`, `idx_epr_event_role (event_id, role) WHERE deleted_at IS NULL`


### Tabela: `event_participants`
Rastreamento do credenciamento presencial e entrega de camisetas/kits por edição de evento.
*   `id`: `SERIAL PRIMARY KEY`
*   `event_id`: `INT NOT NULL REFERENCES events(id)`
*   `person_id`: `INT NOT NULL REFERENCES people(id)`
*   `tshirt_size`: `VARCHAR(5) NOT NULL` — `'PP'`, `'P'`, `'M'`, `'G'`, `'GG'`, `'XG'`
*   `kit_delivered`: `BOOLEAN NOT NULL DEFAULT FALSE`
*   `kit_delivered_at`: `TIMESTAMP WITH TIME ZONE NULL`
*   `presence_confirmed`: `BOOLEAN NOT NULL DEFAULT FALSE` (Presença geral na entrada/portaria da feira)
*   `presence_confirmed_at`: `TIMESTAMP WITH TIME ZONE NULL`
*   `evaluator_presence_confirmed`: `BOOLEAN NOT NULL DEFAULT FALSE` (Check-in específico na Sala dos Avaliadores)
*   `evaluator_presence_confirmed_at`: `TIMESTAMP WITH TIME ZONE NULL`
*   `deleted_at`: `TIMESTAMP WITH TIME ZONE NULL`
*   *Restrição:* `UNIQUE(event_id, person_id)`
*   *Regra de Negócio (BR-09 e BR-29):* Controla a baixa atômica de entrega de kits e camisetas. Base para a emissão de Cards de Kits em formato PDF (individual com etiquetas de 6 por folha A4 e coletivo por estande com 2 por folha A4 contendo Packing List e Checklist nominal), respeitando filtros de concessão orçamentária de camisetas por papel (Estudantes, Orientadores, Coorientadores e Avaliadores).

### Tabela: `person_subareas`
Vincula avaliadores às suas subáreas de conhecimento para distribuição balanceada e alocação manual (Regra BR-10).
*   `id`: `SERIAL PRIMARY KEY`
*   `person_id`: `INT NOT NULL REFERENCES people(id)`
*   `subarea_id`: `INT NOT NULL REFERENCES subareas(id)`
*   `event_id`: `INT NOT NULL REFERENCES events(id)`
*   `deleted_at`: `TIMESTAMP WITH TIME ZONE NULL`
*   *Restrição:* `UNIQUE(person_id, subarea_id, event_id)`
*   *Regra de Negócio (BR-10 e BR-26):* Mandatória tanto na distribuição dinâmica no check-in (Momento 1) quanto na atribuição/remanejamento manual pelo Administrador (Momento 2). Projetos com `projects.subarea_id` não correspondente às subáreas cadastradas do avaliador não podem ser alocados. Na importação em lote (BR-26), a vinculação em `person_subareas` é resolvida a partir de `subareas.id` considerando a hierarquia `knowledge_areas.name -> subareas.name`, prevenindo colisões quando subáreas homônimas coexistem sob grandes áreas distintas no mesmo evento.

### Tabela: `person_education_levels`
Qualifica e restringe os níveis de ensino (`MEDIO`, `FUNDAMENTAL`, `JUNIOR`, `GRADUACAO`, `POS_GRADUACAO`) que cada avaliador está habilitado a avaliar na edição ativa (Regra BR-25).
*   `id`: `SERIAL PRIMARY KEY`
*   `person_id`: `INT NOT NULL REFERENCES people(id) ON DELETE CASCADE`
*   `event_id`: `INT NOT NULL REFERENCES events(id) ON DELETE CASCADE`
*   `education_level`: `VARCHAR(20) NOT NULL` — `'MEDIO'`, `'FUNDAMENTAL'`, `'JUNIOR'`, `'GRADUACAO'`, `'POS_GRADUACAO'`
*   `created_at`: `TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()`
*   `updated_at`: `TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()`
*   `deleted_at`: `TIMESTAMP WITH TIME ZONE NULL`
*   *Restrição:* `CONSTRAINT uq_person_event_education_level UNIQUE(person_id, event_id, education_level)`
*   *Índices:* `idx_pel_person_event (person_id, event_id) WHERE deleted_at IS NULL`, `idx_pel_event_level (event_id, education_level) WHERE deleted_at IS NULL`
*   *Regra de Negócio (BR-25):* Caso o avaliador não possua registros vinculados para o evento ativo, o sistema o considera universal (habilitado a avaliar trabalhos de qualquer nível de ensino). Se houver um ou mais registros ativos, tanto o check-in dinâmico quanto o auto-balanceamento ($\Delta \le 1$) e a alocação manual restringem estritamente a distribuição aos níveis associados. Tentativas de alocação manual fora dos níveis configurados são bloqueadas com `HTTP 400 Bad Request`.

### Tabela: `projects`
Trabalhos de pesquisa submetidos à feira.
*   `id`: `SERIAL PRIMARY KEY`
*   `event_id`: `INT NOT NULL REFERENCES events(id)`
*   `school_id`: `INT NOT NULL REFERENCES schools(id)`
*   `level_id`: `INT NOT NULL REFERENCES education_levels(id)`
*   `subarea_id`: `INT NOT NULL REFERENCES sub_areas(id)`
*   `title`: `VARCHAR(255) NOT NULL`
*   `project_type`: `VARCHAR(20) NOT NULL` — `'SCIENTIFIC'`, `'TECHNOLOGICAL'`
*   `abstract`: `TEXT NOT NULL`
*   `booth_number`: `VARCHAR(20) NULL`
*   `summary_file_url`: `VARCHAR(500) NULL`
*   `banner_file_url`: `VARCHAR(500) NULL`
*   `logbook_file_url`: `VARCHAR(500) NULL`
*   `qrcode_token`: `VARCHAR(100) UNIQUE NOT NULL` — *Token único do QR Code afixado no estande de apresentação.*
*   `status`: `VARCHAR(30) NOT NULL DEFAULT 'DRAFT'`
*   `advisor_consent`: `BOOLEAN NOT NULL DEFAULT FALSE`
*   `advisor_consent_at`: `TIMESTAMP WITH TIME ZONE NULL`
*   `rejection_reason`: `TEXT NULL` — *Justificativa formal em caso de indeferimento (Regra BR-06).*
*   `needs_electricity`: `BOOLEAN NOT NULL DEFAULT FALSE` — *Indica se o trabalho necessita de ponto de energia elétrica (tomada) no estande.*
*   `needs_table`: `BOOLEAN NOT NULL DEFAULT FALSE` — *Indica se o trabalho necessita de mesa/bancada para o protótipo.*
*   `deleted_at`: `TIMESTAMP WITH TIME ZONE NULL`

### Tabela: `project_members`
Composição da equipe do projeto (alunos e orientadores).
*   `id`: `SERIAL PRIMARY KEY`
*   `project_id`: `INT NOT NULL REFERENCES projects(id)`
*   `person_id`: `INT NOT NULL REFERENCES people(id)`
*   `role`: `VARCHAR(20) NOT NULL` — `'STUDENT_LEADER'`, `'STUDENT_MEMBER'`, `'ADVISOR'`, `'COADVISOR'`
*   `deleted_at`: `TIMESTAMP WITH TIME ZONE NULL`
*   *Restrição:* `UNIQUE(project_id, person_id)`

### Tabela: `evaluator_allocations`
Registro das alocações de trabalhos para avaliadores (automática no check-in ou manual).
*   `id`: `SERIAL PRIMARY KEY`
*   `event_id`: `INT NOT NULL REFERENCES events(id)`
*   `project_id`: `INT NOT NULL REFERENCES projects(id)`
*   `evaluator_id`: `INT NOT NULL REFERENCES people(id)`
*   `allocation_type`: `VARCHAR(30) NOT NULL` — `'AUTOMATIC_CHECKIN'`, `'MANUAL_ADMIN'`
*   `status`: `VARCHAR(20) NOT NULL DEFAULT 'PENDING'` — `'PENDING'`, `'COMPLETED'`, `'CANCELLED'`
*   `allocated_at`: `TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP`
*   `deleted_at`: `TIMESTAMP WITH TIME ZONE NULL`
*   *Restrição:* `UNIQUE(project_id, evaluator_id)`

### Tabela: `evaluation_criteria`
Critérios e perguntas da ficha de notas por edição de evento (gerenciados no painel administrativo em `/criteria`).
*   `id`: `SERIAL PRIMARY KEY` — *Determina a ordem fixa e unificada da pergunta na ficha de avaliação mobile.*
*   `event_id`: `INT NOT NULL REFERENCES events(id)`
*   `name`: `VARCHAR(200) NOT NULL` — *Identificador / Título unificado do critério (ex: "Critério 1: Rigor Metodológico / Projeto de Engenharia").*
*   `scientific_description`: `TEXT NOT NULL` — *Pergunta e orientações de avaliação específicas para trabalhos do tipo Científico (`SCIENTIFIC`). O app mobile renderiza este texto automaticamente se o trabalho avaliado for científico.*
*   `technological_description`: `TEXT NOT NULL` — *Pergunta e orientações de avaliação específicas para trabalhos do tipo Tecnológico (`TECHNOLOGICAL`). O app mobile renderiza este texto automaticamente se o trabalho avaliado for tecnológico.*
*   `max_score`: `DECIMAL(5,2) NOT NULL DEFAULT 10.0` — *Pontuação máxima compartilhada entre ambas as formulações.*
*   `weight`: `DECIMAL(5,2) NOT NULL DEFAULT 1.0` — *Peso padrão compartilhado na ficha de avaliação.*
*   `deleted_at`: `TIMESTAMP WITH TIME ZONE NULL`
*   *Mecânica de Pergunta Dual / Unificada:* Cada linha da tabela corresponde a um item da ficha avaliativa. A ordem da pergunta, a pontuação máxima e o peso padrão são rigorosamente idênticos.
    *   *Eventos com distinção:* O backend seleciona em tempo de execução (`get_evaluation_sheet`) a pergunta correspondente com base no `project_type` do trabalho alocado.
    *   *Eventos com tipo único de trabalho:* Para eventos sem separação metodológica, todos os projetos concorrem sob o tipo `SCIENTIFIC` e o administrador marca a opção de tipo único no formulário de critérios, fazendo com que ambas as colunas (`scientific_description` e `technological_description`) sejam preenchidas com o mesmo texto da pergunta.
*   *Regra de Integridade:* Não pode ser excluído se já possuir notas registradas em `evaluation_items`. A desativação lógica também desvincula automaticamente registros em `award_criteria`.

### Tabela: `evaluations` (Mestre)
Cabeçalho da avaliação preenchida presencialmente pelo avaliador.
*   `id`: `SERIAL PRIMARY KEY`
*   `allocation_id`: `INT NOT NULL REFERENCES evaluator_allocations(id)`
*   `project_id`: `INT NOT NULL REFERENCES projects(id)`
*   `evaluator_id`: `INT NOT NULL REFERENCES people(id)`
*   `general_feedback`: `TEXT NULL` — *Parecer geral / observação consolidada única ao final da avaliação.*
*   `status`: `VARCHAR(20) NOT NULL DEFAULT 'COMPLETED'` — `'DRAFT'`, `'COMPLETED'`
*   `evaluated_at`: `TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP`
*   `deleted_at`: `TIMESTAMP WITH TIME ZONE NULL`
*   *Restrição:* `UNIQUE(project_id, evaluator_id)`

### Tabela: `evaluation_items` (Detalhe)
Notas numéricas individuais atribuídas por critério/pergunta da ficha.
*   `id`: `SERIAL PRIMARY KEY`
*   `evaluation_id`: `INT NOT NULL REFERENCES evaluations(id)`
*   `criterion_id`: `INT NOT NULL REFERENCES evaluation_criteria(id)`
*   `score`: `DECIMAL(5,2) NOT NULL`
*   `deleted_at`: `TIMESTAMP WITH TIME ZONE NULL`
*   *Restrição:* `UNIQUE(evaluation_id, criterion_id)`

### Tabela: `snack_moments`
Cadastro e parametrização de momentos de fornecimento de lanche/refeição por edição do evento (Regra BR-30).
*   `id`: `SERIAL PRIMARY KEY`
*   `event_id`: `INT NOT NULL REFERENCES events(id) ON DELETE CASCADE`
*   `name`: `VARCHAR(100) NOT NULL` — *Ex.: "Lanche da Tarde - Dia 1", "Coffee Break Avaliadores"*
*   `date`: `DATE NOT NULL` — *Data de fornecimento do lanche*
*   `start_time`: `VARCHAR(10) NULL` — *Ex.: "15:30"*
*   `end_time`: `VARCHAR(10) NULL` — *Ex.: "17:00"*
*   `is_active`: `BOOLEAN NOT NULL DEFAULT FALSE` — *Momento aberto para bipagem/distribuição na fila*
*   `target_roles`: `VARCHAR(255) NULL DEFAULT 'ALL'` — *Filtro de papéis autorizados (ex.: 'ALL', 'STUDENT,ADVISOR')*
*   `total_budgeted`: `INT NULL DEFAULT 0` — *Meta/quantidade estimada de lanches para controle de consumo*
*   `notes`: `TEXT NULL` — *Instruções ou observações logísticas*
*   `created_at`: `TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP`
*   `updated_at`: `TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP`
*   `deleted_at`: `TIMESTAMP WITH TIME ZONE NULL`
*   *Restrição:* `UNIQUE(event_id, name)`

### Tabela: `snack_deliveries`
Registro de entrega/baixa individual de lanche para participante, com trava estrita de unicidade (Regra BR-30).
*   `id`: `SERIAL PRIMARY KEY`
*   `snack_moment_id`: `INT NOT NULL REFERENCES snack_moments(id) ON DELETE CASCADE`
*   `participant_id`: `INT NOT NULL REFERENCES event_participants(id) ON DELETE CASCADE`
*   `delivered_by_user_id`: `INT NULL REFERENCES people(id) ON DELETE SET NULL` — *Operador que bipou a entrega*
*   `delivered_at`: `TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP`
*   `notes`: `VARCHAR(255) NULL`
*   `created_at`: `TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP`
*   `updated_at`: `TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP`
*   `deleted_at`: `TIMESTAMP WITH TIME ZONE NULL`
*   *Restrição:* `UNIQUE(snack_moment_id, participant_id)`

---

## 4. Índices Estratégicos de Alta Performance

```sql
-- Busca rápida por e-mail para autenticação
CREATE INDEX idx_people_email ON people(email) WHERE deleted_at IS NULL;

-- Busca rápida por CPF para credenciamento e emissão de certificados
CREATE INDEX idx_people_cpf ON people(cpf) WHERE deleted_at IS NULL;

-- Busca rápida por código de barras para recepção e baixa de kit
CREATE INDEX idx_people_barcode ON people(barcode) WHERE deleted_at IS NULL;

-- Verificação rápida de participação e status de kit
CREATE INDEX idx_event_partic_lookup ON event_participants(event_id, person_id) WHERE deleted_at IS NULL;

-- Leitura rápida do QR Code do estande pelos avaliadores
CREATE INDEX idx_projects_qrcode ON projects(qrcode_token) WHERE deleted_at IS NULL;

-- Indexação de subárea e status para algoritmo de balanceamento e dashboards
CREATE INDEX idx_projects_subarea_status ON projects(event_id, subarea_id, status) WHERE deleted_at IS NULL;
CREATE INDEX idx_knowledge_areas_event ON knowledge_areas(event_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_subareas_area ON sub_areas(area_id) WHERE deleted_at IS NULL;

-- Mapeamento de premiações e associação com critérios
CREATE INDEX idx_awards_event ON awards(event_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_award_criteria_lookup ON award_criteria(award_id, criterion_id) WHERE deleted_at IS NULL;

-- Consulta rápida de alocações de avaliadores
CREATE INDEX idx_allocations_lookup ON evaluator_allocations(project_id, evaluator_id, status) WHERE deleted_at IS NULL;

-- Agregação ultrarrápida para apuração e leaderboard em tempo real
CREATE INDEX idx_evaluations_project ON evaluations(project_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_eval_items_parent ON evaluation_items(evaluation_id) WHERE deleted_at IS NULL;

-- Validação rápida de tokens OTP para auto-cadastro de organizadores
CREATE INDEX idx_reg_verif_lookup ON registration_verifications(email, verified);

-- Busca rápida de momentos de lanches por evento
CREATE INDEX idx_snack_moments_event ON snack_moments(event_id, is_active) WHERE deleted_at IS NULL;

-- Verificação rápida de entregas de lanches e integridade de retirada
CREATE INDEX idx_snack_deliveries_lookup ON snack_deliveries(snack_moment_id, participant_id) WHERE deleted_at IS NULL;
```

---

## 5. Especificação de Códigos Ópticos (Códigos de Barras e QR Codes) e Rastreabilidade Operacional

O ecossistema EasyEvent integra tecnologias de captura óptica (Códigos de Barras 1D e QR Codes 2D) para garantir máxima velocidade operacional, integridade transacional e eliminação de digitação manual na portaria e no pavilhão de avaliação.

### 5.1 Tabela Geral de Códigos Ópticos do Sistema

| Elemento Óptico | Simbologia | Entidade & Coluna no Banco de Dados | Padrão / Formato do Valor | Onde Aparece no Sistema | Ação / O que Dispara ao Ser Lido |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Código de Barras do Participante** | Linear **Code128** | Tabela: `people`<br>Campo: `barcode`<br>`VARCHAR(100) UNIQUE NULL` | `BC-XXXXX`<br>*(ex: `BC-A8K2F` ou `BC-00042`)* | • **Crachás em PDF** (rodapé inferior central)<br>• **Cards Individuais de Kit em PDF** (rodapé inferior direito)<br>• Tela `/participants` (Admin - coluna Documento)<br>• Input óptico na tela `/logistics` (Portaria) | **Credenciamento & Retirada de Kit Individual:** Ao ser bipado com leitor óptico laser na recepção, registra a presença da pessoa física (`event_participants.presence_confirmed = True`) e a baixa do kit/camiseta (`kit_delivered = True`). Se o participante for autor de trabalho científico, dispara a **Presença Coletiva (Regra BR-08)**, promovendo o status do projeto para `PRESENT`. |
| **Código de Barras do Crachá (Lanches)** | Linear **Code128** | Tabela: `people`<br>Campo: `barcode`<br>`VARCHAR(100) UNIQUE NULL` | `BC-XXXXX`<br>*(ex: `BC-A8K2F` ou `BC-00042`)* | • **Crachás em PDF** (rodapé inferior central)<br>• Tela `/snacks/distribution` (Admin/Mobile) | **Controle e Retirada de Lanches (Regra BR-30):** Ao ser lido por leitor USB (OTG) ou câmera do celular, valida se o participante tem direito ao momento de lanche ativo e se já retirou. Se for a primeira leitura, registra a entrega com feedback sonoro verde. Se for tentativa duplicada, bloqueia e acusa horário da retirada anterior com alerta vermelho. |
| **QR Code do Perfil do Avaliador** | Bidimensional **QR Code (2D)** | Tabela: `people`<br>Campo: `barcode`<br>`VARCHAR(100) UNIQUE NULL` | `BC-XXXXX`<br>*(reutiliza o mesmo barcode pessoal)* | • App Mobile do Avaliador (tela **"Meu Perfil"**, exibido na tela do smartphone) | **Check-in de Avaliadores:** O avaliador apresenta a tela do celular na Sala dos Avaliadores. A recepção lê o QR Code em `/evaluators/checkin`, confirmando a presença do avaliador (`event_participants.evaluator_presence_confirmed = True`) e disparando a **alocação automática e balanceada de projetos** ($\Delta \le 1$). *(Utiliza QR Code 2D pois telas de smartphones têm leitura óptica superior em 2D frente a leitores a laser de código de barra linear).* |
| **QR Code da Bancada / Estande** | Bidimensional **QR Code (2D)** | Tabela: `projects`<br>Campo: `qrcode_token`<br>`VARCHAR(100) UNIQUE NOT NULL` | `FECITEL-2026-XXXXXXXXXXXXXXXX`<br>*(ou `ID Trabalho` numérico)* | • **Adesivo/Placa de Bancada em PDF** (impresso em folha A4 nos modelos A5 ou A6, com QR Code maximizado e sem número de estande, afixado na bancada física do projeto)<br>• Modal de Detalhes do Projeto em `/projects` (Admin) | **Abertura da Ficha Oficial de Avaliação:** O avaliador aponta a câmera do smartphone no app mobile (tela `/scan`) para a placa da bancada. O sistema valida se o avaliador está alocado para o trabalho, confere inexistência de conflito de interesses (escola/parentesco) e abre a **Ficha de Avaliação** (Científica ou Tecnológica) com notas de 0 a 10. |
| **Código do Pacote do Projeto (Card Coletivo)** | Linear **Code128** | Tabela: `projects`<br>Campo: `qrcode_token`<br>`VARCHAR(100) UNIQUE NOT NULL` | `FECITEL-2026-XXXXXXXXXXXXXXXX`<br>*(ou `PRJ-{id:05d}` em fallback)* | • Rodapé inferior esquerdo do **Card Coletivo de Kit por Projeto** (PDF impresso colado na sacola/caixa kraft) | **Retirada do Pacote do Estande por Qualquer Integrante:** O voluntário bipa a sacola kraft na tela `/logistics`. Como o código é padronizado com o estande (`projects.qrcode_token`), o sistema reconhece o projeto, promove o estande para `PRESENT` e permite com 1 clique (`POST /api/v1/logistics/project-kits/{id}/checkout`) a **baixa coletiva e atômica de todos os kits da equipe**. **Qualquer integrante do grupo (orientador, coorientador ou estudantes)** pode retirar o pacote completo na portaria. |

### 5.2 Regras de Negócio e Rastreabilidade Operacional
1. **Padronização Estrita do Pacote com o Estande:** O pacote coletivo de kits não fica vinculado a uma pessoa física específica (como o orientador). Seu código de barras impresso no card de identificação é exatamente o identificador único do trabalho/estande (`projects.qrcode_token`).
2. **Desacoplamento e Isonomia de Retirada:** Qualquer membro da equipe participante pode se apresentar na recepção da feira e retirar o pacote completo de kits e crachás de seu estande.
3. **Resolução Polimórfica de Leitura na Portaria:** O endpoint `POST /api/v1/logistics/scan-barcode` resolve transparentemente tanto códigos de participantes (`people.barcode`, CPF, e-mail) quanto códigos de estande/projeto (`projects.qrcode_token`, `booth_number`, `PRJ-{id}`).
4. **Baixa Atômica Coletiva:** A operação `POST /api/v1/logistics/project-kits/{project_id}/checkout` aplica baixa simultânea protegida por transação em todos os integrantes cadastrados em `event_participants`, evitando incongruências onde parte da equipe receba e outra parte fique pendente no mesmo estande.
5. **Adesivos de Bancada sem Número de Estande e com QR Code Maximizado:** Na emissão dos adesivos em PDF para a bancada física do projeto, os dados redundantes do banner (título, autores, escola, nível e instituição organizadora) e o número do estande são omitidos, permitindo a exibição do QR Code vetorial de alta definição com tamanho ampliado para leitura à distância de celulares.
