# Documentação Técnica: Geração Vetorial de Crachás em PDF (ReportLab) e Upload de Logotipos (PNG/JPG) — EasyEvent

**Data:** 13 de Setembro de 2026  
**Status:** Implementado & Validado  
**Regras de Referência:** Regra BR-05 (Identificação de Participantes), Regra BR-10 (Qualificação de Avaliadores), Regra BR-23 (Comissão Gestora) e Regra BR-27 (Geração Vetorial de Crachás em PDF)  
**Módulos Impactados:** `apps/backend` (ReportLab, Barcode Code128 Vetorial, Endpoints de Upload e Download de PDF, Testes), `apps/frontend-admin` (Upload com Preview PNG/JPG em Eventos, Ações de Download Individual e em Lote em Participantes), `docs` (`context.md`, `database.md`, `047_geracao_crachas_pdf_e_upload_logo.md`).

---

## 1. Contexto e Motivação

Durante a realização de feiras científicas e mostras acadêmicas, a emissão física de crachás é um processo crítico de credenciamento e logística. Os crachás cumprem três funções primordiais:
1. **Credenciamento e Presença Física:** Leitura rápida de código de barras no posto de recepção para confirmar presença e baixa individual de camisetas/kits.
2. **Identificação Visual no Pavilhão:** Permite a circulação de estudantes, orientadores, avaliadores e membros da organização com distinção clara de papéis e estandes.
3. **Avaliação no Estande:** Apresentação de dados do projeto científico aos avaliadores técnicos.

Anteriormente, o sistema não contava com gerador integrado de crachás prontos para impressão gráfica, exigindo esforços manuais externos de diagramação. Além disso, o logotipo do evento era informado apenas como URL textual, sem suporte a upload de arquivos de imagem locais.

---

## 2. A Solução Implementada (Opção 3 — Híbrida)

Foi implementada a **Opção 3 (Híbrida: Backend ReportLab + Frontend Admin)**, que garante:
* **Geração Server-Side com ReportLab:** Renderização vetorial precisa sem dependências de navegadores headless (evitando overhead de Chromium/Puppeteer).
* **Código de Barras Code128 Vetorial:** Desenhado diretamente no canvas do ReportLab com `reportlab.graphics.barcode.code128.Code128`, garantindo linhas nítidas para qualquer leitor óptico ou laser de código de barras.
* **Folha Padrão A4 com Grid 2x2 (4 Crachás por Página):**
  * Dimensão exata de cada crachá: $95\,\text{mm} \times 130\,\text{mm}$ (orientação retrato).
  * Linhas pontilhadas cinzas para facilitar o corte com guilhotina ou tesoura.
  * Marcador central de furo superior ($\varnothing 4\,\text{mm}$) para inserção de cordão ou presilha jacaré.
* **Upload Direto de Logotipo (PNG e JPG/JPEG):**
  * Cadastro e edição da feira com upload direto de arquivos de imagem de até 5MB.
  * Armazenamento local persistente em `storage/uploads/logos/` e exposição estática via `/static/uploads/...`.
  * Renderização instantânea nos crachás com resolução proporcional mantendo aspect ratio.

---

## 3. Estrutura do Crachá e Seções da Impressão em Lote

### 3.1 Anatomia Visual do Crachá e Otimização de Espaço
Cada crachá gerado contém:
1. **Cabeçalho com Logotipo ou Identificação do Evento:**
   * **Com Logotipo Cadastrado:** O logotipo oficial do evento ocupa **100% da largura superior do crachá** ($w = 260\,\text{pt}$), com altura dinâmica proporcional até $88\,\text{pt}$, ajustado aos cantos arredondados do topo da moldura do crachá via clipping path. Quando o logotipo está presente, **não são impressos o nome do evento e o local de realização**, garantindo máxima visibilidade e identidade visual à arte oficial da feira.
   * **Sem Logotipo Cadastrado (Fallback):** São impressos em destaque centralizado o **Nome do Evento** ($13.5\,\text{pt}$, negrito) e o **Local de Realização** (`event.location` ou `organizing_institution`, $9.0\,\text{pt}$), delimitados por divisória cinza.
   * **Furo de Presilha/Cordão:** Marcador circular pontilhado de furo central de cordão/presilha jacaré ($\varnothing 4.5\,\text{pt}$) posicionado a $13\,\text{pt}$ do topo, renderizado por cima da imagem para orientação precisa de furação física.
2. **Tarja de Papel Destacada:**
   * Faixa colorida horizontal com cantos arredondados (altura ampliada para $28\,\text{pt}$) indicando a função do participante:
     * **Estudante / Autor:** Azul Royal (`#1E40AF` / fundo `#DBEAFE`, $13\,\text{pt}$ negrito).
     * **Orientador:** Verde Esmeralda (`#065F46` / fundo `#D1FAE5`, $13\,\text{pt}$ negrito).
     * **Coorientador:** Ciano Escuro (`#0E7490` / fundo `#CFFAFE`, $13\,\text{pt}$ negrito).
     * **Avaliador:** Roxo (`#581C87` / fundo `#F3E8FF`, $13\,\text{pt}$ negrito).
     * **Equipe Organizadora / Apoio:** Terracota (`#9A3412` / fundo `#FFEDD5`, $11.5\,\text{pt}$ a $13\,\text{pt}$ negrito).
3. **Dados Pessoais e Vínculo Institucional:**
   * Nome completo em destaque máximo e **obrigatoriamente em caixa alta (UPPERCASE)** ($13.5\,\text{pt}$ a $19\,\text{pt}$, negrito).
   * **Quebra Dinâmica de Linha no Nome:** Nomes longos ou compostos que ultrapassem a largura útil do crachá ($232\,\text{pt}$) são automaticamente divididos em até 2 linhas balanceadas, evitando que preposições fiquem isoladas.
   * **Ajuste Proporcional da Caixa de Detalhes:** Quando o nome ocupar 2 linhas, o topo da caixa de detalhes é deslocado para baixo e sua altura é reduzida proporcionalmente na mesma medida, garantindo que o código de barras e os limites inferiores do crachá permaneçam estáveis sem estourar.
   * Instituição / Afiliação ($10.0\,\text{pt}$, negrito).
4. **Metadados Operacionais Contextuais (Box de Conteúdo):**
   * **Para Estudantes / Orientadores / Coorientadores:**
     * Número do Estande em destaque ($13.5\,\text{pt}$ negrito, ex: `"ESTANDE: B-04"`).
     * Subárea e Área temática ($10.5\,\text{pt}$ negrito em tom teal `#0D9488`).
     * Linha divisória interna sutil.
     * Título do Projeto de Pesquisa ($10\,\text{pt}$ com quebra dinâmica de texto em até 4 linhas sem corte abrupto).
   * **Para Avaliadores:**
     * Áreas e Subáreas de Avaliação ($11\,\text{pt}$ negrito com marcadores de tópicos a $9.5\,\text{pt}$).
     * Níveis de Ensino habilitados ($9.5\,\text{pt}$ negrito, ex: `"Níveis: Ensino Médio, Graduação"`).
   * **Para Equipe Organizadora:**
     * Função específica na feira ($13.5\,\text{pt}$ negrito, ex: `"Comissão Organizadora da Feira"`).
     * Informações de livre trânsito aos pavilhões e salas técnicas ($10\,\text{pt}$).
5. **Código de Barras Vetorial Code128:**
   * Código de barras padrão Code128 de alta legibilidade óptica com barras ampliadas para $36\,\text{pt}$ de altura.
   * Legenda alfanumérica inferior ampliada para $10.5\,\text{pt}$ em fonte monospace (`Courier-Bold`).

### 3.2 Seções do PDF de Exportação em Lote
Ao solicitar a exportação completa da feira, o documento agrupa os crachás em 3 seções cronológicas:
1. **Seção 1 — Trabalhos Científicos (Projetos):**
   * Agrupados projeto a projeto, ordenados pelo número de estande / ID do projeto.
   * Ordem dos membros do projeto: **Orientador $\rightarrow$ Coorientador (se houver) $\rightarrow$ Estudantes Autores**.
2. **Seção 2 — Equipe Organizadora:**
   * Coordenadores Gerais (`COORDINATOR`), membros da comissão (`ORGANIZER`) e operadores de credenciamento (`OPERATOR`).
3. **Seção 3 — Avaliadores Credenciados:**
   * Relação de todos os avaliadores vinculados à feira, com suas respectivas subáreas e níveis de ensino habilitados.

---

## 4. Endpoints no Backend (`apps/backend`)

### 4.1 Upload de Logotipo
* **`POST /api/v1/events/upload-logo` (Upload Temporário):**
  * Recebe `multipart/form-data` com parâmetro `file`.
  * Valida extensão (`.png`, `.jpg`, `.jpeg`) e tamanho ($\le 5\,\text{MB}$).
  * Grava em `storage/uploads/logos/logo_<uuid>.<ext>`.
  * Retorna `{"logo_url": "/static/uploads/logos/logo_<uuid>.<ext>"}`.
* **`POST /api/v1/events/{event_id}/logo` (Atualização Direta do Evento):**
  * Atualiza o campo `events.logo_url` no banco de dados para a edição ativa.
  * Exige papel mínimo `ORGANIZER`.

### 4.2 Geração de Crachás em PDF
* **`GET /api/v1/events/{event_id}/badges/pdf?filter=all|projects|evaluators|staff`:**
  * Gera o lote consolidado em folha A4 com 4 crachás por página.
  * Retorna `application/pdf` com cabeçalho `Content-Disposition: attachment; filename=crachas_evento_{id}_{filter}.pdf`.
* **`GET /api/v1/participants/{participant_id}/badge/pdf?event_id={event_id}`:**
  * Gera o PDF avulso contendo o crachá individual do participante selecionado posicionado no **primeiro quadrante (canto superior esquerdo)** da folha A4 com as linhas pontilhadas de corte da página inteira (como se existissem os 4 crachás), facilitando o corte com guilhotina e permitindo o reaproveitamento das demais partes da folha.
  * Retorna `application/pdf` com cabeçalho `Content-Disposition: attachment; filename=cracha_participante_{id}.pdf`.

---

## 5. Interface com o Usuário no Frontend (`apps/frontend-admin`)

### 5.1 Edições do Evento (`/events`)
* Modais de Criação e Edição contam com componente intuitivo de upload na aba **Identidade**:
  * Dropzone/botão com ícone `Upload` aceitando arquivos PNG ou JPG/JPEG até 5MB.
  * Pré-visualização instantânea do logotipo com suporte a rotas estáticas locais ou URLs remotas.
  * Ações de *Substituir Imagem* e *Remover Logotipo*.
* Cards de Edições exibem miniatura do logotipo no cabeçalho ao lado do título do evento.

### 5.2 Gestão de Participantes (`/participants`)
* **Botão Superior "Exportar Crachás (PDF)":**
  * Abre modal de confirmação com seleção de escopo:
    * *Todos os Crachás da Feira* (completo com as 3 seções);
    * *Apenas Trabalhos Científicos* (Orientadores + Coorientadores + Estudantes);
    * *Apenas Avaliadores Credenciados*;
    * *Apenas Equipe Organizadora e Apoio*.
  * Feedback visual de progresso com spinner animado durante a compilação do PDF.
* **Ação na Tabela de Participantes ("Imprimir Crachá"):**
  * Novo botão de ação com ícone de impressora (`Printer`) na coluna de ações de cada participante para download imediato do crachá avulso.

---

## 6. Verificação e Testes Automatizados

O módulo conta com suíte de testes de regressão no backend em [`tests/test_badges_pdf.py`](file:///Users/alexaraujo/Documents/Fecitel-Alex-Rogerio/apps/backend/tests/test_badges_pdf.py):
1. `test_upload_event_logo_png_and_jpg`:
   * Testa upload de arquivo PNG e JPG no endpoint `/events/upload-logo`.
   * Testa upload no endpoint `/events/{id}/logo`.
   * Valida rejeição com `HTTP 400` de arquivos com formato inválido (`.txt`).
2. `test_generate_badges_pdf_batch_and_individual`:
   * Cria evento com projetos, orientador, estudantes, avaliador e comissão organizadora.
   * Solicita o PDF em lote (`/events/{id}/badges/pdf?filter=all`).
   * Solicita o PDF individual (`/participants/{id}/badge/pdf`).
   * Valida cabeçalho mágico `%PDF-`, código `HTTP 200` e tamanho de bytes gerados $> 1\,\text{KB}$.

**Resultado dos Testes:** 53/53 testes automatizados passando com 100% de sucesso no pytest.  
**Compilação Frontend:** `npm run build` executado com código de saída 0 e todas as 18 rotas otimizadas estaticamente.
