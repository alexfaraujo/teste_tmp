# 023 — Módulo de Gerenciamento de Participantes e Atribuição de Papéis no Evento
**Data / Hora:** 11/09/2026 — 15h40  
**Autor:** Equipe Técnica FECITEL (Alex Araújo & Antigravity)  
**Status:** Aprovado e em Execução  

---

## 1. Contexto e Motivação

Durante os testes de homologação e credenciamento operacional da FECITEL com o dataset real da feira (edição **"Fecitel do Alex"**, 125 projetos e 449 participantes), o Gestor do Projeto (Alex Araújo) identificou a necessidade de um módulo administrativo soberano para **Gerenciamento de Participantes**.

### Problemas e Necessidades Identificadas:
1. **Inconsistências em Importações de Lote:** Planilhas e integrações de submissão (CSV/SUAP) frequentemente contêm erros de digitação de nomes, CPFs com formatação inválida, afiliações institucionais incompletas ou ausentes e tamanhos incorretos de camiseta.
2. **Entrada de Participantes Avulsos:** A necessidade de incluir no evento participantes que não constavam da planilha inicial — especialmente **avaliadores científicos e tecnológicos convidados**, coorientadores adicionados tardiamente ou estudantes remanejados.
3. **Atribuição e Reclassificação de Papéis:** Permitir ao Administrador alterar a função do participante no sistema (`STUDENT`, `ADVISOR`, `COADVISOR`, `EVALUATOR`, `ADMIN`) e, quando o papel for Avaliador, atribuir suas subáreas temáticas de conhecimento.
4. **Governança de Integridade (BR-16):** Impedir exclusões inadvertidas de pessoas que são autores ou orientadores ativos de projetos homologados.

---

## 2. Métricas de Esforço da Equipe

Em estrita conformidade com a Seção 1.3 de `.agents/rules.md`:

| Dimensão | Percentual | Descrição do Esforço |
| :--- | :---: | :--- |
| **Participação Humana** | **50%** | Identificação da ausência do módulo durante os testes operacionais, especificação dos casos de uso (correção de importações e novos cadastros), definição dos papéis permitidos e aprovação do plano de implementação. |
| **Trabalho Híbrido** | **35%** | Alinhamento da arquitetura técnica (relação `people` vs `event_participants`), integração com o contexto global de evento ativo (BR-19) e definição do padrão de paginação real (BR-18). |
| **Atuação Autônoma da IA** | **15%** | Criação de schemas Pydantic, service de regras de negócio, endpoints FastAPI, suite de testes automatizados `pytest` e desenvolvimento da página interativa Next.js em TypeScript. |

---

## 3. Especificação do Módulo de Participantes

### 3.1. Arquitetura de Dados e Relacionamentos
*   **`people`:** Registro cadastral global da pessoa (Nome, E-mail único, CPF, Afiliação, Senha/Hash de Acesso, Código de Barras e Papel Principal).
*   **`event_participants`:** Registro da participação da pessoa na edição específica do evento (ID do Evento, ID da Pessoa, Tamanho da Camiseta, Status e Data de Baixa do Kit, Confirmação de Presença Física e Data).
*   **`person_subareas`:** Subáreas de especialidade vinculadas caso a pessoa atue como avaliador na edição.

### 3.2. Funcionalidades do Backend (`/api/v1/participants`)
1.  **Listagem Paginada (`GET /api/v1/participants`):**
    *   Filtro obrigatório por `event_id`.
    *   Paginação real server-side (padrão 15 itens/página — Regra BR-18).
    *   Busca textual ampla via `ilike` por nome, e-mail, CPF ou código de barras.
    *   Filtros combinados por papel (`role`), presença confirmada e entrega de kit.
2.  **Detalhes do Participante (`GET /api/v1/participants/{person_id}`):**
    *   Retorna dados completos, contagem e títulos de projetos vinculados e subáreas qualificadas.
3.  **Criação de Participante (`POST /api/v1/participants`):**
    *   Verifica unicidade por e-mail; reaproveita pessoa existente no sistema ou cria novo registro.
    *   Gera automaticamente código de barras (`BC-XXXXX`) caso não informado.
    *   Cria ou reativa o vínculo em `event_participants`.
    *   Vincula subáreas de avaliação caso o papel seja `EVALUATOR`.
4.  **Atualização Cadastral (`PATCH /api/v1/participants/{person_id}`):**
    *   Edita dados pessoais (nome, e-mail, CPF, afiliação, papel).
    *   Edita dados de logística do evento (tamanho da camiseta, presença, kit).
5.  **Exclusão / Desvinculação (`DELETE /api/v1/participants/{person_id}`):**
    *   Valida se a pessoa integra equipes de projetos ativos (`project_members`). Se houver vínculos ativos, recusa com `HTTP 400 Bad Request` indicando os trabalhos.
    *   Aplica soft-delete no vínculo `event_participants`.

### 3.3. Interface no Painel Administrativo (`/participants`)
*   Protegida por `<RequireActiveEvent featureName="a Gestão de Participantes">` (Regra BR-19).
*   Cards de métricas instantâneas: Total de Participantes, Estudantes, Orientadores e Avaliadores.
*   Barra de busca com debounce (300ms) e filtros instantâneos.
*   Tabela rica com identificação visual por Badges coloridas de papéis.
*   Modais com tratamento de erros internos (Regra UX-01) para Novo Participante, Edição e Detalhes.
*   Controle de paginação real (15 itens por página) via componente `<Pagination>`.
