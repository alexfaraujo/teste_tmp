# Documentação Técnica: Contexto e Escopo do Sistema — EasyEvent

## 1. Visão Geral e Propósito
O **EasyEvent** é uma plataforma integrada de gestão e avaliação de feiras, congressos, mostras e eventos acadêmicos e científicos, voltada a incentivar a pesquisa e a inovação tecnológica entre estudantes de todos os níveis de ensino.

O sistema EasyEvent automatiza, centraliza e agiliza todo o ciclo de vida do evento:
*   **Pré-Evento:** Configuração multi-evento, cronograma dinâmico de etapas, submissão de trabalhos em equipe, fluxo de anuência do orientador e validação de participantes em lote.
*   **Durante o Evento (Logística e Avaliação):** Credenciamento presencial com leitor de código de barras no crachá individual, check-in do projeto em tempo real, entrega de camisetas/kits à prova de duplicidade, crachá de dupla identificação e avaliação digital ágil via QR Code fixado no estande.
*   **Pós-Evento e Apuração:** Totalização de notas por média aritmética simples sem descarte, dashboards gerenciais da coordenação e travamento temporal definitivo dos dados após o encerramento do evento.
*   **Engajamento Público na Feira:** Painel exclusivo para Smart TVs e telões do pavilhão, exibindo métricas de presença e volume de avaliações em tempo real sem expor notas parciais ou ranqueamento competitivo.

---

## 2. Escopo e Limites do Sistema

### O que o Sistema FAZ (Escopo):
1.  **Arquitetura Multi-Evento (Independência Completa e Parametrização Rica):**
    *   Suporta múltiplos eventos e edições anuais simultâneos de feiras e mostras científicas.
    *   Cada evento possui administração própria (`ADMIN`), equipe gestora (`event_administrators`), comissão avaliadora, trabalhos inscritos, áreas temáticas, premiações e participantes isolados.
    *   **Parametrização Completa da Edição:** O formulário de cadastro e edição da feira permite configurar metadados ricos: nome, ano, datas (início e término), local físico (`location`), descrição/orientações (`description`), carga horária total para certificados (`workload_hours`), capacidade máxima de trabalhos (`max_projects`), teto por avaliador (`max_projects_per_evaluator`), extensões de resumo e banner (`summary_extension`, `banner_extension`), limite de arquivo (`max_file_size_mb`), instituição organizadora (`organizing_institution`), tema oficial (`theme`), e-mail de contato (`contact_email`), site/regulamento oficial (`website_url`) e logotipo (`logo_url`).
    *   **Configuração Integrada de Níveis de Ensino (BR-04):** Permite selecionar os níveis atendidos (Fundamental I, Fundamental II, Médio/Técnico, Graduação, Pós-Graduação) e ajustar cotas de estudantes (`max_students`) e meta mínima de avaliações (`min_evaluators`).
    *   **Indicação Opcional de Equipe Gestora (BR-23):** Permite pré-indicar no cadastro ou gerenciar na edição os administradores convidados (Comissão Organizadora / Apoio).
    *   **Encerramento Temporal Automático:** A data limite `end_date` do evento dispara uma trava lógica automática, convertendo todo o evento para o modo somente leitura para fins de auditoria histórica.
2.  **Modelo Duplo de Autenticação:**
    *   **Administradores (`ADMIN`):** E-mail institucional e senha mestre criptografada com algoritmo de alta entropia (bcrypt/Argon2id).
    *   **Participantes (`STUDENT`, `ADVISOR`, `COADVISOR`, `EVALUATOR`):** Autenticação sem senha estática via **código de acesso único e aleatório de 8 caracteres** enviado para o e-mail cadastrado.
        *   Formato: `YY` (ano corrente em 2 dígitos, ex: `26` para 2026) + 4 letras maiúsculas + 2 números aleatórios (ex: `26AB34CD`).
        *   Garantia de unicidade checada no banco antes da persistência.
        *   Armazenado criptografado como hash (`access_code_hash`) na tabela `people`.
        *   Renderizado na tela de login como campo de senha mascarado (`type="password"`).
    *   **Proteção Universal de Todas as Rotas por API Key (Regra SEC-03):** Todas as rotas da API (`/api/v1/*`), incluindo expressamente consultas de leitura via método `GET` e operações de mutação (`POST`, `PUT`, `DELETE`), exigem a presença de uma API Key corporativa válida no cabeçalho `X-API-Key` (ou parâmetro `api_key`). Requisições sem chave válida são rejeitadas com `HTTP 401 Unauthorized`.
3.  **Configuração Dinâmica de Etapas e Arquivos:**
    *   O Administrador define as extensões permitidas no cadastro do evento (Resumo: `.pdf` ou `.docx`, padrão `.pdf`; Banner: `.pdf` ou `.pptx`, padrão `.pdf`; Diário de Bordo: `.pdf`) e limite de tamanho em MB validado por streaming.
4.  **Submissão em Lote e Fluxo Obrigatório de Anuência do Orientador (*Advisor Consent*):**
    *   Validação de e-mails em lote em transação única no banco de dados.
    *   Projetos submetidos entram no status `WAITING_CONSENT`.
    *   O professor orientador precisa acessar o sistema e conceder o aceite digital formal para que a organização possa homologar o trabalho.
5.  **Crachá de Dupla Identificação e Impressão Vetorial em PDF:**
    *   **Código de Barras Individual:** Impresso no crachá do participante para confirmar presença individual e baixa única de kits/camisetas. Gerado em vetor Code128 para garantir leitura por leitor laser/ótico.
    *   **QR Code do Projeto:** Afixado no estande de apresentação para acesso imediato dos avaliadores à ficha de notas digital via câmera do celular.
    *   **Presença Coletiva:** A confirmação de presença de qualquer membro da equipe no credenciamento altera automaticamente o status do trabalho para `PRESENT`.
    *   **Geração para Impressão:** Exportação individual e em lote em formato PDF A4 (4 crachás por folha com marcas de corte pontilhadas, guia de furo e logotipo oficial).
6.  **Logística e Emissão de Cards de Kits em PDF (Regras BR-09 e BR-29):**
    *   **Rastreamento com Lock Atômico:** Entrega de kits e tamanhos de camisetas registrado em `event_participants`, protegido por update atômico condicional contra retiradas duplicadas simultâneas.
    *   **Cards de Kits para Impressão em Folha A4 (Dois Modelos):**
        *   *Coletivo por Projeto / Estande (Grade 1x2 — 2 por folha A4):* Ideal para sacolas ou caixas de estande. Apresenta identificação gigante do número do estande (20pt negrito), badges de infraestrutura (`ENERGIA: SIM`, `MESA: SIM`), resumo de montagem do conteúdo do pacote (contagem total de kits e discriminativo de camisetas a ensacar) e checklist nominal com caixas de marcação `[ ]`. **Código do Pacote:** Padronizado para ser o mesmo código do estande (`projects.qrcode_token`), permitindo que **qualquer integrante da equipe (orientador ou estudantes)** retire o kit completo do estande na portaria, com baixa atômica de toda a equipe.
        *   *Individual por Participante (Grade 2x3 — 6 por folha A4):* Etiquetas individuais com código de barras Code128, papel do participante, estande, projeto e destaque de camiseta.
    *   **Concessão Flexível de Camisetas:** Toggles independentes para Estudantes, Orientadores, Coorientadores e Avaliadores. Categorias desmarcadas têm a camiseta suprimida no card impresso para evitar constrangimentos e questionamentos em feiras com restrições orçamentárias.
    *   **Ordenação Flexível da Impressão:** Geração ordenada por número de estande (padrão pavilhão), escola/instituição (caravanas) ou alfabética.
7.  **Alocação de Avaliadores em Dois Momentos (Credenciamento Contínuo e Paralelo):**
    *   *Credenciamento Contínuo e Paralelo:* Autores (projetos) e avaliadores realizam check-in de forma contínua e paralela durante todo o evento, sem travas de corte em lote.
    *   *Momento 1 (Alocação Dinâmica no Check-in do Avaliador):* No exato instante em que a equipe organizadora realiza o check-in do avaliador no evento, o sistema consulta os projetos já presentes (`PRESENT`) da mesma subárea, seleciona prioritariamente os trabalhos com menor número de avaliadores alocados, e realiza a alocação automática até a cota máxima (`max_projects_per_evaluator`), assegurando a Regra de Ouro ($\Delta \le 1$) e bloqueio de conflitos de interesse.
    *   *Momento 2 (Remanejamento Manual):* Atribuição, substituição ou ajuste pontual a qualquer instante por administradores.
    *   *Desvinculação Automática:* Projetos que permanecerem `ABSENT` ao final do evento têm suas alocações canceladas automaticamente.
8.  **Avaliação Digital Mestre-Detalhe e Duplo Ranqueamento:**
    *   Preenchimento de notas por critérios dinâmicos com descrição científica e/ou tecnológica.
    *   **Parecer/observação consolidada única** ao final de cada avaliação.
    *   **Dois Rankings Oficiais de Premiação:**
        *   *Ranking 1 (Premiações Regulares / Gerais):* Média aritmética simples considerando **todos os itens** de avaliação da ficha, agrupando por Área do Conhecimento e Nível de Ensino (Fundamental I, Fundamental II, Ensino Médio/Técnico, Graduação, Pós-Graduação), além do ranqueamento de **Melhor Geral** da feira.
        *   *Ranking 2 (Premiações Específicas):* Classificação de prêmios especiais considerando **exclusivamente os itens** de avaliação indicados no momento do cadastro do prêmio/critério.
9.  **Dashboard Exclusivo para Telões e TVs (Modo Quiosque):**
    *   Otimizado para resoluções 1080p e 4K em corredores e auditórios.
    *   Exibe métricas agregadas: participantes inscritos vs. presentes, projetos no estande, avaliações concluídas por grande área e escolas participantes.
    *   **Regra de Sigilo e Fair Play:** Dados puramente agregados; é proibido exibir notas individuais, nomes de avaliadores ou ranqueamentos competitivos.
10. **Gestão de Áreas e Subáreas no Painel do Administrador do Evento (CRUD):**
    *   Módulo completo dentro do Painel do Administrador do Evento para criar, listar, editar e desativar áreas do conhecimento e suas respectivas subáreas por edição.
    *   Permite a personalização temática das feiras sem intervenção manual no banco.
    *   Proteção referencial impeditiva: impede desativação de áreas com subáreas ativas e de subáreas vinculadas a projetos ou avaliadores.
    *   **Reativação Automática de Registros Desativados (Regra BR-16):** Se uma área ou subárea foi desativada (soft delete) anteriormente e o usuário recadastrar um registro com o mesmo nome, o sistema não emite erro de duplicidade; reativa o registro existente (`deleted_at = NULL`) e atualiza sua data.
11. **Gestão de Premiações e Vínculo com Questões da Avaliação (CRUD):**
    *   Módulo administrativo no Painel do Evento para criar, editar, listar e desativar prêmios, troféus de patrocinadores e menções honrosas.
    *   Opção de indicar quais perguntas/critérios da ficha de avaliação (`evaluation_criteria`) compõem a pontuação de cada prêmio específico.
    *   Cálculo automático de classificação dos projetos por prêmio específico baseando-se unicamente nas notas dos itens indicados para cada prêmio.
12. **Seleção Obrigatória de Evento Ativo e Contexto Global de Gerenciamento (Regra BR-19):**
    *   Em cenários com múltiplos eventos ou edições anuais da feira, o administrador deve selecionar expressamente qual evento deseja gerenciar por vez na tela de **Edições do Evento (`/events`)** através da ação *"Gerenciar este Evento"*.
    *   O evento selecionado torna-se o **contexto operacional ativo global** em todas as telas (`/`, `/areas`, `/projects`, etc.), persistido no `localStorage` do navegador.
    *   **Bloqueio de Páginas Dependentes (Gating):** As demais telas que operam sobre dados de evento só ficam ativas após a seleção de uma edição, sendo protegidas pelo componente `<RequireActiveEvent>`.
    *   O evento permanece ativo continuamente até que o usuário retorne à tela `/events` e escolha outro evento.
    *   A tela `/events` permite ainda editar parâmetros da edição (com trava temporal se encerrada, conforme Regra BR-02) e pesquisar edições por nome com debounce de 300ms.
13. **Paginação Real Obrigatória em Listagens de Dados (Regra BR-18 — Padrão: 15 Itens por Página):**
    *   Todas as telas e consultas de coleções de registros do sistema implementam **paginação real server-side** diretamente no SQL (`OFFSET` e `LIMIT`), com padrão obrigatório de **15 itens por página**.
    *   É expressamente proibido carregar toda a massa de dados para paginação em memória no frontend.
    *   O backend fornece metadados padronizados (`items`, `total`, `page`, `limit`, `total_pages`) e o frontend dispõe de componente com botões anterior/próximo, números de página e texto informativo.
    *   **Busca Textual Integrada:** Listagens dispõem de campo de pesquisa com debounce de 300ms que reseta para a página 1 e aciona busca textual via SQL `ilike` recalculando os totais.
14. **Gestão e Homologação Documental de Trabalhos Científicos (Fase 3):**
    *   Listagem paginada (15/página) isolada por edição ativa (`GET /api/v1/projects?event_id=...`).
    *   **Trava de Anuência Formal do Orientador (BR-05):** O deferimento de um projeto exige prévia anuência digital emitida pelo orientador titular (`advisor_consent == True`).
    *   **Homologação e Indeferimento com Justificativa (BR-06):** O coordenador pode deferir (`HOMOLOGATED`) com alocação opcional de estande ou indeferir (`REJECTED`) com preenchimento obrigatório de justificativa (`rejection_reason`).
    *   **Alocação de Estande (BR-08):** Atribuição e edição direta de código de estande (`PATCH /api/v1/projects/{id}/booth`).
    *   **Filtros Combinados:** Filtragem instantânea por status, nível de ensino (Fundamental I, Fundamental II, Médio/Técnico, Graduação, Pós-Graduação) e subárea temática.
15. **Diretrizes de Interface e Prevenção de Erros (Regras UX-01 e DEV-01):**
    *   **Mensagens dentro de Modais (UX-01):** Toda mensagem de alerta ou erro disparada em ações de modais é exibida diretamente dentro do corpo da modal, sem sobreposição ou ocultação sob o backdrop.
    *   **Componentes de Cliente (DEV-01):** Toda página ou componente interativo com hooks possui `"use client";` na primeira linha absoluta para prevenir telas em branco (*white screens*).
16. **Módulo de Gerenciamento de Participantes e Atribuição de Múltiplos Papéis no Evento (Opção 1):**
    *   Módulo administrativo para controle soberano de todas as pessoas vinculadas à edição ativa da feira.
    *   **Suporte a Múltiplos Papéis por Edição (`event_participant_roles`):** Uma pessoa pode exercer simultaneamente mais de um papel na mesma edição do evento (ex: ser **Orientador** no Projeto A e **Coorientador** no Projeto B; ser **Orientador** e também **Avaliador** da feira em outras subáreas; ser **Coorientador** e **Avaliador**).
    *   **Seleção Múltipla via Checkboxes:** Modais de cadastro e edição utilizam checkboxes interativos para seleção de um ou mais papéis (`STUDENT`, `ADVISOR`, `COADVISOR`, `EVALUATOR`, `ADMIN`).
    *   **Correção de Dados Importados:** Edição direta de nomes, e-mails, CPFs, afiliação institucional (IFMS/Externo), múltiplos papéis e tamanhos de camiseta de pessoas oriundas de importação em lote (CSV/SUAP) que contenham inconsistências.
    *   **Cadastro Avulso de Pessoas:** Permite ao Administrador registrar participantes adicionais (novos avaliadores convidados, coorientadores ou alunos transferidos) com geração automática de código de barras pessoal (`barcode` único).
    *   **Qualificação Temática de Avaliadores:** Se o papel `EVALUATOR` for marcado (isoladamente ou em conjunto com outro papel), exibe seleção múltipla de subáreas de conhecimento do evento.
    *   **Paginação Real de 15 Itens (BR-18):** Listagem de participantes paginada no banco com busca textual (nome, e-mail, CPF, código de barras) e filtros por papel (localiza participantes que possuam o papel em seus múltiplos vínculos), presença física e entrega de kit.
    *   **Trava de Integridade Referencial (BR-16):** Proteção que impede desvincular ou excluir participantes que sejam integrantes ativos de projetos científicos homologados na feira.
    *   **Garantia da Regra de Ouro:** O acúmulo de papéis de Orientador e Avaliador não gera conflito de interesse, pois o motor de alocação verifica diretamente a autoria e impede que orientadores avaliem seus próprios projetos ou de seus coautores.
17. **Separação Rigorosa dos Fluxos de Check-in (Recepção Geral vs. Sala dos Avaliadores):**
    *   **Credenciamento Geral (`/logistics`):** Posto na portaria/hall de entrada para recepção de estudantes, orientadores e equipes. A leitura de crachá/CPF confirma presença física (`presence_confirmed`), entrega kit/camiseta e promove projetos da equipe a `PRESENT` (Estande ativado - BR-08). **Não aloca trabalhos de avaliação** para não sobrecarregar orientadores ocupados com alunos.
    *   **Check-in Centralizado da Sala dos Avaliadores (`/evaluators/checkin`):** Posto dedicado na sala da comissão julgadora após o briefing de critérios. A digitação de CPF (com/sem pontuação) ou leitura de crachá/QR Code confirma estritamente a presença do avaliador na comissão (`evaluator_presence_confirmed`), sem interferir na presença geral nem na entrega de kits/camisetas de participantes (controle exclusivo da equipe de recepção/logística), e dispara a **Alocação Dinâmica Imediata** de projetos da subárea. Não há botões redundantes de check-in na listagem geral de avaliadores.
    *   **Blindagem do Rebalanceamento Automático (BR-10):** O algoritmo `run_auto_balance_allocation` considera exclusivamente avaliadores com `evaluator_presence_confirmed == True`, prevenindo alocações a pessoas que ainda não se apresentaram na sala da comissão.
18. **Trava Rígida de Subárea na Alocação Manual e Exibição Hierárquica de Áreas (Regra BR-10 Momento 2):**
    *   **Bloqueio Rígido no Backend (`manual_allocate`):** A vinculação manual de um avaliador a um trabalho científico exige que o projeto pertença estritamente a uma das subáreas de conhecimento cadastradas para o avaliador na edição (`person_subareas.subarea_id == project.subarea_id`). Tentativas de atribuir trabalhos de subárea diferente ou a avaliadores sem subáreas cadastradas são barradas com `HTTP 400 Bad Request`.
    *   **Filtragem Reativa no Frontend (`/evaluators`):** No modal de alocação manual, o administrador seleciona o avaliador; o sistema exibe as subáreas vinculadas e filtra imediatamente o dropdown de trabalhos, apresentando apenas projetos pertencentes às subáreas do avaliador (um avaliador pode possuir múltiplas subáreas).
    *   **Exibição Hierárquica (`Área Geral > Subárea`):** Nas telas de alocações, trabalhos científicos, check-in da sala dos avaliadores e detalhes de participantes, as subáreas são exibidas acompanhadas de sua respectiva Grande Área do Conhecimento mãe (`{Área Geral} > {Subárea}`), eliminando ambiguidades em subáreas homônimas.
19. **Gestão de Premiações e Apuração Oficial dos Dois Rankings (Fase 6 - BR-12 e BR-17):**
    *   **Módulo de Premiações (`/awards`):** Cadastro e parametrização completa de troféus especiais, menções honrosas e prêmios de patrocinadores vinculados à edição ativa (`RequireActiveEvent`). **Exige obrigatoriamente a seleção de ao menos um critério de avaliação vinculado** com pesos ponderados configuráveis (`0.1` a `10.0`, default `1.0`), impedindo premiações sem critério na apuração do Ranking 2.
    *   **Módulo de Classificação Oficial (`/results`):** Painel de apuração do Sistema Dual de Premiação organizado em três abas:
        1. **Por Área e Nível de Ensino (Ranking 1 - Categoria Principal):** Apuração por Grande Área e Nível de Ensino (Fundamental I, Fundamental II, Ensino Médio, Graduação, Pós-Graduação) calculada por média aritmética simples sem descarte de notas (BR-12). Pódio visual para os 3 primeiros colocados (Ouro 🥇, Prata 🥈, Bronze 🥉) e tabela detalhada.
        2. **Melhor Geral da Feira (Ranking 1 - Overall):** Classificação unificada dos melhores trabalhos de toda a feira, pódio de honra ao mérito e tabela completa.
        3. **Premiações Específicas (Ranking 2):** Apuração restrita às notas dos itens vinculados a cada prêmio e ponderadas pelos seus respectivos pesos (BR-17), com pódio e classificação oficial.
    *   **Emissão da Ata Oficial de Homologação:** Recurso de impressão estilizado (`@media print`) contendo cabeçalho oficial IFMS Campus Três Lagoas / FECITEL, quadro de pontuações, termo de homologação e campos para assinaturas da coordenação geral, comissão científica e direção-geral do campus.
20. **Módulo de Critérios de Avaliação (`/criteria` - Fase 2):**
    *   **Gestão Completa da Ficha de Avaliação:** CRUD completo para cadastro, edição e exclusão lógica de perguntas/itens da ficha mobile.
    *   **Sistema de Pergunta Dual por Tipo de Trabalho (Científico vs. Tecnológico):** Cada critério conta com campos de redação de pergunta configuráveis:
        1.  *Pergunta / Formulação para Trabalho Científico (`scientific_description`):* Focada na formulação da hipótese, controle de variáveis, método experimental e rigor na análise de dados.
        2.  *Pergunta / Formulação para Trabalho Tecnológico (`technological_description`):* Focada na definição da demanda técnica, engenharia do protótipo, relevância e viabilidade prática da solução.
    *   **Suporte a Eventos com Tipo Único de Trabalho:** Para edições que não dividem os trabalhos metodologicamente em científico e tecnológico, todos os trabalhos da feira são classificados sob o tipo `SCIENTIFIC` padrão. No cadastro do critério, o administrador pode assinalar a opção *"Evento com tipo único de trabalho"*, fazendo com que ambas as formulações sejam preenchidas com a mesma pergunta e simplificando a interface com um único campo de texto.
    *   **Unicidade de Ordem, Peso e Pontuação:** Ambas as formulações compartilham rigorosamente a mesma pontuação máxima (`max_score`), o mesmo peso ponderado (`weight`) e a mesma ordem na ficha. O sistema mobile decide em tempo de execução qual pergunta exibir conforme a tipagem do trabalho (`project.project_type`).
    *   **Trava de Integridade Histórica:** O sistema impede a exclusão de qualquer critério que já possua notas registradas em avaliações presenciais de projetos. O vínculo com premiações (`award_criteria`) é desativado em cascata no soft-delete.
21. **Identificação Soberana de Evento no Admin e URL Paramétrica do Telão TV Kiosk (Regra BR-20):**
    *   **Identificação do Evento no Admin:** As telas de Visão Geral (`/`) e Edições de Eventos (`/events`) do Painel Administrativo exibem obrigatoriamente o identificador numérico único do evento ativo (`ID: #{activeEvent.id}`).
    *   **Atalho e Cópia da URL do Kiosk:** Disponibilização de card de integração contendo a URL paramétrica (`http://<host>:3003/?event_id=X`), botão com feedback de cópia rápida para compartilhamento com operadores de TV e botão para abertura direta do telão em nova aba.
    *   **Suporte a Múltiplos Telões:** O Telão TV Kiosk (`apps/frontend-kiosk`) aceita o parâmetro `?event_id=X` na URL para permitir a projeção de eventos distintos em salas ou ginásios diferentes, com fallback inteligente para o evento ativo/recente caso nenhum parâmetro seja informado.
22. **Cálculo Oficial de Progresso da Feira por Cota de Avaliadores e Telão Kiosk Moderno (Regra BR-21):**
    *   **Superação do Multiplicador Fixo:** O cálculo do percentual consolidado da feira e do andamento por Grande Área não utiliza valor fixo ou hardcoded (`* 2`), mas obtém a cota oficial configurada dinamicamente no banco de dados para a respectiva edição (`events.max_projects_per_evaluator` ou `education_levels.min_evaluators` para cada nível dos projetos presentes).
    *   **Cálculo Server-Side e Otimização SQL no Backend:** O endpoint `GET /api/v1/dashboard/public-tv` apura a meta global de avaliações esperadas ($\sum \text{Cota}(p)$), a meta por Grande Área e entrega os percentuais e contagens em consultas únicas agrupadas (`GROUP BY`), eliminando loops N+1.
    *   **Reestruturação dos 4 Cards Superiores (Opção 4B):** Apresenta: Card 1 (Projetos em Estande), Card 2 (Participantes Presentes: apenas alunos e orientadores), Card 3 (Avaliadores Presentes: presença na sala dos avaliadores) e Card 4 (Progresso da Feira), todos estilizados com medidores circulares radiais SVG ampliados e responsivos no corpo do card ao lado dos valores de quantidade.
    *   **Layout Expandido e Opção 1C nas Grandes Áreas:** O grid de Grandes Áreas ocupa 100% da largura útil em até 4 colunas para Smart TVs 1080p e 4K, exibindo para cada área tanto *"X presentes de Y inscritos"* quanto *"W de Z avaliações esperadas"*, mantendo os avisos de sigilo (BR-14) no letreiro digital (News Ticker) inferior.
23. **Centro de Comando da Visão Geral do Administrador e Diagnóstico em Tempo Real (Regra BR-22):**
    *   **Painel Unificado de Tomada de Decisão (War Room):** O painel administrativo de Visão Geral (`apps/frontend-admin/src/app/(dashboard)/page.tsx`) atua como centro de comando executivo, apresentando métricas idênticas às do Telão Kiosk acrescidas de microdetalhes operacionais para gestão de contingência.
    *   **Requisição Única Otimizada (`GET /api/v1/dashboard/admin-overview`):** Agrupa todos os dados analíticos em uma única consulta server-side em O(1), eliminando concorrência de requisições e latência de rede.
    *   **Termômetro de Risco por Grande Área e Déficit de Avaliadores:** Diagnóstico instantâneo por semáforo (Verde $\ge 100\%$, Amarelo $70\%-99\%$, Vermelho $< 70\%$) comparando a demanda de avaliações com a capacidade real dos avaliadores presentes, calculando exatamente quantos novos avaliadores são necessários para suprir o déficit de cada área temática.
    *   **Monitoramento de Projetos Críticos e Alocação Imediata:** Alerta contadores de projetos vulneráveis (0 avaliadores ou abaixo da cota mínima) com tabela colapsável e botão de alocação manual direta com modal integrado.
    *   **Ações Rápidas de Gestão:** Botão de rebalanceamento algorítmico global em 1-clique ($\Delta \le 1$) e atalho para o fluxo oficial de cadastro de avaliadores voluntários (`/participants?role=EVALUATOR`).
    *   **Polling de 30s com Anel Regressivo e Notificações:** Ciclo de atualização automática com anel SVG circular regressivo de 30 segundos, controle de pausa/retomada e disparo de alertas em tempo real (toasts).
24. **Plataforma Multi-Feiras com Isolamento Estrito por Evento e Hierarquia Administrativa (Regra BR-23):**
    *   **Isolamento Estrito Absoluto (Multi-Tenant Soberano):** O sistema opera como plataforma aberta para gestão de múltiplas feiras e eventos científicos independentes (FECITEL, FECITEC, feiras municipais e escolares). Cada evento pertence exclusivamente ao seu criador (`events.owner_id = current_user.id`) e somente é visível e gerenciável por ele e pelos administradores expressamente convidados por ele.
    *   **Ausência Deliberada de Super Administrador:** O sistema adota o princípio de menor privilégio e privacidade estrita sem nenhuma conta mestra global. Nenhum usuário visualiza ou altera eventos de outros organizadores sem ter sido convidado.
    *   **Hierarquia de Governança por Feira (Tabela `event_administrators`):**
        *   **`COORDINATOR` (Coordenador Geral / Dono):** Criador da edição. Possui controle irrestrito: edição de regulamento, datas, trava temporal, homologação, alocação, apuração, exclusão/arquivamento da feira e gestão da equipe gestora (convidar por e-mail, alterar papéis ou revogar acessos). O dono soberano nunca pode ser revogado por terceiros.
        *   **`ORGANIZER` (Comissão Organizadora / Co-Administrador):** Gestão operacional plena da feira (projetos, homologação documental, áreas, critérios, prêmios, participantes, balanceamento algorítmico $\Delta \le 1$, apuração e Centro de Comando). Não possui permissão para excluir a feira nem alterar a coordenação geral.
        *   **`OPERATOR` (Apoio / Recepção & Credenciamento):** Operação tática de linha de frente. Acesso restrito à Mesa de Credenciamento Geral e entrega de kits (`/logistics`), Check-in dos Avaliadores (`/evaluators/checkin`) e visualização da Visão Geral (`/`). Menus estratégicos e de configuração sensível (Critérios, Alocação, Premiações) permanecem bloqueados.
    *   **Blindagem de Segurança no Backend:** Toda consulta analítica ou mutação de dados valida se o usuário autenticado possui vínculo ativo em `(event.owner_id == user.id OR event_administrators.person_id == user.id)`, retornando `HTTP 403 Forbidden` caso ocorra tentativa de acesso a evento não autorizado.
25. **Auto-Cadastro de Novos Organizadores com Verificação OTP em Duas Etapas (Regra BR-24):**
    *   **Onboarding Autônomo e Descentralizado:** Em decorrência da inexistência de um Super Administrador (BR-23), professores e gestores de novos eventos científicos podem se auto-cadastrar na plataforma via formulário público em `/register`.
    *   **Verificação em Duas Etapas via E-mail:**
        1.  *Etapa 1 (Solicitação):* O usuário informa Nome e E-mail. O backend valida a inexistência prévia de conta ativa, gera um código OTP seguro de 8 caracteres alfanuméricos com expiração de 15 minutos e envia para o e-mail do solicitante via SMTP.
        2.  *Etapa 2 (Validação e Definição de Senha):* O usuário digita o OTP de 8 caracteres recebido, seu CPF, Afiliação/Instituição e define sua senha. O backend valida o hash do código, cria o registro em `people` com `password_hash`, autentica o usuário emitindo token JWT e redireciona para `/events`.
    *   **Primeira Feira do Organizador:** O novo organizador é recebido em `/events` com tela de boas-vindas orientando a criação de seu primeiro evento. Ao cadastrá-lo, torna-se automaticamente seu `owner_id` e Coordenador Geral soberano (`COORDINATOR`).
26. **Distinção e Restrição de Níveis de Ensino para Avaliadores (Regra BR-25):**
    *   **Qualificação Fina de Níveis de Ensino (`person_education_levels`):** Nem todos os avaliadores de uma feira científica possuem habilitação ou disponibilidade para julgar projetos de todas as categorias escolares ou acadêmicas. O sistema permite vincular cada avaliador aos níveis de ensino em que está apto a atuar (`JUNIOR` [Fundamental I], `FUNDAMENTAL` [Fundamental II], `MEDIO` [Médio/Técnico], `GRADUACAO` [Graduação/Superior], `POS_GRADUACAO` [Pós-Graduação]).
    *   **Princípio da Universalidade por Omissão:** Se o avaliador for cadastrado sem nenhuma restrição explícita de nível de ensino vinculada na edição ativa, o motor de alocação o considera apto universalmente (avalia trabalhos de qualquer nível).
    *   **Filtragem Estrita na Alocação Dinâmica por Check-in:** Ao registrar presença do avaliador via leitura de código de barras ou CPF na Sala dos Avaliadores (`/evaluators/checkin`), a consulta de projetos presentes (`PRESENT`) aplica o filtro `Project.education_level.in_(evaluator_levels)`.
    *   **Compatibilidade no Auto-Balanceamento Global ($\Delta \le 1$):** O algoritmo distributivo descarta pares avaliador-projeto que possuam incompatibilidade de nível de ensino.
    *   **Trava Impeditiva na Alocação Manual:** No painel `/evaluators`, a tentativa de designar manualmente um avaliador para um projeto de nível divergente aos seus níveis habilitados é rejeitada pela API com `HTTP 400 Bad Request`.
27. **Importação em Lote de Participantes via Planilha CSV (Regra BR-26):**
    *   **Padrão Tabular Flexível:** Permite o cadastramento e sincronização massiva de pessoas vinculadas à feira ativa via arquivo `.csv` codificado em UTF-8 com BOM (delimitadores `;` ou `,`), contendo as colunas: `nome`, `email`, `papeis`, `cpf`, `afiliacao`, `tamanho_camiseta`, `subareas`, `niveis_ensino`.
    *   **Suporte a Múltiplos Papéis:** A coluna `papeis` aceita termos em português ou inglês separados por vírgula (ex: `"Orientador, Avaliador"`, `"Estudante"`, `"Avaliador"`). Não permite o papel `ADMIN` (gestão exclusiva em `event_administrators`).
    *   **Associação Dinâmica de Subáreas e Níveis para Avaliadores:** Se a linha contiver o papel `Avaliador`, as subáreas podem ser informadas no formato hierárquico `Área -> Subárea` (ou `Área > Subárea` / `Área: Subárea`), ex: `"Engenharias -> Robótica, Ciências Exatas -> Informática"`. Caso seja informado apenas o nome simples da subárea e ele for exclusivo na feira ativa, o vínculo é resolvido automaticamente; caso existam subáreas homônimas em áreas distintas, o sistema emite erro impeditivo solicitando a notação hierárquica para prevenir vinculações incorretas. A coluna `niveis_ensino` qualifica os níveis aceitos (ex: `"Fundamental I, Médio, Graduação"` ou `"Fundamental II, Pós-Graduação"`).
    *   **Idempotência e Reativação:** Linhas contendo e-mails de pessoas já cadastradas atualizam seus dados complementares (nome, CPF, afiliação institucional, tamanho de camiseta) e reativam registros marcados com soft-delete (`deleted_at = NULL`).
    *   **Geração Automática de Códigos:** Participantes novos recebem código de barras pessoal único `BC-XXXXX` e hash de código de acesso de 8 caracteres para login passwordless.
    *   **Pré-visualização e Validação Client-Side no Frontend:** A tela `/participants` oferece modal interativo com cards de KPI (Total, Alunos, Orientadores, Avaliadores), tabela com chips coloridos de papéis e detecção prévia de erros impeditivos antes do envio.
28. **Geração Vetorial de Crachás em PDF (Individual e em Lote) e Upload de Logotipo (Regra BR-27):**
    *   **Motor Gráfico Vetorial em ReportLab:** Geração server-side de crachás de alta fidelidade visual e precisão dimensional em padrão folha A4 (grid 2x2, 4 crachás por folha), com margens de segurança, guias de corte pontilhadas e marcação central de furo para cordão de pescoço.
    *   **Identificação Visual e Código de Barras Vetorial:** Cada crachá incorpora o logotipo oficial da feira, nome do evento, ano, tarja com cor representativa por papel (Estudante, Orientador, Coorientador, Avaliador, Equipe Organizadora), nome do participante, instituição, estande e título do projeto (para autores) ou subáreas temáticas e níveis de ensino autorizados (para avaliadores), acompanhado de código de barras **Code128** gerado vetorialmente (legível instantaneamente por leitores ópticos).
    *   **Exportação em Lote Estruturada por Seções:** O PDF consolidado da feira organiza os participantes em 3 seções temáticas padronizadas:
        1.  *Seção 1 (Trabalhos Científicos):* Agrupados por projeto na ordem hierárquica oficial: Orientador $\rightarrow$ Coorientador $\rightarrow$ Estudantes autores.
        2.  *Seção 2 (Equipe Organizadora):* Coordenadores gerais (`COORDINATOR`), membros da comissão (`ORGANIZER`) e operadores de apoio (`OPERATOR`).
        3.  *Seção 3 (Avaliadores Credenciados):* Relação de avaliadores com subáreas temáticas e níveis de ensino habilitados.
    *   **Impressão Individual Avulsa:** Ação rápida na listagem de participantes (`/participants`) para emissão do crachá individual de qualquer pessoa cadastrada.
    *   **Upload Direto de Logotipo (PNG e JPG/JPEG):** O cadastro e edição de eventos em `/events` aceita upload direto de arquivo de imagem nos formatos `.png`, `.jpg`, `.jpeg` (com limite de até 5MB), gravando em `storage/uploads/logos/` e servindo via rota estática `/static/uploads/logos/`. O ReportLab lê o arquivo de imagem diretamente do disco para renderização no PDF sem latência de rede.
29. **Gestão de Infraestrutura de Projetos (Energia e Mesa) e Modelo CSV Dinâmico por Edição (Regra BR-28):**
    *   **Campos de Infraestrutura de Apresentação:** A tabela `projects` armazena `needs_electricity` (necessidade de ponto de energia elétrica/tomada no estande) e `needs_table` (necessidade de mesa/bancada para protótipo), ambos campos booleanos com valor padrão `False` ("Não").
    *   **Visibilidade e Edição no Painel do Administrador:** Na tela `/projects`, a coluna de identificação/título do trabalho exibe badges visuais indicando tomada (`⚡ Tomada: Sim/Não`) e mesa (`🪑 Mesa: Sim/Não`) ao lado do tipo de trabalho (`Científico` ou `Tecnológico`). O modal de detalhes e a modal de edição cadastral permitem consultar e alterar esses parâmetros, além de título, código de estande, subárea, nível de ensino e resumo.
    *   **Geração Dinâmica do Template CSV por Edição:** O endpoint `GET /api/v1/projects/template-csv?event_id=X` consulta a tabela `education_levels` do evento ativo, identifica o maior número de estudantes permitido (`max(max_students)`), e gera dinamicamente as colunas `autor1_nome`, `autor1_email`, ..., `autorN_nome`, `autorN_email`, além das colunas `ponto_energia`, `mesa_prototipo` (com suporte a Sim/Não, S/N, 1/0, True/False) e a coluna `area_subarea`.
    *   **Desambiguação de Subáreas via Notação Hierárquica (`Área -> Subárea`):** A coluna `area_subarea` do CSV é gerada e importada no formato em pares `Área -> Subárea` (aceitando também os separadores `>` e `:`), garantindo 100% de precisão mesmo quando áreas distintas possuírem subáreas com o mesmo nome (subáreas homônimas). O backend e o frontend utilizam mapas compostos `(Área, Subárea) -> ID` e emitem erro impeditivo amigável caso seja informado um nome simples ambíguo sem a discriminação da grande área mãe.
    *   **Importação e Upsert em Lote:** O parser de CSV do backend e do frontend processa ordenadamente até $N$ autores e persiste os requisitos de infraestrutura tanto na criação quanto no upsert de trabalhos científicos.
30. **Emissão de Cards de Kits em PDF (Individual e por Projeto) e Sincronização de Camisetas (Regra BR-29):**
    *   **Cards de Kit em PDF Vetorial de Alta Resolução via ReportLab:** Emissão em folha A4 com guias de corte pontilhadas para agilizar a logística de recepção e entrega de materiais aos participantes.
    *   **Formato Coletivo por Projeto / Estande (Grade 1x2 — 2 por A4):** Projetado para sacolas grandes ou caixas kraft de estande. Apresenta badge gigante de estande no topo (visível à distância), título do trabalho, área, escola/instituição, pills de infraestrutura (energia e mesa), resumo de montagem da sacola (*Packing List* com contagem líquida de kits e camisetas) e checklist nominal com caixas de marcação `[ ]` para cada integrante da equipe.
    *   **Formato Individual por Participante (Grade 2x3 — 6 por A4):** Etiquetas individuais para colagem direta em sacolas compactas de cada pessoa, contendo nome em destaque, papel, estande, projeto vinculado, box de concessão de camiseta e código de barras Code128.
    *   **Filtro Flexível de Concessão de Camisetas por Categoria:** O administrador pode configurar se deseja incluir camisetas para Estudantes, Orientadores, Coorientadores e/ou Avaliadores, permitindo ajustar a logística às restrições orçamentárias de cada edição e suprimindo menções a camisetas nos cards de categorias não contempladas.
    *   **Sincronização de Tamanhos de Camiseta no CSV de Projetos:** O modelo e o importador CSV de trabalhos científicos incluem colunas nominais de camiseta (`orientador_camiseta`, `coorientador_camiseta`, `autor{i}_camiseta` para $i = 1 \dots N$). Aceita tamanhos `PP`, `P`, `M`, `G`, `GG`, `XG`, sincronizando diretamente na tabela `event_participants` para aquela edição do evento e eliminando distorções onde todas as camisetas saíam como `"M"`.
    *   **Visualização de Tamanho de Camiseta na Gestão de Projetos:** A modal de importação em lote (`ProjectsCsvImportModal`) exibe os tamanhos no preview dos autores, e a listagem de projetos (`/projects`) apresenta badge com o tamanho da camiseta de cada membro nos detalhes do trabalho.
    *   **Script de Limpeza e Reset Seletivo do Banco (`scripts/limpar_banco.py`):** Utilitário CLI interativo em Python para expurgo seletivo de tabelas (projetos, participantes, avaliações, alocações, critérios, áreas ou reset completo) preservando a integridade referencial por chaves estrangeiras.
31. **Gestão de Momentos de Lanche e Distribuição com Captura Óptica (Regra BR-30):**
    *   **Cadastro Flexível de Momentos de Lanche:** O administrador cadastra múltiplos momentos de lanche por edição (`snack_moments`), configurando nome descritivo (ex.: *"Lanche da Tarde - Dia 1"*), data, faixa de horário, cota prevista (`total_budgeted`) e público-alvo autorizado (`target_roles`: `ALL` ou papéis selecionados como estudantes, orientadores, avaliadores e equipe).
    *   **Trava Antifraude de Unicidade Estrita:** O banco de dados impõe `UNIQUE (snack_moment_id, participant_id)`. Se o mesmo crachá for bipado duas vezes no mesmo momento, a leitura é rejeitada com alerta visual vermelho enfático e som de aviso, informando o horário exato da retirada anterior e impedindo duplicidade.
    *   **Captura Óptica Híbrida (USB/OTG e Câmera de Smartphone):** A tela operacional mobile-first `/snacks/distribution` permite bipar crachás em altíssima velocidade usando leitor de código de barras USB conectado ao celular via adaptador OTG (R$ 15), ou usando a própria câmera do celular via navegador (`html5-qrcode`), com busca manual de contingência por CPF/nome.
    *   **Feedback Audiovisual Imediato e Placar em Tempo Real:** Resposta com síntese sonora nativa (`Web Audio API`) verde/vermelha, exibição dos dados do participante e percentual atingido da cota de lanches.

### O que o Sistema NÃO FAZ (Fora de Escopo):
1.  **Cobranças Financeiras / Gateway de Pagamento:** O evento é 100% público e gratuito.
2.  **Emissão de Certificados:** A emissão de certificados físicos ou digitais é processada externamente pelo IFMS/sistemas institucionais.

---

## 3. Atores e Papéis do Sistema (RBAC Multirrol por Edição)

### 3.1 Papéis do Sistema (`UserRole`)
| Papel | Descrição | Permissões Principais |
| :--- | :--- | :--- |
| **`ADMIN`** | Usuário com credenciais administrativas no sistema. | Acesso ao Painel Administrativo (`apps/frontend-admin`). Suas permissões sobre cada feira dependem de ser o criador (`owner_id`) ou do nível concedido em `event_administrators`. Autentica via e-mail e senha. |
| **`STUDENT`** | Estudante autor/proponente. | Cadastro de equipe, submissão de projeto, upload de arquivos e consulta de status. Autentica via código OTP de 8 caracteres. |
| **`ADVISOR`** | Professor orientador. | Consulta dos projetos orientados e concessão formal da anuência digital. Pode atuar concomitantemente como Avaliador na feira. Autentica via código OTP de 8 caracteres. |
| **`COADVISOR`** | Professor coorientador. | Consulta e acompanhamento dos dados dos projetos que coorienta. Pode atuar concomitantemente como Avaliador na feira. Autentica via código OTP de 8 caracteres. |
| **`EVALUATOR`** | Avaliador científico/tecnológico. | Leitura do QR Code de estande, visualização de projetos alocados e preenchimento das fichas de notas e parecer. Pode ser acumulado por orientadores/coorientadores com blindagem de conflito de interesse. Autentica via código OTP de 8 caracteres. |

### 3.2 Níveis de Governança por Evento (`EventAdminRole` - Regra BR-23)
| Nível por Feira | Escopo | Ações Autorizadas |
| :--- | :--- | :--- |
| **`COORDINATOR`** | Coordenador Geral (Dono da Feira) | Controle soberano: configurações gerais, datas e regras da feira, convidar/remover administradores e exclusão da edição. |
| **`ORGANIZER`** | Comissão Organizadora (Co-Admin) | Gestão operacional integral: projetos, estandes, homologação, áreas, critérios, prêmios, lanches, alocação, apuração e War Room. |
| **`OPERATOR`** | Apoio / Recepção & Credenciamento | Acesso tático: Mesa de Credenciamento, Check-in de Avaliadores, baixa de kits, distribuição de lanches na fila (`/snacks/distribution`) e leitura da Visão Geral. |


---

## 4. Integrações Externas e Periféricos de Hardware

1.  **Importação SUAP:** Upload em lote de planilhas (`.csv` / `.xlsx`) contendo matrículas e registros de alunos e servidores.
2.  **Leitores de Código de Barras (USB / Bluetooth / Câmera):** Leitura veloz dos códigos dos crachás no credenciamento e na entrega de lanches.
3.  **Leitores de QR Code (Câmeras de Smartphones e Tablets):** Leitura dos QR Codes dos estandes pelos avaliadores via navegador mobile.
4.  **Smart TVs e Projetores (Telão Público):** Painel web em tela cheia com alta legibilidade e atualização em segundo plano.
5.  **Armazenamento de Arquivos:** Upload em streaming com validação MIME estrita de resumos, banners e diários de bordo.
6.  **Servidor SMTP de E-mails:** Envio automatizado dos códigos de acesso OTP de 8 caracteres e avisos de solicitação de anuência aos orientadores.

---

## 5. Especificação de Códigos Ópticos (Códigos de Barras e QR Codes) e Rastreabilidade Operacional

| Elemento Óptico | Simbologia | Entidade & Coluna no Banco de Dados | Padrão / Formato do Valor | Onde Aparece no Sistema | Ação / O que Dispara ao Ser Lido |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Código de Barras do Participante** | Linear **Code128** | Tabela: `people`<br>Campo: `barcode`<br>`VARCHAR(100) UNIQUE NULL` | `BC-XXXXX`<br>*(ex: `BC-A8K2F` ou `BC-00042`)* | • **Crachás em PDF** (rodapé inferior central)<br>• **Cards Individuais de Kit em PDF** (rodapé inferior direito)<br>• Tela `/participants` (Admin - coluna Documento)<br>• Input óptico na tela `/logistics` (Portaria) | **Credenciamento & Retirada de Kit Individual:** Ao ser bipado com leitor óptico na recepção, registra a presença da pessoa física (`presence_confirmed = True`) e a baixa do kit/camiseta (`kit_delivered = True`). Se o participante for autor de trabalho científico, dispara a **Presença Coletiva (Regra BR-08)**, promovendo o status do projeto para `PRESENT`. |
| **Código de Barras do Crachá (Lanches)** | Linear **Code128** | Tabela: `people`<br>Campo: `barcode`<br>`VARCHAR(100) UNIQUE NULL` | `BC-XXXXX`<br>*(ex: `BC-A8K2F` ou `BC-00042`)* | • **Crachás em PDF** (rodapé inferior central)<br>• Tela `/snacks/distribution` (Admin/Mobile) | **Controle e Retirada de Lanches (Regra BR-30):** Ao ser lido por leitor USB (OTG) ou câmera do celular, valida se o participante tem direito ao momento de lanche ativo e se já retirou. Se for a primeira leitura, registra a entrega com feedback sonoro verde. Se for tentativa duplicada, bloqueia e acusa horário da retirada anterior com alerta vermelho. |
| **QR Code do Perfil do Avaliador** | Bidimensional **QR Code (2D)** | Tabela: `people`<br>Campo: `barcode`<br>`VARCHAR(100) UNIQUE NULL` | `BC-XXXXX`<br>*(reutiliza o mesmo barcode pessoal)* | • App Mobile do Avaliador (tela **"Meu Perfil"**, exibido na tela do smartphone) | **Check-in de Avaliadores:** O avaliador apresenta a tela do celular na Sala dos Avaliadores. A recepção lê o QR Code em `/evaluators/checkin`, confirmando a presença do avaliador (`evaluator_presence_confirmed = True`) e disparando a **alocação automática e balanceada de projetos** ($\Delta \le 1$). |
| **QR Code da Bancada / Estande** | Bidimensional **QR Code (2D)** | Tabela: `projects`<br>Campo: `qrcode_token`<br>`VARCHAR(100) UNIQUE NOT NULL` | `FECITEL-2026-XXXXXXXXXXXXXXXX`<br>*(ou `ID Trabalho` numérico)* | • **Adesivo/Placa de Bancada em PDF** (impresso em folha A4 nos modelos A5 ou A6, com QR Code maximizado e sem número de estande, colado na bancada física do projeto)<br>• Modal de Detalhes do Projeto em `/projects` (Admin) | **Abertura da Ficha Oficial de Avaliação:** O avaliador aponta a câmera do smartphone no app mobile (tela `/scan`) para a placa da bancada. O sistema valida se o avaliador está alocado para o trabalho, confere inexistência de conflito de interesses (escola/parentesco) e abre a **Ficha de Avaliação** (Científica ou Tecnológica) com notas de 0 a 10. |
| **Código do Pacote do Projeto (Card Coletivo)** | Linear **Code128** | Tabela: `projects`<br>Campo: `qrcode_token`<br>`VARCHAR(100) UNIQUE NOT NULL` | `FECITEL-2026-XXXXXXXXXXXXXXXX`<br>*(ou `PRJ-{id:05d}` em fallback)* | • Rodapé inferior esquerdo do **Card Coletivo de Kit por Projeto** (PDF impresso colado na sacola/caixa kraft) | **Retirada do Pacote do Estande por Qualquer Integrante:** O voluntário bipa a sacola kraft na tela `/logistics`. Como o código é padronizado com o estande (`projects.qrcode_token`), o sistema reconhece o projeto, promove o estande para `PRESENT` e permite com 1 clique (`POST /api/v1/logistics/project-kits/{id}/checkout`) a **baixa coletiva e atômica de todos os kits da equipe**. **Qualquer integrante do grupo (orientador, coorientador ou estudantes)** pode retirar o pacote completo na portaria. |

---

## 6. Adesivos de Bancada em PDF e Utilitário de Limpeza de Eventos

### 6.1 Adesivos de Bancada com QR Code e ID do Trabalho (PDF)
* **Finalidade:** Identificação direta das bancadas físicas no pavilhão de feiras científicas e viabilização da avaliação ágil por smartphones.
* **Layout Simplificado e Focado:** Omite dados já presentes no banner impresso pelo grupo (título, autores, escola, nível e instituição organizadora) e também o número do estande.
* **Maximização do QR Code:** A eliminação de elementos dispensáveis permitiu ampliar o QR Code para até 180 pt (modelo A5) ou 135 pt (modelo A6), garantindo leitura instantânea em corredores de feiras.
* **Disponibilidade:** Emissão em lote via modal em `/projects` (com filtros de status, grande área e layout 2 ou 4 por folha) e emissão individual por trabalho via botão de ação com ícone `QrCode` na tabela.

### 6.2 Utilitário de Limpeza e Reset (`scripts/limpar_banco.py`)
* Ferramenta interativa para ambiente de desenvolvimento e homologação.
* Contém opção exclusiva (`[10]`) para **remover todos os eventos cadastrados no banco de dados, exceto o ID de evento informado pelo usuário**, apagando em cascata todas as tabelas dependentes dos demais eventos e mantendo íntegro o evento ativo de trabalho.
