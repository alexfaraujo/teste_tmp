# Regras de Desenvolvimento, Arquitetura e Comportamento do Agente — FECITEL

Este documento estabelece as diretrizes obrigatórias de governança, metodologia de trabalho, arquitetura, segurança, padrões de idioma e regras de negócio que qualquer agente de inteligência artificial (Antigravity ou outro) e membros da equipe técnica devem seguir estritamente neste projeto.

---

## 1. Governança, Metodologia e Dinâmica de Trabalho (Invioláveis)

### 1.1. Autoridade Soberana do Gestor do Projeto
*   **Propriedade Exclusiva:** O usuário (Alex Araújo) é o único dono do projeto e o **Gestor do Projeto**, sendo a autoridade máxima e soberana para definir, aprovar e autorizar toda e qualquer modificação no sistema.
*   **Decisões Colaborativas (Pair Programming):** Nenhuma decisão arquitetural, funcional ou estrutural pode ser tomada autonomamente pelo agente sem consulta prévia e aprovação expressa do Gestor no chat.
*   **Proibição de Implementação Autônoma:** O agente é **ESTRITAMENTE PROIBIDO** de iniciar a codificação física de qualquer etapa sem receber autorização prévia e expressa do Gestor.
*   **Paradas Obrigatórias em Checkpoints:** Ao concluir qualquer etapa incremental de modelagem, relatório ou entrega física, o agente deve parar imediatamente, apresentar um resumo transparente do que foi feito e aguardar a validação e autorização do usuário antes de prosseguir.

### 1.2. Padrão de Idiomas do Projeto (Código em Inglês; Documentos e Telas em Português)
*   **Código-Fonte e Banco de Dados (Estritamente em Inglês):**
    *   Todos os nomes de arquivos de código (ex: `main.py`, `models.py`, `auth_service.py`), nomes de pastas de código, variáveis, constantes, funções, métodos, classes, rotas de API RESTful, tabelas do PostgreSQL (`events`, `projects`, `knowledge_areas`, `awards`, `award_criteria`), colunas de banco de dados e payloads JSON devem seguir o idioma **inglês** (`snake_case` para variáveis/tabelas/colunas; `PascalCase` para classes/modelos).
*   **Documentação, Interface com o Usuário e Comunicações (Estritamente em Português):**
    *   **Arquivos de Documentação (`.md`):** Todos os arquivos markdown (`docs/`, `.agents/rules.md`, relatórios, especificações de arquitetura) devem ser redigidos em **português (pt-BR)**.
    *   **Interface Gráfica (UI):** Todos os textos de telas, rótulos de campos, botões, modais, títulos de páginas, menus e navegações dos frontends devem ser em **português**.
    *   **Mensagens e Comunicação:** Todas as mensagens do sistema, avisos de erro, validações, notificações de toast, e-mails enviados aos participantes (contendo código de acesso OTP) e informes de telão devem ser estritamente em **português**.

### 1.3. Rastreabilidade e Histórico Cronológico Obrigatório na Pasta `docs/`
*   **Repositório Cronológico:** É **estritamente obrigatório** manter todo o histórico de análises, relatórios, pareceres técnicos, decisões do Gestor e interações registrado na pasta `docs/`.
*   **Padrão de Nomenclatura com Data e Hora:** Todos os relatórios, análises e decisões salvos na pasta `docs/` devem seguir o formato cronológico:  
    `docs/XXX_nome_descritivo_YYYY-MM-DD_HHhMM.md` (exemplo: `docs/001_analysis_report_and_decisions_2026-09-09_10h05.md`).
*   **Proibição de Sobrescrita:** Arquivos de histórico cronológico nunca devem ser sobrescritos ou apagados; novas decisões geram novos registros sequenciais.
*   **Métricas de Esforço da IA em Todos os Registros:** Todo registro de marco no histórico deve detalhar:
    1. `% Feito por IA:` Boilerplates diretos, scripts automatizados, testes estruturais.
    2. `% Híbrido:` Pair programming, refinamento colaborativo de regras, ajustes em tempo real com feedback.
    3. `% Participação Humana:` Requisitos iniciais, aprovações soberanas, regras de negócio e escolhas de arquitetura.

### 1.4. Controle de Versão (Git) e Restrição Estrita de Push
*   **Commits em Checkpoints:** Commits locais frequentes seguindo o padrão Conventional Commits (`feat:`, `fix:`, `docs:`, `chore:`) após a validação do usuário.
*   **Proibição Absoluta de `git push` Autônomo:** O agente é **ESTRITAMENTE PROIBIDO** de executar `git push` por iniciativa própria. Qualquer envio para o repositório remoto exige autorização explícita e textual do Gestor no chat (ex: *"pode fazer o push"*).

### 1.5. Stack Tecnológica, Monorepo em 4 Blocos e Execução Bare-Metal
*   **Estrutura em Monorepo (4 Blocos Funcionais Desacoplados):**
    1.  `apps/backend/`: Exclusivamente **Python 3.11+**, **FastAPI**, **SQLAlchemy 2.0 (assíncrono com `asyncpg`)** e **Pydantic v2**.
    2.  `apps/frontend-admin/`: **Next.js 14+ (App Router)**, **TypeScript**, **Tailwind CSS**, para gestão do evento, homologação, mesa de recepção/credenciamento, áreas, prêmios e apuração oficial.
    3.  `apps/frontend-evaluator/`: **Next.js 14+ Mobile-First PWA** para avaliadores na feira com leitor QR de bancada, notas com botões táteis (`+`/`-`) e parecer consolidado único.
    4.  `apps/frontend-kiosk/`: **Next.js 14+ Quiosque para Telões e TVs** de auditórios/corredores (1080p e 4K, dark mode nativo padrão, métricas agregadas sem notas individuais).
*   **Sem Docker, Sem Node.js no Backend:** Execução bare-metal nativa no sistema operacional, utilizando ambiente virtual Python (`venv`) e PostgreSQL local instalado na máquina.
*   **Scripts de Inicialização (`run.sh` / `start.sh`):** Mantidos em `apps/backend/` para configurar `venv`, instalar dependências, executar migrações e subir os serviços.
*   **Sem Mocks e Sem SQLite em Testes:** É terminantemente proibido o uso de mocks ou bancos em memória nos testes e em produção. Todos os testes automatizados (`pytest`) devem rodar contra o **PostgreSQL real bare-metal**.

### 1.6. Padrão Visual e Estrutural dos READMEs (Geral do Projeto e Módulos do Monorepo)
*   **Aplicação Universal da Regra Estética:** O padrão visual moderno, bonito, profissional e colorido é **obrigatório tanto para o `README.md` geral na raiz do projeto quanto para os arquivos `README.md` de cada um dos 4 módulos do monorepo** (`apps/backend/`, `apps/frontend-admin/`, `apps/frontend-evaluator/`, `apps/frontend-kiosk/`).
*   **Badges e Ícones Oficiais das Tecnologias Adotadas:** Todos os arquivos README do projeto devem apresentar, logo abaixo do título principal, uma galeria de badges visuais estilizados e coloridos (via Shields.io no formato `for-the-badge` ou `flat-square`, com logos oficiais e cores institucionais):
    *   *README Geral da Raiz:* FastAPI, Python 3.11+, PostgreSQL 15+, Next.js 14+, TypeScript 5+, Tailwind CSS, PWA, Shell Automation, Bare-Metal.
    *   *Backend (`apps/backend/`):* Python 3.11+, FastAPI, PostgreSQL, SQLAlchemy 2.0 Async, Pydantic v2, Pytest, Uvicorn, AsyncPG.
    *   *Frontend Admin (`apps/frontend-admin/`):* Next.js 14+, React, TypeScript, Tailwind CSS, Lucide Icons, Axios.
    *   *Frontend Evaluator (`apps/frontend-evaluator/`):* Next.js 14+, PWA, TypeScript, Tailwind CSS, HTML5 QR Scanner/ZBar, Mobile Touch UX.
    *   *Frontend Kiosk (`apps/frontend-kiosk/`):* Next.js 14+, TypeScript, Tailwind CSS, Fullscreen API, Auto-Refresh/SWR, 4K/1080p Ultra-Wide UI.
*   **Estrutura Obrigatória nos READMEs:**
    1.  **Cabeçalho com Título e Badges:** Nome em destaque, descrição de valor e galeria de badges coloridos.
    2.  **Visão Geral & Arquitetura:** Propósito da aplicação, papéis no ecossistema FECITEL e público-alvo.
    3.  **Tabela de Tecnologias & Versões:** Relação minuciosa das dependências com versões e responsabilidades.
    4.  **Mapa de Diretórios (`tree`):** Representação gráfica da organização interna de pastas e arquivos.
    5.  **Variáveis de Ambiente & Pré-requisitos:** Relação clara e documentada das variáveis de configuração.
    6.  **Guia de Execução Rápida:** Comandos de terminal diretos e menção aos scripts `.sh` de automação correspondentes.
    7.  **Portas, Rotas e Endpoints:** Tabelas formatadas com URLs locais e portas de escuta.
    8.  **Padrão de Idioma:** Redação integralmente em **português (pt-BR)**, mantendo termos de código, variáveis e tabelas em **inglês**.

---

## 2. Regras de Autenticação e Segurança

### SEC-01: Modelo Duplo de Autenticação (Admin vs. Participantes)
O sistema adota duas estratégias distintas de autenticação conforme o perfil do usuário:

1.  **Administradores do Evento (`ADMIN`):**
    *   Autenticação via `email` cadastrado e `password` mestre criptografada de alta entropia.
    *   Senhas nunca são salvas em texto puro; são criptografadas com **bcrypt** (salt rounds = 12) ou **Argon2id**.
2.  **Participantes Convencionais (`STUDENT`, `ADVISOR`, `COADVISOR`, `EVALUATOR`):**
    *   **Código de Acesso sem Senha Estática (OTP):** Participantes não possuem senha estática. A autenticação ocorre por meio de um **código único e aleatório de 8 caracteres** enviado para o e-mail cadastrado no sistema.
    *   **Formato do Código de 8 Caracteres (Caixa Alta):**
        *   Tamanho exato: 8 caracteres, **TOTALMENTE EM CAIXA ALTA (MAIÚSCULO)**.
        *   Dois primeiros dígitos: Ano corrente da edição (ex: `26` para 2026, `27` para 2027, etc.).
        *   Demais 6 caracteres: Exatamente **4 letras** e **2 números** gerados aleatoriamente.
    *   **Validação de Unicidade no Banco:** Antes de gravar e enviar qualquer código, o sistema consulta a tabela `people` para garantir que o código gerado é único no banco de dados.
    *   **Armazenamento Criptografado:** O código é armazenado de forma criptografada/hasheada (`access_code_hash`) na tabela `people`. Nunca em texto puro.
    *   **Campo Mascarado no Login:** Na tela de login, o campo para digitar esse código deve aparecer mascarado como campo de senha (`type="password"`, com botão para visualizar), impedindo que pessoas ao redor memorizem o código em ambientes públicos.

### SEC-02: Autorização via JWT e RBAC (Least Privilege)
*   Tokens JWT Bearer (`Authorization: Bearer <TOKEN>`) expiram em **12 horas** (tempo suficiente para um dia completo de feira).
*   Permissões de Perfil (RBAC):
    *   `ADMIN`: Acesso irrestrito a configurações do evento, homologação, distribuição de avaliadores, áreas, prêmios e dashboards completos.
    *   `STUDENT`: Acesso restrito de leitura e upload ao seu próprio projeto na etapa de submissão.
    *   `ADVISOR` / `COADVISOR`: Visualização dos projetos orientados; permissão exclusiva do orientador para conceder a anuência digital formal.
    *   `EVALUATOR`: Acesso restrito aos projetos alocados para si; permissão de escrita apenas na sua ficha de avaliação.

### SEC-03: Proteção Universal de Todas as Rotas por API Key (Obrigatoriedade em GET, POST, PUT, DELETE)
*   **Obrigatoriedade Universal em 100% dos Endpoints:** Todas as rotas da API (`/api/v1/*`), **incluindo expressamente todas as rotas de leitura via método `GET`**, além de mutações (`POST`, `PUT`, `DELETE`, `PATCH`), devem ser obrigatoriamente protegidas por validação de **API Key**.
*   **Correção das Rotas de Consulta (`GET`):** Nenhuma rota de leitura (ex: listagem de eventos, consulta de áreas, subáreas, prêmios, projetos ou credenciais) pode ser deixada pública ou desprotegida. Toda e qualquer requisição deve apresentar uma API Key válida.
*   **Cabeçalho Padronizado:** A chave deve ser transmitida primariamente através do cabeçalho HTTP:
    ```http
    X-API-Key: fecitel_secret_api_key_2026
    ```
    *(com suporte secundário via query parameter `?api_key=...` para ferramentas de diagnóstico ou streaming).*
*   **Rejeição Imediata com HTTP 401:** Qualquer requisição que omita o cabeçalho ou apresente uma chave divergente da configurada no ambiente (`API_KEY`) deve ser prontamente rejeitada com `HTTP 401 Unauthorized`.
*   **Segurança em Camadas (Defense-in-Depth):**
    *   Para rotas públicas ou de leitura geral da aplicação/quiosque: A API Key é a credencial de barreira que impede acesso anônimo, bots ou varreduras não autorizadas.
    *   Para rotas restritas por perfil (Admin, Aluno, Orientador, Avaliador): A API Key atua como a primeira camada de proteção de rede, e o token JWT Bearer (`Authorization: Bearer <token>`) atua como a segunda camada de controle de acesso baseado em papéis (RBAC).

### SEC-04: Identificação Oficial Única e Vínculo Institucional (`cpf` e `affiliation`)
*   **Cadastro Unificado de Participantes:** A tabela `people` armazena o Cadastro de Pessoa Física (`cpf: VARCHAR(20) NULL`) e o vínculo/perfil institucional do participante (`affiliation: VARCHAR(100) NULL`, ex: `'Aluno IFMS'`, `'Aluno Externo'`, `'Público Externo'`).
*   **Emissão de Certificados e Prestação de Contas:** O CPF é o dado canônico para identificação civil dos autores e orientadores, garantindo validade jurídica e unicidade documental na emissão dos certificados oficiais da feira.
*   **Indexação e Performance:** O campo `cpf` possui índice parcial ativo no banco (`WHERE deleted_at IS NULL`) para acelerar buscas operacionais na recepção e no credenciamento.

---

## 3. Regras de Negócio Centrais (BRs)

### BR-01: Independência Total de Eventos Simultâneos (Multi-Evento)
*   O sistema suporta múltiplos eventos simultâneos por ano.
*   Cada evento é isolado, possuindo sua própria comissão (`ADMIN`), avaliadores, trabalhos inscritos, áreas do conhecimento, premiações e participantes, sem vazamento de dados entre edições.

### BR-02: Trava Temporal ao Término do Evento
*   A data `end_date` do evento é a trava definitiva.
*   Ao expirar `end_date`, o evento entra automaticamente em modo leitura (`status = 'CLOSED'`), bloqueando alterações em projetos, alocações, notas e configurações.

### BR-03: Configuração Dinâmica de Arquivos por Evento
*   Definido pelo Administrador no cadastro do evento:
    *   **Resumo:** Configurável para `.pdf` ou `.docx` (apenas um ativo).
    *   **Banner:** Configurável para `.pdf` ou `.pptx`.
    *   **Diário de Bordo:** Estritamente `.pdf`.
    *   **Tamanho Máximo:** Limite em MB (`max_file_size_mb`) validado via streaming (`max_body_size`).

### BR-04: Cotas de Estudantes por Nível de Ensino
*   **Ensino Médio (`MEDIO`):** Máximo de **4 estudantes** por projeto.
*   **Ensino Fundamental (`FUNDAMENTAL`):** Máximo de **5 estudantes** por projeto.
*   **Educação Júnior (`JUNIOR`):** Limite configurável pelo evento.
*   Tentativas de violar o limite retornam `422 Unprocessable Entity`.

### BR-05: Equipe de Orientação e Fluxo Obrigatório de Anuência
*   Cada projeto deve ter exatamente **1 orientador** (`ADVISOR`) e no máximo **1 coorientador** (`COADVISOR`).
*   **Fluxo de Anuência Digital Obrigatória:** Ao ser submetido, o trabalho entra no status `WAITING_CONSENT`.
*   O orientador titular formalmente indicado na submissão deve autenticar-se e conceder a anuência digital formal (`POST /api/v1/projects/{id}/consent`). Essa ação registra a data/hora (`advisor_consent_at`) e promove o projeto para `SUBMITTED`.
*   **Trava Impeditiva de Homologação:** É estritamente proibido deferir ou homologar qualquer projeto sem a prévia anuência digital do orientador (`advisor_consent == True`). Tentativas retornam `HTTP 400 Bad Request`.

### BR-06: Máquina de Estados e Homologação Documental da Coordenação
Transições estritas de estado no ciclo de vida:
1.  `DRAFT`: Em preenchimento inicial pelos alunos proponentes.
2.  `WAITING_CONSENT`: Submetido pelos alunos, aguardando formalização da anuência digital pelo orientador titular.
3.  `SUBMITTED`: Anuência concedida pelo orientador, trabalho liberado para análise e homologação documental da comissão organizadora.
4.  `HOMOLOGATED`: Aprovado/deferido pela coordenação para apresentação presencial na feira (com opção de alocação de bancada `booth_number`).
5.  `REJECTED`: Indeferido pela coordenação. Exige obrigatoriamente o registro de uma justificativa formal (`rejection_reason`) para transparência com os autores.
6.  `PRESENT`: Presença confirmada pelo credenciamento físico de qualquer membro na recepção.
7.  `ABSENT`: Credenciamento da feira encerrado sem comparecimento de nenhum integrante.
8.  `UNDER_EVALUATION`: Pelo menos um avaliador abriu a ficha de notas e iniciou o preenchimento.
9.  `EVALUATED`: Todas as avaliações exigidas para o trabalho foram concluídas com parecer consolidado.

### BR-07: Verificação em Lote de Participantes e Multi-Papel Flexível
*   **Verificação em Lote:** Cadastros e submissões verificam e-mails em lote (`WHERE email IN (...)`), eliminando queries N+1.
*   **Multi-Papel:** Uma mesma pessoa pode exercer diferentes papéis no evento (ex: orientador em um trabalho e avaliador em outro) via tabela associativa `user_roles`.

### BR-08: Dupla Identificação no Crachá
Cada participante recebe um crachá com dois códigos independentes:
1.  **Código de Barras Pessoal (`barcode`):** Individual do participante, bipado para confirmar presença física e retirar camiseta/kit.
2.  **QR Code do Projeto (`qrcode_token`):** Afixado na bancada de apresentação para que os avaliadores leiam com a câmera do celular e abram a ficha de notas.
3.  **Gatilho de Presença Coletiva:** A confirmação de presença de qualquer membro da equipe no credenciamento promove automaticamente o projeto para `PRESENT`.

### BR-09: Logística Individual de Kits por Edição
*   A entrega de camisetas e kits é registrada em `event_participants`, mantendo o histórico de edições passadas.
*   **Lock Atômico Condicional:** A baixa do kit utiliza SQL atômico condicional (`UPDATE event_participants SET kit_delivered = TRUE WHERE ... AND kit_delivered = FALSE RETURNING tshirt_size;`), impedindo retiradas duplicadas em guichês simultâneos.

### BR-10: Alocação de Avaliadores em Dois Momentos (Alocação Dinâmica por Check-in e Remanejamento Manual)
1.  **Credenciamento Contínuo e Paralelo:**
    *   O check-in dos autores (que promove projetos para `PRESENT`) e o check-in dos avaliadores ocorrem de forma contínua, simultânea e paralela durante todo o evento. Não há fechamento de lote ou barreira de tempo que force esperar todos os projetos chegarem antes de iniciar as avaliações.
2.  **Momento 1 — Alocação Dinâmica no Check-in do Avaliador (Regra de Ouro $\Delta \le 1$):**
    *   **Gatilho Imediato:** Ocorre no exato instante em que a equipe organizadora realiza o check-in presencial do avaliador no evento (seja por leitura do código de barras do crachá, seja por ação no painel).
    *   **Mecanismo de Seleção:**
        1. Consulta as subáreas de especialidade cadastradas para o avaliador (`person_subareas`);
        2. Identifica os trabalhos daquela subárea que **já possuem presença confirmada no evento (`status = 'PRESENT'`)**;
        3. Exclui trabalhos com conflito de interesse (onde o avaliador é orientador, coorientador ou integrante) e trabalhos onde já está alocado;
        4. Seleciona prioritariamente os trabalhos que possuem a **menor quantidade de avaliadores alocados** naquele instante;
        5. Aloca o avaliador para os trabalhos selecionados até o teto de capacidade configurado no evento (`max_projects_per_evaluator`), assegurando a equidade e o equilíbrio da Regra de Ouro ($\Delta \le 1$).
    *   **Equalização Global Opcional:** A coordenação dispõe de ferramenta para disparo de balanceamento global a qualquer momento, equalizando alocações caso haja entrada tardia de novos trabalhos.
3.  **Momento 2 — Remanejamento Manual:**
    *   Administradores podem vincular, substituir ou remover avaliadores pontualmente a qualquer instante, com validação mandatória de impedimento e conflito de interesse.
4.  **Desvinculação Automática:** Projetos que permanecerem `ABSENT` ao final do evento têm eventuais alocações canceladas automaticamente.

### BR-11: Avaliação Mestre-Detalhe com Parecer Consolidado Único
*   `evaluations` (Mestre): Armazena projeto, avaliador, status, data/hora e um único campo de **parecer geral / observação consolidada** ao final.
*   `evaluation_items` (Detalhe): Armazena a nota numérica (0.0 a 10.0) de cada critério da ficha.
*   Critérios dinâmicos com descrição científica e/ou descrição tecnológica.

### BR-12: Sistema de Classificação Oficial e Duplo Ranqueamento (Geral por Área/Nível vs Premiações Específicas)
O sistema calcula a apuração da feira através de **dois rankings distintos e complementares**:
1.  **Ranking 1: Premiações Regulares / Gerais por Média Global das Notas (Todos os Itens de Avaliação):**
    *   **Metodologia de Cálculo:** Considera rigorosamente a média aritmética de **todos os itens/critérios da ficha de avaliação** preenchidos pelos avaliadores, sem descarte de notas extremas.
    *   **Sub-ranking 1.1 (Por Área de Conhecimento e Nível de Ensino):** Agrupa os trabalhos pela respectiva Grande Área do Conhecimento (`KnowledgeArea`) e pelo Nível de Ensino dos cursos dos integrantes (`MEDIO`, `FUNDAMENTAL`, `JUNIOR`). Exemplo: "1º, 2º e 3º lugares em Ciências Exatas e da Terra — Ensino Médio". Considera as notas de **todos os itens** de avaliação.
    *   **Sub-ranking 1.2 (Melhor Geral da Feira / Overall Best):** Classificação unificada de todos os projetos homologados e avaliados da edição do evento, apurando os trabalhos de maior média global de toda a feira, considerando as notas de **todos os itens** de avaliação.
2.  **Ranking 2: Premiações Específicas / Prêmios Temáticos (Apenas Itens Indicados):**
    *   **Metodologia de Cálculo:** Para cada premiação temática ou especial (ex: Troféu Inovação Tecnológica, Destaque em Sustentabilidade, Prêmio Patrocinador X), a pontuação é calculada considerando **exclusivamente as notas dos critérios (itens) de avaliação expressamente indicados e vinculados àquele prêmio** no momento do cadastro (`award_criteria`), aplicando seus respectivos pesos (`weight`).
    *   Projetos concorrentes são ranqueados com base restrita na média das notas obtidas nesses itens selecionados.

### BR-13: Soft Delete Universal (Proibição de Exclusão Física)
*   Todas as tabelas possuem a coluna `deleted_at: Optional[datetime] = None`.
*   A exclusão física (`DELETE FROM`) é expressamente proibida. Consultas filtram `WHERE deleted_at IS NULL`.

### BR-14: Dashboard Público de Telão (TV Kiosk) e Sigilo Absoluto
*   O sistema disponibiliza um painel público (`/tv` ou `apps/frontend-kiosk/`) para televisores e projetores do pavilhão.
*   **Sigilo Absoluto de Notas e Ranqueamentos:** É estritamente proibido exibir notas individuais, nomes de avaliadores, pareceres ou classificação parcial no telão público.
*   **Métricas Permitidas:** Apenas dados agregados da feira (participantes credenciados, projetos na bancada, avaliações concluídas por grande área e escolas presentes).
*   **Operação Autônoma:** Modo escuro por padrão, tipografia legível à distância e atualização silenciosa a cada 30 segundos sem recarregar a página.

### BR-15: Design System, Temas e Perfis de Dispositivo
*   **Paleta de Cores Oficial:** Azul Safira Acadêmico (`#1E3A8A` / `#2563EB`) combinado com Verde Teal/Esmeralda (`#0D9488` / `#10B981` no Modo Claro; `#14B8A6` no Modo Escuro).
*   **Modo Claro arejado:** No Modo Claro ("Dia"), o cabeçalho e menu lateral utilizam fundo branco puro (`#FFFFFF`) e bordas em ardósia suave (`#E2E8F0`), sem blocos escuros pesados.
*   **Modos Dia e Noite:** O usuário pode alternar os temas, gravando sua preferência no `localStorage`.
*   **Perfis de Dispositivo:**
    *   *Avaliadores:* Mobile-First em smartphones (operação com uma mão, botões de notas táteis `+`/`-`, leitura instantânea de QR Code com a câmera).
    *   *Administradores e Recepção:* Desktop e tablet para leitor de código de barras USB/Bluetooth e tabelas gerenciais.
    *   *TV Kiosk:* Resoluções 1080p e 4K landscape sem rolagem vertical.

### BR-16: Gestão de Áreas e Subáreas no Painel do Administrador do Evento
*   **Cadastro no Painel do Administrador:** Administradores têm controle total para criar, visualizar, editar e desativar (soft-delete) áreas do conhecimento e suas respectivas subáreas diretamente no **Painel de Controle do Administrador do Evento** (`apps/frontend-admin/`), com escopo vinculado à edição ativa (`knowledge_areas.event_id`).
*   **Invariante de Unicidade:** Nomes de subáreas devem ser únicos dentro da sua área mãe (`UNIQUE(area_id, name)`).
*   **Integridade Referencial e Proteção contra Exclusão:**
    *   Uma área do conhecimento não pode ser desativada se possuir subáreas ativas.
    *   Uma subárea não pode ser desativada se estiver vinculada a qualquer projeto ativo (`projects.subarea_id`) ou qualificação de avaliador ativa (`person_subareas.subarea_id`).
    *   Exclusões físicas são proibidas; aplica-se `deleted_at = NOW()` somente após validação de ausência de vínculos.
*   **Reativação Automática de Registros Desativados (Sem Erro 400):** Se o usuário tentar cadastrar uma área ou subárea com o mesmo nome de um registro que já foi desativado anteriormente no banco de dados (`deleted_at IS NOT NULL`), o sistema **não deve emitir erro 400 de duplicidade**. Em vez disso, o sistema deve reativar o registro existente, restaurando `deleted_at = NULL` e atualizando `updated_at = NOW()`.

### BR-17: CRUD de Premiações e Vínculo com Questões da Avaliação
*   **Gestão de Prêmios por Edição do Evento:** O administrador do evento pode criar, editar, listar e desativar premiações especiais, troféus de patrocinadores e menções honrosas no Painel do Evento (`/admin/awards`).
*   **Vínculo com Perguntas/Itens da Ficha de Avaliação:**
    *   Cada prêmio cadastrado pode ser vinculado a uma ou mais perguntas/critérios da ficha de avaliação (`evaluation_criteria`) através da tabela associativa `award_criteria`.
    *   O administrador seleciona na interface quais perguntas compõem a nota daquele prêmio (ex: perguntas sobre impacto social, potencial de mercado, inovação técnica), podendo atribuir pesos específicos a cada pergunta.
*   **Apuração Automatizada da Classificação do Prêmio (Ranking 2):**
    *   O sistema calcula automaticamente a classificação dos projetos concorrentes considerando **exclusivamente as notas obtidas nas perguntas/itens indicados para a premiação específica**.
    *   Diferencia-se expressamente do Ranking 1 (Premiações por Área e Nível de Ensino / Melhor Geral), que considera as notas de **todos os itens** da ficha.
    *   Os resultados permanecem confidenciais na área restrita do painel administrativo até a cerimônia oficial de premiação.
*   **Integridade:** Ao desativar um prêmio, seus vínculos com critérios são desativados logicamente. A desativação de um critério que pertença a prêmios ativos exige confirmação e aviso prévio.

### BR-18: Paginação Real Obrigatória em Todas as Listagens de Dados (Padrão: 15 Itens por Página)
*   **Obrigatoriedade Universal:** Toda página ou tela do sistema (em qualquer um dos frontends e no backend) que apresente listagens de registros ou coleções de dados (ex: edições do evento, projetos, avaliadores, premiações, logs, credenciamento, etc.) **deve obrigatoriamente implementar paginação real (server-side)**.
*   **Carregamento Estrito por Página:** É terminantemente proibido carregar todos os registros do banco de dados na memória do frontend e paginar no cliente. A requisição à API deve buscar exclusivamente os itens daquela página específica (`offset` e `limit` no SQL), protegendo o desempenho, o tráfego de rede e a integridade da aplicação.
*   **Padrão de Quantidade do Sistema:** O padrão obrigatório do sistema é de **15 itens por página** (`limit = 15`).
*   **Busca Textual Integrada com Debounce (300ms):** Telas com listagens volumosas (Edições, Projetos, etc.) devem fornecer campo de busca textual no topo com ícone e botão de limpeza. A busca deve possuir debounce de 300ms e resetar a página corrente para 1. O backend aplica o filtro textual com SQL `ilike` recalculando dinamicamente `total` e `total_pages`.
*   **Estrutura Padronizada de Resposta Paginada (Backend):**
    ```json
    {
      "items": [...],
      "total": 45,
      "page": 1,
      "limit": 15,
      "total_pages": 3
    }
    ```
*   **Controles de Navegação Obrigatórios na Interface (Frontend):**
    *   Botão "Anterior" (desabilitado na página 1).
    *   Botão "Próximo" (desabilitado na última página).
    *   Exibição dos botões numéricos de páginas com destaque visual da página ativa.
    *   Indicador textual informativo claro: *"Exibindo X a Y de Z registros"*.

### BR-19: Seleção Obrigatória de Evento Ativo e Contexto Global de Gerenciamento
*   **Seleção Prévia Obrigatória na Tela de Edições (`/events`):** Quando o sistema possui uma ou mais edições de eventos cadastradas, o administrador deve selecionar expressamente qual edição deseja gerenciar por vez através da ação "Gerenciar este Evento" na tela de Edições do Evento (`/events`).
*   **Contexto Persistente Global:** Uma vez selecionada uma edição, ela permanece ativa como contexto global em todas as telas e rotas do painel (`/`, `/areas`, `/projects`, `/evaluators`, `/allocations`, `/results`, etc.), persistida no navegador do usuário (`localStorage`), até que o administrador retorne expressamente à tela de Edições do Evento e selecione outra edição.
*   **Bloqueio de Páginas Dependentes (Gating):** Todas as páginas que operam sobre dados de um evento (visão geral, áreas do conhecimento, projetos, avaliadores, premiações, etc.) permanecem inativas/bloqueadas até que um evento seja selecionado, exibindo um alerta orientador que redireciona o usuário para a tela de Edições do Evento (`RequireActiveEvent`).
*   **Identificação Visual Contínua:** Todas as páginas ativas e cabeçalhos do sistema devem exibir claramente qual edição está sendo gerenciada no momento, com atalho direto ("Trocar Edição") para a tela de seleção.
*   **Ações na Tela de Edições:** A tela de Edições do Evento (`/events`) permite:
    *   **Selecionar para Gerenciar:** Definir a edição como o contexto ativo global no painel.
    *   **Editar Parâmetros:** Atualizar nome, datas, limites e configurações da feira (desabilitado com trava temporal se a edição estiver encerrada, conforme Regra BR-02).

---

## 4. Diretrizes Obrigatórias de Interface e Desenvolvimento (UX & DEV)

### UX-01: Posicionamento Obrigatório de Mensagens e Alertas em Janelas Modais
*   Todas as mensagens de feedback, erros de integridade ou validações de formulário disparadas em interações que ocorrem dentro de janelas modais **devem ser exibidas diretamente DENTRO do corpo da janela modal** (via prop `error` ou container de alerta interno com ícone).
*   É terminantemente proibido renderizar mensagens de erro no corpo da página principal de modo que fiquem ocultas atrás do modal ou sob o overlay escuro (`backdrop`).

### DEV-01: Diretiva `"use client";` Obrigatória para Prevenção de Telas em Branco
*   Toda página ou componente do Next.js App Router que utilize hooks do React (`useState`, `useEffect`, `useContext`, `useRef`, `useRouter`, etc.) ou acesse APIs do navegador (`localStorage`, `window`) **deve conter expressamente a diretiva `"use client";` na primeira linha absoluta do arquivo**.
*   A ausência da diretiva em componentes que usam hooks causa erro de compilação em Server Components e deixa a página em branco (*white screen*).


