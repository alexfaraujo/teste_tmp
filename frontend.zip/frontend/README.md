# 💻 Frontend Web — Irrigação Inteligente

Interface web gerencial responsiva para o produtor rural acompanhar em tempo real o status das sondas, nível de bateria, gráficos de umidade e acionamento de irrigação.

---

## 🚀 Como Executar Localmente

```bash
# 1. Instalar dependências (Node.js 18+)
npm install

# 2. Configurar variáveis de ambiente
cp .env.example .env.local

# 3. Iniciar servidor de desenvolvimento
npm run dev
```

---

## 🔌 Conexão com o Backend

O frontend se comunica exclusivamente via requisições HTTP REST com a API desenvolvida em FastAPI rodando no módulo `backend/` (`http://localhost:8000/api/v1`).

### Autenticação:
- Enviar a chave de aplicação `APP_API_KEY` do backend ou o token do Firebase Auth via cabeçalho HTTP:
  ```text
  Authorization: Bearer <SUA_CHAVE_API_OU_TOKEN>
  ```
