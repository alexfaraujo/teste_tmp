# CONTEXT.MD — Frontend Web de Irrigação Inteligente (React)

## 1. Visão Geral da Aplicação Web
Esta aplicação web frontend, desenvolvida em **React**, é a interface de controle e telemetria voltada para a gestão do sistema de irrigação inteligente instalado nas áreas verdes, canteiros e estufas do campus do **IFMS** (Instituto Federal de Mato Grosso do Sul).

O principal objetivo é proporcionar uma experiência fluida, clara e em tempo real com design **Mobile-First** (totalmente responsiva para smartphones em campo no campus, tablets e computadores), permitindo:
1. **Monitoramento em Tempo Real:** Acompanhamento das leituras coletadas por cada sonda (índice de umidade do solo, umidade bruta analógica, temperatura ambiente, nível percentual de bateria e status de conectividade online/offline).
2. **Parametrização Operacional das Sondas:**
   - Definição do limiar de umidade que dispara a irrigação (`indice_irrigar`, ex.: 35.0%).
   - Seleção do regime de irrigação: Diurna ou Noturna (`irrigacao_diurna`: `true`/`false`).
   - Ajuste do intervalo de transmissão da sonda (`intervalo_envio_segundos`).
3. **Acionamento Manual da Irrigação:** Controle manual intuitivo para ligar ou desligar a irrigação de uma sonda diretamente pela interface gráfica.
4. **Histórico e Alertas:** Visualização paginada dos logs de telemetria e indicação visual de alertas críticos (como bateria baixa < 20% ou sonda offline).

---

## 2. Contrato de Integração com o Backend (FastAPI)

A aplicação React se comunica exclusivamente com a API REST desenvolvida em FastAPI através de endpoints autenticados por cabeçalho Bearer Token:
`Authorization: Bearer <APP_API_KEY_OU_TOKEN>`

### 2.1 Mapeamento de Endpoints Utilizados pelo Frontend

| Método | Rota | Objetivo no Frontend | Payload / Parâmetros |
| :--- | :--- | :--- | :--- |
| `GET` | `/api/v1/users/me` | Identificação do usuário logado e verificação de `perfil_completo`. | Headers: `Authorization` |
| `PUT` | `/api/v1/users/me` | Atualização cadastral inicial (onboarding do responsável/usuário). | Body: `{ "nome": "..." }` |
| `GET` | `/api/v1/dashboard/summary` | Cards do topo da dashboard (`total_sondas`, `sondas_online`, `sondas_offline`, `alertas_bateria`, `ultimas_medicoes`). | Resumo consolidado |
| `GET` | `/api/v1/probes` | Listagem com filtros por status (`todos`, `online`, `offline`), `alerta_bateria` e campo de busca por nome. | Query params: `status`, `alerta_bateria`, `busca` |
| `GET` | `/api/v1/probes/{id}` | Visão detalhada de uma sonda individual, seus limiares e status atual. | Path param: `id` (UUID) |
| `POST` | `/api/v1/probes` | Modal/Formulário para cadastrar uma nova sonda (exibe a API Key gerada apenas uma vez). | Body: `{ "nome_identificador": "...", ... }` |
| `PUT` | `/api/v1/probes/{id}/config` | Atualização dos parâmetros operacionais da sonda (`indice_irrigar`, `irrigacao_diurna`, `intervalo_envio_segundos`). | Body: `{ "indice_irrigar": 35.0, "irrigacao_diurna": false, ... }` |
| `GET` | `/api/v1/probes/{id}/logs` | Tabela paginada e gráficos de histórico de medições. | Query params: `page`, `page_size`, `data_inicio`, `data_fim` |

### 2.2 Convenção de Dados (`snake_case`)
Para manter alinhamento estrito com o backend e banco de dados relacional:
* Todos os campos trafegados via JSON adotam estritamente `snake_case` (ex: `nivel_bateria`, `indice_umidade`, `irrigacao_diurna`, `indice_irrigar`, `intervalo_envio_segundos`, `nome_identificador`).

---

## 3. Arquitetura Proposta para o Frontend React

```
frontend/
├── .agents/
│   └── rules.md                # Regras invioláveis de governança, pair programming e escopo
├── docs/
│   ├── context.md              # Este documento de contexto funcional e arquitetural
│   └── history.md              # Histórico sequencial de todas as mudanças realizadas
├── public/                     # Favicons, logos e assets estáticos
├── src/
│   ├── assets/                 # Imagens e ícones
│   ├── components/             # Componentes de interface modulares e reutilizáveis
│   │   ├── common/             # Botões, inputs, cards, modais, spinners
│   │   ├── dashboard/          # Cards de métricas, filtros, status da sonda
│   │   ├── probe/              # Formulário de configuração de parâmetros, controle manual
│   │   └── telemetry/          # Tabelas e gráficos de logs de umidade/temperatura
│   ├── hooks/                  # Custom hooks para lógica desacoplada (useProbes, useDashboard, etc.)
│   ├── pages/                  # Telas da aplicação (Dashboard, Detalhes da Sonda, Configurações)
│   ├── services/               # Camada de comunicação HTTP com a API REST (api.js / axios / fetch)
│   ├── styles/                 # Estilos globais e temas
│   ├── App.jsx                 # Componente raiz
│   └── main.jsx                # Ponto de montagem React DOM
├── .env.example                # Variáveis de ambiente modelo (URL da API)
├── package.json                # Dependências do ecossistema React
└── README.md                   # Instruções de execução e documentação
```

---

## 4. Telas e Funcionalidades Principais

1. **Dashboard Principal (Visão Geral):**
   - Resumo rápido: total de sondas, quantidade online, offline e sondas em estado de alerta.
   - Grid/lista de cartões das sondas com status visual (verde para online, cinza para offline, vermelho para bateria fraca).
   - Filtro rápido e barra de busca por identificador da sonda.

2. **Cartão / Painel da Sonda:**
   - Leitura atual de umidade calibrada (%) e temperatura (°C).
   - Indicador de nível de bateria com alerta visual se < 20%.
   - **Controle Operacional / Configurações:**
     - Slider ou input para o índice de umidade para irrigar (`indice_irrigar`).
     - Alternador (Toggle Switch) para Irrigação Diurna / Noturna (`irrigacao_diurna`).
     - Botão de Acionamento Manual (Ligar / Desligar Irrigação).
     - Botão "Salvar Parâmetros" que dispara `PUT /api/v1/probes/{id}/config`.

3. **Histórico de Leituras & Gráficos:**
   - Tabela paginada com histórico de medições recebidas.
   - Gráfico de linha demonstrando a evolução temporal da umidade e temperatura.
