import React, { useState } from 'react';
import { User, Mail, CheckCircle2, ArrowRight, ShieldCheck, LogOut } from 'lucide-react';

export default function ProfileScreen({ user, onProfileSaved, onLogout }) {
  const [nome, setNome] = useState(user.nome || '');
  const [erro, setErro] = useState('');
  const [salvando, setSalvando] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!nome.trim() || nome.trim().length < 3) {
      setErro('Por favor, informe seu nome completo (mínimo de 3 caracteres).');
      return;
    }

    setSalvando(true);
    setErro('');

    setTimeout(() => {
      setSalvando(false);
      onProfileSaved({
        ...user,
        nome: nome.trim(),
        perfil_completo: true
      });
    }, 800);
  };

  return (
    <div className="profile-container">
      <div className="profile-card">
        <div className="profile-header">
          <div className="profile-icon-circle">
            <User size={36} color="#10b981" />
          </div>
          <h2>{user.perfil_completo ? 'Editar Perfil' : 'Concluir Cadastro'}</h2>
          <p className="profile-subtitle">
            {user.perfil_completo 
              ? 'Atualize seus dados de responsável pelas sondas no campus' 
              : 'Informe seu nome para liberar o acesso ao dashboard de irrigação'}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="profile-form">
          <div className="form-group">
            <label>E-mail (Autenticado)</label>
            <div className="input-icon-wrapper input-readonly">
              <Mail size={20} className="input-icon" />
              <input
                type="email"
                className="text-input"
                value={user.email || 'seu.email@exemplo.com'}
                readOnly
                disabled
              />
              <span className="email-verified-tag">
                <CheckCircle2 size={16} color="#10b981" />
                <span>Verificado</span>
              </span>
            </div>
            <span className="form-help-text">
              Este e-mail está vinculado à sua sessão e não pode ser alterado aqui.
            </span>
          </div>

          <div className="form-group">
            <label htmlFor="user-name">Nome do Responsável</label>
            <div className="input-icon-wrapper">
              <User size={20} className="input-icon" />
              <input
                id="user-name"
                type="text"
                className="text-input"
                placeholder="Ex: Carlos Eduardo"
                value={nome}
                onChange={(e) => setNome(e.target.value)}
                disabled={salvando}
                required
                autoFocus
              />
            </div>
          </div>

          {erro && (
            <div className="feedback-alert error-alert">
              <span>{erro}</span>
            </div>
          )}

          <div className="profile-actions">
            <button type="submit" className="btn btn-save-profile" disabled={salvando}>
              {salvando ? 'Salvando no Banco...' : (
                <>
                  <span>{user.perfil_completo ? 'Salvar Alterações' : 'Concluir e Acessar Dashboard'}</span>
                  <ArrowRight size={18} />
                </>
              )}
            </button>

            {onLogout && (
              <button type="button" className="btn btn-logout" onClick={onLogout}>
                <LogOut size={16} />
                <span>Encerrar Sessão</span>
              </button>
            )}
          </div>
        </form>
      </div>
    </div>
  );
}
