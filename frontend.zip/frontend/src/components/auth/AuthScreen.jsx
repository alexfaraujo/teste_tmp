import React, { useState } from 'react';
import { Droplets, Mail, ArrowRight, ShieldCheck, Sparkles } from 'lucide-react';

export default function AuthScreen({ onLoginSuccess }) {
  const [email, setEmail] = useState('');
  const [mensagem, setMensagem] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!email || !email.includes('@')) {
      setMensagem('Por favor, informe um endereço de e-mail válido.');
      return;
    }

    setLoading(true);
    setMensagem('Enviando autenticação para o seu e-mail...');

    setTimeout(() => {
      setLoading(false);
      setMensagem('E-mail verificado com sucesso! Redirecionando para o onboarding...');
      setTimeout(() => {
        onLoginSuccess({
          email: email.trim(),
          nome: '',
          perfil_completo: false
        });
      }, 1000);
    }, 1200);
  };

  const handleDemoLogin = () => {
    onLoginSuccess({
      email: 'gestor.ifms@exemplo.com',
      nome: '',
      perfil_completo: false
    });
  };

  return (
    <div className="auth-container">
      <div className="auth-card">
        <div className="auth-header">
          <div className="auth-icon-circle">
            <Droplets size={36} color="#10b981" />
          </div>
          <h2>Irrigação Inteligente</h2>
          <p className="auth-subtitle">Campus IFMS — Acesso Seguro</p>
        </div>

        <form onSubmit={handleSubmit} className="auth-form">
          <div className="form-group">
            <label htmlFor="auth-email">E-mail</label>
            <div className="input-icon-wrapper">
              <Mail size={20} className="input-icon" />
              <input
                id="auth-email"
                type="email"
                className="text-input"
                placeholder="seu.email@exemplo.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                disabled={loading}
                required
              />
            </div>
            <span className="form-help-text">
              Enviaremos um link de confirmação direto para sua caixa de entrada.
            </span>
          </div>

          {mensagem && (
            <div className="feedback-alert">
              <span>{mensagem}</span>
            </div>
          )}

          <button type="submit" className="btn btn-primary btn-block" disabled={loading}>
            {loading ? 'Verificando...' : (
              <>
                <span>Acessar com E-mail</span>
                <ArrowRight size={18} />
              </>
            )}
          </button>
        </form>

        <div className="auth-divider">
          <span>OU</span>
        </div>

        <button 
          type="button" 
          className="btn btn-demo btn-block"
          onClick={handleDemoLogin}
        >
          <span>Acesso Rápido</span>
        </button>
      </div>
    </div>
  );
}
