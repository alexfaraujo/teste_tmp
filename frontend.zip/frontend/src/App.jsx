import React, { useState, useEffect } from 'react';
import { 
  Droplets, 
  Thermometer, 
  Battery, 
  Sun, 
  Moon, 
  Power, 
  Radio, 
  Save, 
  Activity, 
  AlertTriangle 
} from 'lucide-react';
import AuthScreen from './components/auth/AuthScreen.jsx';
import ProfileScreen from './components/profile/ProfileScreen.jsx';
import './App.css';

export default function App() {
  const [currentUser, setCurrentUser] = useState(() => {
    try {
      const savedUser = localStorage.getItem('irrigacao_user');
      return savedUser ? JSON.parse(savedUser) : null;
    } catch {
      return null;
    }
  });

  const [currentScreen, setCurrentScreen] = useState(() => {
    try {
      const savedUser = localStorage.getItem('irrigacao_user');
      const savedScreen = localStorage.getItem('irrigacao_screen');
      if (savedUser) {
        const parsed = JSON.parse(savedUser);
        if (!parsed.perfil_completo) {
          return 'profile';
        }
        return savedScreen === 'profile' ? 'profile' : 'dashboard';
      }
      return 'auth';
    } catch {
      return 'auth';
    }
  });

  const handleLoginSuccess = (userData) => {
    setCurrentUser(userData);
    localStorage.setItem('irrigacao_user', JSON.stringify(userData));

    if (!userData.perfil_completo) {
      setCurrentScreen('profile');
      localStorage.setItem('irrigacao_screen', 'profile');
    } else {
      setCurrentScreen('dashboard');
      localStorage.setItem('irrigacao_screen', 'dashboard');
    }
  };

  const handleProfileSaved = (updatedUser) => {
    setCurrentUser(updatedUser);
    localStorage.setItem('irrigacao_user', JSON.stringify(updatedUser));
    setCurrentScreen('dashboard');
    localStorage.setItem('irrigacao_screen', 'dashboard');
  };

  const handleEditProfile = () => {
    setCurrentScreen('profile');
    localStorage.setItem('irrigacao_screen', 'profile');
  };

  const handleLogout = () => {
    localStorage.removeItem('irrigacao_user');
    localStorage.removeItem('irrigacao_screen');
    setCurrentUser(null);
    setCurrentScreen('auth');
  };

  const userInitial = (currentUser?.nome?.trim()?.[0] || currentUser?.email?.trim()?.[0] || 'U').toUpperCase();

  const [probe, setProbe] = useState({
    id: 'sonda-01',
    nome_identificador: 'Sonda 01 — Canteiro Central',
    localizacao: 'Horta Experimental (Bloco C)',
    online: true,
    nivel_bateria: 85.0,
    temperatura: 26.4,
    umidade_bruta: 1980,
    indice_umidade: 42.5,
    indice_irrigar: 35.0,
    irrigacao_diurna: false,
    intervalo_envio_segundos: 600,
    irrigacao_manual_ativa: false
  });

  const [indiceInput, setIndiceInput] = useState(String(probe.indice_irrigar));
  const [mensagem, setMensagem] = useState('');

  const handleToggleModo = () => {
    setProbe(prev => ({
      ...prev,
      irrigacao_diurna: !prev.irrigacao_diurna
    }));
  };

  const handleToggleManual = () => {
    setProbe(prev => ({
      ...prev,
      irrigacao_manual_ativa: !prev.irrigacao_manual_ativa
    }));
  };

  const handleIndiceChange = (e) => {
    const valor = e.target.value;
    if (valor === '') {
      setIndiceInput('');
      return;
    }
    const regexNumero = /^\d*\.?\d*$/;
    if (regexNumero.test(valor)) {
      const num = parseFloat(valor);
      if (!isNaN(num) && num <= 100) {
        setIndiceInput(valor);
      }
    }
  };

  const handleSalvarConfig = () => {
    if (indiceInput === '') {
      setMensagem('Informe um valor de umidade válido (0 a 100%)');
      return;
    }
    const valorFinal = parseFloat(indiceInput);
    if (isNaN(valorFinal) || valorFinal < 0 || valorFinal > 100) {
      setMensagem('A umidade deve estar entre 0 e 100%');
      return;
    }
    setProbe(prev => ({
      ...prev,
      indice_irrigar: valorFinal
    }));
    setMensagem('Configurações salvas com sucesso!');
    setTimeout(() => setMensagem(''), 3000);
  };

  if (currentScreen === 'auth') {
    return <AuthScreen onLoginSuccess={handleLoginSuccess} />;
  }

  if (currentScreen === 'profile') {
    return (
      <ProfileScreen 
        user={currentUser || { email: 'servidor@ifms.edu.br', nome: '', perfil_completo: false }} 
        onProfileSaved={handleProfileSaved} 
        onLogout={handleLogout}
      />
    );
  }

  return (
    <div className="app-layout">
      <header className="app-header">
        <div>
          <div className="header-title-group">
            <Droplets size={32} color="#10b981" />
            <h1>Irrigação Inteligente</h1>
          </div>
          <p className="campus-subtitle">Campus IFMS — Monitoramento e Gestão de Recursos Hídricos</p>
        </div>

        <div className="header-user-actions">
          <button 
            type="button" 
            className="user-avatar-btn" 
            onClick={handleEditProfile}
            title={`Meu Perfil (${currentUser?.nome || 'Usuário'})`}
            aria-label="Acessar Perfil"
          >
            {userInitial}
          </button>

          <button type="button" className="btn-header-logout" onClick={handleLogout}>
            Sair
          </button>
        </div>
      </header>

      <section className="metrics-grid">
        <div className="metric-card">
          <div className="metric-info">
            <h3>Total de Sondas</h3>
            <div className="metric-value">1</div>
          </div>
          <Radio size={30} color="var(--text-surface-muted)" />
        </div>

        <div className="metric-card">
          <div className="metric-info">
            <h3>Sondas Online</h3>
            <div className="metric-value" style={{ color: '#047857' }}>1</div>
          </div>
          <Activity size={30} color="#047857" />
        </div>

        <div className="metric-card">
          <div className="metric-info">
            <h3>Sondas Offline</h3>
            <div className="metric-value" style={{ color: 'var(--status-offline)' }}>0</div>
          </div>
          <Radio size={30} color="var(--status-offline)" />
        </div>

        <div className="metric-card">
          <div className="metric-info">
            <h3>Alertas de Bateria</h3>
            <div className="metric-value" style={{ color: probe.nivel_bateria < 20 ? 'var(--status-danger)' : 'var(--text-surface-muted)' }}>
              {probe.nivel_bateria < 20 ? 1 : 0}
            </div>
          </div>
          <AlertTriangle size={30} color={probe.nivel_bateria < 20 ? 'var(--status-danger)' : 'var(--text-surface-muted)'} />
        </div>
      </section>

      <section className="probes-section">
        <div className="section-header">
          <h2>Sondas em Monitoramento</h2>
          {mensagem && <span style={{ color: '#34d399', fontWeight: 700, fontSize: '1rem' }}>{mensagem}</span>}
        </div>

        <div className="probes-grid">
          <article className="probe-card">
            <div className="probe-card-header">
              <div>
                <h3 className="probe-title">{probe.nome_identificador}</h3>
                <p className="probe-location">{probe.localizacao}</p>
              </div>
              <span className={`status-tag ${probe.online ? 'status-online' : 'status-offline'}`}>
                {probe.online ? '● Online' : '○ Offline'}
              </span>
            </div>

            <div className="telemetry-row">
              <div className="telemetry-item">
                <span className="telemetry-label">Umidade</span>
                <span className="telemetry-val telemetry-umidade">
                  {probe.indice_umidade.toFixed(1)}%
                </span>
              </div>

              <div className="telemetry-item">
                <span className="telemetry-label">Temperatura</span>
                <span className="telemetry-val telemetry-temp">
                  {probe.temperatura.toFixed(1)}°C
                </span>
              </div>

              <div className="telemetry-item">
                <span className="telemetry-label">Bateria</span>
                <div className="telemetry-val-group">
                  <span 
                    className={`telemetry-val telemetry-bateria ${probe.nivel_bateria < 20 ? 'alerta' : ''}`}
                    style={{ color: probe.nivel_bateria < 20 ? '#dc2626' : '#14532d' }}
                  >
                    {probe.nivel_bateria.toFixed(0)}%
                  </span>
                </div>
              </div>
            </div>

            <div className="control-box">
              <div className="control-item">
                <label htmlFor="input-indice">Irrigar quando umidade for menor que</label>
                <div style={{ display: 'inline-flex', alignItems: 'center', gap: '0.35rem' }}>
                  <input
                    id="input-indice"
                    type="text"
                    inputMode="decimal"
                    className="control-input"
                    value={indiceInput}
                    onChange={handleIndiceChange}
                    placeholder="35"
                  />
                  <span style={{ fontWeight: 700 }}>%</span>
                </div>
              </div>

              <div className="control-item">
                <span>Horário Permitido:</span>
                <button 
                  type="button" 
                  className={`btn ${probe.irrigacao_diurna ? 'btn-mode-diurno' : 'btn-mode-noturno'}`} 
                  onClick={handleToggleModo}
                  title="Clique para alternar entre diurno e noturno"
                >
                  {probe.irrigacao_diurna ? (
                    <><Sun size={22} color="#d97706" /> Modo Diurno</>
                  ) : (
                    <><Moon size={22} color="#7c3aed" /> Modo Noturno</>
                  )}
                </button>
              </div>

              <div className="actions-row">
                <button
                  type="button"
                  className={`btn ${probe.irrigacao_manual_ativa ? 'btn-power-on' : 'btn-power-off'}`}
                  onClick={handleToggleManual}
                >
                  <Power size={20} />
                  {probe.irrigacao_manual_ativa ? 'Irrigação Ligada' : 'Irrigação Desligada'}
                </button>

                <button
                  type="button"
                  className="btn btn-save"
                  onClick={handleSalvarConfig}
                >
                  <Save size={20} />
                  Salvar
                </button>
              </div>
            </div>
          </article>
        </div>
      </section>
    </div>
  );
}
