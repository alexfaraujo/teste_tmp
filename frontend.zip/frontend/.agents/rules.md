# RULES.MD — Regras de Negócio, Desenvolvimento e Governança do Frontend (React)

Este documento estabelece as regras estritas e obrigatórias de conduta, fluxo de trabalho, governança, segurança, stack tecnológica e padrões de desenvolvimento que QUALQUER agente de IA deve seguir ao atuar no desenvolvimento do Frontend deste projeto.

---

## 1. Diretrizes de Autoridade, Governança e Controle do Usuário (Inviolável)

* **Propriedade do Projeto:** O usuário é o único dono do projeto e o Gestor final responsável por definir, aprovar e autorizar todo e qualquer ajuste no sistema.
* **Decisões Compartilhadas (Pair Programming):** Todo o desenvolvimento deve ser realizado de forma estritamente colaborativa. Nenhuma decisão arquitetural, funcional ou estrutural pode ser tomada autonomamente sem a análise e aprovação expressa do usuário.
* **Arquitetura de Desenvolvimento Incremental (Etapa por Etapa):** O desenvolvimento deve ser estritamente **incremental e modular**. Cada nova funcionalidade, módulo ou componente deve ser fatiado em etapas pequenas, testáveis e independentes.
* **Proibido Iniciar Novas Etapas Sem Autorização:** O agente está **TERMINANTEMENTE PROIBIDO** de iniciar a codificação ou execução de uma nova etapa sem receber a autorização expressa e por escrito do Gestor no chat.
* **Pausa Obrigatória entre Etapas (Checkpoint de Validação):** Ao concluir qualquer etapa incremental, tarefa ou entrega física de código/documentação, o agente **DEVE PARAR IMEDIATAMENTE**, apresentar um resumo transparente do que foi feito e **AGUARDAR A VALIDAÇÃO, TESTE E APROVAÇÃO FORMAL DO USUÁRIO** antes de começar a implementação de qualquer outra parte.
* **Alterações Apenas Sob Pedido Explícito:** O agente **NÃO deve fazer nenhuma alteração** no código, estrutura de arquivos ou configurações sem um pedido ou autorização explícita do usuário.
* **Transparência Total e Resumo Pré-Push (Regra do Gestor):** Em qualquer mudança efetuada, o agente DEVE passar todas as informações detalhadas ao usuário — exatamente o que foi feito, arquivos tocados e um resumo completo — para que o usuário possa validar e posteriormente ser realizado o push na branch.

---

## 2. Restrição Estrita de Escopo (Fronteira do Frontend)

* **Escopo Exclusivo do Frontend:** Todas as alterações realizadas pelo agente serão **APENAS E UNICAMENTE na pasta `frontend/`**.
* **Congelamento dos Demais Módulos:** Todo o restante do repositório (`backend/`, `firmware/`, scripts de raiz, workflows não relacionados, etc.) está **CONGELADO** e NÃO será alterado de maneira alguma.
* **Comunicação com Backend via Contrato REST:** O frontend deve consumir a API REST do backend conforme especificado na documentação do backend, sem tentar modificar o backend para adequar o frontend.

---

## 3. Rastreabilidade, Histórico de Mudanças e Material Didático

### 3.1 Registro de Mudanças (`frontend/docs/history.md`)
* É obrigatório registrar **toda e qualquer mudança** feita pelo agente no arquivo `frontend/docs/history.md`.
* Cada registro deve conter obrigatoriamente:
  - Identificador sequencial da etapa (`[HIST-FE-XXX]`).
  - Data e hora exata da alteração.
  - Objetivo e escopo da etapa.
  - Mudanças efetuadas e arquivos manipulados.
  - Resumo transparente para validação e posterior push.
  - Métricas de esforço estimadas (Humano, Híbrido, IA).

### 3.2 Material Didático de React para Iniciantes (`react-irrigação`)
* Manter e alimentar a pasta externa na Área de Trabalho: `C:\Users\Windows11\Desktop\react-irrigação`.
* A cada etapa ou modificação no projeto, gerar um documento didático em formato de aula/tutorial para iniciantes contendo:
  - O que foi construído e o porquê.
  - Conceitos de React abordados de forma simples e intuitiva (Componentes, JSX, Props, State, Hooks, Renderização, etc.).
  - Trechos de código comentados linha a linha.
  - Dicas práticas de boas práticas no ecossistema React.

---

## 4. Stack Tecnológica e Padrões de Código do Frontend

* **Biblioteca Principal:** React (versão moderna com Function Components e Hooks).
* **Estilo e Responsividade:** Design **Mobile-First**, priorizando o uso em smartphones e tablets de campo, com layout responsivo para desktop.
* **Comunicação com API Backend:**
  - Consumo via `fetch` ou `axios`.
  - Conformidade com o backend: payloads e respostas utilizam `snake_case` (ex.: `nivel_bateria`, `indice_irrigar`, `irrigacao_diurna`).
  - Variáveis de ambiente configuráveis para URL da API (`VITE_API_URL` ou `REACT_APP_API_URL` / `.env`).
* **Segurança e Autenticação:**
  - Envio do cabeçalho `Authorization: Bearer <TOKEN_OU_API_KEY>` em todas as requisições autenticadas.
  - Zero credenciais reais versionadas em arquivos de exemplo (`.env.example`).
* **Clean Code & Boas Práticas:**
  - Componentes pequenos, reutilizáveis e com responsabilidade única.
  - Separação clara entre componentes de interface (UI), lógica de negócio (Hooks customizados) e serviços de API (`services/`).

---

## 5. Versionamento e Regra Estrita de Git Push

* **Commits Locais por Checkpoint:** A cada etapa concluída e validada pelo usuário, organizar as alterações para commit local utilizando Conventional Commits em português (`feat:`, `fix:`, `docs:`, `chore:`).
* **Proibição Absoluta de `git push` Autônomo:** O agente está **TERMINANTEMENTE PROIBIDO** de executar `git push` sem autorização expressa e por escrito do Gestor no chat.
