import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Configuração do Vite para aplicação React
// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    port: 3000,
    open: false,
    host: true
  }
});
