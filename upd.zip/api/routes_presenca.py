from fastapi import APIRouter, Depends, Request, Form, UploadFile, File
from fastapi.responses import RedirectResponse, HTMLResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session, joinedload
from datetime import datetime, timedelta, timezone
import urllib.parse
from app.db.database import get_db
from app.models.evento import Evento
from app.models.presenca import Presenca, PhotoEvent, ReportEvent
from app.services.imagem_service import process_image_for_gallery
import os
import time
import shutil
from app.core.config import settings

router = APIRouter(tags=["presenca"])
templates = Jinja2Templates(directory="app/templates")
templates.env.globals['EMAIL_ADDRESS'] = settings.email_address

@router.get("/frequencia", response_class=HTMLResponse)
def frequencia_form(request: Request):
    if "user_id" not in request.session:
        return RedirectResponse(url="/", status_code=303)
    return templates.TemplateResponse(request=request, name="frequencia.html")

def has_overlap(e1_start: datetime, e1_end: datetime, e2_start: datetime, e2_end: datetime):
    # Two intervals overlap if max(start1, start2) < min(end1, end2)
    return max(e1_start, e2_start) < min(e1_end, e2_end)

@router.post("/frequencia")
def registrar_frequencia(request: Request, event_code: str = Form(...), db: Session = Depends(get_db)):
    if "user_id" not in request.session:
        return RedirectResponse(url="/", status_code=303)
        
    user_id = request.session["user_id"]
    event_code = event_code.lower() # No banco está salvo em minúsculo, mas o usuário pode digitar maiúsculo. Ops, my routes_eventos.py gerou maiúsculo, wait, "O codigo do evento deve estar sempre em minúsculo na tabela." 
    # Vou jogar pra lower por precaução e garantir case insensitive.
    
    evento = db.query(Evento).filter(
        (Evento.codigo == event_code) | (Evento.codigo == event_code.upper()) | (Evento.codigo == event_code.lower()),
        Evento.deleted_at.is_(None)
    ).first()
    
    if not evento:
        err = urllib.parse.quote("Evento não encontrado ou código inválido.")
        return RedirectResponse(url=f"/frequencia?error={err}", status_code=303)
        
    now = datetime.now(timezone.utc).astimezone()
    hoje = now.date()
    
    # Validação Crítica 1: A data atual deve ser exatamente igual à data do evento.
    if evento.data_inicio != hoje:
        err = urllib.parse.quote(f"Este evento não ocorre hoje. Data: {evento.data_inicio.strftime('%d/%m/%Y')}")
        return RedirectResponse(url=f"/frequencia?error={err}", status_code=303)
        
    # Validação Crítica 2: Horário entre inicio e (termino + 1h)
    start_dt = datetime.combine(hoje, evento.hora_inicio).astimezone()
    duration_hrs = float(evento.carga_horaria)
    end_dt = start_dt + timedelta(hours=duration_hrs)
    end_dt_tolerancia = end_dt + timedelta(hours=1)
    
    if now < start_dt:
        err = urllib.parse.quote("O evento ainda não começou.")
        return RedirectResponse(url=f"/frequencia?error={err}", status_code=303)
        
    if now > end_dt_tolerancia:
        err = urllib.parse.quote("O período de tolerância para registrar presença neste evento já encerrou.")
        return RedirectResponse(url=f"/frequencia?error={err}", status_code=303)
        
    # Validação Crítica 3: Impede registros duplicados no mesmo evento.
    ja_registrou = db.query(Presenca).filter(Presenca.pessoa_id == user_id, Presenca.evento_id == evento.id).first()
    if ja_registrou:
        err = urllib.parse.quote("Você já registrou presença neste evento.")
        return RedirectResponse(url=f"/frequencia?error={err}", status_code=303)
        
    # Validação Crítica 4: Sobreposição
    presencas_hoje = db.query(Presenca).join(Evento).filter(
        Presenca.pessoa_id == user_id,
        Evento.data_inicio == hoje
    ).options(joinedload(Presenca.evento)).all()
    
    for p in presencas_hoje:
        e2 = p.evento
        e2_start = datetime.combine(hoje, e2.hora_inicio).astimezone()
        e2_end = e2_start + timedelta(hours=float(e2.carga_horaria))
        
        # Check overlap
        if has_overlap(start_dt, end_dt, e2_start, e2_end):
            err = urllib.parse.quote(f"Conflito de horário! Você já possui presença no evento: {e2.nome}")
            return RedirectResponse(url=f"/frequencia?error={err}", status_code=303)
            
    # Registrar
    nova_presenca = Presenca(
        pessoa_id=user_id,
        evento_id=evento.id,
        endereco_ip=request.client.host
    )
    db.add(nova_presenca)
    db.commit()
    
    return RedirectResponse(url="/frequencia?success=true", status_code=303)

@router.get("/evento/{evento_id}/galeria", response_class=HTMLResponse)
def galeria_evento(request: Request, evento_id: int, db: Session = Depends(get_db)):
    if "user_id" not in request.session:
        return RedirectResponse(url="/", status_code=303)
        
    user_id = request.session["user_id"]
    
    # Check if user has presence
    presenca = db.query(Presenca).filter(Presenca.evento_id == evento_id, Presenca.pessoa_id == user_id).first()
    if not presenca:
        return RedirectResponse(url="/perfil?error=Acesso+negado", status_code=303)
        
    fotos = db.query(PhotoEvent).options(joinedload(PhotoEvent.pessoa)).filter(
        PhotoEvent.evento_id == evento_id, 
        PhotoEvent.pessoa_id == user_id, 
        PhotoEvent.status == 'ativo'
    ).all()
    minhas_fotos_count = len(fotos)
    
    evento = presenca.evento
    start_dt = datetime.combine(evento.data_inicio, evento.hora_inicio).astimezone()
    if datetime.now(timezone.utc).astimezone() > start_dt + timedelta(hours=72):
        pode_enviar = False
    else:
        pode_enviar = True
    
    return templates.TemplateResponse(request=request, name="evento_galeria.html", context={"evento_id": evento_id, "fotos": fotos, "minhas_fotos_count": minhas_fotos_count, "user_id": user_id, "pode_enviar": pode_enviar})

@router.get("/evento/{evento_id}/relato", response_class=HTMLResponse)
def relato_evento(request: Request, evento_id: int, db: Session = Depends(get_db)):
    if "user_id" not in request.session:
        return RedirectResponse(url="/", status_code=303)
        
    user_id = request.session["user_id"]
    
    # Check presence
    presenca = db.query(Presenca).filter(Presenca.evento_id == evento_id, Presenca.pessoa_id == user_id).first()
    if not presenca:
        return RedirectResponse(url="/perfil?error=Acesso+negado", status_code=303)
        
    # Check 72 hours from event start
    evento = presenca.evento
    start_dt = datetime.combine(evento.data_inicio, evento.hora_inicio).astimezone()
    if datetime.now(timezone.utc).astimezone() > start_dt + timedelta(hours=72):
        pode_enviar = False
    else:
        pode_enviar = True
        
    meu_relato = db.query(ReportEvent).filter(ReportEvent.evento_id == evento_id, ReportEvent.pessoa_id == user_id, ReportEvent.status == 'ativo').first()
    
    return templates.TemplateResponse(request=request, name="evento_relato.html", context={"evento": evento, "meu_relato": meu_relato, "pode_enviar": pode_enviar})

@router.post("/upload_event_photo")
def upload_foto_evento(request: Request, event_id: int = Form(...), descricao: str = Form(""), event_photo: UploadFile = File(...), db: Session = Depends(get_db)):
    if "user_id" not in request.session:
        return RedirectResponse(url="/", status_code=303)
        
    user_id = request.session["user_id"]
    
    presenca = db.query(Presenca).filter(Presenca.evento_id == event_id, Presenca.pessoa_id == user_id).first()
    if not presenca:
        return RedirectResponse(url="/perfil?error=Acesso+negado", status_code=303)
        
    evento = presenca.evento
    start_dt = datetime.combine(evento.data_inicio, evento.hora_inicio).astimezone()
    if datetime.now(timezone.utc).astimezone() > start_dt + timedelta(hours=72):
        return RedirectResponse(url=f"/evento/{event_id}/galeria?error=Tempo+esgotado+para+envio+de+fotos", status_code=303)
    
    # Check 10 photos limit
    active_photos = db.query(PhotoEvent).filter(PhotoEvent.evento_id == event_id, PhotoEvent.pessoa_id == user_id, PhotoEvent.status == 'ativo').count()
    if active_photos >= 10:
        return RedirectResponse(url=f"/evento/{event_id}/galeria?error=Limite+de+10+fotos+atingido", status_code=303)
        
    if event_photo and event_photo.filename:
        ext = event_photo.filename.split(".")[-1].lower()
        if ext in ["jpg", "jpeg", "png"]:
            original_dir = os.path.join("static", "event_photos", "original")
            processed_dir = os.path.join("static", "event_photos", "processed")
            os.makedirs(original_dir, exist_ok=True)
            os.makedirs(processed_dir, exist_ok=True)
            
            timestamp = int(time.time())
            base_name = f"evt_{event_id}_usr_{user_id}_{timestamp}"
            original_path = os.path.join(original_dir, f"{base_name}.{ext}")
            processed_path = os.path.join(processed_dir, f"{base_name}.jpg")
            
            with open(original_path, "wb") as buffer:
                shutil.copyfileobj(event_photo.file, buffer)
                
            # Process image
            logo_path = os.path.join("static", "images", "logo_transp.png")
            if not os.path.exists(logo_path):
                logo_path = None # Will run without watermark if missing
                
            process_image_for_gallery(original_path, processed_path, watermark_path=logo_path)
            
            nova_foto = PhotoEvent(
                evento_id=event_id,
                pessoa_id=user_id,
                caminho_arquivo=f"event_photos/processed/{base_name}.jpg",
                descricao=descricao
            )
            db.add(nova_foto)
            db.commit()
            
    return RedirectResponse(url=f"/evento/{event_id}/galeria", status_code=303)

@router.post("/report")
def enviar_relato(request: Request, event_id: int = Form(...), relato: str = Form(...), db: Session = Depends(get_db)):
    if "user_id" not in request.session:
        return RedirectResponse(url="/", status_code=303)
        
    user_id = request.session["user_id"]
    
    presenca = db.query(Presenca).filter(Presenca.evento_id == event_id, Presenca.pessoa_id == user_id).first()
    if not presenca:
        return RedirectResponse(url="/perfil?error=Acesso+negado", status_code=303)
        
    # Validation 72h from event start
    evento = presenca.evento
    start_dt = datetime.combine(evento.data_inicio, evento.hora_inicio).astimezone()
    if datetime.now(timezone.utc).astimezone() > start_dt + timedelta(hours=72):
        return RedirectResponse(url=f"/evento/{event_id}/relato?error=Tempo+esgotado+para+envio+de+relato", status_code=303)
        
    # Check if already sent
    existing = db.query(ReportEvent).filter(ReportEvent.evento_id == event_id, ReportEvent.pessoa_id == user_id, ReportEvent.status == 'ativo').first()
    if existing:
        return RedirectResponse(url=f"/evento/{event_id}/relato?error=Relato+já+enviado", status_code=303)
        
    novo_relato = ReportEvent(
        evento_id=event_id,
        pessoa_id=user_id,
        relato=relato
    )
    db.add(novo_relato)
    db.commit()
    
    return RedirectResponse(url=f"/evento/{event_id}/relato?success=true", status_code=303)

@router.post("/delete_photo/{photo_id}")
def delete_photo(request: Request, photo_id: int, db: Session = Depends(get_db)):
    if "user_id" not in request.session:
        return RedirectResponse(url="/", status_code=303)
        
    user_id = request.session["user_id"]
    foto = db.query(PhotoEvent).filter(PhotoEvent.id == photo_id).first()
    
    if foto:
        now = datetime.now(timezone.utc).astimezone()
            
        evento = foto.evento
        start_dt = datetime.combine(evento.data_inicio, evento.hora_inicio).astimezone()

        # Check if user is organizer
        from app.models.evento import EventoOrganizador
        is_moderator = db.query(EventoOrganizador).filter(
            EventoOrganizador.evento_id == evento.id,
            EventoOrganizador.pessoa_id == user_id
        ).first()

        can_delete = False
        
        if foto.pessoa_id == user_id:
            if now <= foto.data_upload + timedelta(hours=24):
                can_delete = True
                
        if is_moderator:
            if now <= start_dt + timedelta(hours=72):
                can_delete = True
                
        if can_delete:
            foto.status = 'inativo'
            db.commit()
            
    # Redirect back to where they came from (galeria or painel)
    referer = request.headers.get("referer", f"/evento/{foto.evento_id}/galeria" if foto else "/perfil")
    return RedirectResponse(url=referer, status_code=303)

@router.post("/delete_report/{report_id}")
def delete_report(request: Request, report_id: int, db: Session = Depends(get_db)):
    if "user_id" not in request.session:
        return RedirectResponse(url="/", status_code=303)
        
    user_id = request.session["user_id"]
    relato = db.query(ReportEvent).filter(ReportEvent.id == report_id).first()
    
    if relato:
        now = datetime.now(timezone.utc).astimezone()
            
        evento = relato.evento
        start_dt = datetime.combine(evento.data_inicio, evento.hora_inicio).astimezone()

        from app.models.evento import EventoOrganizador
        is_moderator = db.query(EventoOrganizador).filter(
            EventoOrganizador.evento_id == evento.id,
            EventoOrganizador.pessoa_id == user_id
        ).first()

        can_delete = False
        
        if relato.pessoa_id == user_id:
            if now <= relato.data_upload + timedelta(hours=24):
                can_delete = True
                
        if is_moderator:
            if now <= start_dt + timedelta(hours=72):
                can_delete = True
                
        if can_delete:
            relato.status = 'inativo'
            db.commit()
                
    referer = request.headers.get("referer", f"/evento/{relato.evento_id}/relato" if relato else "/perfil")
    return RedirectResponse(url=referer, status_code=303)
