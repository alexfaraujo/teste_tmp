import multiprocessing
import os

# Configurações do Gunicorn
bind = "0.0.0.0:5000"  # Altere a porta aqui (5000 é um exemplo)
workers = multiprocessing.cpu_count() * 2 + 1
timeout = 120
keepalive = 5
max_requests = 1000
max_requests_jitter = 50

# Configurações de Log
accesslog = None  # Desativa log de acesso
errorlog = "-"    # Mantém log de erro no terminal
loglevel = "warning"  # Reduz o nível de log para warning
access_log_format = '%(h)s %(l)s %(u)s %(t)s "%(r)s" %(s)s %(b)s "%(f)s" "%(a)s"'
disable_redirect_access_to_syslog = True

# Configurações de Segurança
forwarded_allow_ips = "*"
proxy_protocol = True

# Configurações de Performance
worker_connections = 1000
threads = 2
worker_tmp_dir = "/dev/shm"

# Configurações de Host
host = os.environ.get('HOST', '0.0.0.0')
port = int(os.environ.get('PORT', 5000))
bind = f"{host}:{port}" 