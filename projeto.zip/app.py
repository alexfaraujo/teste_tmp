from flask import Flask, render_template, request, redirect, url_for, session, flash, g, jsonify
import sqlite3
import os
import io
import qrcode
import io
import qrcode
from flask import send_file
from datetime import datetime, timedelta
from PIL import Image

app = Flask(__name__)
app.secret_key = 'supersecretkey'  # Change this in production!
DATABASE = 'perfil.db'

def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row
    return db

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

@app.route('/', methods=['GET'])
def index():
    if 'user_id' in session:
        return redirect(url_for('perfil'))
    return render_template('login.html')

@app.route('/login', methods=['POST'])
def login():
    access_key = request.form['access_key']
    db = get_db()
    
    # Check if access key exists
    cursor = db.execute('SELECT * FROM codigos_acesso WHERE codigo = ?', (access_key,))
    access_code = cursor.fetchone()
    
    if access_code:
        session['user_id'] = access_code['pessoa_id']
        return redirect(url_for('perfil'))
    else:
        flash('Chave de acesso inválida. Tente novamente.', 'error')
        return redirect(url_for('index'))

@app.route('/perfil')
def perfil():
    if 'user_id' not in session:
        return redirect(url_for('index'))
    
    user_id = session['user_id']
    db = get_db()
    
    cursor = db.execute('SELECT * FROM pessoas WHERE id = ?', (user_id,))
    user = cursor.fetchone()
    
    if user is None:
        # Should not happen if referential integrity is maintained
        session.pop('user_id', None)
        return redirect(url_for('index'))
    
    # Get events for today where the user is responsible
    from datetime import date
    today = date.today().strftime('%Y-%m-%d')
    
    # Query events with attendance count
    cursor = db.execute('''
        SELECT e.*, (SELECT COUNT(*) FROM presencas p WHERE p.evento_id = e.id) as qtd_presencas 
        FROM eventos e 
        WHERE e.pessoa_id = ? AND e.data = ?
    ''', (user_id, today))
    meus_eventos = cursor.fetchall()
    
    # Get attendance registered for today
    cursor = db.execute('''
        SELECT e.id, e.nome, e.horario, e.local, p.registrado_em 
        FROM presencas p
        JOIN eventos e ON p.evento_id = e.id
        WHERE p.pessoa_id = ? AND date(p.registrado_em) = ?
    ''', (user_id, today))
    presencas_data = cursor.fetchall()
    
    # Process presences to add photo count
    import glob
    presencas_hoje = []
    EVENT_PHOTOS_FOLDER = os.path.join('static', 'event_photos')
    
    for p in presencas_data:
        p_dict = dict(p)
        event_id = p_dict['id']
        # Count photos for this event: picture_{user_id}_{event_id}_*
        pattern = os.path.join(EVENT_PHOTOS_FOLDER, f"picture_{user_id}_{event_id}_*")
        photos = glob.glob(pattern)
        p_dict['photo_count'] = len(photos)
        presencas_hoje.append(p_dict)
        
    return render_template('perfil.html', user=user, meus_eventos=meus_eventos, presencas_hoje=presencas_hoje)

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    return redirect(url_for('index'))

from werkzeug.utils import secure_filename

UPLOAD_FOLDER = 'static/uploads'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/frequencia', methods=['GET', 'POST'])
def frequencia():
    if 'user_id' not in session:
        return redirect(url_for('index'))
    
    if request.method == 'GET':
        import random
        # 50% chance of requiring selfie
        session['require_selfie'] = random.random() < 0.5
        return render_template('frequencia.html', require_selfie=session['require_selfie'])
    
    if request.method == 'POST':
        if 'file' not in request.files:
            return jsonify({'success': False, 'message': 'Nenhum arquivo enviado'})
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({'success': False, 'message': 'Nenhum arquivo selecionado'})
            
        # Check for selfie if required
        if session.get('require_selfie'):
            if 'selfie' not in request.files:
                 return jsonify({'success': False, 'message': 'Selfie de confirmação obrigatória.'})
            selfie_file = request.files['selfie']
            if selfie_file.filename == '':
                 return jsonify({'success': False, 'message': 'Selfie não selecionada.'})
        
        if file and allowed_file(file.filename):
            import time
            timestamp = int(time.time())
            user_id = session['user_id']
            # Get extension
            ext = file.filename.rsplit('.', 1)[1].lower() if '.' in file.filename else 'jpg'
            filename = secure_filename(f"qr_user_{user_id}_{timestamp}.{ext}")
            
            # Ensure upload folder exists
            if not os.path.exists(app.config['UPLOAD_FOLDER']):
                os.makedirs(app.config['UPLOAD_FOLDER'])
                
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)
            
            # Save selfie if required
            if session.get('require_selfie') and 'selfie_file' in locals():
                selfie_ext = selfie_file.filename.rsplit('.', 1)[1].lower() if '.' in selfie_file.filename else 'jpg'
                selfie_filename = secure_filename(f"selfie_user_{user_id}_{timestamp}.{selfie_ext}")
                selfie_path = os.path.join(app.config['UPLOAD_FOLDER'], selfie_filename)
                selfie_file.save(selfie_path)
                
                # Resize selfie if necessary
                try:
                    img = Image.open(selfie_path)
                    max_size = 720
                    if img.width > max_size or img.height > max_size:
                        img.thumbnail((max_size, max_size), Image.Resampling.LANCZOS)
                        img.save(selfie_path)
                except Exception as e:
                    print(f"Error resizing selfie: {e}")
            
            # Decode QR Code using pyzbar
            from pyzbar.pyzbar import decode
            from PIL import ImageEnhance
            
            # Open image with Pillow
            img = Image.open(filepath)
            
            decoded_objects = decode(img)
            
            # 1. Try resizing down if image is too large (often helps with high-res photos)
            if not decoded_objects and img.width > 1000:
                ratio = 1000 / img.width
                new_height = int(img.height * ratio)
                resized = img.resize((1000, new_height))
                decoded_objects = decode(resized)
            
            # 2. Try grayscale
            if not decoded_objects:
                gray = img.convert('L')
                decoded_objects = decode(gray)
                
            # 3. Try contrast enhancement
            if not decoded_objects:
                enhancer = ImageEnhance.Contrast(img)
                enhanced = enhancer.enhance(2.0)
                decoded_objects = decode(enhanced)

            # 4. Try binarization (Thresholding) - Very effective for lighting issues
            if not decoded_objects:
                # Convert to grayscale first
                gray = img.convert('L')
                # Apply threshold
                thresh = gray.point(lambda p: p > 128 and 255)
                decoded_objects = decode(thresh)
                
            # 5. Try resizing UP (for small QR codes)
            if not decoded_objects and img.width < 500:
                resized_up = img.resize((img.width * 2, img.height * 2))
                decoded_objects = decode(resized_up)

            # 6. Fallback to OpenCV if pyzbar fails
            if not decoded_objects:
                try:
                    import cv2
                    import numpy as np
                    
                    # Convert PIL image to OpenCV format
                    open_cv_image = np.array(img)
                    # Convert RGB to BGR
                    open_cv_image = open_cv_image[:, :, ::-1].copy()
                    
                    detector = cv2.QRCodeDetector()
                    data_cv2, bbox, _ = detector.detectAndDecode(open_cv_image)
                    
                    if data_cv2:
                        # Create a mock object to match pyzbar structure if needed, 
                        # or just set data directly
                        class MockDecoded:
                            def __init__(self, data):
                                self.data = data.encode('utf-8')
                        
                        decoded_objects = [MockDecoded(data_cv2)]
                except Exception as e:
                    print(f"OpenCV fallback failed: {e}")

            data = None
            if decoded_objects:
                # Take the first decoded object
                data = decoded_objects[0].data.decode('utf-8')
            
            # File is kept for audit purposes
            
            if data:
                try:
                    event_id = int(data)
                    user_id = session['user_id']
                    db = get_db()
                    
                    # 1. Fetch event details
                    cursor = db.execute('SELECT * FROM eventos WHERE id = ?', (event_id,))
                    event = cursor.fetchone()
                    
                    if not event:
                         return jsonify({'success': False, 'message': 'Evento não encontrado.'})
                    
                    # 2. Validate Date
                    today_str = datetime.now().strftime('%Y-%m-%d')
                    if event['data'] != today_str:
                        return jsonify({'success': False, 'message': f'Este evento não é hoje. Data do evento: {event["data"]}'})
                    
                    # 3. Validate Time Window
                    now = datetime.now()
                    event_start_str = f"{event['data']} {event['horario']}"
                    event_start = datetime.strptime(event_start_str, '%Y-%m-%d %H:%M')
                    
                    # Calculate duration in minutes (assuming carga_horaria is in hours)
                    duration_hours = float(event['carga_horaria'])
                    event_end = event_start + timedelta(hours=duration_hours)
                    
                    # Add a small tolerance (e.g., 15 mins before start, 30 mins after end) if desired, 
                    # but user asked for strict "between start and end".
                    # Let's stick to strict window for now as requested: 
                    # "entre o horário de início ... e o horário de término"
                    
                    if now < event_start:
                         return jsonify({'success': False, 'message': f'O evento ainda não começou. Início: {event["horario"]}'})
                    
                    if now > event_end:
                        return jsonify({'success': False, 'message': f'O evento já encerrou. Término: {event_end.strftime("%H:%M")}'})

                    # Check for duplicate attendance
                    cursor = db.execute('SELECT * FROM presencas WHERE pessoa_id = ? AND evento_id = ?', (user_id, event_id))
                    existing_attendance = cursor.fetchone()
                    
                    if existing_attendance:
                        return jsonify({'success': False, 'message': 'Frequência já registrada para este evento.'})
                    
                    # Check if this is the first attendance for the event
                    cursor = db.execute('SELECT COUNT(*) FROM presencas WHERE evento_id = ?', (event_id,))
                    attendance_count = cursor.fetchone()[0]
                    
                    if attendance_count == 0:
                        # Auto-register the organizer
                        organizer_id = event['pessoa_id']
                        # Only auto-register if the current user is NOT the organizer (avoid double insert)
                        if organizer_id != user_id:
                            db.execute('INSERT INTO presencas (pessoa_id, evento_id, origem, registrado_em) VALUES (?, ?, ?, ?)', 
                                       (organizer_id, event_id, 'auto_organizer', now.strftime('%Y-%m-%d %H:%M:%S')))
                    
                    # Register attendance
                    db.execute('INSERT INTO presencas (pessoa_id, evento_id, origem, registrado_em) VALUES (?, ?, ?, ?)', 
                               (user_id, event_id, 'qrcode_upload', now.strftime('%Y-%m-%d %H:%M:%S')))
                    db.commit()
                    
                    return jsonify({'success': True, 'message': 'Presença contabilizada com sucesso!', 'data': data})
                except ValueError:
                     return jsonify({'success': False, 'message': 'QR Code inválido: formato de dados incorreto.'})
                except Exception as e:
                    return jsonify({'success': False, 'message': f'Erro ao registrar frequência: {str(e)}'})
            else:
                # Save failed image for debugging
                debug_filename = f"failed_{timestamp}_{file.filename}"
                debug_path = os.path.join('static/debug', debug_filename)
                img.save(debug_path)
                print(f"Failed to decode. Saved debug image to {debug_path}")
                return jsonify({'success': False, 'message': 'Não foi possível ler o QR Code na imagem. Tente aproximar mais ou melhorar a iluminação.'})
                
    return jsonify({'success': False, 'message': 'Método não permitido'})

@app.route('/upload_foto', methods=['POST'])
def upload_foto():
    if 'user_id' not in session:
        return redirect(url_for('index'))
    
    if 'foto' not in request.files:
        flash('Nenhuma imagem enviada', 'error')
        return redirect(url_for('perfil'))
    
    file = request.files['foto']
    if file.filename == '':
        flash('Nenhuma imagem selecionada', 'error')
        return redirect(url_for('perfil'))
        
    if file and allowed_file(file.filename):
        import time
        user_id = session['user_id']
        timestamp = int(time.time())
        # Create a unique filename: user_{id}_{timestamp}.ext
        ext = file.filename.rsplit('.', 1)[1].lower()
        new_filename = f"user_{user_id}_{timestamp}.{ext}"
        
        # Save to static/photo directory
        photo_dir = os.path.join('static', 'photo')
        if not os.path.exists(photo_dir):
            os.makedirs(photo_dir)
            
        filepath = os.path.join(photo_dir, new_filename)
        
        # Resize image if necessary
        try:
            img = Image.open(file)
            # Convert to RGB if necessary (e.g. for PNGs with transparency being saved as JPG, though we keep extension)
            # But here we keep original extension. If it's PNG, RGBA is fine.
            
            max_size = 512
            if img.width > max_size or img.height > max_size:
                img.thumbnail((max_size, max_size), Image.Resampling.LANCZOS)
            
            img.save(filepath)
        except Exception as e:
            print(f"Error resizing image: {e}")
            # Fallback to saving original if resizing fails
            file.seek(0)
            file.save(filepath)
        
        # Update database
        db = get_db()
        # Store relative path for template usage
        db_path = f"photo/{new_filename}"
        db.execute('UPDATE pessoas SET foto = ? WHERE id = ?', (db_path, user_id))
        db.commit()
        
        flash('Foto de perfil atualizada com sucesso!', 'success')
        return redirect(url_for('perfil'))
    
    flash('Tipo de arquivo não permitido', 'error')
    return redirect(url_for('perfil'))

@app.route('/upload_event_photo', methods=['POST'])
def upload_event_photo():
    if 'user_id' not in session:
        return redirect(url_for('index'))
    
    if 'event_photo' not in request.files:
        flash('Nenhuma imagem enviada', 'error')
        return redirect(url_for('perfil'))
        
    file = request.files['event_photo']
    if file.filename == '':
        flash('Nenhuma imagem selecionada', 'error')
        return redirect(url_for('perfil'))
        
    event_id = request.form.get('event_id')
    if not event_id:
        flash('Evento não identificado', 'error')
        return redirect(url_for('perfil'))

    if file and allowed_file(file.filename):
        import time
        import glob
        import uuid
        
        user_id = session['user_id']
        
        # Define folder
        EVENT_PHOTOS_FOLDER = os.path.join('static', 'event_photos')
        if not os.path.exists(EVENT_PHOTOS_FOLDER):
            os.makedirs(EVENT_PHOTOS_FOLDER)
            
        # Check limit (max 10 photos per user PER EVENT)
        # Pattern: picture_{user_id}_{event_id}_*
        existing_files = glob.glob(os.path.join(EVENT_PHOTOS_FOLDER, f"picture_{user_id}_{event_id}_*"))
        if len(existing_files) >= 10:
            flash('Limite de 10 fotografias atingido para este evento.', 'error')
            return redirect(url_for('perfil'))
            
        timestamp = int(time.time())
        unique_id = uuid.uuid4().hex[:8]
        ext = file.filename.rsplit('.', 1)[1].lower()
        # New format: picture_{user_id}_{event_id}_{timestamp}_{uuid}.{ext}
        filename = secure_filename(f"picture_{user_id}_{event_id}_{timestamp}_{unique_id}.{ext}")
        filepath = os.path.join(EVENT_PHOTOS_FOLDER, filename)
        
        # Save without resizing to keep original dimensions
        file.save(filepath)
        
        flash('Fotografia enviada com sucesso!', 'success')
        return redirect(url_for('perfil'))
        
    flash('Tipo de arquivo não permitido', 'error')
    return redirect(url_for('perfil'))

@app.route('/relatorio/<int:evento_id>')
def gerar_relatorio(evento_id):
    if 'user_id' not in session:
        return redirect(url_for('index'))
        
    db = get_db()
    
    # 1. Fetch event details
    cursor = db.execute('SELECT * FROM eventos WHERE id = ?', (evento_id,))
    evento = cursor.fetchone()
    
    if not evento:
        flash('Evento não encontrado.', 'error')
        return redirect(url_for('perfil'))
        
    # Check if user is owner
    if evento['pessoa_id'] != session['user_id']:
        flash('Você não tem permissão para gerar relatório deste evento.', 'error')
        return redirect(url_for('perfil'))

    # 2. Fetch attendance data
    cursor = db.execute('''
        SELECT p.id, p.nome, p.curso, pr.registrado_em
        FROM presencas pr
        JOIN pessoas p ON pr.pessoa_id = p.id
        WHERE pr.evento_id = ?
        ORDER BY p.nome ASC
    ''', (evento_id,))
    presencas = cursor.fetchall()
    
    # 3. Load Template
    from odf.opendocument import load
    from odf.table import Table, TableRow, TableCell
    from odf.text import P
    from odf import teletype
    
    template_path = os.path.join('static', 'template_relatorios', 'template_lista_frequencia.odt')
    if not os.path.exists(template_path):
        flash('Template de relatório não encontrado.', 'error')
        return redirect(url_for('perfil'))
        
    doc = load(template_path)
    
    # 4. Replace Placeholders (Simple Text)
    # We iterate over all paragraphs to replace event info
    for p in doc.getElementsByType(P):
        text = teletype.extractText(p)
        if '{{eventos.nome}}' in text:
            new_text = text.replace('{{eventos.nome}}', evento['nome'])
            # Clear children safely?
            # odfpy hack: direct list clear might work if we don't use removeChild
            p.childNodes = []
            teletype.addTextToElement(p, new_text)
            
        if '{{eventos.data}}' in text:
            # Format date
            data_fmt = datetime.strptime(evento['data'], '%Y-%m-%d').strftime('%d/%m/%Y')
            new_text = text.replace('{{eventos.data}}', data_fmt)
            p.childNodes = []
            teletype.addTextToElement(p, new_text)
            
        if '{{eventos.local}}' in text:
            new_text = text.replace('{{eventos.local}}', evento['local'])
            p.childNodes = []
            teletype.addTextToElement(p, new_text)
            
        if '{{eventos.horario}}' in text:
            new_text = text.replace('{{eventos.horario}}', evento['horario'])
            p.childNodes = []
            teletype.addTextToElement(p, new_text)

    # 5. Handle Table Rows
    # Find the table containing the markers
    tables = doc.getElementsByType(Table)
    for table in tables:
        rows = table.getElementsByType(TableRow)
        template_row = None
        
        # Find the row with markers
        for row in rows:
            cells = row.getElementsByType(TableCell)
            row_text = ""
            for cell in cells:
                row_text += teletype.extractText(cell)
            
            if '{{pessoas.nome}}' in row_text:
                template_row = row
                break
        
        if template_row:
            # Manual cloning function to avoid RecursionError with deepcopy
            from odf.element import Text, Element
            def clone_element(element):
                if isinstance(element, Text):
                    return Text(element.data)
                # Create new instance of the same class
                new_el = element.__class__(qname=element.qname, qattributes=element.attributes)
                for child in element.childNodes:
                    cloned_child = clone_element(child)
                    if isinstance(cloned_child, Text):
                        new_el.appendChild(cloned_child)
                    else:
                        new_el.addElement(cloned_child)
                return new_el

            for presenca in presencas:
                new_row = clone_element(template_row)
                
                # Fill data in new_row
                cells = new_row.getElementsByType(TableCell)
                for cell in cells:
                    # Iterate paragraphs in cell
                    for p in cell.getElementsByType(P):
                        text = teletype.extractText(p)
                        if '{{pessoas.nome}}' in text:
                            nome_exibicao = presenca['nome']
                            if presenca['id'] == evento['pessoa_id']:
                                nome_exibicao += " (responsável)"
                            new_text = text.replace('{{pessoas.nome}}', nome_exibicao)
                            p.childNodes = []
                            teletype.addTextToElement(p, new_text)
                        if '{{pessoas.curso}}' in text:
                            new_text = text.replace('{{pessoas.curso}}', presenca['curso'])
                            p.childNodes = []
                            teletype.addTextToElement(p, new_text)
                        if '{{presencas.registrado_em}}' in text:
                            # Format timestamp
                            reg_dt = datetime.strptime(presenca['registrado_em'], '%Y-%m-%d %H:%M:%S')
                            reg_fmt = reg_dt.strftime('%H:%M:%S')
                            new_text = text.replace('{{presencas.registrado_em}}', reg_fmt)
                            p.childNodes = []
                            teletype.addTextToElement(p, new_text)
                
                # Add new row to table
                table.insertBefore(new_row, template_row)
            
            # Remove the original template row
            table.removeChild(template_row)
            break # Assume only one table needs filling

    # 6. Save ODT
    reports_dir = os.path.join('static', 'reports')
    if not os.path.exists(reports_dir):
        os.makedirs(reports_dir)
        
    odt_filename = f"relatorio_evento_{evento_id}.odt"
    odt_path = os.path.join(reports_dir, odt_filename)
    doc.save(odt_path)
    
    # 7. Convert to PDF
    import subprocess
    try:
        # libreoffice --headless --convert-to pdf --outdir <dir> <file>
        cmd = ['libreoffice', '--headless', '--convert-to', 'pdf', '--outdir', reports_dir, odt_path]
        subprocess.run(cmd, check=True)
        
        pdf_filename = odt_filename.replace('.odt', '.pdf')
        # pdf_path = os.path.join(reports_dir, pdf_filename)
        
        return send_file(os.path.join(reports_dir, pdf_filename), as_attachment=True)
        
    except Exception as e:
        print(f"PDF conversion failed: {e}")
        flash('Erro ao gerar PDF. O arquivo ODT foi gerado.', 'error')
        # Fallback to ODT?
        return send_file(odt_path, as_attachment=True)

@app.route('/qr_code/<event_id>')
def get_qr_code(event_id):
    if 'user_id' not in session:
        return redirect(url_for('index'))
    
    # Generate QR Code
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_H,
        box_size=20,
        border=4,
    )
    qr.add_data(str(event_id))
    qr.make(fit=True)

    img = qr.make_image(fill_color="black", back_color="white")
    
    # Save to IO buffer
    img_io = io.BytesIO()
    img.save(img_io, 'PNG')
    img_io.seek(0)
    
    return send_file(img_io, mimetype='image/png')

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
