from flask import Flask, render_template, request, url_for, session, redirect
import qrcode
from PIL import Image
import pathlib
import sqlite3
import os
from pathlib import Path
import datetime

app = Flask(__name__)
# chave para sessão (em produção, definir via variável de ambiente)
app.secret_key = os.environ.get('SECRET_KEY', 'dev-secret-key')
# TTL (segundos) para autorizações em sessão; padrão 10 minutos
AUTH_TTL_SECONDS = int(os.environ.get('AUTH_TTL_SECONDS', '600'))
ROOT = Path(__file__).parent
DB_PATH = ROOT / "perfil.db"
STATIC_DIR = ROOT / "static"
DEFAULT_PHOTO = "img/profile.jpg"  # coloque o arquivo de imagem padrão em static/img/profile.jpg

def row_get(row, *keys, default=None):
    """Retorna o primeiro valor existente em row para as chaves fornecidas."""
    for k in keys:
        if k in row.keys():
            return row[k]
    return default

def normalize_photo_path(raw):
    """Retorna caminho relativo dentro de `static/` (ex: 'img/ana.jpg').
    Se arquivo não existir, retorna DEFAULT_PHOTO.
    """
    if not raw:
        return DEFAULT_PHOTO

    # remover prefixo 'static/' se presente
    if raw.startswith("static/"):
        rel = raw.split("static/", 1)[1]
    elif raw.startswith("/"):
        rel = raw.lstrip("/")
    else:
        rel = raw

    # se o caminho tiver 'static' como primeiro segmento (ex: 'static\\img\\x'), garantir limpeza
    rel = rel.replace("\\", "/")

    fs_path = STATIC_DIR / rel
    if fs_path.exists():
        return rel
    # tenta também interpretar raw como caminho absoluto relativo ao projeto
    alt_path = ROOT / raw
    if alt_path.exists():
        # construir caminho relativo a static/ se possível
        try:
            rel_alt = alt_path.relative_to(STATIC_DIR)
            return str(rel_alt).replace("\\", "/")
        except Exception:
            return DEFAULT_PHOTO
    return DEFAULT_PHOTO

def load_profile_from_db(id_pessoa=None):
    """Carrega o perfil da pessoa pelo id_pessoa.

    Se id_pessoa for None, retorna o primeiro registro (comportamento legado).
    """
    if not DB_PATH.exists():
        return None
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    if id_pessoa is not None:
        cur.execute("SELECT * FROM pessoas WHERE id = ?", (id_pessoa,))
    else:
        cur.execute("SELECT * FROM pessoas ORDER BY id LIMIT 1")
    row = cur.fetchone()
    conn.close()
    if not row:
        return None

    # obtém valores verificando múltiplos nomes de coluna (pt/en)
    nome = row_get(row, "nome", default="")
    curso = row_get(row, "curso", default="")
    telefone = row_get(row, "telefone", default="")
    email = row_get(row, "email", default="")
    foto_raw = row_get(row, "foto", default="")

    foto_rel = normalize_photo_path(foto_raw)


    # devolve chaves tanto em pt quanto em en para compatibilidade com templates
    return {
        "id": row["id"],
        "foto": foto_rel,
        "nome": nome,
        "curso": curso,
        "telefone": telefone,
        "email": email
    }


def load_all_people():
    """Retorna lista de pessoas com campos mínimos (id, nome, foto, curso)."""
    if not DB_PATH.exists():
        return []
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    cur.execute("SELECT id, nome, curso, foto FROM pessoas ORDER BY nome ASC")
    rows = cur.fetchall()
    conn.close()

    people = []
    for row in rows:
        foto_raw = row_get(row, "foto", default="")
        foto_rel = normalize_photo_path(foto_raw)
        people.append({
            "id": row["id"],
            "nome": row_get(row, "nome", default=""),
            "curso": row_get(row, "curso", default=""),
            "foto": foto_rel
        })
    return people


def load_events_recent(days=7):
    """Retorna lista de eventos cuja data está no intervalo [hoje-days, hoje].

    Cada evento é um dict com chaves: id, data (ISO str), horario, nome, local, pessoa_id, carga_horaria
    """
    if not DB_PATH.exists():
        return []
    today = datetime.date.today()
    start = today - datetime.timedelta(days=days)
    start_s = start.isoformat()
    end_s = today.isoformat()

    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    # usa comparação por texto ISO (YYYY-MM-DD) que funciona para intervalos
    # traz também o nome da pessoa responsável (se existir) para facilitar exibição no cliente
    cur.execute("""
        SELECT e.*, p.nome AS pessoa_nome
        FROM eventos e
        LEFT JOIN pessoas p ON e.pessoa_id = p.id
        WHERE e.data BETWEEN ? AND ?
        ORDER BY e.data DESC, e.nome ASC
    """, (start_s, end_s))
    rows = cur.fetchall()
    conn.close()

    events = []
    for row in rows:
        # tenta garantir formato ISO
        data_raw = row_get(row, "data", default="")
        try:
            # valida/normaliza
            _ = datetime.date.fromisoformat(data_raw)
            data_iso = data_raw
        except Exception:
            # ignora eventos com data inválida
            continue
        # formatar data para exibição pt-BR
        try:
            dt_ev = datetime.date.fromisoformat(data_iso)
            data_fmt = dt_ev.strftime('%d/%m/%Y')
        except Exception:
            data_fmt = data_iso

        events.append({
            "id": row["id"],
            "data": data_iso,
            "data_fmt": data_fmt,
            "horario": row_get(row, "horario", default=""),
            "nome": row_get(row, "nome", default=""),
            "local": row_get(row, "local", default=""),
            "pessoa_id": row_get(row, "pessoa_id", default=None),
            "pessoa_nome": row_get(row, "pessoa_nome", default=None),
            "carga_horaria": row_get(row, "carga_horaria", default=None)
        })
    return events


def load_event_by_id(id_evento):
    """Retorna um evento (dict) pelo id ou None."""
    if not DB_PATH.exists():
        return None
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    # incluir nome do responsável (se houver) para uso no template
    cur.execute(
        "SELECT e.*, p.nome AS pessoa_nome FROM eventos e LEFT JOIN pessoas p ON e.pessoa_id = p.id WHERE e.id = ?",
        (id_evento,)
    )
    row = cur.fetchone()
    conn.close()
    if not row:
        return None
    data_raw = row_get(row, "data", default="")
    try:
        _ = datetime.date.fromisoformat(data_raw)
        data_iso = data_raw
    except Exception:
        data_iso = data_raw
    # formatar para pt-BR
    try:
        dt_ev = datetime.date.fromisoformat(data_iso)
        data_fmt = dt_ev.strftime('%d/%m/%Y')
    except Exception:
        data_fmt = data_iso
    return {
        "id": row["id"],
        "data": data_iso,
        "horario": row_get(row, "horario", default=""),
        "nome": row_get(row, "nome", default=""),
        "local": row_get(row, "local", default=""),
        "pessoa_id": row_get(row, "pessoa_id", default=None),
        "pessoa_nome": row_get(row, "pessoa_nome", default=None),
        "data_fmt": data_fmt,
        "carga_horaria": row_get(row, "carga_horaria", default=None)
    }


def has_presence(pessoa_id, evento_id):
    """Retorna True se existir ao menos um registro em presencas para a pessoa/evento."""
    if not DB_PATH.exists():
        return False
    try:
        conn = sqlite3.connect(DB_PATH)
        cur = conn.cursor()
        cur.execute("SELECT 1 FROM presencas WHERE pessoa_id = ? AND evento_id = ? LIMIT 1", (pessoa_id, evento_id))
        exists = cur.fetchone() is not None
        return exists
    except Exception:
        return False
    finally:
        try:
            conn.close()
        except Exception:
            pass


def get_presence(pessoa_id, evento_id):
    """Retorna o último registro de presença (id, registrado_em) para a pessoa/evento ou None.

    Também fornece o campo 'registrado_em_fmt' formatado para exibição (dd/mm/YYYY HH:MM:SS).
    """
    if not DB_PATH.exists():
        return None
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()
        cur.execute(
            "SELECT id, registrado_em FROM presencas WHERE pessoa_id = ? AND evento_id = ? ORDER BY registrado_em DESC LIMIT 1",
            (pessoa_id, evento_id)
        )
        row = cur.fetchone()
        if not row:
            return None
        registrado_em = row_get(row, 'registrado_em', default=None)
        registrado_em_fmt = None
        try:
            if registrado_em:
                # tentar interpretar e formatar
                dt = datetime.datetime.fromisoformat(registrado_em)
                registrado_em_fmt = dt.strftime('%d/%m/%Y %H:%M:%S')
        except Exception:
            registrado_em_fmt = registrado_em
        return {
            'id': row['id'],
            'registrado_em': registrado_em,
            'registrado_em_fmt': registrado_em_fmt,
        }
    except Exception:
        return None
    finally:
        try:
            conn.close()
        except Exception:
            pass


def _prune_authorizations():
    """Remove autorizações expiradas da sessão e retorna o dicionário atual.

    Estrutura em sessão: session['authorized_events'] = { '<id_evento>': '<isoexpires>', ... }
    """
    auth = session.get('authorized_events', {}) or {}
    now = datetime.datetime.utcnow()
    changed = False
    for k, v in list(auth.items()):
        try:
            expires = datetime.datetime.fromisoformat(v)
        except Exception:
            # entrada inválida -> remover
            del auth[k]
            changed = True
            continue
        if expires < now:
            del auth[k]
            changed = True
    if changed:
        session['authorized_events'] = auth
    return auth


def is_event_authorized(event_id):
    auth = _prune_authorizations()
    return str(event_id) in auth


def authorize_event(event_id):
    auth = session.get('authorized_events', {}) or {}
    expires = (datetime.datetime.utcnow() + datetime.timedelta(seconds=AUTH_TTL_SECONDS)).isoformat()
    auth[str(event_id)] = expires
    session['authorized_events'] = auth

@app.route('/')
def index():
    """Rota raiz: redireciona para /evento por padrão."""
    return redirect(url_for('evento'))


@app.route('/pessoas', methods=['GET', 'POST'])
@app.route('/pessoas/<int:id_evento>', methods=['GET', 'POST'])
def pessoas(id_evento=None):
    """Lista de pessoas (cards). Pode receber id_evento para operações futuras.

    Se `id_evento` for fornecido, exige autenticação para mostrar a lista relacionada ao evento.
    """
    people = load_all_people()
    if not people:
        return "Banco não encontrado ou sem registros. Execute create_db.py para criar dados de exemplo.", 404

    # permitir id_evento via query string também
    if id_evento is None:
        id_evento = request.args.get('id_evento', type=int)

    # POST: tentativa de autenticar código para o evento (reaproveita lógica similar)
    if request.method == 'POST':
        form_evento = request.form.get('id_evento', type=int) or id_evento
        code = request.form.get('access_code', type=str)
        if form_evento is None or not code:
            return render_template('event_auth.html', id_evento=form_evento, error='Informe o código de acesso.'), 400

        evento = load_event_by_id(form_evento)
        if evento is None:
            return render_template('event_auth.html', id_evento=form_evento, error='Evento não encontrado.'), 404

        pessoa_id = evento.get('pessoa_id')
        responsible_profile = load_profile_from_db(pessoa_id) if pessoa_id else None
        try:
            conn = sqlite3.connect(DB_PATH)
            cur = conn.cursor()
            cur.execute('SELECT 1 FROM codigos_acesso WHERE pessoa_id = ? AND codigo = ? LIMIT 1', (pessoa_id, code))
            ok = cur.fetchone() is not None
        finally:
            try:
                conn.close()
            except Exception:
                pass

        if ok:
            authorize_event(form_evento)
            return redirect(url_for('pessoas', id_evento=form_evento))
        else:
            return render_template('event_auth.html', id_evento=form_evento, error='Código inválido.', responsible=responsible_profile), 403

    selected_event = None
    if id_evento is not None:
        # se não autorizado, pedir autenticação
        if not is_event_authorized(id_evento):
            evento = load_event_by_id(id_evento)
            responsible_profile = None
            if evento and evento.get('pessoa_id'):
                responsible_profile = load_profile_from_db(evento.get('pessoa_id'))
            return render_template('event_auth.html', id_evento=id_evento, responsible=responsible_profile)
        selected_event = load_event_by_id(id_evento)

    return render_template('index.html', people=people, selected_event=selected_event)


@app.route('/<int:id_pessoa>', defaults={'id_evento': None})
@app.route('/<int:id_pessoa>/<int:id_evento>')
def home(id_pessoa, id_evento=None):
    """Mostra o perfil da pessoa. Se id_evento for fornecido na URL, carrega o evento e passa
    `selected_event` ao template para que a página saiba tanto o id da pessoa quanto o do evento.
    """
    profile = load_profile_from_db(id_pessoa)
    if not profile:
        return "Pessoa não encontrada (id={}). Verifique o banco de dados.".format(id_pessoa), 404

    selected_event = None
    selected_has_presence = False
    selected_presence = None
    if id_evento is not None:
        selected_event = load_event_by_id(id_evento)
        if selected_event is None:
            return "Evento não encontrado (id={}).".format(id_evento), 404
        # obtem último registro de presença (se houver)
        try:
            selected_presence = get_presence(id_pessoa, id_evento)
            selected_has_presence = selected_presence is not None
        except Exception:
            selected_presence = None
            selected_has_presence = False
        # formatar data do evento para pt-BR (dd/mm/YYYY) para exibição no perfil
        try:
            if selected_event.get('data'):
                dt = datetime.date.fromisoformat(selected_event.get('data'))
                selected_event['data_fmt'] = dt.strftime('%d/%m/%Y')
        except Exception:
            selected_event['data_fmt'] = selected_event.get('data')

    return render_template('profile.html', profile=profile, selected_event=selected_event, selected_has_presence=selected_has_presence, selected_presence=selected_presence)


@app.route('/evento')
def evento():
    # lista de eventos permitidos (hoje-7 .. hoje)
    events = load_events_recent(days=7)
    if not events:
        return "Nenhum evento encontrado no período permitido (últimos 7 dias).", 404

    # por padrão seleciona o primeiro (mais recente)
    selected = events[0]

    # validar que o evento selecionado tem data dentro do intervalo (defensivo, embora load_events_recent já filtre)
    try:
        ev_date = datetime.date.fromisoformat(selected["data"])
    except Exception:
        return "Evento com data inválida.", 400

    today = datetime.date.today()
    start = today - datetime.timedelta(days=7)
    if not (start <= ev_date <= today):
        return "Evento fora do intervalo permitido (de {} até {}).".format(start.isoformat(), today.isoformat()), 400

    # obter nome da pessoa responsável (opcional)
    responsible = None
    if selected.get("pessoa_id"):
        responsible = load_profile_from_db(selected.get("pessoa_id"))

    return render_template('event.html', events=events, selected=selected, responsible=responsible)


@app.route('/gerar_codigo_chamada')
def gerar_codigo_chamada(id_pessoa=None, id_evento=None):
    """Gera no servidor um QRCode que contém a URL absoluta para /registrar_frequencia
    e salva a imagem em static/qrcodes/<id_pessoa>/<id_evento>.png. Recebe opcionalmente
    id_pessoa e id_evento via query string ou via rota (preferimos query string aqui).
    Exemplo de chamada: /gerar_codigo_chamada?id_pessoa=1&id_evento=2
    """
    # extrair parâmetros (podem vir via query string)
    if id_pessoa is None:
        id_pessoa = request.args.get('id_pessoa', type=int)
    if id_evento is None:
        id_evento = request.args.get('id_evento', type=int)

    if id_pessoa is None or id_evento is None:
        return "É necessário fornecer id_pessoa e id_evento (ex: ?id_pessoa=1&id_evento=2)", 400

    # construir URL absoluta para /registrar_frequencia incorporando ids (pode ser usado pelo registro)
    registrar_path = url_for('registrar_frequencia', _external=False)
    # opcionalmente incluir query params para identificar pessoa/evento
    registrar_url = request.host_url.rstrip('/') + registrar_path + f"?id_pessoa={id_pessoa}&id_evento={id_evento}"

    # caminho físico e URL público para a imagem do QR
    qrcode_dir = STATIC_DIR / 'qrcodes' / str(id_pessoa)
    qrcode_dir.mkdir(parents=True, exist_ok=True)
    qrcode_file = qrcode_dir / f"{id_evento}.png"

    # gerar e salvar QR (sobrescreve se já existir)
    qr = qrcode.QRCode(version=1, box_size=10, border=2)
    qr.add_data(registrar_url)
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white")
    # garantir que o diretório existe e salvar
    img.save(qrcode_file)

    # url pública para o template
    qrcode_url = url_for('static', filename=f"qrcodes/{id_pessoa}/{id_evento}.png", _external=True)
    return render_template('gerar_codigo.html', registrar_url=registrar_url, qrcode_url=qrcode_url, id_pessoa=id_pessoa, id_evento=id_evento)


@app.route('/registrar_frequencia')
def registrar_frequencia():
    """Rota temporária que representaria o endpoint de registro de presença.

    Por enquanto exibe uma página simples -- poderá ser estendida para receber POSTs do app cliente.
    """
    # aceitar parâmetros via query string (ex: ?id_pessoa=1&id_evento=2)
    id_pessoa = request.args.get('id_pessoa', type=int)
    id_evento = request.args.get('id_evento', type=int)

    context = {
        'success': False,
        'message': 'Nenhuma ação realizada.',
        'id_pessoa': id_pessoa,
        'id_evento': id_evento,
    }

    if id_pessoa is None or id_evento is None:
        context['message'] = 'É necessário fornecer id_pessoa e id_evento (ex: ?id_pessoa=1&id_evento=2)'
        return render_template('registrar_frequencia.html', **context), 400

    # valida existência de pessoa e evento
    if not DB_PATH.exists():
        context['message'] = 'Banco de dados não encontrado.'
        return render_template('registrar_frequencia.html', **context), 500

    try:
        conn = sqlite3.connect(DB_PATH)
        cur = conn.cursor()
        cur.execute("SELECT id FROM pessoas WHERE id = ?", (id_pessoa,))
        if cur.fetchone() is None:
            context['message'] = f'Pessoa não encontrada (id={id_pessoa}).'
            return render_template('registrar_frequencia.html', **context), 404

        cur.execute("SELECT id FROM eventos WHERE id = ?", (id_evento,))
        if cur.fetchone() is None:
            context['message'] = f'Evento não encontrado (id={id_evento}).'
            return render_template('registrar_frequencia.html', **context), 404

        # prevenir duplicatas: verificar se já existe presença para a mesma pessoa+evento no mesmo dia
        cur.execute(
            "SELECT id FROM presencas WHERE pessoa_id = ? AND evento_id = ? AND date(registrado_em) = date('now','localtime')",
            (id_pessoa, id_evento)
        )
        existing = cur.fetchone()
        if existing:
            context['success'] = False
            context['message'] = 'Presença já registrada hoje para esta pessoa e evento.'
            context['presenca_id'] = existing[0]
            return render_template('registrar_frequencia.html', **context)

        # inserir registro de presença (novo)
        cur.execute(
            "INSERT INTO presencas (pessoa_id, evento_id, origem, info_extra) VALUES (?, ?, ?, ?)",
            (id_pessoa, id_evento, 'qrcode', request.headers.get('User-Agent', ''))
        )
        conn.commit()
        presenca_id = cur.lastrowid
        context['success'] = True
        context['message'] = 'Presença registrada com sucesso.'
        context['presenca_id'] = presenca_id
        return render_template('registrar_frequencia.html', **context)
    except Exception as e:
        context['message'] = f'Erro ao registrar presença: {e}'
        return render_template('registrar_frequencia.html', **context), 500
    finally:
        try:
            conn.close()
        except Exception:
            pass


@app.route('/logout')
def logout():
    """Encerra a sessão do usuário (limpa autorizações em sessão) e redireciona para a raiz."""
    # limpar toda a sessão para garantir logout completo
    session.clear()
    return redirect(url_for('index'))


@app.route('/check_frequencia', methods=['GET'])
def check_frequencia():
    """Endpoint para checar se a presença já foi registrada para uma pessoa/evento.

    Recebe via query string: id_pessoa, id_evento
    Retorna JSON: { 'registered': True/False }
    """
    id_pessoa = request.args.get('id_pessoa', type=int)
    id_evento = request.args.get('id_evento', type=int)

    if id_pessoa is None or id_evento is None:
        return {'error': 'Parâmetros id_pessoa e id_evento são obrigatórios.'}, 400

    try:
        registered = has_presence(id_pessoa, id_evento)
        return {'registered': registered}
    except Exception as e:
        return {'error': f'Erro ao verificar presença: {e}'}, 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', debug=True)