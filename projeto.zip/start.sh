#!/bin/bash

# Configurações padrão
HOST=${HOST:-0.0.0.0}
PORT=${PORT:-5000}

# Ativar ambiente virtual (se estiver usando)
source ../.venv_ocorrencias/bin/activate

# Instalar dependências
pip install -r requirements.txt

# Executar migrações do banco de dados
flask db upgrade

# Iniciar o Gunicorn com Uvicorn
echo "Iniciando servidor em $HOST:$PORT"
HOST=$HOST PORT=$PORT gunicorn -c gunicorn_config.py "app:create_app()" --capture-output --log-level warning 
