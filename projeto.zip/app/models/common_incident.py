from app import db

class CommonIncident(db.Model):
    __tablename__ = 'common_incidents'
    __table_args__ = {'extend_existing': True}
    
    id = db.Column(db.Integer, primary_key=True)
    description = db.Column(db.String(255), nullable=False)
    created_at = db.Column(db.DateTime, default=db.func.current_timestamp())
    updated_at = db.Column(db.DateTime, default=db.func.current_timestamp(), 
                          onupdate=db.func.current_timestamp())
    
    # Relacionamento com ocorrências
    incidents = db.relationship('Incident', backref='common_incident', lazy=True)
    
    def __repr__(self):
        return f'<CommonIncident {self.description}>' 