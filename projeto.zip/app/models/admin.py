from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import UserMixin
from app import db
import secrets
import string
import pytz

def get_local_time():
    """Retorna o horário atual no fuso horário de Campo Grande (Mato Grosso do Sul)"""
    return datetime.now(pytz.timezone('America/Campo_Grande'))

class User(UserMixin, db.Model):
    __tablename__ = 'users'
    __table_args__ = {'extend_existing': True}
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    user_name = db.Column(db.String(20), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(128))
    category = db.Column(db.String(20), nullable=False)  # 'professor' ou 'admin'
    is_active = db.Column(db.Boolean, default=True)
    login_attempts = db.Column(db.Integer, default=0)
    last_login_attempt = db.Column(db.DateTime, nullable=True)
    created_at = db.Column(db.DateTime, default=get_local_time)
    updated_at = db.Column(db.DateTime, default=get_local_time, 
                          onupdate=get_local_time)
    
    @property
    def password(self):
        raise AttributeError('password não é um atributo legível')
    
    @password.setter
    def password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def verify_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    @property
    def is_admin(self):
        return self.category == 'admin'
    
    @staticmethod
    def generate_password(length=8):
        """Gera uma senha aleatória com números."""
        return ''.join(secrets.choice(string.digits) for _ in range(length))
    
    def __repr__(self):
        return f'<User {self.name}>'

class AccessLog(db.Model):
    __tablename__ = 'access_logs'
    __table_args__ = {'extend_existing': True}
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    action = db.Column(db.String(20), nullable=False)  # 'authenticate' ou 'logout'
    timestamp = db.Column(db.DateTime, default=get_local_time)
    ip_address = db.Column(db.String(45))  # IPv6 tem até 45 caracteres
    
    user = db.relationship('User', backref='access_logs', lazy=True)
    
    def __repr__(self):
        return f'<AccessLog {self.user_id} {self.action}>'

class CommonIncident(db.Model):
    __tablename__ = 'common_incidents'
    
    id = db.Column(db.Integer, primary_key=True)
    description = db.Column(db.String(255), nullable=False)
    created_at = db.Column(db.DateTime, default=get_local_time)
    updated_at = db.Column(db.DateTime, default=get_local_time, onupdate=get_local_time)
    deleted_at = db.Column(db.DateTime, nullable=True)

    def __repr__(self):
        return f'<CommonIncident {self.description}>' 