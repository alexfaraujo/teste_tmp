from app import db

class Class(db.Model):
    __tablename__ = 'classes'
    __table_args__ = {'extend_existing': True}
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False)
    course_id = db.Column(db.Integer, db.ForeignKey('courses.id'), nullable=False)
    shift = db.Column(db.String(20), nullable=False)  # matutino, vespertino, integral, diurno
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=db.func.current_timestamp())
    updated_at = db.Column(db.DateTime, default=db.func.current_timestamp(), 
                          onupdate=db.func.current_timestamp())
    
    # Relacionamento com alunos
    students = db.relationship('Student', backref='class_', lazy=True)
    
    def __repr__(self):
        return f'<Class {self.name}>' 