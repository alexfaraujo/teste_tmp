from datetime import datetime
from app import db
from app.models.admin import User
from sqlalchemy.sql import func
import pytz

class Incident(db.Model):
    __tablename__ = 'incidents'
    __table_args__ = {'extend_existing': True}
    
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('students.id'), nullable=False)
    common_incident_id = db.Column(db.Integer, db.ForeignKey('common_incidents.id'))
    description = db.Column(db.Text)
    incident_date = db.Column(db.DateTime, nullable=False)
    status = db.Column(db.String(20), nullable=False, default='open')
    registered_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    solution_description = db.Column(db.Text)
    closed_by_user_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(pytz.timezone('America/Campo_Grande')))
    updated_at = db.Column(db.DateTime, default=lambda: datetime.now(pytz.timezone('America/Campo_Grande')), 
                          onupdate=lambda: datetime.now(pytz.timezone('America/Campo_Grande')))
    
    # Relacionamentos
    student = db.relationship('Student', backref='incidents', lazy=True)
    registered_by_user = db.relationship('User', backref='registered_incidents', lazy=True, foreign_keys=[registered_by])
    closed_by_user = db.relationship('User', backref='closed_incidents', lazy=True, foreign_keys=[closed_by_user_id])
    
    def __repr__(self):
        return f'<Incident {self.id}>' 