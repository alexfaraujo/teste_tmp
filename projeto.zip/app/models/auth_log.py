from datetime import datetime
from app import db
import pytz

class AuthLog(db.Model):
    __tablename__ = 'auth_logs'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), nullable=False)
    attempt_date = db.Column(db.DateTime, nullable=False, default=lambda: datetime.now(pytz.timezone('America/Campo_Grande')))
    ip_address = db.Column(db.String(45), nullable=False)  # IPv6 pode ter até 45 caracteres
    
    def __repr__(self):
        return f'<AuthLog {self.id}: {self.username} at {self.attempt_date}>' 