from app import db
from datetime import datetime

class CurricularUnit(db.Model):
    __tablename__ = 'curricular_units'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    course_id = db.Column(db.Integer, db.ForeignKey('courses.id'), nullable=False)
    shift = db.Column(db.String(20), nullable=False)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relacionamentos
    course = db.relationship('Course', backref=db.backref('curricular_units', lazy=True))
    
    # Índice único composto para garantir que não haja unidades curriculares duplicadas para o mesmo curso e turno
    __table_args__ = (
        db.UniqueConstraint('name', 'course_id', 'shift', name='uix_curricular_unit_course_shift'),
    )
    
    def __repr__(self):
        return f'<CurricularUnit {self.name}>' 