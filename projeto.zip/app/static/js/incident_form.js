document.addEventListener('DOMContentLoaded', function() {
    // Elementos do formulário
    const courseInput = document.getElementById('course');
    const classInput = document.getElementById('class');
    const studentInput = document.getElementById('student');
    const commonIncidentSelect = document.getElementById('common_incident');
    const descriptionField = document.getElementById('description_field');
    const descriptionInput = document.getElementById('description');
    const incidentDateInput = document.getElementById('incident_date');
    const statusSelect = document.getElementById('status');

    // Configurar data e hora atual como padrão
    const now = new Date();
    incidentDateInput.value = now.toISOString().slice(0, 16);

    // Mostrar/ocultar campo de descrição baseado na seleção de ocorrência comum
    commonIncidentSelect.addEventListener('change', function() {
        if (this.value === 'other') {
            descriptionField.style.display = 'block';
            descriptionInput.required = true;
        } else {
            descriptionField.style.display = 'none';
            descriptionInput.required = false;
        }
    });

    // Função para criar dropdown de autocompletar
    function createAutocompleteDropdown(input, options) {
        // Remover dropdown existente
        const existingDropdown = input.parentElement.querySelector('.autocomplete-dropdown');
        if (existingDropdown) {
            existingDropdown.remove();
        }

        if (!options.length) return;

        const dropdown = document.createElement('div');
        dropdown.className = 'autocomplete-dropdown';

        options.forEach(option => {
            const div = document.createElement('div');
            div.className = 'autocomplete-option';
            div.textContent = option;
            div.addEventListener('click', () => {
                input.value = option;
                dropdown.remove();
            });
            dropdown.appendChild(div);
        });

        input.parentElement.appendChild(dropdown);
    }

    // Função para buscar opções de autocompletar
    async function fetchAutocompleteOptions(input, endpoint) {
        const query = input.value.trim();
        if (query.length < 2) return [];

        try {
            const response = await fetch(`${endpoint}?q=${encodeURIComponent(query)}`);
            if (!response.ok) throw new Error('Erro ao buscar opções');
            return await response.json();
        } catch (error) {
            console.error('Erro:', error);
            return [];
        }
    }

    // Configurar autocompletar para curso
    courseInput.addEventListener('input', async function() {
        const options = await fetchAutocompleteOptions(this, '/api/courses');
        createAutocompleteDropdown(this, options);
    });

    // Configurar autocompletar para turma
    classInput.addEventListener('input', async function() {
        const course = courseInput.value.trim();
        if (!course) return;
        
        const options = await fetchAutocompleteOptions(this, `/api/classes?course=${encodeURIComponent(course)}`);
        createAutocompleteDropdown(this, options);
    });

    // Configurar autocompletar para aluno
    studentInput.addEventListener('input', async function() {
        const course = courseInput.value.trim();
        const class_ = classInput.value.trim();
        if (!course || !class_) return;
        
        const options = await fetchAutocompleteOptions(this, 
            `/api/students?course=${encodeURIComponent(course)}&class=${encodeURIComponent(class_)}`);
        createAutocompleteDropdown(this, options);
    });

    // Fechar dropdowns ao clicar fora
    document.addEventListener('click', function(e) {
        if (!e.target.closest('.autocomplete-dropdown') && !e.target.matches('input')) {
            const dropdowns = document.querySelectorAll('.autocomplete-dropdown');
            dropdowns.forEach(dropdown => dropdown.remove());
        }
    });
}); 