from datetime import datetime
import pytz

def to_utc(dt):
    """Converte uma data/hora local para UTC"""
    if dt.tzinfo is None:
        # Se não tiver timezone, assume que é local
        local_tz = pytz.timezone('America/Campo_Grande')
        dt = local_tz.localize(dt)
    return dt.astimezone(pytz.UTC)

def to_local(dt):
    """Converte uma data/hora UTC para local"""
    if dt.tzinfo is None:
        # Se não tiver timezone, assume que é UTC
        dt = pytz.UTC.localize(dt)
    local_tz = pytz.timezone('America/Campo_Grande')
    return dt.astimezone(local_tz)

def format_datetime(dt, format='%d/%m/%Y %H:%M'):
    """Formata uma data/hora para o formato especificado"""
    if dt.tzinfo is None:
        # Se não tiver timezone, assume que é local
        local_tz = pytz.timezone('America/Campo_Grande')
        dt = local_tz.localize(dt)
    return dt.strftime(format) 