from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_user, logout_user, login_required, current_user
from app.models.admin import User, AccessLog
from app.models.auth_log import AuthLog
from app import db
from datetime import datetime, timedelta
import pytz

bp = Blueprint('professor_auth', __name__)

def check_excessive_auth_attempts(username, ip_address):
    """Verifica se há tentativas excessivas de autenticação"""
    # Verifica tentativas nos últimos 5 minutos
    five_minutes_ago = datetime.now(pytz.timezone('America/Campo_Grande')) - timedelta(minutes=5)
    
    # Conta tentativas por IP
    ip_attempts = AuthLog.query.filter(
        AuthLog.ip_address == ip_address,
        AuthLog.attempt_date >= five_minutes_ago
    ).count()
    
    # Conta tentativas por usuário
    user_attempts = AuthLog.query.filter(
        AuthLog.username == username,
        AuthLog.attempt_date >= five_minutes_ago
    ).count()
    
    # Se houver mais de 5 tentativas por IP ou usuário em 5 minutos
    if ip_attempts >= 5 or user_attempts >= 5:
        return True
    return False

@bp.route('/professor/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        if current_user.category == 'professor':
            return redirect(url_for('professor.dashboard'))
        elif current_user.category.lower() == 'admin':
            return redirect(url_for('admin.index'))
        else:
            flash('Acesso não autorizado.', 'error')
            return redirect(url_for('main.index'))
    
    if request.method == 'POST':
        user_name = request.form.get('user_name')
        password = request.form.get('password')
        
        # Verifica tentativas excessivas
        if check_excessive_auth_attempts(user_name, request.remote_addr):
            flash('Muitas tentativas de login. Por favor, aguarde alguns minutos antes de tentar novamente.', 'error')
            return redirect(url_for('professor_auth.login'))
        
        user = User.query.filter_by(user_name=user_name).first()
        
        if user and user.verify_password(password):
            login_user(user)
            
            # Registra o login
            log = AccessLog(
                user_id=user.id,
                action='login',
                ip_address=request.remote_addr
            )
            db.session.add(log)
            db.session.commit()
            
            if user.category == 'professor':
                return redirect(url_for('professor.dashboard'))
            elif user.category.lower() == 'admin':
                return redirect(url_for('admin.index'))
            else:
                flash('Acesso não autorizado.', 'error')
                return redirect(url_for('main.index'))
        else:
            # Registra a tentativa falha de autenticação
            auth_log = AuthLog(
                username=user_name,
                ip_address=request.remote_addr
            )
            db.session.add(auth_log)
            db.session.commit()
            
            flash('Nome de usuário ou senha incorretos.', 'error')
    
    return render_template('professor_auth/login.html')

@bp.route('/professor/logout')
@login_required
def logout():
    # Registra o logout
    log = AccessLog(
        user_id=current_user.id,
        action='logout',
        ip_address=request.remote_addr
    )
    db.session.add(log)
    db.session.commit()
    
    logout_user()
    flash('Você foi desconectado com sucesso.', 'info')
    return redirect(url_for('professor_auth.login')) 