from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify, current_app, send_file
from flask_login import login_required, current_user
from app.models.admin import User, AccessLog, CommonIncident
from app.models.course import Course
from app.models.class_ import Class
from app.models.student import Student
from app.models.incident import Incident
from app import db
import os
from datetime import datetime, timedelta
import pandas as pd
from werkzeug.utils import secure_filename
import secrets
import string
import csv
from io import StringIO, BytesIO
from sqlalchemy import or_
from app.models.curricular_unit import CurricularUnit

bp = Blueprint('admin', __name__, url_prefix='/admin')

def is_admin_associated_with_course(admin_email):
    """Verifica se o email do administrador está associado a algum curso."""
    return Course.query.filter_by(coordinator_email=admin_email).first() is not None

def can_access_incident(incident_id):
    """Verifica se o administrador pode acessar a ocorrência"""
    if not is_admin_associated_with_course(current_user.email):
        return True  # Admin geral pode acessar todas as ocorrências
    
    # Para coordenadores, verifica se a ocorrência é do seu curso
    course = Course.query.filter_by(coordinator_email=current_user.email).first()
    if not course:
        return False
    
    incident = Incident.query.get(incident_id)
    if not incident:
        return False
    
    # Verifica se o aluno da ocorrência pertence ao curso do coordenador
    return incident.student.class_.course_id == course.id

def admin_required(f):
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or current_user.category.lower() != 'admin':
            flash('Acesso permitido apenas para administradores.', 'error')
            return redirect(url_for('auth.login'))
        
        # Se o admin está associado a um curso, verifica se a rota é permitida
        if is_admin_associated_with_course(current_user.email):
            allowed_routes = [
                'admin.index', 
                'admin.reports', 
                'admin.export_reports', 
                'admin.profile', 
                'admin.update_password',
                'admin.view_incident',
                'admin.update_incident_status',
                'admin.edit_incident',
                'admin.close_incident'
            ]
            if request.endpoint not in allowed_routes:
                flash('Acesso restrito. Você só pode acessar o dashboard e relatórios.', 'error')
                return redirect(url_for('admin.index'))
        
        return f(*args, **kwargs)
    decorated_function.__name__ = f.__name__
    return decorated_function

@bp.before_request
def before_request():
    # Verifica autenticação para todas as rotas
    if not current_user.is_authenticated or current_user.category.lower() != 'admin':
        flash('Acesso permitido apenas para administradores.', 'error')
        return redirect(url_for('auth.login'))
    
    # Se o admin está associado a um curso, verifica se a rota é permitida
    if is_admin_associated_with_course(current_user.email):
        allowed_routes = [
            'admin.index', 
            'admin.reports', 
            'admin.export_reports', 
            'admin.profile', 
            'admin.update_password',
            'admin.view_incident',
            'admin.update_incident_status',
            'admin.edit_incident',
            'admin.close_incident'
        ]
        if request.endpoint not in allowed_routes:
            flash('Acesso restrito. Você só pode acessar o dashboard e relatórios.', 'error')
            return redirect(url_for('admin.index'))

# Rota principal do admin
@bp.route('/')
@login_required
@admin_required
def index():
    if current_user.category.lower() != 'admin':
        return redirect(url_for('main.index'))
    
    today = datetime.now().date()
    
    # Query base para ocorrências
    incident_query = Incident.query
    
    # Se o admin está associado a um curso, filtra apenas as ocorrências desse curso
    if is_admin_associated_with_course(current_user.email):
        course = Course.query.filter_by(coordinator_email=current_user.email).first()
        if course:
            incident_query = incident_query.join(Incident.student).join(Student.class_).filter(Class.course_id == course.id)
    
    # Contagem de ocorrências
    open_incidents_count = incident_query.filter(Incident.status == 'open').count()
    today_incidents_count = incident_query.filter(
        db.func.date(Incident.incident_date) == today
    ).count()
    
    # Query base para contagem de registros
    student_query = Student.query.filter_by(is_active=True)
    course_query = Course.query.filter_by(is_active=True)
    class_query = Class.query.filter_by(is_active=True)
    user_query = User.query.filter_by(is_active=True)
    curricular_unit_query = CurricularUnit.query.filter_by(is_active=True)
    
    # Se o admin está associado a um curso, filtra os registros
    if is_admin_associated_with_course(current_user.email):
        course = Course.query.filter_by(coordinator_email=current_user.email).first()
        if course:
            student_query = student_query.join(Student.class_).filter(Class.course_id == course.id)
            class_query = class_query.filter(Class.course_id == course.id)
            course_query = Course.query.filter_by(id=course.id, is_active=True)
            curricular_unit_query = curricular_unit_query.filter_by(course_id=course.id)
    
    # Contagem de registros
    total_students = student_query.count()
    total_courses = course_query.count()
    total_classes = class_query.count()
    total_users = user_query.count()
    total_curricular_units = curricular_unit_query.count()
    
    # Últimas ocorrências
    recent_incidents = incident_query.order_by(
        Incident.incident_date.desc()
    ).limit(10).all()
    
    return render_template('admin/index.html',
                         open_incidents_count=open_incidents_count,
                         today_incidents_count=today_incidents_count,
                         total_students=total_students,
                         total_courses=total_courses,
                         total_classes=total_classes,
                         total_users=total_users,
                         total_curricular_units=total_curricular_units,
                         recent_incidents=recent_incidents,
                         today=today)

@bp.route('/profile')
@login_required
def profile():
    return render_template('admin/profile.html')

@bp.route('/update-password', methods=['POST'])
@login_required
def update_password():
    current_password = request.form.get('current_password')
    new_password = request.form.get('new_password')
    confirm_password = request.form.get('confirm_password')

    if not current_password or not new_password or not confirm_password:
        flash('Todos os campos são obrigatórios', 'error')
        return redirect(url_for('admin.profile'))

    if new_password != confirm_password:
        flash('As senhas não coincidem', 'error')
        return redirect(url_for('admin.profile'))

    if len(new_password) < 8:
        flash('A senha deve ter no mínimo 8 caracteres', 'error')
        return redirect(url_for('admin.profile'))

    if not current_user.verify_password(current_password):
        flash('Senha atual incorreta', 'error')
        return redirect(url_for('admin.profile'))

    current_user.password = new_password
    db.session.commit()

    flash('Senha alterada com sucesso', 'success')
    return redirect(url_for('admin.profile'))

# Course CRUD
@bp.route('/courses')
def courses():
    courses = Course.query.filter_by(is_active=True).all()
    return render_template('admin/courses.html', courses=courses)

@bp.route('/courses/create', methods=['GET', 'POST'])
def create_course():
    if request.method == 'POST':
        name = request.form.get('name')
        coordinator_email = request.form.get('coordinator_email')
        
        course = Course(name=name, coordinator_email=coordinator_email)
        db.session.add(course)
        db.session.commit()
        
        flash('Curso criado com sucesso!', 'success')
        return redirect(url_for('admin.courses'))
    
    return render_template('admin/course_form.html')

@bp.route('/courses/<int:id>/edit', methods=['GET', 'POST'])
def edit_course(id):
    course = Course.query.get_or_404(id)
    if request.method == 'POST':
        course.name = request.form.get('name')
        course.coordinator_email = request.form.get('coordinator_email')
        db.session.commit()
        flash('Curso atualizado com sucesso!', 'success')
        return redirect(url_for('admin.courses'))
    return render_template('admin/course_form.html', course=course)

@bp.route('/courses/<int:id>/delete')
def delete_course(id):
    course = Course.query.get_or_404(id)
    course.is_active = False
    db.session.commit()
    flash('Curso removido com sucesso!', 'success')
    return redirect(url_for('admin.courses'))

# Class CRUD
@bp.route('/classes')
def classes():
    classes = Class.query.filter_by(is_active=True).all()
    return render_template('admin/classes.html', classes=classes)

@bp.route('/classes/create', methods=['GET', 'POST'])
def create_class():
    if request.method == 'POST':
        name = request.form.get('name')
        course_id = request.form.get('course_id')
        shift = request.form.get('shift').lower()  # Convert to lowercase
        print(f"Creating new class - Name: {name}, Course ID: {course_id}, Shift: {shift}")  # Debug print
        
        class_ = Class(name=name, course_id=course_id, shift=shift)
        db.session.add(class_)
        db.session.commit()
        
        flash('Turma criada com sucesso!', 'success')
        return redirect(url_for('admin.classes'))
    
    courses = Course.query.filter_by(is_active=True).all()
    return render_template('admin/class_form.html', courses=courses)

@bp.route('/classes/<int:id>/edit', methods=['GET', 'POST'])
def edit_class(id):
    class_ = Class.query.get_or_404(id)
    print(f"Loading class for editing - ID: {class_.id}, Name: {class_.name}, Shift: {class_.shift}")  # Debug print
    if request.method == 'POST':
        class_.name = request.form.get('name')
        class_.course_id = request.form.get('course_id')
        class_.shift = request.form.get('shift').lower()  # Convert to lowercase
        db.session.commit()
        flash('Turma atualizada com sucesso!', 'success')
        return redirect(url_for('admin.classes'))
    
    courses = Course.query.filter_by(is_active=True).all()
    return render_template('admin/class_form.html', class_=class_, courses=courses)

@bp.route('/classes/<int:id>/delete')
def delete_class(id):
    class_ = Class.query.get_or_404(id)
    class_.is_active = False
    db.session.commit()
    flash('Turma removida com sucesso!', 'success')
    return redirect(url_for('admin.classes'))

# Student CRUD
@bp.route('/students')
def students():
    students = Student.query.filter_by(is_active=True).all()
    return render_template('admin/students.html', students=students)

@bp.route('/students/create', methods=['GET', 'POST'])
def create_student():
    if request.method == 'POST':
        name = request.form.get('name')
        ra = request.form.get('ra')
        class_id = request.form.get('class_id')
        
        student = Student(name=name, ra=ra, class_id=class_id)
        db.session.add(student)
        db.session.commit()
        
        flash('Estudante criado com sucesso!', 'success')
        return redirect(url_for('admin.students'))
    
    classes = Class.query.filter_by(is_active=True).all()
    return render_template('admin/student_form.html', classes=classes)

@bp.route('/students/batch', methods=['POST'])
def create_students_batch():
    if 'file' not in request.files:
        flash('Nenhum arquivo enviado', 'error')
        return redirect(url_for('admin.students'))
    
    file = request.files['file']
    if file.filename == '':
        flash('Nenhum arquivo selecionado', 'error')
        return redirect(url_for('admin.students'))
    
    if not file.filename.endswith('.csv'):
        flash('Arquivo deve ser CSV', 'error')
        return redirect(url_for('admin.students'))
    
    try:
        # Ler o arquivo CSV
        csv_data = StringIO(file.read().decode('utf-8'))
        reader = csv.DictReader(csv_data)
        
        # Verificar se as colunas necessárias estão presentes
        required_columns = {'curso', 'nome_estudante', 'turma', 'ra', 'turno'}
        if not all(col in reader.fieldnames for col in required_columns):
            flash('O arquivo CSV deve conter as colunas: curso, nome_estudante, turma, ra, turno', 'error')
            return redirect(url_for('admin.students'))
        
        # Converter o reader para lista para poder iterar múltiplas vezes
        rows = list(reader)
        
        # Primeira passagem: Processar cursos
        courses_map = {}  # Mapear nome do curso para seu ID
        for row in rows:
            course_name = row['curso']
            if course_name not in courses_map:
                course = Course.query.filter_by(name=course_name).first()
                if not course:
                    course = Course(
                        name=course_name,
                        coordinator_email=f"coord_{course_name.lower().replace(' ', '_')}@example.com"
                    )
                    db.session.add(course)
                    db.session.flush()
                courses_map[course_name] = course.id
        
        db.session.commit()
        
        # Segunda passagem: Processar turmas
        classes_map = {}  # Mapear (nome_turma, nome_curso) para ID da turma
        for row in rows:
            class_name = row['turma']
            course_name = row['curso']
            key = (class_name, course_name)
            
            if key not in classes_map:
                class_ = Class.query.filter_by(
                    name=class_name,
                    course_id=courses_map[course_name]
                ).first()
                
                if not class_:
                    class_ = Class(
                        name=class_name,
                        course_id=courses_map[course_name],
                        shift=row['turno']
                    )
                    db.session.add(class_)
                    db.session.flush()
                classes_map[key] = class_.id
        
        db.session.commit()
        
        # Terceira passagem: Processar estudantes
        success_count = 0
        error_count = 0
        
        for row in rows:
            try:
                # Verificar se o estudante já existe pelo RA
                if Student.query.filter_by(ra=row['ra']).first():
                    error_count += 1
                    continue
                
                # Obter IDs do curso e da turma
                course_name = row['curso']
                class_key = (row['turma'], course_name)
                course_id = courses_map[course_name]
                class_id = classes_map[class_key]
                
                # Criar o estudante
                student = Student(
                    name=row['nome_estudante'],
                    ra=row['ra'],
                    class_id=class_id,
                    course_id=course_id  # Definir o course_id aqui
                )
                db.session.add(student)
                success_count += 1
                
            except Exception as e:
                error_count += 1
                continue
        
        db.session.commit()
        
        if success_count > 0:
            flash(f'Sucesso ao cadastrar {success_count} estudantes', 'success')
        if error_count > 0:
            flash(f'{error_count} estudantes não foram cadastrados (já existiam ou houve erro)', 'warning')
            
    except Exception as e:
        db.session.rollback()
        flash(f'Erro ao importar estudantes: {str(e)}', 'error')
    
    return redirect(url_for('admin.students'))

@bp.route('/students/<int:id>/edit', methods=['GET', 'POST'])
def edit_student(id):
    student = Student.query.get_or_404(id)
    if request.method == 'POST':
        student.name = request.form.get('name')
        student.ra = request.form.get('ra')
        student.class_id = request.form.get('class_id')
        db.session.commit()
        flash('Estudante atualizado com sucesso!', 'success')
        return redirect(url_for('admin.students'))
    
    classes = Class.query.filter_by(is_active=True).all()
    return render_template('admin/student_form.html', student=student, classes=classes)

@bp.route('/students/<int:id>/delete')
def delete_student(id):
    student = Student.query.get_or_404(id)
    student.is_active = False
    db.session.commit()
    flash('Estudante removido com sucesso!', 'success')
    return redirect(url_for('admin.students'))

# User CRUD
@bp.route('/users')
def users():
    users = User.query.filter_by(is_active=True).all()
    return render_template('admin/users.html', users=users)

@bp.route('/users/create', methods=['GET', 'POST'])
@login_required
def create_user():
    if request.method == 'POST':
        name = request.form.get('name')
        user_name = request.form.get('user_name')
        email = request.form.get('email')
        category = request.form.get('category')
        
        if not all([name, user_name, email, category]):
            flash('Todos os campos são obrigatórios', 'error')
            return redirect(url_for('admin.create_user'))
        
        # Verificar se o nome de usuário já existe
        existing_user = User.query.filter_by(user_name=user_name).first()
        if existing_user:
            flash('Nome de usuário já está em uso', 'error')
            return redirect(url_for('admin.create_user'))
        
        # Verificar se o email já existe
        existing_email = User.query.filter_by(email=email).first()
        if existing_email:
            flash('Email já está em uso', 'error')
            return redirect(url_for('admin.create_user'))
        
        # Criar novo usuário com senha padrão
        user = User(
            name=name,
            user_name=user_name,
            email=email,
            category=category,
            password=f"{user_name}$101"  # Senha padrão: nome de usuário + $101
        )
        
        db.session.add(user)
        db.session.commit()
        
        flash('Usuário criado com sucesso', 'success')
        return redirect(url_for('admin.users'))
    
    return render_template('admin/user_form.html')

@bp.route('/users/create/batch', methods=['POST'])
@login_required
def create_users_batch():
    if current_user.category != 'admin':
        flash('Acesso negado. Apenas administradores podem criar usuários.', 'error')
        return redirect(url_for('admin.index'))
    
    if 'csv_file' not in request.files:
        flash('Nenhum arquivo enviado', 'error')
        return redirect(url_for('admin.users'))
    
    file = request.files['csv_file']
    if file.filename == '':
        flash('Nenhum arquivo selecionado', 'error')
        return redirect(url_for('admin.users'))
    
    if not file.filename.endswith('.csv'):
        flash('O arquivo deve ser um CSV', 'error')
        return redirect(url_for('admin.users'))
    
    try:
        # Ler o arquivo CSV
        import csv
        from io import StringIO
        
        # Converter o arquivo para string e ler como CSV
        stream = StringIO(file.stream.read().decode("UTF8"), newline=None)
        csv_reader = csv.DictReader(stream)
        
        # Verificar se as colunas necessárias estão presentes
        required_columns = {'name', 'email', 'category'}
        if not all(col in csv_reader.fieldnames for col in required_columns):
            flash('O arquivo CSV deve conter as colunas: name, email, category', 'error')
            return redirect(url_for('admin.users'))
        
        # Processar cada linha do CSV
        success_count = 0
        error_count = 0
        for row in csv_reader:
            try:
                # Verificar se o usuário já existe
                if User.query.filter_by(email=row['email']).first():
                    error_count += 1
                    continue
                
                # Gerar nome de usuário a partir do email
                user_name = row['email'].split('@')[0]
                
                # Verificar se o nome de usuário já existe
                if User.query.filter_by(user_name=user_name).first():
                    error_count += 1
                    continue
                
                # Validar categoria
                category = row['category'].lower()
                if category not in ['professor', 'admin']:
                    category = 'professor'  # Valor padrão
                
                # Criar novo usuário
                new_user = User(
                    name=row['name'],
                    email=row['email'],
                    user_name=user_name,
                    category=category
                )
                
                # Definir senha no padrão: nome de usuário + $101
                new_user.password = f"{user_name}$101"
                
                db.session.add(new_user)
                success_count += 1
                
            except Exception as e:
                error_count += 1
                continue
        
        # Commit das alterações
        db.session.commit()
        
        # Mensagem de feedback
        if success_count > 0:
            flash(f'Sucesso ao cadastrar {success_count} usuários', 'success')
        if error_count > 0:
            flash(f'{error_count} usuários não foram cadastrados (já existiam ou houve erro)', 'warning')
        
    except Exception as e:
        db.session.rollback()
        flash('Erro ao processar o arquivo CSV', 'error')
    
    return redirect(url_for('admin.users'))

@bp.route('/users/<int:user_id>/edit')
@login_required
def edit_user(user_id):
    if current_user.category != 'admin':
        flash('Acesso negado. Apenas administradores podem editar usuários.', 'error')
        return redirect(url_for('admin.index'))
    
    user = User.query.get_or_404(user_id)
    return render_template('admin/user_form.html', user=user)

@bp.route('/users/<int:user_id>/update', methods=['POST'])
@login_required
def update_user(user_id):
    if current_user.category != 'admin':
        flash('Acesso negado. Apenas administradores podem editar usuários.', 'error')
        return redirect(url_for('admin.index'))
    
    user = User.query.get_or_404(user_id)
    
    # Verificar se o email já existe para outro usuário
    existing_user = User.query.filter(
        User.email == request.form.get('email'),
        User.id != user_id
    ).first()
    
    if existing_user:
        flash('Este email já está cadastrado para outro usuário.', 'error')
        return redirect(url_for('admin.edit_user', user_id=user_id))
    
    # Verificar se o nome de usuário já existe para outro usuário
    existing_username = User.query.filter(
        User.user_name == request.form.get('user_name'),
        User.id != user_id
    ).first()
    
    if existing_username:
        flash('Este nome de usuário já está em uso.', 'error')
        return redirect(url_for('admin.edit_user', user_id=user_id))
    
    # Atualizar os dados do usuário
    user.name = request.form.get('name')
    user.email = request.form.get('email')
    user.user_name = request.form.get('user_name')
    user.category = request.form.get('category')
    
    try:
        db.session.commit()
        flash('Usuário atualizado com sucesso!', 'success')
    except Exception as e:
        db.session.rollback()
        flash('Erro ao atualizar usuário.', 'error')
    
    return redirect(url_for('admin.users'))

@bp.route('/users/<int:id>/delete')
def delete_user(id):
    user = User.query.get_or_404(id)
    user.is_active = False
    db.session.commit()
    flash('Usuário removido com sucesso!', 'success')
    return redirect(url_for('admin.users'))

@bp.route('/common-incidents')
@login_required
def common_incidents():
    incidents = CommonIncident.query.filter_by(deleted_at=None).order_by(CommonIncident.description).all()
    return render_template('admin/common_incidents.html', incidents=incidents)

@bp.route('/common-incidents/create', methods=['GET', 'POST'])
@login_required
def create_common_incident():
    if request.method == 'POST':
        description = request.form.get('description')
        
        if not description:
            flash('A descrição é obrigatória', 'error')
            return redirect(url_for('admin.create_common_incident'))
        
        incident = CommonIncident(description=description)
        db.session.add(incident)
        db.session.commit()
        
        flash('Ocorrência criada com sucesso!', 'success')
        return redirect(url_for('admin.common_incidents'))
    
    return render_template('admin/common_incident_form.html')

@bp.route('/common-incidents/<int:id>/edit', methods=['GET', 'POST'])
@login_required
def edit_common_incident(id):
    incident = CommonIncident.query.get_or_404(id)
    
    if request.method == 'POST':
        description = request.form.get('description')
        
        if not description:
            flash('A descrição é obrigatória', 'error')
            return redirect(url_for('admin.edit_common_incident', id=id))
        
        incident.description = description
        db.session.commit()
        
        flash('Ocorrência atualizada com sucesso!', 'success')
        return redirect(url_for('admin.common_incidents'))
    
    return render_template('admin/common_incident_form.html', incident=incident)

@bp.route('/common-incidents/<int:id>/delete')
@login_required
def delete_common_incident(id):
    incident = CommonIncident.query.get_or_404(id)
    incident.deleted_at = datetime.utcnow()
    db.session.commit()
    
    flash('Ocorrência removida com sucesso!', 'success')
    return redirect(url_for('admin.common_incidents'))

@bp.route('/reports')
@login_required
@admin_required
def reports():
    # Filtros
    status = request.args.get('status')
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    course_id = request.args.get('course_id')
    class_id = request.args.get('class_id')
    student_id = request.args.get('student_id')
    student_name = request.args.get('student')  # Adicionado para filtrar por nome do aluno
    
    # Query base
    query = Incident.query.join(Incident.student).join(Student.class_).join(Class.course)
    
    # Se o admin está associado a um curso, filtra apenas as ocorrências desse curso
    if is_admin_associated_with_course(current_user.email):
        course = Course.query.filter_by(coordinator_email=current_user.email).first()
        if course:
            query = query.filter(Class.course_id == course.id)
            # Filtra cursos e turmas apenas para o curso do admin
            courses = Course.query.filter_by(id=course.id, is_active=True).all()
            classes = Class.query.filter_by(course_id=course.id, is_active=True).all()
        else:
            courses = []
            classes = []
    else:
        # Se não está associado a um curso, mostra todos os cursos e turmas ativos
        courses = Course.query.filter_by(is_active=True).all()
        classes = Class.query.filter_by(is_active=True).all()
    
    # Aplicar filtros
    if status:
        query = query.filter(Incident.status == status)
    
    if start_date:
        start_date = datetime.strptime(start_date, '%Y-%m-%d')
        query = query.filter(Incident.incident_date >= start_date)
    
    if end_date:
        end_date = datetime.strptime(end_date, '%Y-%m-%d')
        # Adiciona 23:59:59 ao final do dia
        end_date = end_date.replace(hour=23, minute=59, second=59)
        query = query.filter(Incident.incident_date <= end_date)
    
    if course_id:
        query = query.filter(Class.course_id == course_id)
    
    if class_id:
        query = query.filter(Student.class_id == class_id)
    
    if student_id:
        query = query.filter(Incident.student_id == student_id)
    
    if student_name:  # Adicionado filtro por nome do aluno
        query = query.filter(
            db.or_(
                Student.name.ilike(f'%{student_name}%'),
                Student.ra.ilike(f'%{student_name}%')
            )
        )
    
    # Ordenar por data decrescente
    incidents = query.order_by(Incident.incident_date.desc()).all()
    
    # Obter opções para os filtros
    students = Student.query.filter_by(is_active=True).all()
    
    # Obter tipos de ocorrências comuns
    common_incidents = CommonIncident.query.filter_by(deleted_at=None).order_by(CommonIncident.description).all()
    
    return render_template('admin/reports.html',
                         incidents=incidents,
                         courses=courses,
                         classes=classes,
                         students=students,
                         common_incidents=common_incidents,
                         status=status,
                         start_date=start_date,
                         end_date=end_date,
                         course_id=course_id,
                         class_id=class_id,
                         student_id=student_id,
                         student_name=student_name)  # Adicionado para manter o valor do filtro

@bp.route('/reports/export')
@login_required
@admin_required
def export_reports():
    # Obter os mesmos filtros da rota de relatórios
    query = Incident.query.join(Student).join(Class).join(Course).join(User)
    
    # Se o admin está associado a um curso, filtra apenas as ocorrências desse curso
    if is_admin_associated_with_course(current_user.email):
        course = Course.query.filter_by(coordinator_email=current_user.email).first()
        if course:
            query = query.filter(Course.id == course.id)
    
    course_id = request.args.get('course_id')
    class_id = request.args.get('class_id')
    student_query = request.args.get('student')
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    status = request.args.get('status')
    user_id = request.args.get('user_id')
    
    if course_id:
        query = query.filter(Course.id == course_id)
    if class_id:
        query = query.filter(Class.id == class_id)
    if student_query:
        query = query.filter(
            db.or_(
                Student.name.ilike(f'%{student_query}%'),
                Student.ra.ilike(f'%{student_query}%')
            )
        )
    if start_date:
        query = query.filter(Incident.incident_date >= datetime.strptime(start_date, '%Y-%m-%d'))
    if end_date:
        query = query.filter(Incident.incident_date <= datetime.strptime(end_date, '%Y-%m-%d'))
    if status:
        query = query.filter(Incident.status == status)
    if user_id:
        query = query.filter(User.id == user_id)
    
    incidents = query.order_by(Incident.incident_date.desc()).all()
    
    # Criar DataFrame com os dados
    data = []
    for incident in incidents:
        data.append({
            'Data': incident.incident_date.strftime('%d/%m/%Y %H:%M'),
            'Curso': incident.student.class_.course.name,
            'Turma': incident.student.class_.name,
            'Aluno': incident.student.name,
            'RA': incident.student.ra,
            'Ocorrência': incident.common_incident.description if incident.common_incident else incident.description,
            'Status': incident.status,
            'Registrado por': incident.user.name,
            'SIAPE': incident.user.user_name
        })
    
    df = pd.DataFrame(data)
    
    # Criar arquivo Excel em memória
    output = BytesIO()
    with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
        df.to_excel(writer, sheet_name='Relatório de Ocorrências', index=False)
        
        # Ajustar largura das colunas
        worksheet = writer.sheets['Relatório de Ocorrências']
        for i, col in enumerate(df.columns):
            max_length = max(df[col].astype(str).apply(len).max(), len(col)) + 2
            worksheet.set_column(i, i, max_length)
    
    output.seek(0)
    
    # Gerar nome do arquivo com data e hora
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    filename = f'relatorio_ocorrencias_{timestamp}.xlsx'
    
    return send_file(
        output,
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        as_attachment=True,
        download_name=filename
    )

@bp.route('/incidents/<int:id>/update-status', methods=['POST'])
@login_required
@admin_required
def update_incident_status(id):
    incident = Incident.query.get_or_404(id)
    
    # Se o admin está associado a um curso, verifica se a ocorrência é do seu curso
    if is_admin_associated_with_course(current_user.email):
        course = Course.query.filter_by(coordinator_email=current_user.email).first()
        if course and incident.student.class_.course_id != course.id:
            flash('Você não tem permissão para alterar o status desta ocorrência.', 'error')
            return redirect(url_for('admin.reports'))
    
    new_status = request.form.get('status')
    if new_status not in ['open', 'closed']:
        flash('Status inválido.', 'error')
        return redirect(url_for('admin.view_incident', id=id))
    
    incident.status = new_status
    db.session.commit()
    
    flash(f'Ocorrência {new_status} com sucesso!', 'success')
    return redirect(url_for('admin.view_incident', id=id))

@bp.route('/api/courses')
@login_required
@admin_required
def api_courses():
    query = request.args.get('q', '').strip()
    if not query:
        return jsonify([])
    
    courses = Course.query.filter(
        Course.name.ilike(f'%{query}%'),
        Course.is_active == True
    ).all()
    
    return jsonify([{
        'id': course.id,
        'name': course.name
    } for course in courses])

@bp.route('/api/courses/<int:id>')
@login_required
@admin_required
def api_course(id):
    course = Course.query.get_or_404(id)
    return jsonify({
        'id': course.id,
        'name': course.name
    })

@bp.route('/incidents/<int:id>')
@login_required
@admin_required
def view_incident(id):
    if not can_access_incident(id):
        flash('Acesso não autorizado a esta ocorrência.', 'error')
        return redirect(url_for('admin.index'))
    
    incident = Incident.query.get_or_404(id)
    is_admin = current_user.category.lower() == 'admin'
    return render_template('admin/view_incident.html', incident=incident, is_admin=is_admin)

@bp.route('/api/classes')
@login_required
@admin_required
def api_classes():
    query = request.args.get('q', '').strip()
    if not query:
        return jsonify([])
    
    classes = Class.query.filter(
        Class.name.ilike(f'%{query}%'),
        Class.is_active == True
    ).all()
    
    return jsonify([{
        'id': class_.id,
        'name': class_.name
    } for class_ in classes])

@bp.route('/api/classes/<int:id>')
@login_required
@admin_required
def api_class(id):
    class_ = Class.query.get_or_404(id)
    return jsonify({
        'id': class_.id,
        'name': class_.name
    })

@bp.route('/api/students')
@login_required
@admin_required
def api_students():
    query = request.args.get('q', '')
    if not query:
        return jsonify([])
    
    students = Student.query.filter(
        Student.is_active == True,
        or_(
            Student.name.ilike(f'%{query}%'),
            Student.ra.ilike(f'%{query}%')
        )
    ).all()
    
    return jsonify([{
        'id': student.id,
        'name': student.name,
        'ra': student.ra
    } for student in students])

@bp.route('/api/students/<int:id>')
@login_required
@admin_required
def api_student(id):
    student = Student.query.get_or_404(id)
    return jsonify({
        'id': student.id,
        'name': student.name,
        'ra': student.ra
    })

@bp.route('/incidents/<int:id>/edit', methods=['GET', 'POST'])
@login_required
@admin_required
def edit_incident(id):
    incident = Incident.query.get_or_404(id)
    
    # Se o admin está associado a um curso, verifica se a ocorrência é do seu curso
    if is_admin_associated_with_course(current_user.email):
        course = Course.query.filter_by(coordinator_email=current_user.email).first()
        if course and incident.student.class_.course_id != course.id:
            flash('Você não tem permissão para editar esta ocorrência.', 'error')
            return redirect(url_for('admin.view_incident', id=id))
    
    if request.method == 'POST':
        # Converter a data/hora do formato HTML para datetime
        incident_date_str = request.form.get('incident_date')
        incident_date = datetime.strptime(incident_date_str, '%Y-%m-%dT%H:%M')
        
        incident.incident_date = incident_date
        incident.description = request.form.get('description')
        incident.common_incident_id = request.form.get('common_incident_id') or None
        incident.student_id = request.form.get('student_id')
        
        db.session.commit()
        flash('Ocorrência atualizada com sucesso!', 'success')
        return redirect(url_for('admin.view_incident', id=id))
    
    # Se o admin está associado a um curso, filtra apenas os alunos do seu curso
    if is_admin_associated_with_course(current_user.email):
        course = Course.query.filter_by(coordinator_email=current_user.email).first()
        if course:
            students = Student.query.join(Student.class_).filter(Class.course_id == course.id, Student.is_active == True).all()
        else:
            students = []
    else:
        students = Student.query.filter_by(is_active=True).all()
    
    common_incidents = CommonIncident.query.filter_by(deleted_at=None).order_by(CommonIncident.description).all()
    
    return render_template('admin/incident_form.html',
                         incident=incident,
                         students=students,
                         common_incidents=common_incidents)

# Curricular Units CRUD
@bp.route('/curricular-units')
@login_required
@admin_required
def curricular_units():
    # Query base para unidades curriculares
    curricular_units_query = CurricularUnit.query.filter_by(is_active=True)
    
    # Se o admin está associado a um curso, filtra apenas as unidades curriculares desse curso
    if is_admin_associated_with_course(current_user.email):
        course = Course.query.filter_by(coordinator_email=current_user.email).first()
        if course:
            curricular_units_query = curricular_units_query.filter_by(course_id=course.id)
    
    curricular_units = curricular_units_query.all()
    return render_template('admin/curricular_units/index.html', curricular_units=curricular_units)

@bp.route('/curricular-units/new', methods=['GET', 'POST'])
@login_required
@admin_required
def new_curricular_unit():
    if request.method == 'POST':
        name = request.form.get('name')
        course_id = request.form.get('course_id')
        shift = request.form.get('shift').lower()
        
        curricular_unit = CurricularUnit(name=name, course_id=course_id, shift=shift)
        db.session.add(curricular_unit)
        db.session.commit()
        
        flash('Unidade curricular criada com sucesso!', 'success')
        return redirect(url_for('admin.curricular_units'))
    
    courses = Course.query.filter_by(is_active=True).all()
    return render_template('admin/curricular_units/form.html', courses=courses)

@bp.route('/curricular-units/<int:id>/edit', methods=['GET', 'POST'])
@login_required
@admin_required
def edit_curricular_unit(id):
    curricular_unit = CurricularUnit.query.get_or_404(id)
    if request.method == 'POST':
        curricular_unit.name = request.form.get('name')
        curricular_unit.course_id = request.form.get('course_id')
        curricular_unit.shift = request.form.get('shift').lower()
        db.session.commit()
        flash('Unidade curricular atualizada com sucesso!', 'success')
        return redirect(url_for('admin.curricular_units'))
    
    courses = Course.query.filter_by(is_active=True).all()
    return render_template('admin/curricular_units/form.html', curricular_unit=curricular_unit, courses=courses)

@bp.route('/curricular-units/<int:id>/delete', methods=['POST'])
@login_required
@admin_required
def delete_curricular_unit(id):
    curricular_unit = CurricularUnit.query.get_or_404(id)
    curricular_unit.is_active = False
    db.session.commit()
    flash('Unidade curricular removida com sucesso!', 'success')
    return redirect(url_for('admin.curricular_units'))

@bp.route('/curricular-units/import', methods=['POST'])
@login_required
@admin_required
def import_curricular_units():
    if 'file' not in request.files:
        flash('Nenhum arquivo enviado', 'error')
        return redirect(url_for('admin.curricular_units'))
    
    file = request.files['file']
    if file.filename == '':
        flash('Nenhum arquivo selecionado', 'error')
        return redirect(url_for('admin.curricular_units'))
    
    if not file.filename.endswith('.csv'):
        flash('O arquivo deve ser um CSV', 'error')
        return redirect(url_for('admin.curricular_units'))
    
    try:
        # Ler o arquivo CSV
        df = pd.read_csv(file)
        
        # Verificar colunas obrigatórias
        required_columns = ['curso', 'unidade_curricular', 'turno']
        if not all(col in df.columns for col in required_columns):
            flash('O arquivo CSV deve conter as colunas: curso, unidade_curricular e turno', 'error')
            return redirect(url_for('admin.curricular_units'))
        
        # Processar cada linha
        success_count = 0
        error_count = 0
        for _, row in df.iterrows():
            try:
                # Buscar o curso pelo nome
                course = Course.query.filter_by(name=row['curso']).first()
                if not course:
                    error_count += 1
                    continue
                
                # Verificar se a unidade curricular já existe para este curso
                existing_unit = CurricularUnit.query.filter_by(
                    name=row['unidade_curricular'],
                    course_id=course.id
                ).first()
                
                if existing_unit:
                    error_count += 1
                    continue
                
                # Criar nova unidade curricular
                new_unit = CurricularUnit(
                    name=row['unidade_curricular'],
                    course_id=course.id,
                    shift=row['turno']
                )
                
                db.session.add(new_unit)
                success_count += 1
                
            except Exception as e:
                error_count += 1
                continue
        
        db.session.commit()
        
        flash(f'Importação concluída: {success_count} unidades curriculares importadas com sucesso, {error_count} ignoradas/erros', 'success')
        
    except Exception as e:
        db.session.rollback()
        flash(f'Erro ao processar o arquivo: {str(e)}', 'error')
    
    return redirect(url_for('admin.curricular_units'))

@bp.route('/incidents/<int:id>/close', methods=['POST'])
@login_required
@admin_required
def close_incident(id):
    if not can_access_incident(id):
        flash('Acesso não autorizado a esta ocorrência.', 'error')
        return redirect(url_for('admin.index'))
    
    incident = Incident.query.get_or_404(id)
    solution_description = request.form.get('solution_description')
    
    if not solution_description:
        flash('A descrição da solução é obrigatória.', 'error')
        return redirect(url_for('admin.view_incident', id=id))
    
    incident.status = 'closed'
    incident.solution_description = solution_description
    incident.closed_by_user_id = current_user.id
    
    db.session.commit()
    flash('Ocorrência fechada com sucesso!', 'success')
    return redirect(url_for('admin.view_incident', id=id)) 