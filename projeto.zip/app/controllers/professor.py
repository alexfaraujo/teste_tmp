from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify, current_app
from flask_login import login_required, current_user
from app import db
from app.models.course import Course
from app.models.class_ import Class
from app.models.student import Student
from app.models.incident import Incident
from app.models.common_incident import CommonIncident
from datetime import datetime, timedelta
from app.models.admin import User
from app.models.curricular_unit import CurricularUnit
from twilio.rest import Client

bp = Blueprint('professor', __name__, url_prefix='/professor')

@bp.before_request
def before_request():
    # Verifica autenticação para todas as rotas
    if not current_user.is_authenticated:
        flash('Por favor, faça login para acessar esta página.', 'error')
        return redirect(url_for('professor_auth.login'))
    
    if current_user.category.lower() == 'admin':
        return redirect(url_for('main.index'))
    elif current_user.category != 'professor':
        flash('Acesso não autorizado.', 'error')
        return redirect(url_for('main.index'))

@bp.route('/')
@login_required
def index():
    today = datetime.now().date()
    week_ago = today - timedelta(days=7)
    
    today_incidents = Incident.query.filter(
        db.func.date(Incident.incident_date) == today,
        Incident.registered_by == current_user.id
    ).count()
    
    week_incidents = Incident.query.filter(
        db.func.date(Incident.incident_date) >= week_ago,
        Incident.registered_by == current_user.id
    ).count()
    
    open_incidents = Incident.query.filter(
        Incident.status == 'open',
        Incident.registered_by == current_user.id
    ).count()
    
    recent_incidents = Incident.query.filter(
        Incident.registered_by == current_user.id
    ).order_by(Incident.incident_date.desc()).limit(10).all()
    
    return render_template('professor/dashboard.html',
                         today_incidents=today_incidents,
                         week_incidents=week_incidents,
                         open_incidents=open_incidents,
                         recent_incidents=recent_incidents)

@bp.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    if request.method == 'POST':
        current_password = request.form.get('current_password')
        new_password = request.form.get('new_password')
        confirm_password = request.form.get('confirm_password')

        if not current_user.verify_password(current_password):
            flash('Senha atual incorreta', 'error')
            return redirect(url_for('professor.profile'))

        if new_password != confirm_password:
            flash('As senhas não coincidem', 'error')
            return redirect(url_for('professor.profile'))

        if len(new_password) < 6:
            flash('A senha deve ter no mínimo 6 caracteres', 'error')
            return redirect(url_for('professor.profile'))

        current_user.password = new_password
        db.session.commit()
        flash('Senha alterada com sucesso', 'success')
        return redirect(url_for('professor.profile'))

    return render_template('professor/profile.html')

@bp.route('/api/courses')
@login_required
def api_courses():
    query = request.args.get('q', '').lower()
    # Buscar cursos do banco de dados
    courses = Course.query.filter(Course.name.ilike(f'%{query}%')).all()
    return jsonify([course.name for course in courses])

@bp.route('/api/classes')
@login_required
def api_classes():
    course = request.args.get('course', '')
    query = request.args.get('q', '').lower()
    # Buscar unidades curriculares do banco de dados filtradas por curso
    curricular_units = CurricularUnit.query.join(Course).filter(
        Course.name.ilike(f'%{course}%'),
        CurricularUnit.name.ilike(f'%{query}%'),
        CurricularUnit.is_active == True
    ).all()
    return jsonify([curricular_unit.name for curricular_unit in curricular_units])

@bp.route('/api/students')
@login_required
def api_students():
    course = request.args.get('course', '').strip()
    query = request.args.get('q', '').lower()
    
    # Se não houver curso selecionado, retornar lista vazia
    if not course:
        return jsonify([])
    
    # Buscar alunos do banco de dados filtrados apenas por curso
    students = Student.query.join(Course).filter(
        Course.name == course,  # Usar comparação exata para garantir que é o curso correto
        Student.is_active == True,
        db.or_(
            Student.name.ilike(f'%{query}%'),
            Student.ra.ilike(f'%{query}%')
        )
    ).all()
    
    # Retornar os dados no formato esperado pelo autocomplete
    return jsonify([{
        'label': f"{student.name} ({student.ra})",
        'value': f"{student.name} ({student.ra})",
        'id': student.id
    } for student in students])

@bp.route('/register_incident', methods=['GET', 'POST'])
@login_required
def register_incident():
    if request.method == 'GET':
        # Buscar todos os tipos de ocorrência comuns ativos
        common_incidents = CommonIncident.query.filter_by(deleted_at=None).order_by(CommonIncident.description).all()
        return render_template('professor/register_incident.html', common_incidents=common_incidents)

    # Obter dados do formulário
    student_info = request.form.get('student')
    course_name = request.form.get('course')
    class_name = request.form.get('class')  # Agora é o nome da unidade curricular
    incident_date = request.form.get('incident_date')
    common_incident_id = request.form.get('common_incident')
    description = request.form.get('description')

    try:
        # Extrair RA do aluno do formato "Nome (RA)"
        try:
            student_ra = student_info.split('(')[1].rstrip(')')
            student_name = student_info.split('(')[0]
        except IndexError:
            flash('Formato inválido do RA do aluno', 'error')
            return redirect(url_for('professor.register_incident'))
        
        # Validar se o campo de observações está preenchido quando "Outro" é selecionado
        if common_incident_id == "other" and not description:
            flash('O campo de observações é obrigatório quando seleciona "Outro" como tipo de ocorrência', 'error')
            return redirect(url_for('professor.register_incident'))
        
        # Buscar entidades no banco
        course = Course.query.filter_by(name=course_name).first()
        if not course:
            flash('Curso não encontrado', 'error')
            return redirect(url_for('professor.register_incident'))
            
        # Buscar a unidade curricular
        curricular_unit = CurricularUnit.query.filter_by(
            name=class_name,
            course_id=course.id,
            is_active=True
        ).first()
        
        if not curricular_unit:
            flash('Unidade curricular não encontrada para este curso', 'error')
            return redirect(url_for('professor.register_incident'))
            
        # Buscar o aluno usando o RA
        student = Student.query.filter_by(
            ra=student_ra,
            is_active=True
        ).first()
        
        if not student:
            flash('Aluno não encontrado ou está inativo', 'error')
            return redirect(url_for('professor.register_incident'))

        # Validar data da ocorrência
        try:
            incident_date = datetime.fromisoformat(incident_date)
            if incident_date > datetime.now():
                flash('A data da ocorrência não pode ser futura', 'error')
                return redirect(url_for('professor.register_incident'))
        except ValueError:
            flash('Data da ocorrência inválida', 'error')
            return redirect(url_for('professor.register_incident'))

        # Criar a ocorrência
        incident = Incident(
            student_id=student.id,
            common_incident_id=common_incident_id if common_incident_id else None,
            description=description,
            registered_by=current_user.id,
            incident_date=incident_date
        )
        db.session.add(incident)
        db.session.commit()

        flash('Ocorrência registrada com sucesso!', 'success')
        
        # Envio de notificação via Twilio WhatsApp
        try:
            # Usar as credenciais diretamente do config
            client = Client(
                current_app.config['TWILIO_ACCOUNT_SID'],
                current_app.config['TWILIO_AUTH_TOKEN']
            )
            
            message = client.messages.create(
                from_=current_app.config['TWILIO_FROM_NUMBER'],
                content_sid=current_app.config['TWILIO_CONTENT_SID'],
                content_variables='{"professor":"'+current_user.name+'","estudante":"'+student_name+'"}',
                to=current_app.config['TWILIO_TO_NUMBER']
            )
            
            print(f"Mensagem Twilio enviada com sucesso. SID: {message.sid}")
        except Exception as e:
            print(f"Erro ao enviar notificação Twilio: {str(e)}")
            # Não interrompe o fluxo principal, apenas loga o erro
        
        return redirect(url_for('professor.dashboard'))

    except Exception as e:
        flash('Erro ao registrar ocorrência. Por favor, tente novamente.', 'error')
        print(e)
        return redirect(url_for('professor.register_incident'))

@bp.route('/dashboard')
@login_required
def dashboard():
    today = datetime.now().date()
    week_ago = today - timedelta(days=7)
    
    today_incidents = Incident.query.filter(
        db.func.date(Incident.incident_date) == today,
        Incident.registered_by == current_user.id
    ).count()
    
    week_incidents = Incident.query.filter(
        db.func.date(Incident.incident_date) >= week_ago,
        Incident.registered_by == current_user.id
    ).count()
    
    open_incidents = Incident.query.filter(
        Incident.status == 'open',
        Incident.registered_by == current_user.id
    ).count()
    
    recent_incidents = Incident.query.filter(
        Incident.registered_by == current_user.id
    ).order_by(Incident.incident_date.desc()).limit(10).all()
    
    return render_template('professor/dashboard.html',
                         today_incidents=today_incidents,
                         week_incidents=week_incidents,
                         open_incidents=open_incidents,
                         recent_incidents=recent_incidents) 