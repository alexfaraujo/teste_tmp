from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user, logout_user
from app.models.incident import Incident
from app.models.course import Course
from app.models.class_ import Class
from app.models.student import Student
from app import db
from datetime import datetime, timedelta

bp = Blueprint('main', __name__)

@bp.route('/')
def index():
    if not current_user.is_authenticated:
        return redirect(url_for('professor_auth.login'))
    
    # Se o usuário for administrador, redireciona para o painel admin
    if current_user.category.lower() == 'admin':
        return redirect(url_for('admin.index'))
    
    # Se o usuário for professor, redireciona para o dashboard do professor
    if current_user.category == 'professor':
        return redirect(url_for('professor.dashboard'))
    
    # Se o usuário não for nem admin nem professor, mostra uma mensagem de erro
    flash('Acesso não autorizado.', 'error')
    logout_user()  # Desloga o usuário para evitar loops
    return redirect(url_for('professor_auth.login'))

@bp.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        title = request.form.get('title')
        description = request.form.get('description')
        location = request.form.get('location')

        if not all([title, description, location]):
            flash('Please fill in all fields', 'error')
            return redirect(url_for('main.register'))

        incident = Incident(
            title=title,
            description=description,
            location=location
        )

        db.session.add(incident)
        db.session.commit()

        flash('Incident registered successfully!', 'success')
        return redirect(url_for('main.index'))

    return render_template('register.html') 