from flask import Flask, flash, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, current_user
from flask_migrate import Migrate
from config import Config
import os

db = SQLAlchemy()
login_manager = LoginManager()
migrate = Migrate()

def professor_required(f):
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or current_user.category != 'professor':
            flash('Acesso permitido apenas para professores.', 'error')
            return redirect(url_for('professor_auth.login'))
        return f(*args, **kwargs)
    decorated_function.__name__ = f.__name__
    return decorated_function

def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)

    # Ensure the templates directory is properly set
    app.template_folder = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'templates')
    app.static_folder = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static')

    # Configuração de sessão
    app.config['PERMANENT_SESSION_LIFETIME'] = 1800  # 30 minutos em segundos
    app.config['SESSION_COOKIE_SECURE'] = os.environ.get('FLASK_ENV') == 'production'  # Só permite cookies em HTTPS em produção
    app.config['SESSION_COOKIE_HTTPONLY'] = True  # Previne acesso via JavaScript
    app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'  # Proteção contra CSRF

    db.init_app(app)
    login_manager.init_app(app)
    migrate.init_app(app, db)
    login_manager.login_view = 'professor_auth.login'
    login_manager.login_message = 'Por favor, faça login para acessar esta página.'
    login_manager.login_message_category = 'info'

    @login_manager.user_loader
    def load_user(user_id):
        from app.models.admin import User
        return User.query.get(int(user_id))

    with app.app_context():
        # Importar todos os modelos para garantir que sejam registrados
        from app.models.admin import User
        from app.models.course import Course
        from app.models.class_ import Class
        from app.models.student import Student
        from app.models.incident import Incident
        from app.models.common_incident import CommonIncident
        from app.models.curricular_unit import CurricularUnit

        from app.controllers import main, admin, auth, professor_auth, professor
        app.register_blueprint(main.bp)
        app.register_blueprint(admin.bp)
        app.register_blueprint(auth.bp)
        app.register_blueprint(professor_auth.bp)
        app.register_blueprint(professor.bp)

        # Create database tables
        db.create_all()

    from app.controllers.admin import is_admin_associated_with_course
    
    # Adiciona a função ao contexto dos templates
    @app.context_processor
    def utility_processor():
        return dict(is_admin_associated_with_course=is_admin_associated_with_course)

    return app 