// Backend-only mode
let qrFile = null;
let selfieFile = null;

document.getElementById('file-input').addEventListener('change', function (e) {
    if (e.target.files && e.target.files.length > 0) {
        qrFile = e.target.files[0];
        checkAndSend();
    }
});

const selfieInput = document.getElementById('selfie-input');
if (selfieInput) {
    selfieInput.addEventListener('change', function (e) {
        if (e.target.files && e.target.files.length > 0) {
            selfieFile = e.target.files[0];

            // Show preview
            const reader = new FileReader();
            reader.onload = function (e) {
                document.getElementById('selfie-img').src = e.target.result;
                document.getElementById('selfie-preview').style.display = 'block';
                document.getElementById('selfie-btn-text').innerText = '🤳 Selfie Capturada';
            }
            reader.readAsDataURL(selfieFile);

            checkAndSend();
        }
    });
}

function checkAndSend() {
    const selfieRequired = !!document.getElementById('selfie-input');

    if (selfieRequired) {
        if (qrFile && selfieFile) {
            enviarParaBackend(qrFile, selfieFile);
        } else if (qrFile && !selfieFile) {
            alert('⚠️ Por favor, tire também a selfie de confirmação para finalizar o registro.');
        } else if (!qrFile && selfieFile) {
            // Wait for QR code
        }
    } else {
        if (qrFile) {
            enviarParaBackend(qrFile);
        }
    }
}

function enviarParaBackend(file, selfie = null) {
    const formData = new FormData();
    formData.append('file', file);
    if (selfie) {
        formData.append('selfie', selfie);
    }

    const btnText = document.getElementById('btn-text');
    const originalText = btnText.innerText;

    btnText.innerText = "⏳ Processando...";
    document.querySelector('label[for="file-input"]').style.opacity = "0.7";
    if (selfie) {
        document.querySelector('label[for="selfie-input"]').style.opacity = "0.7";
    }

    fetch('/frequencia', {
        method: 'POST',
        body: formData
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('✅ ' + data.message + (data.data ? '\nDados: ' + data.data : ''));
                // Optional: Redirect or update UI
                if (data.success) window.location.href = '/perfil';
            } else {
                alert('❌ ' + data.message);
            }
        })
        .catch(error => {
            console.error('Erro:', error);
            alert('Erro ao processar imagem no servidor.');
        })
        .finally(() => {
            btnText.innerText = originalText;
            document.querySelector('label[for="file-input"]').style.opacity = "1";
            if (selfie) {
                document.querySelector('label[for="selfie-input"]').style.opacity = "1";
            }
            // Clear inputs
            document.getElementById('file-input').value = '';
            if (selfieInput) selfieInput.value = '';
            qrFile = null;
            selfieFile = null;
        });
}
