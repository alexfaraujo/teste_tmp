import os
from dotenv import load_dotenv
from datetime import timedelta
import pytz
import sqlite3

basedir = os.path.abspath(os.path.dirname(__file__))
load_dotenv()

class Config:
    # Configurações básicas
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'dev'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    # Configurações do SQLite
    SQLALCHEMY_DATABASE_URI = 'sqlite:///app.db'
    
    # Otimizações do SQLite
    SQLALCHEMY_ENGINE_OPTIONS = {
        'pool_pre_ping': True,
        'pool_recycle': 3600,
        'connect_args': {
            'timeout': 30,
            'check_same_thread': False,
            'detect_types': sqlite3.PARSE_DECLTYPES | sqlite3.PARSE_COLNAMES
        }
    }
    
    # Configurações de Sessão
    PERMANENT_SESSION_LIFETIME = timedelta(minutes=60)
    SESSION_COOKIE_SECURE = True
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = 'Lax'
    
    # Configurações de Upload
    UPLOAD_FOLDER = 'uploads'
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB max file size
    
    # Configurações de Cache
    CACHE_TYPE = 'simple'
    CACHE_DEFAULT_TIMEOUT = 300
    
    # Configurações de Logging
    LOG_TO_STDOUT = os.environ.get('LOG_TO_STDOUT')
    LOG_LEVEL = 'INFO'
    
    # Configurações de Performance
    JSONIFY_PRETTYPRINT_REGULAR = False
    JSON_SORT_KEYS = False
    
    # Configuração do fuso horário
    TIMEZONE = 'America/Campo_Grande'  # Fuso horário de Campo Grande/MS
    
    # Configurações do Twilio
    TWILIO_ACCOUNT_SID = os.environ.get('TWILIO_ACCOUNT_SID', 'AC2a6bbf0089364fe7375d942011c7ab0c')
    TWILIO_AUTH_TOKEN = os.environ.get('TWILIO_AUTH_TOKEN', '24f7584ea045b1b969831fffd628400e')
    TWILIO_FROM_NUMBER = os.environ.get('TWILIO_FROM_NUMBER', 'whatsapp:+14155238886')
    TWILIO_CONTENT_SID = os.environ.get('TWILIO_CONTENT_SID', 'HX159d31f1f3345bce0cffda7c11d4774f')
    TWILIO_TO_NUMBER = os.environ.get('TWILIO_TO_NUMBER', 'whatsapp:+556696314581') 