# Configuração de Fuso Horário

O sistema utiliza o fuso horário de Campo Grande/MS (America/Campo_Grande) para todas as operações que envolvem datas e horários.

## Detalhes Técnicos

- **Fuso Horário**: America/Campo_Grande
- **UTC Offset**: UTC-4 (horário padrão) / UTC-3 (horário de verão)
- **Região**: Campo Grande, Mato Grosso do Sul, Brasil

## Configuração

O fuso horário está configurado no arquivo `config.py`:

```python
TIMEZONE = 'America/Campo_Grande'
```

## Migração

Uma migração foi criada para atualizar todos os registros existentes para o novo fuso horário. O arquivo de migração está localizado em:

```
migrations/versions/update_timestamps_to_local.py
```

## Observações

- Todos os novos registros serão salvos com o horário de Campo Grande
- Os registros existentes foram migrados para o novo fuso horário
- O sistema considera automaticamente o horário de verão quando aplicável 