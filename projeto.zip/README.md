# Incident Registration System

A simple and efficient web system for registering incidents, inspired by IFMS Acessa system.

## Features

- Quick incident registration (under 60 seconds)
- Clean and intuitive interface
- MVC architecture
- SQLite database
- Flask backend
- Responsive design

## Project Structure

```
incident_system/
├── app/
│   ├── __init__.py
│   ├── models/
│   ├── controllers/
│   ├── views/
│   └── static/
│       ├── css/
│       ├── js/
│       └── images/
├── config.py
├── requirements.txt
└── run.py
```

## Setup

1. Create a virtual environment:
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Run the application:
```bash
python run.py
```

## Technologies

- Backend: Python + Flask + SQLAlchemy
- Frontend: HTML + CSS + Jinja2 Templates
- Database: SQLite 