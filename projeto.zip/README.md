# Perfil Flask App

Este projeto é uma aplicação web simples desenvolvida em Python utilizando o framework Flask. A aplicação exibe o perfil de uma pessoa em uma interface que simula a visualização em um celular.

## Estrutura do Projeto

O projeto possui a seguinte estrutura de arquivos:

```
perfil-flask-app
├── app.py                # Ponto de entrada da aplicação Flask
├── requirements.txt      # Dependências do projeto
├── .gitignore            # Arquivos e pastas a serem ignorados pelo Git
├── templates             # Diretório contendo os templates HTML
│   ├── base.html        # Template base com estrutura comum
│   └── profile.html     # Template que exibe o perfil da pessoa
├── static                # Diretório para arquivos estáticos (CSS, JS)
│   ├── css
│   │   └── styles.css    # Estilos CSS para a aplicação
│   └── js
│       └── main.js       # Scripts JavaScript para interatividade
└── README.md             # Documentação do projeto
```

## Instalação

1. Clone o repositório:
   ```
   git clone <URL_DO_REPOSITORIO>
   cd perfil-flask-app
   ```

2. Crie um ambiente virtual e ative-o:
   ```
   python -m venv venv
   source venv/bin/activate  # Para Linux/Mac
   venv\Scripts\activate     # Para Windows
   ```

3. Instale as dependências:
   ```
   pip install -r requirements.txt
   ```

## Execução

Para executar a aplicação, utilize o seguinte comando:

```
python app.py
```

A aplicação estará disponível em `http://127.0.0.1:5000/`.

## Contribuição

Sinta-se à vontade para contribuir com melhorias ou correções. Faça um fork do repositório e envie um pull request com suas alterações.

## Licença

Este projeto está licenciado sob a MIT License. Veja o arquivo LICENSE para mais detalhes.