"""Update datetime columns to use UTC

Revision ID: update_datetime_columns
Revises: 70ad03ecaa07
Create Date: 2024-04-23 21:30:00.000000

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import sqlite

# revision identifiers, used by Alembic.
revision = 'update_datetime_columns'
down_revision = '70ad03ecaa07'
branch_labels = None
depends_on = None


def upgrade():
    # SQLite não suporta ALTER COLUMN diretamente, então precisamos:
    # 1. Criar uma nova tabela temporária
    # 2. Copiar os dados
    # 3. Remover a tabela antiga
    # 4. Renomear a tabela temporária
    
    # Criar tabela temporária
    op.create_table(
        'incidents_temp',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('student_id', sa.Integer(), nullable=False),
        sa.Column('common_incident_id', sa.Integer(), nullable=True),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('incident_date', sa.DateTime(), nullable=False),
        sa.Column('status', sa.String(20), nullable=False),
        sa.Column('registered_by', sa.Integer(), nullable=False),
        sa.Column('solution_description', sa.Text(), nullable=True),
        sa.Column('closed_by_user_id', sa.Integer(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.Column('updated_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['student_id'], ['students.id'], ),
        sa.ForeignKeyConstraint(['common_incident_id'], ['common_incidents.id'], ),
        sa.ForeignKeyConstraint(['registered_by'], ['users.id'], ),
        sa.ForeignKeyConstraint(['closed_by_user_id'], ['users.id'], ),
        sa.PrimaryKeyConstraint('id')
    )
    
    # Copiar dados
    op.execute("""
        INSERT INTO incidents_temp 
        SELECT 
            id, student_id, common_incident_id, description, 
            incident_date, status, registered_by, solution_description, 
            closed_by_user_id, created_at, updated_at
        FROM incidents
    """)
    
    # Remover tabela antiga
    op.drop_table('incidents')
    
    # Renomear tabela temporária
    op.rename_table('incidents_temp', 'incidents')


def downgrade():
    # Reverter as alterações
    op.create_table(
        'incidents_temp',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('student_id', sa.Integer(), nullable=False),
        sa.Column('common_incident_id', sa.Integer(), nullable=True),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('incident_date', sa.DateTime(), nullable=False),
        sa.Column('status', sa.String(20), nullable=False),
        sa.Column('registered_by', sa.Integer(), nullable=False),
        sa.Column('solution_description', sa.Text(), nullable=True),
        sa.Column('closed_by_user_id', sa.Integer(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.Column('updated_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['student_id'], ['students.id'], ),
        sa.ForeignKeyConstraint(['common_incident_id'], ['common_incidents.id'], ),
        sa.ForeignKeyConstraint(['registered_by'], ['users.id'], ),
        sa.ForeignKeyConstraint(['closed_by_user_id'], ['users.id'], ),
        sa.PrimaryKeyConstraint('id')
    )
    
    op.execute("""
        INSERT INTO incidents_temp 
        SELECT 
            id, student_id, common_incident_id, description, 
            incident_date, status, registered_by, solution_description, 
            closed_by_user_id, created_at, updated_at
        FROM incidents
    """)
    
    op.drop_table('incidents')
    op.rename_table('incidents_temp', 'incidents') 