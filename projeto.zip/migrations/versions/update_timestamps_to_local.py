"""update timestamps to local timezone

Revision ID: update_timestamps_to_local
Revises: 
Create Date: 2024-03-21 10:00:00.000000

"""
from alembic import op
import sqlalchemy as sa
from datetime import datetime
import pytz

# revision identifiers, used by Alembic.
revision = 'update_timestamps_to_local'
down_revision = None
branch_labels = None
depends_on = None

def upgrade():
    # Get the connection
    conn = op.get_bind()
    
    # Get all tables with timestamp columns
    inspector = sa.inspect(conn)
    tables = inspector.get_table_names()
    
    # Define the timezone
    local_tz = pytz.timezone('America/Campo_Grande')
    
    for table in tables:
        columns = inspector.get_columns(table)
        for column in columns:
            if isinstance(column['type'], (sa.DateTime, sa.TIMESTAMP)):
                # Update all timestamps to local timezone
                conn.execute(
                    f"""
                    UPDATE {table}
                    SET {column['name']} = {column['name']} AT TIME ZONE 'UTC' AT TIME ZONE 'America/Campo_Grande'
                    WHERE {column['name']} IS NOT NULL
                    """
                )

def downgrade():
    # Get the connection
    conn = op.get_bind()
    
    # Get all tables with timestamp columns
    inspector = sa.inspect(conn)
    tables = inspector.get_table_names()
    
    for table in tables:
        columns = inspector.get_columns(table)
        for column in columns:
            if isinstance(column['type'], (sa.DateTime, sa.TIMESTAMP)):
                # Revert timestamps back to UTC
                conn.execute(
                    f"""
                    UPDATE {table}
                    SET {column['name']} = {column['name']} AT TIME ZONE 'America/Campo_Grande' AT TIME ZONE 'UTC'
                    WHERE {column['name']} IS NOT NULL
                    """
                ) 