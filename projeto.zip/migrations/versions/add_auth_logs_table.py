"""Add auth_logs table

Revision ID: add_auth_logs_table
Revises: 
Create Date: 2024-03-19 10:00:00.000000

"""
from alembic import op
import sqlalchemy as sa
from datetime import datetime
import pytz

# revision identifiers, used by Alembic.
revision = 'add_auth_logs_table'
down_revision = None
branch_labels = None
depends_on = None

def upgrade():
    op.create_table('auth_logs',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('username', sa.String(length=80), nullable=False),
        sa.Column('attempt_date', sa.DateTime(), nullable=False, default=datetime.now(pytz.timezone('America/Campo_Grande'))),
        sa.Column('ip_address', sa.String(length=45), nullable=False),
        sa.PrimaryKeyConstraint('id')
    )

def downgrade():
    op.drop_table('auth_logs') 