// Função para atualizar o relógio
function atualizarRelogio(relogio) {
    const agora = new Date();
    
    // Formatar hora
    const hora = agora.toLocaleTimeString('pt-BR', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    });
    
    // Atualizar texto
    relogio.horaElement.textContent = hora;
    
    // Aplicar tamanhos salvos
    relogio.ajustarTamanho();
}

class NoticiaAdaptativa {
    constructor() {
        this.container = document.querySelector('.noticias-container');
        this.maxWidth = 0.95; // 95% da largura disponível
        this.maxHeightTitulo = 0.2; // 20% da altura para o título
        this.maxHeightConteudo = 0.7; // 70% da altura para o conteúdo
        
        // Criar elementos de teste
        this.criarElementosTeste();
    }

    criarElementosTeste() {
        // Elementos de teste ocultos
        this.tituloTest = document.createElement('div');
        this.conteudoTest = document.createElement('div');
        
        const styles = {
            position: 'absolute',
            visibility: 'hidden',
            whiteSpace: 'normal', // Permitir quebra de linha
            width: `${this.maxWidth * 100}%`,
            padding: '20px',
            boxSizing: 'border-box'
        };
        
        Object.assign(this.tituloTest.style, styles);
        Object.assign(this.conteudoTest.style, styles);
        
        document.body.appendChild(this.tituloTest);
        document.body.appendChild(this.conteudoTest);
    }

    calcularTamanhoOtimo(elemento, texto, maxHeight, minSize = 12, maxSize = 200) {
        elemento.textContent = texto;
        let tamanho = minSize;
        
        while (tamanho < maxSize) {
            elemento.style.fontSize = `${tamanho}px`;
            if (elemento.offsetHeight > maxHeight) break;
            tamanho++;
        }
        
        return Math.max(minSize, tamanho - 1);
    }

    ajustarNoticia(noticiaElement) {
        const containerHeight = this.container.offsetHeight;
        const titulo = noticiaElement.querySelector('h2');
        const conteudo = noticiaElement.querySelector('.conteudo');
        const imagem = noticiaElement.querySelector('img');
        
        // Se não tiver imagem, ajustar como notícia apenas texto
        if (!imagem && titulo && conteudo) {
            noticiaElement.classList.add('apenas-texto');
            
            // Calcular tamanhos
            const tamanhoTitulo = this.calcularTamanhoOtimo(
                this.tituloTest,
                titulo.textContent,
                containerHeight * this.maxHeightTitulo,
                24 // tamanho mínimo
            );
            
            const tamanhoConteudo = this.calcularTamanhoOtimo(
                this.conteudoTest,
                conteudo.textContent,
                containerHeight * this.maxHeightConteudo,
                18 // tamanho mínimo
            );
            
            // Aplicar tamanhos
            titulo.style.fontSize = `${tamanhoTitulo}px`;
            conteudo.style.fontSize = `${tamanhoConteudo}px`;
        }
    }

    destruir() {
        this.tituloTest.remove();
        this.conteudoTest.remove();
    }
}

// Função para controlar o carrossel
class Carrossel {
    constructor() {
        this.noticias = document.querySelectorAll('.noticia-item');
        this.atual = 0;
        this.intervalo = null;
        this.tempoExibicao = 30000; // 30 segundos
    }

    mostrarNoticia(index) {
        // Remove a classe ativo de todas as notícias
        this.noticias.forEach(noticia => {
            noticia.classList.remove('ativo');
            noticia.style.opacity = '0';
        });

        // Adiciona a classe ativo à notícia atual
        this.noticias[index].classList.add('ativo');
        setTimeout(() => {
            this.noticias[index].style.opacity = '1';
        }, 50);
    }

    proximaNoticia() {
        this.atual = (this.atual + 1) % this.noticias.length;
        this.mostrarNoticia(this.atual);
    }

    iniciar() {
        if (this.noticias.length > 0) {
            // Mostra a primeira notícia
            this.mostrarNoticia(this.atual);

            // Inicia o loop
            this.intervalo = setInterval(() => {
                this.proximaNoticia();
            }, this.tempoExibicao);
        }
    }

    parar() {
        if (this.intervalo) {
            clearInterval(this.intervalo);
        }
    }
}

class RelogioAdaptativo {
    constructor() {
        this.container = document.querySelector('.relogio-container');
        this.horaElement = document.getElementById('hora');
        this.maxWidth = 0.95;
        this.maxHeight = 0.8;
        
        // Criar elemento de teste
        this.criarElementoTeste();
        
        // Fazer cálculo inicial
        this.calcularTamanhos();
    }

    criarElementoTeste() {
        this.horaTest = document.createElement('div');
        
        const styles = {
            position: 'absolute',
            visibility: 'hidden',
            whiteSpace: 'nowrap',
            width: 'auto',
            height: 'auto',
            fontFamily: window.getComputedStyle(this.horaElement).fontFamily
        };
        
        Object.assign(this.horaTest.style, styles);
        this.horaTest.textContent = "00:00:00";
        document.body.appendChild(this.horaTest);
    }

    calcularTamanhos() {
        // Obter dimensões disponíveis
        const containerWidth = this.container.offsetWidth * this.maxWidth;
        const containerHeight = this.container.offsetHeight * this.maxHeight;
        
        // Calcular área disponível para o relógio (considerando os logos)
        const relogioWidth = containerWidth * 0.5; // 50% da largura disponível
        const relogioHeight = containerHeight;
        
        // Começar com um tamanho pequeno
        let tamanho = 10;
        this.horaTest.style.fontSize = tamanho + 'px';
        
        // Aumentar o tamanho até atingir o limite de largura ou altura
        while (
            this.horaTest.offsetWidth < relogioWidth &&
            this.horaTest.offsetHeight < relogioHeight &&
            tamanho < 500
        ) {
            tamanho++;
            this.horaTest.style.fontSize = tamanho + 'px';
        }
        
        // Reduzir um pouco para garantir que cabe
        tamanho = Math.floor(tamanho * 0.95);
        
        // Calcular proporções
        const proporcaoLargura = relogioWidth / this.horaTest.offsetWidth;
        const proporcaoAltura = relogioHeight / this.horaTest.offsetHeight;
        
        // Usar a menor proporção para garantir que cabe em ambas as dimensões
        const proporcaoFinal = Math.min(proporcaoLargura, proporcaoAltura);
        
        // Calcular tamanho final
        this.horaSize = Math.floor(tamanho * proporcaoFinal);
        
        // Garantir tamanho mínimo
        this.horaSize = Math.max(24, this.horaSize);
    }

    ajustarTamanho() {
        // Recalcular tamanhos se o container mudou de tamanho
        const novaLargura = this.container.offsetWidth;
        const novaAltura = this.container.offsetHeight;
        
        if (this.ultimaLargura !== novaLargura || this.ultimaAltura !== novaAltura) {
            this.calcularTamanhos();
            this.ultimaLargura = novaLargura;
            this.ultimaAltura = novaAltura;
        }

        // Aplicar tamanho calculado
        this.horaElement.style.fontSize = this.horaSize + 'px';
    }

    destruir() {
        if (this.horaTest) {
            this.horaTest.remove();
        }
    }
}

// Inicializar quando o documento estiver pronto
document.addEventListener('DOMContentLoaded', () => {
    // Inicializar relógio
    const relogio = new RelogioAdaptativo();
    
    function atualizarRelogio() {
        const agora = new Date();
        const hora = agora.toLocaleTimeString('pt-BR', {
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
        });
        
        relogio.horaElement.textContent = hora;
        relogio.ajustarTamanho();
    }
    
    // Primeira execução
    atualizarRelogio();
    
    // Atualizar a cada segundo
    setInterval(atualizarRelogio, 1000);

    // Ajustar quando a janela for redimensionada
    let resizeTimeout;
    window.addEventListener('resize', () => {
        clearTimeout(resizeTimeout);
        resizeTimeout = setTimeout(() => {
            relogio.ajustarTamanho();
        }, 100);
    });

    // Inicializar carrossel
    const carrossel = new Carrossel();
    carrossel.iniciar();

    // Limpar ao fechar a página
    window.addEventListener('unload', () => {
        carrossel.parar();
        relogio.destruir();
    });
}); 